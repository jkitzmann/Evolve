package com.cigniti.automation.BusinessFunctions;

import java.util.Map;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.Utilities.WritingExcel;

public class LOUniqueCourseFulfillmentfromSearchResultsPage_LO_15100 extends EvolveCommonBussinessFunctions{
	public static Map<String, String> values=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC_9804", configProps.getProperty("TestData"));
	public static String noenrollment="0";
	public static String noComment="";
	public static String adoptionStatus;
	public static boolean getCourseId(String statusAfterEmailSent,String productId,String username) throws Throwable{
		boolean flag=true;
		try{
			courseID1=getAttribute(ElsevierObjects.adoptionRequestCourseId1,"value", "Get courseId1");
			if(courseID1!=null){
				Reporters.SuccessReport("Fetching The Course ID.", "Fetched Course ID:"+courseID1);
			}
			else{
				Reporters.failureReport("Fetching The Course ID.", "Failed To Fetch Course ID");
		 
			}
			String ID=courseID1.split("_")[2];
			int IDlength=ID.length();
			System.out.println("ID:"+ID);
			System.out.println("courseID1:"+courseID1);
			ReadingExcel.updateCellInSheet(1,12,configProps.getProperty("TestData"), "TC-10410", courseID1);
	
		    adoptionStatus=getText(ElsevierObjects.adoptionRequestafterSave, "adoptionRequestafterSave");
		    System.out.println("adoptionStatus:"+adoptionStatus);
		    System.out.println("statusAfterEmailSent:"+statusAfterEmailSent);
		    if(adoptionStatus.equals(statusAfterEmailSent) && courseID1.contains(productId) && courseID1.contains(username) && IDlength==4){
	
		    	Reporters.SuccessReport("Verifying Status After Email Sent And  Course Id Format.", "Verified "+adoptionStatus+" Status After Email Sent.</br>Succesfully Verified Course ID Format (productID)_(instructorname on the AR)_(4 digit number):"+courseID1);
			}
		    else{
				Reporters.failureReport("Verifying Status After Email Sent And  Course Id Format.", "Failed To Verify Status After Email Sent.</br>Failed To Verify Course ID Format (productID)_(instructorname on the AR)_(4 digit number).");
		    }
		}
		 catch(Exception e){sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
		return flag;
	}

	public static boolean searchResultVerifyLOStatusInARPage(String format_LO,String Username,String Password) throws Throwable{
		boolean flag=true;
		try{
		courseID1=getAttribute(ElsevierObjects.adoptionRequestCourseId1,"value", "Get courseId1");
		// String adoptionrequeststatus=getText(ElsevierObjects.adoptionRequestFulfillStatus,"");
		//	String statusAfterEmailSent=ReadingExcel.columnDataByHeaderName("verifyStatusAfterEmailSent", "TC-10410", configProps.getProperty("TestData"));

		//if(adoptionrequeststatus.contains(statusAfterEmailSent) && courseID1.equals("("+productId+")"+"_"+"("+username+")"+"_"+"([0-9])")){
		if(getAccountDetailsFirstName.contains(adoptionRequest_FirstName) && getAccountDetailsLastName.contains(adoptionRequest_LastName) && getAccountDetailsEmail.contains(adoptionRequest_Email) && getAccountDetailsInstitution.contains(adoptionRequest_Institution) && getAccountDetailsPhone.contains(adoptionRequest_Phone) && Username.contains(adoptionRequest_Username) && Password.contains(adoptionRequest_Password) && adoptionRequest_Country.contains(getAccountDetailsCountry)){
			Reporters.SuccessReport("Verifying The User Information In Matches That Of Instructor.", "Verified Firstname:"+adoptionRequest_FirstName+",Lastname:"+adoptionRequest_LastName+",Email:"+adoptionRequest_Email+",Institution:"+adoptionRequest_Institution+",Usernmae:"+adoptionRequest_Username+",Password:"+adoptionRequest_Password+",Phone:"+adoptionRequest_Phone+",Country:"+adoptionRequest_Country+",Adress:"+adoptionRequest_Country);
		}
		else{
			Reporters.failureReport("Verifying The User Information In Matches That Of Instructor.", "Failed To Verify User Details In Adoption Request Details Page.");
		
		}
		if(title.contains(adoptionRequest_producttitle) && Isbn.contains(adoptionRequest_Isbn) && author.contains(adoptionRequest_Author) && productType.contains(adoptionRequest_ProductType) && adoptionRequest_Format.contains(format_LO)){
			Reporters.SuccessReport("Verifying the product information is correct per the online course ordered ", "Verified ISBN:"+adoptionRequest_Isbn+",Title:"+adoptionRequest_producttitle+",ProductType:"+adoptionRequest_ProductType+",Author:"+adoptionRequest_Author+",Format:"+adoptionRequest_Format);
		}
		else{
			Reporters.failureReport("Verifying the product information is correct per the online course ordered ", "Failed To Verify the product information is correct per the online course ordered.");
		}		
		
		//String changeStatus=ReadingExcel.columnDataByHeaderName("changeStatus", "TC_9804", testDataPath);

		
			Thread.sleep(medium);				
			click(ElsevierObjects.adoptionRequest_Save,"Click on Save button.");
			Thread.sleep(high);
			/*click(ElsevierObjects.emailPopup,"Click on Send mail button on popup.");
			Thread.sleep(medium);*/
		}
		 catch(Exception e){sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
		return flag;
		}
	}
