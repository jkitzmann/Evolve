package com.cigniti.automation.BusinessFunctions;

import java.util.Map;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class ConvertLOCourseToTrial_15567  extends EvolveCommonBussinessFunctions{

	//public static Map<String, String> values=readcolumns.twoColumnsBasedOnSheetName(0, 1, "Tc-9804", configProps.getProperty("TestData"));
public static boolean checkConvertToTrialPopup() throws Throwable{
	
	boolean flag=true;
	try{
		if(isEnabled(ElsevierObjects.adoptionRequest_ConvertToTrial, "")){
			Reporters.SuccessReport("Verifying Whether 'Convert Request to Trial' button present and enabled. ", "Convert To Trial Button Is Present And It Is In Enabled State.");
		}
		else{
			Reporters.failureReport("Verifying Whether 'Convert Request to Trial' button present and enabled. ", "Convert To Trial Button Is Not In Enable State.");
		}
		if(javaClick(ElsevierObjects.adoptionRequest_ConvertToTrial, "Click on convert to permanent button")){
			Reporters.SuccessReport("Clicking On 'Convert Request to Trial' button. ", "Clicked On Convert To Trial Button.");
		}
		else{
			Reporters.failureReport("Clicking On 'Convert Request to Trial' button. ", "Failed To Click On Convert To Trial Button.");
		}
		org.openqa.selenium.Alert alert;
		alert = driver.switchTo().alert();
		Thread.sleep(medium);
		alert.dismiss();
		Reporters.SuccessReport("Clicking On Cancel Button In Popup", "Successfully clicked On Cancel Button In Convert Request to Trial Popup.</br>User is returned to Adoption Request Details page");
		if(javaClick(ElsevierObjects.adoptionRequest_ConvertToTrial, "Click on convert to permanent button")){
			Reporters.SuccessReport("Clicking On 'Convert Request to Trial' button. ", "Clicked On Convert To Trial Button.");
		}
		else{
			Reporters.failureReport("Clicking On 'Convert Request to Trial' button. ", "Failed To Click On Convert To Trial Button.");
		}
		Alert();
		if(verifyText(ElsevierObjects.adoptionRequest_ConvertMessage, verifymessage, "Verify convert to permanent message.")){
		Reporters.SuccessReport("Verifying Success Message After Converting Trial Course To Permanent. ", "Successfully Verified Success Message:"+verifymessage);
		}
		else{
			Reporters.failureReport("Verifying Success Message After Converting Trial Course To Permanent. ", "Failed To Verify Success Message.");
		}
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
	return flag;
}
public static boolean rosterErrorMessage(String errorMssg) throws Throwable{
	boolean flag=true;
	try{	
		if(verifyText(ElsevierObjects.evolve_SubmitLink_RosteErrorMessg, errorMssg, "Verify roster error message.")){
			Reporters.SuccessReport("Verifying Error Message is Received.", "Error Message is Received:"+errorMssg);
		}
		else{
			Reporters.failureReport("Verifying Error Message is Received.", "No Error Message Is Received.");
		}
	}
		catch(Exception e){
		sgErrMsg=e.getMessage();
		System.out.println(e);return false;
		}
	return flag;
}
public static boolean verifyNoTrial() throws Throwable{
	boolean flag=true;
		try{
	
		trialStatus=getText(ElsevierObjects.Admin_Apprstatus_Trial, "Get status of Trial.");
		if(trialStatus.equals("")){
			System.out.println("Trial status matched.");
			}
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
	return flag;
	}
public static boolean verifyDetailsInAdoptionPage(String format_LO) throws Throwable{
	boolean flag=true;
	try{
	System.out.println("lmsvalue:"+lmsvalue);
    System.out.println("adoptionRequest_Format"+adoptionRequest_Format);
   
      if(adoptionRequest_Format.contains(format_LO) && adoptionRequest_Trial.contains(TrialStatus)){
    	 Reporters.SuccessReport("Verifying product Information In Adoption Request Details Page.", "Verified Format:"+adoptionRequest_Format+",Trial:"+adoptionRequest_Trial);
      }
      else{
    	  Reporters.failureReport("Verifying product Information In Adoption Request Details Page.", "Failed To Verify product Information In Adoption Request Details Page.");
      
    }
	}
      catch(Exception e){
    	  sgErrMsg=e.getMessage();
  		System.out.println(e);return false;
  	}
    return flag;
}
}