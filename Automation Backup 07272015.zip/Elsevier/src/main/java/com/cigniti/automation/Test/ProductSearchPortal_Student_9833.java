package com.cigniti.automation.Test;

import java.util.Random;

import jxl.Sheet;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ElsevierConstants;
import com.cigniti.automation.Utilities.ExcelLib;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class ProductSearchPortal_Student_9833 extends User_BusinessFunction {
	
	Random ra = new Random( System.currentTimeMillis() );
	
	@Test
	public void ProductSearchPortal_Student_9833() throws Throwable
	
	{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		String Catalogs=ReadingExcel.columnDataByHeaderName("Catalogs", "TC-9833", configProps.getProperty("TestData"));
		String Catalogs1=ReadingExcel.columnDataByHeaderName("Catalogs1", "TC-9833", configProps.getProperty("TestData"));
		String honeyPotString=ReadingExcel.columnDataByHeaderName("HoneyPots", "TC-9833", configProps.getProperty("TestData"));
		String [] HoneyPots=honeyPotString.split(",");
		System.out.println(Catalogs);
		

		
		writeReport(User_BusinessFunction.Studentlogin(sStudentUser, sStudentPassword),"Login to Application Using User Credentials"+sStudentUser,
        		                                                                           "Launching the URL for User is successful </br > Login to Application Using User credentails :"+sStudentUser+" is Successful",
                		                                                           "Launching and Login to Application Using User credentails : "+ sStudentUser+" is Failed");
		   Thread.sleep(10000);
		writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as:"+sStudentUser,
                "Navigating to CATALOG page is Successful",
                "Navigating to CATALOG Page is failed");

       writeReport(User_BusinessFunction.HESI_Search(Catalogs),"Searching for Value:"+Catalogs,
                  "Entered "+Catalogs+" to Search </br > Click on Go Button",
                  "Unable to Search for : "+ Catalogs);
       Thread.sleep(medium);
        writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Authorlocator,ElsevierObjects.Title,ElsevierObjects.ProductTypeLocatorforStudent,Catalogs),"Verifying Values Present in Results",
                                    "The Acutal Value from  Application is : </br>"+Catalogs+"</br> is Presented in the Exepcted Values  of all first page results, Hence Search is as expected",
                                    "The Acutal Value from  Application is : </br>"+Catalogs+"</br> is Not Presented in the Exepcted Values  of all first page results, Hence Search is not as expected");

         writeReport(User_BusinessFunction.HESI_Search(Catalogs,Catalogs1),"Searching for Value:"+Catalogs +"And "+Catalogs1,
                               "Entered "+Catalogs+" and "+Catalogs1 +"to Search </br > Click on Go Button",
                               "Unable to Search for : "+ Catalogs +" And "+Catalogs1 );

         Thread.sleep(medium);
          writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Authorlocator,ElsevierObjects.Title,ElsevierObjects.ProductTypeLocatorforStudent,Catalogs,Catalogs1),"Verifying Values Present in Results",
                            "The Acutal Value from  Application is : </br>"+Catalogs+"</br> is Presented in the Exepcted Values  of all first page results, Hence Search is as expected",
                         "The Acutal Value from  Application is : </br>"+Catalogs+"</br> is Not Presented in the Exepcted Values  of all first page results, Hence Search is not as expected");

         /*
         writeReport(User_BusinessFunction.Studentlogin(sStudentUser, sStudentPassword),"Login to Application Using User Credentials"+sStudentUser,
                          "Launching the URL for User is successful </br > Login to Application Using User credentails :"+sStudentUser+" is Successful",
                          "Launching and Login to Application Using User credentails : "+ sStudentUser+" is Failed");
         */

         writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as:"+sStudentUser,
                                         "Navigating to CATALOG page is Successful",
                                           "Navigating to CATALOG Page is failed");

for(int i=0;i<=HoneyPots.length;i++)
{
writeReport(User_BusinessFunction.NavigateToCatalogHome(),"Navigating to CATALOG Page using Roles as:"+sStudentUser,
"Navigating to CATALOG page is Successful",
"Navigating to CATALOG Page is failed");

Thread.sleep(medium);	
writeReport(User_BusinessFunction.SearchinHoneyPots_Student(HoneyPots[i], Catalogs),"Searching In Honey Pot: "+HoneyPots[i],
"Searching "+Catalogs+" from "+HoneyPots[i]+" Honey Pot page is Successful",
"Searching "+Catalogs+" from "+HoneyPots[i]+" Honey Pot page is not Successful");
Thread.sleep(medium);	
writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Authorlocator,ElsevierObjects.Title,ElsevierObjects.ProductTypeLocatorforStudent,Catalogs),"Verifying Values Present in Results",
"The Acutal Value from  Application is : </br>"+Catalogs+"</br> is Presented in the Exepcted Values  of all first page results, Hence Search is as expected",
"The Acutal Value from  Application is : </br>"+Catalogs+"</br> is Not Presented in the Exepcted Values  of all first page results, Hence Search is not as expected");
}
writeReport(User_BusinessFunction.Logout(),"Clicking on Logout",
     "Clicking on Logout is Successful",
     "Clicking on Logout is not Successful");
		}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
	}
	/*@AfterClass
	public static void browserStop()
	{
		driver.close();
	}*/
	
	

