package com.cigniti.automation.BusinessFunctions;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.sourceforge.htmlunit.corejs.javascript.ast.ThrowStatement;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class ECommercePreorderALaCarte_Student_SplitOrders1_15597 extends EComm_Preorder_MyEvolve_Page_15452_Bussiness_Functions {

	public static String cardType;
	public static String cardNum;
	public static String cVV;
	public static String name;
	public static String expireYr;
	public static String expireMonth;
	public static int count1;
	public static int count;


	public static boolean updateAccount(String user,String street, String city, String state, String zip) throws Throwable{
		boolean flag=true;
		try{

			// click(ElsevierObjects.Educator_Reedemchkout_btn,"Click on Reedeem Checkout button");
			if(user.equalsIgnoreCase("student")){
				click(ElsevierObjects.Student_Shipping_Chk,"Click check box");
				Thread.sleep(3000);
			}
			if(type(ElsevierObjects.Student_Shipping_Addr1, street,"Enter student Street"))
				Thread.sleep(3000);
			type(ElsevierObjects.Student_Shipping_City,city,"Enter student City");
			Thread.sleep(3000);
			selectByValue(ElsevierObjects.Student_Shipping_State,state, "State name");
			Thread.sleep(3000);
			type(ElsevierObjects.Student_Shipping_Zip,zip,"Enter student Zip code");
			Thread.sleep(3000);
			type(ElsevierObjects.evolve_User_street,street,"Enter user street address");
			Thread.sleep(3000);
			type(ElsevierObjects.evolve_User_City,city,"Enter user city name");
			selectByValue(ElsevierObjects.evolve_User_State,state, "State name");
			type(ElsevierObjects.evolve_User_Postal,zip,"Enter User Postal code");
			if(isChecked(ElsevierObjects.Student_Shipping_AccpChk, "Click Check Box to Accept")){
				if(click(ElsevierObjects.Student_Shipping_ContBtn,"Click Continue Button")){
					Reporters.SuccessReport("Entering Shipping And Billing Address.", "Successfully Entered Shipping And Billing Address: Street:"+street+",City:"+city+",State:"+state+",ZIP:"+zip+".</br>Successfully Clicked On Continue Button.");
				}
				else{
					Reporters.failureReport("Entering Shipping And Billing Address.", "Failed To Enter Shipping And Billing Address: Street:"+street+",City:"+city+",State:"+state+",ZIP:"+zip+"</br>Failed To Click On Continue Button.");
				}
			}
			else
			{
				flag=true;
				click(ElsevierObjects.Student_Shipping_AccpChk,"Click Continue Button");
				if(click(ElsevierObjects.Student_Shipping_ContBtn,"Click Continue Button")){
					Reporters.SuccessReport("Entering Shipping And Billing Address.", "Successfully Entered Shipping And Billing Address: Street:"+street+",City:"+city+",State:"+state+",ZIP:"+zip+".</br>Successfully Clicked On Continue Button.");
				}
				else{
					Reporters.failureReport("Entering Shipping And Billing Address.", "Failed To Enter Shipping And Billing Adress: Street:"+street+",City:"+city+",State:"+state+",ZIP:"+zip+"</br>Failed To Click On Continue Button.");
				}
			}
			Thread.sleep(veryhigh);
			switchToFrameByLocator(ElsevierObjects.Student_register_frame,"Switch to frame");
			click(ElsevierObjects.Student_register_UseAdress_btn,"Click UsethisAdress Button");
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;


	}
	public static boolean getStudentAccountDetails() throws Throwable{
		boolean flag=true;
		try{

			if(!click(ElsevierObjects.myAccount,"click on my account")){
				flag=false;
			}
			Thread.sleep(5000);
			if(!click(ElsevierObjects.myAccount_AccountSettings,"click on account settings.")){
				flag=false;
			}
			Thread.sleep(3000);
			//String firstName=getText(ElsevierObjects.educator_form_txtFirstName, "Get first name");
			getAccountDetailsUserName=getAttribute(ElsevierObjects.educator_form_UserName, "value", "Get first name");
			getAccountDetailsFirstName=getAttribute(ElsevierObjects.educator_form_txtFirstName, "value", "Get first name");
			getAccountDetailsLastName=getAttribute(ElsevierObjects.educator_form_txtLastName,"value","Get Last Name");
			getAccountDetailsEmail=getAttribute(ElsevierObjects.educator_form_txtEmail,"value","Get email id.");
			/*getAccountDetailsInstitution=getAttribute(ElsevierObjects.educator_form_txtInstution, "value","Get Institution name");
		getAccountDetailsPhone=getAttribute(ElsevierObjects.educator_form_txtAddPhone,"value","Get phone number");
		getAccountDetailsStreetAddress=getAttribute(ElsevierObjects.educator_form_txtAddress,"value", "Get Street Adress");
		getAccountDetailsCountry=getAttribute(ElsevierObjects.educator_form_ddInstutionCountry,"value", "Get country of institution.");*/
			Thread.sleep(2000);
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(2000);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	public static boolean viewOrEditUserProfile(String userName) throws Throwable{
		boolean flag=true;
		try{
			click(ElsevierObjects.EVOLVE_ADMIN_VIEWPROFILE_LINK,"Click on View/Edit User Profile Link.");
			//type(ElsevierObjects.ADMIN_VIEWPROFILE_FIRSTNAME,firstName,"Enter FirstName.");
			//type(ElsevierObjects.ADMIN_VIEWPROFILE_LASTNAME,lastName,"Enter LastName.");
			type(ElsevierObjects.ADMIN_VIEWPROFILE_USERNAME,userName,"Enter UserName.");
			//type(ElsevierObjects.ADMIN_VIEWPROFILE_EMAIL,email,"Enter Email.");
			click(ElsevierObjects.ADMIN_VIEWPROFILE_SEARCH, "Click on ViewProfile Search Button.");
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	public static boolean orderHistoryInAdmin() throws Throwable{
		boolean flag=true;
		try{
			click(ElsevierObjects.ADMIN_VIEWPROFILE_SEARCHRESULT,"Click on User.");
			click(ElsevierObjects.ADMIN_VIEWPROFILE_ORDERHITSORY,"Click on OrderHistory Button.");

		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;

	}
	public static boolean verifyMessageInReviewPage(String ISBN1,String ISBN2,String ISBN3,String ISBN4,String ISBN5,String date) throws Throwable{
		boolean flag=true;

		try{
			String s=date;
			SimpleDateFormat ft = new SimpleDateFormat("MM-dd-yyyy");
			Date d1=new SimpleDateFormat("yyyyMMdd").parse(s);
			String verifydate=ft.format(d1);
			System.out.println(ft.format(d1));
			ArrayList<String> list1=new ArrayList<String>();

			list1.add(ISBN1);
			list1.add(ISBN2);
			list1.add(ISBN3);
			list1.add(ISBN4);
			list1.add(ISBN5);
			Thread.sleep(10);
			for(String list2 : list1){
				try{
					Thread.sleep(low);
					String message=getText(By.xpath(".//*[@id='"+list2+"']/div[8]"),"To review your order at any time");	
					if((message !=null )&& message.contains("To review your order at any time"))
					{
						if(message.contains(verifydate)){
							Reporters.SuccessReport("Verifying Notification Message in Review Page for The Item :"+list2, "Notification Message is"+message+"</br>Successfully Verified Publication date : "+verifydate+" In Notification Message.");
						}
						else{
							Reporters.failureReport("Verifying Notification Message in Review Page for The Item :"+list2, "Failed To Verify Notification Message.");
						}
					}

					//break;
				}
				catch(Exception e){
					sgErrMsg=e.getMessage();
				}
			}
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
		}
		return flag;
	}
	public static boolean Checkout() throws Throwable{
		boolean flag=true;
		try{
			if(click(ElsevierObjects.btnRedeem,"Click on My Cart checkout Button")){
				Reporters.SuccessReport("Clicking On Checkout Button in My cart Page.", "Successfully Clicked On Checkout Button In My cart Page.</br>User Is Navigated To Update Account Page.");
			}
			else{
				Reporters.failureReport("Clicking On Checkout Button in My cart Page.", "Failed To Click On Checkout Button In My cart Page.</br>Failed To Navigate To Update Account Page.");
			}
			Thread.sleep(high);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	public static boolean cacelPreOrder(String isbnNumber) throws Throwable{
		boolean flag=true;
		try{
			System.out.println("");
			List<WebElement> isbNumberList = driver.findElements(By.xpath(".//*[@id='orderDetails']//table//table//table//table//tr//td[text()=' "+isbnNumber+"']"));
			for(WebElement webElement : isbNumberList){
				if(webElement.getTagName().equalsIgnoreCase("td")){
					//if(webElement.getText().equalsIgnoreCase("ISBN")){
					if(webElement.getText().contains(isbnNumber)){
						if(click(By.xpath(".//*[@id='orderDetails']//tr[*]//td//input"), "Click On Cancel PreOrder Button")){
							Reporters.SuccessReport("Clicking On Cancel PreOrder Button For ISBN: "+isbnNumber, "Successfully Clicked On Cancel PreOrder Button For ISBN: "+isbnNumber);
						}
						else{
							Reporters.failureReport("Clicking On Cancel PreOrder Button For ISBN: "+isbnNumber, "Failed To Click on Cancel PreOrder Button For ISBN: "+isbnNumber);
						}
					}
				}
			}
			//}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	public static boolean verifyCancelPreOrderButton(String isbnNumber) throws Throwable{
		boolean flag=true;
		try{
			System.out.println("");
			List<WebElement> isbNumberList = driver.findElements(By.xpath(".//*[@id='orderDetails']//table//table//table//table//tr//td[text()=' "+isbnNumber+"']"));
			for(WebElement webElement : isbNumberList){
				if(webElement.getTagName().equalsIgnoreCase("td")){
					//if(webElement.getText().equalsIgnoreCase("ISBN")){
					if(webElement.getText().contains(isbnNumber)){
						if(isElementPresent(By.xpath(".//*[@id='orderDetails']//tr[*]//td//input"))){
							Reporters.SuccessReport("Verifying user can see Cancel PRE-order Item button for the ISBN: "+isbnNumber, "Successfully Verified Cancel PreOrder Button For ISBN: "+isbnNumber);
						}
						else{
							Reporters.failureReport("Verifying user can see Cancel PRE-order Item button for the ISBN: "+isbnNumber, "Failed To Verify Cancel PreOrder Button For ISBN: "+isbnNumber);
						}
					}
				}
			}
			//}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	public static boolean verifyCancelPreOrderPopup(String message,String note) throws Throwable{
		boolean flag=true;
		try{
			isElementPresent(ElsevierObjects.CANCEL_PREORDER_POPUPHEADER,"CANCEL_PREORDER_POPUPHEADER");
			verifyText(ElsevierObjects.CANCEL_PREORDER_MESSAGE, message, "Verify Message On PopUp.");
			verifyText(ElsevierObjects.CANCEL_PREORDER_NOTE, note, "Verify Note On PopUp.");
			isElementPresent(ElsevierObjects.CANCEL_PREORDER_SAVE, "Verify Save Button In PopUp.");
			isElementPresent(ElsevierObjects.CANCEL_PREORDER_CANCEL, "Verify Cancel Button In PopUp.");
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;

	}
	public static void hitCancelButtonInPreOrderPopup() throws Throwable{

		try{
			if(click(ElsevierObjects.CANCEL_PREORDER_CANCEL,"Click On Cancel PREorder Button")){
				Reporters.SuccessReport("Clicking On Cancel Button In Cancel PREorder popUp.", "Successfully Clicked On Cancel Button In Cancel PRE-Order PopUp.");
			}
			else{
				Reporters.failureReport("Clicking On Cancel Button In Cancel PREorder popUp.", "Failed To Click On Cancel Button In Cancel PRE-Order PopUp.");
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}

	}
	public static void hitSaveButtonInCancelPreorder() throws Throwable{

		try{
			if(click(ElsevierObjects.CANCEL_PREORDER_SAVE, "Click On Save Button.")){
				Reporters.SuccessReport("Clicking On Save Button In Cancel PRE-Order popUp.", "Successfully Clicked On Save Button In Cancel PRE-Order PopUp.");
			}
			else{
				Reporters.failureReport("Clicking On Save Button In Cancel PRE-order popUp.", "Failed To Click On Save Button In Cancel PRE-Order PopUp.");
			}
			Thread.sleep(4000);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	public static void enterMessage(String message) throws Throwable{
		try{
			if(type(ElsevierObjects.CANCEL_PREORDER_ENTERMESSAGE,message,"Enter Message In Text box.")){
				Reporters.SuccessReport("Entering Message In Cancel PreOrder PopUp.", "Successfully Entered Message In Cancel PRE-Order PopUp :"+message);
			}
			else{
				Reporters.failureReport("Entering Message In Cancel PreOrder PopUp.", "Failed To Enter Message In Cancel PRE-Order PopUp.");
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	public static void verifyErrorMessage() throws Throwable{
		try{
			String errormssg=getText(ElsevierObjects.CANCEL_PREORDER_ERRORMESSAGE, "Verifying Save Message.");
			if((errormssg !="")){
				Reporters.SuccessReport("Verifying Message After Clicking Save Button Without Entering Message.", "Successfully Verified Error Message After Clicking Save Button :"+errormssg);
			}
			else{
				Reporters.failureReport("Verifying Message After Clicking Save Button Without Entering Message.", "Failed To Verify Error Message.");
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	public static void verifySaveMessage() throws Throwable{
		try{
			String saveMessage=getText(ElsevierObjects.CANCEL_PREORDER_SAVEMESSAGE, "Verifying Save Message.");
			if((saveMessage !="")){
				Reporters.SuccessReport("Verifying Message After Saving Message In CancelPreorder PopUp. ", "Successfully Verified Message After Saving Message :"+saveMessage);
			}
			else{
				Reporters.failureReport("Verifying Message After Saving Message In CancelPreorder PopUp. ", "Failed To Verify Message After Saving Message In Cancel PRE-Order PopUp.");
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	public static void verifyStatusAfterCancel(String message,String status) throws Throwable{
		try{
			if(waitForVisibilityOfElement(ElsevierObjects.CANCEL_PREORDER_BUBBLE, "Wait For Visibility Of Bubble.")){
				click(ElsevierObjects.CANCEL_PREORDER_BUBBLE,"click on the Cancel PRE-Order Bubble");
				Thread.sleep(2000);
				String BubbleMessage=getText(ElsevierObjects.CANCEL_PREORDER_BUBBLEMESSAGE, "");

				if(BubbleMessage.contains(message)){
					Reporters.SuccessReport("Verifying a Bubble icon appears and Clicking on it shows the message that was entered earlier.", "Bubble Icon Appeared In Page And Clicked On Bubble Icon.</br>Verified Message In Bubble Icon PopUp.");
				}
				else{
					Reporters.failureReport("Verifying a Bubble icon appears and Clicking on it shows the message that was entered earlier.", "Failed To Verify Bubble Icon In Page And Failed To Click On Bubble Icon.</br>Failed To Verify Bubble Icon PopUp.");
				}
				javaClick(ElsevierObjects.CANCEL_PREORDER_BUBBLECLOSE,"Click On Close Button In PopUp.");
				Thread.sleep(2000);
				if(verifyText(ElsevierObjects.CANCEL_PREORDER_STATUS, status, "Verifying Status After Cancelling PRE-Order.")){
					Reporters.SuccessReport("Verifying the status of the order shows as cancelled.", "Successfully Verified Status Of The Order :"+status);
				}
				else{
					Reporters.failureReport("Verifying the status of the order shows as cancelled.", "Failed To Verify Status Of The Order.");
				}
			}

		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}



	public  static boolean  CreditCardData(String cardType,String cardNumber,String cvvNumber,String nameOnCard,String expMonth,String expYear) throws Throwable{
		boolean flag = true;
		//String errorMessage ="";
		try {
			if(!selectByVisibleText(ElsevierObjects.creditCard_form,cardType ," Clicked on CreditCard type visa")){
				flag = false;
			}
			Thread.sleep(3000);
			if(!type(ElsevierObjects.CreditCardNum,cardNumber, "Credit Card Num")){
				flag = false;
			}
			Thread.sleep(3000);
			if(!type(ElsevierObjects.CreditCardCvv,cvvNumber, "Credit Card Cvv")){
				flag = false;
			}
			Thread.sleep(3000);
			if(!type(ElsevierObjects.CreditCardName,nameOnCard, "Card Name")){
				flag = false;
			}
			Thread.sleep(3000);
			if(!selectByVisibleText(ElsevierObjects.CreditCardMonth,expMonth ," Select Month")){
				flag = false;
			}
			Thread.sleep(3000);
			if(!selectByVisibleText(ElsevierObjects.CreditCardyear,expYear ," Select Year")){
				flag = false;
			}
			Thread.sleep(3000);
			if(!click(ElsevierObjects.CreditCardSubmit, "Credit Card Submit")){
				flag = false;
			}
			Thread.sleep(veryhigh);


		} catch (Exception e) {
			System.out.println(e);
			//errorMessage =e.getMessage();
		}

		return flag;
	}
	/*public  static boolean  verifyMessageInReviewPage(String ISBN) throws Throwable{
	boolean flag = true;
	//String errorMessage ="";
	try {
		String message = getText(By.xpath("//*[@id='"+ISBN+"']/div[8]"), "");
		if(message != null){
			Reporters.SuccessReport("Verifying Notification Message In Review And Submit Page For Item :"+ISBN, "Successfully Verified Message :"+message+" In Review Page.");
		}
		else{
			Reporters.failureReport("Verifying Notification Message In Review And Submit Page For Item :"+ISBN, "Failed To Verify Message In Review And Submit Page.");
		}

	} catch (Exception e) {
		System.out.println(e);
	}
return flag;
}*/
	public static boolean searchISBNNumber(String iSBNumber,String button,String date,int row) throws Throwable{
		boolean flag = true;
		//String errorMessage ="";
		try{

			Thread.sleep(4000);
			if(click(ElsevierObjects.catalog, "Click On Catalog Button.")){
				Reporters.SuccessReport("Clicking On Catalog Tab", "Successfully Clicked On Catalog Tab.");
			}
			else{
				Reporters.failureReport("Clicking On Catalog Tab", "Failed To Click On Catalog Tab.");
			}
			Thread.sleep(4000);
			if(type(ElsevierObjects.txtproductsearch, iSBNumber, "Enter Isbn.")){
				Reporters.SuccessReport("Entering ISBN In Search Text Box.", "Successfully Entered ISBN :"+iSBNumber+"");
			}
			else{
				Reporters.failureReport("Entering ISBN In Search Text Box.", "Failed To Enter ISBN :"+iSBNumber);
			}
			Thread.sleep(4000);
			if(click(ElsevierObjects.gobutton, "Click On Search Go Button.")){
				Reporters.SuccessReport("Clicking On Go Button.", "Successfully Clicked On Go Button.");
			}
			else{
				Reporters.failureReport("Clicking On Go Button.", "Failed To Click On Go Button.");
			}
			Thread.sleep(high);
			if(click(ElsevierObjects.btnaddtocart, "Clicking On Product Request Button.")){
				Reporters.SuccessReport("Clicking On "+button+" Button.", "Successfully Clicked On "+button+" Button.");
			}
			else{
				Reporters.failureReport("Clicking On "+button+" Button.", "FailedTo Click On  "+button+" Button.");
			}
			Thread.sleep(veryhigh);
			//if(mssg.equalsIgnoreCase("true")){
			try{

				driver.findElement(By.xpath(".//*[@id='pageLayout-body-inner-most']/div//h1[contains(text(),'My Cart')]"));
				String price=getText(By.xpath(".//*[@id='"+iSBNumber+"']//following-sibling::div[@class='price span2']"),"");

				ReadingExcel.updateCellInSheet(row, 1, testDataPath, "TC-15597_PriceValues", price);
			}
			catch(Exception e){
				switchToFrameByLocator(ElsevierObjects.Student_register_frame, "Switch to iframe.");
				Thread.sleep(3000);
				click(ElsevierObjects.popUp_Apply, "Click on Apply button.");
				Thread.sleep(3000);
				if(isElementPresent(By.xpath(".//*[@id='pageLayout-body-inner-most']/div//h1[contains(text(),'My Cart')]"), "Get Text My Cart")){
					Reporters.SuccessReport("", "Navigated To My Cart Page.");
					String price=getText(By.xpath(".//*[@id='"+iSBNumber+"']//following-sibling::div[@class='price span2']"),"");

					ReadingExcel.updateCellInSheet(row, 1, testDataPath, "TC-15597_PriceValues", price);
				}
			}	
			/*String price=getText(By.xpath(".//*[@id='"+iSBNumber+"']//following-sibling::div[@class='price span2']"),"");

		ReadingExcel.updateCellInSheet(row, 1, testDataPath, "TC-15597_PriceValues", price);;*/

			//Changing Publication Date Format To Compare date in Evolve.
			String s=date;
			SimpleDateFormat ft = new SimpleDateFormat("MM-dd-yyyy");
			Date d1=new SimpleDateFormat("yyyyMMdd").parse(s);
			String verifydate=ft.format(d1);
			System.out.println(ft.format(d1));

			try{
				String message = getText(By.xpath("//*[@id='"+iSBNumber+"']/div[8]"), "");
				if((message !=null )&& message.contains("To review your order at any time")){
					if(message.contains(verifydate)){
						Reporters.SuccessReport("Verifying Notification Message In MyCart Page.", "Verified Notification Message For ISBN: "+iSBNumber+" And Notification Message is :"+message+".</br>Verified publication date : "+verifydate+" in Notification Message.");
					}
					else
					{
						Reporters.failureReport("Verifying Notification Message In MyCart Page", "Failed To Verify Notification Message.");
					}
				}
			}
			catch(Exception e){
				sgErrMsg=e.getMessage();return false;
			}
		}
		catch(Exception e){
			sgErrMsg =e.getMessage();return false;
		}
		//	finally{
		//		if(flag){
		//			Reporters.SuccessReport("Verify Notification Message", getText(By.xpath("//*[@id='"+iSBNumber+"']/div[8]"),""));
		//		}else{
		//			Reporters.failureReport("Verify Notification Message", "Unable to display Message Reson"+errorMessage);
		//		}
		//	}
		return flag;
	}


	public static boolean acceptAndContinue(String mssg,String user) throws Throwable{
		boolean flag = true;
		String errorMessage ="";
		try{
			if(user.equalsIgnoreCase("educator")){
				if(click(ElsevierObjects.evolveInstructorChk,"Click on I Am Instructor check box")){
					Reporters.SuccessReport("Clicking On I Am Instructor Checkbox.", "Successfully clicked On Yes I Am Instructor Checkbox.");
				}
				else{
					Reporters.failureReport("Clicking On I Am Instructor Checkbox.", "FailedTo Click On Yes I Am Instructor Checkbox.");
				}
			}
			if(click(ElsevierObjects.Student_accept_chk, "Clicking On Accept Checkbox.")){
				Reporters.SuccessReport("Clicking On Yes ,I Am Registerd User Checkbox.", "Successfully clicked On Yes ,I Am Registerd User Checkbox..");
			}
			else{
				Reporters.failureReport("Clicking On Yes ,I Am Registerd User Checkbox..", "FailedTo Click On Yes ,I Am Registerd User Checkbox..");
			}
			Thread.sleep(3000);
			if(click(ElsevierObjects.Student_Review_Submit, "Clicking On Submit in Review Page.")){
				Reporters.SuccessReport("Clicking On Submit Button In Review Page.", "Successfully clicked On Submit Button In Review Page.");
			}
			else{
				Reporters.failureReport("Clicking On Submit Button In Review Page.", "FailedTo Click On Submit Button In Review Page.");
			}
			Thread.sleep(veryhigh);
		}
		catch(Exception e){
			sgErrMsg = e.getMessage();return false;
		}
		return flag;
	}
	public static void verifyMessageInReceiptPage(String ISBN1,String ISBN2,String ISBN3,String ISBN4,String ISBN5,String date) throws Throwable{
		try{
			//driver.navigate().refresh();
			String s=date;
			SimpleDateFormat ft = new SimpleDateFormat("MM-dd-yyyy");
			Date d1=new SimpleDateFormat("yyyyMMdd").parse(s);
			String verifydate=ft.format(d1);
			System.out.println(ft.format(d1));

			ArrayList<String> list1=new ArrayList<String>();
			list1.add(ISBN1);
			list1.add(ISBN2);
			list1.add(ISBN3);
			list1.add(ISBN4);
			list1.add(ISBN5);

			try{
				for(String list : list1){

					String notification=getText(By.xpath("//*[@id='pageLayout-body-inner-most']//li/div//div[contains(text(),'"+list+"')]//following::div[contains(@class,'notification_box rounded')]"),"");
					Thread.sleep(4000);
					if(notification.contains("To review your order at any time")){
						if(notification.contains(verifydate)){
							Reporters.SuccessReport("Verifying Notification Message in Receipt Page.", "Verified Notification Message For ISBN: "+list+" And Notification Message is :"+notification+".</br>Verified publication date : "+verifydate+" in Notification Message.");
						}
						else
						{
							Reporters.failureReport("Verifying Notification Message in Receipt Page.", "Failed To Verify Notification Message.");
						}

					}
				}
			}
			catch(Exception e){
				sgErrMsg=e.getMessage();
			}
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
		}
	}
	public static void verifyOrderPricesHeadings(String subtotal,String discount,String tax,String total) throws Throwable{

		try{
			driver.navigate().refresh();
			List<WebElement> totalrows=driver.findElements(By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[@class='row']"));
			Thread.sleep(4000);
			ArrayList<String> list=new ArrayList<String>();
			list.add(subtotal);
			list.add(discount);
			list.add(tax);
			list.add(total);
			Thread.sleep(120);
			Thread.sleep(120);
			int orderlist=totalrows.size();
			//*[@class='store-content span24']/div[3]//table/tbody/tr//strong
			//*[@class='store-content span24']/div["++"]//table/tbody/tr["++"]
			for(int i=2;i<=orderlist+1;i++){
				//for(int j=1;j<=orderlist;j++){

				for(String list1 : list){
					String value=driver.findElement(By.xpath("//*[@class='store-content span24']/div["+i+"]//table/tbody/tr//strong[contains(text(),'"+list1+"')]")).getText();
					Thread.sleep(4000);
					if(value.contains(list1)){
						Reporters.SuccessReport("Verifying each Order Contains subtotal,discount,tax and total in confirmation page for Order.", "Successfully Verified "+list1+" in confirmnation page.");
					}
					else{
						Reporters.failureReport("Verifying each Order Contains subtotal,discount,tax and total in confirmation page for Order.", "Failed To Verify "+list1+" in confirmnation page.");
					}

					//	}
				}

				//}
			}
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
		}


	}


	public static void verifyOrderPagerDetails(String ISBN1,String ISBN2,String ISBN3,String ISBN4,String ISBN5,String date) throws Throwable{



		if(!click(ElsevierObjects.myAccount,"click on my account")){
			flag=false;
		}
		Thread.sleep(4000);
		if(click(ElsevierObjects.MYACCOUNT_ORDERHISTORY,"click on Order History.")){
			Reporters.SuccessReport("Clicking On Order History Link In My Account Tab.", "Successfully clicked On Order History Link In My Account Tab.");
		}
		else{
			Reporters.failureReport("Clicking On Order History Link In My Account Tab.", "FailedTo Click On Order History Link In My Account Tab.");
		}
		Thread.sleep(4000);
		driver.navigate().refresh();
		String s=date;
		SimpleDateFormat ft = new SimpleDateFormat("MM-dd-yyyy");
		Date d1=new SimpleDateFormat("yyyyMMdd").parse(s);
		String verifydate=ft.format(d1);
		System.out.println(ft.format(d1));

		ArrayList<String> list1=new ArrayList<String>();
		list1.add(ISBN1);
		list1.add(ISBN2);
		list1.add(ISBN3);
		list1.add(ISBN4);
		list1.add(ISBN5);
		try{
			for(String list : list1){

				String notification=getText(By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(text(),'"+list+"')]//following::div[contains(@class,'notification_box rounded')]"),"");
				Thread.sleep(4000);
				if(notification.contains("reserved for you")){
					if(notification.contains(verifydate)){
						Reporters.SuccessReport("Verifying Notification Message in Order Page.", "Verified Notification Message For ISBN: "+list+" And Notification Message is :"+notification+".</br>Verified publication date : "+verifydate+" in Notification Message.");
					}
					else
					{
						Reporters.failureReport("Verifying Notification Message in Order Page.", "Failed To Verify Notification Message.");
					}

				}
			}
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
		}
	}

	public static boolean fetchOrderNumberInOrderHistoryPage(String ISBN1) throws Throwable{
		boolean flag=true;
		try{

			//Total Orders In Order Page.
			//div[@class='span6 sidebar-list rounded']

			//div[@class='span6 sidebar-list rounded']//following-sibling::div[@class='span18 col']//div[@class='cartproductdetails']

			//div[@class='span6 sidebar-list rounded']//following-sibling::p[@class='no-pm']/span

			if(!click(ElsevierObjects.myAccount,"click on my account")){
				flag=false;
			}
			if(click(ElsevierObjects.MYACCOUNT_ORDERHISTORY,"click on Order History.")){
				Reporters.SuccessReport("Clicking On Order History Link In My Account Tab.", "Successfully clicked On Order History Link In My Account Tab.");
			}
			else{
				Reporters.failureReport("Clicking On Order History Link In My Account Tab.", "FailedTo Click On Order History Link In My Account Tab.");
			}
			Thread.sleep(100);

			List<WebElement> totalOrders=driver.findElements(By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div/div"));

			for(int k=2;k<=totalOrders.size();k++){
				//	String OrderData=
			}


			String ISBN1_total=ISBN1;
			List<WebElement> totalrows=driver.findElements(By.xpath(".//div[@class='span6 sidebar-list rounded']"));
			int index=0;
			int flag_ver=0;
			Thread.sleep(100);
			List<WebElement> totalordetrs=driver.findElements(By.xpath(".//p[@class='no-pm']/span"));
			List<WebElement> ordetrs=driver.findElements(By.xpath(".//p[@class='no-pm']/span"));


			int orderlist=totalordetrs.size();
			Thread.sleep(200);
			if(orderlist>=3){
				String ordernumber1=totalrows.get(0).findElement(By.xpath(".//p[@class='no-pm']/span")).getText();		
				List<WebElement> TotalISBNs=totalrows.get(0).findElements(By.xpath("//div[@class='span18 col']//div[@class='cartproductdetails']"));

				int totalISBNCount=TotalISBNs.size();

				//List<WebElement> TotalISBNs=totalrows.get(0).findElements(By.xpath(".//div[@class='cartproductdetails']"));
				String [] stringParts = ISBN1.split(",");
				for(int b=0;b<stringParts.length;b++)
				{
					for(int a=0;a<TotalISBNs.size();a++)
					{

						String Temp=TotalISBNs.get(a).getText();

						String expectedvalue=stringParts[b];
						if(Temp.contains(expectedvalue))
						{
							//index=a+1;
							Reporters.SuccessReport("Verifying ISBN's in the Current order in Sequence:"+a, "ISBN's are present in the Current order Number:" +ordernumber1+" And ISBN details are"+Temp);
							//	flag_ver=1;
							break;
						}
						else
						{
							ISBN1=expectedvalue+",";
							//  flag_ver=0;
						}
					}
				}
				//if(flag_ver==1)
				try{

					Thread.sleep(200);
					//stringParts = ISBN1.split(",");
					String ordernumber2=totalrows.get(1).findElement(By.xpath(".//p[@class='no-pm']/span")).getText();		
					List<WebElement> TotalISBNs1=totalrows.get(1).findElements(By.xpath("//div[@class='span18 col']//div[@class='cartproductdetails']"));
					for(int b=0;b<stringParts.length;b++)
					{

						for(int a=0;a<TotalISBNs1.size();a++)
						{

							String Temp=TotalISBNs1.get(a).getText();
							String expectedvalue=stringParts[b];
							if(Temp.contains(expectedvalue))
							{
								index=a+1;
								Reporters.SuccessReport("Verifying ISBN's in the Current order in Sequence:"+a, "ISBN's are present in the Current order Number:" +ordernumber2+" And ISBN details are"+Temp);
								//flag_ver=1;
							}
							else
							{
								ISBN1=expectedvalue+",";
								//	flag_ver=0;
							}
						}
					}
				}
				catch(Exception e){
					sgErrMsg=e.getMessage();
				}

				//	if(flag_ver==1)
				try
				{
					Thread.sleep(200);
					//stringParts = ISBN1.split(",");
					String ordernumber3=totalrows.get(2).findElement(By.xpath(".//p[@class='no-pm']/span")).getText();		
					List<WebElement> TotalISBNs2=totalrows.get(2).findElements(By.xpath("//div[@class='span18 col']//div[@class='cartproductdetails']"));
					for(int b=0;b<stringParts.length;b++)
					{

						for(int a=0;a<TotalISBNs2.size();a++)
						{	String Temp=TotalISBNs2.get(a).getText();
						String expectedvalue=stringParts[b];
						if(Temp.contains(expectedvalue))
						{
							index=a+1;
							Reporters.SuccessReport("Verifying ISBN's in the Current order in Sequence in Receipt Page:"+a, "ISBN's are present in the Current order Number:" +ordernumber3+" And ISBN details are"+Temp);
							flag_ver=1;
							break;
						}
						else
						{
							ISBN1=expectedvalue+",";
							flag_ver=0;
						}
						}
					}
				}
				catch(Exception e11){
					sgErrMsg=e11.getMessage();
				}
				Thread.sleep(200);
				/*if(ISBN1_total.contains(ISBN1))
		{

		//if(flag_ver==1)
		{
			Reporters.failureReport("ISBN or not present or Oder not splited in to three orders", "One of the ISBN is not present or"+ISBN1);

		}
		}*/		

			}
			else{
				Reporters.failureReport("Verifying Orders in Receipt Page.", "Number Of Orders Are Less Than three. ISze Of Orders List Is :"+orderlist);
			}



		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
		}

		return flag;
	}

	public static boolean checkorderwithISBN(String ordernumber,String ISBN,String value)throws Throwable
	{
		try
		{
			if(!click(ElsevierObjects.myAccount,"click on my account")){
				flag=false;
			}
			if(click(ElsevierObjects.MYACCOUNT_ORDERHISTORY,"click on Order History.")){
				Reporters.SuccessReport("Clicking On Order History Link In My Account Tab.", "Successfully clicked On Order History Link In My Account Tab.");
			}
			else{
				Reporters.failureReport("Clicking On Order History Link In My Account Tab.", "FailedTo Click On Order History Link In My Account Tab.");
			}
			driver.findElement(By.xpath(".//*[@id='pageLayout-body-inner-most']//div[@class='row']"));

			List<WebElement> TotalOrder=driver.findElements(By.xpath(".//*[@id='pageLayout-body-inner-most']//div[@class='row']"));
			Thread.sleep(500);
			String Order="";
			String ISBNActual="";
			flag =true;
			for(int i=0;i<TotalOrder.size();i++)
			{
				if(value.equalsIgnoreCase("Yes"))
				{
					try
					{
						Order= TotalOrder.get(i).findElement(By.xpath(".//p[contains(text(),'Order Number:')]/descendant::span")).getText();
						if(Order.contains(ordernumber))
						{
							ISBNActual=TotalOrder.get(i).findElement(By.xpath(".//div[contains(text(),'"+ISBN+"')]")).getText();
							if(ISBNActual.contains(ISBN))
							{
								Reporters.SuccessReport("Verifying pre-order item will show as its own order with a unique order number.", "Successfully Verified Pre-Order item : "+ISBN+" and its Order Id :"+ordernumber);
								return true;	
							}
							else
							{
								Reporters.failureReport("Verifying pre-order item will show as its own order with a unique order number.", "Failed To Verify Pre-Order item : "+ISBN+" and its Order Id :"+ordernumber);
								return false;
							}

						}
					}
					catch(NoSuchElementException e){flag=false;
					Reporters.failureReport("Verifying pre-order item will show as its own order with a unique order number.", "Failed To Verify Pre-Order item : "+ISBN+" and its Order Id :"+ordernumber);}
				}
				else if(value.equalsIgnoreCase("No"))
				{
					if((isElementPresentforweb(TotalOrder.get(i).findElement(By.xpath(".//span[contains(text(),'"+ordernumber+"')]"))))&&!isElementPresentforweb(TotalOrder.get(i).findElement(By.xpath(".//span[contians(text(),'"+ordernumber+"')]"))))
					{
						return true;
					}
					else
					{
						return false;
					}

				}
			}


			return true;
		}catch(Exception e){sgErrMsg="Failed to check Orders with ISBN's due to "+e; return false;}
	}


	private static boolean isElementPresentforweb(WebElement findElement) throws Throwable 
	{

		try {
			findElement.isDisplayed();
			flag = true;
			return true;
		} catch (Exception e) {

			System.out.println(e.getMessage());
			return false;
		} 

	}
	public static boolean fetchOrderNumberfromsecond(String ISBN1) throws Throwable{
		boolean flag=true;
		try{
			driver.navigate().refresh();
			//String ISBN1_total=ISBN1;
			List<WebElement> totalrows=driver.findElements(By.xpath(".//div[@class='row']"));
			int index=0;
			//int flag_ver=0;
			Thread.sleep(100);
			List<WebElement> totalordetrs=driver.findElements(By.xpath(".//div[@class='sidebar-list rounded']//h4/following-sibling::div"));
			int orderlist=totalordetrs.size();

			if(orderlist>=3){
				ordernumber1=totalrows.get(1).findElement(By.xpath(".//div[@class='sidebar-list rounded']//h4/following-sibling::div")).getText();		
				//ReadingExcel.updateCellInSheet(rowNumber, columnNumber, path, sheetName, cellValueToUpdate);
				List<WebElement> TotalISBNs=totalrows.get(1).findElements(By.xpath(".//div[@class='cartproductdetails']"));
				String [] stringParts = ISBN1.split(",");

				count=0;
				for(int b=0;b<stringParts.length;b++)
				{
					for(int a=0;a<TotalISBNs.size();a++)
					{

						String Temp=TotalISBNs.get(a).getText();

						String expectedvalue=stringParts[b];
						if(Temp.contains(expectedvalue))
						{
							ReadingExcel.updateCellInSheet(a+1, 1, testDataPath, "TC-15597_Orders", ordernumber1);
							ReadingExcel.updateCellInSheet(a+1, 0, testDataPath, "TC-15597_Orders", expectedvalue);
							count++;
							Reporters.SuccessReport("Verifying ISBN's in the Current order in Sequence:"+a, "ISBN's are present in the Current order Number:" +ordernumber1+" And ISBN details are"+Temp);
							//	flag_ver=1;
							break;
						}
						else
						{
							ISBN1=expectedvalue+",";
							//  flag_ver=0;
						}
					}
				}
				//if(flag_ver==1)
				try{

					Thread.sleep(200);
					//stringParts = ISBN1.split(",");
					ordernumber2=totalrows.get(2).findElement(By.xpath(".//div[@class='sidebar-list rounded']//h4/following-sibling::div")).getText();		
					count1=count;
					List<WebElement> TotalISBNs1=totalrows.get(2).findElements(By.xpath(".//div[@class='cartproductdetails']"));
					for(int b=0;b<stringParts.length;b++)
					{

						for(int a=0;a<TotalISBNs1.size();a++)
						{

							String Temp=TotalISBNs1.get(a).getText();
							String expectedvalue=stringParts[b];
							if(Temp.contains(expectedvalue))
							{
								index=a+1;
								ReadingExcel.updateCellInSheet(count+1, 1, testDataPath, "TC-15597_Orders", ordernumber2);
								ReadingExcel.updateCellInSheet(count+1, 0, testDataPath, "TC-15597_Orders", expectedvalue);
								count1++;
								Reporters.SuccessReport("Verifying ISBN's in the Current order in Sequence:"+a, "ISBN's are present in the Current order Number:" +ordernumber2+" And ISBN details are"+Temp);
								//flag_ver=1;
							}
							else
							{
								ISBN1=expectedvalue+",";
								//	flag_ver=0;
							}
						}
					}


				}
				catch(Exception e){
					sgErrMsg=e.getMessage();
				}

				//	if(flag_ver==1)
				try
				{
					Thread.sleep(200);
					//stringParts = ISBN1.split(",");
					ordernumber3=totalrows.get(3).findElement(By.xpath(".//div[@class='sidebar-list rounded']//h4/following-sibling::div")).getText();		
					List<WebElement> TotalISBNs2=totalrows.get(3).findElements(By.xpath(".//div[@class='cartproductdetails']"));
					for(int b=0;b<stringParts.length;b++)
					{

						for(int a=0;a<TotalISBNs2.size();a++)
						{	
							String Temp=TotalISBNs2.get(a).getText();
							String expectedvalue=stringParts[b];
							if(Temp.contains(expectedvalue))
							{
								index=a+1;
								ReadingExcel.updateCellInSheet(count1+1, 1, testDataPath, "TC-15597_Orders", ordernumber3);
								ReadingExcel.updateCellInSheet(count1+1, 0, testDataPath, "TC-15597_Orders", expectedvalue);
								Reporters.SuccessReport("Verifying ISBN's in the Current order in Sequence in Receipt Page:"+a, "ISBN's are present in the Current order Number:" +ordernumber3+" And ISBN details are"+Temp);
								//	flag_ver=1;
								break;
							}
							else
							{
								ISBN1=expectedvalue+",";
								//	flag_ver=0;
							}
						}
					}
				}
				catch(Exception e11){
					sgErrMsg=e11.getMessage();
				}
				Thread.sleep(200);
				/*if(ISBN1_total.contains(ISBN1))
			{

			//if(flag_ver==1)
			{
				Reporters.failureReport("ISBN or not present or Oder not splited in to three orders", "One of the ISBN is not present or"+ISBN1);

			}
			}*/		

			}
			else{
				Reporters.failureReport("Verifying Orders in Receipt Page.", "Number Of Orders Are Less Than three. ISze Of Orders List Is :"+orderlist);
			}


		}
		catch(Exception e12){
			sgErrMsg=e12.getMessage();
		}

		return flag;
	}

	public static void modifyingPublicatonDate(String type,String publicationDate,String publishingStatus) throws Throwable{
		boolean flag = true;
		//String errorMessage ="";
		try{
			Thread.sleep(2000);
			if(type(ElsevierObjects.PUBLICATION_DATE,publicationDate, "enter the publication Date")){
				Reporters.SuccessReport("Modifying PublicationDate to "+type+" Date.", "Successfully Modified Publication date To "+type+" :"+publicationDate);
			}
			else{
				Reporters.failureReport("Modifying PublicationDate to "+type+" Date.", "Failed To Modify Publication Date To "+type+" :"+publicationDate);
			}
			if(selectByValue(ElsevierObjects.PUBLICATION_STATUS, publishingStatus, "select the publishingStatus")){
				Reporters.SuccessReport("Selecting Publication Status From Dropdown.", "Successfully Selected Publication Status :"+publishingStatus);
			}
			else{
				Reporters.failureReport("Selecting Publication Status From Dropdown.", "Failed To Select Publication Status To :"+publishingStatus);
			}
			Thread.sleep(2000);
			//((JavascriptExecutor)driver).executeScript("editResource(1)");
			if(click(By.name("btnEdit"), "click on the edit button")){
				Reporters.SuccessReport("Click on the Edit button", "Successfully clicked on the edit button");
			}else{
				Reporters.failureReport("Click on the Edit button", "Failed to click on the edit button");
			}

			Thread.sleep(15000);

			String message = getText(ElsevierObjects.PRODUCT_RESOURCE_MESSAGE, "");

			if(message.contains("successfully")){
				Reporters.SuccessReport("Verifying Product Resource Update Message.", "Successfully Verified Product Resource Update Message :"+message);
			}
			else{
				Reporters.failureReport("Verifying Product Resource Update Message.", "Failed To Verify Product Resource Update Message.");
			}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}

	}
	public static void evolveBreadCrumb() throws Throwable{
		if(click(ElsevierObjects.EVOLVE_BUTTON, "click on the My-Evolve button")){
			Reporters.SuccessReport("Clicking on Evolve Admin Link.", "Successfully Clicked On Evolve Admin Link.");
		}
		else{
			Reporters.failureReport("Clicking on Evolve Admin Link.", "Failed To Click On Evolve Admin Link.");
		}
	}

	public static void editingResource(String clincalNumber) throws Throwable{
		boolean flag = true;
		String errorMessage = "";
		try{
			/*if(click(ElsevierObjects.EVOLVE_BUTTON, "")){
			Reporters.SuccessReport("Clicking on Evolve Admin Link.", "Successfully Clicked On Evolve Admin Link.");
		}
		else{
			Reporters.failureReport("Clicking on Evolve Admin Link.", "Failed To Click On Evolve Admin Link.");
		}*/
			Thread.sleep(2000);
			if(click(ElsevierObjects.BASE_PRDORDUCT_RERPORTS, "click on the Base-Product-Resourse link")){
				Reporters.SuccessReport("Clicking On Base Product Resource under 'ONIX PPM Load Data Manager'.", "Successfully Clicked On Base Product Resource under 'ONIX PPM Load Data Manager'.");
			}
			else{
				Reporters.failureReport("Clicking On Base Product Resource under 'ONIX PPM Load Data Manager'.", "Failed To Click On Base Product Resource under 'ONIX PPM Load Data Manager'.");
			}
			Thread.sleep(2000);
			if(type(ElsevierObjects.SELECT_IBN_TEXT_BOX, clincalNumber, "Enter the ISBN number in the textbox")){
				Reporters.SuccessReport("Entering ISBN In Select ISBN TextBox.", "Successfully Entered ISBN "+clincalNumber+" in Select ISBN Textbox.");
			}
			else{
				Reporters.failureReport("Entering ISBN In Select ISBN TextBox.", "Failed To Enter ISBN "+clincalNumber+" in Select ISBN Textbox. ");
			}
			Thread.sleep(2000);
			if(selectByValue(ElsevierObjects.PROCESS_MENu, "3","seelect the edit resourse from the drop down box")){
				Reporters.SuccessReport("Selecting Edit Resources From Dropdown.", "Successfully Selected Edit Resources From Dropdown");
			}
			else{
				Reporters.failureReport("Selecting Edit Resources From Dropdown.", "Failed To Select Edit Resources From Dropdown.");
			}
			Thread.sleep(2000);
			if(click(ElsevierObjects.VIEW_PRODUCT, "Click On GO Button in View/Update Resource Data Page")){
				Reporters.SuccessReport("Clicking On GO Button in View/Update Resource Data Page.", "Successfully Clicked On GO Button.");
			}
			else{
				Reporters.failureReport("Clicking On GO Button in View/Update Resource Data Page.", "Failed To Click On On GO Button.");
			}
			Thread.sleep(2000);
			if(!isElementPresent(By.xpath("//*[@id='editdatatable']/table/tbody//label[text()='"+clincalNumber+"']"), "")){
				flag  = false;
			}

		}catch(Exception e){
			errorMessage = e.getMessage();
		}
		/*finally{
		if(flag){
			Reporters.SuccessReport("Verify Resource information  ", "Successfully Verifies Resource Information");
		}else{
			Reporters.failureReport("Verify Resource information  ", "Unable to verfiy the Resource Information Reson"+errorMessage);
		}
	}*/
	}

	public static boolean manageAdminstrator() throws Throwable {

		boolean flag = true;

		if(click(ElsevierObjects.MANAGE_ADMINISTRATORS, "Click on Manage Administrators link")){
			Reporters.SuccessReport("Clicking on Manage Administrators link.", "Successfully Clicked On Manage Administrators Link.");
		}
		else{
			Reporters.failureReport("Clicking on Manage Administrators link.", "Failed To Click On Manage Administrators Link.");
		}
		Thread.sleep(2000);
		if(click(ElsevierObjects.ADMIN_USER_NAME_ROW, "Click on admin user we are logging in")){
			Reporters.SuccessReport("Clicking on admin user we are logging in.", "Successfully Clicked On admin user we are logging in.");
		}
		else{
			Reporters.failureReport("Clicking on admin user we are logging in.", "Failed To Click On admin user we are logging in.");
		}
		Thread.sleep(2000);
		try{
			driver.findElement(ElsevierObjects.PERORDER_MAINTANCE);
			Reporters.SuccessReport("Verifying Pre Order Maintenance Link.", "Pre Order Maintenance Is Present In The Roles.");
		}
		catch(Exception e){
			click(ElsevierObjects.MANAGEPRIVILEGES,"Click On Manage Privileges Checkbox");
			if(click(ElsevierObjects.MANAGEPRIVILEGES_PREORDER,"Click On Pre-Order Maintenance Checkbox")){
				Reporters.SuccessReport("Clicking On Manage Privileges And Clicking On Pre-Order Maintenance Checkbox.", "Successfully Clicked On Manage Privileges Link And On Pre-Order Maintenance Checkbox. ");
			}
			else{
				Reporters.failureReport("Clicking On Manage Privileges And Clicking On Pre-Order Maintenance Checkbox.", "Failed To Click On Manage Privileges Link And On Pre-Order Maintenance Checkbox. ");
			}
			click(ElsevierObjects.MANAGEPRIVILEGES_SAVE,"click on the manage privileges save button");
		}

		try{
			driver.findElement(ElsevierObjects.MANTAIN_PPM_DATA);
			Reporters.SuccessReport("Verifying Maintain PPM Data Settings Role.", "Maintain PPM Data Settings Presented In Roles.");
		}
		catch(Exception e){
			click(ElsevierObjects.MANAGEPRIVILEGES,"Click On Manage Privileges");
			if(click(ElsevierObjects.MANAGEPRIVILEGES_MAINTAIN,"Click On Maintain PPM Data Settings Checkbox.")){
				Reporters.SuccessReport("Clicking On Manage Privileges And Clicking On Maintain PPM Data Settings Checkbox.", "Successfully Clicked On Manage Privileges Link And On Maintain PPM Data Settings Checkbox. ");
			}
			else{
				Reporters.failureReport("Clicking On Manage Privileges And Clicking On Maintain PPM Data Settings Checkbox.", "Failed To Click On Manage Privileges Link And On Maintain PPM Data Settings Checkbox. ");
			}
			click(ElsevierObjects.MANAGEPRIVILEGES_SAVE,"click on the manage privileges save button");
		}

		/*else{

		Reporters.failureReport("Verify Maintain PPM Data Settings ", "");
	}*/
		if(!click(ElsevierObjects.ADMIN_SAVE_BUTTON, "click on the admin save button")){
			flag = false;
		}
		Thread.sleep(2000);
		String message = getText(ElsevierObjects.ADMIN_EDIT_MEASSAGE, "");
		if(message != null){
			Reporters.SuccessReport("Verifying Upadte Message.","Verified Message:"+message);
		}
		else{
			Reporters.failureReport("Verifying Upadte Message.", "Failed To Verify Update Message.");
		}
		/*if(message.contains("Account updated successfully")){
		Reporters.SuccessReport("Verify User Successfully saved or not","");
	}
	else{
		Reporters.failureReport("Verify User Successfully saved or not", "");
	}*/
		return flag;
	}
}
