package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.Manual_Unique_Course_Fulfillment_10436_BussinessFuncitons;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.BusinessFunctions.VitalSourceAccountAC_HomePage_StudentExists_VST;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class Manual_Unique_Course_Fulfillment_10436_Script extends Manual_Unique_Course_Fulfillment_10436_BussinessFuncitons {

	@Test
	public void manualUniqueCourse10436() throws Throwable {
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		String isbnNumber = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-10436", configProps.getProperty("TestData")).get("Product"); 
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
	
		String user1="instructor";
		String username=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-10436", configProps.getProperty("TestData")).get("Username");
		String password=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-10436", configProps.getProperty("TestData")).get("Password");
		
		// for some reason this login call was passing "tfaculty393" as the username. changed it to instead pass the username variable initialized above
		writeReport(VitalSourceAccountAC_HomePage_StudentExists_VST.login(user1, username, password), "Login into Existing Instructor", "Successfully logged into the Instructor with the credentials: <br/> Username : "+username+"<br/> Password : "+password, "Failed to log into the application");
		
		searchISBNNumber(isbnNumber);

		evolveContentPlus();
		getAccountDetails();

		writeReport(User_BusinessFunction.Logout(), "Log out from the Faculty user", "Successfully logged out from the application", "Failed to logout from the application");

		Thread.sleep(medium);
		
		adminLogin();

		searchAdoptionRequest(false);

		System.out.println("Course Id===>>>"+EvolveCommonBussinessFunctions.courseID1);
		ReadingExcel.updateCellInSheet(1,0,configProps.getProperty("TestData"), "TC-15574", EvolveCommonBussinessFunctions.courseID1);
		writeReport(User_BusinessFunction.Educatorlogin(configProps.getProperty("ecertAdminUserID"), configProps.getProperty("ecertAdminPassword")), "Log into evolvecert.elsevier.com as a faculty user who has Administration Portal access", "Successfully Logged into evolvecert.elsevier.com as a faculty user who has Administration Portal access<br> Username : "+configProps.getProperty("ecertAdminUserID")+"<br>Password : "+configProps.getProperty("ecertAdminPassword"), "Failed to Log into evolvecert.elsevier.com as a faculty user who has Administration Portal access<br> Username : "+configProps.getProperty("ecertAdminUserID")+"<br>Password : "+configProps.getProperty("ecertAdminPassword"));

		manageCoursePage(EvolveCommonBussinessFunctions.courseID1);		
		
		User_BusinessFunction.Logout();
		
		adminLogin();	

		searchAdoptionRequest(true);

		if(emailLogin()){
			Reporters.SuccessReport("Evolve Mail Login:", "Successfully logged into the EvolveMail ");
		}else{
			Reporters.failureReport("Evolve Mail Login:", "Failed to Login as EvolveMail.");
		}

		searchEmail(getAccountDetailsEmail);
		String emailUniqueCourseTitle=ReadingExcel.columnDataByHeaderName("emailOnlineTitle", "TC-10410", configProps.getProperty("TestData"));

		verifyTitleInEmailBody(emailUniqueCourseTitle);
		instructorLogin();

		verifyProductTitle(EvolveCommonBussinessFunctions.courseID1);
		ReadingExcel.updateCellInSheet(1,1,configProps.getProperty("TestData"), "TC-15574", protectionSchemeID); 
	
	}
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
