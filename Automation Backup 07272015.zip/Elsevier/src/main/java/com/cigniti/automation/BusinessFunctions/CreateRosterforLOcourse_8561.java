package com.cigniti.automation.BusinessFunctions;



import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class CreateRosterforLOcourse_8561 extends EvolveCommonBussinessFunctions {

	public static String studentFirstName;
	public static String newStudentUserName;
	public static String newStudentPassword;
	public static String studentLastName;
	public static String studentEmail;

	public static String roseterFieldForStudent;
	public static String rosterSubmissionStudent;

	public static String RosterUser;
	public static String RosterPwd;

	public static String insUserName;
	public static String insPwd;
	public static String faEmail;
	public static String faLastName;
	public static String faFirstName;
	public static String rosterFieldForFaculty;
	public static String LoEmail;

	public static String InstructorHeader;
	public static String StudentHeader;

	public static String newLastname = "smith";
	public static String newFirstname = "John";
	public static String newEmail;
	public static String newStudent;
	public static String ID;
	public static String errorMsg;


	public static boolean AccountCreationdetails() throws Throwable{
		try
		{
			boolean flag = true;
			CreateNewUser("STUDENT");
			Thread.sleep(3000);
			getAccountDetailsforRoster();
			studentLastName = getAccountDetailsLastName;
			studentFirstName = getAccountDetailsFirstName;
			studentEmail = getAccountDetailsEmail;
			roseterFieldForStudent = studentLastName+","+studentFirstName+","+studentEmail;
			System.out.println(roseterFieldForStudent);
			newStudentUserName = getAccountDetailsUserName;
			newStudentPassword = credentials[1];
			ReadingExcel.updateCellInSheet(1,2,configProps.getProperty("TestData"), "TC-10433", newStudentUserName);
			ReadingExcel.updateCellInSheet(1,3,configProps.getProperty("TestData"), "TC-10433", newStudentPassword);
			EvolveCommonBussinessFunctions.instructorLogout();
			String user="educator";
			RosterUser=ReadingExcel.columnDataByHeaderName("Roster_UserName","TC_8561",testDataPath);
			RosterPwd=ReadingExcel.columnDataByHeaderName("Roster_UserPwd","TC_8561",testDataPath);
			ReadingExcel.updateCellInSheet(1,1,testDataPath, "TC-15565", RosterUser);
			ReadingExcel.updateCellInSheet(1,2,testDataPath, "TC-15565", RosterPwd);
			EvolveCommonBussinessFunctions.existingUserLogin(user,RosterUser,RosterPwd);
			Thread.sleep(3000);
			getAccountDetailsforRoster();
			faLastName = getAccountDetailsLastName;
			faFirstName = getAccountDetailsFirstName;
			faEmail = getAccountDetailsEmail;
			ReadingExcel.updateCellInSheet(1,5,testDataPath, "TC-15565", faEmail);
			rosterFieldForFaculty = faLastName+","+faFirstName+","+faEmail;
			System.out.println(rosterFieldForFaculty);
			insUserName = getAccountDetailsUserName;
			insPwd = configProps.getProperty("Roster_Pwd");
			EvolveCommonBussinessFunctions.instructorLogout();
			
			// main page link no longer applies
			//clickOnMainPageLink();
			
			return flag;}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}	}


	//==================================End of the Method==========================================//



	public static boolean courseIDSearch(String ID1) throws Throwable{
		boolean flag=true;
		try{
			if(ID1.equalsIgnoreCase("true")){
				waitForVisibilityOfElement(By.xpath(".//*[@id='set']/li/div/div/span[text()='COURSE ID: "+ID+"']"),"Verify course id1 present.");
			}
			click(By.xpath("//*[@id='set']/li/div/div/span[text()='COURSE ID: "+ID+"']/following-sibling::a"),"Click on Course Title.");
			Thread.sleep(60000);
			//driver.manage().timeouts().implicitlyWait(600, TimeUnit.SECONDS);

			//driver.navigate().refresh();
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
		return flag;	
	}


	//==================================End of the Method==========================================//




	public static void submitRosterData(String CourseID,String roseterFieldForStudent,String rosterFieldForFaculty)throws Throwable
	{
		try{


			b=true;
			type(ElsevierObjects.txtcourseID, ReadingExcel.columnDataByHeaderName("SampleCourser_id", "TC_8561",configProps.getProperty("TestData")), "Enter wrong CourseId in the 'courseID' text field ");
			Thread.sleep(2000);
			type(ElsevierObjects.txtArea, ReadingExcel.columnDataByHeaderName("Roster field", "TC_8561",configProps.getProperty("TestData")), "Enter details in larger textArea");
			click(ElsevierObjects.btnpreiviewroster, "'Preview Roster & Assign Roles' button");
			b=false;

			String wrongMessage = getText(ElsevierObjects.TC_8561_ErrorMessage, "Get thr Error Message");
			if(wrongMessage.contains(errorMsg)){
				Reporters.SuccessReport("Error message : ","Successfully Error meesage is verified: </br> Actual Error Message is : " +errorMsg+" </br> Expected Error Message is :  "+wrongMessage);
			}else{
				Reporters.failureReport("Error message :", "Failed to find error message: </br> Actual Error Message is :" +errorMsg+" </br> Expected Error Message is :  "+wrongMessage);
			}

			b=true;
			Thread.sleep(1000);
			type(ElsevierObjects.txtcourseID,ID,"Enter unique course id created from Step #1 in the course ID field");

			b=false;
			driver.findElement(ElsevierObjects.txtArea).clear();

			driver.findElement(ElsevierObjects.txtArea).sendKeys(roseterFieldForStudent);	
			if(roseterFieldForStudent!=null){
				Reporters.SuccessReport("Enter Lastname,Firstname and EmailId","Successfully entered student details that has previously been created in step#2 :</br>" +roseterFieldForStudent);
			}else{
				Reporters.failureReport("Enter Lastname,Firstname and EmailId","Failed to enter created student details");
			}
			Thread.sleep(4000);
			driver.findElement(ElsevierObjects.txtArea).sendKeys(Keys.ENTER);
			Thread.sleep(4000);
			driver.findElement(ElsevierObjects.txtArea).sendKeys(rosterFieldForFaculty);
			Thread.sleep(4000);
			if(rosterFieldForFaculty!=null){
				Reporters.SuccessReport("Enter Lastname,Firstname and EmailId","Successfully entered instructor details that has previously been created in evolve cert:</br>"+rosterFieldForFaculty);
			}else{
				Reporters.failureReport("Enter Lastname,Firstname and EmailId","Failed to enter created Faculty details");
			}
			driver.findElement(ElsevierObjects.txtArea).sendKeys(Keys.ENTER);
			Thread.sleep(4000);
			Random ra = new Random(System.currentTimeMillis());
			newEmail= "Jhonsmith"+Integer.toString((1 + ra.nextInt(2)) * 1000 + ra.nextInt(1000))+"@evolveqa.info";
			newStudent = newFirstname+","+newLastname+","+newEmail;
			System.out.println("new student EmailID::"+newEmail);
			driver.findElement(ElsevierObjects.txtArea).sendKeys(newStudent);
			if(newStudent!=null){
				Reporters.SuccessReport("Enter Lastname,Firstname and EmailId","Successfully newstudent details for Roster are entered :</br>"+newStudent);
			}else{
				Reporters.failureReport("Enter Lastname,Firstname and EmailId","Failed to enter newstudent details for Roster");
			}
			if(click(ElsevierObjects.btnpreiviewroster, "click on preview and Roster button"))
			{
				Reporters.SuccessReport("Click on 'Preview Roster & Assign Roles 'Button", "Sucessfully clicked on 'Preview And Roster'Button then user got a second screen which shows the 3 users listed with a dropdown next to each name to assign roles to the enrollees");
			}
			else
			{
				Reporters.failureReport("Click on 'Preview And Roster' Button ", "unable to show the 3 users listed with a dropdown next to each name to assign roles to the enrollees");	
			}

		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);
		} 

	}



	//==================================End of the Method==========================================//




	public static void selectingRoles()throws Throwable
	{
		
		try{
			if(selectByValue(ElsevierObjects.selection_Of_Role, "instructor", "Select the role as an instructor")){
				Reporters.SuccessReport("Selecting the Roles", "sucessfully selecting the roles for the Students as 'STUDENT' and instructor role as 'INSTRUCTOR'");
			}else{
				Reporters.failureReport("Selecting the Roles", "Unable to select the roles for the Students and Instructor");
			}
	
			if(!isChecked(ElsevierObjects.Email_To_Me_RadioBtn,"selecting the 'Email the roster to me, and also email my students their usernames & passwords.' radio button")){
				Reporters.SuccessReport("select Radio button", " sucessfully selecting the 'Email the roster to me, and also email my students their usernames & passwords.' radio button");
			}else{
				b=true;
				click(ElsevierObjects.Email_To_Me_RadioBtn,"selecting the 'Email the roster to me, and also email my students their usernames & passwords.' radio button");
				b=false;
			}
			b=true;
			click(ElsevierObjects.btnsubmitroster,"'Submit this Roster' Button'");
			b=false;
			String suc = "Success";
			Thread.sleep(high);
			String s=getText(ElsevierObjects.sucess_Message, "comparing the sucess message");
			if(s.contains(ID)&&s.contains(suc)){
				Reporters.SuccessReport("Verify Success Message","User will see a success message: "+s);
			}else{
				Reporters.failureReport("Verify Success Message","User will unable to see a success message: "+s);	
			}
			EvolveCommonBussinessFunctions.instructorLogout();
			Thread.sleep(2000);
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);
		} 
	}



	//==================================End of the Method==========================================//




	public static boolean Emailforwarding() throws Throwable {
		boolean flag = true;
		try
		{
			
			launchUrl(configProps.getProperty("EmailURL"));
			Thread.sleep(2000);
			type(ElsevierObjects.emailaddress,configProps.getProperty("verifyemail_username"),"Enter email id");
			Thread.sleep(3000);
			String Password=configProps.getProperty("verifyemail_password");
			
			type(ElsevierObjects.emailpassword,configProps.getProperty("verifyemail_password"),"Enter password");
			Thread.sleep(2000);
			click(ElsevierObjects.emaillogin, "Click on Login Button.");
			Thread.sleep(4000);
			click(ElsevierObjects.email_Icon,"Click on Email icon.");
			Thread.sleep(3000);
			click(ElsevierObjects.email_dropdown,"Click on Dropdown.");
			Thread.sleep(3000);
			click(ElsevierObjects.email_dropdown_Fromchk,"Click on From check box.");
			Thread.sleep(3000);
			click(ElsevierObjects.email_dropdown_Tochk,"Click on To checkbox.");
			Thread.sleep(2000);
			
			Thread.sleep(3000);
			type(ElsevierObjects.email_SearchBox,newEmail,"Enter the EmailAddress.");
			Thread.sleep(3000);
			click(ElsevierObjects.email_SearchIcon,"Click on search icon.");
			Thread.sleep(8000);
			String EmailTitle2 = getText(ElsevierObjects. titleInEmail,"Verify the Subject of the Email");
			if(EmailTitle2.equalsIgnoreCase(StudentHeader)){
				Reporters.SuccessReport("Log into the designated email account for the main instructor and Verify the Subject of Email","Successfully Logged into the designated email account and also verified Email subject</br> Actual title is :"+EmailTitle2+"</br> Expected title is: "+StudentHeader);
			}else{
				Reporters.failureReport("Log into the designated email account for the main instructor and Verify the Subject of Email","Failed to verify Email subject </br> Actual title is :"+EmailTitle2+"</br> Expected title is: "+StudentHeader);
			}
			Thread.sleep(2000);
			switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
			String emailBody2 = getText(ElsevierObjects.email_body_text,"Get email body text");
			
			String[] credentialsArr = emailBody2.split("\n");
			userName = null;
			password = null;
			for(String credentials : credentialsArr){
				if(credentials.contains("Username:")){
					userName = credentials.replaceAll("Username:", "").trim();
				}
				if(credentials.contains("Password:")){
					password = credentials.replaceAll("Password:", "").trim();
				} 
			}
			
			if(emailBody2.contains(userName)&& emailBody2.contains(password)){ 
				Reporters.SuccessReport("Verify email content.","Successfully Roster Student details are verified :</br> Student Username :"+userName+"</br> Student Password :"+password);
			}else{
				Reporters.failureReport("Verify email content.","Failed to verify the email content.");
			}
			
			driver.switchTo().defaultContent();
			
			driver.findElement(ElsevierObjects.email_SearchBox).clear();
			type(ElsevierObjects.email_SearchBox,LoEmail,"Enter the EmailAddress.");
			Thread.sleep(3000);
			click(ElsevierObjects.email_SearchIcon,"Click on search icon.");
			Thread.sleep(8000);
			String EmailTitle = getText(ElsevierObjects. titleInEmail,"Verify the Subject of the Email");
			if(EmailTitle.equalsIgnoreCase(InstructorHeader)){
				Reporters.SuccessReport("Log into the designated email account for the main instructor and Verify the Subject of Email","Successfully Logged into the designated email account and also verified Email subject </br> Actual title is :"+EmailTitle+"</br> Expected title is: " +InstructorHeader);
			}else{
				Reporters.failureReport("Log into the designated email account for the main instructor and Verify the Subject of Email","Failed to verify Email subject </br> Actual title is :"+EmailTitle+"</br> Expected title is: " +InstructorHeader);
			}
			Thread.sleep(5000);
			switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
			String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
			
			if(emailBody.contains(ID)&& emailBody.contains(faLastName) && emailBody.contains(faFirstName) && emailBody.contains(faEmail) && emailBody.contains(RosterUser) && emailBody.contains("******")&& emailBody.contains(studentLastName)
					&& emailBody.contains(studentFirstName)&& emailBody.contains(studentEmail)&& emailBody.contains(newStudentUserName)&& emailBody.contains(newLastname)&& emailBody.contains(newFirstname)&&emailBody.contains(newEmail) && emailBody.contains(userName)&& emailBody.contains(password)){
				Reporters.SuccessReport("Verify email content.","Successfully details in Email are compared and the details are :</br> CourseId :" +ID+"</br> Student Firstname :"+studentFirstName+"</br> Student Lastname :"+studentLastName+"</br> Student EmailId :"+studentEmail+"</br> Student Username :"+newStudentUserName+"</br> Student Password :"+Pwd+
						"</br> Faculty Firstname :"+faFirstName+"</br> Faculty Lastname :"+faLastName+"</br> Faculty EmailId :"+faEmail+"</br> Faculty Username :"+RosterUser+"</br> Faculty Password :"+Pwd+
						"</br> RosterStudent Firstname :"+newFirstname+"</br> RosterStudent Lastname :"+newLastname+"</br> RosterStudent EmailId :"+newEmail+"</br> RosterStudent Username :"+userName+"</br> RosterStudent Password :"+password);
			}else{
				Reporters.failureReport("Verify email content.","Failed to verify the email content.");
			}
			
			driver.switchTo().defaultContent();
			
			/*
			if(emailBody!=null){
				Reporters.SuccessReport("Verify Emailbody content","Successfully Emailbody content is verified </br> "+emailBody);
			}else{
				Reporters.failureReport("Verify Emailbody content","Failed to verify Emailbody content.");
			}
			driver.switchTo().defaultContent();
			b= true;
			click(ElsevierObjects.Email_forward,"Forward button");
			b= false;
			Thread.sleep(3000);
			String parentHandle = driver.getWindowHandle();
			for(String winHandle : driver.getWindowHandles()) {
				driver.switchTo().window(winHandle);
				Thread.sleep(3000);
			} 
			Thread.sleep(1000);

			type(ElsevierObjects.Email_Forwarding_To,configProps.getProperty("gmailUsername"),"Gmail Account");
			Thread.sleep(1000);
			if(click(ElsevierObjects.Email_Send,"Send button and Email is forwarded to a checkable gmail account"))
			{
				Reporters.SuccessReport("Forward Email to checkable gmailAccount", "Sucessfully forwarded the Email to checkable gmail account");
			}
			else
			{
				Reporters.failureReport("Forward Email to checkable gmailAccount", "failed to forword the email");
			}

			driver.switchTo().window(parentHandle);
			Thread.sleep(5000);
			*/
			
			//2nd email
			driver.findElement(ElsevierObjects.email_SearchBox).clear();
			Thread.sleep(3000);
			type(ElsevierObjects.email_SearchBox,studentEmail,"Enter the EmailAddress.");
			Thread.sleep(4000);
			click(ElsevierObjects.email_SearchIcon,"Click on search icon.");
			Thread.sleep(8000);
			String EmailTitle1 = getText(ElsevierObjects. titleInEmail,"Verify the Subject of the Email");
			if(EmailTitle1.equalsIgnoreCase(StudentHeader)){
				Reporters.SuccessReport("Log into the designated email account for the main instructor and Verify the Subject of Email","Successfully Logged into the designated email account and also verified Email subject</br> Actual title is :"+EmailTitle1+"</br> Expected title is: " +StudentHeader);
			}else{
				Reporters.failureReport("Log into the designated email account for the main instructor and Verify the Subject of Email","Failed to verify Email subject </br> Actual title is :"+EmailTitle1+"</br> Expected title is: " +StudentHeader);
			}
			Thread.sleep(3000);
			switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
			String emailBody1=getText(ElsevierObjects.email_body_text,"Get email body text");
			
			if(emailBody1.contains(newStudentUserName)&& emailBody1.contains(newStudentPassword)){ 
				Reporters.SuccessReport("Verify email content.","Successfully Student details are verified :</br> Student Username :"+newStudentUserName+"</br> Student Password :"+newStudentPassword);
			}else{
				Reporters.failureReport("Verify email content.","Failed to verify the email content.");
			}
			
			driver.switchTo().defaultContent();
			
			/*
			if(emailBody1!=null){
				Reporters.SuccessReport("Verify Emailbody content","Successfully Emailbody content is verified </br> "+emailBody1);
			}else{
				Reporters.failureReport("Verify Emailbody content","Failed to verify Emailbody content.");
			}
			driver.switchTo().defaultContent();
			b= true;
			click(ElsevierObjects.Email_forward,"Forward button");
			b= false;
			Thread.sleep(3000);
			String parentHandle1 = driver.getWindowHandle();
			for(String winHandle : driver.getWindowHandles()) {
				driver.switchTo().window(winHandle);
				Thread.sleep(3000);
			} 
			Thread.sleep(1000);

			type(ElsevierObjects.Email_Forwarding_To,configProps.getProperty("gmailUsername"),"Gmail Account");
			Thread.sleep(3000);
			if(click(ElsevierObjects.Email_Send,"Send button and Email is forwarded to a checkable gmail account"))

			{
				Reporters.SuccessReport("Forward Email to checkable gmailAccount", "Sucessfully forwarded the Email to checkable gmail account");
			}
			else
			{
				Reporters.failureReport("Forward Email to checkable gmailAccount", "failed to forword the email");
			}
			driver.switchTo().window(parentHandle1);
			Thread.sleep(5000);
			*/
			
			//3rd email
			
			
			/*
			if(emailBody2!=null){
				Reporters.SuccessReport("Verify Emailbody content","Successfully Emailbody content is verified </br> "+emailBody2);
			}else{
				Reporters.failureReport("Verify Emailbody content","Failed to verify Emailbody content.");
			}
			
			
			//ReadingExcel.updateCellInSheet(1,0,configProps.getProperty("TestData"), "TC-15565", userName);
			//ReadingExcel.updateCellInSheet(1,1,configProps.getProperty("TestData"), "TC-15565", password);
			driver.switchTo().defaultContent();
			b= true;
			click(ElsevierObjects.Email_forward,"Forward button");
			b= false;
			Thread.sleep(3000);
			String parentHandle2 = driver.getWindowHandle();
			for(String winHandle : driver.getWindowHandles()) {
				driver.switchTo().window(winHandle);
				Thread.sleep(3000);
			} 
			Thread.sleep(1000);

			type(ElsevierObjects.Email_Forwarding_To,configProps.getProperty("gmailUsername"),"Gmail Account");
			Thread.sleep(1000);
			if(click(ElsevierObjects.Email_Send,"Send button and Email is forwarded to a checkable gmail account"))

			{
				Reporters.SuccessReport("Forward Email to checkable gmailAccount", "Sucessfully forwarded the Email to checkable gmail account");
			}
			else
			{
				Reporters.failureReport("Forward Email to checkable gmailAccount", "failed to forword the email");
			}


			driver.switchTo().window(parentHandle2);
			Thread.sleep(3000);
			*/
			
			b=true;
			click(ElsevierObjects.email_logout,"Logout button");  
			b = false;
			}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);
		}
		return flag;
		}


	//==================================End of the Method==========================================//




	public static boolean GmailverificationforFaculty() throws Throwable{
		boolean flag = true;
		try
		{
			
			//driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");
			Thread.sleep(2000);
			launchUrl(configProps.getProperty("GmailURL"));
			Thread.sleep(2000);
			b=true;
			type(ElsevierObjects.Gmail_username,configProps.getProperty("gmailUsername"),"Enter username");
			Thread.sleep(2000);
			type(ElsevierObjects.Gmail_password,configProps.getProperty("gmailPassword"),"Enter password");
			Thread.sleep(2000);
			click(ElsevierObjects.Gmail_login,"Login");
			Thread.sleep(3000);
			b=false;
			click(ElsevierObjects.Gmail_searchbox,"Click on gmail searchbox");
			Thread.sleep(2000);
			type(ElsevierObjects.Gmail_searchbox,LoEmail,"Enter EmailAddress in the searchbox");
			Thread.sleep(2000);
			click(ElsevierObjects.Gmail_search_button,"Click on search button");
			Thread.sleep(3000);
			click(ElsevierObjects.Gmail_verify_mail,"Click on forward mail present there");
			Thread.sleep(4000);
			String Pwd = "******";
			String content = getText(ElsevierObjects.Gmail_total_frame,"Get Text of body content");
			if(content.contains(ID)&& content.contains(faLastName) && content.contains(faFirstName) && content.contains(faEmail) && content.contains(RosterUser) && content.contains("******")&& content.contains(studentLastName)
					&& content.contains(studentFirstName)&& content.contains(studentEmail)&& content.contains(newStudentUserName)&& content.contains(newLastname)&& content.contains(newFirstname)&&content.contains(newEmail) && content.contains(userName)&& content.contains(password)){
				Reporters.SuccessReport("Verify text in Gmail","Successfully details in Email are compared and the details are :</br> CourseId :" +ID+"</br> Student Firstname :"+studentFirstName+"</br> Student Lastname :"+studentLastName+"</br> Student EmailId :"+studentEmail+"</br> Student Username :"+newStudentUserName+"</br> Student Password :"+Pwd+
						"</br> Faculty Firstname :"+faFirstName+"</br> Faculty Lastname :"+faLastName+"</br> Faculty EmailId :"+faEmail+"</br> Faculty Username :"+RosterUser+"</br> Faculty Password :"+Pwd+
						"</br> RosterStudent Firstname :"+newFirstname+"</br> RosterStudent Lastname :"+newLastname+"</br> RosterStudent EmailId :"+newEmail+"</br> RosterStudent Username :"+userName+"</br> RosterStudent Password :"+password);
			}else{
				Reporters.failureReport("Verify text in Gmail","Failed to verify the Emailbody");
			}
			//2nd iteration
			Thread.sleep(3000);
			click(ElsevierObjects.Gmail_searchbox,"Click on gmail searchbox");
			Thread.sleep(3000);
			type(ElsevierObjects.Gmail_searchbox,newStudentUserName,"Enter EmailAddress in the searchbox");
			Thread.sleep(3000);
			click(ElsevierObjects.Gmail_search_button,"Click on search button");
			Thread.sleep(3000);
			WebElement element = driver.findElement(By.xpath(".//*[@class='y6']//span[2]/b[text()='"+newStudentUserName+"']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", element);
			//click(ElsevierObjects.Gmail_verify_mail,"Click on forward mail present there");
			Thread.sleep(3000);
			String content1 = getText(ElsevierObjects.Gmail_total_frame_top,"Get Text of body content");
			if(content1.contains(newStudentUserName)&& content1.contains(newStudentPassword)){ 
				Reporters.SuccessReport("Verify text in Gmail","Successfully Student details are verified :</br> Student Username :"+newStudentUserName+"</br> Student Password :"+newStudentPassword);
			}else{
				Reporters.failureReport("Verify text in Gmail","Failed to verify the Emailbody");
			}

			//3rd iteration
			Thread.sleep(3000);
			click(ElsevierObjects.Gmail_searchbox,"Click on gmail searchbox");
			Thread.sleep(3000);
			type(ElsevierObjects.Gmail_searchbox,newEmail,"Enter EmailAddress in the searchbox");
			Thread.sleep(3000);
			click(ElsevierObjects.Gmail_search_button,"Click on search button");
			Thread.sleep(3000);
			WebElement element1 = driver.findElement(By.xpath(".//*[@class='y6']/span[1]"));
			JavascriptExecutor executor1 = (JavascriptExecutor)driver;
			executor1.executeScript("arguments[0].click();", element1);
			Thread.sleep(3000);
			String content2 = getText(ElsevierObjects.Gmail_total_frame,"Get Text of body content");
			if(content2.contains(userName)&& content2.contains(password)){ 
				Reporters.SuccessReport("Verify text in Gmail","Successfully Roster Student details are verified :</br> Student Username :"+userName+"</br> Student Password :"+password);
			}else{
				Reporters.failureReport("Verify text in Gmail","Failed to verify the Emailbody");
			}

			click(ElsevierObjects.Gmail_Signout_button,"Click on dropdown");
			Thread.sleep(3000);
			click(ElsevierObjects.Gmail_Logout,"Click on signout button");
			}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);
		} 
		return flag;
	}


	//==================================End of the Method==========================================//



	public static boolean InstructorRelogin() throws Throwable{
		boolean flag = true;
		try
		{
			
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			launchUrl(configProps.getProperty("URL3"));
			//EvolveCommonBussinessFunctions.instructorLogout();
			if(click(ElsevierObjects.Student_Home_Login,"Click on login button")){
				Reporters.SuccessReport("Click on login", "Launched Evolvecert URL Successfully and clicked on login");
			}else{
				Reporters.failureReport("Click on login", "Failed to Launch Evolvecert URL and click on login");
			}
			Thread.sleep(1000);
			b=true;
			type(ElsevierObjects.common_login_userName,ReadingExcel.columnDataByHeaderName("Faculty_UserName","TC_8561",testDataPath),"Enter username in the textbox");
			Thread.sleep(1000);
			type(ElsevierObjects.common_login_passWord,ReadingExcel.columnDataByHeaderName("Faculty_UserPwd","TC_8561",testDataPath),"Enter Password in the textbox");
			Thread.sleep(1000);
			b=false;
			if(click(ElsevierObjects.submit,"Click on login button")){
				Reporters.SuccessReport("Click on login", "User is Successfully login with the faculty details");
			}else{
				Reporters.failureReport("Click on login", "User is failed to login with the faculty details");
			}
			Thread.sleep(1000);
			b=true;
			click(ElsevierObjects.Myevolve,"MyEvolve");
			b=false;
			String ID1="true";
			CreateRosterforLOcourse_8561.courseIDSearch(ID1);
			b=true;
			click(ElsevierObjects.roster_And_Teams_lnk,"' Roster & Teams' link");
			Thread.sleep(2000);
			b=false;
			switchToFrameById("embeddedTool");
			String user = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+newStudentUserName+"')]"),"Get the Student Username");
			if(user!=null){
				Reporters.SuccessReport("Verify Student Username from the table","Successfully Student Username is verified </br>" +user);
			}else{
				Reporters.failureReport("Verify Student Username from the table","Failed to verify Student Username");
			}
			String role = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+newStudentUserName+"')]/following-sibling::td[contains(text(),'Student')]"),"Get the Role of user");
			if(role!=null){
				Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +role);
			}else{
				Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
			}
			String fuser = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+RosterUser+"')]"),"Get Faculty Usename from table");
			if(fuser!=null){
				Reporters.SuccessReport("Verify Faculty Username from the table","Successfully Faculty Username is verified </br>" +fuser);
			}else{
				Reporters.failureReport("Verify Faculty Username from the table","Failed to verify Faculty Username");
			}
			String Role = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+RosterUser+"')]/following-sibling::td[contains(text(),'Instructor')]"),"Get the Role of User");
			if(Role!=null){
				Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +Role);
			}else{
				Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
			}
			String newuser = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+userName+"')]"),"Get the new Student Username");
			if(newuser!=null){
				Reporters.SuccessReport("Verify new Student Username from the table","Successfully new Student Username is verified </br>" +newuser);
			}else{
				Reporters.failureReport("Verify new Student Username from the table","Failed to verify new Student Username");
			}
			String role1 = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+userName+"')]/following-sibling::td[contains(text(),'Student')]"),"Get the Role of user");
			if(role1!=null){
				Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +role1);
			}else{
				Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
			} 
			switchToDefaultFrame();
			EvolveCommonBussinessFunctions.instructorLogout();
			}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);
		} 
		return flag;
	}
	



	//==================================End of the Method==========================================//




	public static boolean RostersearchingAdmin() throws Throwable{
		boolean flag = true;
		
		try
		{
			
			b= true;
			click(ElsevierObjects.Admin_Search_Rosters,"Search Rosters");
			Thread.sleep(1000);
			type(ElsevierObjects.Roster_Course_ID,ID,"Enter the CourseId in the textbox");
			Thread.sleep(1000);
			click(ElsevierObjects.Roster_Search,"Search button");
			Thread.sleep(1000);
			click(ElsevierObjects.Course_ID_Link,"Courseid link of the Roster now created");
			Thread.sleep(1000);
			b= false;
			String fUser =getText(By.xpath(".//*[@id='pageBody']//tr//td[contains(text(),'"+RosterUser+"')]"),"Get Faculty Usename from table");
			Thread.sleep(1000);
			if(fUser!=null){
				Reporters.SuccessReport("Verify Faculty Username from the table","Successfully Faculty Username is verified </br>" +fUser);
			}else{
				Reporters.failureReport("Verify Faculty Username from the table","Failed to verify Faculty Username");
			}
			String fRole =getText(By.xpath(".//*[@id='pageBody']//tr//td[contains(text(),'"+RosterUser+"')]/following-sibling::td[contains(text(),'Instructor')]"),"Get the Role of user");
			Thread.sleep(1000);
			if(fRole!=null){
				Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +fRole);
			}else{
				Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
			}
			String sUser =getText(By.xpath(".//*[@id='pageBody']//tr//td[contains(text(),'"+newStudentUserName+"')]"),"Get student Usename from table");
			Thread.sleep(1000);
			if(sUser!=null){
				Reporters.SuccessReport("Verify Student Username from the table","Successfully Student Username is verified </br>" +sUser);
			}else{
				Reporters.failureReport("Verify Student Username from the table","Failed to verify Student Username");
			}
			String sRole =getText(By.xpath(".//*[@id='pageBody']//tr//td[contains(text(),'"+newStudentUserName+"')]/following-sibling::td[contains(text(),'Student')]"),"Get the Role of user");
			Thread.sleep(1000);
			if(sRole!=null){
				Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +sRole);
			}else{
				Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
			}
			String nUser =getText(By.xpath(".//*[@id='pageBody']//tr//td[contains(text(),'"+userName+"')]"),"Get student Username from table");
			Thread.sleep(1000);
			if(nUser!=null){
				Reporters.SuccessReport("Verify new Student Username from the table","Successfully new Student Username is verified </br>" +nUser);
			}else{
				Reporters.failureReport("Verify new Student Username from the table","Failed to verify new Student Username");
			}
			String nRole =getText(By.xpath(".//*[@id='pageBody']//tr//td[contains(text(),'"+userName+"')]/following-sibling::td[contains(text(),'Student')]"),"Get the Role of user");
			Thread.sleep(1000);
			if(nRole!=null){
				Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +nRole);
			}else{
				Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
			}
			}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);
		} 
		return flag;
	}



	//==================================End of the Method==========================================//




	public static boolean StudentRelogin() throws Throwable{
		
		boolean flag = true;
		try
		{
		
			launchUrl("https://evolvetest.elsevier.com/cs/store?role=student");
			Thread.sleep(1000);

			//User_BusinessFunction.Studentlogin(ElsevierObjects.common_login_userName, ElsevierObjects.common_login_passWord,newStudentPassword);

			if(click(ElsevierObjects.Student_Home_Login,"Click on login button"))
			{
				b=true;
				Reporters.SuccessReport("Click on login", "Launched Evolvecert URL Successfully and clicked on login");
			}else{
				Reporters.failureReport("Click on login", "Failed to Launch Evolvecert URL and click on login");
			}
			Thread.sleep(1000);
			type(ElsevierObjects.common_login_userName,newStudentUserName,"Enter username");
			Thread.sleep(1000);
			type(ElsevierObjects.common_login_passWord,newStudentPassword,"Enter Password");
			Thread.sleep(1000);
			b=false;
			if(click(ElsevierObjects.submit,"Click on login button")){
				Reporters.SuccessReport("Click on login", "User is Successfully login with the created student details");
			}else{
				Reporters.failureReport("Click on login", "User is failed to login with the created student details");
			}
			Thread.sleep(1000);
			b=true;
			click(ElsevierObjects.Myevolve,"My Evolve");
			Thread.sleep(1000);
			b=false;
			String Id = getText(ElsevierObjects.Roster_Evolve_CourseId,"Get Unique CourseId");
			if(Id.contains(ID)){
				Reporters.SuccessReport("Verify Unique CourseId","Successfully verified CourseId </br> Actual CourseId is :"+ID+"</br> Expected CourseId is: "+Id);
			}else{
				Reporters.failureReport("Verify Unique CourseId","Failed to verify CourseId");
			}
			Thread.sleep(1000);
			String Courselink = getText(ElsevierObjects.Roster_Evolve_Courselink,"Get Unique CourseId link");
			if(Courselink!=null){
				Reporters.SuccessReport("Verify Unique CourseId link","Successfully verified CourseId link </br>" +Courselink);
			}else{
				Reporters.failureReport("Verify Unique CourseId link","Failed to verify CourseId link");
			}
			Thread.sleep(1000);
			b=true;
			click(ElsevierObjects.Roster_Evolve_Courselink,"Unique CourseId link");
			Thread.sleep(1000);
			click(ElsevierObjects.educator_CoursePage_Courselink,"Courses");
			Thread.sleep(1000);
			b=false;
			String Protect = getText(ElsevierObjects.Protected_content,"Get title of Protected Content");
			if(Protect!=null){
				Reporters.SuccessReport("Verify title of Protected Content","User is Successfully verified title of Protected Content</br>" +Protect);
			}else{
				Reporters.failureReport("Verify title of Protected Content","User is failed to verify title of Protected Content");
			}
			Thread.sleep(1000);
			if(isElementPresent(ElsevierObjects.redeem_AcessCode_txt,"RedeemAccess Blank textbox")){
				Reporters.SuccessReport("Verify RedeemAccess Blank textbox","User is Successfully verified RedeemAccess Blank textbox");
			}else{
				Reporters.failureReport("Verify RedeemAccess Blank textbox","User is failed to verify RedeemAccess Blank textbox");
			}
			Thread.sleep(1000);
			click(ElsevierObjects.protectedContent_PopUp_cancel_Btn,"Cancle button");
			EvolveCommonBussinessFunctions.instructorLogout();
		}
			catch(Exception e){
				sgErrMsg=e.getMessage();
				System.out.println(e);
			} 
			return flag;
	}



	//==================================End of the Method==========================================//


	public static boolean RosterStudentRelogin() throws Throwable{
		boolean flag = true;
		try
		{
			
			b=true;
			if(click(ElsevierObjects.Student_Home_Login,"Click on login button")){
				Reporters.SuccessReport("Click on login", "Launched Evolvecert URL Successfully and clicked on login");
			}else{
				Reporters.failureReport("Click on login", "Failed to Launch Evolvecert URL and click on login");
			}
			Thread.sleep(1000);
			type(ElsevierObjects.common_login_userName,userName,"Enter username");
			Thread.sleep(1000);
			type(ElsevierObjects.common_login_passWord,password,"Enter Password");
			Thread.sleep(1000);
			b=false;
			if(click(ElsevierObjects.submit,"Click on login button")){
				Reporters.SuccessReport("Click on login", "Successfully login with the created student details");
			}else{
				Reporters.failureReport("Click on login", "Failed to login with the created student details");
			}
			Thread.sleep(1000);
			b=true;
			click(ElsevierObjects.Myevolve,"My Evolve");
			Thread.sleep(1000);
			b=false;
			String Id = getText(ElsevierObjects.Roster_Evolve_CourseId,"Get Unique CourseId");
			if(Id.contains(ID)){
				Reporters.SuccessReport("Verify Unique CourseId","Successfully verified CourseId </br> Actual CourseId is :"+ID+"</br> Expected CourseId is: "+Id);
			}else{
				Reporters.failureReport("Verify Unique CourseId","Failed to verify CourseId");
			}
			Thread.sleep(1000);
			String Courselink = getText(ElsevierObjects.Roster_Evolve_Courselink,"Get Unique CourseId link");
			if(Courselink!=null){
				Reporters.SuccessReport("Verify Unique CourseId link","Successfully verified CourseId link </br>" +Courselink);
			}else{
				Reporters.failureReport("Verify Unique CourseId link","Failed to verify CourseId link");
			}
			Thread.sleep(1000);
			b=true;
			click(ElsevierObjects.Roster_Evolve_Courselink,"Unique CourseId link");
			Thread.sleep(1000);
			click(ElsevierObjects.educator_CoursePage_Courselink,"Courses");
			Thread.sleep(1000);
			b=false;
			String Protect = getText(ElsevierObjects.Protected_content,"Get title of Protected Content");
			if(Protect!=null){
				Reporters.SuccessReport("Verify title of Protected Content","User is Successfully verified title of Protected Content</br>" +Protect);
			}else{
				Reporters.failureReport("Verify title of Protected Content","User is failed to verify title of Protected Content");
			}
			Thread.sleep(1000);
			if(isElementPresent(ElsevierObjects.redeem_AcessCode_txt,"RedeemAccess Blank textbox")){
				Reporters.SuccessReport("Verify RedeemAccess Blank textbox","User is Successfully verified RedeemAccess Blank textbox");
			}else{
				Reporters.failureReport("Verify RedeemAccess Blank textbox","User is failed to verify RedeemAccess Blank textbox");
			}
			Thread.sleep(1000);
			click(ElsevierObjects.protectedContent_PopUp_cancel_Btn,"Cancle button");
			EvolveCommonBussinessFunctions.instructorLogout();
			}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);
		}
		return flag;
	} 
}





