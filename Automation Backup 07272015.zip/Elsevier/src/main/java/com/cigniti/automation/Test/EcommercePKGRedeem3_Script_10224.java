package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EcommercePKGRedeem3_10224;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class EcommercePKGRedeem3_Script_10224 extends EcommercePKGRedeem3_10224{

	@Test
	public void ecommercePKGRedeem3_10224() throws Throwable
	{
	try{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		isbnVerify("Ecom_TCID_10217",tc10217_a.get("ISBNTextBox1"), 17, 18, 19, 1);
		isbnVerify("Ecom_TCID_10217",tc10217_a.get("ISBNTextBox2"), 20, 21, 22, 1);
		isbnVerify("Ecom_TCID_10217",tc10217_a.get("ISBNTextBox3"), 23, 24, 25, 1);
		if(evolveAdminlogin())
		{
			Reporters.SuccessReport("Login into Application as Admin ", "Successfully logged in as Admin user "+ configProps.getProperty("adminemail"));
		}else{
    	  
			Reporters.failureReport("Login into Application as Admin  ", "Failed to login as Admin user"+ configProps.getProperty("adminemail"));
		}
		//accessCodePackage;
		
		if(verifyEcommerceLink())
		{
     		Reporters.SuccessReport("Access code package link ", "Successfully clicked on access code pacakge link");
		}else
		{			
			Reporters.failureReport("Access code package link ", "Failed to click on access code pacakge link");
		}		
		if(viewTopViewAddPakage())
		{
     		Reporters.SuccessReport("Top View of Add Package", "All fields are available in Add Package");
		}
		else
		{			
			Reporters.failureReport("Top View of Add Package", "All fields are not available in Add Package");
		}
		
		if(inputPackageData())
		{
     		Reporters.SuccessReport("Input the Package Data", "The data is correctly entered into the fields");
		}
		else
		{
			Reporters.failureReport("Input the Package Data", "The data is Not correctly entered into the fields");
		}
		
		if(verifyAndAddISBNPackages())
		{
     		Reporters.SuccessReport("Verify and Add ISBN Packages", "The data is verified and entered into the fields");
		}
		else
		{			
			Reporters.failureReport("Verify and Add ISBN Packages", "The data is verified and entered into the fields");
		}
		
		if(crossPromotionTab())
		{
     		Reporters.SuccessReport("Promotion Tab", "The data is correctly entered into the fields");
		}
		else
		{			
			Reporters.failureReport("Promotion Tab", "The data is correctly entered into the fields");
		}
		
		if(marketingPageTab())
		{
	 		Reporters.SuccessReport("Validating Marketing Tab", "Marketing tab validations are Successfully Done");
		}
		else
		{			
			Reporters.failureReport("Validating Marketing Tab", "Marketing tab validations are failed");
		}
				
		if(crossPromoteItems())
		{
	 		Reporters.SuccessReport("Validating Cross Promote Items", "Cross Promote items are Successfully Validated");
		}
		else
		{			
			Reporters.failureReport("Validating Cross Promote Items", "Cross Promote items are Validation failed");
		}
		String uniqueURL = "evolvetest.elsevier.com"+ EvolveCommonBussinessFunctions.uniqueURL;
		if(launchUrl_AddToCart(uniqueURL))
		{
	 		Reporters.SuccessReport("Launching uniqueUrl and Adding product to Cart", "Product added and validated");
		}
		else
		{			
			Reporters.failureReport("Launching uniqueUrl and Adding product to Cart", "Product validation failed");
		}
		
		if(verifyCart())
		{
	 		Reporters.SuccessReport("Verify items in the cart", "Items in the cart are Successfully Validated");
		}
		else
		{			
			Reporters.failureReport("Verify items in the cart", "Items in the cart validation failed ");
		}
		if(validateConfirmationPage())
		{
	 		Reporters.SuccessReport("Validating Cross Promote Items", "Cross Promote items are Successfully Validated");
		}
		else
		{			
			Reporters.failureReport("Validating Cross Promote Items", "Cross Promote items are Validation failed");
		}
		Thread.sleep(medium);
		//myEvolveLink();
		
	}catch(Exception e){
		System.out.println(e.getMessage());
	}
	
	}
	@AfterTest
	public void tear() throws Throwable{
		HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		Base.tearDown();
	}
}
