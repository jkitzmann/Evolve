package com.cigniti.automation.BusinessFunctions;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class LO_SelfStudy_ECommerce_15570_BussinessFunctions extends Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions {

	String priceText ="";


	@Override
	public void searchISBNNumber(String isBNumber) throws Throwable {

		boolean flag = true;

		String errorMessage ="";
		try{
			if(!click(ElsevierObjects.catalog, "catalog link")){
				flag = false;
			}
			Thread.sleep(medium);
			if(type(ElsevierObjects.txtproductsearch, isBNumber, "ISBN number")){
				Reporters.SuccessReport("Enter the ISBN into the search box", "Successfully entered the ISBN :  "+isBNumber+" into the search box");
			}else{
				Reporters.failureReport("Enter the ISBN into the search box", "Failed to enter the ISBN :  "+isBNumber+" into the search box");
			}
			Thread.sleep(medium);

			if(click(ElsevierObjects.gobutton, "GO button")){
				Reporters.SuccessReport("Search for a product "+isBNumber+" that is setup for LO Self Study Fulfillment.", "Successfully searched for the product "+isBNumber);
			}else{
				Reporters.failureReport("Search for a product "+isBNumber+" that is setup for LO Self Study Fulfillment.", "Failed to search for the product : "+isBNumber);
			}
			Thread.sleep(medium);

			if(isElementPresent(By.xpath("//li//span[text()='"+isBNumber+"']"))){
				Reporters.SuccessReport("Verify Product Page", "User is on the product page for "+isBNumber);
			}else{
				Reporters.failureReport("Verify Product Page", "User is not on the product page for "+isBNumber);
			}

			priceText = getText(ElsevierObjects.priceText, "price text");


			if(click(ElsevierObjects.btnaddtocart, "Add to cart button")){
				Reporters.SuccessReport("Register for this product to add it to the cart.", "The product is Successfully added to the cart without any issues");
			}else{
				Reporters.failureReport("Register for this product to add it to the cart.", "The product is not added to the cart ");
			}
			Thread.sleep(medium);

			String title=getText(By.xpath("//div[@class='cartproductdetails']"), "");
			String price=getText(By.xpath("//div[text()='"+priceText.trim()+"']"), "Price");
			if(title.contains(isBNumber) && isElementPresent(By.xpath("//div[text()='"+priceText.trim()+"']"))){
				Reporters.SuccessReport("Verify Title and ISBN Number", "The Tilte and ISBN Number are correct and prices mathces  what is set up for the product <br/> The details are : "+title+" and " +price);
			}else{
				Reporters.SuccessReport("Verify Title and ISBN Number", "The Tilte and ISBN Number are not");
			}
			if(click(ElsevierObjects.btnRedeem, "Reedeem Button")){
				Reporters.SuccessReport("On My Cart page, select the radio button to pay with credit card.  Press Checkout. ", "Successfully clicked on the Redeem Checkout button <br>User is taken to the Update your Account page. ");
			}

		}catch(Exception e){

		}
	}


	public static void  enterBillingInformation(String isbNumber,String couserTitle) throws Throwable{

		LO_SelfStudy.formFill(ElsevierObjects.STUDENT);

		LO_SelfStudy.verifyBillingAddress();

		try
		{
			System.out.println("Credit Text ==>>>"+getText(By.xpath("//div[@class='current']"),""));
			if(getText(By.xpath("//div[@class='current']"),"").contains("1. CREDIT CARD")){
				Reporters.SuccessReport("Verify User Navigation  Credit Card", "User Success fully Brought to  Credit Card page");	
			}else{
				Reporters.failureReport("Verify User Navigation  Credit Card", "User  was unable  to navigate   Credit Card page");	
			}

			/*if(creditCardDetails()){
				Reporters.SuccessReport("Input Credit Card details", "Credit Card details are successfully entered: <br> Card Type : "+cardType+"<br>Card Number : "+cardNumber+"<br>Card CVV : "+cardCVV+"<br>Card Name : "+cardName);
			}else{
				Reporters.failureReport("Input Credit Card details", "Credit Card details are failed to enter");
			}*/
			Evolve_StudentLogin_9795.evolve_StudentCreditCardDetails();

			Thread.sleep(high);

			System.out.println("Review Text ==>>>"+getText(By.xpath("//div[@class='current']"),""));

			if(getText(By.xpath("//div[@class='current']"),"").equalsIgnoreCase("2. REVIEW & SUBMIT")){
				Reporters.SuccessReport("Verify User Navigation Review", "User Success fully Brought to  Review page");	
			}else{ 
				Reporters.failureReport("Verify User Navigation Review", "User  was unable  to navigate   Review page");	
			}

			String title = getText(By.xpath("//div[@class='carttitle']/a"),"");

			if(title.contains("") && getText(By.xpath("//div[@class='cartproductdetails']"), "").contains(isbNumber)){
				Reporters.SuccessReport("Veify Item title,ISBN, Price ", " Item Title , isbn price are correct");
			}else{
				Reporters.failureReport("Veify Item title,ISBN, Price ", " Item Title , isbn price are in correct");
			}

			List<WebElement> priceList = driver.findElements(By.xpath("//div[@class='price span2']"));
			String priceText = priceList.get(1).getText().split("\\$")[1];

			String estimatedTax = getText(By.xpath("//*[@id='pageLayout-body-inner-most']/div/div/div[5]/div[1]/div[3]/table/tbody/tr[2]/td[2]"), "");

			System.out.println("Estimated Tax===>>>"+estimatedTax);

			Double totalValue = Double.parseDouble(estimatedTax.split("\\$")[1])+Double.parseDouble(priceText);

			if(isElementPresent(By.xpath("//*[@id='pageLayout-body-inner-most']//table//td[text()='$"+totalValue+"']"))){
				Reporters.SuccessReport("Verify total Sum", "total is the sum of the item price and estimated tax amount.");
			}else{
				Reporters.failureReport("Verify total Sum", "total is not the sum of the item price and estimated tax amount.");
			}

			click(ElsevierObjects.chkaccept, "Accept check box");

			click(ElsevierObjects.Student_Review_Submit, "Submit button");

			Thread.sleep(12000);

			System.out.println("Confirmation Text ==>>>"+getText(By.xpath("//div[@class='current']"),""));

			if(getText(By.xpath("//div[@class='current']"),"").equalsIgnoreCase("3. CONFIRMATION")){
				Reporters.SuccessReport("Verify User Navigation Confirmation", "User Successfully Brought to  Confirmation page");	
			}else{ 
				Reporters.failureReport("Verify User Navigation Confirmation", "User Successfully was unable  to navigate   Confirmation page");	
			}

			if(getText(By.xpath("//span[@class='totalamount']"),"").contains(priceText)){
				Reporters.SuccessReport("Verify Total", "Total is the same as the item price");
			}else{
				Reporters.failureReport("Verify Total", "Total is not same as the item price");
			}

			String title1 = getText(By.xpath("//div[@class='carttitle']/a"),"");

			if((title1!=null) && getText(By.xpath("//div[@class='cartproductdetails']"), "").contains(isbNumber)){
				Reporters.SuccessReport("Veify Item title,ISBN, Price ", " Item Title , isbn and price are correct <br/> The details on the page are : "+title1+" and "+isbNumber);
			}else{
				Reporters.failureReport("Veify Item title,ISBN, Price ", " Item Title , isbn price are in correct");
			}

		}
		catch(Exception e)

		{

			sgErrMsg=e.getMessage();
		}

	}

	public void evolveCatalog(String isbnNUmber) throws Throwable{
		try
		{
			Thread.sleep(medium);
			if(javaClick(ElsevierObjects.lnkevolve, "evolve link")){
				Reporters.SuccessReport("Click on My Evolve tab.", "Successfully clicked on the My Evolve tab");
			}else{
				Reporters.failureReport("Click on My Evolve tab.", "Failed to click on the My Evolve tab");
			}
			Thread.sleep(low);

			if(isElementPresent(By.xpath("//span[text()='COURSE ID: 166768_selfstudy_0001']"),"COURSE ID: 166768_selfstudy_0001"))
				Reporters.SuccessReport("Verify User Content List ", "resource in user's content list as: 166768_selfstudy_0001");
			else
				Reporters.failureReport("Verify User Content List ", "unable to see the 166768_selfstudy_0001 in course content list ");

			click(By.xpath("//a[text()='PBC Test - UAT0237 - SimChart eComm (SME), 1st Edition']"), "item");


			if(javaClick(By.xpath("//span[text()='SimChart for the Medical Office']"), "item")){
				Reporters.SuccessReport("Click on the 'SimChart for the Medical Office' library folder.", "Successfully clicked on the 'SimChart for the Medical Office' library folder.");
			}else{
				Reporters.failureReport("Click on the 'SimChart for the Medical Office' library folder.", "Failed to click on the 'SimChart for the Medical Office' library folder.");
			}

			/*	rightclick(By.xpath("//span[text()='SimChart for the Medical Office']"), "simchart for the medical office");
		Robot r=new Robot();
		r.keyPress(KeyEvent.VK_DOWN);
		r.keyPress(KeyEvent.VK_ENTER);*/

			Set<String> windowName = driver.getWindowHandles();

			for(String s:windowName){
				System.out.println("Window Name===>>>>"+s);
				driver.switchTo().window(s);
				Thread.sleep(medium);
			}
			if(isElementPresent(By.id("logoimg"),"login button image"))

				Reporters.SuccessReport("Verify New window", " User Success fully navigates to New window");
			else{
				Reporters.failureReport("Verify New window", " User unable to navigate New window");
			}
		}
		catch(Exception e)

		{

			sgErrMsg=e.getMessage();
		}

	}

	public void coursePARReport(String courseId,String userName) throws Throwable{
		try
		{
			if(click(ElsevierObjects.EVOLVE_BUTTON, "Evolve button")){
				Reporters.SuccessReport("Click on the Evolve Admin button", " Successfully clicked on the Evolve Admin Button");
			}else{
				Reporters.failureReport("Click on the Evolve Admin button", " Successfully clicked on the Evolve Admin Button");
			}


			if(click(ElsevierObjects.COURSE_PAR_REPORT, "COurse PAR report")){
				Reporters.SuccessReport("Click on the Course PAR Report", " Successfully clicked on the Course PAR Report");
			}else{
				Reporters.failureReport("Click on the Course PAR Report", " Successfully clicked on the Course PAR Report");
			}

			if(type(ElsevierObjects.txtcourseID_1, courseId, "course ID")){
				Reporters.SuccessReport("Enter the course ID : "+courseId, " Successfully entered course ID : "+courseId);
			}else{
				Reporters.failureReport("Enter the course ID : "+courseId, " Failed to enter course ID : "+courseId);
			}

			if(click(ElsevierObjects.btncoursego, "GO button")){
				Reporters.SuccessReport("Click on the Go Button", " Successfully clicked on the Go Button");
			}else{
				Reporters.failureReport("Click on the Go Button", " Successfully clicked on the Go Button");
			}




			if(isElementPresent(By.xpath("//span[text()='"+userName+"']"))){
				Reporters.SuccessReport("Verify the Record", "The record displays the student's "+userName);
			}else{
				Reporters.failureReport("Verify the Record", "The unable to find the record with the student's "+userName);
			}
		}

		catch(Exception e)

		{

			sgErrMsg=e.getMessage();
		}

	}
}