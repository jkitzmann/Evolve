package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.KNO_Pageburst_CC_NewStudent_15231;
import com.cigniti.automation.BusinessFunctions.LO_GlobalCourse_9826;
import com.cigniti.automation.BusinessFunctions.LO_GlobalStudent_8571;
import com.cigniti.automation.BusinessFunctions.LO_Global_Instructor_AR_8572;
import com.cigniti.automation.BusinessFunctions.SelfEnrollLOCourseHomePage_10303;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class LO_GlobalCourse_Script_9826 extends LO_GlobalCourse_9826 {

	@Test 
	public void lo_GlobalCourse_Script_9826() throws Throwable{
		try {
			
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			stepReport("Create new instructor user");
			trial="false";
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String user="educator";
			KNO_Pageburst_CC_NewStudent_15231.CreateUser(user);
			String product = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("Product"); 
			String productCost = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("ProductCost");
		
			stepReport("Search for product and add to cart");
			writeReport(EvolveCommonBussinessFunctions.searchProduct(product,productCost),"Serach for the product..",
					  "Successfully Entered ISBN:"+product+" in Search Box.</br>Clicked On Go Button.</br>Navigated To Product Details Page.",
					  "Failed to Enter ISBN:"+product+" in Search Box.");

			writeReport(EvolveCommonBussinessFunctions.requestProduct(),"Clicking on the Request Product Button In Product Details Page.",
					"Successfully clicked on Request Product Button.",
					"Failed to click on Request Product Button.");
			
			stepReport("Verify cart contents and enter checkout");
			LO_Global_Instructor_AR_8572.myCart();
			
			stepReport("Complete checkout and submit order");
			EvolveCommonBussinessFunctions.updateVSTandKNOAccount("educator","","","");
			
			//SelfEnrollLOCourseHomePage_10303.StudentReviewandSubmit();
			
			if(reviewAndSubmit()){
				Reporters.SuccessReport("Navigating To Review And Submit Page And Submitting The Order In Review Page.","User is brought directly to the 'Review/Submit' page because there is no shipping or billing associated with the order.</br>Clicked On CheckBoxes And Submitted The Order.");
			} else {
				Reporters.failureReport("Navigating To Review And Submit Page And Submitting The Order In Review Page.","Failed To Click On CheckBoxes And Failed To Submit The Order.");
			}
			Thread.sleep(veryhigh);
			
			stepReport("Verify receipt page");
			LO_GlobalStudent_8571.receiptPage();
			
			getAccountDetails();
			
			writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the Faculty page.", 
					"Sucecssfully logged out the Faculty:"+credentials[0], 
					"Failed to logout the Faculty page:"+credentials[0]);
			
		//	SwitchToBrowser(ElsevierObjects.adminBrowserType);
			stepReport("Login to Evolve Admin");
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login to Application Using Admin Credentials"+adminUser,
					"Launching the URL for Admin is successfull </br > Login to Application Using Admin credentials :"+adminUser+" is Successfull", 
					"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");	
			
			stepReport("Search for the AR and fulfill it");
			LO_Global_Instructor_AR_8572.admin_Adoptionsearch();
			
			check_Approvedstatus();
			
			writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout as "+adminUser,
					"Successfully logged out admin page.", 
				  	"Failed to logout admin page.");	
			//SwitchToBrowser(ElsevierObjects.studentBrowserType);
			
			stepReport("Log back in as the new instructor user");
			writeReport(User_BusinessFunction.Educatorlogin(credentials[0],credentials[1]),"Relogin Into Educator Page.",
					"Successfully Logged Into Educator :"+credentials[0]+" Page.",
					"Failed To Login Into Educator Page.");
		
			String courseID=readcolumns.twoColumns(0, 1, "TC-9826 & 8572", configProps.getProperty("TestData")).get("CourseID");
			String courseTitle=readcolumns.twoColumns(0, 1, "TC-9826 & 8572", configProps.getProperty("TestData")).get("Educator_course_Title");
			
			stepReport("Verify the course is included in My Evolve");
			LO_Global_Instructor_AR_8572.educator_courseId_search(courseID,courseTitle);
			
			writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the Faculty page.", 
					"Sucecssfully logged out the Faculty:"+credentials[0], 
					"Failed to logout the Faculty page:"+credentials[0]);
			
			stepReport("Login to Evolve Admin and verify the role of the new user");
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login to Application Using Admin Credentials"+adminUser,
					"Launching the URL for Admin is successfull </br > Login to Application Using Admin credentials :"+adminUser+" is Successfull", 
					"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");
		
			viewUserProfile(credentials[0]);
			
			openEditUserProfilePage();
			
			writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout as "+adminUser,
					"Successfully logged out admin page.", 
				  	"Failed to logout admin page.");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}

