package com.cigniti.automation.Test;

import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EComm_Preorde_MyEvolve_Page15594_BussinessFunctions;
import com.cigniti.automation.BusinessFunctions.EComm_Preorde_rMyEvolve_Page15591_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.ECommercePackagependingcourseid_15461;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class EComm_Preorde_MyEvolve_Page15591_Script2 extends EComm_Preorde_rMyEvolve_Page15591_Bussiness_Functions {
	
	public static final String CINICAL_MEDICAL_ASSISTANT_ONLINE =ReadingExcel.columnDataByHeaderName("product", "TC-15591", testDataPath);
	
	@Test
	public void eCommPreordeMyEvolvePage15591_2() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		launchUrl(configProps.getProperty("URL4"));
		String username=readcolumns.twoColumns(0,1, "ECommercePreOrder", configProps.getProperty("TestData")).get("ECommPreordeMyEvolvePage15591");
		String password=readcolumns.twoColumns(0,2, "ECommercePreOrder", configProps.getProperty("TestData")).get("ECommPreordeMyEvolvePage15591");
		
		if(User_BusinessFunction.SignInAsDifferentUser(username, password)){
			Reporters.SuccessReport("Login into Application as same student user", "Successfully logged in as Student user with the credentials : <br> Username : "+username+"<br> Password : "+password);
		}else{
			Reporters.failureReport("Login into Application as same student user", "Failed to log in as Student user with the credentials : <br> Username : "+username+"<br> Password : "+password);
		}
		click(ElsevierObjects.Myevolve,"Click on my evolve");
		Thread.sleep(medium);
		String course=ReadingExcel.columnDataByHeaderName("course", "TC-15591", testDataPath);
		String button1=ReadingExcel.columnDataByHeaderName("button1", "TC-15591", testDataPath);
		String button2=ReadingExcel.columnDataByHeaderName("button2", "TC-15591", testDataPath);
		String courseType=ReadingExcel.columnDataByHeaderName("courseType", "TC-15591", testDataPath);
		
		ECommercePackagependingcourseid_15461.VerifyContentpagewithinputs(courseType,course,button1,button2,"Yes");
		//verifyOnlineCourseButtons();
		enterAsIndependentSelfStudy();
		//ECommercePackagependingcourseid_15461.VerifyContentpagewithinputs("Online Course","Clinical Medical Assisting Online for Clinical Procedures for Medical Assistants, 9th Edition","Enter Instructor's Course ID","Enter as Independent Self-Study","No");
		EComm_Preorde_MyEvolve_Page15594_BussinessFunctions.courseDetailsPage(By.xpath("//*[@id='set']/li/div/div/a"),"contentHome");
		
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
