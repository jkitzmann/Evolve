package com.cigniti.automation.BusinessFunctions;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Accessories;

public class Z_LO_Unique_Course_Fulfillment_Faculty_10410 extends EvolveCommonBussinessFunctions{
	public boolean emailVerificationn() throws Throwable{
		Map<String, String> userMap = readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData"));
		Map<String, String> emailDetails = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15584", configProps.getProperty("TestData"));
		
		Map<String, String> emailMap  = new HashMap<String, String>();
		emailMap.put("UserName", userMap.get("UserName"));
		emailMap.put("Password", userMap.get("Password"));
		emailMap.put("EmailSubject", emailDetails.get("EmailSubject"));
		emailMap.put("email", "automationEvolvea112@evolveqa.info");

		return emailVerification(emailMap);
	}
	
	public boolean emailVerification(Map<String, String> emailMap) throws Throwable{
		boolean flag=true;
		driver.manage().deleteAllCookies();
		Thread.sleep(medium);
		if(!launchUrl(configProps.getProperty("EmailURL"))){
			flag = false;
		}
		Thread.sleep(medium);
		if(!type(ElsevierObjects.emailaddress,configProps.getProperty("verifyemail_username"),"Enter email id")){
			flag=false;
		}
		Thread.sleep(medium);
		if(!type(ElsevierObjects.emailpassword,configProps.getProperty("verifyemail_password"),"Enter password")){
			flag=false;
		}
		Thread.sleep(medium);
		if(!click(ElsevierObjects.emaillogin, "Click on Login Button.")){
			flag=false;
		}
		Thread.sleep(medium);
		
		if(!click(ElsevierObjects.email_Icon,"Click on Email icon.")){
			flag=false;
		}
		Thread.sleep(medium);
		if(!click(ElsevierObjects.email_dropdown,"Click on Dropdown.")){
			flag=false;
		}
		Thread.sleep(medium);
		if(!click(ElsevierObjects.email_dropdown_Fromchk,"Click on From check box.")){
			flag=false;
		}
		Thread.sleep(medium);
		if(!click(ElsevierObjects.email_dropdown_Tochk,"Click on To checkbox.")){
			flag=false;
		}
		Thread.sleep(medium);
		if(!type(ElsevierObjects.email_SearchBox,emailMap.get("email"),"Enter the email id.")){
			flag=false;
		}
		Thread.sleep(medium);
		if(!click(ElsevierObjects.email_SearchIcon,"Click on search icon.")){
			flag=false;
		}
		Thread.sleep(medium);
		if(!switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame")){
			flag=false;
		}
		Thread.sleep(medium);
		String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text"); 
		
		if(!emailBody.contains(emailMap.get("UserName"))){
			flag = false;
		}

		if(!emailBody.contains(emailMap.get("Password"))){
			flag = false;
		}
		
		driver.switchTo().defaultContent();
		
		//Verify email Subject/Title
		if(!getText(ElsevierObjects.EmailSubject,"Fetch Email Subject").trim().equalsIgnoreCase(emailMap.get("EmailSubject").trim())){
			flag = false;
		}
		
		//logout of email application.
		if(!click(ElsevierObjects.email_logout,"Click on logout.")){
			flag=false;
		} 
		Thread.sleep(high);
		
		return flag;  
	}
	
	public static boolean nonAdminLogin() throws Throwable{
		return nonAdminLogin(readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData")));
	}
	
	public static boolean nonAdminLogin(Map<String, String> credMap) throws Throwable{
		boolean flag = true;
		driver.manage().deleteAllCookies();
		driver.navigate().refresh();	
		if(!launchUrl(configProps.getProperty("URL"))){
			flag = false;
		}
		driver.manage().deleteAllCookies();
		driver.navigate().refresh();
		if(!clickOnMainPageLink()){
			flag=false;
		}
		Thread.sleep(medium);
		if(!click(ElsevierObjects.iameducator, "Clicked on Educator")){
			flag = false;
		} 
		
		if(!click(ElsevierObjects.login, "login link")){
			flag = false;
		} 
		if(!type(ElsevierObjects.email,credMap.get("UserName"),"Email")){
			flag = false;
		}
		if(!type(ElsevierObjects.password,credMap.get("Password"), "password")){
			flag = false;
		}
		if(!click(ElsevierObjects.submit, "login submit")){
			flag = false;
		}
		return flag;
	}
	
	public static boolean openNewlyCreatedCourseLink() throws Throwable{
		Map<String, String> userMap = readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData"));
		boolean flag = false;
		
		String xpath = Accessories.fetchDynamicLocator(ElsevierObjects.FacultyContentLink.toString(), ElsevierObjects.ReplaceString1, userMap.get("UserName"));
		if(!click(By.xpath(xpath), "Clicked on content link for the course.")){
			flag = false;
		}
		
		return flag; 
	}
	
}
