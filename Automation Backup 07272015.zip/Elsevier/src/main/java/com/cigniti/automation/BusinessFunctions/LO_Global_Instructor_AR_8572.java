package com.cigniti.automation.BusinessFunctions;

import org.openqa.selenium.By;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class LO_Global_Instructor_AR_8572 extends EvolveCommonBussinessFunctions{

	
	
	
	public boolean click_Request() throws Throwable{
		
		boolean flag=true;
		try
		{
		Thread.sleep(medium);
		if(!click(ElsevierObjects.Educator_RequestProduct_btn,"Click Request button")){
			flag=false;
		}
		
		price=getText(ElsevierObjects.Educator_RequestPage_btn, "price");
 		 expectedPrice="$0.00";
 		  Thread.sleep(high);
 		 if(price.equals(expectedPrice)){
 			if(!click(ElsevierObjects.checkout, "Redeem Checkout")){
 				flag = false;
 		}
	}
		}
 		catch(Exception e)
 		{
 		sgErrMsg=e.getMessage();

 		return false;
		}
 		return flag;

	}
	public static boolean check_Approvedstatus(String trial) throws Throwable {
		 boolean flag=true;
		 try
		 {
		if(trial=="true"){
		trialStatus=getText(ElsevierObjects.Admin_Apprstatus_Trial, "Get status of Trial.");
		if(trialStatus.equals(checkTrialStatus)){
			System.out.println("Trial status matched.");
			}
		}
		 String s1=getText(ElsevierObjects.Admin_Apprstatus_BeforeChk,"Status");
		 Thread.sleep(medium);
		 if(click(ElsevierObjects.Admin_AdoptionSerach_Approve_chk,"Adoption checkbox click")){
			 Reporters.SuccessReport("Clicking On Approved Checkbox.", "Sucessfully Clicked On Approved Checkbox.</br>Status is changed To Approved.Checkbox is disabled.");
	 		}
	 		else{
	 			Reporters.failureReport("Clicking On Approved Checkbox.","Failed To Click On Approved Checkbox." );
	 			
	 		}
		 
		 Thread.sleep(medium);
		 if(click(ElsevierObjects.Admin_Submit_btn,"submit button click")){
			 Reporters.SuccessReport("Clicking On Submit Button After Clicking Checking Approved Checkbox.", "Sucessfully Clicked On Submit Button After Clicking Checking Approved Checkbox..");
	 		}
	 		else{
	 			Reporters.failureReport("Clicking On Submit Button After Clicking Checking Approved Checkbox..","Failed To Click On Submit Button." );
	 		}
		
		 String s2=getText(ElsevierObjects.Admin_Apprstatus_AfterChk,"Status");
		 System.out.println(s2);
		 
		 if(s1!=s2){
			 		if(click(ElsevierObjects.Admin_Fulfil_chk,"Fullfilled checkbox click")){
					Reporters.SuccessReport("Clicking On Fulfilled Checkbox.", "Sucessfully Clicked On Fulfilled Checkbox.</br>Status is changed to Fulfilled. Checkboxes are checked and disabled");
			 		}
			 		else{
			 			Reporters.failureReport("Clicking On Fulfilled Checkbox.","Failed To Click On Fulfilled Checkbox." );
			 			
			 		}
			 		if(click(ElsevierObjects.Admin_Email_chk,"Email checkbox click")){
			 			Reporters.SuccessReport("Clicking On Email Checkbox.", "Sucessfully Clicked On Email Checkbox.");
			 		}
			 		else{
			 			Reporters.failureReport("Clicking On Email Checkbox.","Failed To Click On Email Checkbox." );
			 			
			 		}
			 		if(click(ElsevierObjects.Admin_Submit_btn,"submit button click")){
			 			Reporters.SuccessReport("Clicking On Submit Button After Clicking Checking Fulfill And Email Checkbox.", "Sucessfully Clicked On Submit Button After Clicking Checking Fulfill And Email Checkbox..");
			 		}
			 		else{
			 			Reporters.failureReport("Clicking On Submit Button After Clicking Checking Fulfill And Email Checkbox..","Failed To Click On Submit Button." );
			 		}
		 	Thread.sleep(medium);
		 }
		 }
		 catch(Exception e)

		 {

		 sgErrMsg=e.getMessage();

		 return false;
		 }
			 return flag;
	 }
	
	
	public static boolean EducatorLogin() throws Throwable{
		boolean flag = true;
		try{
	
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			String URL=configProps.getProperty("URL");
			String educatorUsername=ReadingExcel.columnDataByHeaderName("facultyUserName", "TC-15461", configProps.getProperty("TestData"));
			String educatorPassword=ReadingExcel.columnDataByHeaderName("facultyPassword", "TC-15461", configProps.getProperty("TestData"));
			/*String educatorUsername=configProps.getProperty("Faculty_User");
			String educatorPassword=configProps.getProperty("Educator_passWord");*/
			if(launchUrl(URL)){
				Reporters.SuccessReport("Launching The URL.", "Launched The URL:"+URL+" Successfully");
			}
			else{
				Reporters.failureReport("Launching The URL.", "Failed TO Launch The URL:"+URL);
			}
			Thread.sleep(medium);
			if(!clickOnMainPageLink()){
				flag=false;
			}
			if(!click(ElsevierObjects.iameducator, "Clicked on Educator")){
					flag = false;
			} 
			Thread.sleep(medium);
				if(!click(ElsevierObjects.login, "login link")){
					flag = false;
			} 
				if(!type(ElsevierObjects.email,educatorUsername,"Email")){
					flag = false;
			}
				if(!type(ElsevierObjects.password,educatorPassword, "password")){
					flag = false;
			}
				
				if(click(ElsevierObjects.submit, "login submit")){
					Reporters.SuccessReport("Login Into Application As Educator:", "Successfully Entered Username:"+educatorUsername+",Password:"+educatorPassword+"</br>Clicked On Login Button.</br>User Logged Into Application Without Any Issues.");
				}
				else{
					Reporters.failureReport("Login Into Application As Educator:", "Failed To Login Into Application.");
				}
				Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
			return flag;
	
	}
	
	
	public static boolean Admin_searchCourse() throws Throwable{
		boolean flag = true;
		try
		{
		if(!click(ElsevierObjects.lnkevolvecart, "Clicked on Evolve")){
			flag = false;
		}
		if(!type(ElsevierObjects.txtproductsearch,readcolumns.twoColumns(0, 1, "TC-9826 & 8572", configProps.getProperty("TestData")).get("Educatorsearch_Num"), "text to search")){
			flag = false;
		}
		if(!click(ElsevierObjects.gobutton, "search button")){
			flag = false;
		}
		if(!waitForElementPresent(ElsevierObjects.btnaddtocart,"Request this product now")){
			flag = false;
		}
		}
		catch(Exception e)

		{

		sgErrMsg=e.getMessage();

		return false;
		}
		
		return flag;	
	}
	
		public static boolean myCart() throws Throwable{
			boolean flag=true;
			try
			{
			//lmsText=getText(ElsevierObjects.lmsTitle, "Get lms title.");
			Isbn=getText(ElsevierObjects.Student_Product_ISBN,"get isbn number.");
			title=getText(ElsevierObjects.evolve_Rview_chktitle,"Get title of book.");
			myCartPrice=getText(ElsevierObjects.evolve_Product_priceAfterRequest, "Get the product price");
			System.out.println("myCartPrice:"+myCartPrice);
			if(myCartPrice.contains(requestProductPage_Price) && requestProductPage_Title.contains(title) && Isbn.contains(requestProductPage_Isbn)){
				if(click(ElsevierObjects.Educator_Reedemchkout_btn,"Click on Reedeem Checkout button")){
					Reporters.SuccessReport("Verifying Product Details In My Cart Page.</br>Clicking On Redeem/Checkout Button.", "Successfully Verified Price:"+myCartPrice+",Title:"+requestProductPage_Title+",ISBN:"+Isbn+" in Mycart Page.</br>Successfully Clicked On Redeem/Checkout Button.");
				}
				else{
					Reporters.failureReport("Verifying Product Details In My Cart Page.</br>Clicking On Redeem/Checkout Button.", "Failed To Verified Product Details in Mycart Page.</br>Failed To Click On Redeem/Checkout Button.");
				
				} 
				Thread.sleep(medium);
			}
			}
			catch(Exception e)

			{

			sgErrMsg=e.getMessage();

			return false;
			}
			return flag;
		}
	/*public boolean click_Request() throws Throwable{
		
		boolean flag=true;
		Thread.sleep(medium);
		if(!click(ElsevierObjects.Educator_RequestProduct_btn,"Click Request button")){
			flag=false;
		}
		
		price=getText(ElsevierObjects.Educator_RequestPage_btn, "price");
 		 expectedPrice="$0.00";
 		  Thread.sleep(high);
 		 if(price.equals(expectedPrice)){
 			if(!click(ElsevierObjects.checkout, "Redeem Checkout")){
 				flag = false;
 		}
	}
 		return flag;

	}*/
		public static boolean verifyPendingStatus() throws Throwable{
			boolean flag=true;
			String s1=getText(ElsevierObjects.Admin_Apprstatus_BeforeChk,"Status");
			String status=ReadingExcel.columnDataByHeaderName("Status", "SchoolHostedCommonData", testDataPath);
			if(s1.equalsIgnoreCase(status)){
				Reporters.SuccessReport("Verifying Status in Adoption Requests Search Results page", "Successfully Verified Status:"+s1);
			}
			else{
				Reporters.failureReport("Verifying Status in Adoption Requests Search Results page", "Failed To Verify Status:"+s1);
			}
			return flag;
		}
		public static boolean verifyUserDetails(String format_LO) throws Throwable{
			boolean flag=true;
			try{
				if(getAccountDetailsUserName.contains(adoptionRequest_Username) && Isbn.contains(adoptionRequest_Isbn) && adoptionRequest_Format.contains(format_LO)){
					Reporters.SuccessReport("Verifying The User Information In Matches That Of Instructor.", "Verified ISBN:"+adoptionRequest_Isbn+",Username:"+adoptionRequest_Username+",Format:"+adoptionRequest_Format);
				}
				else{
					Reporters.failureReport("Verifying The User Information In Matches That Of Instructor.", "Failed To Verify User Details In Adoption Request Details Page.");
				}
				String changeStatus=ReadingExcel.columnDataByHeaderName("changeStatus", "SchoolHostedCommonData", testDataPath);
				selectByVisibleText(ElsevierObjects.adoptionRequestStatus, changeStatus, "Change status to fullfilled.");
				Thread.sleep(medium);				
				if(click(ElsevierObjects.adoptionRequest_Save,"Click on Save button.")){
					Reporters.SuccessReport("Selecting "+changeStatus+" Status from dropdown.</br>Cilcking On Save Button", "Successfully Selected Status:"+changeStatus+" from Dropdown.</br>Clicked On Save Button.</br>User is shown a pop up regarding if an email should be sent.");
				}
				else{
					Reporters.failureReport("Selecting "+changeStatus+" Status from dropdown.</br>Cilcking On Save Button", "Failed To Change Status from dropdown.</br>Failed To Click On Save Button.");
				}
				final By cancelEmail=By.xpath("//*[@id='cancelemail']");
				if(click(cancelEmail,"Click on Cancel Email button on popup.")){
					Reporters.SuccessReport("Clicking On Cancel Email Button In Email Popup.", "Successfully Clicked On Cancel Email Button in Email Popup.</br>The Page is Refreshed After Send Email Button Is Clicked.");
				}
				else{
					Reporters.failureReport("Clicking On Cancel Email Button In Email Popup.", "Failed To Click On Cancel Email Button In Email Popup.");
				}
			}
			catch(Exception e){
				System.out.println(e.getMessage());
			}
			return flag;
		}
	
	public static boolean admin_Adoptionsearch() throws Throwable{
		   
		boolean flag=true;
		   try{
			   if(click(ElsevierObjects.searchAR,"Adoption Requests")){
			    Reporters.SuccessReport("Clicking On Search Adoption Requests.", "Successfully Clicked On Search Adoption Request Link.");
			   }
			   else{
				   Reporters.failureReport("Clicking On Search Adoption Requests.", "Failed To Click On Search Adoption Request Link.");
			   }
			   if(!waitForElementPresent(ElsevierObjects.btndatesearch, "search button")){
			    flag = false;
			   }
			   Thread.sleep(medium);
			   
			   // This part doesn't seem necessary
			   /*if(click(ElsevierObjects.rbtndate, "date Radio button")){
				   Reporters.SuccessReport("Clicking On Todays Radio Button.", "Successfully Clicked On Todays Radio Button.");
			   }
			   else{
				   Reporters.failureReport("Clicking On Todays Radio Button.", "Failed Clicked On Todays Radio Button.");
			   }
			   Thread.sleep(medium);
				
				if(!click(ElsevierObjects.btndatesearch_AR, "ToDay date Radio button")){
					flag = false;
				}*/
				selectByVisibleText(ElsevierObjects.selectdays, "Today", "Select Today's locator");
				
				// This too
				/*if(!waitForElementPresent(ElsevierObjects.btndatesearch_AR, "search button")){
					flag = false;
				}
				
				Thread.sleep(medium);*/
			
				
			   if(type(ElsevierObjects.Adoption_userId, getAccountDetailsUserName, "Adoption search User Id")){
				   Reporters.SuccessReport("Entering UserID In Search Results Page..", "Successfully Entered UserID:"+getAccountDetailsUserName);
			   }
			   else{
				   Reporters.failureReport("Entering UserID In Search Results Page..", "Failed Enter UserID:"+getAccountDetailsUserName);
			   }
				

			   if(click(ElsevierObjects.Searchon, "search button")){
			    Reporters.SuccessReport("Clicking On Search Button In  Search Adoption Requests Page.", "Successfully Clicked On Search Button In Clicking On Search Button In  Search Adoption Requests Page.</br>Navigated To Adoption Search Results Page.");
			   }
			   else{
				   Reporters.failureReport("Clicking On Search Button In  Search Adoption Requests Page.", "Failed To Click On Search Button In Clicking On Search Button In  Search Adoption Requests Page.");
			   }
			   Thread.sleep(medium);
		   }
		   catch(Exception e){
			   System.out.println(e.getMessage());
		   }
		   return flag;
		 }
	public static boolean educator_courseId_search(String courseId,String courseTitle) throws Throwable {
		 boolean flag=true;
		 try
		 {
		 /*if(!waitForElementPresent(ElsevierObjects.Educator_CourseId_search, "Online couse id")){
			 flag=false;
			 }*/
		String str=getText(ElsevierObjects.Student_CourseId_search, "");
		if(str.contains(courseId)){
			Reporters.SuccessReport("Verifying Course ID In My Evolve Page.", "Successfully Verified CourseID:"+courseId+" In My Evolve Page.");
		 }
		 else{
			 Reporters.failureReport("Verifying Course ID In My Evolve Page.", "Failed To Verify CourseID:"+courseId+" In My Evolve Page.");
		 }
		
		/* if(verifyText(ElsevierObjects.Student_CourseId_search,courseId, "Online couse id")){
			 Reporters.SuccessReport("Verifying Course ID In My Evolve Page.", "Successfully Verified CourseID:"+courseId+" In My Evolve Page.");
		 }
		 else{
			 Reporters.failureReport("Verifying Course ID In My Evolve Page.", "Failed To Verify CourseID:"+courseId+" In My Evolve Page.");
		 }*/
		 Thread.sleep(medium);
		 if(click(ElsevierObjects.Student_CourseId_Click,"click on online course")){
			 Reporters.SuccessReport("Clicking On Course ID Resource Link In My Evolve Page.", "Successfully Clicked On CourseID:"+courseId+" Resource Link In My Evolve Page.</br>Navigated To Resource Page in LO.");
		 }
		 else{
			 Reporters.failureReport("Clicking On Course ID Resource Link In My Evolve Page.", "Failed To Click On CourseID:"+courseId+" Resource Link In My Evolve Page.");
		 }		 Thread.sleep(medium);
		 
		 Thread.sleep(veryhigh);
		
		 if(verifyText(ElsevierObjects.Educator_CourseId_Title,courseTitle, "Online couse Title")){
			 Reporters.SuccessReport("Verifying The Global Course Title in Resources Page.", "Successfully Verified Title:"+courseTitle);
		 }
		 else{
			 Reporters.failureReport("Verifying The Global Course Title in Resources Page.", "Failed To Verify Title:"+courseTitle);
		 }
		 }
		 catch(Exception e)

		 {

		 sgErrMsg=e.getMessage();

		 return false;
		 }
		 return flag;

}

}
