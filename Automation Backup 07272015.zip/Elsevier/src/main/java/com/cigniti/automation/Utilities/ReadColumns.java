package com.cigniti.automation.Utilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReadColumns {

	
	//This method is used for reading two columns as Key,Value and returns them in HASHMAP.... "excelConfig" returns Hashmap 
	public  Map<String, String> twoColumns(int col1,int col2,String sheet,String path) {
		
		ReadingExcel re=new ReadingExcel();
		ArrayList<String> Keys=re.columnData(col1, sheet, path);
		ArrayList<String> values=re.columnData(col2, sheet, path);
		
		Map<String, String> excelConfig = new HashMap<String, String>();
		
		for(int i=0; i<Keys.size(); i++)
		{	
			for(int j=i; j<values.size(); j++)
			{
				excelConfig.put(Keys.get(i), values.get(j));
				break;
			}
		}
		 //System.out.println(excelConfig.size());
		// System.out.println(excelConfig.get("pin"));
		return excelConfig;
		
	}
	
	
public  Map<String, String> twoColumnsBasedOnSheetName(int col1,int col2,String sheetName,String path) {
		
		ReadingExcel re=new ReadingExcel();
		ArrayList<String> Keys=re.columnDataBasedOnSheetName(col1, sheetName, path);
		ArrayList<String> values=re.columnDataBasedOnSheetName(col2, sheetName, path);
		
		Map<String, String> excelConfig = new HashMap<String, String>();
		
		for(int i=0; i<Keys.size(); i++)
		{	
			for(int j=i; j<values.size(); j++)
			{
				excelConfig.put(Keys.get(i), values.get(j));
				break;
			}
		}

		return excelConfig;
		
	}

public  Map<String, String> twoColumnsFroKeys() {
	
	ReadingExcel re=new ReadingExcel();
	ArrayList<String> Keys=re.columnData(0, "TC-10214Copy", "C:\\Users\\IN00893\\Desktop\\EvolveNew21-11-2014\\Elsevier24-11\\TestData\\TestData - Copy.xlsx");
	ArrayList<String> values=re.columnData(1, "TC-10214Copy", "C:\\Users\\IN00893\\Desktop\\EvolveNew21-11-2014\\Elsevier24-11\\TestData\\TestData - Copy.xlsx");
	String dynamic="CreatePackageData";
	Map<String, String> excelConfig = new HashMap<String, String>();
	if(Keys.get(0).equalsIgnoreCase("CreatePackageData")){
	for(int i=0; i<Keys.size(); i++)
	{	
		for(int j=i; j<values.size(); j++)
		{
			excelConfig.put(Keys.get(i), values.get(j));
			break;
		}
	}
	}
	 //System.out.println(excelConfig.size());
	// System.out.println(excelConfig.get("pin"));
	return excelConfig;
	
}


public  Map<String, String> twoColumnsFroKeys(String path,String uniqueName,int uniqueColumnValue,int getColumnValue, String sheetName) {
	 List<String> getValue = new ArrayList<String>();
	 ArrayList<String> Keys=new ArrayList<String>();
	 Map<String, String> excelConfig = new HashMap<String, String>();
		ReadingExcel re=new ReadingExcel();
		List<String> key=re.columnData(0, sheetName, path);
		ArrayList<String> values=re.columnData(1, sheetName, path);
		for (int i = 0; i < key.size(); i++) {
			if(key.get(i).equalsIgnoreCase(uniqueName)){
				for (int j = i; j < values.size(); j++) {
					if(key.get(j).equalsIgnoreCase(uniqueName)){
					excelConfig.put(key.get(i), values.get(j));
					String excel=excelConfig.put(key.get(i), values.get(j)).toString();
					Keys.add(excel);
					//System.out.println(excel);
				}
				}
				break;
			}
		}
		ArrayList<String> values1=re.columnData(2, sheetName, path);
		for(int i=0; i<Keys.size(); i++)
		{	
			for(int j=i; j<values1.size(); j++)
			{
				excelConfig.put(Keys.get(i), values1.get(j));
				break;
			}
		}
		return excelConfig;
	}


	
}
