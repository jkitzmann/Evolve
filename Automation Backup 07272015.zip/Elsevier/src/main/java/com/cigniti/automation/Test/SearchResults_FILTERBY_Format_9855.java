package com.cigniti.automation.Test;

import java.util.Random;

import jxl.Sheet;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class SearchResults_FILTERBY_Format_9855 extends User_BusinessFunction {
	
	//**************************** Declarations *****************************************************
 	public static Sheet inputSheetObj =null;
	Random ra = new Random( System.currentTimeMillis() );
	@Test
	public void SearchResults_FILTERBY_Format() throws Throwable

	{
//try	
	{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());

	   writeReport(SwitchToBrowser(ElsevierObjects.studentBrowserType),"Launching Browser to Portal User","Launching Browser to Portal User is succesful","Lanching Browser to Portal User is failed");

		//String Catalogs=ReadingExcel.columnDataByHeaderName( "SearchElements", "TC-9812",configProps.getProperty("TestData"));		
		String Catalogs=ReadingExcel.columnDataByHeaderName( "SearchElement", "TC-9855",configProps.getProperty("TestData"));
		String ProductType=ReadingExcel.columnDataByHeaderName( "ProductType", "TC-9855",configProps.getProperty("TestData"));
		String Input1=ReadingExcel.columnDataByHeaderName( "Input1", "TC-9855",configProps.getProperty("TestData"));
		String Input2=ReadingExcel.columnDataByHeaderName( "Input2", "TC-9855",configProps.getProperty("TestData"));
		String Input3=ReadingExcel.columnDataByHeaderName( "Input3", "TC-9855",configProps.getProperty("TestData"));
		
		String Value1=ReadingExcel.columnDataByHeaderName( "Value1", "TC-9855",configProps.getProperty("TestData"));
		String Value2=ReadingExcel.columnDataByHeaderName( "Value2", "TC-9855",configProps.getProperty("TestData"));
		String Value3=ReadingExcel.columnDataByHeaderName( "Value3", "TC-9855",configProps.getProperty("TestData"));
		exlu_formatby=Catalogs;
		System.out.println(Catalogs);
		
		
        System.out.println("*********************************Login As Faculty****************************");


       writeReport(User_BusinessFunction.Educatorlogin(sEducatorUser, sEducatorPassword),"Login to Application Using Educator Credentials"+sEducatorUser,
                                                       "Launching the URL for Educator is successful </br > Login to Application Using Educator credentails :"+sEducatorUser+" is Successful",
                                                       "Launching and Login to Application Using Educator credentails : "+ sEducatorUser+" is Failed");
       if(!click(ElsevierObjects.Myevolve,"Click on my evolve"))
		{
			flag=false;
		}
       writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as:"+sStudentUser,
                "Navigating to CATALOG page is Successful",
                "Navigating to CATALOG Page is failed");

       writeReport(User_BusinessFunction.HESI_Search(Catalogs),"Searching for Value:"+Catalogs,
                  "Entered "+Catalogs+" to Search </br > Click on Go Button",
                  "Unable to Search for : "+ Catalogs);
       Thread.sleep(3000);	

       writeReport((isChecked(ElsevierObjects.Selecallfilterbyformat,"Checking Select All")),"Verifying Select All option is Selected by Default","Search results screen is displayed with default FILTER BY FORMAT TYPE 'Select All'"
       		+ "  radio button selected","Search results screen is displayed with default FILTER BY PRODUCT TYPE 'Select All ' radio button is not selected");
       Thread.sleep(3000);	
        writeReport((isChecked(ElsevierObjects.Selecallfilterbyproducttype,"Checking All Products Link")),"Verifying 'All Products'  option is Selected by Default","Search results screen is displayed with default FILTER BY PRODUCT TYPE 'All Products' radio button selected","Search results screen is displayed with default FILTER BY PRODUCT TYPE 'All Products' radio button is not selected");
		
        
        writeReport(User_BusinessFunction.ClickonFilterByProudctType(ProductType),"Click on More Link is Successful </br> Clicking on Product Type :"+ProductType+" Under Filter By Product Type",
               "Clicking On Product Type :"+ProductType+" Under Filter By Product Type is Successful",
               "Clicking On Product Type :"+ProductType+" Under Filter By Product Type is not Successful");
		
       System.out.println("*********************************Verifying All the Results with No Selection****************************");
       Thread.sleep(3000);	
       
       writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value1),"Verifying Title Values: "+Value1+" Present in Results",
               "The Acutal Value from  Application is : "+sActualValues+", is Present in the results",
               "The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the results");
       Thread.sleep(3000);	

       writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value2),"Verifying Title Values: "+Value2+" Present in Results",
               "The Acutal Value from  Application is : "+sActualValues+", is Present in the results",
               "The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the results");

       writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value3),"Verifying Title Values: "+Value3+" Present in Results",
               "The Acutal Value from  Application is : "+sActualValues+", is Present in the results",
               "The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the results");
       Thread.sleep(3000);	

       System.out.println("*********************************Verifying All with only Input1 Selection ****************************");
       writeReport(User_BusinessFunction.clickonMorelink(),"Click on More Link is Successful","Click on More Link is Successful","Click on More Link is NOT Successful");
       writeReport(User_BusinessFunction.ClickonFilterByFormatType(Input1,"Check"),"Click on Format Type :"+Input1+" Under Filter By Product Type",
                                                                            "Clicking On Format Type :"+Input1+" Under Filter By Format  is Successful",
                                                                            "Clicking On Format Type :"+Input1+" Under Filter By Format  is not Successful");
       Thread.sleep(5000);	

       writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value2),"Verifying Title Values: "+Value2+" Present in Results",
                                                                           "The Acutal Value from  Application is : "+sActualValues+", is Present in the results",
                                                                           "The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the results");
       
       writeReport(!User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value1),"Verifying Title Values: "+Value1+" NOT Present in Results",
               "The Acutal Value from  Application is : "+sActualValues+", is NOT Present in the results",
               "The Acutal Value from  Application is : "+sActualValues+" ,is Present in the results,Hence Test is failed");

       writeReport(!User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value3),"Verifying Title Values: "+Value3+" NOT Present in Results",
               "The Acutal Value from  Application is : "+sActualValues+", is NOT Present in the results",
               "The Acutal Value from  Application is : "+sActualValues+" ,is  Present in the results, Hence Test is failed");

       Thread.sleep(3000);	
       
       writeReport(User_BusinessFunction.ClickonFilterByFormatType(Input1,"UnCheck"),"Uncheck the Format Type :"+Input1+" Under Filter By Format",
                                                                             "Format Type :"+Input1+" Under Filter By Format is Unchecked Successful",
                                                                             "Format Type :"+Input1+" Under Filter By Format is not Unchecked Successful");
       Thread.sleep(3000);	
        
       writeReport((isChecked(ElsevierObjects.Selecallfilterbyformat,"Checking Select All")),"Verifying Select All option is Selected by Default","Search results screen is displayed with default FILTER BY PRODUCT TYPE 'All Products' radio button selected","Search results screen is displayed with default FILTER BY PRODUCT TYPE 'All Products' radio button is not selected");

        Thread.sleep(3000);	

        
        
        System.out.println("*********************************Verifying All with only Input2 Selection ****************************");
        
        writeReport(User_BusinessFunction.ClickonFilterByFormatType(Input2,"Check"),"Click on Format Type :"+Input2+" Under Filter By Product Type",
                "Clicking On Format Type :"+Input2+" Under Filter By Format  is Successful",
                "Clicking On Format Type :"+Input2+" Under Filter By Format  is not Successful");
        Thread.sleep(3000);	

        
        writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value2),"Verifying Title Values: "+Value2+" Present in Results",
                "The Acutal Value from  Application is : "+sActualValues+", is Present in the results",
                "The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the results");

        Thread.sleep(3000);	


        writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value3),"Verifying Title Values: "+Value3+" Present in Results",
                "The Acutal Value from  Application is : "+sActualValues+", is Present in the results",
                "The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the results");
        Thread.sleep(3000);	


        writeReport(!User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value1),"Verifying Title Values: "+Value1+" NOT Present in Results",
                "The Acutal Value from  Application is : "+sActualValues+", is NOT Present in the results",
                "The Acutal Value from  Application is : "+sActualValues+" ,is  Present in the results, Hence Test is failed");
        Thread.sleep(3000);	

        writeReport(User_BusinessFunction.ClickonFilterByFormatType(Input2,"UnCheck"),"Uncheck the Format Type :"+Input1+" Under Filter By Format",
                "Format Type :"+Input2+" Under Filter By Format is Unchecked Successful",
                "Format Type :"+Input2+" Under Filter By Format is not Unchecked Successful");
        Thread.sleep(3000);	
        
        
        writeReport((isChecked(ElsevierObjects.Selecallfilterbyformat,"Checking Select All")),"Verifying Select All option is Selected by Default","Search results screen is displayed with default FILTER BY PRODUCT TYPE 'All Products' radio button selected","Search results screen is displayed with default FILTER BY PRODUCT TYPE 'All Products' radio button is not selected");
        Thread.sleep(3000);	
 
        System.out.println("*********************************Verifying All with only Input2 and Input3 Selection ****************************");

        writeReport(User_BusinessFunction.ClickonFilterByFormatType(Input2,"Check"),"Click on Format Type :"+Input2+" Under Filter By Product Type",
                "Clicking On Format Type :"+Input2+" Under Filter By Format  is Successful",
                "Clicking On Format Type :"+Input2+" Under Filter By Format  is not Successful");
        Thread.sleep(3000);	


        writeReport(User_BusinessFunction.ClickonFilterByFormatType(Input3,"Check"),"Click on Format Type :"+Input3+" Under Filter By Product Type",
                "Clicking On Format Type :"+Input3+" Under Filter By Format  is Successful",
                "Clicking On Format Type :"+Input3+" Under Filter By Format  is not Successful");
        Thread.sleep(3000);	

        writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value1),"Verifying Title Values: "+Value1+" Present in Results",
                "The Acutal Value from  Application is : "+sActualValues+", is Present in the results",
                "The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the results");

        writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value2),"Verifying Title Values: "+Value2+" Present in Results",
                "The Acutal Value from  Application is : "+sActualValues+", is Present in the results",
                "The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the results");

        writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value3),"Verifying Title Values: "+Value3+" Present in Results",
                "The Acutal Value from  Application is : "+sActualValues+", is Present in the results",
                "The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the results");
        Thread.sleep(3000);	

        writeReport(User_BusinessFunction.ClickonFilterByFormatType(Input3,"UnCheck"),"Uncheck the Format Type :"+Input3+" Under Filter By Format",
                "Format Type :"+Input3+" Under Filter By Format is Unchecked Successful",
                "Format Type :"+Input3+" Under Filter By Format is not Unchecked Successful");
        Thread.sleep(3000);	
        
        System.out.println("*********************************Verifying All with only Input2 value by deselecting Input3 Selection ****************************");
        
        writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value2),"Verifying Title Values: "+Value2+" Present in Results",
                "The Acutal Value from  Application is : "+sActualValues+", is Present in the results",
                "The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the results");

        writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value3),"Verifying Title Values: "+Value3+" Present in Results",
                "The Acutal Value from  Application is : "+sActualValues+", is Present in the results",
                "The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the results");

        writeReport(!User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value1),"Verifying Title Values: "+Value1+" NOT Present in Results",
                "The Acutal Value from  Application is : "+sActualValues+", is NOT Present in the results",
                "The Acutal Value from  Application is : "+sActualValues+" ,is Present in the results,Hence Test is failed");

        System.out.println("*********************************Verifying Deselecting Input3 and Selecting Input 1 Selection ****************************");
        writeReport(User_BusinessFunction.ClickonFilterByFormatType(Input2,"UnCheck"),"Uncheck the Format Type :"+Input2+" Under Filter By Format",
                "Format Type :"+Input2+" Under Filter By Format is Unchecked Successful",
                "Format Type :"+Input2+" Under Filter By Format is not Unchecked Successful");
        Thread.sleep(3000);	
        writeReport(User_BusinessFunction.clickonMorelink(),"Click on More Link is Successful","Click on More Link is Successful","Click on More Link is NOT Successful");
        writeReport(User_BusinessFunction.ClickonFilterByFormatType(Input1,"Check"),"Click on Format Type :"+Input1+" Under Filter By Product Type",
                "Clicking On Format Type :"+Input1+" Under Filter By Format  is Successful",
                "Clicking On Format Type :"+Input1+" Under Filter By Format  is not Successful");
        Thread.sleep(3000);	


        writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value2),"Verifying Title Values: "+Value2+" Present in Results",
                "The Acutal Value from  Application is : "+sActualValues+", is Present in the results",
                "The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the results");

        writeReport(!User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value1),"Verifying Title Values: "+Value1+" NOT Present in Results",
                 "The Acutal Value from  Application is : "+sActualValues+", is NOT Present in the results",
                 "The Acutal Value from  Application is : "+sActualValues+" ,is Present in the results,Hence Test is failed");

        writeReport(!User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,Value3),"Verifying Title Values: "+Value3+" NOT Present in Results",
                                                                                               "The Acutal Value from  Application is : "+sActualValues+", is NOT Present in the results",
                                                                                               "The Acutal Value from  Application is : "+sActualValues+" ,is  Present in the results, Hence Test is failed");
        Thread.sleep(3000);	

 
	
		
}
	/**catch(Exception e){  boolean test1=false; writeReport(test1,"Test Got failed due to:"+e,
                     "No Results",
        "The Test Case Failed due to This exception:"+e);******/
}

	@AfterTest
	public void tear() throws Throwable{
	 //HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}

	

