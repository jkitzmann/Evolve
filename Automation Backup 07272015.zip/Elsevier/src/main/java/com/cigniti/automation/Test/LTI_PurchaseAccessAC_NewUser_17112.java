package com.cigniti.automation.Test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import com.cigniti.automation.BusinessFunctions.LTI_BusinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class LTI_PurchaseAccessAC_NewUser_17112 extends LTI_BusinessFunctions{
	
	@Test
	public static void LTI_PurchaseAccessAC_NewUser_17112_Script() throws Throwable {
		
		// login to d2l as admin
		stepReport("Login to D2L as admin user");
		String username = ReadingExcel.columnDataByHeaderName("D2L_AdminUser", "LTITestCases", configProps.getProperty("TestData"));
		String password = ReadingExcel.columnDataByHeaderName("D2L_AdminPass", "LTITestCases", configProps.getProperty("TestData"));
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		writeReport(d2l_Login(username, password), "Login to D2L as admin user",
				"Successfully logged into D2L as admin",
				"Failed to login to D2L as admin");
		
		// create a new course
		stepReport("Create a new course");
		writeReport(adminCreateNewCourse(), "Create a new course in D2L",
				"Successfully created a new course in D2L",
				"Failed to create a new course in D2L");
		
		// login to evolve as portal admin
		stepReport("Login to Evolve as portal administrator");
		writeReport(existingUserLogin("educator", configProps.getProperty("ecertAdminUserID"), configProps.getProperty("ecertAdminPassword")),
				"Login to Evolve as portal admin",
				"Successfully logged into Evolve as portal admin",
				"Failed to login to Evolve as portal admin");
		
		// create new integration connector
		stepReport("Create a new integration connector in Evolve portal admin");
		writeReport(createNewIntegrationConnector(), "Create new integration connector",
				"Successfully created new integration connector",
				"Failed to create new integration connector");
		
		// add the new integration to an existing course
		stepReport("Add the new integration to an existing course");
		writeReport(addIntegrationToCourse(), "Add integration to existing course",
				"Successfully added new integration to existing course",
				"Failed to add new integration to existing course");
		
		// get the LTI url and protection scheme
		stepReport("Get the LTI URL and protection scheme of the assessment");
		String courseID = ReadingExcel.columnDataByHeaderName("ExistingCourseID", "LTITestCases", configProps.getProperty("TestData"));
		String module = ReadingExcel.columnDataByHeaderName("EvolveModule", "LTITestCases", configProps.getProperty("TestData"));
		String assessment = ReadingExcel.columnDataByHeaderName("EvolveAssessment", "LTITestCases", configProps.getProperty("TestData"));
		writeReport(getURLandScheme(courseID, module, assessment), "Get the LTI URL and protection scheme of the assessment",
				"Successfully retrieved the URL and protection scheme for the following assessment...</br>" +
				"Course ID: " + courseID + "</br>" +
				"Module: " + module + "</br>" +
				"Assessment: " + assessment,
				"Failed to retrieve the URL and protection scheme for the following assessment...</br>" +
				"Course ID: " + courseID + "</br>" +
				"Module: " + module + "</br>" +
				"Assessment: " + assessment);
		
		// login to d2l as admin
		stepReport("Login to D2L as admin user");
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		writeReport(d2l_Login(username, password), "Login to D2L as admin user",
				"Successfully logged into D2L as admin",
				"Failed to login to D2L as admin");
		
		// add the link to the d2l course
		stepReport("Add link to course in D2L");
		String courseName = ReadingExcel.columnDataByHeaderName("CourseName", "LTITestCases", configProps.getProperty("TestData"));
		String secretKey = ReadingExcel.columnDataByHeaderName("SecretKey", "LTITestCases", configProps.getProperty("TestData"));
		String connectorID = ReadingExcel.columnDataByHeaderName("CourseName", "LTITestCases", configProps.getProperty("TestData")) + "@evolveqa.info";
		String assessmentLink = ReadingExcel.columnDataByHeaderName("AssessmentLink", "LTITestCases", configProps.getProperty("TestData"));
		String prefix = "AutoModule-";
		writeReport(addLinkToD2LCourse(prefix, courseName, secretKey, connectorID, assessmentLink), "Add link to course in D2L",
				"Successfully added link to course...</br>" +
				"Course: " + courseName + "</br>" +
				"Link: " + assessmentLink + "</br>" +
				"Key: " + secretKey + "</br>" +
				"Connector ID: " + connectorID,
				"Failed to add link to course...</br>" +
				"Course: " + courseName + "</br>" +
				"Link: " + assessmentLink + "</br>" +
				"Key: " + secretKey + "</br>" +
				"Connector ID: " + connectorID);
		
		// add new student to classlist
		stepReport("Add new student to classlist");
		Random ra = new Random( System.currentTimeMillis() );
		Date today = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat ("MMddyyyy");
		String number = Integer.toString((1 + ra.nextInt(2)) * 100 + ra.nextInt(100));
		String newFirstName = "First_" + number + "_" + sdf.format(today);
		String newLastName = "Last_" + number + "_" + sdf.format(today);
		String newPass = ReadingExcel.columnDataByHeaderName("NewUserPass", "LTITestCases", configProps.getProperty("TestData"));
		String newRole = ReadingExcel.columnDataByHeaderName("Role", "LTITestCases", configProps.getProperty("TestData"));
		
		String newUserID = "LTIauto_" + number + "_" + sdf.format(today);
		String newEmail = newUserID + "@evolveqa.info";
		writeReport(addUserToClasslist(courseName, newFirstName, newLastName, newUserID, newEmail, newRole, newPass), "Add new student to classlist",
				"Successfully added new student to classlist...</br>" +
				"Course: " + courseName + "</br>" +
				"First Name: " + newFirstName + "</br>" +
				"Last Name: " + newLastName + "</br>" +
				"User ID: " + newUserID + "</br>" +
				"Password: " + newPass + "</br>" +
				"Email: " + newEmail + "</br>" +
				"Role: " + newRole,
				"Failed to add new student to classlist...</br>" +
				"Course: " + courseName + "</br>" +
				"User ID: " + newUserID + "</br>" +
				"Password: " + newPass + "</br>" +
				"First Name: " + newFirstName + "</br>" +
				"Last Name: " + newLastName + "</br>" +
				"Email: " + newEmail + "</br>" +
				"Role: " + newRole);
		
		// verify student appears in classlist
		stepReport("Verify the new student appears in the classlist");
		writeReport(verifyClasslist(courseName, newFirstName, newLastName, newEmail, newRole), "Add new student to classlist",
				"Successfully added new student to classlist...</br>" +
				"Course: " + courseName + "</br>" +
				"First Name: " + newFirstName + "</br>" +
				"Last Name: " + newLastName + "</br>" +
				"Email: " + newEmail + "</br>" +
				"Role: " + newRole,
				"Failed to add new student to classlist...</br>" +
				"Course: " + courseName + "</br>" +
				"First Name: " + newFirstName + "</br>" +
				"Last Name: " + newLastName + "</br>" +
				"Email: " + newEmail + "</br>" +
				"Role: " + newRole);
		
		// logout of d2l
		stepReport("Log out of D2L");
		writeReport(d2l_Logout(), "Logout of D2L", "Successfully logged out of D2L", "Failed to log out of D2L");
		
		// login to evolve admin
		stepReport("Login to Evolve Admin");
		writeReport(evolveAdminlogin(), "Login to Evolve Admin",
				"Successfully logged in as user: " + adminUser,
				"Failed to log in as user: " + adminUser);
		
		// navigate to maintain product screen for the isbn
		stepReport("Go to product details");
		String isbn = ReadingExcel.columnDataByHeaderName("ISBN", "LTITestCases", configProps.getProperty("TestData"));
		writeReport(maintainProduct(isbn), "Go to product details",
				"Successfully navigated to product details for ISBN: " + isbn,
				"Failed to navigate to product details for ISBN: " + isbn);
		
		// create new access code
		stepReport("Create a new access code");
		String scheme = ReadingExcel.columnDataByHeaderName("ProtectionScheme", "LTITestCases", configProps.getProperty("TestData"));
		writeReport(createAccessCode(scheme), "Create a new access code",
				"Successfully created a new access code for ISBN: " + isbn,
				"Failed to create a new access code for ISBN: " + isbn);
		
		// log out of evolve admin
		stepReport("Log out of Evolve Admin");
		writeReport(adminLogout(), "Log out of Evolve Admin",
				"Successfully logged out of Evolve Admin",
				"Failed to log out of Evolve Admin");
		
		// login to d2l as the new student
		stepReport("Login to D2L as the new student");
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		writeReport(d2l_Login(newFirstName + "." + newLastName, newPass), "Login to D2L as new student",
				"Successfully logged in as user: " + newFirstName + "." + newLastName,
				"Failed to log in as user: " + newFirstName + "." + newLastName);
		
		// verify student can open course
		stepReport("Open the course as the student");
		writeReport(studentVerifyCourse(courseName), "Open course as student",
				"Successfully verified course: " + courseName,
				"Unable to verify course: " + courseName);
		
		// submit access code for the content
		stepReport("Submit the access code for the protected content");
		writeReport(submitAccessCode(), "Submit access code for the protected content",
				"Successfully submitted access code and verified content",
				"Failed to submit access code and verify content");
		
		// logout of d2l
		stepReport("Log out of D2L");
		writeReport(d2l_Logout(), "Logout of D2L", "Successfully logged out of D2L", "Failed to log out of D2L");
		
		// relogin as student
		stepReport("Relogin to D2L as the new student");
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		writeReport(d2l_Login(newFirstName + "." + newLastName, newPass), "Login to D2L as new student",
				"Successfully logged in as user: " + newFirstName + "." + newLastName,
				"Failed to log in as user: " + newFirstName + "." + newLastName);
		
		// open the course
		stepReport("Open the course as the student");
		writeReport(studentVerifyCourse(courseName), "Open course as student",
				"Successfully verified course: " + courseName,
				"Unable to verify course: " + courseName);
		
		// verify student's access remains
		stepReport("Verify student still has access to protected content");
		writeReport(reverifyStudentAccess(), "Verify access to protected content remains",
				"Verified student still has access to protected content",
				"Student is no longer able to access protected content");
				
	}
	
	@AfterTest
	public void tear() throws Throwable{
		
	}

}
