package com.cigniti.automation.BusinessFunctions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;


public class Z_LO_SelfEnrollLOAccessCodeThroughCart_15585 extends EvolveCommonBussinessFunctions{
		
	//Click on the Access Code Package link and verify	
	public static String ISBNPkg;
	public static boolean selfEnrollLO() throws Throwable{
		boolean flag = true;
		Thread.sleep(medium);
		driver.manage().deleteAllCookies();
		if(!launchUrl(configProps.getProperty("URL"))){
			flag = false;
		}
		driver.manage().deleteAllCookies();
		driver.navigate().refresh();
		Thread.sleep(medium);
		if(!click(ElsevierObjects.home_student_lnkstudent,"i am student")){
			 flag=false;
		}
		
		return flag;
	}
	
	public static boolean verifySearchNumber() throws Throwable{
		boolean flag = true;
		ISBNPkg="";
		ReadingExcel re =new ReadingExcel();
		ISBNPkg =re.columnDataByHeaderName("searchNumber", "TC-10410", configProps.getProperty("TestData"));
		
		if(ISBNPkg == ""){
			Thread.sleep(medium);
			flag = false;
		}
		
		return flag;
	}
	
	public static boolean verifySelfEnrollNavigate(String courseid, String isbn, String title) throws Throwable{
		boolean flag = true;
		String s="";
		
		if(!type(ElsevierObjects.enrollResourceId, courseid, "Input Course Id ")){
			Thread.sleep(medium);
			flag = false;
		}
		
		if(!click(ElsevierObjects.enrollContinue, "Click on Continue Button")){
			flag = false;
		}
		Thread.sleep(medium);
		
				
		//if(!isElementPresent(ElsevierObjects.txtmycart,"")){
		//	Thread.sleep(medium);
		//	flag = false;
		//}
		
		//if(isElementPresent(ElsevierObjects.isbnText,"")){
		//	s=getText(ElsevierObjects.isbnText, "");
		//	if(!(s.contains(isbn))){
		//		flag = false;
		//	}
		//	Thread.sleep(medium);
		//} else {
		//	Thread.sleep(medium);
		//	flag = false;
		//}
		
		if(!(driver.getPageSource()).contains(courseid)){
			Thread.sleep(medium);
			flag=false;
		}
		
		Thread.sleep(500);
		
		if(!(driver.getPageSource()).contains(isbn)){
			Thread.sleep(medium);
			flag=false;
		}
		
		//if(!verifyTextPresent(title)){
		//	Thread.sleep(medium);
		//	flag=false;
		//}
		
		//if(!waitForTitlePresent(ElsevierObjects.enrollTitle)){
		//	s=getText(ElsevierObjects.enrollTitle, "");
		//	if(!(s.contains(title))){
		//		flag = false;
		//	}
		//	Thread.sleep(medium);
		//} else {
		//	Thread.sleep(medium);
		//	flag = false;
		//}		
		return flag;
	}
	
	public static boolean verifyCheckout() throws Throwable{
		boolean flag=true;
		
		if(!click(ElsevierObjects.btnRedeem,"Click on My Cart checkout Button")){
			flag=false;
		}
		Thread.sleep(medium);

		return flag;
	}
	
	public static boolean verifyMyEvolveCourseId() throws Throwable{
		boolean flag=true;
		
		if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
			flag=false;
		}
		Thread.sleep(high);
		
		if(!click(ElsevierObjects.Kno_refresh_lnk,"Click on refresh content list")){
			flag=false;
		}
		Thread.sleep(medium);
		
		
		if(!click(ElsevierObjects.educator_courseSearch_title,"Click on COurse Title.")){
			flag=false;
		}
		Thread.sleep(medium);

		return flag;
	}
	
	public static boolean verifyCoursePage() throws Throwable{
		boolean flag=true;
		
		//click on course content list in course page
		if(!click(ElsevierObjects.educator_CoursePage_Courselink, "Click on course link present in course details page.")){
			flag=false;
		}
		Thread.sleep(medium);
		
		
		//check for subfolders
		if(!waitForElementPresent(ElsevierObjects.educator_CoursePage_SubFolders, "Course folder contains sub folders.")){
					flag=false;
				}
				Thread.sleep(medium);

				return flag;
	}
	
	public static boolean verifyMyEvolveAdmin(String courseid) throws Throwable{
		boolean flag=true;
		
		//click on My evolve link 
		if(!click(ElsevierObjects.Admin_Evolve_lnk, "Click on Evolve Admin link")){
			flag = false;
		}
		Thread.sleep(medium);
		
		//click on View Edit User Profile link 
		if(!click(ElsevierObjects.Admin_ViewEdit_UserProfile, "Click on View/Edit Evolve User PRofile")){
			flag = false;
		}
		Thread.sleep(medium);
		
		
		Map<String, String> values=readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData"));
		String userName=values.get("UserName");
		if(!type(ElsevierObjects.Admin_SearchUser_UserName, userName, "Input UserNamed ")){
			Thread.sleep(medium);
			flag = false;
		}
		Thread.sleep(medium);
		
		if(!click(ElsevierObjects.Admin_SearchUser_SearchButton, "Click on Search Button")){
			flag = false;
		}
		Thread.sleep(medium);
		
		if(!click(ElsevierObjects.Admin_CourseParReport_Search_Results_Row2, "Click on Search Results")){
			flag = false;
		}
		Thread.sleep(medium);
		if(!click(ElsevierObjects.parBtn, "Click on Search Results")){
			flag = false;
		}
		Thread.sleep(medium);
		
		//check for courseid
		if(!selectByVisibleText(ElsevierObjects.enrollCourseId,courseid ,"Check Course id Exists")){
					flag=false;
				}
				Thread.sleep(medium);

				return flag;
	}
	
	
	public static boolean verifyMaintainProduct(String isbn) throws Throwable{
		boolean flag = true;
		
		if(!maintainProductLink(isbn)){
			flag=false;
		}
		Thread.sleep(medium);
		if(!click(ElsevierObjects.MaintainPrdct_prdctSerachReslut_isbn,"Click on isbn num in product result page")){
			flag=false;
		}
		Thread.sleep(medium);
		return flag;
	}
	

	public static boolean  verifyTextPresent(String text) throws Throwable{  
		boolean flag=false;
		String bool=configProps.getProperty("OnSuccessReports");
		boolean b=Boolean.parseBoolean(bool);
		if(!(driver.getPageSource()).contains(text))
		{
		
			Reporters.SuccessReport("VerifyTextPresent",text+" is not present in the page");
			flag= true;
		}
		else if(b && flag)
		{
			Reporters.failureReport("VerifyTextPresent",text+" is present in the page");
			flag= false;
			
		}
		return flag;
	}

}
