package com.cigniti.automation.Test;

import java.util.Random;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.PromotionRedeemSinglePercentageOff_10229;
import com.cigniti.automation.BusinessFunctions.Promotion_CreatePromotionMarketingPageSinglePercentage_15582;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;

public class PromotionRedeemVariablePercentageOff_Script_10230 extends EvolveCommonBussinessFunctions{
	public static String DMCode;
	
	Random ra = new Random(System.currentTimeMillis() );
	@Test
	public void promotionRedeemVariablePercentageOff_10230() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String DMCode=ReadingExcel.columnDataByHeaderName("DMcode", "PromotionTestData",testDataPath)+Integer.toString((1 + ra.nextInt(2)) * 100000 + ra.nextInt(100000));
			String PromotionCode=ReadingExcel.columnDataByHeaderName("PromotionCode", "PromotionTestData",testDataPath);
			String DiscountType2=ReadingExcel.columnDataByHeaderName("DiscountType2", "PromotionTestData",testDataPath);
			String CampaignCode=ReadingExcel.columnDataByHeaderName("CampaignCode", "PromotionTestData",testDataPath);
			String PromotionName=ReadingExcel.columnDataByHeaderName("PromotionName", "PromotionTestData",testDataPath);
			String TerritoryCode=ReadingExcel.columnDataByHeaderName("TerritoryCode", "PromotionTestData",testDataPath);
			String percentageOff=ReadingExcel.columnDataByHeaderName("PercentageOff", "PromotionTestData",testDataPath);
			String percentageOff1=ReadingExcel.columnDataByHeaderName("PercentageOff1", "PromotionTestData",testDataPath);
			String invalidPercentage=ReadingExcel.columnDataByHeaderName("invalidPercentage", "PromotionTestData",testDataPath);
			String percentage=ReadingExcel.columnDataByHeaderName("percentage", "PromotionTestData",testDataPath);		
			String healthNursing=ReadingExcel.columnDataByHeaderName("SearchProduct", "PromotionTestData", testDataPath);
			String percentageCDROM=ReadingExcel.columnDataByHeaderName("percentageCDROM", "TC-15582", testDataPath);
			String variablePercentage=ReadingExcel.columnDataByHeaderName("variablePercentage", "PromotionTestData", testDataPath);
			
			String shippingAdress=ReadingExcel.columnDataByHeaderName("student_StreetAdress", "PromotionTestData",configProps.getProperty("TestData"));
			String shippingCity=ReadingExcel.columnDataByHeaderName("student_City", "PromotionTestData",configProps.getProperty("TestData"));
			String shippingState=ReadingExcel.columnDataByHeaderName("student_State", "PromotionTestData",configProps.getProperty("TestData"));
			String shippingZip=ReadingExcel.columnDataByHeaderName("student_ZipCode", "PromotionTestData",configProps.getProperty("TestData"));
		
			/*String username=configProps.getProperty("userNamePromotionRedeem");
			String password=configProps.getProperty("passwordPromotionRedeem");
			writeReport(User_BusinessFunction.Studentlogin(username, password),"Login to Application Using Student User Credentials : "+username,
                    "Launching the URL for Student User is successful </br > Login to Application Using Student User credentails :"+username+" is Successful",
                       "Launching and Login to Application Using Student User credentails : "+ username+" is Failed");
				Thread.sleep(medium);*/
				
			writeReport(User_BusinessFunction.Studentlogin(sStudentUser, sStudentPassword),"Login to Application Using Student User Credentials : "+sStudentUser,
	                    "Launching the URL for Student User is successful </br > Login to Application Using Student User credentails :"+sStudentUser+" is Successful",
	                       "Launching and Login to Application Using Student User credentails : "+ sStudentUser+" is Failed");
				
			writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as:"+sStudentUser,
                    "Navigating to CATALOG page is Successful",
                    "Navigating to CATALOG Page is failed");
			Thread.sleep(medium);
			writeReport(productSearch(healthNursing),"Searching for Value:"+healthNursing,
                      "Search for "+healthNursing+" is successfully verified ",
                      "Unable to Search for : "+ healthNursing+ " search results failed");
			Thread.sleep(medium);
			writeReport(clickDVDHardcover(),"Filter by DVD and Hardcover Product Types",
            "Successfully Clicked on the DVD Product type and HardCover product type Checkboxes ",
            "Unable to Click on the DVD Product type and HardCover product type Checkboxes  ");
		
			productClick();
			Thread.sleep(medium);
			
			writeReport(instructorLogout(),"Log out of Evolve student account.","Successfully logged out of Evolve student account.","Failed to logout of Evolve student account.");
			
			//SwitchToBrowser(ElsevierObjects.adminBrowserType);
			writeReport(evolveAdminlogin(),"Login to Application Using User Credentials"+adminUser,
                    "Launching the URL for User is successful </br > Login to Application Using User credentails :"+adminUser+" is Successful",
                       "Launching and Login to Application Using User credentails : "+ adminUser+" is Failed");
			
			Thread.sleep(medium);
			writeReport(checkPromotionLink(),"Click on the 'Global Promotion Exclusions' under the 'Promotion Management' Section",
                    "Global Promotion Exclusions Link is successfully clicked ",
                       "Clicking on the Global Promotion Exclusions Link is failed");
			Thread.sleep(medium);
			String isbn=isbnForFutureUse2;
			String isbn4=isbnForFutureUse4;
			writeReport(ISBNExcludeGlobalPromotion(isbn),  
					"ISBN is added to exclude under ISBN Section", 
					"ISBN is successful added to the table", 
					"ISBN is not added to the table");
			Thread.sleep(medium);
			click(ElsevierObjects.marketingPageSinglePercentage_PrmPge_EvlAdmnLnk, "Click on the Evolve Admin Bread Crumb");
			Thread.sleep(medium);
			writeReport(addPromotionLink(), "Click on Add Promotion Link",
					"Clicking on Promotion Link is successful",
					"Failed to click on Promotion Link");
			Thread.sleep(medium);
					
			String user="variablePercentage";
			writeReport(inputValuesInPromotionCode(user, DMCode, "", "", DiscountType2, "", PromotionName, TerritoryCode, ""),  
					"Fill all the mandatory fields in Promotion Type under Add Promotion", 
					"Details are filled successfully: DM Code : "+DMCode+"<br> Discount Type : "+user+ "<br> Promotion Name : "+PromotionName+"<br> Territory Code : "+TerritoryCode+"<br> Promotion Name : "+percentageOff,
					"Failed to fill Details : DM Code : "+DMCode+"<br> Discount Type : "+user+ "<br> Promotion Name : "+PromotionName+"<br> Territory Code : "+TerritoryCode+"<br> Promotion Name : "+percentageOff+"<br> Promotion successfully saved. ");
			
			Thread.sleep(medium);
			writeReport(globalPromotionDVD(user, percentage),  
					"Select the CDROM product type", 
					"CDROM Product type is selected successful </br>and Validated by checking for the product added to the right side in a table", 
					"CDROM Product type is not selected");
			Thread.sleep(medium);
			writeReport(ISBNExclude(variablePercentage),  
					"ISBN is added to exclude under ISBN Section", 
					"ISBN is successful added to the table", 
					"ISBN is not added to the table");
			Thread.sleep(medium);
			writeReport(PromotionRedeemSinglePercentageOff_10229.viewMarketingPage(),  
					"View Marketing Page link is successfully clicked and navigated to the next page", 
					"View Marketing Page link is successfully clicked and navigated to the next page </br> Bread Crumb is present and unique URL is created", 
					"View Marketing Page link is failed to click on the link </br> Bread Crumb is not present and unique URL is not created");
			Thread.sleep(medium);
			writeReport(detailsForFutureUse(),  
					"Details are stored for future use", 
					"Details DM Code, ISBN, Title and Price for 4 items are successfully saved for future use </br> DM Code is : "+DMCode+"</br>"+"ISBNs are : "+Promotion_CreatePromotionMarketingPageSinglePercentage_15582.isbnForFutureUse1+ "," +Promotion_CreatePromotionMarketingPageSinglePercentage_15582.isbnForFutureUse2+"," +Promotion_CreatePromotionMarketingPageSinglePercentage_15582.isbnForFutureUse3+","+Promotion_CreatePromotionMarketingPageSinglePercentage_15582.isbnForFutureUse4
					+"</br> The Titles are : "+Promotion_CreatePromotionMarketingPageSinglePercentage_15582.titleforfutureuse1+ "</br>"+Promotion_CreatePromotionMarketingPageSinglePercentage_15582.titleforfutureuse2 + "</br>"+Promotion_CreatePromotionMarketingPageSinglePercentage_15582.titleforfutureuse3 + "</br>"+Promotion_CreatePromotionMarketingPageSinglePercentage_15582.titleforfutureuse4 
					+ "</br>"+Promotion_CreatePromotionMarketingPageSinglePercentage_15582.priceforfutureuse1+"," +Promotion_CreatePromotionMarketingPageSinglePercentage_15582.priceforfutureuse2 +"," +Promotion_CreatePromotionMarketingPageSinglePercentage_15582.priceforfutureuse3 +"," +Promotion_CreatePromotionMarketingPageSinglePercentage_15582.priceforfutureuse4, 
					"Details ISBN, Title and Price for 4 items are failed to save for future use");		
			
			String uniqueMarketingURL =	EvolveCommonBussinessFunctions.UniqueURL;
			
			//writeReport(launchUrl_AddToCart(uniqueMarketingURL), "Complete the Test case Promotion - Create Promotion & Marketing Page - Single Percentage", "A new promotion has been created and the following data from the test case is carried over for use in this test case.:", "Failed to create promotion and save the data");
			 
			PromotionRedeemSinglePercentageOff_10229.clickOnTitle();
			
			Float discount=(float) 0.90;
			writeReport(PromotionRedeemSinglePercentageOff_10229.titleClickAndVerify(discount), "Launch URL and Verify the Title, ISBN and Price from previous test case :</br> Promotion - Create Promotion & Marketing Page - Single Percentage", "Launch URL : "+uniqueMarketingURL+" is successfull <br>and validating the Title, ISBN and Price from previous test case :</br> Promotion - Create Promotion & Marketing Page - Single Percentage is successfully done", "Launching URL : "+uniqueMarketingURL+" is failed <br>and validating the Title, ISBN and Price from previous test case :</br> Promotion - Create Promotion & Marketing Page - Single Percentage is failed");
			
			PromotionRedeemSinglePercentageOff_10229.verifyCartTitle();
			
			PromotionRedeemSinglePercentageOff_10229.verifyCartPrice(DMCode);
			
			PromotionRedeemSinglePercentageOff_10229.searchProductAndVerify(healthNursing);
			
			String title1=titleforfutureuse1;	
			System.out.println(title1);
			String isbn1=Promotion_CreatePromotionMarketingPageSinglePercentage_15582.isbnForFutureUse1;
			System.out.println(isbn1);
			String pric1=priceforfutureuse1;
			PromotionRedeemSinglePercentageOff_10229.productClickEntirePage(title1, isbn1, pric1);
			
			PromotionRedeemSinglePercentageOff_10229.searchProductAndVerify(healthNursing);
			
			String title2=titleforfutureuse2;	
			System.out.println(title2);
			String isbn2=Promotion_CreatePromotionMarketingPageSinglePercentage_15582.isbnForFutureUse2;
			System.out.println(isbn2);
			String pric2=Promotion_CreatePromotionMarketingPageSinglePercentage_15582.priceforfutureuse2;
			System.out.println(pric2);
			PromotionRedeemSinglePercentageOff_10229.productClickEntirePage(title2, isbn2, pric2);
			
			PromotionRedeemSinglePercentageOff_10229.searchProductAndVerify(healthNursing);
			String title4=titleforfutureuse4;	
			System.out.println(title4);
			//String isbn4=isbnForFutureUse4;
			System.out.println(isbn4);
			String priceforuse=priceforfutureuse4;
			System.out.println(priceforuse);
			PromotionRedeemSinglePercentageOff_10229.productClickEntirePage(title4, isbn4, priceforuse);
			
			deleteCart();
			String isbnSearch=isbnForFutureUse4;
			type(ElsevierObjects.Hesi_Search, isbnSearch, "Type the ISBN4 from previous script");
			click(ElsevierObjects.Hesi_Go, "Click on Go Button");
			//searchProductAndVerify(isbnSearch);
			float discount1=(float)0.50;
			PromotionRedeemSinglePercentageOff_10229.isbn4Verify(discount1);
			PromotionRedeemSinglePercentageOff_10229.addCartButton();
			PromotionRedeemSinglePercentageOff_10229.redeemCheckout();
			
			type(ElsevierObjects.checkout_login_username, sStudentUser, "Existing Student username");
			type(ElsevierObjects.checkout_login_password, sStudentPassword, "Existing student password");
			click(ElsevierObjects.educator_btnLogin, "Click on Login button");
			
			Thread.sleep(medium);
			if(!EvolveCommonBussinessFunctions.creditCardDetails())
				flag = false;
			Thread.sleep(high);
			
			PromotionRedeemSinglePercentageOff_10229.reviewAndSubmitValidation();
			//PromotionRedeemSinglePercentageOff_10229.shipping(shippingAdress, shippingCity, shippingState, shippingZip);	
			click(ElsevierObjects.checkbox1, "Check the checkbox 'Yes, I accept the Registered User Agreement.'");
			//type(ElsevierObjects.instructor_checkoutcvv, "123", "Enter the cvv number");
			click(ElsevierObjects.submitbutton, "Click on the submit button");
			PromotionRedeemSinglePercentageOff_10229.validateConfirmationPage();
						
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}


