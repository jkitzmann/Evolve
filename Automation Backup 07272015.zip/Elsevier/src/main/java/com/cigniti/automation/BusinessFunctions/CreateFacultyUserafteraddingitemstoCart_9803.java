package com.cigniti.automation.BusinessFunctions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class CreateFacultyUserafteraddingitemstoCart_9803 extends EvolveCommonBussinessFunctions {
	
	public static String isbn;
	public static String Firstname;
	public static String Lastname;
	public static String EmailId;
	public static String Password;
	public static String ConformPassword;
	public static String Country;
	public static String State;
	public static String City;
	public static String Institution;
	public static String StreetAddress;
	public static String Zipcode;
	public static String PhoneNumber;
	public static String ProgramType;
	public static String username;
	public static String price;
	public static String Title;
	public static String ISBN;
	
	public static boolean facultyafteraddingcart() throws Throwable{
	try
	{
	 boolean flag = true;
	 launchUrl(configProps.getProperty("URL3"));
	 //Thread.sleep(low);
	 //click(ElsevierObjects.Online_courses,"Click on online courses");
	 Thread.sleep(low);
	 type(ElsevierObjects.Search_Online_Courses,isbn,"Enter the isbn number in the searchbox");
	 Thread.sleep(medium);
	 click(ElsevierObjects.Search_Button,"Click on search button");
	 Thread.sleep(medium);
	 price = getText(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomprice,"Get the price present there");
	 float p=convertStringToPrice(price);
	 float e=convertStringToPrice(ExpectedPrice);
	 if(p==e){
		   Reporters.SuccessReport("Verify price of the product","Price of The Product is ZERO in product page:"+p);
	  }else{
		   Reporters.failureReport("Verify price of the product","Failed to verify Price of The Product.");
	  }
	 Thread.sleep(medium);
	 if(click(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomAddtoCart,"Click on Register for this product now button")){
		 Reporters.SuccessReport("Click Register for this","Successfully clicked on Register for this now button");
	 }else{
		 Reporters.failureReport("Click Register for this","Failed to click on Register for this now button");
	 }
	 Thread.sleep(high);
	 hostedAfterRequestPopUp();
	 Reporters.SuccessReport("Verify Configuration PopUp","User is successfully shown a course configuration pop up");
	 click(ElsevierObjects.Resource_tool,"Click on Evolve content plus tool option");
	 Thread.sleep(medium);
	 click(ElsevierObjects.Apply,"Click on Apply button");
	 Reporters.SuccessReport("Click on Apply","Successfully user is choose to 'Evolve, Content Plus Course Tools' option and clicked on Applu button");
	 Thread.sleep(medium);
	 if(isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MyCartTitle,"Check Mycart title")){
		  Reporters.SuccessReport("Verify MyCart title", "MyCart title is present");
	 }else{
		  Reporters.failureReport("Verify MyCart title", "MyCart title is not present");
	 }
	 Thread.sleep(low);
	 Title = getText(ElsevierObjects.Medical_title,"Get title of the product");
	 Reporters.SuccessReport("Verify the title of the product","Title of the product is verified and title is :"+Title);
	 Thread.sleep(low);
     ISBN =	getText(ElsevierObjects.Evolve_Isbn_Number,"Get the ISBN of the product");
     Reporters.SuccessReport("Verify the ISBN of the product","ISBN of the product is verified and ISBN is :"+ISBN);	  
     Thread.sleep(low);
	 String ProductPrice = getText(ElsevierObjects.Evolve_price,"Get the price present there");
	 if(ProductPrice.contains(price)){
		 Reporters.SuccessReport("Verify the price of the product","Prices are compared Successfully :<br> Expected Price is : "+ProductPrice+"<br> Actual Price is :"+price);
	 }else{
		 Reporters.failureReport("Verify the price of the product","Prices comparison is Failed :<br> Expected Price is : "+ProductPrice+"<br> Actual Price is :"+price);
	 }
	 Thread.sleep(low);
	 click(ElsevierObjects.Hesi_Student_Reedembutton,"Click on Redeem/Checkout button");
	 Thread.sleep(medium);
	 return flag;}
	catch(Exception e){
		sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
	}
	 
	public static boolean Registrationform()throws Throwable {
	try	 
	  {
		boolean flag = true;
	 String h = ReadingExcel.columnDataByHeaderName("h","TC-9803",configProps.getProperty("TestData"));
	 String header =getText(ElsevierObjects.Admin_Evolve_Ecom_NewToEvolve,"Get the header in the page");
	 if(header.contains(h)){
		 Reporters.SuccessReport("Verify the header of the page","Headers are verified Successfully :<br>Expected header is :"+header+"<br> Actual header is :"+h);
	 }else{
		 Reporters.failureReport("Verify the header of the page","Failed to verify the headers :<br>Expected header is :"+header+"<br> Actual header is :"+h);
	 }
	 Thread.sleep(low);
	 String h1 = ReadingExcel.columnDataByHeaderName("h1","TC-9803",configProps.getProperty("TestData"));
	 String header1=getText(ElsevierObjects.Header1,"Get the Section in the page");
	 if(header1.contains(h1)){
		 Reporters.SuccessReport("Verify the Section of the page","Successfully Section is verified :<br>Expected header is :"+header1+"<br> Actual header is :"+h1);
	 }else{
		 Reporters.failureReport("Verify the Section of the page","Failed to verify the Section :<br>Expected header is :"+header1+"<br> Actual header is :"+h1);
	 }
	 Thread.sleep(low);
	 String h2 = ReadingExcel.columnDataByHeaderName("h2","TC-9803",configProps.getProperty("TestData"));
	 String header2 = getText(ElsevierObjects.Header2,"Get the Section in the page");
	 if(header2.contains(h2)){
		 Reporters.SuccessReport("Verify the Section of the page","Section is verified Successfully :<br>Expected header is :"+header2+"<br> Actual header is :"+h2);
	 }else{
		 Reporters.failureReport("Verify the Section of the page","Failed to verify the Section :<br>Expected header is :"+header2+"<br> Actual header is :"+h2);
	 }
	 Thread.sleep(low);
	 if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
		 Reporters.SuccessReport("Click on continue","Fields are left blank and clicked on continue button");
	 }else{
		 Reporters.failureReport("Click on continue","Failed to click on continue button");
	 }
	 Thread.sleep(low);
	 String Err = ReadingExcel.columnDataByHeaderName("Err","TC-9803",configProps.getProperty("TestData"));
	 String error = getText(ElsevierObjects.createNewAccnt_EmptyField_Error,"Get error message");
	 if(error.contains(Err)){
		 Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully:<br>Expected Error is :"+error+"<br> Actual Error is :"+Err);
	 }else{
		 Reporters.failureReport("Verify the Error in the page","Failed to verify the Errors :<br>Expected Error is :"+error+"<br> Actual Error is :"+Err);
	 }
	 Thread.sleep(low);
	 type(ElsevierObjects.educator_form_txtFirstName,Firstname,"Enter firstname in the textbox");
	 Thread.sleep(low);
	 type(ElsevierObjects.educator_form_txtLastName,Lastname,"Enter lastname in the textbox");
	 Thread.sleep(low);	
	 type(ElsevierObjects.educator_form_txtEmail,EmailId,"Enter email in the textbox");
	 Thread.sleep(low);
	 if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
		 Reporters.SuccessReport("Enter and click","Details are entered confirm Email,Password fields left blank and clicked on continue </br> Firstname :"+Firstname+"</br>"+"Lastname :"+Lastname+"</br>"+"Email :"+EmailId);
	 }else{
		 Reporters.failureReport("Enter and click","Failed to enter details and click on continue button");
	 }
	 Thread.sleep(low);		
	 String Err1 = ReadingExcel.columnDataByHeaderName("Err1","TC-9803",configProps.getProperty("TestData"));
	 String error1 = getText(ElsevierObjects.createNewAccnt_EmptyField_Error,"Get error message");
	 if(error1.contains(Err1)){
		 Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully :<br>Expected Error is :"+error1+"<br> Actual Error is :"+Err1);
	 }else{
		 Reporters.failureReport("Verify the Error in the page","Failed to verify the errors :<br>Expected Error is :"+error1+"<br> Actual Error is :"+Err1);
	 }
	 Thread.sleep(low);
	 type(ElsevierObjects.educator_form_txtConformEmail,EmailId,"Enter Confirm email in the textbox");
	 Thread.sleep(low);
	 if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
		 Reporters.SuccessReport("Enter and click","Details are entered and Password field left blank and clicked on continue </br>"+"Confirm Email :"+EmailId);
	 }else{
		 Reporters.failureReport("Enter and click","Failed to enter details and click on continue button");
	 }
	 Thread.sleep(low);
	 String Err2 =ReadingExcel.columnDataByHeaderName("Err2","TC-9803",configProps.getProperty("TestData"));
	 String error2 = getText(ElsevierObjects.createNewAccnt_EmptyField_Error,"Get error message");
	 if(error2.contains(Err2)){
		 Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully : <br> Expected Error is :"+error2+"<br> Actual Error is :"+Err2);
	 }else{
		 Reporters.failureReport("Verify the Error in the page","Failed to verify the errors : <br> Expected Error is :"+error2+"<br> Actual Error is :"+Err2);
	 }
	 Thread.sleep(low);
	 type(ElsevierObjects.educator_form_txtPassword,Password,"Enter Password in the textbox");
	 Thread.sleep(low);
	 type(ElsevierObjects.educator_form_txtConformPassword,ConformPassword,"Enter Confirm Password in the textbox");
	 Thread.sleep(low);
	 if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
		 Reporters.SuccessReport("Enter and click","Details are entered and Entered different password and clicked on continue button </br>"+"Password :"+Password+"</br>"+"ConformPassword :"+ConformPassword);
	 }else{
		 Reporters.failureReport("Enter and click", "Failed to enter details and click on continue button");
	 }
	 Thread.sleep(low);
	 String Err3 = ReadingExcel.columnDataByHeaderName("Err3","TC-9803",configProps.getProperty("TestData"));
	 String error3 =getText(ElsevierObjects.createNewAccnt_EmptyField_Error,"Get error message");
	 if(error3.contains(Err3)){
		 Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully :<br> Expected Error is :"+error3+"<br> Actual Error is :"+Err3);
	 }else{
		 Reporters.failureReport("Verify the Error in the page","Failed to verify the errors :<br> Expected Error is :"+error3+"<br> Actual Error is :"+Err3);
	 }
	 Thread.sleep(low);
	 type(ElsevierObjects.educator_form_txtPassword,Password,"Enter Password in the textbox");
	 Thread.sleep(low);
	 type(ElsevierObjects.educator_form_txtConformPassword,Password,"Enter Conform Password in the textbox");
	 Thread.sleep(low);
	 if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
		 Reporters.SuccessReport("Enter and click","Details are entered and leave Institution details blank and clicked on continue button </br>"+"Password :"+Password+"</br>"+"ConformPassword :"+Password);
	 }else{
		 Reporters.failureReport("Enter and click","Failed to enter details and click on continue button");
	 }
	 Thread.sleep(low);
	 String Err4 = ReadingExcel.columnDataByHeaderName("Err4","TC-9803",configProps.getProperty("TestData"));
	 String error4 = getText(ElsevierObjects.Institution_Error_msg1,"Get error message");
	 if(error4.contains(Err4)){
		 Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully :<br>Expected Error is :"+error4+"<br> Actual Error is :"+Err4);
	 }else{
		 Reporters.failureReport("Verify the Error in the page","Failed to verify the errors :<br>Expected Error is :"+error4+"<br> Actual Error is :"+Err4);
	 }
	 Thread.sleep(low);
	 selectByVisibleText(ElsevierObjects.Hesi_Student_country,Country,"Select Country name from the list");
	 Thread.sleep(medium);
	 selectByVisibleText(ElsevierObjects.Hesi_Student_state,State,"Select State name from the list");
	 Thread.sleep(medium);
	 b= true;
	 if(selectBySendkeys(ElsevierObjects.Hesi_Student_City,City,"Enter City name")){
	    Reporters.SuccessReport("Get Cityname","Cityname is :" +City);
	 }else{
		 Reporters.failureReport("Get Cityname", "Failed to get city name");
	 }
	 Thread.sleep(medium);
	 driver.findElement(ElsevierObjects.Hesi_Student_City).sendKeys(Keys.ENTER);
	 Thread.sleep(medium);
	 if(selectBySendkeys(ElsevierObjects.Hesi_Student_institute,Institution,"Enter Institute name")){
	    Reporters.SuccessReport("Get Institutename","Institutename is :" +Institution);
	 }else{
		Reporters.failureReport("Get Institutename", "Failed to get Institute name");
	 }
	 b=false;
	 if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
		 Reporters.SuccessReport("Enter and click","Details are entered,leave address fields blank and clicked on continue button  </br>"+"Country :"+Country+"</br>"+"State :"+State+"</br>"+"City :"+City+"</br>"+"Institute :"+Institution);
	 }else{
		 Reporters.failureReport("Enter and click", "Failed to enter details and click on continue button");
	 }
	 Thread.sleep(low);
	 String Err5 = ReadingExcel.columnDataByHeaderName("Err4","TC-9803",configProps.getProperty("TestData"));
	 String error5 = getText(ElsevierObjects.Institution_Error_msg2,"Get error message");
	 if(error4.contains(Err4)){
		 Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully :<br> Expected Error is :"+error5+"<br> Actual Error is :"+Err5);
	 }else{
		 Reporters.failureReport("Verify the Error in the page","Failed to verify the errors :<br> Expected Error is :"+error5+"<br> Actual Error is :"+Err5);
	 }
	 Thread.sleep(low);
	 String ActualCity = ReadingExcel.columnDataByHeaderName("ActualCity","TC-9803",configProps.getProperty("TestData"));
	 String cityVal=null;
	 
	 if (driver instanceof JavascriptExecutor) {
		 JavascriptExecutor js = (JavascriptExecutor)driver;
		 cityVal=(String)js.executeScript("return document.getElementById('address0-city').value;");
		
	 }
	 if(/*cityVal.contains(ActualCity)*/cityVal.equalsIgnoreCase(ActualCity)){
		 Reporters.SuccessReport("Verify the city in the textbox", "City is verified Successfully :<br> Expected City is :"+cityVal+"<br> Actual City is :"+ActualCity);
	 }else{
		 Reporters.failureReport("Verify the city in the textbox","Failed to verify city :<br> Expected City is :"+cityVal+"<br> Actual City is :"+ActualCity);
	 }
	 Thread.sleep(low);
	 String ActualState = ReadingExcel.columnDataByHeaderName("ActualState","TC-9803",configProps.getProperty("TestData"));
	 String StateVal = null;
	 if (driver instanceof JavascriptExecutor) {
		 JavascriptExecutor js = (JavascriptExecutor)driver;
		 StateVal=(String)js.executeScript("return document.getElementById('address0-state').value;");	
	 }
	 if(StateVal.contains(ActualState)){
		 Reporters.SuccessReport("Verify the State in the textbox","State is verified Successfully :<br>Expected State is :"+StateVal+"<br> Actual State is :"+ActualState);
	 }else{
		 Reporters.failureReport("Verify the State in the textbox","Failed to verify state :<br>Expected State is :"+StateVal+"<br> Actual State is :"+ActualState); 
		 
	 }
	 Thread.sleep(low);
	 type(ElsevierObjects.evolve_Institution_street,StreetAddress,"Enter the Street address");
	 Thread.sleep(medium);
	 type(ElsevierObjects.Zip_Code,Zipcode,"Enter the Zipcode");
	 Thread.sleep(medium);
	 type(ElsevierObjects.educator_form_txtAddPhone,PhoneNumber,"Enter PhoneNumber");
	 Thread.sleep(medium);
	 selectByVisibleText(ElsevierObjects.educator_form_txtddprogramType,ProgramType,"Select program type form list");
	 Thread.sleep(medium);
	 Reporters.SuccessReport("Enter details","Details of Institution entered Successfully :</br>"+"Street Address :"+StreetAddress+"</br>"+"Zipcode :"+Zipcode+"</br>"+"Program type :"+ProgramType+"</br>"+"PhoneNumber :"+PhoneNumber);
	 click(ElsevierObjects.educator_form_btnContinue,"Click on continue button");
	 Thread.sleep(medium);
	 String title = getText(ElsevierObjects.Product_title,"Get the product title");
	 if(title.contains(Title)){
		   Reporters.SuccessReport("Verify the title of the product", "Title's are compared successfully :<br> Expected title is :"+title+"<br> Actual title is :"+Title);
	 }else{
		   Reporters.failureReport("Verify the title of the product", "Title's comparision is failed :<br> Expected title is :"+title+"<br> Actual title is :"+Title);
	 }
	 Thread.sleep(low);
	 String ProductISBN = getText(ElsevierObjects.Evolve_Isbn_Number,"Get the ISBN of the product");
     if(ProductISBN.contains(ISBN)){
    	 Reporters.SuccessReport("Verify the ISBN of the product","ISBN's compared Successfully :<br> Expected ISBN is :"+ProductISBN+"<br> Actual ISBN is :"+ISBN);
     }else{
    	 Reporters.failureReport("Verify the ISBN of the product","ISBN's comparison is failed :<br> Expected ISBN is :"+ProductISBN+"<br> Actual ISBN is :"+ISBN);
     }
	 Thread.sleep(low);
	 String Price = getText(ElsevierObjects.Evolve_price,"Get the price is $0.00");
	 if(Price.contains(price)){
		 Reporters.SuccessReport("Verify the price of the product","Prices are compared successfully :<br> Expected price is : "+price+"<br> Actual price is :"+Price);
	 }else{
		 Reporters.failureReport("Verify the price of the product","Prices comparision is failed :<br> Expected price is : "+price+"<br> Actual price is :"+Price);
	 }
	 String TotalPrice = getText(ElsevierObjects.Totalprice,"Get the price is $0.00");
	 if(Price.contains(price)){
		 Reporters.SuccessReport("Verify the Total price of the product","Total prices are compared successfully :<br> Expected price is : "+price+"<br> Actual price is :"+TotalPrice);
	 }else{
		 Reporters.failureReport("Verify the Total price of the product","Total prices comparison is failed :<br> Expected price is : "+price+"<br> Actual price is :"+TotalPrice);
	 }
	 Thread.sleep(low);
	 click(ElsevierObjects.checkbox1,"Click on checkbox");
	 Thread.sleep(medium);
	 click(ElsevierObjects.checkbox2,"Click on checkbox");
	 Thread.sleep(medium);
	 click(ElsevierObjects.instructor_submit,"Click on submit button");
	 Thread.sleep(low);
	 return flag;}
	catch(Exception e){
		sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
	
	}	 
	
	public static boolean ConfirmationRelogin()throws Throwable{
	try
	  {
	   boolean flag = true;	
	   String producttitle = getText(ElsevierObjects.Admin_Evolve_Ecom_Confirmtitle1,"Get Title of the product");
	   if(Title.contains(producttitle)){
		   Reporters.SuccessReport("Verify the title of the product", "Title's are compared successfully :<br> Expected title is :"+Title+"<br> Actual title is :"+producttitle);
	   }else{ 
		   Reporters.failureReport("Verify the title of the product", "Title's comparision is failed :<br> Expected title is :"+Title+"<br> Actual title is :"+producttitle);
	   }
	   Thread.sleep(low);
	   String Isbn = getText(ElsevierObjects.Isbn_number,"Get Isbn number");
	   if(Isbn.contains(ISBN)){
    	   Reporters.SuccessReport("Verify the ISBN of the product","ISBN's compared Successfully :<br> Expected ISBN is :"+Isbn+"<br> Actual ISBN is :"+ISBN);
       }else{
    	   Reporters.failureReport("Verify the ISBN of the product","ISBN's comparision is failed :<br> Expected ISBN is :"+Isbn+"<br> Actual ISBN is :"+ISBN);
       }
	   Thread.sleep(low);
	   String Price =getText(ElsevierObjects.price,"Get the Price of product");
	   if(Price.contains(price)){
		   Reporters.SuccessReport("Verify the Item price of the product","prices are compared successfully :<br> Expected price is : "+Price+"<br> Actual price is :"+price);
	   }else{
		   Reporters.failureReport("Verify the Item price of the product","prices comparision is failed :<br> Expected price is : "+Price+"<br> Actual price is :"+price);
	   }
	   Thread.sleep(low);
	   String TotalPrice = getText(ElsevierObjects.Total_Price,"Get Totalprice is $0.00");
	   if(TotalPrice.contains(price)){
		   Reporters.SuccessReport("Verify the Totalprice of the product","Totalprices are compared successfully :<br> Expected price is : "+TotalPrice+"<br> Actual price is :"+price);
	   }else{
		   Reporters.failureReport("Verify the Totalprice of the product","Totalprices comparision is failed :<br> Expected price is : "+TotalPrice+"<br> Actual price is :"+price);
	   } 
	   Thread.sleep(low);
	   click(ElsevierObjects.myAccount,"Click on MyAccount");
	   Thread.sleep(low);
	   click(ElsevierObjects.myAccount_AccountSettings,"Click on Account settings");
	   Thread.sleep(low);
       username=getAttribute(ElsevierObjects.Accountsettings_username, "value", "Get attribute of username");
       if(username!=null){
			Reporters.SuccessReport("Get Username","Click on Account settings Successfully and Username is :" +username);
	   }else{
			Reporters.failureReport("Get Username", "Failed to click on Account settings and get username");
	   }
	   Thread.sleep(low);
	   click(ElsevierObjects.myAccount,"Click on MyAccount");
	   if(click(ElsevierObjects.Student_Logout,"Click on logout button")){
			Reporters.SuccessReport("Click on logout","User is Successfully logout");
	   }else{
			Reporters.failureReport("Click on logout","User is failed to logout");
	   }
	   Thread.sleep(low);
	   if(click(ElsevierObjects.Student_Home_Login,"Click on login button")){
			Reporters.SuccessReport("Click on login", "User is Successfully login with the created Faculty details");
	   }else{
		    Reporters.failureReport("Click on login", "User is failed to login with the created Faculty details");
	   }
	   type(ElsevierObjects.common_login_userName,username,"Enter username in the textbox");
	   Thread.sleep(low);
	   type(ElsevierObjects.common_login_passWord,Password,"Enter Password in the textbox");
	   Thread.sleep(low);
	   click(ElsevierObjects.submit,"Click on login button");
	   Thread.sleep(low);
	   click(ElsevierObjects.evolveCatalog,"Click on catalog button");
	   Thread.sleep(low);
	   //click(ElsevierObjects.Online_courses,"Click on online courses");
	   //Thread.sleep(low);
	   type(ElsevierObjects.Search_Online_Courses,isbn,"Enter the isbn number in the searchbox");
	   Reporters.SuccessReport("Enter ISBN","Isbn is entered Successfully and Product is searched from Onlinecourses Honeypot "+isbn);
	   Thread.sleep(medium);
	   click(ElsevierObjects.Search_Button,"Click on search button");
	   Thread.sleep(medium);
	   String price = getText(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomprice,"Get the price present there");
	   float p=convertStringToPrice(price);
	   float e=convertStringToPrice(ExpectedPrice);
	   if(p==e){
		  Reporters.SuccessReport("Verify price of the product","Price of The Product Is Greater Than Zero:"+p);
	   }else{
		  Reporters.failureReport("Verify price of the product","Failed to verify Price of The Product.");
       } 
	   Thread.sleep(low);
	   return flag;}
	catch(Exception e){
		sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}	  }	
	 //step21
	 //login evolve admin
	 public static boolean search_adoptions() throws Throwable {
	 try
	 {
	  boolean flag = true;
	  click(ElsevierObjects.searchAR,"Click on search Adoptions Request");
	  Thread.sleep(low);
	  selectByVisibleText(ElsevierObjects.selectdays, "Today", "Select Today's locator");
	  Thread.sleep(low);
	  waitForElementPresent(ElsevierObjects.btndatesearch_AR, "search button");	
	  Thread.sleep(medium);
	  click(ElsevierObjects.btndatesearch_AR, "ToDay date Radio button");
	  Thread.sleep(low);
	  type(ElsevierObjects.User_Id,username,"Enter username in the textbox");
	  Thread.sleep(low);
	  click(ElsevierObjects.Searchon,"Click on search option");
	  Thread.sleep(low);
	  click(ElsevierObjects.Adoption_label,"Click on online label on adoption page");
	  Thread.sleep(low);
	  String ISBN = getText(ElsevierObjects.Adoption_request_isbn,"Get the ISBN present there");
	  if(ISBN.contains(isbn)){
		  Reporters.SuccessReport("verify the isbn of the product in Search Adoptions","ISBN's are successfully verified : <br>Excpected ISBN :" +ISBN+"<br> Actual ISBN is :"+isbn);
	  }else{
		  Reporters.failureReport("verify the isbn of the product in Search Adoptions", "Failed to verify ISBN's : <br>Excpected ISBN :" +ISBN+"<br> Actual ISBN is :"+isbn);
	  }
	  Thread.sleep(low);
	  String s = getText(ElsevierObjects.Adoption_request_username,"Get username");
	  if(s.contains(username)){
		  Reporters.SuccessReport("Verify username","Usernames are verified Successfully :<br> Expected Username is :" +username+"<br> Actual username is:"+s);
	  }else{
		  Reporters.failureReport("Verify username","Failed to verify username :<br> Expected Username is :" +username+"<br> Actual username is:"+s);
	  }
	  click(ElsevierObjects.logoutadmin,"click on logout button");
	
	 return flag;}
	 catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}  }	
	/* //step22 email 
	 public static boolean emailVerification() throws Throwable{
	 try
	    { 
		 boolean flag=true;
    	 launchUrl(configProps.getProperty("EmailURL"));
		 Thread.sleep(medium);
		 type(ElsevierObjects.emailaddress,configProps.getProperty("verifyemail_username"),"Enter email id");
		 Thread.sleep(medium);
		 type(ElsevierObjects.emailpassword,configProps.getProperty("verifyemail_password"),"Enter password");
	 	  Thread.sleep(medium);
		 click(ElsevierObjects.emaillogin, "Click on Login Button.");
		 Thread.sleep(medium);
		 click(ElsevierObjects.email_Icon,"Click on Email icon.");
		 Thread.sleep(medium);
		 click(ElsevierObjects.email_dropdown,"Click on Dropdown.");
		 Thread.sleep(medium);
		 click(ElsevierObjects.email_dropdown_Fromchk,"Click on From check box.");
		 Thread.sleep(medium);
		 click(ElsevierObjects.email_dropdown_Tochk,"Click on To checkbox.");
   		 Thread.sleep(medium);
		 type(ElsevierObjects.email_SearchBox,EmailId,"Enter the email id.");	
		 Thread.sleep(medium);
		 click(ElsevierObjects.email_SearchIcon,"Click on search icon.");
		 Thread.sleep(high);
		 click(ElsevierObjects.Email_selection,"Click on welcome to evolve");
		 Thread.sleep(medium);
		 switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
		 String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
		 if(emailBody.contains(Firstname) && emailBody.contains(Lastname) && emailBody.contains(EmailId) && emailBody.contains(username) && emailBody.contains(Password)){
		 driver.switchTo().defaultContent();
		 if(click(ElsevierObjects.email_logout,"Click on logout."))
		 {
			Reporters.SuccessReport("Verifying User details In Email Body.</br>Clicking On Logout Button.","Successfully Verified Username: "+username+"</br>Password: "+Password+"</br>Firstname: "+Firstname+" </br>Lastname: "+Lastname+"</br>Email:"+EmailId+"</br>Successfully Clicked On Logout Button </br></br> Email Body Is: "+emailBody+"</br>");
		 }else{
			Reporters.failureReport("Verifying User details In Email Body.</br>Clicking On Logout Button.", "Failed To Verify User Details.</br>Failed To Click On Logout Button.  Email Body Is: "+emailBody+"</br>");
		 }
	    }
		else{
	 		Reporters.failureReport("Verifying User details In Email Body.", "Failed To Verify User Details in Email Body.");
	    }	 
	   return flag;}
	 catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}	
	 }*/
	
	 //Common Business logic for Tc-9800,Tc-9801,8798,9799
			public static boolean emailVerification() throws Throwable{
				boolean flag=true;
				  String reLoginUser=credentials[0];
				  String reLoginPassword=credentials[0];

				try{
				//String email=tc_9798.get("user_email");
				if(type(ElsevierObjects.email_SearchBox,getAccountDetailsEmail,"Enter the email id.")){
					Reporters.SuccessReport("Searching The EmailId.", "Successfully Entered email: "+getAccountDetailsEmail);
				}
				else{
					Reporters.failureReport("Searching The EmailId.", "Failed To Enter email: "+getAccountDetailsEmail);
				}
				Thread.sleep(veryhigh);
				if(!click(ElsevierObjects.email_SearchIcon,"Click on search icon.")){
					flag=false;
				}
				Thread.sleep(veryhigh);
				List <WebElement> a=driver.findElements(By.xpath(".//td[contains(text(),'Welcome')]"));
				
				for(int i=0;i<=a.size();i++)
				{
				try{
					a.get(i).click();
					break;
				}catch(Exception e){}
				}
				
				//driver.findElement(By.xpath(".//*[@id='mail.hsplit.grid']//td[Contains(text(),'Welcome to Evolve')]")).click();
		//	driver.findElement(By.partialLinkText("Welcome to Evolve"));
				//driver.findElement(By.xpath(".//*[@id='mail.hsplit.grid']/div[1]/table[31]/tbody/tr/td[5]")).click();
				//driver.findElement(By.xpath(".//*[@id='mail.hsplit.grid']/div[1]/table[31]/tbody/tr/td[5]")).sendKeys(Keys.ENTER);
				
				Thread.sleep(high);
				Thread.sleep(200);
					if(!switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame")){
					flag=false;
				}
				Thread.sleep(medium);
				String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
				emailBody=emailBody.replaceAll("<", "| ");
				emailBody=emailBody.replace(">", "  |");	
				//String firstName=tc_9798.get("user_firstname");
				//String studentlastName=tc_9798.get("student_lastname");
				//String facultyLastName=tc_9798.get("faculty_lastname");
				String Password=ReadingExcel.columnDataByHeaderName("Password","TC-15588",configProps.getProperty("TestData"));
					if(emailBody.trim().contains(getAccountDetailsFirstName.trim()) && emailBody.trim().contains(getAccountDetailsLastName.trim())&& emailBody.trim().contains(getAccountDetailsEmail.trim()) && emailBody.trim().contains(getAccountDetailsUserName.trim()) && emailBody.trim().contains(Password.trim()))
					{
						System.out.println("Check user details in email.");
						driver.switchTo().defaultContent();
						if(click(ElsevierObjects.email_logout,"Click on logout.")){
							
							Reporters.SuccessReport("Verifying User details In Email Body.</br>Clicking On Logout Button.","Successfully Verified Username: "+username+"</br>Password: "+Password+"</br>Firstname: "+getAccountDetailsFirstName+" </br>Lastname: "+getAccountDetailsLastName+"</br>Email:"+getAccountDetailsEmail+"</br>Successfully Clicked On Logout Button </br></br> Email Body Is: "+emailBody+"</br>");
						}
						else{
							Reporters.failureReport("Verifying User details In Email Body.</br>Clicking On Logout Button.", "Failed To Verify User Details.</br>Failed To Click On Logout Button.  Email Body Is: "+emailBody+"</br>");
						}
					}
					else{
						Reporters.failureReport("Verifying User details In Email Body.", "Failed To Verify User Details in Email Body.");
					}
				
				}
				catch(Exception e){
					sgErrMsg=e.getMessage();
					System.out.println(e);return false;
				}
			return flag;
			}
}
