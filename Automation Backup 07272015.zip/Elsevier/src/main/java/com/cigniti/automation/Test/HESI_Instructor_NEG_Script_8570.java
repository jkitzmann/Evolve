package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;

public class HESI_Instructor_NEG_Script_8570 extends EvolveCommonBussinessFunctions {
  @Test
  public void HESI_Instructor_NEG_8570() throws Throwable {
     try
	   { 
		  SwitchToBrowser(ElsevierObjects.studentBrowserType);
    	  String user = "educator";
		  String userName = ReadingExcel.columnDataByHeaderName("EducatorUserName", "TC-8567", configProps.getProperty("TestData"));
		  String password = ReadingExcel.columnDataByHeaderName("EducatorPassword", "TC-8567", configProps.getProperty("TestData"));
    	 
		  HesiNegISBN =ReadingExcel.columnDataByHeaderName("HesinegISBN","TC-8567",configProps.getProperty("TestData"));
    	  
    	  stepReport("Login as existing Instructor");
		  writeReport(EvolveCommonBussinessFunctions.existingUserLogin (user,userName,password),"Login to the application as a Faculty user",
    			                                                         "Successfully EvolveCert URL is Launched and Entered as a Faculty user </br>" +userName,
    			                                                         "Failed to Launch URL an enter as an Educator");
    	  stepReport("Verify no results for HESI ISBN search");
		  writeReport(EvolveCommonBussinessFunctions.SearchNegProduct(),"Enter ISBN in searchbox,click on GO button and check the result",
    			                                                        "Successfully Isbn is Entered in searchbox,clicked on Go button and NO result is found for HESI ISBN: </br>" +HesiNegISBN,
    			                                                        "Failed to enter Isbn in searchbox and unable to get result");
	   	}
	    catch(Exception e){
	    	System.out.println(e);
	    }
  	}
}
