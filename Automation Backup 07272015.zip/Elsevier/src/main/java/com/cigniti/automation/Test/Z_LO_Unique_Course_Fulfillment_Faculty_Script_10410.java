package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.LO_GlobalCourse_9826;
import com.cigniti.automation.BusinessFunctions.LO_GlobalStudent_8571;
import com.cigniti.automation.BusinessFunctions.Z_Create_LO_Unique_Course_15583;
import com.cigniti.automation.BusinessFunctions.Z_LO_Unique_Course_Fulfillment_Faculty_10410;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class Z_LO_Unique_Course_Fulfillment_Faculty_Script_10410 extends Z_LO_Unique_Course_Fulfillment_Faculty_10410 {
	
	@Test 
	public void zCreateLoUniqueCourse() throws Throwable{
		try {
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			
			if(CreateNewUser(ElsevierObjects.EDUCATOR)){
	     		Reporters.SuccessReport("Login into Application ", "Successfully logged in as Faculty user");
			}
			else{
				Reporters.failureReport("Login into Application ", "Failed to login as Faculty user");
			}
			
			if(Z_Create_LO_Unique_Course_15583.searchProduct()){
	     		Reporters.SuccessReport("Search Product ", "Successfully searched product.");
			}
			else{
				Reporters.failureReport("Search Product ", "Failed to search product.");
			}	

			if(Z_Create_LO_Unique_Course_15583.addProductToCart()){
	     		Reporters.SuccessReport("Add product to cart ", "Successfully added product to cart.");
			}
			else{
				Reporters.failureReport("Search Product ", "Failed to added product to cart.");
			}
			
			if(LO_GlobalStudent_8571.checkOut())
			{
	     		Reporters.SuccessReport("CheckOut ", "Successfully CheckOut.");
			}
			else
			{
				Reporters.failureReport("CheckOut ", "Failed to CheckOut.");
			}
			
			if(LO_GlobalCourse_9826.formFill(ElsevierObjects.EDUCATOR))
			{
	     		Reporters.SuccessReport("Fill update user form ", "Successfully filled 'update user form'.");
			}
			else
			{
				Reporters.failureReport("Fill update user form ", "Failed to fill 'update user form'.");
			}
			
			if(LO_GlobalStudent_8571.submitOrder(ElsevierObjects.EDUCATOR))
			{
	     		Reporters.SuccessReport("Submit Order ", "Successfully submitted order.");
			}
			else
			{
				Reporters.failureReport("Submit Order ", "Failed to submitt order.");
			}
			
			//SwitchToBrowser(ElsevierObjects.adminBrowserType);
			if(evolveAdminlogin())
			{
	     		Reporters.SuccessReport("Login as admin ", "Successfully login in as admin.");
			}
			else
			{
				Reporters.failureReport("Login as admin ", "Failed to login in as admin.");
			}	
			
			if(Z_Create_LO_Unique_Course_15583.searchAdoptionRequest())
			{
	     		Reporters.SuccessReport("Search Adoption Results ", "Successfully searched Adoption Results.");
			}
			else
			{
				Reporters.failureReport("Login as admin ", "Failed to search Adoption Results.");
			}		
			
			if(Z_Create_LO_Unique_Course_15583.adoptionSearchResults())
			{
	     		Reporters.SuccessReport("Navigate to Adoption Request Details page. ", "Successfully navigated to Adoption Request Details page.");
			}
			else
			{
				Reporters.failureReport("Navigate to Adoption Request Details page. ", "Failed to navigate to Adoption Request Details page.");
			}
			
			if(Z_Create_LO_Unique_Course_15583.verifyAdoptionRequestDetails())
			{
	     		Reporters.SuccessReport("Navigate to Adoption Request Details page. ", "Successfully navigated to Adoption Request Details page.");
			}
			else
			{
				Reporters.failureReport("Navigate to Adoption Request Details page. ", "Failed to navigate to Adoption Request Details page.");
			}	
			
			if(Z_Create_LO_Unique_Course_15583.updateARD_RequestStatus())
			{
	     		Reporters.SuccessReport("Update Request Status. ", "Successfully updated request status.");
			}
			else
			{
				Reporters.failureReport("Update Request Status. ", "Failed to updated request status.");
			}
			if(emailVerification())
			{
	     		Reporters.SuccessReport("Verify email is received by instructor . ", "Successfully email is received by instructor.");
			}
			else
			{
				Reporters.failureReport("Verify email is received by instructor. ", "Failed to receive email by instructor..");
			}		
			
			if(nonAdminLogin()){
	     		Reporters.SuccessReport("Login as facult user . ", "Successfully logged in as faculty user.");
			}
			else
			{
				Reporters.failureReport("Login as facult user. ", "Failed to loggin as faculty user.");
			}
			
			if(openNewlyCreatedCourseLink()){
	     		Reporters.SuccessReport("Open content link . ", "Successfully opened content link.");
			}
			else
			{
				Reporters.failureReport("Open content link . ", "Failed to open content link.");
			}
			
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}

