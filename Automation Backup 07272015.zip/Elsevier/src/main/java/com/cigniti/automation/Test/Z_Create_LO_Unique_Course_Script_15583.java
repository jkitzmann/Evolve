package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.LO_GlobalCourse_9826;
import com.cigniti.automation.BusinessFunctions.LO_GlobalStudent_8571;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.BusinessFunctions.Z_Create_LO_Unique_Course_15583;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class Z_Create_LO_Unique_Course_Script_15583 extends Z_Create_LO_Unique_Course_15583 {

	@Test 
	public void zCreateLoUniqueCourse() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			
			if(CreateNewUser(ElsevierObjects.EDUCATOR)){
	     		Reporters.SuccessReport("Login into Application ", "Successfully logged in as Faculty user");
			}
			else{
				Reporters.failureReport("Login into Application ", "Failed to login as Faculty user");
			}
			
			if(searchProduct()){
	     		Reporters.SuccessReport("Search Product ", "Successfully searched product.");
			}
			else{
				Reporters.failureReport("Search Product ", "Failed to search product.");
			}	

			if(addProductToCart()){
	     		Reporters.SuccessReport("Add product to cart ", "Successfully added product to cart.");
			}
			else{
				Reporters.failureReport("Search Product ", "Failed to added product to cart.");
			}
			
			if(LO_GlobalStudent_8571.checkOut())
			{
	     		Reporters.SuccessReport("CheckOut ", "Successfully CheckOut.");
			}
			else
			{
				Reporters.failureReport("CheckOut ", "Failed to CheckOut.");
			}
			
			if(LO_GlobalCourse_9826.formFill(ElsevierObjects.EDUCATOR))
			{
	     		Reporters.SuccessReport("Fill update user form ", "Successfully filled 'update user form'.");
			}
			else
			{
				Reporters.failureReport("Fill update user form ", "Failed to fill 'update user form'.");
			}
			
			if(LO_GlobalStudent_8571.submitOrder(ElsevierObjects.EDUCATOR))
			{
	     		Reporters.SuccessReport("Submit Order ", "Successfully submitted order.");
			}
			else
			{
				Reporters.failureReport("Submit Order ", "Failed to submitt order.");
			}
			
			if(confirmationOrder())
			{
	     		Reporters.SuccessReport("Confirm Order ", "Successfully verified data in confirm page.");
			}
			else
			{
				Reporters.failureReport("Confirm Order ", "Failed to verify data in confirm page.");
			}
			
			Thread.sleep(high);
			User_BusinessFunction.Logout();
			
			//SwitchToBrowser(ElsevierObjects.adminBrowserType);
			if(evolveAdminlogin())
			{
	     		Reporters.SuccessReport("Login as admin ", "Successfully login in as admin.");
			}
			else
			{
				Reporters.failureReport("Login as admin ", "Failed to login in as admin.");
			}	
			
			if(searchAdoptionRequest())
			{
	     		Reporters.SuccessReport("Search Adoption Results ", "Successfully searched Adoption Results.");
			}
			else
			{
				Reporters.failureReport("Login as admin ", "Failed to search Adoption Results.");
			}		
			
			
			
			if(verifyAdoptionRequestDetails())
			{
	     		Reporters.SuccessReport("Navigate to Adoption Request Details page. ", "Successfully navigated to Adoption Request Details page.");
			}
			else
			{
				Reporters.failureReport("Navigate to Adoption Request Details page. ", "Failed to navigate to Adoption Request Details page.");
			}	
			
			if(updateARD_RequestStatus())
			{
	     		Reporters.SuccessReport("Update Request Status. ", "Successfully updated request status.");
			}
			else
			{
				Reporters.failureReport("Update Request Status. ", "Failed to updated request status.");
			}	
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	@AfterTest
	public void closeBrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}

