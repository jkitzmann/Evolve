package com.cigniti.automation.BusinessFunctions;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class PromotionSinglePercentageInclusions_10226 extends EvolveCommonBussinessFunctions{
	//static org.openqa.selenium.Alert alert;
	
	//Validating the products 
	public static boolean validateIncludeAllProducts() throws Throwable{
		
		try{
			boolean flag=true;
			click(ElsevierObjects.Evolve_Admin_Prmlnk_IncludeChk, "Check the checkbox");
			Thread.sleep(medium);
			org.openqa.selenium.Alert alert;
			alert = driver.switchTo().alert();
			String alertMessage=alert.getText();
			Reporters.SuccessReport(alertMessage, "PopUp is present with the Message : " + alertMessage);
			alert.dismiss();
			if(isCheckedNegative(ElsevierObjects.Evolve_Admin_Prmlnk_IncludeChk, "")){
				Reporters.failureReport("promotion page with no changes made", "User is not taken back to promotion page with no changes made");				
			}else{
				Reporters.SuccessReport("promotion page with no changes made", "User is taken back to promotion page with no changes made");
			}
			click(ElsevierObjects.Evolve_Admin_Prmlnk_IncludeChk, "Check the checkbox");
			Alert();
			
			String AddDisabled=getAttribute(ElsevierObjects.Evolve_Admin_Prmlnk_AddIncludeBtn, "disabled", "Get the attribute value ");
			if(AddDisabled.contains("true")){
				Reporters.SuccessReport("Promotion Inclusions section is now grayed out/disabled. ", "The rest of the Promotion Inclusions section is now grayed out/disabled. ");
			}else{
				Reporters.failureReport("Promotion Inclusions section is now grayed out/disabled. ", "The rest of the Promotion Inclusions section Enabled. ");
			}
			verifyText(ElsevierObjects.Evolve_Admin_Prmlnk_SucMsgInclude, "All products have been included successfully. ", "Success Message is present");
			
			click(ElsevierObjects.Evolve_Admin_Prmlnk_SelcallRdiobtn, "Select Specific Radio button");
					
			return flag;			
		}catch(Exception e){return false;}
	}
	
public static boolean validateSelectAllProducts() throws Throwable{
		
		try{
			boolean flag=true;
			click(ElsevierObjects.Evolve_Admin_Prmlnk_SelcallRdiobtn, "Check the checkbox");
			isEnabled(ElsevierObjects.Evolve_Admin_Prmlnk_AddIncludeBtn, "Add Button is Enabled");
			String comboSize=getAttribute(ElsevierObjects.Evolve_Admin_Prmlnk_PrtCetr, "size", "");
			if(comboSize.contains("5")){
				Reporters.SuccessReport("Validate that the Profit Centers shows 5 Products in the Combo Box", "Profit Centers shows 5 Products in the Combo Box ");
			}else{
				Reporters.failureReport("Validate that the Profit Centers shows 5 Products in the Combo Box", "Profit Centers fails to show 5 Products in the Combo Box ");
			}
			
			List<WebElement> selectOptionData=getElements(ElsevierObjects.Evolve_Admin_Prmlnk_PrtCetr);
			
			for(WebElement option: selectOptionData){
				System.out.println(option.getText());
			}			
			isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_AddIncludeBtn, "Add Button is present", driver.getCurrentUrl());
			return flag;			
		}catch(Exception e){return false;}
	}	



//Validating Profit Center Section for Variable Percentage Inclusions
	public static boolean validateDifferentSection(String type,By xpath,String user,By comboBox, By addBtn, By percentField,String percentage1, String percentage2,By percFailMsg, 
			By sucMsg, By backgroundColor, By selectOption1,By selectOption2, By rmvLink, By anyTextField, 
			By percRowValue, By selectOptionFinal, By viewAllLink) throws Throwable{
		try{
			boolean flag=true;
			
			String comboSize=getAttribute(comboBox, "size", "");
			System.out.println(comboSize);
			if(comboSize.contains("5")){
				Reporters.SuccessReport("Profit Centers shows 5", "The scroll bar of of Centers shows 5 in alph	abetic order");
			}else{
				Reporters.failureReport("Profit Centers shows 5", "The scroll bar of Centers failed to show 5 in alphabetic order");
			}		
			
			
			String [] Values1=new String[5];
			List<WebElement> selectOptionData=driver.findElements(xpath);
			for(int i =0;i<5;i++)
			{
			  Values1[i]=selectOptionData.get(i).getText();  	
			//	System.out.println(option.getText());
			}				
			verifysort(Values1);
						
						
			/*//Validating the products...
			List<WebElement> ProductType=driver.findElements();
			for(int i =0;i<5;i++)
			{
			  Values1[i]=ProductType.get(i).getText();  	
			//	System.out.println(option.getText());
			}				
			verifysort(Values1,"Product Type");
				
			List<WebElement> MajorSubjectCode=driver.findElements();
			for(int i =0;i<5;i++)
			{
			  Values1[i]=MajorSubjectCode.get(i).getText();  	
			//	System.out.println(option.getText());
			}				
			verifysort(Values1,"Major Subject Code");
			*/
			
			isElementPresent(addBtn, "Add Button is present", driver.getCurrentUrl());
			click(addBtn, "Click on add button");
			Thread.sleep(medium);
			String msg=getText(percFailMsg, "");
			if(verifyText(percFailMsg, "Please select product group to add to the promotion.", "Select one or more inclusions from  the Profit Center")){
				Reporters.SuccessReport("The Error Message Validation", "The Error message : "+msg+" is displayed");	
			}else{
				Reporters.failureReport("The Error Message Validation", "The Error message : "+msg+" is failed to display");
			}
			Thread.sleep(medium);		
			//addProduct(ElsevierObjects.Evolve_Admin_Prmlnk_SelcOption,percentField, percentage , addBtn, 1);
			if(click(selectOption1, "Select any Option ")){
				Reporters.SuccessReport("Click on the any one product ", "Successfully Selected one product from the list");	
			}else{
				Reporters.failureReport("Click on the any one product ", "Failed to Select product from the list");
			}

		
			if(click(addBtn, "Click on add button")){
				Reporters.SuccessReport("Click on the add button", "Successfully Clicked on the add button");	
			}else{
				Reporters.failureReport("Click on the add button ", "Failed to Click on the add button");
			}
			String msg1=getText(sucMsg, "");
			if(verifyText(sucMsg, "The Promotion Inclusion is successfully saved. ", "Promotion Inclusions are successfully saved")){
				Reporters.SuccessReport("The Success Message Validation", "The Success message : "+msg1+" is displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The Success message : "+msg1+" is failed to display");
			}
			
			verifyBackGroundColor(backgroundColor);			
			isElementPresent(rmvLink, "Remove link", driver.getCurrentUrl());			
			//step 7			
			click(selectOption1, "Select any Option ");
			
			if(click(selectOption2, "Select any Option ")){
				Reporters.SuccessReport("Select any product from the list", "Successfully selected the product from the list");
			}else{
				Reporters.failureReport("Select any product from the list", "Failed to select the product from the list");
			}
			
			if(click(addBtn, "Click on add button")){
				Reporters.SuccessReport("Click on the add button", "Successfully Clicked on the add button");	
			}else{
				Reporters.failureReport("Click on the add button ", "Failed to Click on the add button");
			}
			if(verifyText(sucMsg, "The Promotion Inclusion is successfully saved. ", "Promotion Inclusions are successfully saved")){
				Reporters.SuccessReport("The Success Message Validation", "The Success message : "+msg1+" is displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The Success message : "+msg1+" is failed to display");
			}
			verifyBackGroundColor(backgroundColor);
			
			List<WebElement> element=driver.findElements(rmvLink);
			int getSize=element.size();
			for (int i = 1; i < getSize+1; i++) {
				String row1=getText(By.xpath(ElsevierObjects.remove1+i+ElsevierObjects.remove2), "");
				
				System.out.println(row1);
				if(row1.contains("remove")){
					System.out.println(row1);
					Reporters.SuccessReport("Validating the presence of Remove link", "Remove Link is present for each inclusion : "+row1);
				}else{

					Reporters.failureReport("Validating the presence of Remove link", "Remove Link is not present for each inclusion : "+row1);
				}
			}
			//Step 8			
			if(click(rmvLink, "")){
				Reporters.SuccessReport("Click on the remove link", "Successfully Clicked on the remove link. An Alert will be displayed");	
			}else{
				Reporters.failureReport("Click on the remove link", "Failed to Click on the remove link.");	
			}
			Thread.sleep(medium);
			Alert();	
			Thread.sleep(medium);
			if(click(rmvLink, "")){
				Reporters.SuccessReport("Click on the remove link", "Successfully Clicked on the remove link. An Alert will be displayed");	
			}else{
				Reporters.failureReport("Click on the remove link", "Failed to Click on the remove link.");	
			}
			
			Alert();	
			Thread.sleep(medium);
			//Step 9
			
			flag=iterate(type,user,selectOptionFinal, percentField, percentage1, addBtn, sucMsg, percRowValue, rmvLink, 5, anyTextField);

			flag= validateViewAll(viewAllLink, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_ViewNewPageMsg, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, VerifyText3,"");

			return flag;			
		}catch(Exception e){System.out.println(e.getMessage());return false;}
	}	

	public static boolean validateISBNSection() throws Throwable{
		try{
			boolean flag=true;
			
			flag=PromotionVariablePercentageExclusions_15581.validateISBNSection("",ElsevierObjects.Evolve_Admin_Prmlnk_ISBNtxt, ElsevierObjects.Evolve_Admin_Prmlnk_ISBNAdd, ElsevierObjects.Evolve_Admin_Prmlnk_ISBNErrMsg, 
					ElsevierObjects.Evolve_Admin_Prmlnk_IncSucMsg, ElsevierObjects.Evolve_Admin_Prmlnk_ISBNAddList, 
					ElsevierObjects.Evolve_Admin_Prmlnk_ISBNRem, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("InvalidISBN"));
			
			/*flag= validateViewAll(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNViewall, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_ViewNewPageMsg, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, VerifyText3,"isbnIncExclusion");
*/
			return flag;			
		}catch(Exception e){return false;}
	}

	//Validating the ISBN Upload Section
	public static boolean uploadCSVFile() throws Throwable{
		boolean flag=true;
		flag=PromotionVariablePercentageExclusions_15581.uploadCSVFile("", ElsevierObjects.Evolve_Admin_Prmlnk_ISBNBrowse, 
				ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplBtn, ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplSucMsg);
		flag=PromotionVariablePercentageExclusions_15581.removeVerify(ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplRemlnk, ElsevierObjects.remove8, ElsevierObjects.remove9);
		
		flag= validateViewAll(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNViewall, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_ViewNewPageMsg, 
				ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
				ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, VerifyText3,"");

		
		Thread.sleep(medium);
		return flag;
	}
	
	



		}


