package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Actiondriver;

public class SampleReports extends Actiondriver{
	
@Test
public void test() throws Throwable{
//ElsevierObjects.adminBrowserType="firefox";
//ElsevierObjects.studentBrowserType="Chrome";
	Reporters.SuccessReport("pass", "");
	//Reporters.failureReport("fail", "");
	Reporters.SuccessReport("hi", "");
	//Reporters.failureReport("fail", "");
}

}
