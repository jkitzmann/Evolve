package com.cigniti.automation.BusinessFunctions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;
import com.thoughtworks.selenium.webdriven.commands.IsEditable;

public class Rosteredstudentredeemsaccesscode_10433 extends EvolveCommonBussinessFunctions {
	
	public static String Isbn;
	public static String CodeSetName;
	public static String Codesetnumber;
	public static String Accesscode;
	public static String Username;
	public static String Password;
	public static String CoursId;
	
	public static boolean RedeemaccessinAdmin() throws Throwable{
		try
		   {
		    boolean flag = true;
		    b=true;
		    click(ElsevierObjects.admin_MaintainProduct_lnk,"Maintain Products");
			Thread.sleep(medium);
			type(ElsevierObjects.admin_MaintainProduct_Knotxt,Isbn,"Enter Isbn number in product page </br>" +Isbn);
			Thread.sleep(medium);
			click(ElsevierObjects.admin_MaintainProduct_Submit,"Search button");
			Thread.sleep(medium);
			click(ElsevierObjects.MaintainPrdct_prdctSerachReslut_isbn,"ISBN Number in the product Result page");
			Thread.sleep(medium);
			click(ElsevierObjects.createAccessCode, "Create Access Codes tab");
			b=false;
			//verify
			String SchemeId = getText(ElsevierObjects.Protection_scheme_id,"Get Protection SchemeId");
			if(protectionScheme.equalsIgnoreCase(SchemeId)){
				Reporters.SuccessReport("Verify Protection SchemeId","Protection SchemeId is Successfully verified");
			}else{
				Reporters.failureReport("Verify Protection SchemeId","Failed to verify Protection SchemeId");
			}
			b=true;
			type(ElsevierObjects.CreateAccessCode_codesetname,CodeSetName,"Enter Code Set Name "+CodeSetName); 
			Thread.sleep(low);
			type(ElsevierObjects.CreateAccessCode_codeNumber, Codesetnumber,"Enter Number to Generate "+Codesetnumber);
			Thread.sleep(low);
			click(ElsevierObjects.CreateAccessCode_Submit, "Create Access Code Save button");
			Thread.sleep(low);
			b=false;
			String SuccMsg = getText(ElsevierObjects.Reedem_success_Msg,"Get Success Message");
			if(SuccMsg!=null){
				Reporters.SuccessReport("Verify Success message","Success Message is verified Successfully and it is <br> "+SuccMsg);
			}else{
				Reporters.failureReport("Verify Success message","Failed to verify Success message");
			}
			Thread.sleep(low);
			b=true;
			click(ElsevierObjects.Manage_access_codes,"Manage Access Codes tab");
			Thread.sleep(low);
			click(By.xpath(".//*[@id='anchoracsinfo'][contains(text(),'"+CodeSetName+"')]"),"Access Code Set name that matches the set created");
			b=false;
			Accesscode = getText(ElsevierObjects.Reedem_Access_code,"Get the first access code in this set");
			if(Accesscode!=null){
				Reporters.SuccessReport("Get first Access code in this set","Successfully first access code in this set is taken and it is: "+Accesscode);
			}else{
				Reporters.failureReport("Get first Access code in this set","Failed to get first access code in this set");
			}
			System.out.println(Accesscode);
			return flag;}
	        catch(Exception e){return false;} 
	   }
		
	 public static boolean Studentlogin() throws Throwable{
		 try
		    {
		     boolean flag = true;
			 launchUrl(configProps.getProperty("URL4"));
			 Thread.sleep(medium);
			 //clickOnMainPageLink();
			/* Thread.sleep(low);
			 click(ElsevierObjects.iamstudent,"Click on student");
			 Thread.sleep(low);*/
			 b=true;
			 click(ElsevierObjects.Student_Home_Login,"Login button");
			 Thread.sleep(low);
			 type(ElsevierObjects.common_login_userName,Username,"Enter username");
			 Thread.sleep(low);
			 type(ElsevierObjects.common_login_passWord,Password,"Enter Password");
			 Thread.sleep(low);
			 b=false;
			 if(click(ElsevierObjects.submit,"Click on login button")){
				   Reporters.SuccessReport("Click on login", "User is Successfully login with the created student details");
			 }else{
					   Reporters.failureReport("Click on login", "User is failed to login with the created student details");
			 }
			 Thread.sleep(low);
			 b=true;
			 click(ElsevierObjects.Myevolve,"My Evolve");
			 Thread.sleep(low);
			 b=false;
			 String Id = getText(ElsevierObjects.Roster_Evolve_CourseId,"Get Unique CourseId");
			 if(Id.contains(CoursId)){
				 Reporters.SuccessReport("Verify Unique CourseId","User is Successfully verified CourseId </br>"+Id);
			 }else{
				 Reporters.failureReport("Verify Unique CourseId","User is failed to verify CourseId");
			 }
			 Thread.sleep(low);
			 String Courselink = getText(ElsevierObjects.Roster_Evolve_Courselink,"Get Unique CourseId link");
			 if(Courselink!=null){
				  Reporters.SuccessReport("Verify Unique CourseId link","User is Successfully verified CourseId link </br>" +Courselink);
			 }else{
				  Reporters.failureReport("Verify Unique CourseId link","User is failed to verify CourseId link");
			 }
			 Thread.sleep(low);
			 b=true;
			 click(ElsevierObjects.Roster_Evolve_Courselink,"Unique CourseId link");
			 Thread.sleep(low);
			 b=false;
			 if(waitForElementPresent(ElsevierObjects.educator_CoursePage_LockIcon, "Verify Lock Icon present or not.")){
	             Reporters.SuccessReport("Verifying Course Library Link And Lock Icon Are present in Course Content Menu.", "Verified Course Library Link And Lock Icon In Course Content Menu.");
	         }else{
	             Reporters.failureReport("Verifying Course Library Link And Lock Icon Are present in Course Content Menu.", "Failed To Verify Course Library Link And Lock Icon In Course Content Menu.");
	         }
			 Thread.sleep(medium);
	         if(click(ElsevierObjects.educator_CoursePage_Courselink, "Click on course link present in course details page.")){
	               Reporters.SuccessReport("Clicking On Course Link.", "Clicked On Course Link In content menu.");
	         }else{
	               Reporters.failureReport("Clicking On Course Link.", "Failed To Click On Course Link In content menu.");
	         }
	         Thread.sleep(medium);
			 String Protect = getText(ElsevierObjects.Protected_content,"Get title of Protected Content");
			 if(Protect!=null){
				   Reporters.SuccessReport("Verify title of Protected Content","User is Successfully Clicked on the protected course folder and shows a popup window to purchase the course via access code or via credit card");
			 }else{
				   Reporters.failureReport("Verify title of Protected Content","User is failed to Click on the protected course folder and shows a popup window to purchase the course via access code or via credit card");
			 }
			 Thread.sleep(low);
			 b=true;
			 type(ElsevierObjects.redeem_AcessCode_txt,Accesscode,"Enter Access Code in the textbox");
			 Thread.sleep(low);
			 click(ElsevierObjects.Reedem_button,"Reedem button");
			 Thread.sleep(medium);
			 b=false;
			 Thread.sleep(medium);
	         if(click(ElsevierObjects.educator_CoursePage_Courselink, "Click on course link present in course details page.")){
	                Reporters.SuccessReport("Clicking On Course Link.", "Clicked On Course Link In content menu.");
	         }else{
	               Reporters.failureReport("Clicking On Course Link.", "Failed To Click On Course Link In content menu.");
	         }
	         Thread.sleep(medium);
			 List<WebElement> s=driver.findElements(ElsevierObjects.educator_CoursePage_SubFolders);
				  for(WebElement subFolder:s){
			 if(waitForElementPresent(ElsevierObjects.educator_CoursePage_SubFolders, "Course folder contains sub folders.")){
				   Reporters.SuccessReport("Verifying subfolders.", "Verified Subfolders of Course Folder and any subfolder can be clicked on without seeing the access code prompt anymore.</br>SubFolder is:"+subFolder.getText());
			 }else{
				   Reporters.failureReport("Verifying subfolders.", "Failed To Verify Subfolders of Course Folder.");
			 }
		   }
		    String title = getText(ElsevierObjects.course_title,"Get the Course Title");
		     
		      Actions actions = new Actions(driver);
		      WebElement tableContent = driver.findElement(ElsevierObjects.course_title);

		      actions.doubleClick(tableContent).build().perform();
		      Thread.sleep(high);
		     if(isEnabled(ElsevierObjects.course_title,"Get the Course Title")){
		    	Reporters.SuccessReport("Verify the Course title is Editable or not","The Course title does not become editable ");
		    }else{
		    	Reporters.failureReport("Verify the Course title is Editable or not","The Course title is editable ");
		    }
			 EvolveCommonBussinessFunctions.instructorLogout();
			 return flag;}
			 catch(Exception e){return false;}
	    }
	}

