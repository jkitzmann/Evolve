package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.HESI_BusinessFunction;
import com.cigniti.automation.BusinessFunctions.HESI_Student_login_8567;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;

public class  HESI_Student_login_Script_8567 extends HESI_Student_login_8567 {
  @Test
  public void HESI_Student_login_8567() throws Throwable {
	 
		   SwitchToBrowser(ElsevierObjects.studentBrowserType);
		   Country=ReadingExcel.columnDataByHeaderName("Country", "TC-8567",configProps.getProperty("TestData"));
		   State=ReadingExcel.columnDataByHeaderName("State", "TC-8567",configProps.getProperty("TestData"));
		   City=ReadingExcel.columnDataByHeaderName("City", "TC-8567",configProps.getProperty("TestData"));
		   Institute=ReadingExcel.columnDataByHeaderName("InstitutionName","TC-8567",configProps.getProperty("TestData"));
		   Programtype=ReadingExcel.columnDataByHeaderName("Programtype","TC-8567",configProps.getProperty("TestData"));
		   Year=ReadingExcel.columnDataByHeaderName("YearofGraduation","TC-8567",configProps.getProperty("TestData"));
		
		  
		   String user = "student";
		   stepReport("Create new student user");
		   writeReport(EvolveCommonBussinessFunctions.CreateNewUser(user),"Login to application as a student",
				                                                          "Successfully the EvolveCert URL Launched and new student user is created <br>" +EvolveCommonBussinessFunctions.credentials[0],
				                                                          "Failed to launch the URL and create a new student user");
		   writeReport(HESI_BusinessFunction.getAccountDetails("studentUpdate"), "Fetching Account Details From MyAccount Page.", 
					"Successfully Fetched Username: "+getAccountDetailsUserName+"</br>Successfully Fetched FirstName: "+getAccountDetailsFirstName+"</br>Successfully Fetched Lastname: "+getAccountDetailsLastName+"</br>Successfully Fetched Email: "+getAccountDetailsEmail+"</br>Successfully Fetched Institution: "+getAccountDetailsInstitution+"</br>Successfully Fetched PhoneNumber: "+getAccountDetailsPhone+"</br>Successfully Fetched StreetAdreess: "+ getAccountDetailsStreetAddress, 
					"Failed to Fetch Account Details From MyAccount Page. ");
			
		   stepReport("Register for HESI as new student");
		   HESI_Student_login_8567.HesiRegistration();
		   
		   Thread.sleep(veryhigh);
		   stepReport("Verify HESI email");
		   EvolveCommonBussinessFunctions.HesiEmailVerification();
     }
  }
