package com.cigniti.automation.BusinessFunctions;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.FileReader;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import com.cigniti.automation.Utilities.Property;

//ACP-Access Code Package Module
public class AccessCodePackageUnassignedAccessCreation_10212 extends EvolveCommonBussinessFunctions{

	//Create a reference variable for robot class		
	public static boolean extFileCountAndVerify() throws Throwable{
		boolean flag = true;
		try{
		String sCurrentLine;
		Property configProps=new Property("config.properties");
		BufferedReader br = null;
		int FinalCount = 0;
			try {
				int count=0;								
				br = new BufferedReader(new FileReader(readcolumns.twoColumns(0, 1, "TC-10212", configProps.getProperty("TestData")).get("textfilepath")));
				while ((sCurrentLine = br.readLine()) != null) { 
					count++;
				}
				FinalCount=count;
				System.out.println(count);
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					if (br != null)br.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}	
		Reporters.SuccessReport("The No. of Access Code Generation", "Access Code Count generated : "+FinalCount+"<br> Expected Count is : "+FinalCount +"<br> Actual Count is : "+FinalCount);
		System.out.println("the total no. of lines are :"+FinalCount);
	}catch(Exception e){
		sgErrMsg=e.getMessage();return false;
	}
		return flag;
	} 
}



