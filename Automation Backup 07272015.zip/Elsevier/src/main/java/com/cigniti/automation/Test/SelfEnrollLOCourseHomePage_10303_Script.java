package com.cigniti.automation.Test;


import java.nio.channels.GatheringByteChannel;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.Evolve_StudentLogin_9795;
import com.cigniti.automation.BusinessFunctions.SelfEnrollLOCourseHomePage_10302;
import com.cigniti.automation.BusinessFunctions.SelfEnrollLOCourseHomePage_10303;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.WritingExcel;

public class SelfEnrollLOCourseHomePage_10303_Script extends SelfEnrollLOCourseHomePage_10303{
	
	@Test
	public void SelfEnrollLOCourseHomePage10303() throws Throwable{
    String courseid, isbn, title;
	try{
		//Step 1:Complete test cases:  LO Unique Course Fulfillment-Faculty and capture the product id
		LO_Unique_CourseFulfillment_Faculty_Script_10410 k=new LO_Unique_CourseFulfillment_Faculty_Script_10410();
		k.loUniqueCoursefulfillmentFaculty_10410();
		
		//un-comment below line to run without step1 for debugging purpose
		//courseid="104882_einstein_1083";
		courseid=EvolveCommonBussinessFunctions.courseID1;
		ReadingExcel.updateCellInSheet(1, 2, testDataPath, "Tc-10437", courseid);
		
		isbn=EvolveCommonBussinessFunctions.adoptionRequest_Isbn;
		//un-comment below line to run without step1 for debugging purpose
		//isbn="9780323055536";
		
		title=EvolveCommonBussinessFunctions.title;
		//un-comment below line to run without step1 for debugging purpose
		//title="Medical Terminology Online for Mastering Healthcare Terminology";
		testCaseName ="SelfEnrollLOCourseHomePage_10303_Script";
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		
		//Step 2:Create Student User from Student Page 
		writeReport(EvolveCommonBussinessFunctions.CreateNewUser("student"),"Creating Student User From Student Page.", 
					"Successfuully Created New Student User Username:"+credentials[0]+",Password:"+credentials[1]+"</br>User Now logged Into Evolve Cert As A Student.",
					"Failed To Create New Student User.");
		
		ReadingExcel.updateCellInSheet(1, 0, testDataPath, "Tc-10437",credentials[0]);
		ReadingExcel.updateCellInSheet(1, 1, testDataPath, "Tc-10437",credentials[1]);
		
		//Step 3:In the product search bar, type in the ISBN associated with the course ID in Step #1.
		//Click the button that says "Self Enroll into your Instructor's Course"
		//HESI_Search user business 
		EvolveCommonBussinessFunctions.verifyHoneyPot();
				
		//Step 4:Enter the course ID from Step #1 and submit.
		//get serach number from step1 excel
		//Step 5: Verify the correct self enrollment course info displays in the cart.
		SelfEnrollLOCourseHomePage_10302.selfEnrollNavigate(courseid,isbn,title);
		
		//Step6 : On "My Cart" page, select the radio button to pay with credit card.  Press "Checkout". 
		
		SelfEnrollLOCourseHomePage_10303.verifyMyCart();
		
		String courseId="Course ID";
		SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentCourseInfo(courseID1, courseId);
		
		String Title="Title";
		SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentCourseInfo(newTitle,Title);
		
		String firstname="FirstName";
		String educatorName=getAccountDetailsFirstName+" "+getAccountDetailsLastName;
		String FirstName=getAccountDetailsFirstName;
		SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentFacultyName(educatorName, FirstName,firstname);
		
		String lastname="Lastname"; 
		String LastName=getAccountDetailsLastName;
		SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentFacultyName(educatorName,LastName, lastname);
		
		String institutionName=getAccountDetailsInstitution;
		String Institution="Institution";
		SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentCourseInfo(institutionName, Institution);
		
		SelfEnrollLOCourseHomePage_10303.verifyCheckout();
		
		//Step7&8 verify review/submit checkout, Address validation popup
		EvolveCommonBussinessFunctions.updateVSTandKNOAccount("student","","false","");
		
		//Step 9 and 10:Enter credit card details , Review and Submit
		String creditCardType=ReadingExcel.columnDataByHeaderName("cardType", "TC-15597", configProps.getProperty("TestData"));
		String creditCardNum=ReadingExcel.columnDataByHeaderName("cardNumber", "TC-15597", configProps.getProperty("TestData"));
		String creditCardCvv=ReadingExcel.columnDataByHeaderName("cardCVV", "TC-15597", configProps.getProperty("TestData"));
		String creditCardName=ReadingExcel.columnDataByHeaderName("cardName", "TC-15597", configProps.getProperty("TestData"));
		String creditCardExpYr=ReadingExcel.columnDataByHeaderName("cardExpYear", "TC-15597", configProps.getProperty("TestData"));
		String creditCardExpMnth=ReadingExcel.columnDataByHeaderName("cardExpMonth", "TC-15597", configProps.getProperty("TestData"));
		
		SelfEnrollLOCourseHomePage_10303.creditCardData(creditCardType,creditCardNum,creditCardCvv,creditCardName,creditCardExpMnth,creditCardExpYr);
		
		Thread.sleep(veryhigh);
		SelfEnrollLOCourseHomePage_10303.StudentReviewandSubmit();
		
		Thread.sleep(veryhigh);
		SelfEnrollLOCourseHomePage_10303.verifyReceiptPage();
		
		//Step 11 : Click on My evolve and chk the course id appears under 0content list
		SelfEnrollLOCourseHomePage_10303.verifyMyEvolveCourseId();
		
		//step 13: click on the library folder titled course
		SelfEnrollLOCourseHomePage_10303.verifyCoursePage();
		
		//Step 14: Logout of evlove cert and login as admin
		writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the Student page.", 
				"Successfully logged out the Student:"+credentials[0], 
				"Failed to logout the Student page:"+credentials[0]);
	
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login to Application Using Admin Credentials:"+adminUser,
				"Launching the URL for Admin is successfull </br > Login to Application Using Admin credentials :"+adminUser+" is Successfull", 
				"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");
	
		String Accesscode="false";
		EvolveCommonBussinessFunctions.verifyCoursePARReport(courseid,Accesscode);
		//Step 15 : course validation in Evolve Admin link
		EvolveCommonBussinessFunctions.verifyMyEvolveAdmin(courseid);
		
		writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout as "+adminUser,
				"Successfully logged out admin page.", 
			  	"Failed to logout admin page.");
		
	}catch(Exception e){
		System.out.println(e.getMessage());
	}
	
	}
	/*@AfterClass
	public static void browserStop()
	{
		driver.close();
	}*/
	
	
}
