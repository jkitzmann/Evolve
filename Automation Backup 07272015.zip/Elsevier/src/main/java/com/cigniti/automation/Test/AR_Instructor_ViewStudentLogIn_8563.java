package com.cigniti.automation.Test;

import java.util.Arrays;
import java.util.Random;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.AR_BusinessFunction;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.Instructor_ViewStudentLogIn_8563;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;
public class AR_Instructor_ViewStudentLogIn_8563 extends Instructor_ViewStudentLogIn_8563{
	Random ra = new Random( System.currentTimeMillis() );
	@Test
	public void AR_InstructorViewStudentLogIn_8563() throws Throwable{
	
	//	try 
		{
			//ElsevierObjects.studentBrowserType="firefox";
		   // HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		  writeReport(SwitchToBrowser(ElsevierObjects.studentBrowserType),"Launching Browser to Portal User","Launching Browser to Portal User is succesful","Lanching Browser to Portal User is failed");
			
			String Catalogs=ReadingExcel.columnDataByHeaderName("ISBN", "AR_Inputs", configProps.getProperty("TestData"));
			String StudentUsername=ReadingExcel.columnDataByHeaderName("StudentUsername", "AR_Inputs", configProps.getProperty("TestData"));
			String StudentPassword=ReadingExcel.columnDataByHeaderName("StudentPassword", "AR_Inputs", configProps.getProperty("TestData"));
		
			stepReport("Go to Evolve Educator homepage.");
			writeReport(User_BusinessFunction.LaunchEducator(),"Launch URL navigate to Educator View",
                    "Launching the URL as Educator is successful </br > Navigate to Educator View is Successful",
                    "Launching the URL as Educator is Not successful or </br > Navigate to Educator View is Not Successful");
			Thread.sleep(low);
		    Thread.sleep(medium);
		
			stepReport("Add Online Course to cart.");
		    writeReport(User_BusinessFunction.SearchCatalog(Catalogs),"Searching for Value:"+Catalogs,
		                                                                   "Entered "+Catalogs+" to Search </br > Click on Go Button ",
		                                                                   "Unable to Search for : "+ Catalogs);
		    Thread.sleep(medium);	
		    
		    writeReport(User_BusinessFunction.VerifyISBN(Catalogs), "Verify User Navigated to Product Results Page", "Page Navigate to Product Results Page of ISBN :"+Catalogs, "Page Not Navigated to Product Results Page of ISBN:"+Catalogs);
		    writeReport(AR_BusinessFunction.addToCart(),"Add the product from results to cart ", "Successfully Added the "+Catalogs+" product to cart </br> The Product :"+Catalogs+" Price is verified and the Current Price is $0.00",  "Failed to Add the product to cart, Due to Price is greater than 0.00$ or "+sgErrMsg);
			
		    stepReport("Login as a student user.");
		    writeReport(AR_BusinessFunction.studentLogin(StudentUsername,StudentPassword),"Login As Student User", " Login as Student User is Successful ", "Login as Student User is Failed");
			
		    stepReport("Complete checkout.");
		    writeReport(AR_BusinessFunction.reviewAndSubmit(),"Reviewing the Order  and  Clicking on Submit:", "Check box  'Yes, I am an instructor' is Present in the page </br> Check Box 'Yes, I accept the Registered User Agreement' is Present in the page</br></br> The Product :"+Catalogs+" Price is verified and the Current Price is $0.00</br> Total Price is: $0.00 </br> The Order  Successfully Reviewed and Submitted</br>The Confirmed Order Number is :"+Ordernumber,  "The Order Failed to Review and Submit");
			writeReport(AR_BusinessFunction.getUsernameandDetails(), "Fetching Account Details From MyAccount Page.", 
					"Successfully Fetched FirstName: "+getAccountDetailsFirstName+"</br>Successfully Fetched Last name: "+getAccountDetailsLastName, 
					"Failed to Fetch Account Details From MyAccount Page. ");
			writeReport(instructorLogout(),"LogOut as Student User", "Student Loged Out Successfully","Student Log out Failed.");
			Thread.sleep(high);
			
			stepReport("Login to Evolve Admin");
			writeReport(SwitchToBrowser(ElsevierObjects.adminBrowserType),"Launching Browser for Admin User","Launching Browser for Admin User is succesful","Lanching Browser for Admin User is failed");
			writeReport(evolveAdminlogin(),"Admin login ", "Admin Login is Successful","Admin Login is failed");
			
			stepReport("Search for adoption request");
			writeReport(AR_BusinessFunction.clickAdoptionRequest(getAccountDetailsUserName),"Click on the AR","AR Search results page is displayed","AR Search results page are not displayed");
			Thread.sleep(medium);
			String AliasName=getAccountDetailsLastName+", "+getAccountDetailsFirstName;
         	String[] Headers = {"Name","Status"};
			
			String[] resultsassertions = {AliasName,"Pending"};
			///Thread.sleep(40000);
			
			writeReport(AR_BusinessFunction.VerifyContentByUsingHeadertitleforTableandclick(ElsevierObjects.Admin_ArResults,Headers,resultsassertions), "Verifying the Status of Adoption Request Results:",
                    "In Results, The Values Under The Title:"+Arrays.toString(Headers)+" And </br> Values: "+Arrays.toString(resultsassertions)+"are Maching as Expected", 
                    "In Results, The Values Under The Title:"+Arrays.toString(Headers)+" And </br> Values: "+Arrays.toString(resultsassertions)+"are Not Maching as Expected");
            Thread.sleep(medium);

            stepReport("Verify adoption request details");
            writeReport(AR_BusinessFunction.verifyAdoptionRequestpage(Catalogs,"Evolve Unique Course - LO",getAccountDetailsFirstName,getAccountDetailsLastName), "Verify the Adoption Request Detailes page", "The Detailed Adoption Request Page  Displayed below mentioned : </br>"+sActualValues+"</br> are as Expected", "The Detailed Adoption Request Page  Displayed below mentioned : </br>"+sActualValues+"</br> are not as Expected, Hence Test case is Failed");			Thread.sleep(medium);
			writeReport(adminLogout(),"Clicked on Logout","Successfully Clicked on Logout","Not Clicked on Logout ");
		  
		}	
		
	} 
	@AfterTest
	public void tear() throws Throwable{
		
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
	
