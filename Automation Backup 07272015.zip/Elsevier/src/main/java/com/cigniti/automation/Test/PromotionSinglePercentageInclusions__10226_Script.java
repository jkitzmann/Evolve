package com.cigniti.automation.Test;

import java.util.Random;

import jxl.Sheet;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.PromotionSinglePercentageInclusions_10226;
import com.cigniti.automation.BusinessFunctions.PromotionVariablePercentageInclusions_10227;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class PromotionSinglePercentageInclusions__10226_Script extends PromotionSinglePercentageInclusions_10226 {
	
	public static String DMCodeForUse;
	//**************************** Declarations *****************************************************
 	public static Sheet inputSheetObj =null;
 	 // Input sheet file name
 	Random ra = new Random( System.currentTimeMillis() );
 	String condition="exclusions";
	@Test
	public void promotionSinglePercentageInclusions_10226() throws Throwable
		{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		String DMCode=ReadingExcel.columnDataByHeaderName("DMcode", "PromotionTestData",configProps.getProperty("TestData"))+Integer.toString((1 + ra.nextInt(2)) * 100000 + ra.nextInt(100000));
		String PromotionCode=ReadingExcel.columnDataByHeaderName("PromotionCode", "PromotionTestData",configProps.getProperty("TestData"));
		String DiscountType=ReadingExcel.columnDataByHeaderName("DiscountType2", "PromotionTestData",configProps.getProperty("TestData"));
		String CampaignCode=ReadingExcel.columnDataByHeaderName("CampaignCode", "PromotionTestData",configProps.getProperty("TestData"));
		String PromotionName=ReadingExcel.columnDataByHeaderName("PromotionName", "PromotionTestData",configProps.getProperty("TestData"));
		String TerritoryCode=ReadingExcel.columnDataByHeaderName("TerritoryCode", "PromotionTestData",configProps.getProperty("TestData"));
		String percentageOff=ReadingExcel.columnDataByHeaderName("PercentageOff", "PromotionTestData",configProps.getProperty("TestData"));
		String percentageOff1=ReadingExcel.columnDataByHeaderName("PercentageOff1", "PromotionTestData",configProps.getProperty("TestData"));
		String invalidPercentage=ReadingExcel.columnDataByHeaderName("invalidPercentage", "PromotionTestData",configProps.getProperty("TestData"));
		String percentage=ReadingExcel.columnDataByHeaderName("percentage", "PromotionTestData",configProps.getProperty("TestData"));		
		
		DMCodeForUse=DMCode;
		
		writeReport(evolveAdminlogin(),"Login to Application Using Admin Credentials :"+adminUser,
                "Launching the URL for Admin Credentials is successful </br > Login to Application Using Admin Credentials :"+adminUser+" is Successful",
                   "Launching and Login to Application Using Admin Credentials : "+ adminUser+" is Failed");
		
		Thread.sleep(medium);
		PromotionVariablePercentageInclusions_10227.addPromotionLink();
		Thread.sleep(medium);
		
		writeReport(PromotionVariablePercentageInclusions_10227.validatePromotionCodeValues(),  "Validate all elements in the Promotion Code Section", "Promotion Code Section elements are validated", "Promotion Code Section elements validation failed");
		Thread.sleep(medium);
		String user="singlePercentage";
		
		writeReport(PromotionVariablePercentageInclusions_10227.inputValuesInPromotionCode(user,DMCode, "", "", DiscountType, "", PromotionName, TerritoryCode, percentageOff),  
				"Input all the values in Field and Create a Promotion", 
				"Validating the input values is successful and Successfully added a promotion with DM Code : "+DMCode, 
				"Validating the input values is failed and failed to create a promotion");
		Thread.sleep(medium);
		validateIncludeAllProducts();
		String type="";
		Reporters.SuccessReport("Validating Profit Center section Products", "Validating the Profit center section products in the below steps");
		writeReport(PromotionSinglePercentageInclusions_10226.validateDifferentSection("",ElsevierObjects.xpathProfitcenter,condition,ElsevierObjects.Evolve_Admin_Prmlnk_PrtCetr, 
				ElsevierObjects.Evolve_Admin_Prmlnk_AddIncludeBtn, 	ElsevierObjects.Evolve_Admin_Prmlnk_PerFld, percentageOff, 
				percentageOff1,ElsevierObjects.Evolve_Admin_Prmlnk_PrtCetrFailMsg, 
				ElsevierObjects.Evolve_Admin_Prmlnk_IncSucMsg, ElsevierObjects.Evolve_Admin_Prmlnk_IncAdded, 
				ElsevierObjects.Evolve_Admin_Prmlnk_SelcOptionFinal,ElsevierObjects.Evolve_Admin_Prmlnk_SelcOption2, 
				ElsevierObjects.Evolve_Admin_Prmlnk_RemvLink, ElsevierObjects.Evolve_Admin_Prmlnk_EndDate, 
				ElsevierObjects.Evolve_Admin_Prmlnk_PercValue, ElsevierObjects.Evolve_Admin_Prmlnk_SelcOptionFinal, ElsevierObjects.Evolve_Admin_Prmlnk_ViewAllLnk),
				"Validate Include all Product Section","All Products in Profit Center Section are validated successfully", 
				"Include all Products in Profit Center Product Section validation failed");
		Thread.sleep(medium);
		
		Reporters.SuccessReport("Validating Major Subject Code section Products", "Validating Major Subject Code sectioni products in the below steps");
		writeReport(PromotionSinglePercentageInclusions_10226.validateDifferentSection("",ElsevierObjects.xpathMajorSubjectCode,condition,ElsevierObjects.Evolve_Admin_Prmlnk_MjrCombo, 
				ElsevierObjects.Evolve_Admin_Prmlnk_MjrAdd, 	ElsevierObjects.Evolve_Admin_Prmlnk_MjrPerFld, percentageOff, 
				percentageOff1, ElsevierObjects.Evolve_Admin_Prmlnk_PrtCetrFailMsg, 
				ElsevierObjects.Evolve_Admin_Prmlnk_IncSucMsg, ElsevierObjects.Evolve_Admin_Prmlnk_MjrBckGrnd, 
				ElsevierObjects.Evolve_Admin_Prmlnk_MjrOption1,ElsevierObjects.Evolve_Admin_Prmlnk_MjrOption2, 
				ElsevierObjects.Evolve_Admin_Prmlnk_MjrRemLnk, ElsevierObjects.Evolve_Admin_Prmlnk_EndDate, 
				ElsevierObjects.Evolve_Admin_Prmlnk_MjrPercValue, ElsevierObjects.Evolve_Admin_Prmlnk_MjrSelFinal, ElsevierObjects.Evolve_Admin_Prmlnk_MjrViewAll),
				"Validate Major Subject Code Section", "Include all Products in Profit Center Product Section are validated is successfully", 
				"Include all Products in Profit Center Product Section validation failed");
		Thread.sleep(medium);
		Reporters.SuccessReport("Validating Product type Center section ", "Validating the product type center section in the below steps");
		writeReport(PromotionSinglePercentageInclusions_10226.validateDifferentSection("",ElsevierObjects.xpathProductType,condition,ElsevierObjects.Evolve_Admin_Prmlnk_PrdCombo, 
				ElsevierObjects.Evolve_Admin_Prmlnk_PrdAdd, 	ElsevierObjects.Evolve_Admin_Prmlnk_PrdPerFld, percentageOff, 
				percentageOff1,ElsevierObjects.Evolve_Admin_Prmlnk_PrtCetrFailMsg, 
				ElsevierObjects.Evolve_Admin_Prmlnk_IncSucMsg, ElsevierObjects.Evolve_Admin_Prmlnk_PrdBckGrnd, 
				ElsevierObjects.Evolve_Admin_Prmlnk_PrdOption1,ElsevierObjects.Evolve_Admin_Prmlnk_PrdOption2, 
				ElsevierObjects.Evolve_Admin_Prmlnk_PrdRemLnk, ElsevierObjects.Evolve_Admin_Prmlnk_EndDate, 
				ElsevierObjects.Evolve_Admin_Prmlnk_PrdPercValue, ElsevierObjects.Evolve_Admin_Prmlnk_PrdSelFinal, ElsevierObjects.Evolve_Admin_Prmlnk_PrdViewAll),
				"Validate Product Type Section", "Include all Products in Product Type Section are validated successfully", 
				"Include all Products in Product Type Section validation failed");
		
		Thread.sleep(medium);
		Reporters.SuccessReport("Validating ISBN section ", "Validating the ISBN section in the below steps");
		writeReport(PromotionSinglePercentageInclusions_10226.validateISBNSection(),
				"Validate ISBN Section", "Include all Products in ISBN Section are validated is successfully", 
				"Include all Products in ISBN Section validation failed");
		
		Thread.sleep(medium);
		Reporters.SuccessReport("Validating ISBN Upload section ", "Validating the ISBN Upload section in the below steps");
		PromotionSinglePercentageInclusions_10226.uploadCSVFile();
		
		Reporters.SuccessReport("DM Code for future use : "+DMCodeForUse, "DM Code : "+ DMCodeForUse +" is successfully saved for future use : ");
		writeReport(EvolveCommonBussinessFunctions.adminLogout(),"Clicking on Logout",
                 "Clicking on Logout is Successful",
                 "Clicking on Logout is not Successful");
		
		//Thread.sleep(medium);
		//writeReport(PromotionVariablePercentageInclusions.validateSelectAllProducts(),  "Select All Products", "Select All Products section validation is successful", "Select All Products section validation failed");
		//Validating the ISBN Section
		
		}		
	
@AfterClass
	public static void browserStop() throws Throwable
	{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		//Base.tearDown();
	}
}
