package com.cigniti.automation.BusinessFunctions;



import java.util.List;

import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Test.PromotionRedeemSinglePercentageOff_10229_Script;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class PromotionRedeemSinglePercentageOff_10229 extends EvolveCommonBussinessFunctions{
	public static float ppf;
	/*public static String isbnForFutureUse1;
	public static String isbnForFutureUse2;
	public static String isbnForFutureUse3;
	public static String isbnForFutureUse4;

	public static String titleforfutureuse1;
	public static String titleforfutureuse2;
	public static String titleforfutureuse3;
	public static String titleforfutureuse4;

	public static String priceforfutureuse1;
	public static String priceforfutureuse2;
	public static String priceforfutureuse3;
	public static String priceforfutureuse4;*/

	//public static String ISBNTitle3;
	
	public static String dmcodeforuse;
	/*Click on the ISBN title on the promotion marketing page.
	 * 
	 */
	
	public static boolean clickOnTitle() throws Throwable{
		try{
			boolean flag=true;
			click(ElsevierObjects.Promotion_Redeem_title, "Click on the ISBN title on the promotion marketing page.");
			return flag;
		}catch(Exception e){System.out.println(e.getMessage());return false;}
	}
	
	public static boolean titleClickAndVerify(float discount) throws Throwable
	{
		try
		{
			boolean flag = true;

			//Get the Product Title, Product ISBN and Product Price
			String productTitle=getText(ElsevierObjects.marketingPageSinglePercentage_Title, "Get the title of the Book");
			System.out.println(productTitle);

			String productISBN=getText(ElsevierObjects.marketingPageSinglePercentage_ISBN, "Get the ISBN Value for future Use");
			System.out.println(productISBN);

			ppf=convertPrice(ElsevierObjects.marketingPageSinglePercentage_DiscountPrice);
			/*String productPrice=getText(ElsevierObjects.marketingPageSinglePercentage_DiscountPrice, "Get the Price of the Book");
			//float productPrice1=convertPrice(ElsevierObjects.marketingPageSinglePercentage_DiscountPrice);
			String pp=productPrice.replace("$", "");
			float ppf=Float.parseFloat(pp);*/
			System.out.println(ppf);


			//Get the Product title, product ISBN and Product price from the ISBN#3
			String ISBNTitle3=Promotion_CreatePromotionMarketingPageSinglePercentage_15582.titleforfutureuse3;
			String ISBN_isbn3=Promotion_CreatePromotionMarketingPageSinglePercentage_15582.isbnForFutureUse3;
			String ISBNPrice=Promotion_CreatePromotionMarketingPageSinglePercentage_15582.priceforfutureuse3;
			String ISBNPrice3=ISBNPrice.replace("$", "");

			float ISBN_Price3=Float.parseFloat(ISBNPrice3);
			float finalPriceISBN=(float) (ISBN_Price3*discount);

			//Validate the title, isbn and price displayed in the page with the isbn3 items in the previous page
			if(productTitle.equalsIgnoreCase(ISBNTitle3)){
				Reporters.SuccessReport("Product Title Validation", "The Product title : "+productTitle+ " is matched with the isbn3 title <br>"
						+ "The actual title is : "+productTitle + "<br> The title in ISBN3 is : "+ISBNTitle3);
			}else{
				Reporters.failureReport("Product Title Validation", "The Product title : "+productTitle+ " is not matched with the isbn3 title <br>"
						+ "The actual title is : "+productTitle + "<br> The title in ISBN3 is : "+ISBNTitle3);		
			}

			if(productISBN.contains(ISBN_isbn3)){
				Reporters.SuccessReport("Product ISBN Validation", "The Product ISBN : "+productISBN+ " is matched with the isbn3 ISBN <br>"
						+ "The actual ISBN is : "+productISBN + "<br> The ISBN in ISBN3 is : "+ISBN_isbn3);
			}else{
				Reporters.failureReport("Product ISBN Validation", "The Product ISBN : "+productISBN+ " is not matched with the isbn3 ISBN <br>"
						+ "The actual ISBN is : "+productISBN + "<br> The ISBN in ISBN3 is : "+ISBN_isbn3);		
			}

			if(ppf==finalPriceISBN){
				Reporters.SuccessReport("Product Price Validation", "The Product Price : "+ppf+ " is matched with the isbn3 Price <br>"
						+ "The actual Price is : "+ppf + "<br> The Price in ISBN3 is : "+finalPriceISBN);
			}else{
				Reporters.failureReport("Product Price Validation", "The Product Price : "+ppf+ " is not matched with the isbn3 Price <br>"
						+ "The actual Price is : "+ppf + "<br> The Price in ISBN3 is : "+finalPriceISBN);		
			}

			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}

	public static boolean verifyCartTitle() throws Throwable{
		try{
			boolean flag=true;
			click(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomAddtoCart, "Click on request this product");
			
			Thread.sleep(medium);
			//clickOnEnterLaterButtonIfVisible();			
			clickOnOkButtonIfVisible();
			Thread.sleep(medium);
			List<WebElement> items=driver.findElements(ElsevierObjects.Admin_Evolve_Ecom_MyCartTitle);
			for(WebElement s:items){
				System.out.println(s.getText());
			}
			String ISBNTitle3=Promotion_CreatePromotionMarketingPageSinglePercentage_15582.titleforfutureuse3;	
			System.out.println(ISBNTitle3);
			String title=getText(ElsevierObjects.Admin_Evolve_Ecom_isbn3title, "");
			System.out.println(title);
			if(title.contains(ISBNTitle3)){	
				Reporters.SuccessReport("Title is : "+title, "Title : "+title+ " is present in MyCart and also matched with the isbn3 <br> Actual Title is : "+title+ "<br> Expected Title is :"+ISBNTitle3);
			}else{
				Reporters.failureReport("Title is : "+title, "Title : "+title+ " is not present in MyCart <br> Actual Title is : "+title+ "<br> Expected Title is :"+ISBNTitle3);
			}


			return flag;
		}catch(Exception e){
			System.out.println(e.getMessage());
			return false;
		}

	}
	
	/**Generic Method For Deleting item From Cart
	 * 
	 * @return
	 * @throws Throwable
	 */
	public static boolean deleteCart() throws Throwable{
		boolean flag=true;
		try{
		click(ElsevierObjects.Catalog_Header_Link, "Click on Catalog");
		click(ElsevierObjects.CART, "");
		if(isElementPresentNegCheck(ElsevierObjects.CARTDELETE,"Verify Delete Element present.")){
			List<WebElement> delete=driver.findElements(ElsevierObjects.CARTDELETE);
			for(WebElement d: delete){
				Thread.sleep(medium);
				d.click();
				Thread.sleep(medium);
			}
			
			driver.navigate().back();
			click(ElsevierObjects.Catalog_Header_Link, "Click on Catalog");
			//click(ElsevierObjects.Myevolve,"click on MyEvolve link");
		}
		else{
			click(ElsevierObjects.Myevolve,"click on MyEvolve link");
			click(ElsevierObjects.Catalog_Header_Link, "Click on Catalog");

		}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	public static boolean verifyCartPrice(String dmcode) throws Throwable{
		try{
			boolean flag=true;

			float price=convertPrice(ElsevierObjects.Admin_Evolve_Ecom_studentprice1);
			float subTotal=convertPrice(ElsevierObjects.Admin_Evolve_Ecom_SubTotal);

			if(price==subTotal){
				Reporters.SuccessReport("Product Price Validation", "The Product Price : "+price+ " is matched with the isbn3 Price <br>"
						+ "The actual Price is : "+price + "<br> The Price in ISBN3 is : "+subTotal);
			}else{
				Reporters.failureReport("Product Price Validation", "The Product Price : "+price+ " is not matched with the isbn3 Price <br>"
						+ "The actual Price is : "+price + "<br> The Price in ISBN3 is : "+subTotal);		
			}
			float discPrice=convertPrice(ElsevierObjects.marketingPageSinglePercentage_DiscPrice);
			System.out.println(discPrice);
			String ISBNPrice=Promotion_CreatePromotionMarketingPageSinglePercentage_15582.priceforfutureuse3;
			String ISBNPrice3=ISBNPrice.replace("$", "");	
			float ISBN_Price3=Float.parseFloat(ISBNPrice3);

			//float originalPrice=convertPrice(ElsevierObjects.marketingPageSinglePercentage_orignalPrice);

			float originalDiscPrice=ISBN_Price3-price;

			if(discPrice==originalDiscPrice){
				Reporters.SuccessReport("Product Discount Price Validation", "The Product Discount Price : "+discPrice+ " is matched with the isbn3 Discount Price <br>"
						+ "The actual Price is : "+discPrice + "<br> The Discount Price in ISBN3 is : "+originalDiscPrice);
			}else{
				Reporters.failureReport("Product Discount Price Validation", "The Product Discount Price : "+discPrice+ " is not matched with the isbn3 Discount Price <br>"
						+ "The actual Price is : "+discPrice + "<br> The Discount Price in ISBN3 is : "+originalDiscPrice);		
			}

			//String dmcode=PromotionRedeemSinglePercentageOff_10229_Script.DMCodeforuse;
			//dmcode=dmcodeforuse;
			String PromotionCode=getAttribute(ElsevierObjects.Admin_Evolve_Ecom_PromotionCode, "value", "DM Code");
			if(dmcode.contains(PromotionCode)){
				Reporters.SuccessReport("Validating whether DM Code : "+dmcode+" is shown as Promotion Code or not", "DM Code is shown as Promotion Code in the application <br>Actual DM Code is : "+dmcode+" <br>Expected Promotion Code shown as : "+PromotionCode);
			}else{
				Reporters.failureReport("DM Code : "+dmcode+" is not shown as Promotion Code or not", "DM Code is not shown as Promotion Code in the application <br>Actual DM Code is : "+dmcode+" <br>Expected Promotion Code shown as : "+PromotionCode);
			}

			return flag;
		}catch(Exception e){
			System.out.println(e.getMessage());
			return false;
		}

	}
	//marketingPageSinglePercentage_searchProduct
	public static boolean searchProductAndVerify(String searchData) throws Throwable{
		boolean flag=true;
		try{
			Promotion_CreatePromotionMarketingPageSinglePercentage_15582.productSearch(searchData);
			}catch(Exception e){
			System.out.println(e.getMessage());
			return false;
		}
		return flag;
	}


	public static  boolean productClickEntirePage(String title1, String isbn1, String price1) throws Throwable
	{
		try
		{
			boolean flag = true;
			Thread.sleep(high);
			click(ElsevierObjects.marketingPageSinglePercentage_DvdType, "Check the checkbox DVD Type");
			//List<WebElement> element=driver.findElements(ElsevierObjects.marketingPageSinglePercentage_DvdSearch);
			//element.get(0).click();
			Thread.sleep(high);
			String pageCount=getAttribute(ElsevierObjects.marketingPageSinglePercentage_PrmPgeCount, "value", "");
			int pages=Integer.parseInt(pageCount);
			int check=0;
			
			for (int i = 0; i < pages; i++) {
				if(check==0){
				Thread.sleep(medium);
				//if(!isChecked(ElsevierObjects.marketingPageSinglePercentage_DvdType, "DVD checkbox"))
				//	click(ElsevierObjects.marketingPageSinglePercentage_DvdType, "Check the checkbox DVD Type");
				//Thread.sleep(high);
				List<WebElement> ele=driver.findElements(ElsevierObjects.marketingPageSinglePercentage_PrmPgeLnk);
				ele.get(i).click();
				Thread.sleep(high);
				List<WebElement> element1=driver.findElements(ElsevierObjects.marketingPageSinglePercentage_searchProduct);

				int size=element1.size();
				for (int j = 0; j < size; j++) {
					Thread.sleep(medium);
					//if(!isChecked(ElsevierObjects.marketingPageSinglePercentage_DvdType, "DVD checkbox"))
					//	click(ElsevierObjects.marketingPageSinglePercentage_DvdType, "Check the checkbox DVD Type");
					//Thread.sleep(high);
					List<WebElement> element2=driver.findElements(ElsevierObjects.marketingPageSinglePercentage_searchProduct);
					element2.get(j).click();
					Thread.sleep(high);
					String titleOnPage=getText(ElsevierObjects.marketingPageSinglePercentage_Title, "Get the title of the Book");
					System.out.println(titleOnPage);
					String isbnOnPage=getText(ElsevierObjects.marketingPageSinglePercentage_ISBN, "Get the ISBN Value from the current page");
					System.out.println(isbnOnPage);
					String priceOnPage=getText(ElsevierObjects.marketingPageSinglePercentage_Price, "Get the Price value from the current page");
					System.out.println(priceOnPage);
					Thread.sleep(high);
					if(titleOnPage.equalsIgnoreCase(title1) && isbnOnPage.contains(isbn1) && priceOnPage.contains(price1)){
						System.out.println("If title and ISBN are equal print the success report and break");
						Reporters.SuccessReport("Title, ISBN and Price are Equal", "Title : " +titleOnPage+ " is same as expected with the ISBN1 title : "+title1+ "<br> The expected title is : "+title1 + "<br> The Actual title is : "+titleOnPage
								+"<br> The expected ISBN is : "+isbn1 + "<br> The Actual title is : "+isbnOnPage+"<br> The expected ISBN is : "+price1 + "<br> The Actual title is : "+priceOnPage);
						break;
					}
					else{
						System.out.println("If title and ISBN are not equal then print the Failure report and Go back and click on the next product");
						//Reporters.failureReport("Title, ISBN and Price are Equal", "Title : " +titleOnPage+ " is not same as expected with the ISBN1 title : "+title1+ "<br> The expected title is : "+title1 + "<br> The Actual title is : "+titleOnPage);
						driver.navigate().back();							
						continue;
					}
					
					
				}
				
			}check++;
				}
			
		}catch(Exception e){System.out.println(e.getMessage());return false;}
		driver.navigate().back();
		return flag;
	}
	
	public static boolean crossPromoteItems(String user, String checkbox) throws Throwable{

		boolean flag=true;  

		try{
			if(!isElementPresent1(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Items, "Cross Promote Items ")){
				flag = false;
			}
			if(!isElementPresent1(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrTitle, "Cross Promote Items title")){
				flag = false;
			}
			if(!isElementPresent1(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrDescrip, "Cross Promote Items page body")){
				flag = false;
			}
			if(!isElementPresent1(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrImg, "Cross Promote Items image header")){
				flag = false;
			}
			if(!isElementPresent1(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ImgPrw, "Cross Promote Items image preview")){
				flag = false;
			}
			if(!isElementPresent1(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrUrl, "Cross Promote URL")){
				flag = false;
			}

			if(checkbox.equalsIgnoreCase("selectFeatureRadioButton")){
				if(!click(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SltFeatureRadBtn, "Click on Feature Selected Resources radio button")){
					flag = false;
				}
			}else{
				System.out.println("Feature Radio Button is not present");
			}
			if(user.equalsIgnoreCase("variablePercentage")){
				marketingPageBookDetails(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ISBN, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("ISBN"), ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ISBNAdd,ElsevierObjects.crossPromoteISBNtableContent,""  );
			}else{
				System.out.println("");
			}
			if(!type(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Title, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("TitleCrossPromote"), "Type title  ")){
				
				flag = false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Description, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("BodyCrossPromote"), "Type URL  ")){
				
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SaveAndPublish, "Click on Marketing Page Tab")){
				flag = false;
			}
			Thread.sleep(medium);
			String sucMsg=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SuccMsg, "");
			if(verifyText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SuccMsg, "Marketing page details are saved successfully.", "Success Message")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
			}

			if(!isElementPresent1(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ReqFlds, "Required Fields")){
				flag = false;
			}

			
			Thread.sleep(medium);

			
			//String UniqueURL = "evolvecert.elsevier.com"+ readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("UniqueURL");
			UniqueURL = "evolvetest.elsevier.com"+uniqueURL;
			
				if(!launchUrl("https://"+UniqueURL)){
					flag = false;
				}
					   
				Thread.sleep(medium);
			System.out.println(UniqueURL);
			String pageTitle=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrPageTitleVfyTxt, "");
			String pageBody=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrPageBodyVfyTxt, "");
			String crossPromoteTitle=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_TitleVrfy, "");
			String crossPromoteBody=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_DescVrfy, "");
			
			String expTitle=readcolumns.twoColumns(0, 1,"Ecom_TCID_10217", configProps.getProperty("TestData")).get("PageTitle");
			String expBody=readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("pageBody");
			String expCrossPromoteTitle=readcolumns.twoColumns(0, 1,"Ecom_TCID_10217", configProps.getProperty("TestData")).get("TitleCrossPromote");
			String expCrossPromoteBody=readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("BodyCrossPromote");
			
			if(pageTitle.equalsIgnoreCase(expTitle)){
				Reporters.SuccessReport("Verify the Titles are correct", "The titles are matched with each other <br> Actual Title is : "+pageTitle+" <br> Expected title is : "+expTitle);	
			}else{
				Reporters.failureReport("Verify the Titles are correct", "The titles are not matched with each other <br> Actual Title is : "+pageTitle+" <br> Expected title is : "+expTitle);	
			}
			
			if(pageBody.equalsIgnoreCase(expBody)){
				Reporters.SuccessReport("Verify the Titles are correct", "The titles are matched with each other <br> Actual Title is : "+pageBody+" <br> Expected title is : "+expBody);	
			}else{
				Reporters.failureReport("Verify the Titles are correct", "The titles are not matched with each other <br> Actual Title is : "+pageBody+" <br> Expected title is : "+expBody);	
			}
			if(crossPromoteTitle.equalsIgnoreCase(expCrossPromoteTitle)){
				Reporters.SuccessReport("Verify the Titles are correct", "The titles are matched with each other <br> Actual Title is : "+crossPromoteTitle+" <br> Expected title is : "+expCrossPromoteTitle);	
			}else{
				Reporters.failureReport("Verify the Titles are correct", "The titles are not matched with each other <br> Actual Title is : "+crossPromoteTitle+" <br> Expected title is : "+expCrossPromoteTitle);	
			}
			if(crossPromoteBody.equalsIgnoreCase(expCrossPromoteBody)){
				Reporters.SuccessReport("Verify the Titles are correct", "The titles are matched with each other <br> Actual Title is : "+crossPromoteBody+" <br> Expected title is : "+expCrossPromoteBody);	
			}else{
				Reporters.failureReport("Verify the Titles are correct", "The titles are not matched with each other <br> Actual Title is : "+crossPromoteBody+" <br> Expected title is : "+expCrossPromoteBody);	
			}
			
			
			
			
			/*Thread.sleep(low);
			if(!verifyText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrPageTitleVfyTxt, readcolumns.twoColumns(0, 1,"Ecom_TCID_10217", configProps.getProperty("TestData")).get("PageTitle"), "Page Title Verification is successfull")){
				flag = false;
			}
			Thread.sleep(low);
			if(!verifyText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrPageBodyVfyTxt, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("pageBody"), "Page Body Verification is successfull")){
				flag = false;
			}
			Thread.sleep(low);
			if(!verifyText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_TitleVrfy, readcolumns.twoColumns(0, 1,"Ecom_TCID_10217", configProps.getProperty("TestData")).get("TitleCrossPromote"), "Page title Verification is successfull")){
				flag = false;
			}
			Thread.sleep(low);
			if(!verifyText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_DescVrfy, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("BodyCrossPromote"), "Page Body Verification is successfull")){
				flag = false;
			}
*/
		}catch(Exception e){
			System.out.println("Error Message Throwing " + e);
		}
		return flag;
	}
	
	public static boolean viewMarketingPage() throws Throwable
	{
		try
		{
			boolean flag = true;
		
			click(ElsevierObjects.marketingPageSinglePercentage_ViewMarketingPageLink, "Click on the View Marketing Page Link on the top right portion of the page");
			Thread.sleep(medium);
			String breadCrumb=getText(ElsevierObjects.marketingPageSinglePercentage_ViewMarketingPageBreadCrumb, "Getting the text for BreadCrumb");
			if(breadCrumb.contains("Evolve Admin > Maintain Promotions > Active Promotions > Edit Promotion > Promotion Marketing Page")){
				Reporters.SuccessReport("Bread Crumb", "Bread Crumb : "+breadCrumb+ " is present");
			}else{
				Reporters.failureReport("Bread Crumb", "Bread Crumb : "+breadCrumb+ " is not present");
			}
			isElementPresent1(ElsevierObjects.marketingPageSinglePercentage_ViewMarketingPageBreadCrumb, "Bread Crumb");
			dmcodeforuse=getText(ElsevierObjects.dmCodeforuse, "");
			marketingPageBookDetails(ElsevierObjects.marketingPageISBNTextBox, isbnForFutureUse3, ElsevierObjects.marketingPageISBNAddBtn, ElsevierObjects.marketingPageISBNtableContent,"");
			//System.out.println("");
			//Click on save and publish
			verifyUniqueurl();
			String user="singlePercentage";
			String checkbox="";
			crossPromoteItems(user,checkbox);
			String uniqueUrl=EvolveCommonBussinessFunctions.UniqueURL;
			
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}
	}
	
	public static boolean verifyISBN4(float discount) throws Throwable
	{
		try
		{
			boolean flag = true;
			//Get the Product Title, Product ISBN and Product Price
			String productTitle=getText(ElsevierObjects.marketingPageSinglePercentage_Title, "Get the title of the Book");
			System.out.println(productTitle);

			String productISBN=getText(ElsevierObjects.marketingPageSinglePercentage_ISBN, "Get the ISBN Value for future Use");
			System.out.println(productISBN);

			float productPrice=convertPrice(ElsevierObjects.marketingPageSinglePercentage_DiscountPrice);
			/*String productPrice=getText(ElsevierObjects.marketingPageSinglePercentage_DiscountPrice, "Get the Price of the Book");
			//float productPrice1=convertPrice(ElsevierObjects.marketingPageSinglePercentage_DiscountPrice);
			String pp=productPrice.replace("$", "");
			float ppf=Float.parseFloat(pp);*/
			System.out.println(productPrice);


			//Get the Product title, product ISBN and Product price from the ISBN#3
			String ISBNTitle4=Promotion_CreatePromotionMarketingPageSinglePercentage_15582.titleforfutureuse4;
			String ISBN_isbn4=Promotion_CreatePromotionMarketingPageSinglePercentage_15582.isbnForFutureUse4;
			String ISBNPrice=Promotion_CreatePromotionMarketingPageSinglePercentage_15582.priceforfutureuse4;
			String ISBNPrice4=ISBNPrice.replace("$", "");

			float ISBN_Price4=Float.parseFloat(ISBNPrice4);
			float finalPriceISBN=(float) (ISBN_Price4*discount);

			//Validate the title, isbn and price displayed in the page with the isbn3 items in the previous page
			if(productTitle.equalsIgnoreCase(ISBNTitle4)){
				Reporters.SuccessReport("Product Title Validation", "The Product title : "+productTitle+ " is matched with the isbn3 title <br>"
						+ "The actual title is : "+productTitle + "<br> The title in ISBN3 is : "+ISBNTitle4);
			}else{
				Reporters.failureReport("Product Title Validation", "The Product title : "+productTitle+ " is not matched with the isbn3 title <br>"
						+ "The actual title is : "+productTitle + "<br> The title in ISBN3 is : "+ISBNTitle4);		
			}

			if(productISBN.contains(ISBN_isbn4)){
				Reporters.SuccessReport("Product ISBN Validation", "The Product ISBN : "+productISBN+ " is matched with the isbn3 ISBN <br>"
						+ "The actual ISBN is : "+productISBN + "<br> The ISBN in ISBN3 is : "+ISBN_isbn4);
			}else{
				Reporters.failureReport("Product ISBN Validation", "The Product ISBN : "+productISBN+ " is not matched with the isbn3 ISBN <br>"
						+ "The actual ISBN is : "+productISBN + "<br> The ISBN in ISBN3 is : "+ISBN_isbn4);		
			}

			if(productPrice==finalPriceISBN){
				Reporters.SuccessReport("Product Price Validation", "The Product Price : "+productPrice+ " is matched with the isbn3 Price <br>"
						+ "The actual Price is : "+productPrice + "<br> The Price in ISBN3 is : "+finalPriceISBN);
			}else{
				Reporters.failureReport("Product Price Validation", "The Product Price : "+productPrice+ " is not matched with the isbn3 Price <br>"
						+ "The actual Price is : "+productPrice + "<br> The Price in ISBN3 is : "+finalPriceISBN);		
			}

			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}
	
	}
	
	public static boolean isbn4Verify(float discount) throws Throwable{
			boolean flag=true;
			try{
			float discountAmount=convertPrice(ElsevierObjects.marketingPageSinglePercentage_DiscountPrice);
			String ISBNPrice=Promotion_CreatePromotionMarketingPageSinglePercentage_15582.priceforfutureuse4;
			String ISBNPrice4=ISBNPrice.replace("$", "");

			float ISBN_Price4=Float.parseFloat(ISBNPrice4);
			float finalPriceISBN=(float) (ISBN_Price4*discount);
			
			if(discountAmount==finalPriceISBN){
				Reporters.SuccessReport("Product Price Validation", "The Product Price : "+discountAmount+ " is matched with the isbn3 Price <br>"
						+ "The actual Price is : "+discountAmount + "<br> The Price in ISBN3 is : "+finalPriceISBN);
			}else{
				Reporters.failureReport("Product Price Validation", "The Product Price : "+discountAmount+ " is not matched with the isbn3 Price <br>"
						+ "The actual Price is : "+discountAmount + "<br> The Price in ISBN3 is : "+finalPriceISBN);		
			}	
			return flag;
	}catch(Exception e){System.out.println(e.getMessage());return flag;
	
	}	
	}
	
	public static boolean addCartButton() throws Throwable{
		boolean flag=true;
		try{
			waitForVisibilityOfElement(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomAddtoCart, "");
			Thread.sleep(medium);
			javaClick(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomAddtoCart, "Click on add to cart button");
			Thread.sleep(medium);
		}catch(Exception e){System.out.println(e.getMessage());return false;}
		return flag;
	}
	
	public static boolean redeemCheckout() throws Throwable{
		boolean flag=true;
		try{
			waitForVisibilityOfElement(ElsevierObjects.Hesi_Student_Reedembutton, "Wait for Redeem/Checkout Button");
			javaClick(ElsevierObjects.Hesi_Student_Reedembutton, "Click on Redeem/Checkout");
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}
	
	
	public static boolean reviewAndSubmitValidation() throws Throwable{
		boolean flag=true;
		try{
			String reviewAndSubmit=getText(ElsevierObjects.reviewAndSubmit, "Get the value review and submit to a string");
			if(reviewAndSubmit.contains("2. REVIEW & SUBMIT")){
				Reporters.SuccessReport("The REVIEW & SUBMIT page is presented", "The REVIEW & SUBMIT page is successfully displayed");
			}else{
				Reporters.failureReport("The REVIEW & SUBMIT page is not present", "The REVIEW & SUBMIT page is failed to display");
			}
			//System.out.println("hi");
			float priceInApplication=convertPrice(ElsevierObjects.isbn4);
			List<WebElement> prices=driver.findElements(ElsevierObjects.priceValidation);
			String freeshipping=prices.get(0).getText();
			String discount_Promotion=prices.get(1).getText();
			String estimatedTax=prices.get(2).getText();
			String total=prices.get(3).getText();
			float freeship=convertStringToPrice(freeshipping);
			float discount=convertStringToPrice(discount_Promotion);
			float estTax=convertStringToPrice(estimatedTax);
			float tot=convertStringToPrice(total);
			
			float finalPrice=priceInApplication+freeship-discount+estTax;
			System.out.println("Checking price values");
			if(finalPrice==tot){
				Reporters.SuccessReport("Validate the subtotal, discount/promotion, and total prices are all calculated as expected.", "the subtotal, discount/promotion, and total prices are all calculated as expected.");
			}else{
				Reporters.failureReport("Validate the subtotal, discount/promotion, and total prices are all calculated as expected.", "the subtotal, discount/promotion, and total prices are failed to calculate as expected.");
			}
		}catch(Exception e){
			System.out.println(e.getMessage());
			System.out.println("");return false;
		}
		return flag;
	}

	public static boolean shipping(String street, String city, String state, String zip) throws Throwable{
		boolean flag=true;
		try{
			click(ElsevierObjects.Student_Shipping_Chk,"Click checkbox");	
			type(ElsevierObjects.Student_Shipping_Addr1, street,"Enter student Street");	
			type(ElsevierObjects.Student_Shipping_City,city,"Enter student City");	
			selectByValue(ElsevierObjects.Student_Shipping_State,state, "State name");
			type(ElsevierObjects.Student_Shipping_Zip,zip,"Enter student Zipcode");	
			if(isChecked(ElsevierObjects.Student_Shipping_AccpChk, "Click Check Box to Accept")){
				click(ElsevierObjects.Student_Shipping_ContBtn,"Click Continue Button");
			}else{
				flag=true;
				click(ElsevierObjects.Student_Shipping_AccpChk,"Click Continue Button");
				click(ElsevierObjects.Student_Shipping_ContBtn,"Click Continue Button");
				}
			switchToFrameByLocator(ElsevierObjects.Student_register_frame,"Switch to frame");
			click(ElsevierObjects.Student_register_UseAdress_btn,"Click UsethisAdress Button");
			click(ElsevierObjects.Student_Shipping_Accept, "Click on Accept Button");				
			click(ElsevierObjects.Student_Shipping_Submit, "Click on Submit Button");
			String productShipConfirm=getText(ElsevierObjects.Student_Shipping_Comfirm, "");
			if(verifyText(ElsevierObjects.Student_Shipping_Comfirm, "Thank you for your request! This product is now available in your Evolve  account. ", "Success Message")){
				Reporters.SuccessReport("The Success Message Validation", "The Thank you Request message : "+productShipConfirm+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The Thank you Request message : "+productShipConfirm+" is failed to display");
			}


		}catch(Exception e){System.out.println(e.getMessage());return false;}
		return flag;
	}
	
	public static boolean validateConfirmationPage() throws Throwable{
		boolean flag=true;
		try{
		Thread.sleep(medium);
		 String orderNo=getText(ElsevierObjects.Admin_Evolve_Ecom_OrdNo, "");
		    if(orderNo!=null){
		    Reporters.SuccessReport("Order No.", "Örder No. is : " +orderNo);
		    }else{
		    	Reporters.failureReport("Order No.", "Örder is not submitted");
		    }
	  	    
	    String billingAddress=getText(ElsevierObjects.Admin_Evolve_Ecom_Billing, "");
	    String shipping=getText(ElsevierObjects.Admin_Evolve_Ecom_Shipping, "");
	    String creditCard=getText(ElsevierObjects.Admin_Evolve_Ecom_CreditCard, "");
	    String userstreetAddress=ReadingExcel.columnDataByHeaderName("User_StreetAddress", "PromotionTestData",configProps.getProperty("TestData"));
	    if(billingAddress.contains(userstreetAddress))	{
	    	Reporters.SuccessReport("Validating Billing address", "Billing address is Verified and is correct as expected <Br> Billing Address Captured from Application is : "+billingAddress +"<br> Actual Billing Address is : "+readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("User_StreetAddress"));
	    }else{
	    	Reporters.failureReport("Validating Billing address", "Billing address is Verified and is different as expected <Br> Billing Address Captured from Application is : "+billingAddress +"<br> Actual Billing Address is : "+readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("User_StreetAddress"));
	    }
	    if(shipping.contains(userstreetAddress))	{
	    	Reporters.SuccessReport("Validating Shipping address", "Shipping address is Verified and is correct as expected <Br> Shipping Address Captured from Application is : "+shipping +"<br> Actual Shipping Address is : "+readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("User_StreetAddress"));
	    }else{
	    	Reporters.failureReport("Validating Shipping address", "Shipping address is Verified and is correct as expected <Br> Shipping Address Captured from Application is : "+shipping +"<br> Actual Shipping Address is : "+readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("User_StreetAddress"));
	    }
	    if(creditCard.equalsIgnoreCase("visa"))	{
	    	Reporters.SuccessReport("Validating Credit card details", "Credit card details are correct");
	    }else{
	    	Reporters.failureReport("Validating Credit card details", "Credit card details are not correct");
	    }
	   
	    List<WebElement> testdata= driver.findElements(ElsevierObjects.Admin_Evolve_Ecom_pricelist);
	    	    
	    String freeShip=testdata.get(0).getText();
	    
	    float freeShipping=Float.parseFloat(freeShip.replace("$", ""));
	    
	    String subTot=testdata.get(1).getText();
	    float subTotal=Float.parseFloat(subTot.replace("$", ""));
	    
	    String disc=testdata.get(2).getText();
	    float discount=Float.parseFloat(disc.replace("$", ""));
	    
	    String tax=testdata.get(3).getText();
	    float taxpayable=Float.parseFloat(tax.replace("$", ""));
	    
	    String total=testdata.get(4).getText();
	    float finalPrice=Float.parseFloat(total.replace("$", ""));
	    
	    //TODO change the decimal places to two digit
	    float expected=freeShipping + subTotal-discount+taxpayable;
	    float actual=finalPrice;
	    
	    if(expected==actual){
	    	Reporters.SuccessReport("Price are Calculated", "The subtotal, discount/promotion, and total prices are all calculated as expected <Br> Actual Price is : "+actual + "<br> Expected Price after the calculations is : "+expected);
	    }else{
	    	Reporters.failureReport("Price are Calculated", "The subtotal, discount/promotion, and total prices are all failed to calculate as expected <Br> Actual Price is : "+actual + "<br> Expected Price after the calculations is : "+expected);
	    }
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}
	
	
}




