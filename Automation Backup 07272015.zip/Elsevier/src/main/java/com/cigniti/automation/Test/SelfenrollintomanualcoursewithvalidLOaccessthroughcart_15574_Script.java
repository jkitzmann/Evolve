package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.SelfenrollintomanualcoursewithvalidLOaccessthroughcart_15574;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class SelfenrollintomanualcoursewithvalidLOaccessthroughcart_15574_Script extends  SelfenrollintomanualcoursewithvalidLOaccessthroughcart_15574 {
  @Test
  public void selfenrollintomanualcoursewithvalidLOaccessthroughcart_15574() throws Throwable{
	  //HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
	  SwitchToBrowser(ElsevierObjects.studentBrowserType);
	  String user = "student";
	  String userName = ReadingExcel.columnDataByHeaderName("username", "TC-15574", testDataPath);
	  String password = ReadingExcel.columnDataByHeaderName("password", "TC-15574", testDataPath);
	  ElsevierObjects.browserType="firefox";
	  Manual_Unique_Course_Fulfillment_10436_Script e=new Manual_Unique_Course_Fulfillment_10436_Script();
	  e.manualUniqueCourse10436();
	  ProIsbn = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-10436", configProps.getProperty("TestData")).get("Product"); 
	  ProschemeId = ReadingExcel.columnDataByHeaderName("protectionSchemeID","TC-15574",configProps.getProperty("TestData"));
	  CourId = ReadingExcel.columnDataByHeaderName("courseID","TC-15574",configProps.getProperty("TestData"));
	  Usepercode = ReadingExcel.columnDataByHeaderName("Usespercode","TC-15574",configProps.getProperty("TestData"));
	  
	  Reporters.SuccessReport("Complete Testcase Manual Unique Course Fulfillment",
			                  "Completed Testcase Manual Unique Course Fulfillment and details are:</br> Product ISBN :"+ProIsbn+"</br> Course Id :"+CourId+" </br> Protection SchemeId :"+ProschemeId);
	 
	  EvolveCommonBussinessFunctions.existingUserLogin (user,userName,password);
                                                                                            
	  EvolveCommonBussinessFunctions.getAccountDetails();
	  firstname = getAccountDetailsFirstName;
	  lastname = getAccountDetailsLastName;
	  Instname = getAccountDetailsInstitution; 
	  System.out.println(Instname);
	  writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Enter Admin URL and login with the Credentials",
                                                                    "Successfully launched with Admin URL and logged in with User credentials",
                                                                    "Failed to login with Admin URL and login");

	  createAccessCode(ProIsbn,"1","1");
	  //EvolveCommonBussinessFunctions.adminLogout();
	  Thread.sleep(high);
	  AccountCreation();
	  studnetCheckOut(true,ProIsbn);
	  Confirmationpage();
	  writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Enter Admin URL and login with the Credentials",
                                                                    "Successfully launched with Admin URL and logged in with User credentials",
                                                                    "Failed to login with Admin URL and login");

	  AdminVerification();
	  Reverification(ProIsbn);
  }
  @AfterTest
	public void closeBrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
