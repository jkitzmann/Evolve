package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.CreateRosterforLOcourse_8561;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.Utilities.ReadingExcel;

public class CreateRosterforLOcourse_Script_8561 extends CreateRosterforLOcourse_8561 {
	@Test
	public static void createRosterforLOcourse_8561() throws Throwable
	{

		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		//SwitchToBrowser(ElsevierObjects.studentBrowserType);
		//String user="educator";


		//======Step1: Execute complete steps of LO Unique Course FullFillment Faculty for getting CourseID=========//
		CreateLOUniqueCourseFaculty_Script_15583 louniqueCourse=new CreateLOUniqueCourseFaculty_Script_15583();
		String isbnNumber=ReadingExcel.columnDataByHeaderName("ISBNNumber", "TC_8561", testDataPath);
		louniqueCourse.uniqueCourseLOFaculty("TC_8561",isbnNumber,4);

		facultyUser=ReadingExcel.columnDataByHeaderName("Faculty_UserName", "TC_8561", testDataPath);
		facultyPwd=ReadingExcel.columnDataByHeaderName("Faculty_UserPwd", "TC_8561", testDataPath);

		ID=ReadingExcel.columnDataByHeaderName("COURSEID","TC_8561",configProps.getProperty("TestData"));
		ReadingExcel.updateCellInSheet(1,0,configProps.getProperty("TestData"),"TC-15565",ID);
		errorMsg=ReadingExcel.columnDataByHeaderName("ErrorMsg","TC_8561",configProps.getProperty("TestData")); 
		InstructorHeader=ReadingExcel.columnDataByHeaderName("Instructorheader","TC_8561",testDataPath);
		StudentHeader=ReadingExcel.columnDataByHeaderName("Studentheader","TC_8561",testDataPath);


		//=======Step#2 & 3: "Create Student User from Student Page"====================//
		stepReport("Create new Student user");
		writeReport(CreateRosterforLOcourse_8561.AccountCreationdetails(),"Create 'LO Unique Course Fulfillment-Faculty' Launch Evolvecert URL and create a new student",
				"Created 'LO Unique Course Fulfillment-Faculty' with CourseId "  +ID+ "</br> Username :  "+ facultyUser+ "</br> Password :  "+ facultyPwd+ 
				"</br> Launched Evolvecert URL Successfully and </br> Created a new student and his details are </br>Lastname :  "+studentLastName+"</br>Firstname :  "+studentFirstName+"</br> Username :  "+newStudentUserName+"</br> Password :  "+newStudentPassword+
				"</br>instructor details that has previously been created in evolve cert </br>Lastname : "+faLastName+"</br>Firstname :  "+faFirstName+"<br>EmailId :  "+faEmail+"</br> Username :  "+RosterUser+"</br> Password :  "+RosterPwd,
		"Failed to create 'LO Unique Course Fulfillment-Faculty' and Launch Evolvecert URL ");

		
		//=============Step#4: Log into evolve cert as the same instructor used to create the course in Step #1=============//
		
		// no need to launch the url here, it's launched through the EducatorLogin function below
		//launchUrl("https://evolvecert.elsevier.com/cs/store?role=faculty");
		Thread.sleep(1000);
		stepReport("Login to Evolve course instructor");
		writeReport(User_BusinessFunction.Educatorlogin(facultyUser,facultyPwd),"Launching Evolvecert URL and Login to Application.",
				"Launching Evolvecert URL is successful </br > Login to Application Using instructor credentails :"+facultyUser+" is Successful",
				"Launching and Login to Application Using instructor credentails : "+facultyUser+" is Failed");
		EvolveCommonBussinessFunctions.getAccountDetails();
		LoEmail = getAccountDetailsEmail;

		
		//==========Step#5 & 6: 'Get Student into your Course' Section==================//
		stepReport("Go to Submit Roster page");
		EvolveCommonBussinessFunctions.getStundentIntoYourCourse();
		
		//=========================Step#7 & 8==========================================//
		stepReport("Enter course and student info on roster page");
		submitRosterData(ID, roseterFieldForStudent, rosterFieldForFaculty );
		
		//========================Step#9===============================================//
		stepReport("Select roles for roster and submit");
		selectingRoles();
		
		//=======================Step#10 to Step#15====================================//
		stepReport("Verify roster emails");
		Emailforwarding();
		
		//=======================Step#16 to Step#19===================================//
		//GmailverificationforFaculty();
		
		//=========Step#20 log in as the instructor of the course (from step #1).==================//
		stepReport("Login to Evolve as the course instructor and verify roster");
		InstructorRelogin();
		
		//===========Step#21 Log into Evolve Admin Cert.=========================//
		//SwitchToBrowser(ElsevierObjects.adminBrowserType);
		stepReport("Login to Evolve Admin");
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Enter Admin URL and login with the Credentials",
				"Successfully launched with Admin URL and logged in with User credentials",
		"Failed to login with Admin URL and login");
		
		//===========Step#22 to Step#26=======================================//
		stepReport("Verify roster in Evolve Admin");
		CreateRosterforLOcourse_8561.RostersearchingAdmin();

		writeReport(EvolveCommonBussinessFunctions.adminLogout(),"Logout from the admin","Successfully logout from the admin","Failed to logout from the admin");
		
		stepReport("Verify student has course access");
		StudentRelogin();
		
		stepReport("Verify student created via roster has course access");
		RosterStudentRelogin();
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}

