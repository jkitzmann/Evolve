package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;


public class Ecomm_PreOrder_My_Evolve_Page_15596 extends Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions {
	
	public static final String SIM_CHART_6_MONTH = ReadingExcel.columnDataByHeaderName("product", "TC-15596", testDataPath);

	@Test
	public void ecommPreOrderMyEvolve15596() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		String pubDatePreOrder=ReadingExcel.columnDataByHeaderName("pubDatePreOrder", "TC-15596", testDataPath);
		String pubDatePreOrderStatus=ReadingExcel.columnDataByHeaderName("pubDateStatusPreOrder", "TC-15596", testDataPath);
		String pubDatePostOrder=ReadingExcel.columnDataByHeaderName("pubDatePostOrder", "TC-15596", testDataPath);
		String pubDatePostOrderStatus=ReadingExcel.columnDataByHeaderName("pubDatePostStatus", "TC-15596", testDataPath);
		String cardType=ReadingExcel.columnDataByHeaderName("CardType", "TC-15596", testDataPath);
		String cardNumber=ReadingExcel.columnDataByHeaderName("CardNumber", "TC-15596", testDataPath);
		String cardName=ReadingExcel.columnDataByHeaderName("CardName", "TC-15596", testDataPath);
		String month=ReadingExcel.columnDataByHeaderName("Month", "TC-15596", testDataPath);
		String year=ReadingExcel.columnDataByHeaderName("Year", "TC-15596", testDataPath);
		String cvv=ReadingExcel.columnDataByHeaderName("CVV", "TC-15596", testDataPath);
		
		/*String cardType=readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("student_CardType");
		String cardNumber=readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("student_CardNum");
		String cardName=readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("studentCardName");
		String month=readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("CreditCardMonth");
		String year=readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("CreditCardYear");
		String cvv=readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("student_CardCvv");
		*/
		
		
		CreateLOUniqueCourseFaculty_Script_15583 louniqueCourse=new CreateLOUniqueCourseFaculty_Script_15583();
		String product=ReadingExcel.columnDataByHeaderName("product", "TC-15596", testDataPath);
		louniqueCourse.uniqueCourseLOFaculty("TC-15596",product, 1);
		
		System.out.println("CourseID===>>>>"+EvolveCommonBussinessFunctions.courseID1);
		
		adminLogin();
		
		editResource(SIM_CHART_6_MONTH);
		
		modifyPublicatonDate(pubDatePreOrder,pubDatePreOrderStatus);
		Thread.sleep(low);
		writeReport(launchUrl(configProps.getProperty("NoCacheURL")), "Run the noCache URL", "Successfully ran the noCache URL.", "Failed to run the noCache URL.");
		Thread.sleep(medium);
		driver.navigate().back();
		
		adminLogout();
		
		writeReport(Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions.CreateNewUser("student", "ecommPreOrderMyEvolve15596", "ECommercePreOrder", 5, 1,2,0), "Create New Student user", "Successfully created new student user with credentials: <br> Username: "+credentials[0]+"<br> Password : "+credentials[1], "Failed to create a new student account");
		
		String studentUserName = EvolveCommonBussinessFunctions.credentials[0];
		String studentPasswrod = EvolveCommonBussinessFunctions.credentials[1];
		
		System.out.println(studentUserName +","+ studentPasswrod);
		
		
		
		searchISBNNumber(SIM_CHART_6_MONTH);
		
		studnetCheckOut(false,SIM_CHART_6_MONTH);
		enterCreditCardData(cardType, cardNumber, cvv, cardName, month, year, SIM_CHART_6_MONTH);
		
		acceptAndContinue();
		
		User_BusinessFunction.Logout();
		
		adminLogin();
		
		editResource(SIM_CHART_6_MONTH);
		
		modifyPublicatonDate(pubDatePostOrder,pubDatePostOrderStatus);
		
		Thread.sleep(medium);
		
		writeReport(launchUrl(configProps.getProperty("NoCacheURL")), "Run the noCache URL", "Successfully ran the noCache URL.", "Failed to run the noCache URL.");
		
		/*User_BusinessFunction.Studentlogin("nuser2080", "abc@123");
		
		//verifyInstructorCouseidButton();
		
		verifyEnterLaterButton();
		
		enterCourseId("111638_nuser2013_1001");
		
		verifySubFloders();*/
	}
	@AfterTest
	public void closeBrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		//Base.tearDown();
	}
	
}
