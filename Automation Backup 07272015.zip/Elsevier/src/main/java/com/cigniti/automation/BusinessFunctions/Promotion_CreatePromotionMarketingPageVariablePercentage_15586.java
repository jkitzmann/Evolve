package com.cigniti.automation.BusinessFunctions;

import java.util.ArrayList;

public class Promotion_CreatePromotionMarketingPageVariablePercentage_15586 extends EvolveCommonBussinessFunctions{

	public static int i;
	public static String title;
	public static String ISBN;
	public static String price;
	public static ArrayList<String> title1=new ArrayList<String>();
	public static ArrayList<String> isbn1=new ArrayList<String>();
	public static ArrayList<String> price1=new ArrayList<String>();
	/*public static String isbnForFutureUse1;
	public static String isbnForFutureUse2;
	public static String isbnForFutureUse3;
	public static String isbnForFutureUse4;
	
	public static String titleforfutureuse1;
	public static String titleforfutureuse2;
	public static String titleforfutureuse3;
	public static String titleforfutureuse4;
	
	public static String priceforfutureuse1;
	public static String priceforfutureuse2;
	public static String priceforfutureuse3;
	public static String priceforfutureuse4;
	public static String uniqueUrl;*/
	
	
	
	
}
