package com.cigniti.automation.BusinessFunctions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Accessories;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class LO_GlobalStudent_8571 extends EvolveCommonBussinessFunctions{
	public static String EMAIL_ID ="";	

	
	public static boolean receiptPage() throws Throwable{
		boolean flag=true;
		try{
			
			productType=getText(ElsevierObjects.ProductType, "");
			titleInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chktitle,"Price in Receipt page");
			isbnInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chktisbn,"Price in Receipt page");
			PriceinReceiptPage=getText(ElsevierObjects.evolve_Receipt_chkprice,"Price in Receipt page");
			if(isbnInReceiptPage.contains(Isbn) && titleInReceiptPage.contains(title) &&  PriceinReceiptPage.equals(ExpectedPrice) ){
				Reporters.SuccessReport("Verifying Product details In Receipt Page.", "Successfully Verified price:"+PriceinReceiptPage+",ISBN:"+isbnInReceiptPage+",Title:"+title+" in Receipt Page.");
			}
			else{
				Reporters.failureReport("Verifying Product details In Receipt Page.", "Failed To Verify Product Details In Receipt Page.");
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	public static boolean student_courseId_search(String courseId,String courseTitle) throws Throwable {
		 boolean flag=true;
		
		try{
		 if(verifyText(ElsevierObjects.Student_CourseId_search,courseId, "Online couse id")){
			 Reporters.SuccessReport("Verifying Course ID In My Evolve Page.", "Successfully Verified CourseID:"+courseId+" In My Evolve Page.");
		 }
		 else{
			 Reporters.failureReport("Verifying Course ID In My Evolve Page.", "Failed To Verify CourseID:"+courseId+" In My Evolve Page.");
		 }
		 Thread.sleep(medium);
		 if(click(ElsevierObjects.Student_CourseId_Click,"click on online course")){
			 Reporters.SuccessReport("Clicking On Course ID Resource Link In My Evolve Page.", "Successfully Clicked On CourseID:"+courseId+" Resource Link In My Evolve Page.</br>Navigated To Resource Page in LO.");
		 }
		 else{
			 Reporters.failureReport("Clicking On Course ID Resource Link In My Evolve Page.", "Failed To Click On CourseID:"+courseId+" Resource Link In My Evolve Page.");
		 }	
		 Thread.sleep(medium);
		 if(verifyText(ElsevierObjects.Educator_CourseId_Title,courseTitle, "Online couse Title")){
			 Reporters.SuccessReport("Verifying The Global Course Title in Resources Page.", "Successfully Verified Title:"+courseTitle);
		 }
		 else{
			 Reporters.failureReport("Verifying The Global Course Title in Resources Page.", "Failed To Verify Title:"+courseTitle);
		 }
		 Thread.sleep(medium);
		 click(ElsevierObjects.Student_Update_Account_ResourcesFolder, "Clicking On Resource Folder.");
		
		 List<WebElement> s=driver.findElements(ElsevierObjects.Student_Update_Account_ResourcesFolder_SubfolderList);
		  for(WebElement subFolder:s){
		
			  if(waitForElementPresent(ElsevierObjects.Student_Update_Account_ResourcesFolder_SubfolderList, "Resource folder contains sub folders.")){
				  Reporters.SuccessReport("Verifying Resource subfolders.", "Verified Subfolders of Resource Folder.</br>SubFolder is:"+subFolder.getText());
			  }
			  else{
				  Reporters.failureReport("Verifying Resource subfolders.", "Failed To Verify Resource Subfolders of Course Folder.");
			  }
		  }
		
		 click(ElsevierObjects.Student_Update_Account_ResourcesFolder_SubFolder,"click on the Student update resourse sub folder");
		 
		 click(ElsevierObjects.Student_ResourcesFolder_SubFolder_chapter, "subfolder");
		
		 click(ElsevierObjects.Student_ResourcesFolder_SubFolder_Folder,"subfolder");
		 
		 Thread.sleep(high);
		 
		 waitForElementPresent(ElsevierObjects.Student_ResourcesFolder_SubFolder_Folder_Heading, "Wiat For visibility Of Heading.");
		

		 String heading=getText(ElsevierObjects.Student_ResourcesFolder_SubFolder_Folder_Heading, "folder Heading");
		 
		 System.out.println("heading:"+heading);
		 
		System.out.println();
		 if(heading !=""){
			Reporters.SuccessReport("Clicking On One Of The Subfolder Of Resource Subfolders And Verifying Whether User should be able to access the content","Successfully Clicked On Subfolder Link And Navigated To Content Page.</br>Successfully Fetched The Heading Of The Content Page :"+heading);
		}
		else{
			Reporters.failureReport("Clicking On One Of The Subfolder Of Resource Subfolders And Verifying Whether User should be able to access the content", "Failed To Click On Subfolder Link And Failed To Navigated To Content Page.");
		}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		 return flag;

}
	public static boolean studentInstitution(String country,String state,String city,String institute,String programType,String year) throws Throwable{
		boolean flag=true;
		try{
	
			 selectByVisibleText(ElsevierObjects.Hesi_Student_country,country,"Enter Institute country");
			 Thread.sleep(high);
			 selectByVisibleText(ElsevierObjects.Hesi_Student_state,state,"Enter Institution state");
		     Thread.sleep(high);
			 driver.findElement(ElsevierObjects.Hesi_Student_City).sendKeys(city);
			 driver.findElement(ElsevierObjects.Hesi_Student_City).sendKeys(Keys.ENTER);
			 Thread.sleep(high);
		     type(ElsevierObjects.Hesi_Student_institute,institute,"Enter institute name");
		     Thread.sleep(high);
		     selectByVisibleText(ElsevierObjects.Hesi_Student_prgtype,programType,"Enter Program type");
		     Thread.sleep(high);
		     selectByVisibleText(ElsevierObjects.Hesi_Student_year,year,"Enter year of graduation");
		   	 Thread.sleep(high);
		     click(ElsevierObjects.Hesi_Student_continue,"Click on continue button");
			 Thread.sleep(medium);		
			 
	}
	catch(Exception e){
		System.out.println(e.getMessage());
	}
	 return flag;
	}
	public static boolean searchProduct() throws Throwable{
		String product = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("Product"); 
		String productCost = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("ProductCost");
		return searchProduct(product,productCost);
	}
	
	/** Generic Method for adding the product to cart.
	 * 
	 * @param product
	 * @return
	 * @throws Throwable
	 */
	public static boolean addProductToCart(Map<String, String> prodCartMap) throws Throwable
	{  
		boolean flag=true;
try
{
		Thread.sleep(medium);
		if(!click(ElsevierObjects.Student_RequestProduct_btn,"Click the REGISTER For This Now button.")){
			 flag=false;
		}
		
		// no longer applies
		/*Thread.sleep(high);
		if(!clickOnOkButtonIfVisible()){
			 flag=false;
		}*/

		//Enter the data for 'Content Plus Course Tool', if the dialog is displayed for 'Content Plus Course Tool'.
		if(prodCartMap.get("VerifyDetailsOfContentPlusCourseTools")!=null && 
				prodCartMap.get("VerifyDetailsOfContentPlusCourseTools").equalsIgnoreCase("Yes")){
			contentPlusCourseTools(prodCartMap);
		}
		
		Thread.sleep(medium);
		//Verifies the title
		if(!waitForElementPresent(ElsevierObjects.Student_Page_MyCart,"My Cart")){
			flag=false;
		}

		//Verify ISBN
		if(prodCartMap.get("Product")!=null){
			if(!getText(ElsevierObjects.Student_Product_ISBN, "Fetch ISBN Number").contains(prodCartMap.get("Product"))){
				 flag=false;
			}			
		}
		
		//Verify the Price.
		if(prodCartMap.get("Product")!=null){
			String xpath = Accessories.fetchDynamicLocator(ElsevierObjects.Student_product_Edition_Price.toString(),ElsevierObjects.ReplaceString1, prodCartMap.get("Product").trim());
			if(!waitForElementPresent(By.xpath(xpath),"Price of Edition")){
				flag=false;
			}
		}		
		Thread.sleep(medium);
}
catch(Exception e)

{

sgErrMsg=e.getMessage();

return false;

}
		return flag;
	}
	
	/** Generic method for entering the Content Plus course information.
	 * 
	 * @param contentMap
	 * @return
	 * @throws Throwable
	 */
	public static boolean contentPlusCourseTools(Map<String, String> contentMap) throws Throwable{
		boolean flag = true;
		try
		{
		Thread.sleep(medium);
		if(!switchToFrameByLocator(ElsevierObjects.Student_BillingAdd_ModalDialog, "Switch to IFrame")){
			flag=false;
		}
		
		//Check checkbox 'Evolve'.
		if(contentMap.get("CourseToolChkbox")!=null && contentMap.get("CourseToolChkbox").equalsIgnoreCase("Evolve")){
			if(!isChecked(ElsevierObjects.Faculty_ContentPlus_CourseTools_Chkbx,"Click checkbox 'Evolve, Content Plus Course Tools'.")){
				 flag=false;
			}			
		}

		//Check checkbox 'Evolve'.
		if(contentMap.get("CourseToolChkbox")!=null && contentMap.get("CourseToolChkbox").equalsIgnoreCase("LMS")){
			if(!isChecked(ElsevierObjects.Faculty_ContentPlus_LMS_Chkbx,"Click checkbox 'LMS'.")){
				 flag=false;
			}			
		}		
		
		//Select 'Course Section'
		if(contentMap.get("CourseSection")!=null){
			if(!selectByVisibleText(ElsevierObjects.Faculty_ContentPlus_CourseSection, contentMap.get("CourseSection"), "Select Course Section.")){
				flag = false;
			}
		}
		
		//Enter 'Projected Course Enrollment'
		if(contentMap.get("ProjectedCourseEnrollment")!=null){
			if(!type(ElsevierObjects.Faculty_ContentPlus_PCE, contentMap.get("ProjectedCourseEnrollment"), "Enter 'Projected Course Enrollment'.")){
				flag = false;
			}
		}
		
		//Enter Comment.
		if(contentMap.get("Comment")!=null){
			if(!type(ElsevierObjects.Faculty_ContentPlus_Comment, contentMap.get("Comment"), "Enter 'Comment'.")){
				flag = false;
			}
		}
		
		String actionToPerform = contentMap.get("ActionToPerform");
		//Click 'Apply' button.		
		if(actionToPerform!=null && actionToPerform.equalsIgnoreCase("Apply")){
			if(!click(ElsevierObjects.Faculty_ContentPlus_ApplyButton,"Click on Apply Button")){
				flag = false;
	    	}
		}

		//Click 'Cancel' button.
		if(actionToPerform!=null && actionToPerform.equalsIgnoreCase("Cancel")){
			if(!click(ElsevierObjects.Faculty_ContentPlus_CancelButton,"Click on Cancel Button")){
				flag = false;
	    	}
		}
		
		//Click 'X' button.
		if(actionToPerform!=null && actionToPerform.equalsIgnoreCase("FrameClose")){
			if(!click(ElsevierObjects.frame_close,"Click on Apply Button")){
				flag = false;
	    	}
		}	
		
		if(!switchToDefaultFrame()){
			flag = false;
		}
		Thread.sleep(medium);		
		}
		catch(Exception e)

		{

		sgErrMsg=e.getMessage();

		return false;
		}

		return flag;
	}	
	
	/** Click on 'Ok' button if it is present while adding the product to cart. 
	 * Note: 'Ok' button is displayed only for the new User.
	 * 
	 * @return
	 * @throws Throwable
	 */
	public static boolean clickOnOkButtonIfVisible() throws Throwable{
		boolean flag = true;

			try{
				WebElement okButton = driver.findElement(ElsevierObjects.Student_Update_Account_PopUp);
				if(okButton.isDisplayed()){
					if(!click(ElsevierObjects.Student_Update_Account_PopUp,"Click on 'OK' button.")){
						flag=false;
					}				
				}					
			}catch (NoSuchElementException e1) {
				System.out.println("'Popup'is not displayed.");
				//Note: Don't make "flag=false;" in 'catch' block, since application display's 'Main Page' links only some times.
			}
		
		return flag;
	}
	
	//Add product to Cart.
	public static boolean addProductToCart() throws Throwable{
		return addProductToCart(readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")));
	}
	
	//Checkout the product.
	public static boolean checkOut() throws Throwable{
		boolean flag=true;
		
		Thread.sleep(medium);
		if(!click(ElsevierObjects.Student_MyCart_Checkout_btn,"click the checkout button")){
			flag=false;
		}
		
		Thread.sleep(medium);
		String updateAccountTitle = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("UpdateAccountTitle");
		if(!getText(ElsevierObjects.Student_Update_Account, "Verify title 'Update your Account'").equalsIgnoreCase(updateAccountTitle)){
			 flag=false;
		}
		
		return flag;
	}
	
	public static boolean formFill(Map<String, String> formMap, String user) throws Throwable{
		boolean flag = true;
		try{
		Thread.sleep(medium);
		
		EMAIL_ID =  driver.findElement(ElsevierObjects.educator_form_txtEmail).getAttribute("value");
		if(EMAIL_ID!=null){
			Reporters.SuccessReport("Verify the User is taken to the Update your Account page. ", "User is successfully taken to the Update your Account page. ");
		}else{
			Reporters.failureReport("Verify the User is taken to the Update your Account page. ", "User is not taken to the Update your Account page. ");
		}
		/*if(formMap.get("FirstName")!=null){
			if(!type(ElsevierObjects.educator_form_txtFirstName,formMap.get("FirstName"), "First Name")){
				flag = false;
			}			
		}
		
		if(formMap.get("LastName")!=null){
			if(!type(ElsevierObjects.educator_form_txtLastName,formMap.get("LastName"), "Last Name")){
				flag = false;
			}
		}

		if(formMap.get("Email")!=null){		
			if(!type(ElsevierObjects.educator_form_txtEmail,formMap.get("Email"), "Email")){
				flag = false;
			}
		}

		if(formMap.get("ConfirmEmail")!=null){		
			if(!type(ElsevierObjects.educator_form_txtConformEmail,formMap.get("ConfirmEmail"), "ConformEmail")){
				flag = false;
			}
		}*/
		/*click(ElsevierObjects.User_form_ddInstutionCountry, "Country");
		Thread.sleep(low);
		
		selectByVisibleText(ElsevierObjects.User_form_ddInstutionCountry,formMap.get("CountryValue") , "country of institution.");
        Thread.sleep(low);
         driver.findElement(ElsevierObjects.User_form_ddInstutionCountry).sendKeys(Keys.ENTER);
        click(ElsevierObjects.User_form_State, "State");
        String state=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("State");
        selectByVisibleText(ElsevierObjects.User_form_State,state, "Select State institution.");
        driver.findElement(ElsevierObjects.User_form_State).sendKeys(Keys.ENTER);				
		type(ElsevierObjects.User_form_City,"test", "Street Adress");
		driver.findElement(ElsevierObjects.User_form_City).sendKeys(Keys.TAB);*/
         
	/*	if(formMap.get("CountryValue")!=null){			
			if(!selectByValue(ElsevierObjects.educator_form_ddInstutionCountry, formMap.get("CountryValue") ," Click on dropdown")){
				flag = false;
			}
		}*/
		
		selectByValue(ElsevierObjects.Institution_Country, "IN", "Country");
		
		if(formMap.get("InstutionName")!=null){		
			if(!type(ElsevierObjects.educator_form_txtInstution,"Indianinstitute", "InstutionName")){
				flag = false;
			}
		}

		//for Faulty User
		if(user.equalsIgnoreCase(ElsevierObjects.EDUCATOR)){
			if(formMap.get("InstutionAdd")!=null){
				if(!type(ElsevierObjects.educator_form_txtAddress,formMap.get("InstutionAdd"), "InstutionAdd")){
					flag = false;
				}			
			}
		}

		//for Faulty User
		if(user.equalsIgnoreCase(ElsevierObjects.EDUCATOR)){
			if(formMap.get("InstutionAdd2")!=null){
				if(!type(ElsevierObjects.Student_Update_Account_Address2,formMap.get("InstutionAdd2"), "InstutionAdd2")){
					flag = false;
				}			
			}
		}

		//for Faulty User
		if(user.equalsIgnoreCase(ElsevierObjects.EDUCATOR)){
			if(formMap.get("Province")!=null){
				if(!type(ElsevierObjects.Student_Update_Account_State,formMap.get("Province"), "Province")){
					flag = false;
				}
			}
		}
		
		//for Faulty User
		if(user.equalsIgnoreCase(ElsevierObjects.EDUCATOR)){
			if(formMap.get("Town")!=null){
				if(!type(ElsevierObjects.Student_Update_Account_City,formMap.get("Town"), "Town")){
					flag = false;
				}	
			}
		}
		
		if(formMap.get("ProgramValue")!=null){
			if(!selectByValue(ElsevierObjects.educator_form_txtddprogramType,formMap.get("ProgramValue") ," Click on dropdown")){
				flag = false;
			}	
		}
		
		//for Student User 
		if(user.equalsIgnoreCase(ElsevierObjects.STUDENT)){
			if(formMap.get("GraduationYear")!=null){
				if(!selectByValue(ElsevierObjects.Student_Update_Account_GraduationYear,formMap.get("GraduationYear") ," Click on dropdown")){
					flag = false;
				}			
			}
		}

		if(user.equalsIgnoreCase(ElsevierObjects.STUDENT)){
			if(formMap.get("StudentID")!=null){
				if(!type(ElsevierObjects.Student_Update_Account_StudentID,formMap.get("StudentID"), "StudentID")){
					flag = false;
				}
			}
		}
		
		//for Faulty User
		if(user.equalsIgnoreCase(ElsevierObjects.EDUCATOR)){
			if(formMap.get("PhoneNumber")!=null){
				if(!type(ElsevierObjects.educator_form_txtAddPhone, formMap.get("PhoneNumber"), "PhoneNumber")){
					flag = false;
				}
			}
		}

		//for Faulty User
		if(user.equalsIgnoreCase(ElsevierObjects.EDUCATOR)){
			if(formMap.get("PostalCode")!=null){
				if(!type(ElsevierObjects.educator_form_txtAddPostalCode,formMap.get("PostalCode"), "PostalCode")){
					flag = false;
				}
			}
		}	
		
		//Need to add some more logic for handling billing address.
		enterBillingAddress(formMap);
		Thread.sleep(medium);
		if(!javaClick(ElsevierObjects.educator_form_btnContinue,"Clicked on Continue Button")){
			flag = false;
    	}
		}catch(Exception e){
			System.out.println(sgErrMsg="Error occurred");
		}
		return flag;
	}	
	
	/*public static boolean formFill(Map<String, String> formMap, String user) throws Throwable{
		boolean flag = true;
		
		Thread.sleep(medium);
		
		if(formMap.get("FirstName")!=null){
			if(!type(ElsevierObjects.educator_form_txtFirstName,formMap.get("FirstName"), "First Name")){
				flag = false;
			}			
		}
		
		if(formMap.get("LastName")!=null){
			if(!type(ElsevierObjects.educator_form_txtLastName,formMap.get("LastName"), "Last Name")){
				flag = false;
			}
		}

		if(formMap.get("Email")!=null){		
			if(!type(ElsevierObjects.educator_form_txtEmail,formMap.get("Email"), "Email")){
				flag = false;
			}
		}

		if(formMap.get("ConfirmEmail")!=null){		
			if(!type(ElsevierObjects.educator_form_txtConformEmail,formMap.get("ConfirmEmail"), "ConformEmail")){
				flag = false;
			}
		}
		
		if(formMap.get("CountryValue")!=null){			
			if(!selectByValue(ElsevierObjects.educator_form_ddInstutionCountry, formMap.get("CountryValue") ," Click on dropdown")){
				flag = false;
			}
		}
		
		if(formMap.get("InstutionName")!=null){		
			if(!type(ElsevierObjects.educator_form_txtInstution,formMap.get("InstutionName"), "InstutionName")){
				flag = false;
			}
		}

		//for Faulty User
		if(user.equalsIgnoreCase(ElsevierObjects.EDUCATOR)){
			if(formMap.get("InstutionAdd")!=null){
				if(!type(ElsevierObjects.educator_form_txtAddress,formMap.get("InstutionAdd"), "InstutionAdd")){
					flag = false;
				}			
			}
		}

		//for Faulty User
		if(user.equalsIgnoreCase(ElsevierObjects.EDUCATOR)){
			if(formMap.get("InstutionAdd2")!=null){
				if(!type(ElsevierObjects.Student_Update_Account_Address2,formMap.get("InstutionAdd2"), "InstutionAdd2")){
					flag = false;
				}			
			}
		}

		//for Faulty User
		if(user.equalsIgnoreCase(ElsevierObjects.EDUCATOR)){
			if(formMap.get("Province")!=null){
				if(!type(ElsevierObjects.Student_Update_Account_State,formMap.get("Province"), "Province")){
					flag = false;
				}
			}
		}
		
		//for Faulty User
		if(user.equalsIgnoreCase(ElsevierObjects.EDUCATOR)){
			if(formMap.get("Town")!=null){
				if(!type(ElsevierObjects.Student_Update_Account_City,formMap.get("Town"), "Town")){
					flag = false;
				}	
			}
		}
		
		if(formMap.get("ProgramValue")!=null){
			if(!selectByValue(ElsevierObjects.educator_form_txtddprogramType,formMap.get("ProgramValue") ," Click on dropdown")){
				flag = false;
			}	
		}
		
		//for Student User 
		if(user.equalsIgnoreCase(ElsevierObjects.STUDENT)){
			if(formMap.get("GraduationYear")!=null){
				if(!selectByValue(ElsevierObjects.Student_Update_Account_GraduationYear,formMap.get("GraduationYear") ," Click on dropdown")){
					flag = false;
				}			
			}
		}

		if(user.equalsIgnoreCase(ElsevierObjects.STUDENT)){
			if(formMap.get("StudentID")!=null){
				if(!type(ElsevierObjects.Student_Update_Account_StudentID,formMap.get("StudentID"), "StudentID")){
					flag = false;
				}
			}
		}
		
		//for Faulty User
		if(user.equalsIgnoreCase(ElsevierObjects.EDUCATOR)){
			if(formMap.get("PhoneNumber")!=null){
				if(!type(ElsevierObjects.educator_form_txtAddPhone, formMap.get("PhoneNumber"), "PhoneNumber")){
					flag = false;
				}
			}
		}

		//for Faulty User
		if(user.equalsIgnoreCase(ElsevierObjects.EDUCATOR)){
			if(formMap.get("PostalCode")!=null){
				if(!type(ElsevierObjects.educator_form_txtAddPostalCode,formMap.get("PostalCode"), "PostalCode")){
					flag = false;
				}
			}
		}	
		
		//Need to add some more logic for handling billing address.
		enterBillingAddress(formMap);
		
		if(!click(ElsevierObjects.educator_form_btnContinue,"Clicked on Continue Button")){
			flag = false;
    	}
		 
		return flag;
	}	*/
	
	/** Enter Billing Address.
	 * 
	 * @param billingAddressMap
	 * @return
	 * @throws Throwable
	 */
	private static boolean enterBillingAddress(Map<String, String> billingAddressMap) throws Throwable{
		boolean flag = true;
		try
		{
		if(billingAddressMap.get("BillingAdd")!=null){
			if(!type(ElsevierObjects.Student_BillingAdd,billingAddressMap.get("BillingAdd"), "BillingAdd")){
				flag = false;
			}			
		}

		if(billingAddressMap.get("BillingAdd2")!=null){
			if(!type(ElsevierObjects.Student_BillingAdd2,billingAddressMap.get("BillingAdd"), "BillingAdd")){
				flag = false;
			}			
		}		

		if(billingAddressMap.get("BillingAdd2")!=null){
			if(!type(ElsevierObjects.Student_BillingAdd2,billingAddressMap.get("BillingAdd"), "BillingAdd")){
				flag = false;
			}			
		}		

		if(billingAddressMap.get("BillingCity")!=null){
			if(!type(ElsevierObjects.Student_BillingCity,billingAddressMap.get("BillingAdd"), "BillingAdd")){
				flag = false;
			}			
		}		
		
		if(billingAddressMap.get("ProgramValue")!=null){
			if(!selectByVisibleText(ElsevierObjects.Student_BillingState,billingAddressMap.get("BillingState") ," Click on dropdown")){
				flag = false;
			}	
		}
		
		if(billingAddressMap.get("BillingZipCode")!=null){
			if(!type(ElsevierObjects.evolve_User_Postal,billingAddressMap.get("BillingZipCode"), "Billing Zip Code")){
				flag = false;
			}			
		}		
		
		//Click on 'Edit This Address' or 'Use This Address'.
		/*if(billingAddressMap.get("BillingAddressButtonToProceed")!=null){
			String xpath = Accessories.fetchDynamicLocator(ElsevierObjects.Student_BillingAdd_ModalDialogButtons.toString(), 
					ElsevierObjects.ReplaceString1, billingAddressMap.get("BillingAddressButtonToProceed"));
			if(!click(By.xpath(xpath),"Clicked on Continue Button")){
				flag = false;
	    	}
		}*/
		}
		catch(Exception e)

		{

		sgErrMsg=e.getMessage();

		return false;

		}
		return flag;
	}
	
	//Fill 'Update Your Account" Form.
	public static boolean formFill(String user) throws Throwable{
		try
		{
		Map<String, String> formMap = new HashMap<String, String>();
		String[] testDataArr = new String[]{"FirstName", "LastName", "CountryValue", "InstutionName", "InstutionAdd", "InstutionAdd2",
								"Town", "Province", "PostalCode", "PhoneNumber", "ProgramValue", "GraduationYear"};
		
		for(String testData : testDataArr){
			formMap.put(testData, readcolumns.twoColumns(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get(testData));
		}
		
		ReadingExcel.updateCellValue(6, 1, configProps.getProperty("TestData"), "TC-8571 & 9826");
		formMap.put("Email", readcolumns.twoColumns(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("Email"));
		
		ReadingExcel.updateCellValue(7, 1, configProps.getProperty("TestData"), "TC-8571 & 9826");
		formMap.put("ConfirmEmail", readcolumns.twoColumns(0, 1,"TC-8571 & 9826", configProps.getProperty("TestData")).get("ConfirmEmail"));
	
		ReadingExcel.updateCellValue(18, 1, configProps.getProperty("TestData"), "TC-8571 & 9826");
		formMap.put("StudentID", readcolumns.twoColumns(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("StudentID"));
		
		return formFill(formMap, user);
		}
		catch(Exception e)

		{

		sgErrMsg=e.getMessage();

		}
		return false;

	}		
	
	
	
	
	
	public static boolean submitOrder(String user) throws Throwable{
		boolean flag = true;
		
		Thread.sleep(medium);
		if(user == ElsevierObjects.EDUCATOR){
			if(!click(ElsevierObjects.evolveInstructorChk,"Click on Instructor checkbox")){
				flag=false;
			}
		}
		
		if(!click(ElsevierObjects.evolveRegisterAcceptChk,"Click on Register checkbox")){
			flag=false;
		}
		
		if(!click(ElsevierObjects.instructor_submit,"Click on Submit button")){
			flag=false;
		}
		return flag;
	}
	
	/** Generic method for searching courseId in CourseList.
	 * 
	 * @param courseId
	 * @return
	 * @throws Throwable
	 */
	public static boolean verifyCourseListContainsCourseID(String courseId) throws Throwable{
		boolean flag = true;
		try
		
		{
		Thread.sleep(high);
		//Click on 'MyEvolve' tab.
		if(!click(ElsevierObjects.Student_Update_Account_MyEvolveTab,"Click on 'MyEvolve' tab.")){
			flag=false;
		}

		int contentList = getElements(ElsevierObjects.Student_Update_Account_UserContentList).size();
		
		List<String> courseList = new ArrayList<String>();  
		for(int index=1; index<=contentList; index++){
			String xpath = Accessories.fetchDynamicLocator(ElsevierObjects.Student_Update_Account_UserContent.toString(),ElsevierObjects.ReplaceString1, index+"");
			courseList.add(getText(By.xpath(xpath), "Fetch CourseId"));
		}

		if(!courseList.contains(courseId)){
			 flag=false;
		}
		}
		catch(Exception e)

		{

		sgErrMsg=e.getMessage();

		return false;

		}

		return flag;
	}
	
	//Verify CourseList contains courseId.
	public static boolean verifyCourseListContainsCourseID() throws Throwable{
		String courseId = readcolumns.twoColumns(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("CourseID");
		return verifyCourseListContainsCourseID(courseId);
	}
	
	/** Generic method for clicking the ContentLink based on the courseId.
	 * 
	 * @param courseId
	 * @return
	 * @throws Throwable
	 */
	public static boolean clickContentLink(String courseId) throws Throwable{
		boolean flag = true;
		try
		{
		Thread.sleep(medium);
		int contentList = getElements(ElsevierObjects.Student_Update_Account_UserContentList).size();
		for(int index=1; index<=contentList; index++){
			String xpath = Accessories.fetchDynamicLocator(ElsevierObjects.Student_Update_Account_UserContent.toString(),ElsevierObjects.ReplaceString1, index+"");
			if((getText(By.xpath(xpath),"Fetch CourseId").equals(courseId))){
				String contetLinkXpath = Accessories.fetchDynamicLocator(ElsevierObjects.Student_Update_Account_ContentLink.toString(),ElsevierObjects.ReplaceString1, index+"");

				//Click on content link.
				if(!click(By.xpath(contetLinkXpath),"Click on 'content link'.")){
					flag=false;
				}
			}
		}
		}
		catch(Exception e)

		{

		sgErrMsg=e.getMessage();

		return false;
		}
		return flag;
	}
	
	//Click on the contentLink.
	public static boolean clickContentLink() throws Throwable{
		String courseId = readcolumns.twoColumns(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("CourseID");
		return clickContentLink(courseId);
	}
	
	/** Generic method for verifying course title.
	 * 
	 * @return
	 * @throws Throwable
	 */
	public static boolean verifyCourseTitle(String courseTitle) throws Throwable{
		boolean flag = true;
		 Thread.sleep(medium);
		 
		 if(!verifyText(ElsevierObjects.Educator_CourseId_Title, courseTitle, "Online couse Title")){
			 flag=false;
		 }
		return flag;		
	}
	
	//Verify's courseTitle.
	public static boolean verifyCourseTitle() throws Throwable{
		String courseTitle = readcolumns.twoColumns(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("CourseTitle");
		return verifyCourseTitle(courseTitle);
	}
	
	/** Generic method for verifying SubFolder names in Resource Folder.
	  * 
	  * @param subFolderNames
	  * @return
	  * @throws Throwable
	  */
	 public static boolean verifyResourcesSubFolderNames(String[] subFolderNames) throws Throwable{
	  boolean flag = true;
	  try
	  {
	  Thread.sleep(medium);
	  int resourceSubFolderList = getElements(ElsevierObjects.Student_Update_Account_ResourcesFolder_SubfolderList).size();
	  
	  List<String> subFolderList = new ArrayList<String>();  
	  for(int index=1; index<=resourceSubFolderList; index++){
	   String xpath = Accessories.fetchDynamicLocator(ElsevierObjects.Student_Update_Account_ResourcesFolder_SubfolderName.toString(),ElsevierObjects.ReplaceString1, index+"");
	   subFolderList.add(getText(By.xpath(xpath), "Fetch CourseId"));
	  }
	        
	  for(String subFolderName : subFolderNames){
	   if(!subFolderList.contains(subFolderName.trim())){
	     flag=false;
	   } 
	  }
	  }
	  catch(Exception e)

	  {

	  sgErrMsg=e.getMessage();

	  return false;
	  }
	  return flag;
	 }
	
	
	

	
}
