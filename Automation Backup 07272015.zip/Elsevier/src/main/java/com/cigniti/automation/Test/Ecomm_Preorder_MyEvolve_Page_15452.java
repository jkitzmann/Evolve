package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EComm_Preorder_MyEvolve_Page_15452_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;


public class Ecomm_Preorder_MyEvolve_Page_15452  extends EComm_Preorder_MyEvolve_Page_15452_Bussiness_Functions{

	public static final String CINICAL_MEDICAL_ASSISTANT_ONLINE =ReadingExcel.columnDataByHeaderName("product", "TC-15452", testDataPath);
	@Test
	public void eCommPreorderMyEvolvePage15452() throws Throwable{
		String pubDatePreOrder=ReadingExcel.columnDataByHeaderName("pubDatePreOrder", "TC-15452", testDataPath);
		String pubDatePreOrderStatus=ReadingExcel.columnDataByHeaderName("pubDateStatusPreOrder", "TC-15452", testDataPath);
		String pubDatePostOrder=ReadingExcel.columnDataByHeaderName("pubDatePostOrder", "TC-15452", testDataPath);
		String pubDatePostOrderStatus=ReadingExcel.columnDataByHeaderName("pubDatePostStatus", "TC-15452", testDataPath);
		
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//ElsevierObjects.browserType ="Firefox";
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		
		//String product=ReadingExcel.columnDataByHeaderName("product", "TC-15452", testDataPath);
		//louniqueCourse.uniqueCourseLOFaculty("TC-15452",product, 1);
		
		//String protectionSche="EV-65661450-c6d0-4366-9751-b16d4980756c";
		String courseID=ReadingExcel.columnDataByHeaderName("CourseID", "TC-15452", testDataPath);
		//Thread.sleep(veryhigh);
		ZFindProtectionSchemeSelfStudyCourse_Script_15571 zFind = new ZFindProtectionSchemeSelfStudyCourse_Script_15571();
		zFind.findProtectionSchemeSelfStudyCourse_15571(courseID,"");
		
		//protectionSchemeID="EV-65661450-c6d0-4366-9751-b16d4980756c";
		System.out.println("Protection Shcemem==>"+protectionSchemeID);
		
		//System.out.println("CourseId===>>>"+EvolveCommonBussinessFunctions.courseID1);
		
		
		adminLogin();
		
		editResource(CINICAL_MEDICAL_ASSISTANT_ONLINE);
		
		modifyPublicatonDate(pubDatePreOrder,pubDatePreOrderStatus);
		
		writeReport(launchUrl(configProps.getProperty("NoCacheURL")), "Run the URL https://evolvetest.elsevier.com/cs/noCache", "Successfully ran the URL https://evolvetest.elsevier.com/cs/noCache", "Failed to run the URL https://evolvecert.elsevier.com/cs/noCache");
		Thread.sleep(medium);
		driver.navigate().back();
		Thread.sleep(high);
		createAccessCode(CINICAL_MEDICAL_ASSISTANT_ONLINE);
		Thread.sleep(medium);
		//adminLogout();
		compareProtectionScheme(protectionSchemeID);
		writeReport(Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions.CreateNewUser("student", "eCommPreorderMyEvolvePage15452", "ECommercePreOrder", 7, 1,2,0), "Create New Student user", "Successfully created new student user with credentials: <br> Username: "+credentials[0]+"<br> Password : "+credentials[1], "Failed to create a new student account");
		String studentUserName = EvolveCommonBussinessFunctions.credentials[0];
		String studentPasswrod = EvolveCommonBussinessFunctions.credentials[1];
		System.out.println(studentUserName +","+ studentPasswrod);
		
		searchISBNNumber(CINICAL_MEDICAL_ASSISTANT_ONLINE);
		
		studnetCheckOut(true,CINICAL_MEDICAL_ASSISTANT_ONLINE);
		
		adminLogin();
		
		editResource(CINICAL_MEDICAL_ASSISTANT_ONLINE);
		
		modifyPublicatonDate(pubDatePostOrder,pubDatePostOrderStatus);
		
		writeReport(launchUrl(configProps.getProperty("NoCacheURL")), "Run the URL https://evolvetest.elsevier.com/cs/noCache", "Successfully ran the URL https://evolvetest.elsevier.com/cs/noCache", "Failed to run the URL https://evolvecert.elsevier.com/cs/noCache");
		
		
	}
	
	@AfterTest
	public void closeBrowser() throws Throwable{
		HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		Base.tearDown();
	}
}
