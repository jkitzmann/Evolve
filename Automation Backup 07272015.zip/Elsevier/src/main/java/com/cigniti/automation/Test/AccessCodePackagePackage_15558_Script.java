package com.cigniti.automation.Test;

import java.util.Random;

import org.apache.http.auth.Credentials;
import org.eclipse.jetty.util.security.Credential;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.AccessCodePackagePaperbacksACMPackage_15557;
import com.cigniti.automation.BusinessFunctions.AccessCodePackageUnassignedAccessCodesUpload_10213;
import com.cigniti.automation.BusinessFunctions.AcesscodeBusinessfunctions15558;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.FileDelete;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class AccessCodePackagePackage_15558_Script extends AccessCodePackagePaperbacksACMPackage_15557{

	@Test
	public void AccessCodePackagePackage_15558Script() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			//ElsevierObjects.adminBrowserType="firefox";
			String filePath = ReadingExcel.columnDataByHeaderName("Filepath", "Tc-15558",configProps.getProperty("TestData"));
			String downloadpath = ReadingExcel.columnDataByHeaderName("DownloadPath", "Tc-15558",configProps.getProperty("TestData"));
			//String validAccessCodes=ReadingExcel.getCell(1, 2, filePath, "UploadFile");

			String shippingAdress=ReadingExcel.columnDataByHeaderName("student_StreetAdress", "Tc-15558",configProps.getProperty("TestData"));
			String shippingCity=ReadingExcel.columnDataByHeaderName("student_City", "Tc-15558",configProps.getProperty("TestData"));
			String shippingState=ReadingExcel.columnDataByHeaderName("student_State", "Tc-15558",configProps.getProperty("TestData"));
			String shippingZip=ReadingExcel.columnDataByHeaderName("student_ZipCode", "Tc-15558",configProps.getProperty("TestData"));
			String VSTPassword=ReadingExcel.columnDataByHeaderName("VKno_Password", "Tc-15558",configProps.getProperty("TestData"));
			String studentSecurityQuestion=ReadingExcel.columnDataByHeaderName("Student_Secu_Que", "Tc-15558",configProps.getProperty("TestData"));
			String studentSecurityAns=ReadingExcel.columnDataByHeaderName("Student_Sec_Ans", "Tc-15558",configProps.getProperty("TestData"));
			String KNOPassword=ReadingExcel.columnDataByHeaderName("KNO_Pwd", "Tc-15558",configProps.getProperty("TestData"));
			String ISBNPkg=ReadingExcel.columnDataByHeaderName("ISBNPkg", "Tc-15558",configProps.getProperty("TestData"));

			String ISBNPkgname=ReadingExcel.columnDataByHeaderName("ISBNPkgname", "Tc-15558",configProps.getProperty("TestData"));


			String ISBN1=ReadingExcel.columnDataByHeaderName("ISBN1", "Tc-15558",configProps.getProperty("TestData"));
			String ISBN2=ReadingExcel.columnDataByHeaderName("ISBN2", "Tc-15558",configProps.getProperty("TestData"));
			String ISBN3=ReadingExcel.columnDataByHeaderName("ISBN3", "Tc-15558",configProps.getProperty("TestData"));
			String ISBN4=ReadingExcel.columnDataByHeaderName("ISBN4", "Tc-15558",configProps.getProperty("TestData"));
			String ISBN5=ReadingExcel.columnDataByHeaderName("ISBN5", "Tc-15558",configProps.getProperty("TestData"));
			String ISBN6=ReadingExcel.columnDataByHeaderName("ISBN6", "Tc-15558",configProps.getProperty("TestData"));
			String ISBN7=ReadingExcel.columnDataByHeaderName("ISBN7", "Tc-15558",configProps.getProperty("TestData"));
			String ISBN8=ReadingExcel.columnDataByHeaderName("ISBN8", "Tc-15558",configProps.getProperty("TestData"));
			String ISBN9=ReadingExcel.columnDataByHeaderName("ISBN9", "Tc-15558",configProps.getProperty("TestData"));
			
            String month_txt=ReadingExcel.columnDataByHeaderName("month_txt", "Tc-15558",configProps.getProperty("TestData"));
			String day_txt=ReadingExcel.columnDataByHeaderName("day_txt", "Tc-15558",configProps.getProperty("TestData"));
			String year_txt=ReadingExcel.columnDataByHeaderName("year_txt", "Tc-15558",configProps.getProperty("TestData"));
			String Daysaccess_txt=ReadingExcel.columnDataByHeaderName("Daysaccess_txt", "Tc-15558",configProps.getProperty("TestData"));
			String CountGenerate_txt=ReadingExcel.columnDataByHeaderName("CountGenerate_txt", "Tc-15558",configProps.getProperty("TestData"));
			String verifycount="";
			
	
			Random ra = new Random( System.currentTimeMillis() );
			String isbnPkg=ISBNPkg;
	        ISBNPkg = isbnPkg+Integer.toString((1 + ra.nextInt(2)) * 10000+ ra.nextInt(10000));
			
	        stepReport("Login to Evolve Admin.");
	        writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials : "+ configProps.getProperty("AdminUser"),
					"Launching the URL for User is successful </br > Login to Application Using User credentails : "+configProps.getProperty("AdminUser")+" is Successful",
					"Launching and Login to Application Using User credentails : "+ configProps.getProperty("AdminUser")+" is Failed");

			stepReport("Create new access code package.");
	        AcesscodeBusinessfunctions15558.createAccesscode(ISBNPkg, ISBNPkgname);

			stepReport("Add ISBNs to access code package.");
	        writeReport(AcesscodeBusinessfunctions15558.AddISBN(ISBN1), "ISBN Successfully Added", ISBN1+": ISBN Successfully Added to PackageName: "+ISBNPkgname, "Failed to ADD ISBN to Pacakge");
			writeReport(AcesscodeBusinessfunctions15558.AddISBN(ISBN2), "ISBN Successfully Added", ISBN2+": ISBN Successfully Added to PackageName: "+ISBNPkgname, "Failed to ADD ISBN to Pacakge");
			writeReport(AcesscodeBusinessfunctions15558.AddISBN(ISBN3), "ISBN Successfully Added", ISBN3+": ISBN Successfully Added to PackageName: "+ISBNPkgname, "Failed to ADD ISBN to Pacakge");
			writeReport(AcesscodeBusinessfunctions15558.AddISBN(ISBN4), "ISBN Successfully Added", ISBN4+": ISBN Successfully Added to PackageName: "+ISBNPkgname, "Failed to ADD ISBN to Pacakge");
			writeReport(AcesscodeBusinessfunctions15558.AddISBN(ISBN5), "ISBN Successfully Added", ISBN5+": ISBN Successfully Added to PackageName: "+ISBNPkgname, "Failed to ADD ISBN to Pacakge");
			writeReport(AcesscodeBusinessfunctions15558.AddISBN(ISBN6), "ISBN Successfully Added", ISBN6+": ISBN Successfully Added to PackageName: "+ISBNPkgname, "Failed to ADD ISBN to Pacakge");
			writeReport(AcesscodeBusinessfunctions15558.AddISBN(ISBN7), "ISBN Successfully Added", ISBN7+": ISBN Successfully Added to PackageName: "+ISBNPkgname, "Failed to ADD ISBN to Pacakge");
			writeReport(AcesscodeBusinessfunctions15558.AddISBN(ISBN8), "ISBN Successfully Added", ISBN8+": ISBN Successfully Added to PackageName: "+ISBNPkgname, "Failed to ADD ISBN to Pacakge");
			writeReport(AcesscodeBusinessfunctions15558.AddISBN(ISBN9), "ISBN Successfully Added", ISBN9+": ISBN Successfully Added to PackageName: "+ISBNPkgname, "Failed to ADD ISBN to Pacakge");
			Thread.sleep(medium);

			stepReport("Create unassigned access codes.");
			writeReport(AcesscodeBusinessfunctions15558.NavigatetoUnassigncodes(), "Navigate to  Create Unassigned Access Code ","Navigate to  Create Unassigned Access Code is successful", "Failed to Navigate to  Create Unassigned Access Code ");
			Thread.sleep(medium);
			
			AcesscodeBusinessfunctions15558.verifyCodeCreation_15558(month_txt, day_txt, year_txt, CountGenerate_txt);
			
			stepReport("Download unassigned access codes.");
			if(AccessCodePackageUnassignedAccessCodesUpload_10213.clickDownloadAndCompareNotePadDataWithStringliterals())
			{
				Reporters.SuccessReport("Verify Access Codes generated", "Access Codes text file is downloaded and String literals verified successfully in the above steps");
			}
			else
			{
				Reporters.failureReport("Verify Access Codes generated", "Access Codes text file failed to download and String literals verified failed. ");
			}	
		
			stepReport("Upload the unassigned access codes.");
			click(ElsevierObjects.Admin_Evolve_lnk, "Click on Bread Crumb Evolve Admin");
			
			Thread.sleep(medium);

			if(AccessCodePackageUnassignedAccessCodesUpload_10213.accesscodeUploadLink())
			{
				Reporters.SuccessReport("Access Code Upload Link", "Successfully Clicked on Access Code Upload Link ");
			}
			else
			{
				Reporters.failureReport("Access Code Upload Link", "Successfully Clicked on Access Code Upload Link ");
			}
			
			
			if(AcesscodeBusinessfunctions15558.verifyCopyToExcel(filePath,downloadpath))
			{
				Reporters.SuccessReport("Copy the access codes data from text file to excel file", "Successfully Copied the access codes available <br> in the text file to the excel file to upload");
			}
			else
			{
				Reporters.failureReport("Copy the access codes data from text file to excel file", "failed to Copy the access codes available <br> in the text file to the excel file to upload");
			}
			
			
			for (int i=1;i<=Integer.parseInt(CountGenerate_txt);i++)
			{
			ReadingExcel.updateCellInSheet(i,1,filePath, "UploadFile", ISBNPkg);
			}
			
			if(AccessCodePackageUnassignedAccessCodesUpload_10213.uploadExcel(filePath))
			{
				Reporters.SuccessReport("Upload Excel File", "Excel File Uploaded Successfully ");
			}
			else
			{
				Reporters.failureReport("Upload Excel File", "Excel File Fialed to Upload");
			}
			
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			 CreateLOUniqueCourseFaculty_Script_15583 louniqueCourse=new CreateLOUniqueCourseFaculty_Script_15583();
		     
			 stepReport("Existing instructor creates new course #1.");
			 louniqueCourse.uniqueCourseLOFaculty("Tc-15558",ISBN1, 25);
		    
			 stepReport("Existing instructor creates new course #2.");
			 louniqueCourse.uniqueCourseLOFaculty("Tc-15558",ISBN2, 26);
		    
			 stepReport("Existing instructor creates new course #3.");
			 louniqueCourse.uniqueCourseLOFaculty("Tc-15558",ISBN8, 27);
		    
	
		     SwitchToBrowser(ElsevierObjects.studentBrowserType);
			stepReport("Create new student user.");
		     if(CreateNewUser(ElsevierObjects.STUDENT))
			{
				Reporters.SuccessReport("Create New Student user and log into the application", "Successfully Created new student user with the credentials : <br> Username : "+credentials[0]+"<br> Password : "+credentials[1]+" <br>Successfully logged in as New Student user");
			}
			
			else
			{
				Reporters.failureReport("Create New Student user and log into the application", "Failed to login as New Student user");
			}
			String user1="true";
			
			stepReport("Enter package access code on catalog page and begin checkout.");
			if(AcesscodeBusinessfunctions15558.EvolveCatalog(user1,filePath))
			{
				Reporters.SuccessReport("Redeemption of valid Code", "valid Redeem Code Message was Printed Successfully ");
			}
			else
			{
				Reporters.failureReport("Redeemption of valid Code", "Case Failed No valid Redeem Code Message was Printed ");
			}
			Thread.sleep(medium);
			
			stepReport("Complete checkout.");
			studentShippingOrder(shippingAdress, shippingCity, shippingState, shippingZip, VSTPassword, studentSecurityQuestion, studentSecurityAns, KNOPassword);

			Thread.sleep(medium);
			//User_BusinessFunction.Logout();
			Thread.sleep(medium);

			//String username=readcolumns.twoColumns(0,1, "DynamicCredentials", configProps.getProperty("TestData")).get("UserName");

	
			System.out.println("*********************************Login As Student****************************");
			
	/*		writeReport(User_BusinessFunction.Studentlogin("nuser3321", "abc@123"),"Login to Application Using User Credentials :"+sStudentUser,
	        		                                                                           "Launching the URL for User is successful </br > Login to Application Using User credentails :"+sStudentUser+" is Successful",
	        		           		                                                           "Launching and Login to Application Using User credentails : "+ sStudentUser+" is Failed");
		
		*/
	
			
			Thread.sleep(veryhigh);
			stepReport("Verify contents of My Evolve page.");
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			
		    AcesscodeBusinessfunctions15558.VerifyContentpage();
			String onlinecoureproductytpe=ReadingExcel.columnDataByHeaderName("ISBN2Producttype", "Tc-15558",configProps.getProperty("TestData"));
			String onlinecoursedetails=ReadingExcel.columnDataByHeaderName("ISBN2CourseDetails", "Tc-15558",configProps.getProperty("TestData"));
			String onlinebutton1=ReadingExcel.columnDataByHeaderName("ISBN2Button1", "Tc-15558",configProps.getProperty("TestData"));
			String onlinebutton2=ReadingExcel.columnDataByHeaderName("ISBN2Button2", "Tc-15558",configProps.getProperty("TestData"));
			String simcourseproductype=ReadingExcel.columnDataByHeaderName("ISBN1Producttype", "Tc-15558",configProps.getProperty("TestData"));
			String simcoursedetails=ReadingExcel.columnDataByHeaderName("ISBN1Course", "Tc-15558",configProps.getProperty("TestData"));
			String simcoursebutton=ReadingExcel.columnDataByHeaderName("ISBN1Button1", "Tc-15558",configProps.getProperty("TestData"));
			
			String knocourse=ReadingExcel.columnDataByHeaderName("ISBNKnoCoursedetails", "Tc-15558",configProps.getProperty("TestData"));
			String knoproductype=ReadingExcel.columnDataByHeaderName("ISBNknoProducttype", "Tc-15558",configProps.getProperty("TestData"));
			
			String vstcourse=ReadingExcel.columnDataByHeaderName("ISBNVSTCoursedetails", "Tc-15558",configProps.getProperty("TestData"));
			String vstproductype=ReadingExcel.columnDataByHeaderName("ISBNVSTProducttype", "Tc-15558",configProps.getProperty("TestData"));
			
			//AcesscodeBusinessfunctions15558.VerifyContentpagewithinputs("Online Course","Clinical Medical Assisting Online for Clinical Procedures for Medical Assistants, 9th Edition","Enter Instructor's Course ID","Enter as Independent Self-Study","Yes");
			stepReport("Verify appearance of Online Course in My Evolve.");
			AcesscodeBusinessfunctions15558.VerifyContentpagewithinputs(onlinecoureproductytpe,onlinecoursedetails,onlinebutton1,onlinebutton2,"Yes");
			
			stepReport("Verify appearance of Simulation in My Evolve.");
			AcesscodeBusinessfunctions15558.VerifyContentpagewithinputs(simcourseproductype,simcoursedetails,simcoursebutton,"","Yes");
			
			stepReport("Verify appearance of KNO in My Evolve.");
			AcesscodeBusinessfunctions15558.verifyProducttype(knoproductype);
			
			stepReport("Verify appearance of VST in My Evolve");
			AcesscodeBusinessfunctions15558.verifyProducttype(vstproductype);
		   //AcesscodeBusinessfunctions15558.VerifyContentpagewithinputs(simcourseproductype,simcoursedetails,simcoursebutton,"","Yes");
			
			//AcesscodeBusinessfunctions15558.VerifyContentpagewithinputs("Simulations - SimChart","SimChart 6-Month, 1st Edition","Enter Instructor's Course ID","","Yes");
			//AcesscodeBusinessfunctions15558.VerifyContentpagewithinputs("Resources","Evolve Resources for Modern Dental Assisting, 11th Edition","Enter Instructor's Course ID","","No");
			//AcesscodeBusinessfunctions15558.VerifyContentpagewithinputs("Kno","Structure & Function of the Body - Pageburst E-Book on Kno, 14th Edition","","","No");
			//AcesscodeBusinessfunctions15558.VerifyContentpagewithinputs("VitalSource","2011 ICD-9-CM Coding Theory and Practice with ICD-10 - Pageburst E-Book on VitalSource","","","No");
			
//			writeReport(AcesscodeBusinessfunctions15558.clickonbutton_coursedetails("Clinical Medical Assisting Online for Clinical Procedures for Medical Assistants, 9th Edition","Enter as Independent Self-Study"),"Click on Button under Course Details","Clicking on Button is Successful","Clicking on Button is not Successful");
			
			stepReport("Click self-study button for the online course product.");
			writeReport(AcesscodeBusinessfunctions15558.clickonbutton_coursedetails(onlinecoursedetails,onlinebutton2),"Click on Button under Course Details"+onlinebutton2,"Clicking on Button "+onlinebutton2+" is Successful on course"+onlinecoursedetails,"Clicking on Button"+onlinebutton2+" is not Successful on online course"+onlinecoursedetails);
			AcesscodeBusinessfunctions15558.confirmbutton();
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve"))
			{
				flag=false;
			}
			
			
			writeReport(AcesscodeBusinessfunctions15558.clickon_coursedetails(onlinecoursedetails),"Click on Course Details"+onlinecoursedetails,"Clicking on Course is Successful "+onlinecoursedetails,"Clicking on Course is not Successful "+onlinecoursedetails);
			//writeReport(AcesscodeBusinessfunctions15558.clickon_coursedetails("Clinical Medical Assisting Online for Clinical Procedures for Medical Assistants, 9th Edition"),"Click on Course Details","Clicking on Course is Successful","Clicking on Course is not Successful");
			Thread.sleep(high);
			
			stepReport("Launch Online Course and verify content.");
			AcesscodeBusinessfunctions15558.verifyingcoursedetailsafternavigationforcourse();
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve"))
			{
				flag=false;
			}
			Thread.sleep(high);
			//writeReport(AcesscodeBusinessfunctions15558.clickon_coursedetails("PBC Test - UAT0237 - SimChart eComm (SME), 1st Edition"),"Click on Course Details","Clicking on Course is Successful","Clicking on Course is not Successful");
			//FileDelete.deleteFile();
			
			stepReport("Enter instructor's course id for the Simulation product.");
			writeReport(AcesscodeBusinessfunctions15558.clickonbutton_coursedetails(simcoursedetails,simcoursebutton),"Click on Button under Course Details" +simcoursebutton,"Clicking on Button "+simcoursebutton+" is Successful on Course Details"+simcoursedetails,"Clicking on Button "+simcoursebutton+" is not Successful on course details"+simcoursedetails);
			String Courseid1=ReadingExcel.columnDataByHeaderName("LOCourseid1", "Tc-15558",configProps.getProperty("TestData"));
			Thread.sleep(high);
			
			AcesscodeBusinessfunctions15558.Entercourseid(Courseid1);
			
			stepReport("Launch Simulation and verify content.");
			writeReport(AcesscodeBusinessfunctions15558.clickon_coursedetails(simcoursedetails),"Click on Course Details"+simcoursedetails,"Clicking on Course is Successful:" +simcoursedetails,"Clicking on Button is not Successful :"+simcoursedetails);
			Thread.sleep(high);
			Thread.sleep(veryhigh);
			AcesscodeBusinessfunctions15558.verifyingcoursedetailsafternavigationforcontenthome();
			Thread.sleep(high);
			
			// don't think this is necessary anymore
			//AcesscodeBusinessfunctions15558.verifyHoneyPot();
			
			
			// Navigate to the Catalog tab
			stepReport("Enter final course id through Catalog page.");
			driver.findElement(ElsevierObjects.catalog).sendKeys(Keys.ENTER);
			
			String Courseid3=ReadingExcel.columnDataByHeaderName("LOCourseid3", "Tc-15558",configProps.getProperty("TestData"));
			AcesscodeBusinessfunctions15558.selfEnrollNavigate(Courseid3);
	
			Thread.sleep(high);
			
			stepReport("Login to Evolve Admin.");
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials : "+ configProps.getProperty("AdminUser"),
					"Launching the URL for User is successful </br > Login to Application Using User credentails : "+configProps.getProperty("AdminUser")+" is Successful",
					"Launching and Login to Application Using User credentails : "+ configProps.getProperty("AdminUser")+" is Failed");
			Thread.sleep(high);
			
			stepReport("Verify PAR details for student in Evolve Admin.");
			AcesscodeBusinessfunctions15558.adminPARVerify(credentials[0]);
			//AcesscodeBusinessfunctions15558.adminPARVerify("nuser3368");
			Thread.sleep(high);
			String coursestring1[]=Courseid1.split("_");
			String CourseDetails1=coursestring1[0];
			String PAR_Day1=ReadingExcel.columnDataByHeaderName("PAR_Day1", "Tc-15558",configProps.getProperty("TestData"));
			int iPAR_Day1=Integer.parseInt(PAR_Day1);
			
			String PAR_DAY2=ReadingExcel.columnDataByHeaderName("PAR_DAY2", "Tc-15558",configProps.getProperty("TestData"));
			int iPAR_Day2=Integer.parseInt(PAR_DAY2);
			
			writeReport(AcesscodeBusinessfunctions15558.verifytable(CourseDetails1,iPAR_Day1),"Verifying PAR details for ISBN"+ISBN1,"Verifying PAR details for ISBN is successful:"+ISBN1,"Verifying PAR details for ISBN1 is Not successful:"+ISBN1);
			
			String coursestring2[]=Courseid3.split("_");
			String CourseDetails3=coursestring2[0]+"_"+coursestring2[1];
			writeReport(AcesscodeBusinessfunctions15558.verifytable(CourseDetails3,iPAR_Day2),"Verifying PAR details for ISBN"+ISBN8,"Verifying PAR details for ISBN is successful:"+ISBN8,"Verifying PAR details for ISBN1 is Not successful:"+ISBN8);
			//AcesscodeBusinessfunctions15558.verifytable(ISBN8);
			
			FileDelete.deleteFile(downloadFilePath_15558);
			
		} catch (Exception e) {
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			//FileDelete.deleteFile();
			FileDelete.deleteFile(downloadFilePath_15558);
		}
		
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}


}