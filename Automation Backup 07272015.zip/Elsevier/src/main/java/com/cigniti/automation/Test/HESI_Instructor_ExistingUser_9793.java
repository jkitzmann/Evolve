package com.cigniti.automation.Test;

import java.util.Random;

import jxl.Sheet;

import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.CreateFacultyUserfromSplashPage_9799;
import com.cigniti.automation.BusinessFunctions.Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.HESI_BusinessFunction;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;


public class HESI_Instructor_ExistingUser_9793 extends User_BusinessFunction {
	
	//**************************** Declarations *****************************************************
 	public static Sheet inputSheetObj =null;
	//Random ra = new Random( System.currentTimeMillis() );
	@Test
	public void HESI_Instructor_ExistingUser9793() throws Throwable
	
	{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());

		String ISBN=ReadingExcel.columnDataByHeaderName("ISBN", "TC-9793", configProps.getProperty("TestData"));
		 	
		        
    
        //String HESIEducator=dynamicUserName;
        //String HESIEducatorPassword=dynamicPassword;
		
      
          //String HESIEducator="tfaculty493";
          //String HESIEducatorPassword="Test123";
        /*
    	String HESI_USER=configProps.getProperty("HESI_USER");        
        String HESI_Password=configProps.getProperty("HESI_Password");
        String HESIEducator=configProps.getProperty("HESI_FacultyUserName");
        String HESIEducatorPassword=configProps.getProperty("HESI_FacultyPassword");
        */
  
      //  String EvolveId=ReadingExcel.columnDataByHeaderName("Catalogs", "TC-9793", configProps.getProperty("TestData"));
       
        String Firstname=ReadingExcel.columnDataByHeaderName("FirstName", "TC-9793", configProps.getProperty("TestData"));
        String Lastname=ReadingExcel.columnDataByHeaderName("LastName", "TC-9793", configProps.getProperty("TestData"));
        String Emailid=ReadingExcel.columnDataByHeaderName("Emailid", "TC-9793", configProps.getProperty("TestData"));
        String Instution=ReadingExcel.columnDataByHeaderName("Institution", "TC-9793", configProps.getProperty("TestData"));
        String Mobile=ReadingExcel.columnDataByHeaderName("Phone", "TC-9793", configProps.getProperty("TestData"));
        String Address1=ReadingExcel.columnDataByHeaderName("Address1", "TC-9793", configProps.getProperty("TestData"));
        String Address2=ReadingExcel.columnDataByHeaderName("Address2", "TC-9793", configProps.getProperty("TestData"));
        String Country=ReadingExcel.columnDataByHeaderName("Country", "TC-9793", configProps.getProperty("TestData"));
        String State=ReadingExcel.columnDataByHeaderName("State", "TC-9793", configProps.getProperty("TestData"));
        String City=ReadingExcel.columnDataByHeaderName("City", "TC-9793", configProps.getProperty("TestData"));
        String Program=ReadingExcel.columnDataByHeaderName("Program", "TC-9793", configProps.getProperty("TestData"));
        String ZipCode=ReadingExcel.columnDataByHeaderName("ZipCode", "TC-9793", configProps.getProperty("TestData"));
       // String Catalogs=ReadingExcel.columnDataByHeaderName("Catalogs", "TC-8563AndTC-8565", configProps.getProperty("TestData"));
        
        String Hesi_firstname=ReadingExcel.columnDataByHeaderName("Hesi_Firstname", "TC-9793", configProps.getProperty("TestData"));
        String Hesi_lastname=ReadingExcel.columnDataByHeaderName("Hesi_lastname", "TC-9793", configProps.getProperty("TestData"));
        String Hesi_Email=ReadingExcel.columnDataByHeaderName("Hesi_Email", "TC-9793", configProps.getProperty("TestData"));
        String Hesi_Areacode=ReadingExcel.columnDataByHeaderName("Hesi_AreaCode", "TC-9793", configProps.getProperty("TestData"));
        String Hesi_Phonenumber=ReadingExcel.columnDataByHeaderName("Hesi_Phonenumber", "TC-9793", configProps.getProperty("TestData"));
        String Hesi_Comments=ReadingExcel.columnDataByHeaderName("Hesi_Comments", "TC-9793", configProps.getProperty("TestData"));
        String HESI_University=ReadingExcel.columnDataByHeaderName("HESI_University", "TC-9793", configProps.getProperty("TestData"));
        String HESI_Role=ReadingExcel.columnDataByHeaderName("Hesi_Comments", "TC-9793", configProps.getProperty("TestData"));
        String HESI_USER=ReadingExcel.columnDataByHeaderName("HESI_USERNAME", "HESI", configProps.getProperty("TestData"));        
        String HESI_Password=ReadingExcel.columnDataByHeaderName("HESI_PASSWORD", "HESI", configProps.getProperty("TestData"));
       String EMailtemp=null;   
        //String Mobiletemp=null;
        facultyUser=ReadingExcel.columnDataByHeaderName("HESI_FACULTYUSER", "HESI", configProps.getProperty("TestData"));
		facultyPwd=ReadingExcel.columnDataByHeaderName("HESI_FACULTYPASSWORD", "HESI", configProps.getProperty("TestData"));
//		String user="educator";
		
		stepReport("Create new Educator user");
		writeReport(Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions.CreateNewUser("Educator", "HESI9793", "ECommercePreOrder", 9, 1,2,0), "Create New Educator user", "Successfully created new Educator user with credentials: <br> Username: "+credentials[0]+"<br> Password : "+credentials[1], "Failed to create a new Educator account");
		
		stepReport("Update new user's account details");
		writeReport(HESI_BusinessFunction.UpdateAccountDetails(Firstname,Lastname,EMailtemp,Instution,Mobile,Address1,Address2,Country,State,City,ZipCode,Program),"Values Submitted Successfully","Entered Values are Successfully Submitted","Entered Values are not Submitted");
		writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the educator page.", 
				"Successfully logged out the educator:"+credentials[0], 
				"Failed to logout the educator page:"+credentials[0]);

		String HESIEducator=credentials[0];
		String HESIEducatorPassword=credentials[1];
		String useremail="";
		CreateLOUniqueCourseFaculty_Script_15583 louniqueCourse=new CreateLOUniqueCourseFaculty_Script_15583();
		Hesi_lofalg=true;
		louniqueCourse.uniqueCourseLOFaculty("TC-15598",ISBN, 1);
		Hesi_lofalg=false; 
		
		stepReport("Log back in as new instructor user and get account details");
		writeReport(SwitchToBrowser(ElsevierObjects.studentBrowserType),"Launching Browser to Educator","Launching Browser to Educator is succesful","Lanching Browser to Educator is failed");

		String user="educator";


		writeReport(EvolveCommonBussinessFunctions.existingUserLogin(user,HESIEducator,HESIEducatorPassword), "Launch Evolve Cert URL And Login As Existing Educator: "+HESIEducator, 
				"Successfully Launched Evolve Cert URL.</br>Successfully Logged In as Educator. "+HESIEducator,
				"Failed to Launch Evolve Cert URL.</br>Failed to Login As Educator. "+HESIEducator);
		
	    //writeReport(HESI_BusinessFunction.UpdateAccountDetails(EvolveId,Firstname,Lastname,Emailid,Instution,Mobile,Address1,Address2,Country,State,City,ZipCode,Program),"Values Submitted Successfully","Entered Values are Successfully Submitted","Entered Values are not Submitted");
		writeReport(HESI_BusinessFunction.getAccountDetails(), "Fetching Account Details From MyAccount Page.", 
				"Successfully Fetched Username: "+getAccountDetailsUserName+
				"</br>Successfully Fetched FirstName: "+getAccountDetailsFirstName+
				"</br>Successfully Fetched Lastname: "+getAccountDetailsLastName+
				"</br>Successfully Fetched Email: "+getAccountDetailsEmail+
				"</br>Successfully Fetched Institution: "+getAccountDetailsInstitution+
				"</br>Successfully Fetched PhoneNumber: "+getAccountDetailsPhone+
				"</br>Successfully Fetched StreetAdreess: "+ getAccountDetailsStreetAddress+
				"</br>Successfully Fetched StreetAdreess2: "+ getAccountDetailsStreetAddress2+
				"</br>Successfully Fetched Country: "+ getAccountDetailsCountry+
				"</br>Successfully Fetched State: "+ getAccountDetailsState+
				"</br>Successfully Fetched Town: "+ getAccountDetailsTown+
				"</br>Successfully Fetched ZipCode: "+ getAccountDetailsZipcode, 
				"Failed to Fetch Account Details From MyAccount Page. ");
		useremail=getAccountDetailsEmail;	
		
		stepReport("Login to HESI");
		writeReport(HESI_BusinessFunction.HESI_Login(HESI_USER,HESI_Password),"Launching HESI URL and UserName"+HESI_USER,
                                                                                            "Launching the URL for HESI USER is successful </br > Login to Application Using HESI USER credentails :"+HESI_USER+" is Successful",
                                                                                              "Launching and Login to Application Using HESI USER credentails : "+ HESI_USER+" is Failed");

		writeReport( HESI_BusinessFunction.NavigatingtoAccountManagmentPage(),"Navigating to Account Managment Page",
                "Clicking on Account Managment is Successful </br> Clicking on Faculty and Programs link is Successful",
                "Navigating to Account Managment is Failed");
		
   	    stepReport("Add new instructor to HESI");
		writeReport(HESI_BusinessFunction.AddUser(HESIEducator), "Adding newly Created Faculty User in HESI", "Clicking on New faculty Link is successful </br> Educator :"+HESIEducator+" added Successfully", "Failed to Add Educator:"+HESIEducator);
   	 		Thread.sleep(5000);
		/*
		writeReport( HESI_BusinessFunction.SearchUser(getAccountDetailsUserName),"Searching for User to Navigate to Account Managment Tab",
                                                                                 "Successfully Entered the Userdetails And Submitted",
                                                                                 "Failed to Enter User Details or Submission failed");

	    writeReport(HESI_BusinessFunction.CompareValuesintheResultsandClickonResults(getAccountDetailsUserName,getAccountDetailsFirstName,getAccountDetailsLastName,getAccountDetailsEmail),"Verifying the Results and Clicking Evolve ID",
			                                                                       "The Values Are verified and Successfully Clicked on EvolveId",
			                                                                       "</br>Results are not Appeared");
	  
*/
   	    stepReport("Verify new HESI instructor");
   	 	writeReport(HESI_BusinessFunction.CompareHESINewFacDetails(getAccountDetailsUserName, getAccountDetailsFirstName, getAccountDetailsLastName, getAccountDetailsEmail, getAccountDetailsInstitution, getAccountDetailsPhone, getAccountDetailsStreetAddress, getAccountDetailsStreetAddress2, getAccountDetailsCountry, getAccountDetailsState, getAccountDetailsTown, getAccountDetailsZipcode),"Comparing values from CERT to HESI","All the Above Comparions are Successful","All the Comparisons are Failed");
   	 	
   	 	stepReport("Update instructor in HESI");
	    writeReport(HESI_BusinessFunction.UpdateExistingFac(Hesi_Areacode,Hesi_Phonenumber),"Updating Phone Number"," Updating Area Code"+Hesi_Areacode+" Phone Number"+Hesi_Phonenumber,"Updating Area code or Phone number"); 
	    writeReport(HESI_BusinessFunction.UpdateNewFac(Hesi_Comments, HESI_University,"Faculty/Instructor"),"Update Faculty Roles and University Details","Update Comments and Click on Next is Successful</br>Selecting University is Successful</br>Selecting  Roles","Unable to  Update Faculty Roles and University Details");
	    	
	    Thread.sleep(10000);
	    stepReport("Verify the updates were successful");
	    Thread.sleep(veryhigh);
	    writeReport(HESI_BusinessFunction.CompareValuesintheResultsandClickonResults(getAccountDetailsUserName,getAccountDetailsFirstName,getAccountDetailsLastName,getAccountDetailsEmail),"Verifying the Results and Clicking Evolve ID",
                "The Values Are verified and Successfully Clicked on EvolveId",
                "</br>Results are not Appeared");
	     Thread.sleep(14000);
	     //SwitchToBrowser("Chrome");
	     
	     stepReport("Verify HESI email");
	 	if(emailLogin()){
			Reporters.SuccessReport("Evolve Email login:", "Successfully logged into User Email.");
		}
		else{
			Reporters.failureReport("Evolve Email Login:", "Failed to login into User Email.");
		}
		String Title="New HESI Faculty Account Approved";
		emailAdress=getAccountDetailsEmail;
		CreateFacultyUserfromSplashPage_9799.emailBodyVerification(Title,useremail);
		Thread.sleep(1000);
		
		stepReport("Login to Evolve as new instructor");
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
	     writeReport(EvolveCommonBussinessFunctions.existingUserLogin(user,HESIEducator,HESIEducatorPassword), "Launch Evolve Cert URL And Login As Existing Educator: "+HESIEducator, 
				"Successfully Launched Evolve Cert URL.</br>Successfully Logged In as Educator. "+HESIEducator,
				"Failed to Launch Evolve Cert URL.</br>Failed to Login As Educator. "+HESIEducator);
		
	    stepReport("Verify changes made in HESI are reflected in Evolve");
	     writeReport(HESI_BusinessFunction.getAccountDetails(), "Fetching Account Details From MyAccount Page.", 
				"Successfully Fetched Username: "+getAccountDetailsUserName+"</br>Successfully Fetched FirstName: "+getAccountDetailsFirstName+"</br>Successfully Fetched Lastname: "+getAccountDetailsLastName+"</br>Successfully Fetched Email: "+getAccountDetailsEmail+"</br>Successfully Fetched Institution: "+getAccountDetailsInstitution+"</br>Successfully Fetched PhoneNumber: "+getAccountDetailsPhone+"</br>Successfully Fetched StreetAdreess: "+ getAccountDetailsStreetAddress, 
				"Failed to Fetch Account Details From MyAccount Page. ");
		String Phone_number=Hesi_Areacode+Hesi_Phonenumber;
	//  writeReport(HESI_BusinessFunction.CompareaferhesiupdateinCERT(Hesi_firstname,Hesi_lastname,Hesi_Email,Phone_number), "Comparing values from HESI to CERT", "Comparisions values from  HESI  updated Values to CERT Environment is Successful", "Comparisions values from  HESI  updated Values to CERT Environment is not matching");
	  
		stepReport("Verify HESI access");
		if(!click(ElsevierObjects.Myevolve,"Click on my evolve"))
		{
			flag=false;
		}
	  HESI_BusinessFunction.verifyProducttypeandclick("Faculty Access");
	  Thread.sleep(6000);

	  String ExpectedText="HESI Faculty Access";
	  String actualText=driver.findElement(By.xpath(".//*[@id='ctl00_divBreadcrumbs']/span")).getText();
	  String currenturl=driver.getCurrentUrl();
	  writeReport(CompareString(ExpectedText, actualText, "Validating Values in New browser "),"Navigating to HESI URL","Navigating to HESI URL is successful"+currenturl+"</br>  Bread crum HESI Faculty Access  is avilable on current URL","Navigating to HESI URL is failed or validation failed"+currenturl);
	  Thread.sleep(3000);
		}
    
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
	}
	

