package com.cigniti.automation.BusinessFunctions;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class LOUniqueCourseTrialFulfillmentFaculty_15243 extends EvolveCommonBussinessFunctions{
	public static Map<String, String> values=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC_9804", configProps.getProperty("TestData"));
	
	
	/**Generic method for email id search
	 * 
	 * @param emailID1
	 * @return
	 * @throws Throwable
	 */
	
	/*public static boolean searchEmail(String emailID1) throws Throwable{
		boolean flag=true;
		try{
			System.out.println("emailID:"+emailID1);
			type(ElsevierObjects.email_SearchBox,emailID1,"Enter the email id.");
			Thread.sleep(medium);
			click(ElsevierObjects.email_SearchIcon,"Click on search icon.");
			Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e);
		}
		
	 return flag;	
	}*/
	
	
	//Common Business logic for Tc-15101,Tc-15243,
		//public static boolean verifyEmailBody(String emailID) throws Throwable{
			public static boolean verifyEmailBodyAfterRequestProduct(String trial) throws Throwable{
			boolean flag=true;
				try{
				titleInEmail=getText(ElsevierObjects.titleInEmail, "Get title in evolve email page.");
				System.out.println( "titleInEmail:"+titleInEmail);
				if(trial.equalsIgnoreCase("true")){	
					if(TrialEmailTitle.contains(titleInEmail)){
						if(click(ElsevierObjects.email_logout,"Click on logout.")){
							Reporters.SuccessReport("Verifying Title In Email After Requesting The Product.", "Successfully Verified Title In Email.</br>The Actual Title In Email Is:"+titleInEmail+"</br>The Expected Title Is:"+TrialEmailTitle);
						}
						else{
							Reporters.failureReport("Verifying Title In Email After Requesting The Product.", "Failed To Verify Title In Email.</br>The Actual Title In Email Is:"+titleInEmail+"</br>The Expected Title Is:"+TrialEmailTitle);

						}
						Thread.sleep(high);
					}
				}
				else{
					if(NoTrialEmailTitle.contains(titleInEmail)){
						if(click(ElsevierObjects.email_logout,"Click on logout.")){
						Reporters.SuccessReport("Verifying Title In Email After Requesting The Product..", "Successfully Verified Title In Email..</br>The Actual Title In Email Is:"+titleInEmail+"</br>The Expected Title Is:"+NoTrialEmailTitle);
					}
					else{
						Reporters.failureReport("Verifying Title In Email After Requesting The Product..", "Failed To Verify Title In Email.</br>The Actual Title In Email Is:"+titleInEmail+"</br>The Expected Title Is:"+NoTrialEmailTitle);

					}
					}
				
				}
			
			}
			 catch(Exception e){sgErrMsg=e.getMessage();
				System.out.println(e);return false;
			}
			  
			return flag;
		}
			public static boolean verifyEmailBodyAfterRequestFullfill(String EmailTitleAfterFullfilled) throws Throwable{
			boolean flag=true;
				try{	
					String titleInEmail=getText(ElsevierObjects.titleInEmail, "Get title in evolve email page.");
					System.out.println( "titleInEmail:"+titleInEmail);
						
					/*List<WebElement> e=driver.findElements(By.xpath(".//*[@id='mail.hsplit.grid']/div/table/tbody/tr/td[5]"));
					titleInEmail=e.get(0).getAttribute("text");
					String titleInEmail2=e.get(1).getAttribute("text");		*/
				
					if(EmailTitleAfterFullfilled.contains(titleInEmail))
							
						{
							Reporters.SuccessReport("Verifying Title In Email Body.", "Successfully Verified Title In Email Body</br>The Actual Title is :"+titleInEmail+"</br>The Expected Title Is :"+EmailTitleAfterFullfilled);
						}
						else{
							Reporters.failureReport("Verifying Title In Email Body.", "Failed To Verify Title in Email Body.</br>The Actual Title is :"+titleInEmail+"</br>The Expected Title Is :"+EmailTitleAfterFullfilled);
						}
						Thread.sleep(low);
						if(click(ElsevierObjects.email_logout,"Click on logout.")){
							Reporters.SuccessReport("Evolve Email Logout.", "Successfully Logged Out Evolve Email.");
						}
						else{
							Reporters.failureReport("Evolve Email Logout.", "Failed To Logout Evolve Email.");
						}
						Thread.sleep(low);
				}
					catch(Exception e){sgErrMsg=e.getMessage();return false;
						
					}
				return flag;
			}
			
			
		public static boolean verifyTrial() throws Throwable{
		boolean flag=true;
			try{
		
			trialStatus=getText(ElsevierObjects.Admin_Apprstatus_Trial, "Get status of Trial.");
			if(trialStatus.equals(checkTrialStatus)){
				System.out.println("Trial status matched.");
				}
		}
			catch(Exception e){sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
		 
		return flag;
		}
		public static boolean changeStatusAndEmailPopup(String statusAfterEmailSent) throws Throwable{
			boolean flag=true;
			try
			{
				String changeStatus=ReadingExcel.columnDataByHeaderName("changeStatus", "TC-10410", testDataPath);
				selectByVisibleText(ElsevierObjects.adoptionRequestStatus, changeStatus, "Change ststus to fullfilled.");
				Thread.sleep(medium);				
				click(ElsevierObjects.adoptionRequest_Save,"Click on Save button.");
				Thread.sleep(high);
				javaClick(ElsevierObjects.emailPopup,"Click on Send mail button on popup.");
				Thread.sleep(medium);
				//verifyText(ElsevierObjects.adoptionRequestStatus, changeStatus, "Verify request status.");	
				 String adoptionrequeststatus=getText(ElsevierObjects.adoptionRequestFulfillStatus,"adoptionRequestFulfillStatus");
				if(adoptionrequeststatus.equals(statusAfterEmailSent) ){
					 Reporters.SuccessReport("Verifying Status After Sending Email", "Successfully Verified Status:"+statusAfterEmailSent+" after sending email");
					}
				 else{
						Reporters.failureReport("Verifying Status After Sending Email", "Failed To Verify Status:"+statusAfterEmailSent+" after sending email."); 
				 }
			}
			catch(Exception e){sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
		 
		return flag;
		}
}