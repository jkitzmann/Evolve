package com.cigniti.automation.BusinessFunctions;

import java.util.List;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.Utilities.Database;

public class BlackBoard_BusinessFunctions extends EvolveCommonBussinessFunctions {
	
	public static boolean blackboardLogin (String username, String password) throws Throwable {
		
		boolean flag = true;
		try {
			
			if (!launchUrl(configProps.getProperty("BB_URL"))) {
				flag = false;
				Reporters.failureReport("Open the BlackBoard login page", "Failed to open the BlackBoard login page");
			}
			else
				Reporters.SuccessReport("Open the BlackBoard login page", "Successfully opened the BlackBoard login page");
			Thread.sleep(low);
			
			if (!type(ElsevierObjects.BB_Username, username, "Username")) {
				flag = false;
				Reporters.failureReport("Enter username", "Failed to enter username: " + username);
			}
			else
				Reporters.SuccessReport("Enter username", "Successfully entered username: " + username);
			
			if (!type(ElsevierObjects.BB_Password, password, "Password")) {
				flag = false;
				Reporters.failureReport("Enter password", "Failed to enter password: " + password);
			}
			else
				Reporters.SuccessReport("Enter password", "Successfully entered password: " + password);
			
			if (!click(ElsevierObjects.BB_LoginButton, "Login button")) {
				flag = false;
				Reporters.failureReport("Click Login button", "Failed to click Login button");
			}
			else
				Reporters.SuccessReport("Click Login button", "Successfully clicked Login button");
			Thread.sleep(high);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean gotoAcademicMaterials() throws Throwable {
		
		boolean flag = true;
		try {
			
			if (click(ElsevierObjects.BB_MyCoursesLink, "Courses link"))
				Reporters.SuccessReport("Click Courses link", "Successfully clicked Courses link");
			else
				Reporters.failureReport("Click Courses link", "Failed to click Courses link");
			Thread.sleep(medium);
			
			if (click(ElsevierObjects.BB_CourseLink, "Course link"))
				Reporters.SuccessReport("Open the course", "Successfully opened the course");
			else
				Reporters.failureReport("Open the course", "Failed to open the course");
			Thread.sleep(low);
			
			if (click(ElsevierObjects.BB_ToolsLink, "Tools link"))
				Reporters.SuccessReport("Click the Tools link", "Successfully clicked Tools");
			else
				Reporters.failureReport("Click the Tools link", "Failed to click Tools");
			Thread.sleep(low);
			
			if (click(ElsevierObjects.BB_AcademicMaterials, "Academic Materials link"))
				Reporters.SuccessReport("Click Academic Materials", "Successfully clicked Academic Materials");
			else
				Reporters.failureReport("Click Academic Materials", "Failed to click Academic Materials");
			Thread.sleep(veryhigh);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean verifyFilter(By filterLocator, String defaultSelection, String availableSelection) throws Throwable {
		
		boolean flag = true;
		try {
			
			// verify filter is displayed
			if (isElementPresent(filterLocator)) {
				Reporters.SuccessReport("Verify filter dropdown is displayed", "Filter dropdown is displayed");
				
				// verify default selected option
				Select filterDropdown = new Select(driver.findElement(filterLocator));
				String optionText = filterDropdown.getFirstSelectedOption().getText();
				if (optionText.equals(defaultSelection))
					Reporters.SuccessReport("Verify the default option in the filter",
							"Successfully verified the filter has the correct default option...</br>" +
							"Expected: " + defaultSelection + "</br>" +
							"Actual: " + optionText);
				else {
					flag = false;
					Reporters.failureReport("Verify the default option in the filter",
							"The filter does not have the correct default option... </br>" + 
							"Expected: " + defaultSelection + "</br>" +
							"Actual: " + optionText);
				}
				
				// verify correct option is available, if applicable
				if (!availableSelection.isEmpty()) {
					boolean found = false;
					List<WebElement> options = filterDropdown.getOptions();
					for (WebElement option : options) {
						if (option.getText().equals(availableSelection))
							found = true;
					}
					if (found)
						Reporters.SuccessReport("Verify the filter contains the correct option", "Successfully verified the filter contains the option: " + availableSelection);
					else {
						flag = false;
						Reporters.failureReport("Verify the filter contains the correct option", "Failed to verify the filter contains the option: " + availableSelection);
					}
				}
			}
			else {
				flag = false;
				Reporters.failureReport("Verify filter dropdown is displayed","Filter dropdown is not displayed");
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean placeOrder(String title, String isbn, boolean isPreorder) throws Throwable {
		
		boolean flag = true;
		try {
			
			// click the Order button for the product (opens in new tab)
			By orderButton = By.xpath(".//h3[text()='" + title + "']/following-sibling::div[@class='actions']//a");
			if (click(orderButton, "Order button"))
				Reporters.SuccessReport("Click Order button for the product", "Successfully clicked Order button for: " + title);
			else {
				flag = false;
				Reporters.failureReport("Click order button for the product", "Failed to click the Order button for: " + title);
			}
			Thread.sleep(high);
			
			// move focus to the new tab
			for (String handle : driver.getWindowHandles()) {
				driver.switchTo().window(handle);
			}
			
			// verify title and isbn on evolve product page
			if (getText(ElsevierObjects.isbnProduct, "ISBN").equals(isbn))
				Reporters.SuccessReport("Verify ISBN on Evolve product page", "The product page includes the correct ISBN: " + isbn);
			else {
				flag = false;
				Reporters.failureReport("Verify ISBN on Evolve product page", "The product page does not include the ISBN: " + isbn);
			}
			
			if (getText(ElsevierObjects.evolve_Product_titlebeforerequest, "Title").contains(title))
				Reporters.SuccessReport("Verify title on Evolve product page", "The product page includes the correct title: " + title);
			else {
				flag = false;
				Reporters.failureReport("Verify title on Evolve product page", "The product page does not include the title: " + title);
			}
			
			// add to cart and enter checkout
			if (click(ElsevierObjects.btnaddtocart, "Add to Cart button"))
				Reporters.SuccessReport("Add product to cart", "Successfully clicked Add To Cart");
			else {
				flag = false;
				Reporters.failureReport("Add product to cart", "Failed to click Add To Cart");
			}
			Thread.sleep(high);
			
			if (isPreorder) {
				String cartMessage = getText(By.xpath("//*[@id='" + isbn + "']/div[8]"), "Preorder message");
				if (cartMessage.contains("not yet available"))					
					Reporters.SuccessReport("Verify preorder message", "Preorder message verified: " + cartMessage);
				else{
					flag = false;
					Reporters.failureReport("Verify preorder message", "Unable to verify preorder message");
				}
			}
			
			if (click(ElsevierObjects.btnRedeem, "Checkout button"))
				Reporters.SuccessReport("Enter checkout", "Successfully clicked Redeem/Checkout button");
			else {
				flag = false;
				Reporters.failureReport("Enter checkout", "Failed to click Redeem/Checkout button");
			}
			Thread.sleep(medium);
			
			// create a new account
			Date now = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat ("MMddyyyyHmmss");
			String firstName = ReadingExcel.columnDataByHeaderName("Firstname", "TC-17068", configProps.getProperty("TestData"));
			String lastName = ReadingExcel.columnDataByHeaderName("Lastname", "TC-17068", configProps.getProperty("TestData"));
			String email = ReadingExcel.columnDataByHeaderName("Email", "TC-17068", configProps.getProperty("TestData")) + sdf.format(now) + "@evolveqa.info";
			String password = ReadingExcel.columnDataByHeaderName("Password", "TC-17068", configProps.getProperty("TestData"));
			String street = ReadingExcel.columnDataByHeaderName("Street", "TC-17068", configProps.getProperty("TestData"));
			String city = ReadingExcel.columnDataByHeaderName("City", "TC-17068", configProps.getProperty("TestData"));
			String state = ReadingExcel.columnDataByHeaderName("State", "TC-17068", configProps.getProperty("TestData"));
			String zip = ReadingExcel.columnDataByHeaderName("Zip", "TC-17068", configProps.getProperty("TestData"));
			writeReport(createAccount(firstName, lastName, email, password, street, city, state, zip), "Create new account in checkout",
					"Successfully created new account...</br>" +
					"Name: " + firstName + " " + lastName + "</br>" +
					"Email: " + email + "</br>" +
					"Password: " + password + "</br>" +
					"Street: " + street + "</br>" +
					"City: " + city + "</br>" +
					"State: " + state + "</br>" +
					"Zip: " + zip + "</br>",
					"Failed to create new account...</br>" +
					"Name: " + firstName + " " + lastName + "</br>" +
					"Email: " + email + "</br>" +
					"Password: " + password + "</br>" +
					"Street: " + street + "</br>" +
					"City: " + city + "</br>" +
					"State: " + state + "</br>" +
					"Zip: " + zip + "</br>");
			
			// complete checkout
			String creditCardType=ReadingExcel.columnDataByHeaderName("cardType", "TC-15597", configProps.getProperty("TestData"));
			String creditCardNum=ReadingExcel.columnDataByHeaderName("cardNumber", "TC-15597", configProps.getProperty("TestData"));
			String creditCardCvv=ReadingExcel.columnDataByHeaderName("cardCVV", "TC-15597", configProps.getProperty("TestData"));
			String creditCardName=ReadingExcel.columnDataByHeaderName("cardName", "TC-15597", configProps.getProperty("TestData"));
			String creditCardExpYr=ReadingExcel.columnDataByHeaderName("cardExpYear", "TC-15597", configProps.getProperty("TestData"));
			String creditCardExpMnth=ReadingExcel.columnDataByHeaderName("cardExpMonth", "TC-15597", configProps.getProperty("TestData"));
			if (ECommercePreorderALaCarte_Student_SplitOrders1_15597.CreditCardData(creditCardType, creditCardNum, creditCardCvv, creditCardName, creditCardExpMnth, creditCardExpYr))
				Reporters.SuccessReport("Submit credit card info", "Successfully submitted credit card info");
			else {
				flag = false;
				Reporters.failureReport("Submit credit card info", "Failed to submit credit card info");
			}
			
			if (submitOrder("student"))
				Reporters.SuccessReport("Submit order", "Successfully submitted order");
			else {
				flag = false;
				Reporters.failureReport("Submit order", "Failed to submit order");
			}
			Thread.sleep(veryhigh);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean createAccount(String firstName, String lastName, String email, String password, String street, String city, String state, String zip) throws Throwable {
		
		boolean flag = true;
		try {
			
			// first name
			if (!type(ElsevierObjects.educator_form_txtFirstName, firstName, "First name")) {
				flag = false;
				Reporters.failureReport("Enter first name", "Failed to enter first name on create account form");
			}
			else
				Reporters.SuccessReport("Enter first name", "Successfully entered first name: " + firstName);
			
			// last name
			if (!type(ElsevierObjects.educator_form_txtLastName, lastName, "Last name")) {
				flag = false;
				Reporters.failureReport("Enter Last name", "Failed to enter last name on create account form");
			}
			else
				Reporters.SuccessReport("Enter Last name", "Successfully entered last name: " + lastName);
			
			// email address
			if (!type(ElsevierObjects.educator_form_txtEmail, email, "Email address")) {
				flag = false;
				Reporters.failureReport("Enter email", "Failed to enter email address on create account form");
			}
			else
				Reporters.SuccessReport("Enter email", "Successfully entered email address: " + email);
			
			if (!type(ElsevierObjects.educator_form_txtConformEmail, email, "Confirm email")) {
				flag = false;
				Reporters.failureReport("Enter email", "Failed to enter email address on create account form");
			}
			else
				Reporters.SuccessReport("Enter email", "Successfully entered email address: " + email);
			
			// password
			if (!type(ElsevierObjects.educator_form_txtPassword, password, "Password")) {
				flag = false;
				Reporters.failureReport("Enter password", "Failed to enter password on create account form");
			}
			else
				Reporters.SuccessReport("Enter password", "Successfully entered password: " + password);
			
			if (!type(ElsevierObjects.educator_form_txtConformPassword, password, "Confirm password")) {
				flag = false;
				Reporters.failureReport("Enter password", "Failed to enter password on create account form");
			}
			else
				Reporters.SuccessReport("Enter password", "Successfully entered password: " + password);
			
			// no institution
			if (!click(ElsevierObjects.chkNoinstitution, "No institution checkbox")) {
				flag = false;
				Reporters.failureReport("Check no institution box", "Failed to check no institution box");
			}
			else
				Reporters.SuccessReport("Check no institution box", "Successfully checked no institution box");
			
			// shipping street
			if (!type(ElsevierObjects.Student_Shipping_Addr1, street, "Street address")) {
				flag = false;
				Reporters.failureReport("Enter shipping street address", "Failed to enter shipping street address on create account form");
			}
			else
				Reporters.SuccessReport("Enter shipping street address", "Successfully entered shipping street address: " + street);
			
			// shipping city
			if (!type(ElsevierObjects.Student_Shipping_City, city, "City")) {
				flag = false;
				Reporters.failureReport("Enter shipping city", "Failed to enter shipping city on create account form");
			}
			else
				Reporters.SuccessReport("Enter shipping city", "Successfully entered shipping city: " + city);
			
			// shipping state
			if (!selectByVisibleText(ElsevierObjects.Student_Shipping_State, state, "State")) {
				flag = false;
				Reporters.failureReport("Select shipping state", "Failed to select shipping state");
			}
			else
				Reporters.SuccessReport("Select shipping state", "Successfully selected shipping state: " + state);
			
			// shipping zip
			if (!type(ElsevierObjects.Student_Shipping_Zip, zip, "Zipcode")) {
				flag = false;
				Reporters.failureReport("Enter shipping zip", "Failed to enter shipping zip on create account form");
			}
			else
				Reporters.SuccessReport("Enter shipping zip", "Successfully entered shipping zip: " + zip);
			
			// same billing address checkbox
			if (!click(ElsevierObjects.chkbillingcheckbox, "Same shipping address")) {
				flag = false;
				Reporters.failureReport("Check same shipping address box", "Failed to check same shipping address box");
			}
			else
				Reporters.SuccessReport("Check same shipping address box", "Successfully checked same shipping address box");
			
			// continue button
			if (!click(ElsevierObjects.btnprofilesubmit, "Continue button")) {
				flag = false;
				Reporters.failureReport("Click Continue button", "Failed to click Continue");
			}
			else
				Reporters.SuccessReport("Click Continue button", "Successfully clicked Continue");
			Thread.sleep(veryhigh);
			
			// use this address popup
			switchToFrameByLocator(ElsevierObjects.Admin_Evolve_Ecom_framename, "Verify address popup");
			Thread.sleep(low);
			if (!click(ElsevierObjects.Use_this_address, "Use this address button")) {
				flag = false;
				Reporters.failureReport("Click Use this address button", "Failed to click Use this address");
			}
			else
				Reporters.SuccessReport("Click Use this address button", "Successfully clicked use this address");
			Thread.sleep(veryhigh);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean receiptPage(String title, String isbn, boolean isPreorder) throws Throwable {
		
		boolean flag = true;
		try {
			
			// verify isbn
			if (getText(ElsevierObjects.OrderProduct_Confirmation_ISBN, "ISBN").contains(isbn))
				Reporters.SuccessReport("Verify ISBN in receipt page",
						"The correct ISBN appears on the receipt page...</br>" +
						"Expected: " + isbn + "</br>" + "Actual: " + getText(ElsevierObjects.OrderProduct_Confirmation_ISBN, "ISBN"));
			else {
				flag = false;
				Reporters.failureReport("Verify ISBN in receipt page",
						"The correct ISBN does not appear on the receipt page...</br>" +
						"Expected: " + isbn + "</br>" + "Actual: " + getText(ElsevierObjects.OrderProduct_Confirmation_ISBN, "ISBN"));
			}
			
			// verify product title
			if (getText(ElsevierObjects.itemInCart, "Product title").contains(title))
				Reporters.SuccessReport("Verify product title in receipt page",
						"The correct title appears on the receipt page...</br>" +
						"Expected: " + title + "</br>" + "Actual: " + getText(ElsevierObjects.itemInCart, "Product title"));
			else {
				flag = false;
				Reporters.failureReport("Verify product title in receipt page",
						"The correct title does not appear on the receipt page...</br>" +
						"Expected: " + title + "</br>" + "Actual: " + getText(ElsevierObjects.itemInCart, "Product title"));
			}
			
			// verify preorder message, if applicable
			if (isPreorder) {
				String receiptMessage = getText(By.xpath("//div[@class='notification_box rounded']"), "Preorder message");
				if (receiptMessage.contains("not yet available"))					
					Reporters.SuccessReport("Verify preorder message", "Preorder message verified: " + receiptMessage);
				else{
					flag = false;
					Reporters.failureReport("Verify preorder message", "Unable to verify preorder message");
				}
			}
			
			// save order # for later
			String orderNumber = getText(ElsevierObjects.OrderProduct_Confirmation_OrderNumber, "Order Number");
			if (isPreorder)
				ReadingExcel.updateCellInSheet(1, 13, configProps.getProperty("TestData"), "TC-17068", orderNumber);
			else
				ReadingExcel.updateCellInSheet(1, 12, configProps.getProperty("TestData"), "TC-17068", orderNumber);
			Reporters.SuccessReport("Retrieve order number", "Successfully retrieved and stored the order number: " + orderNumber);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean databaseVerification(String orderNumber) throws Throwable {
		
		boolean flag = true;
		try {
			
			// setup db connection
			ResultSet rs;
			String query;
			Connection conn = Database.getDBConnection();
			Statement statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			
			// get the referral_id and referral_sales_rep_code from the database
			query = "select referral_sales_rep_code, referral_id from evladmin.evl_order where evl_order_id = " + orderNumber;
			rs = statement.executeQuery(query);
			String salesRep = "";
			String referralID = "";
			while(rs.next()) {
				salesRep = rs.getString(1);
				referralID = rs.getString(2);
			}
			
			// verify the values
			if (salesRep.equals("70475"))
				Reporters.SuccessReport("Verify the referral_sales_rep_code value",
						"The correct value is stored in the database...</br>Expected: 70475</br>Actual: " + salesRep);
			else {
				flag = false;
				Reporters.failureReport("Verify the referral_sales_rep_code value",
						"The value is incorrect...</br>Expected: 70475</br>Actual: " + salesRep);
			}
			
			if (referralID.equals("Blackboard"))
				Reporters.SuccessReport("Verify the referral_id value",
						"The correct value is stored in the database...</br>Expected: Blackboard</br>Actual: " + referralID);
			else {
				flag = false;
				Reporters.failureReport("Verify the referral_id value",
						"The value is incorrect...</br>Expected: Blackboard</br>Actual: " + referralID);
			}
			
			rs.close();
			statement.close();
			conn.close();
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}

}
