package com.cigniti.automation.Test;

import java.util.Random;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.Admin_BusinessFunction;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class Search_RemoveCancelledandRemoveOutofPrintProducts_AdminRevert_15477and15595 extends EvolveCommonBussinessFunctions{
	Random ra = new Random( System.currentTimeMillis() );	
	@Test
	public void Search_RemoveCancelledandRemoveOutofPrintProducts_AdminRevert_15477and15595() throws Throwable{
		try 
		{
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			stepReport("Revert changes to first product");
			writeReport(SwitchToBrowser(ElsevierObjects.adminBrowserType),"Launching Browser for Admin User","Launching Browser for Admin User is succesful","Lanching Browser for Admin User is failed");
			
			Thread.sleep(low);
			String ISBN=ReadingExcel.columnDataByHeaderName("ISBN1", "AdminTC-15477and15595", configProps.getProperty("TestData"));
			String Processvalue=ReadingExcel.columnDataByHeaderName("Processvalue1", "AdminTC-15477and15595", configProps.getProperty("TestData"));
			String StatuCode=ReadingExcel.columnDataByHeaderName("StatuCodeRevert1", "AdminTC-15477and15595", configProps.getProperty("TestData"));
			
			
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials"+ configProps.getProperty("AdminUser"),
	                "Launching the URL for User is successful </br > Login to Application Using User credentails :"+configProps.getProperty("AdminUser")+" is Successful",
	                   "Launching and Login to Application Using User credentails : "+ configProps.getProperty("AdminUser")+" is Failed");
		   
			
		       Thread.sleep(high);

		   writeReport(Admin_BusinessFunction.NavigatetoBusinessProducts(), "Navigating to Basic Product Reports under ONIX PPM Load Data Manager ",  
				   "Entering ISBN "+ISBN+" is successful </br> Selecting "+Processvalue+" is Successful</br> Clicking on Go is Successful </br> Selecting "+StatuCode+" is Successful </br>Clicking on Edit is Successful</br> 'Product Resource is successfully updated' Message appeared",
					                                                          "Navigating to Basic Product Reports under ONIX PPM Load Data Manager is failed ");
	       Thread.sleep(high);

		   writeReport(Admin_BusinessFunction.EditISBNStatusCode(ISBN, Processvalue,StatuCode), "Editing ISBN : " +ISBN,  
                                                            				 "Entering ISBN "+ISBN+" is successful </br> Selecting "+Processvalue+" is Successful</br> Clicking on Go is Successful </br> 'Product Resource is successfully updated' Message appeared",
                                                                             "Editing ISBN is failed");
		   
		   // the first isbn also needs to be included back in search results
		   Thread.sleep(high);
		   click(ElsevierObjects.Admin_Evolve_Link, "Clicking on Evolve Admin link.");
		   
		   Thread.sleep(high);
		   writeReport(Admin_BusinessFunction.NavigatetoMaintainProducts(), "Navigating to Basic Product Reports under ONIX PPM Load Data Manager ",  
					   "Entering ISBN "+ISBN+" is successful </br> Selecting "+Processvalue+" is Successful</br> Clicking on Go is Successful </br> Selecting "+StatuCode+" is Successful </br>Clicking on Edit is Successful</br> 'Product Resource is successfully updated' Message appeared",
						                                                          "Navigating to Basic Product Reports under ONIX PPM Load Data Manager is failed ");
		   Thread.sleep(high);
			   
		   writeReport(Admin_BusinessFunction.AddInclusionofSearchCriteriaFPROD(ISBN), "Editing ISBN in Maintain Products : " +ISBN,  
 				 "Entering ISBN "+ISBN+" is successful </br> Selectign FPROD is Successful </br>"
 				 		+ " Clicking on SAVE button is Successful"
 				 		+ "</br> Clicking on Publish Button is Successful ",
                  "Editing ISBN is failed");
		   Thread.sleep(high);
		   writeReport(Admin_BusinessFunction.AddInclusionofSearchCriteriaSPROD(ISBN), "Editing ISBN : " +ISBN,  
				   "Entering ISBN "+ISBN+" is successful </br> Selectign SPROD is Successful </br>"
	  				 		+ " Clicking on SAVE button is Successful"
	  				 		+ "</br> Clicking on Publish Button is Successful ",
				   "Editing ISBN is failed");  		   
		   Thread.sleep(high);
		   
		   click(ElsevierObjects.Admin_Evolve_Link, "Clicking on Evolve Admin link.");
		   
		   Thread.sleep(high);
		   // end of new section
		   
		   stepReport("Revert changes to second product");
		    ISBN=ReadingExcel.columnDataByHeaderName("ISBN2", "AdminTC-15477and15595", configProps.getProperty("TestData"));
			Processvalue=ReadingExcel.columnDataByHeaderName("Processvalue2", "AdminTC-15477and15595", configProps.getProperty("TestData"));
			StatuCode=ReadingExcel.columnDataByHeaderName("StatuCodeRevert2", "AdminTC-15477and15595", configProps.getProperty("TestData"));
			
			writeReport(Admin_BusinessFunction.NavigatetoBusinessProducts(), "Navigating to Basic Product Reports under ONIX PPM Load Data Manager ",  
					   "Entering ISBN "+ISBN+" is successful </br> Selecting "+Processvalue+" is Successful</br> Clicking on Go is Successful </br> Selecting "+StatuCode+" is Successful </br>Clicking on Edit is Successful</br> 'Product Resource is successfully updated' Message appeared",
						                                                          "Navigating to Basic Product Reports under ONIX PPM Load Data Manager is failed ");
			
			Thread.sleep(high);
		   writeReport(Admin_BusinessFunction.EditISBNStatusCode(ISBN, Processvalue,StatuCode), "Editing ISBN : " +ISBN,  
				   "Entering ISBN "+ISBN+" is successful </br> Selecting "+Processvalue+" is Successful</br> Clicking on Go is Successful </br> Selecting "+StatuCode+" is Successful </br>Clicking on Edit is Successful</br> 'Product Resource is successfully updated' Message appeared",
                   "Editing ISBN is failed");

		   
		   
		  
			ISBN=ReadingExcel.columnDataByHeaderName("ISBN1", "AdminTC-15477and15595", configProps.getProperty("TestData"));

			/*writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials"+ configProps.getProperty("AdminUser"),
	                "Launching the URL for User is successful </br > Login to Application Using User credentails :"+configProps.getProperty("AdminUser")+" is Successful",
	                   "Launching and Login to Application Using User credentails : "+ configProps.getProperty("AdminUser")+" is Failed");*/
			
			click(ElsevierObjects.Admin_Evolve_Link, "Clicking on Evolve Admin link.");
		   
			Thread.sleep(high);
			 writeReport(Admin_BusinessFunction.NavigatetoMaintainProducts(), "Navigating to Basic Product Reports under ONIX PPM Load Data Manager ",  
					   "Entering ISBN "+ISBN+" is successful </br> Selecting "+Processvalue+" is Successful</br> Clicking on Go is Successful </br> Selecting "+StatuCode+" is Successful </br>Clicking on Edit is Successful</br> 'Product Resource is successfully updated' Message appeared",
						                                                          "Navigating to Basic Product Reports under ONIX PPM Load Data Manager is failed ");
			 Thread.sleep(high);
			   
		   writeReport(Admin_BusinessFunction.AddInclusionofSearchCriteriaFPROD(ISBN), "Editing ISBN in Maintain Products : " +ISBN,  
  				 "Entering ISBN "+ISBN+" is successful </br> Selectign FPROD is Successful </br>"
  				 		+ " Clicking on SAVE button is Successful"
  				 		+ "</br> Clicking on Publish Button is Successful ",
                   "Editing ISBN is failed");
		   Thread.sleep(high);
		   writeReport(Admin_BusinessFunction.AddInclusionofSearchCriteriaSPROD(ISBN), "Editing ISBN : " +ISBN,  
				   "Entering ISBN "+ISBN+" is successful </br> Selectign SPROD is Successful </br>"
	  				 		+ " Clicking on SAVE button is Successful"
	  				 		+ "</br> Clicking on Publish Button is Successful ",
				   "Editing ISBN is failed");  
		   
		   Thread.sleep(high);
		   
		   // verify archived product not in maintain products search when archived is filtered
		   stepReport("Verify archived product is filtered from maintain products search");
		   ISBN=ReadingExcel.columnDataByHeaderName("ISBN3", "AdminTC-15477and15595", configProps.getProperty("TestData"));
		   
		   // navigate to maintain product
		   writeReport(click(ElsevierObjects.Admin_Evolve_AdminLink, "Click Evolve Admin breadcrumb"),
				   "Navigate to main Admin page",
				   "Successfully navigated to main Admin page", "Failed to navigate to main Admin page");
		   Thread.sleep(low);
		   
		   writeReport(click(ElsevierObjects.admin_MaintainProduct_lnk, "Click Maintain Products"),
				   "Navigate to Maintain Products",
				   "Successfully navigated to Maintain Products","Failed to navigate to Maintain Products");
		   Thread.sleep(low);
		   
		   // verify no results when archived products are filtered
		   if (type(ElsevierObjects.admin_MaintainProduct_Knotxt, ISBN, "Enter ISBN in search field")){
			   Reporters.SuccessReport("Enter ISBN in search field", "Successfully entered ISBN in search field.");
		   }else
				Reporters.failureReport("Enter ISBN in search field", "Failed to enter ISBN in search field.");
			
		   Thread.sleep(low);
		   if (click(ElsevierObjects.admin_MaintainProduct_Submit, "Click on search button")) {
				Reporters.SuccessReport("Click Search button","Successfully clicked on Search button.");
		   }else
				Reporters.failureReport("Click on Search button", "Failed to click on Search button.");
		   Thread.sleep(low);
		   
		   String expectedMsg = ReadingExcel.columnDataByHeaderName("NoResultsMsg", "AdminTC-15477and15595", configProps.getProperty("TestData"));
		   String actualMsg = getText(ElsevierObjects.AdminSearchNoResults, "No search results message");
		   if (actualMsg.contains(expectedMsg)) {
			   Reporters.SuccessReport("Verify no results message when filtering archived products", "Archived product is filtered and no results message displayed.");
		   }
		   else
			   Reporters.failureReport("Verify no results message when filtering archived products", "The no results message is not displayed.");
		   
		   // search again with the archive filter disabled
		   stepReport("Verify product in search results when archive filter disabled");
		   writeReport(click(ElsevierObjects.Admin_Evolve_AdminLink, "Click Evolve Admin breadcrumb"),
				   "Navigate to main Admin page",
				   "Successfully navigated to main Admin page", "Failed to navigate to main Admin page");
		   Thread.sleep(low);
		   
		   writeReport(click(ElsevierObjects.admin_MaintainProduct_lnk, "Click Maintain Products"),
				   "Navigate to Maintain Products",
				   "Successfully navigated to Maintain Products","Failed to navigate to Maintain Products");
		   Thread.sleep(low);
		   
		   writeReport(click(ElsevierObjects.Exclude_Archived, "Archived checkbox"),
				   "Uncheck the Archived filter",
				   "Successfully unchecked the Archived filter","Failed to uncheck the Archived filter");
		   
		   if (type(ElsevierObjects.admin_MaintainProduct_Knotxt, ISBN, "Enter ISBN in search field")){
			   Reporters.SuccessReport("Enter ISBN in search field", "Successfully entered ISBN in search field.");
		   }else
				Reporters.failureReport("Enter ISBN in search field", "Failed to enter ISBN in search field.");
			
		   Thread.sleep(low);
		   if (click(ElsevierObjects.admin_MaintainProduct_Submit, "Click on search button")) {
				Reporters.SuccessReport("Click Search button","Successfully clicked on Search button.");
		   }else
				Reporters.failureReport("Click on Search button", "Failed to click on Search button.");
		   Thread.sleep(low);
		   
		   if (click(ElsevierObjects.MaintainPrdct_prdctSerachReslut_isbn,"Click on isbn num in product result page")) {
				Reporters.SuccessReport("Click on ISBN in search results", "Successfully clicked on ISBN in search results.");
			}
		   else
				Reporters.failureReport("Click on ISBN in search results", "Failed to click on ISBN in search results.");
		   Thread.sleep(medium);
		   
		   // un-archive the product
		   stepReport("Un-archive the product");
		   if (click(ElsevierObjects.Archived, "Archived checkbox")) {
				Reporters.SuccessReport("Uncheck the Archived box", "Successfully unchecked the Archived box.");
			}
		   else
				Reporters.failureReport("Uncheck the Archived box", "Failed to uncheck the Archived box.");
			
		   if (click(ElsevierObjects.Save_and_Publish, "Click the Save & Publish button")) {
				Reporters.SuccessReport("Click the Save & Publish button", "Successfully clicked the Save & Publish button.");
		   }
		   else
			   Reporters.failureReport("Click the Save & Publish button", "Failed to click the Save & Publish button.");
		   Thread.sleep(medium);
		   
		// verify messaging on screen after un-archiving product
		expectedMsg = ReadingExcel.columnDataByHeaderName("ProdUpdatedMsg", "AdminTC-15477and15595", configProps.getProperty("TestData"));
		actualMsg = getText(ElsevierObjects.Updated_Successfully_Msg, "Product updated message");
		if (expectedMsg.equals(actualMsg)){
			Reporters.SuccessReport("Verify that the correct 'product updated' message is displayed",
					"The correct message is displayed:</br>" +
					"Expected: " + expectedMsg + "</br>" +
					"Actual: " + actualMsg);
		}
		else {
			Reporters.failureReport("Verify that the correct 'product updated' message is displayed",
					"The correct message is not displayed:</br>" +
					"Expected: " + expectedMsg + "</br>" +
					"Actual: " + actualMsg);
		}
		
		expectedMsg = ReadingExcel.columnDataByHeaderName("ProdArchivedMsg", "AdminTC-15477and15595", configProps.getProperty("TestData"));
		actualMsg = getText(ElsevierObjects.Product_Archived_Msg, "Product archived message");
		if (actualMsg.contains(expectedMsg)) {
			Reporters.failureReport("Verify that the 'product archived' message is no longer displayed",
					"The 'product archived' message is incorrectly still displayed.");					
		}
		else {
			Reporters.SuccessReport("Verify that the 'product archived' message is no longer displayed",
					"The 'product archived' message is correctly no longer displayed.");
		}
		   
		   
		   driver.navigate().to(configProps.getProperty("SOLR"));
		   boolean falg_SOLR=true;
		   writeReport(falg_SOLR, "Run SOLR reindexing job"+configProps.getProperty("SOLR"), "Running SOLR Job is Successful", "Running SOLR Job is failed");

		   System.out.println("Wait for "+SOLRMinutes+" mins for preorder queue job to run");
			{
			for(int i=1;i<=SOLRMinutes;i++)
			{
			Thread.sleep(60000);
			System.out.println("Completed Minutes:" +i );
			}
			System.out.println("Completed wait time for "+SOLRMinutes+" mins for preorder queue job to run");
			}
		   
		 //  Thread.sleep(1000000);
		   writeReport(falg_SOLR, "Wait for "+SOLRMinutes+" Min till the Indexing and SOLR job is completed", "Waiting for "+SOLRMinutes+" Minutes are Completed", "Waiting for "+SOLRMinutes+"Minutes are NOT Completed");

		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	@AfterTest
	public void tear() throws Throwable{
	    //HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
