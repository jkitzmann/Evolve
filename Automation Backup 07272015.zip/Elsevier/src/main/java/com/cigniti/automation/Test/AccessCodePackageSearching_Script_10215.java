package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.AccessCodePackageSearching_10215;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.accelerators.Base;

public class AccessCodePackageSearching_Script_10215 extends AccessCodePackageSearching_10215{	
@Test
	public void accessCodePackageSearching_10215() throws Throwable{
	
			try {
				//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
				SwitchToBrowser(ElsevierObjects.adminBrowserType);
				String adminUser=configProps.getProperty("AdminUser");
				packageISBN=readcolumns.twoColumns(0,1,"Tc-10215",configProps.getProperty("TestData")).get("ExampleISBN_Num");
				exPackage=readcolumns.twoColumns(0,1,"Tc-10215",configProps.getProperty("TestData")).get("ExPackageISbn_num");
				searchPackage=readcolumns.twoColumns(0,1,"Tc-10215",configProps.getProperty("TestData")).get("Search_Isbn_num");
				addISBN=readcolumns.twoColumns(0,1,"Tc-10215",configProps.getProperty("TestData")).get("AddIsbn_num");
				
				stepReport("Login to Evolve Admin and go to Maintain Access Code Packages.");
				writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login into Admin Page.", 
																				"Successfully logged into Admin Page as"+adminUser, 
																				"Failed to login into Admin Page.");
				writeReport(AccessCodePackageSearching_10215.AcessCodePage(), "Navigate to Maintain acess code Page.", 
																		"Successfully Clicked on Maintain access code link. </br> Successfully navigated to Maintain Access Code page.", 
																		"Failed to Click on Maintain access code link. </br> Failed to navigate to Maintain Access Code page.");
				
				stepReport("Verify error messaging for Package ISBN field.");
				writeReport(AccessCodePackageSearching_10215.regressionPackageData(), "Verify Different Regression Package ISBN data.", 
																				"Successfully Verified Different Package ISBN data.", 
																				"Failed Verify Different Package ISBN data.");
				
				stepReport("Verify error messaging for Package Name field.");
				writeReport(AccessCodePackageSearching_10215.regressionPackageName(), "Verify Different Regression Package Name data.", 
																				"Successfully Verified Different Package Name data.", 
																				"Failed Verify Different Package Name data.");
				
				stepReport("Verify error messaging for Item ISBN field.");
				writeReport(AccessCodePackageSearching_10215.regressionItemISBN_Data(), "Verify Different Regression ISBN Item data.", 
																		        	"Successfully Verified Different ISBN Item data.", 
																				    "Failed Verify Different ISBN Item data.");
				
				stepReport("Verify that searching by Package ISBN is successful.");
				writeReport(AccessCodePackageSearching_10215.verifyPackageISBN(packageISBN), "Search Package ISBN."+packageISBN, 
			        																	"Successfully Searched for Package ISBN "+packageISBN, 
																						"Failed to search for Package ISBN."+packageISBN);

				stepReport("Verify that searching by Item ISBN is successful.");
				writeReport(AccessCodePackageSearching_10215.verify_ItemISBN(exPackage,searchPackage,addISBN), "Search and Add Isbn Package.", 
																									"Successfully Searched for Example Package ISBN.  </br>	Error Popup package ISBN "+exPackage+" does not exists displayed. </br> Searched for package ISBN "+searchPackage+" </br> Succesfully added Package ISBN "+addISBN, 
																									"Failed to Search And Add Packege ISBN.");

				writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Logout "+adminUser+" Admin Page.", 
																		  "Successfully logged out Admin Page as"+adminUser, 
																		  "Failed to logout Admin Page.");

	
	}catch(Exception e){
		System.err.println(e.getMessage());
			}
			
}
@AfterTest
public void tear() throws Throwable{
	//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
	//Base.tearDown();
}

	
}
	
	
	
	



