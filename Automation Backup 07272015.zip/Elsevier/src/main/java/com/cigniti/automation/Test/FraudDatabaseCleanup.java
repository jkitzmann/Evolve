package com.cigniti.automation.Test;

import java.sql.*;
import org.testng.annotations.*;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class FraudDatabaseCleanup extends EvolveCommonBussinessFunctions {
	
	@Test
	public void fraudDBCleanup() throws Throwable {
		
		try {
			final String DB_URL = "jdbc:oracle:thin:@evcertlarge";
			final String DB_USER = "automation";
			final String DB_PASS = "cert1autords";
			final String TNS_NAMES_LOC = "C:/oracle/product/10.2.0/client_1/NETWORK/ADMIN";
			
			boolean flag = true;
			int i = 0, rowCount = 0;
			String[] ccIDs = new String[2];
			String[] reviewIDs = new String[2];
			String shipStateID = "", billStateID = "";
			
			// get addresses and order #s from TestData spreadsheet
			String Order1 = ReadingExcel.columnDataByHeaderName("ORDER1", "FraudTestCases", testDataPath);
			String Order2 = ReadingExcel.columnDataByHeaderName("ORDER2", "FraudTestCases", testDataPath);
			String Order3 = ""; // will retrieve this order # from database
			String ShipStreet = ReadingExcel.columnDataByHeaderName("ShipStreet", "FraudTestCases", testDataPath).toUpperCase();
			String ShipCity = ReadingExcel.columnDataByHeaderName("ShipCity", "FraudTestCases", testDataPath).toUpperCase();
			String ShipState = ReadingExcel.columnDataByHeaderName("ShipState", "FraudTestCases", testDataPath);
			String ShipZip = ReadingExcel.columnDataByHeaderName("ShipZIP", "FraudTestCases", testDataPath);
			String BillStreet = ReadingExcel.columnDataByHeaderName("BillStreet", "FraudTestCases", testDataPath).toUpperCase();
			String BillCity = ReadingExcel.columnDataByHeaderName("BillCity", "FraudTestCases", testDataPath).toUpperCase();
			String BillState = ReadingExcel.columnDataByHeaderName("BillState", "FraudTestCases", testDataPath);
			String BillZip = ReadingExcel.columnDataByHeaderName("BillZIP", "FraudTestCases", testDataPath);
			
			// setup db connection
			ResultSet rs;
			String query;
			System.setProperty("oracle.net.tns_admin", TNS_NAMES_LOC);
			Class.forName("oracle.jdbc.OracleDriver").newInstance();
			Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
			Statement statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			
			// get the evl_order_id of the child of the approved order
			stepReport("Get the evl_order_id of the child of the approved order");
			query = "select evl_order_id from evladmin.preorder_queue where parent_evl_order_id = " + Order2;
			rs = statement.executeQuery(query);
			// make sure the # of records returned = 1
			rs.last();
			rowCount = rs.getRow();
			rs.beforeFirst();
			if (rowCount == 1){
				rs.next();
				Order3 = rs.getString(1);
				Reporters.SuccessReport("Retrieve the child order id of the approved order", "Successfully retrieved the child order id of the approved order. Parent: " + Order2 + " | Child: " + Order3);
			}
			else {
				flag = false;
				Reporters.failureReport("Retrieve the child order id of the approved order", "Failed to retrieve the child order id of the approved order: " + Order2);
			}
			rowCount = 0;
			
			// get credit_card_ids from db
			stepReport("Get credit_card_id from database for both orders");
			query = "select credit_card_id from evladmin.evl_order where evl_order_id in (" + Order1 + "," + Order2 + ")";
			rs = statement.executeQuery(query);
			// make sure the # of records returned = 2
			rs.last();
			rowCount = rs.getRow();
			rs.beforeFirst();
			if (rowCount == 2){
				i = 0;
				while(rs.next()){
					ccIDs[i] = rs.getString(1);
					i++;
				}
				Reporters.SuccessReport("Retrieve credit_card_ids from database for both orders", "Successfully retrieved credit_card_ids from database for orders: " + Order1 + ", " + Order2);
			}
			else {
				flag = false;
				Reporters.failureReport("Retrieve credit_card_ids from database for both orders", "Failed to retrieve credit_card_ids from database for orders: " + Order1 + ", " + Order2);
			}
			rowCount = 0;
			
			// get evl_order_review_ids from db
			stepReport("Get evl_order_review_id from database for both orders");
			query = "select evl_order_review_id from evladmin.evl_order_review where evl_order_id in (" + Order1 + "," + Order2 + ")";
			rs = statement.executeQuery(query);
			// make sure # of records returned = 2
			rs.last();
			rowCount = rs.getRow();
			rs.beforeFirst();
			if (rowCount == 2){
				i = 0;
				while(rs.next()){
					reviewIDs[i] = rs.getString(1);
					i++;
				}
				Reporters.SuccessReport("Retrieve evl_order_review_ids from database for both orders", "Successfully retrieved evl_order_review_ids from database for orders: " + Order1 + ", " + Order2);
			}
			else {
				flag = false;
				Reporters.failureReport("Retrieve evl_order_review_ids from database for both orders", "Failed to retrieve evl_order_review_ids from database for orders: " + Order1 + ", " + Order2);
			}
			rowCount = 0;
			
			// get state ids from db
			stepReport("Get IDs of billing/shipping states from database");
			query = "select mdcuid from evladmin.evolve_state where abbr in ('" + ShipState + "','" + BillState + "')";
			rs = statement.executeQuery(query);
			// make sure # of records returned = 2
			rs.last();
			rowCount = rs.getRow();
			rs.beforeFirst();
			if (rowCount == 2){
				if(rs.next())
					shipStateID = rs.getString(1);
				if(rs.next())
					billStateID = rs.getString(1);
				Reporters.SuccessReport("Retrieve IDs of billing/shipping states from database", "Successfully retrieved IDs of the billing/shipping states from the database.");
			}
			else {
				flag = false;
				Reporters.failureReport("Retrieve IDs of billing/shipping states from database", "Failed to retrieve IDs of the billing/shipping states from the database.");
			}
			
			// if everything was successful so far, move forward with the deletions
			// will need to change selects to deletes, executeQuery to executeUpdate
			stepReport("Delete records from the database");
			if (flag) {
				
				/* this is just for debugging */
				//ResultSetMetaData rsmd;
				
				Reporters.SuccessReport("Retrieve all required info from database", "Successfully retrieved all required info from database.");
				
				conn.setAutoCommit(true);
				int rowsDeleted;
				
				// evl_order_review_audit table
				System.out.println("Deleting from evl_order_review_audit");
				query = "delete from evladmin.evl_order_review_audit where evl_order_review_id in (" + reviewIDs[0] + "," + reviewIDs[1] + ")";
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records from evl_order_review_audit", "Successfully deleted " + rowsDeleted + " rows from evl_order_review_audit.");
				// debugging
				/*
				rsmd = rs.getMetaData();
				while (rs.next()) {
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						if (j > 1) System.out.print(", ");
						String value = rs.getString(j);
						System.out.print(value);
					}
					System.out.println("");
				}
				System.out.println("");
				*/
				
				// evl_order_review table
				System.out.println("Deleting from evl_order_review");
				query = "delete from evladmin.evl_order_review where evl_order_id in (" + Order1 + "," + Order2 + ")";
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records from evl_order_review", "Successfully deleted " + rowsDeleted + " rows from evl_order_review.");
				// debugging
				/*
				rsmd = rs.getMetaData();
				while (rs.next()) {
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						if (j > 1) System.out.print(", ");
						String value = rs.getString(j);
						System.out.print(value);
					}
					System.out.println("");
				}
				System.out.println("");
				*/
				
				// order_item table
				System.out.println("Deleting from order_item");
				query = "delete from evladmin.order_item where evl_order_id in (" + Order1 + "," + Order2 + "," + Order3 + ")";
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records from order_item", "Successfully deleted " + rowsDeleted + " rows from order_item.");
				// debugging
				/*
				rsmd = rs.getMetaData();
				while (rs.next()) {
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						if (j > 1) System.out.print(", ");
						String value = rs.getString(j);
						System.out.print(value);
					}
					System.out.println("");
				}
				System.out.println("");
				*/
				
				// preorder_queue table
				System.out.println("Deleting from preorder_queue");
				query = "delete from evladmin.preorder_queue where parent_evl_order_id in (" + Order1 + "," + Order2 + ")";
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records from preorder_queue", "Successfully deleted " + rowsDeleted + " rows from preorder_queue.");
				// debugging
				/*
				rsmd = rs.getMetaData();
				while (rs.next()) {
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						if (j > 1) System.out.print(", ");
						String value = rs.getString(j);
						System.out.print(value);
					}
					System.out.println("");
				}
				System.out.println("");
				*/
				
				// evl_order table
				System.out.println("Deleting from evl_order");
				query = "delete from evladmin.evl_order where evl_order_id in (" + Order1 + "," + Order2 + "," + Order3 + ")";
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records from evl_order", "Successfully deleted " + rowsDeleted + " rows from evl_order.");
				// debugging
				/*
				rsmd = rs.getMetaData();
				while (rs.next()) {
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						if (j > 1) System.out.print(", ");
						String value = rs.getString(j);
						System.out.print(value);
					}
					System.out.println("");
				}
				System.out.println("");
				*/
				
				// credit_card_detail table
				System.out.println("Deleting from credit_card_detail");
				query = "delete from evladmin.credit_card_detail where credit_card_id in (" + ccIDs[0] + "," + ccIDs[1] + ")";
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records from credit_card_detail", "Successfully deleted " + rowsDeleted + " rows from credit_card_detail.");
				// debugging
				/*
				rsmd = rs.getMetaData();
				while (rs.next()) {
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						if (j > 1) System.out.print(", ");
						String value = rs.getString(j);
						System.out.print(value);
					}
					System.out.println("");
				}
				System.out.println("");
				*/
				
				// suspected_address table (shipping address)
				System.out.println("Deleting from suspected_address (shipping)");
				query = "delete from evladmin.suspected_address where line1 = '" + ShipStreet + "' and city = '" + ShipCity + "' and zip = '" + ShipZip + "' and state_mdcuid = " + shipStateID;
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records for shipping address from suspected_address", "Successfully deleted " + rowsDeleted + " rows from suspected_address.");
				// debugging
				/*
				rsmd = rs.getMetaData();
				while (rs.next()) {
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						if (j > 1) System.out.print(", ");
						String value = rs.getString(j);
						System.out.print(value);
					}
					System.out.println("");
				}
				System.out.println("");
				*/
				
				// suspected_address_table (billing address)
				System.out.println("Deleting from suspected_address (billing)");
				query = "delete from evladmin.suspected_address where line1 = '" + BillStreet + "' and city = '" + BillCity + "' and zip = '" + BillZip + "' and state_mdcuid = " + billStateID;
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records for billing address from suspected_address", "Successfully deleted " + rowsDeleted + " rows from suspected_address.");
				// debugging
				/*
				rsmd = rs.getMetaData();
				while (rs.next()) {
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						if (j > 1) System.out.print(", ");
						String value = rs.getString(j);
						System.out.print(value);
					}
					System.out.println("");
				}
				*/
			}
			
			else {
				Reporters.failureReport("Retrieve all required info from database", "Failed to retrieve all required info from database. Nothing has been deleted!");
			}
			
			rs.close();
			statement.close();
			conn.close();
			
		} catch(Exception e){
			System.out.println(e.getMessage());
		}
			
	}
	
	@AfterTest
	public void tear() throws Throwable {
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}

}
