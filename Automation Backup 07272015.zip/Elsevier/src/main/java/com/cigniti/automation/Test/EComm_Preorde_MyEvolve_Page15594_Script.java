package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EComm_Preorde_MyEvolve_Page15594_BussinessFunctions;
import com.cigniti.automation.BusinessFunctions.Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class EComm_Preorde_MyEvolve_Page15594_Script extends EComm_Preorde_MyEvolve_Page15594_BussinessFunctions {

	public static final String SIM_6 =ReadingExcel.columnDataByHeaderName("product", "TC-15594", testDataPath);
	
	@Test
	public void eCommPreorderMyEvolvePageScript15594()throws Throwable{
		
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//SwitchToBrowser(ElsevierObjects.studentBrowserType);
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		//ElsevierObjects.browserType="firefox";
		String pubDatePreOrder=ReadingExcel.columnDataByHeaderName("pubDatePreOrder", "TC-15594", testDataPath);
		String pubDatePreOrderStatus=ReadingExcel.columnDataByHeaderName("pubDateStatusPreOrder", "TC-15594", testDataPath);
		String pubDatePostOrder=ReadingExcel.columnDataByHeaderName("pubDatePostOrder", "TC-15594", testDataPath);
		String pubDatePostOrderStatus=ReadingExcel.columnDataByHeaderName("pubDatePostStatus", "TC-15594", testDataPath);
		
		adminLogin();
		
		editResource(SIM_6);
		
		modifyPublicatonDate(pubDatePreOrder,pubDatePreOrderStatus);
		Thread.sleep(low);
		writeReport(launchUrl(configProps.getProperty("NoCacheURL")), "Run the URL https://evolvecert.elsevier.com/cs/noCache", "Successfully ran the URL https://evolvecert.elsevier.com/cs/noCache", "Failed to run the URL https://evolvecert.elsevier.com/cs/noCache");
		Thread.sleep(medium);
		driver.navigate().back();
		Thread.sleep(medium);
		createAccessCode(SIM_6);
		
		writeReport(adminLogout(), "Logout from the Admin user", "Successfully logged out from the application as admin user", "Logout failed");
		
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions.CreateNewUser("student", "eCommPreorderMyEvolvePage15594", "ECommercePreOrder", 4, 1,2,0);
				
		
		//writeReport(CreateNewUser("Student"), "Create New Student user and log into the application", "Successfully Created new student user with the credentials : <br> Username : "+credentials[0]+"<br> Password : "+credentials[1]+" <br>Successfully logged in as New Student user", "Failed to Create new user");
		
		String studentUserName = EvolveCommonBussinessFunctions.credentials[0];
		String studentPasswrod = EvolveCommonBussinessFunctions.credentials[1];
		System.out.println(studentUserName +","+ studentPasswrod);
		
		searchISBNNumber(SIM_6);
		
		studnetCheckOut(true,SIM_6);
		
		adminLogin();
		
		editResource(SIM_6);
		
		modifyPublicatonDate(pubDatePostOrder,pubDatePostOrderStatus);
		
		writeReport(launchUrl(configProps.getProperty("NoCacheURL")), "Run the URL https://evolvecert.elsevier.com/cs/noCache", "Successfully ran the URL https://evolvecert.elsevier.com/cs/noCache", "Failed to run the URL https://evolvecert.elsevier.com/cs/noCache");
		
	}
	
	@AfterTest
	public void closeBrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		//Base.tearDown();
	}
	
	
}
