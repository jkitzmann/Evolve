package com.cigniti.automation.Utilities;

import java.io.File;

import com.cigniti.automation.accelerators.Actiondriver;

public class FileDelete extends Actiondriver{
	public static void deleteFile(String filePath) throws Throwable
	{	
		try{
			
			File file = new File(filePath);
			if(file.delete()){
				System.out.println(file.getName() + " is deleted!");
			}else{
				System.out.println("Delete operation is failed.");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	    }
	}
