package com.cigniti.automation.Test;

import java.text.SimpleDateFormat;
import java.util.Random;
import java.util.Date;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.Rosteredstudentredeemsaccesscode_10433;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class Rosteredstudentredeemsaccesscode_Script_10433 extends Rosteredstudentredeemsaccesscode_10433 {
  @Test
  public void rosteredstudentredeemsaccesscode_10433() throws Throwable {
	  SwitchToBrowser(ElsevierObjects.studentBrowserType);
	  Isbn = ReadingExcel.columnDataByHeaderName("searchNumber","TC-10410",configProps.getProperty("TestData")); 
	  Random ra = new Random( System.currentTimeMillis() );
	  Date today = new Date();
	  SimpleDateFormat sdf = new SimpleDateFormat ("MMddyyyy");
	  CodeSetName = ReadingExcel.columnDataByHeaderName("Codesetname","TC-10433",configProps.getProperty("TestData"))+Integer.toString((1 + ra.nextInt(2)) * 100 + ra.nextInt(100)) + "-" + sdf.format(today);
	  Codesetnumber = ReadingExcel.columnDataByHeaderName("Codesetnumber","TC-10433",configProps.getProperty("TestData"));
	  Username=ReadingExcel.columnDataByHeaderName("Username","TC-10433",configProps.getProperty("TestData")); 
	  Password=ReadingExcel.columnDataByHeaderName("password","TC-10433",configProps.getProperty("TestData")); 
	  CoursId=ReadingExcel.columnDataByHeaderName("CourseId","TC-15565",configProps.getProperty("TestData"));
	  
	  Reporters.SuccessReport("Create 'LO Unique Course Fulfillment-Faculty' and 'Create Roster for LO Course'",
			                  "Created 'LO Unique Course Fulfillment-Faculty' and get ISBN and  protection scheme ID </br>" +Isbn+
	  		"                 </br> Created 'Create Roster for LO Course' and get rostered student Username,Password and rostered student CourseId </br> "+Username+"</br>"+Password+"</br>"+CoursId);
	  
	  writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Enter Admin URL and login with the Credentials",
                                                                    "Successfully launched with Admin URL and logged in with User credentials",
                                                                    "Failed to login with Admin URL and login");
	  Rosteredstudentredeemsaccesscode_10433.RedeemaccessinAdmin();
	  Rosteredstudentredeemsaccesscode_10433.Studentlogin();
  }
}
