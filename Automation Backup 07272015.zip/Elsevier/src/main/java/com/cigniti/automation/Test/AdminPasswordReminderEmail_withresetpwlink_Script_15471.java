package com.cigniti.automation.Test;

import java.util.Random;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.AdminPasswordReminderEmail_withresetpwlink_15471;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class AdminPasswordReminderEmail_withresetpwlink_Script_15471 extends AdminPasswordReminderEmail_withresetpwlink_15471{
  @Test
  public void AdminPasswordReminderEmail_withresetpwlink_15471() throws Throwable {
	  
	  stepReport("Create new Evolve Admin user.");
	  SwitchToBrowser(ElsevierObjects.adminBrowserType);
	  Add_Administartors_UI_Script_15476.Add_Administrator_UI_15476();
	  Firstname = ReadingExcel.columnDataByHeaderName("Firstname","TC-15476",configProps.getProperty("TestData"));
	  Lastname =ReadingExcel.columnDataByHeaderName("Lastname","TC-15476",configProps.getProperty("TestData"));
	  EmailId = Add_Administartors_UI_Script_15476.Email;
	  first=ReadingExcel.columnDataByHeaderName("first", "TC-15476",configProps.getProperty("TestData"));
	  last=ReadingExcel.columnDataByHeaderName("last", "TC-15476",configProps.getProperty("TestData"));
	  email=ReadingExcel.columnDataByHeaderName("email", "TC-15476",configProps.getProperty("TestData"));
	  System.out.println("FirstName===>>>>"+EmailId);
	  FIRSTNAME = Firstname.toUpperCase();
	  LASTNAME=Lastname.toUpperCase();
	  EMAILID=EmailId.toUpperCase();
	  Password=ReadingExcel.columnDataByHeaderName("Password",  "TC-15476",configProps.getProperty("TestData"));
	  Password1=ReadingExcel.columnDataByHeaderName("Password1", "TC-15476",configProps.getProperty("TestData"));
	  Password2=ReadingExcel.columnDataByHeaderName("Password2", "TC-15476",configProps.getProperty("TestData"));
	  Password3=ReadingExcel.columnDataByHeaderName("Password3", "TC-15476",configProps.getProperty("TestData"));
	  Password4=ReadingExcel.columnDataByHeaderName("Password4", "TC-15476",configProps.getProperty("TestData"));
	  Password5=ReadingExcel.columnDataByHeaderName("Password5", "TC-15476",configProps.getProperty("TestData"));
	  Random ra = new Random(System.currentTimeMillis());
	  Password6=ReadingExcel.columnDataByHeaderName("Password6", "TC-15476",configProps.getProperty("TestData"))+Integer.toString((1 + ra.nextInt(2)) * 1000 + ra.nextInt(1000));
	  confirmpassword=ReadingExcel.columnDataByHeaderName("confirmPassword", "TC-15476",configProps.getProperty("TestData"));
	 
	  
	  stepReport("Submit password reset request.");
	  writeReport(AdminPasswordReminderEmail_withresetpwlink_15471.ResetPassword(),"Launch EvolveAdminURL,click on PasswordReminder and enter details",
			                                                                       "Successfully Launched EvolveAdmin URL </br> Click on PasswordReminder and Enter details in textboxs",
			                                                                       "Failed to launch URL and Enter details in the PasswordReminder page ");
	 
	  stepReport("Verify password reset email.");
	  //SwitchToBrowser("firefox");
	  // changed function from Emailforwarding() to WebmailVerification()
	  writeReport(AdminPasswordReminderEmail_withresetpwlink_15471.WebmailVerification(),"Launch EmailURl and Forward Email to Checkable Gmail Account",
			                                                                         "Successfully Launched EmailURL and Email is forwarded to Checkable Gmail Account",
			                                                                         "Failed to Launch Email URL and Email forward to Gmail account");
	
	  //SwitchToBrowser("firefox");
	  //Thread.sleep(veryhigh);
	  /*
	  writeReport(AdminPasswordReminderEmail_withresetpwlink_15471.Gmailverification(),"Launch GmailURL,Search for Forwarded Email and ResetPassword",
			                                                                           "Successfully Launched GmailURL </br> searched for Forwarded Email </br> click on ClickHere link </br> Reset Password and Relogin with the password",
			                                                                           "Failed to Launch Gmail URL and Search for Forwarded Email and Reset the Password");
	  */
	
	 }	   		
}
