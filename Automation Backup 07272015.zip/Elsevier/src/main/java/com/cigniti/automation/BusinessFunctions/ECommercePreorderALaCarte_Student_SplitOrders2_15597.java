package com.cigniti.automation.BusinessFunctions;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;









import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class ECommercePreorderALaCarte_Student_SplitOrders2_15597 extends EvolveCommonBussinessFunctions{

public static boolean verifyOrderSubmitDateCalender(String preOrderStatus) throws Throwable{
	boolean flag=true;
	
	try{
		isElementPresent(ElsevierObjects.ORDER_SUBMIT_DATE);
		click(ElsevierObjects.ORDER_SUBMIT_STARTDATE_CALENDER, "Clickin On Start Dtae Calender.");
		Thread.sleep(3000);
		String todaysDate=getText(ElsevierObjects.CALENDER_TODAYSDATE, "");
		String preOrderCalenderDate=todaysDate.split(": ")[1];
		
		System.out.println("preOrderCalenderDate:"+preOrderCalenderDate);
		
		Calendar c = Calendar.getInstance();
		Date d=c.getTime();
		DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
	   
	    String CurrentDate=formatter.format(d);
	   
	    if(preOrderCalenderDate.equalsIgnoreCase(CurrentDate)){
	    	Reporters.SuccessReport("Verifying Whether Start Date is calendar control Or not.", "Successfully Verified Start Date : "+preOrderCalenderDate);
	    }
	    else{
	    	Reporters.failureReport("Verifying Whether Start Date is calendar control Or not.", "Failed To Verify Start Date.");
	    }
	    
	    String NoStartDate=getText(ElsevierObjects.ORDER_SUBMIT_STARTDATE_INPUT, "");
	    System.out.println("star:"+NoStartDate+":end");
		if(NoStartDate.equalsIgnoreCase("")){
			Reporters.SuccessReport("Verifying default date is none in Start Date.", "Successfully Verified Default Date.");
		}
		else{
			Reporters.failureReport("Verifying default date is none in Start Date.", "Failed To Verify Default date.");
		}
	    
		selectByValue(ElsevierObjects.STATUS_INPUT, preOrderStatus, "select the status input");
	    
		click(ElsevierObjects.PREORDER_SEARCH_BUTTON, "Clicking On Search Button.");
		Thread.sleep(3000);
		
		if(isElementPresent(ElsevierObjects.preOrderTable) || isElementPresent(ElsevierObjects.NO_PREORDER)){
				Reporters.SuccessReport("Verifying start date is not required to run the report.","Without Start Date Search is Successfull And The Page Navigated to preorder deatils page.");
		}
		else {
			Reporters.failureReport("Verifying start date is not required to run the report.", "Without Start Date Search Failed.");
		}
	    
		if(click(ElsevierObjects.EVOLVE_BUTTON, "click MyEvolve button")){
			Reporters.SuccessReport("Clicking on Evolve Admin Link.", "Successfully Clicked On Evolve Admin Link.");
		}
		else{
			Reporters.failureReport("Clicking on Evolve Admin Link.", "Failed To Click On Evolve Admin Link.");
		}
		Thread.sleep(3000);
		searchPreOrder();
		Thread.sleep(3000);
		click(ElsevierObjects.ORDER_SUBMIT_ENDDATE_CALENDER, "Clickin On End Dtae Calender.");
		Thread.sleep(3000);
		String endDatetodaysDate=getText(ElsevierObjects.CALENDER_TODAYSDATE, "");
		String endDateCalenderDate=endDatetodaysDate.split(": ")[1];
		
		
		Calendar c1 = Calendar.getInstance();
		Date d1=c1.getTime();
		DateFormat formatter1 = new SimpleDateFormat("MM/dd/yyyy");
	   
	    String CurrentDate1=formatter1.format(d1);
		
	    if(endDateCalenderDate.equalsIgnoreCase(CurrentDate1)){
	    	Reporters.SuccessReport("Verifying Whether End Date is calendar control Or not.", "Successfully Verified End Date : "+endDateCalenderDate);
	    }
	    else{
	    	Reporters.failureReport("Verifying Whether End Date is calendar control Or not.", "Failed To Verify End Date.");
	    }
	    
	    String NoEndDate=getText(ElsevierObjects.ORDER_SUBMIT_ENDDATE_INPUT, "");
		if(NoEndDate.equalsIgnoreCase("")){
			Reporters.SuccessReport("Verifying default date is none in End Date.", "Successfully Verified Default Date in End Date.");
		}
		else{
			Reporters.failureReport("Verifying default date is none in End Date.", "Failed To Verify Default date in End Date.");
		}
	    System.out.println();
	    selectByValue(ElsevierObjects.STATUS_INPUT, preOrderStatus, "select the status input");
		Thread.sleep(3000);
		click(ElsevierObjects.PREORDER_SEARCH_BUTTON, "Clicking On Search Button.");
		Thread.sleep(3000);
		if(isElementPresent(ElsevierObjects.preOrderTable) || isElementPresent(ElsevierObjects.NO_PREORDER)){
			Reporters.SuccessReport("Verifying End date is not required to run the report.","Without End Date Search is Successfull And The Page Navigated to preorder deatils page.");
		}
		else{
			Reporters.failureReport("Verifying End date is not required to run the report.", "");
		} 
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();System.out.println(sgErrMsg);return false;
	}
    
    return flag;
}

public static void searchPreOrder() throws Throwable{
	
	if(click(ElsevierObjects.SEARCHPREORDER,"Clicking On Search PreOrder Link In Admin.")){
		Reporters.SuccessReport("Clicking On Search PreOrder/Generate Report under PreOrder Maintenance section.", "Successfully Clicked On Search PreOrder Report Link.");
	}
	else{
		Reporters.failureReport("Clicking On Search PreOrder/Generate Report under PreOrder Maintenance section.", "Failed To Click On Search PreOrder Report Link.");
	}
}

public static boolean verifyPreOrderFulfillmentCalender(String preOrderStatus) throws Throwable{
	boolean flag=true;
	try{
		
		if(click(ElsevierObjects.EVOLVE_BUTTON, "click MyEvolve button")){
			Reporters.SuccessReport("Clicking on Evolve Admin Link.", "Successfully Clicked On Evolve Admin Link.");
		}
		else{
			Reporters.failureReport("Clicking on Evolve Admin Link.", "Failed To Click On Evolve Admin Link.");
		}
		Thread.sleep(3000);
		searchPreOrder();
		Thread.sleep(3000);
		isElementPresent(ElsevierObjects.PREORDER_FULFILLMENT_DATE);
		click(ElsevierObjects.PREORDER_FULFILLMENT_STARTDATE_CALENDER, "Clickin On Start Dtae Calender.");
		Thread.sleep(3000);
		String todaysDate=getText(ElsevierObjects.CALENDER_TODAYSDATE, "");
		String preOrderCalenderDate=todaysDate.split(": ")[1];
		
		
		Calendar c = Calendar.getInstance();
		Date d=c.getTime();
		DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
	   
	    String CurrentDate=formatter.format(d);
		
	    if(preOrderCalenderDate.equalsIgnoreCase(CurrentDate)){
	    	Reporters.SuccessReport("Verifying Whether Start Date is calendar control Or not.", "Successfully Verified Start Date : "+preOrderCalenderDate);
	    }
	    else{
	    	Reporters.failureReport("Verifying Whether Start Date is calendar control Or not.", "Failed To Verify Start Date.");
	    }
	    
	    String NoStartDate=getText(ElsevierObjects.PREORDER_FULFILLMENT_STARTDATE_INPUT, "");
		if(NoStartDate.equalsIgnoreCase("")){
			Reporters.SuccessReport("Verifying default date is none in Start Date.", "Successfully Verified Default Date.");
		}
		else{
			Reporters.failureReport("Verifying default date is none in Start Date.", "Failed To Verify Default date.");
		}
	    
		selectByValue(ElsevierObjects.STATUS_INPUT, preOrderStatus, "select the input status");
		Thread.sleep(3000);
		click(ElsevierObjects.PREORDER_SEARCH_BUTTON, "Clicking On Search Button.");
		Thread.sleep(3000);
		if(isElementPresent(ElsevierObjects.preOrderTable) || isElementPresent(ElsevierObjects.NO_PREORDER)){
			Reporters.SuccessReport("Verifying start date is not required to run the report.","Without Start Date Search is Successfull And The Page Navigated to preorder deatils page.");
		}
		else{
			Reporters.failureReport("Verifying start date is not required to run the report.", "");
		}
	    
		if(click(ElsevierObjects.EVOLVE_BUTTON, "click on the MyEvolve button")){
			Reporters.SuccessReport("Clicking on Evolve Admin Link.", "Successfully Clicked On Evolve Admin Link.");
		}
		else{
			Reporters.failureReport("Clicking on Evolve Admin Link.", "Failed To Click On Evolve Admin Link.");
		}
		Thread.sleep(3000);
		searchPreOrder();
		Thread.sleep(3000);
		click(ElsevierObjects.PREORDER_FULFILLMENT_ENDDATE_CALENDER, "Clickin On End Dtae Calender.");
		Thread.sleep(3000);
		String endDatetodaysDate=getText(ElsevierObjects.CALENDER_TODAYSDATE, "");
		String endDateCalenderDate=endDatetodaysDate.split(": ")[1];
		
		
		Calendar c1 = Calendar.getInstance();
		Date d1=c1.getTime();
		DateFormat formatter1 = new SimpleDateFormat("MM/dd/yyyy");
	   
	    String CurrentDate1=formatter1.format(d1);
	    if(endDateCalenderDate.equalsIgnoreCase(CurrentDate1)){
	    	Reporters.SuccessReport("Verifying Whether End Date is calendar control Or not.", "Successfully Verified End Date : "+endDateCalenderDate);
	    }
	    else{
	    	Reporters.failureReport("Verifying Whether End Date is calendar control Or not.", "Failed To Verify End Date.");
	    }
	    
	    String NoEndDate=getText(ElsevierObjects.PREORDER_FULFILLMENT_ENDDATE_INPUT, "");
		if(NoEndDate.equalsIgnoreCase("")){
			Reporters.SuccessReport("Verifying default date is none in End Date.", "Successfully Verified Default Date in End Date.");
		}
		else{
			Reporters.failureReport("Verifying default date is none in End Date.", "Failed To Verify Default date in End Date.");
		}
	    
		selectByValue(ElsevierObjects.STATUS_INPUT, preOrderStatus, "select the input status");
		Thread.sleep(3000);
		click(ElsevierObjects.PREORDER_SEARCH_BUTTON, "Clicking On Search Button.");
		Thread.sleep(3000);
		if(isElementPresent(ElsevierObjects.preOrderTable) || isElementPresent(ElsevierObjects.NO_PREORDER)){
			Reporters.SuccessReport("Verifying End date is not required to run the report.","Without End Date Search is Successfull And The Page Navigated to preorder deatils page.");
		}
		else{
			Reporters.failureReport("Verifying End date is not required to run the report.", "");
		} 
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
	}
	return flag;
}
public static boolean verifyStatus(String value1,String value2,String value3,String value4,String ISBN) throws Throwable{
	boolean flag=true;
	try{
		
		List<String> statusValues = new ArrayList<String>();
		statusValues.add(value1);
		statusValues.add(value2);
		statusValues.add(value3);
		statusValues.add(value4);
		
		isElementPresent(ElsevierObjects.STATUS);
		List<WebElement> ele=driver.findElements(By.xpath(".//*[@id='status']/option"));
		
		for(int i=1;i<=4;i++){
			WebElement ele2=ele.get(i);
			String ele3=ele2.getText();
			System.out.println(ele3);
				if(statusValues.contains(ele3.trim())){
					Reporters.SuccessReport("Verifying Dropdown Values of Status Dropdown.", "Succesfully Verified Dropdown Value :"+ele3);
				}
				else{
					Reporters.failureReport("Verifying Dropdown Values of Status Dropdown.", "Failed To Verify Dropdown Value.");
				}
			}
		
		selectByVisibleText(ElsevierObjects.STATUS_INPUT, "Select", "Selecting Value from dropdown.");
		Thread.sleep(medium);
		type(ElsevierObjects.ISBN_INPUT, ISBN, "Entering ISBN Value.");
		click(ElsevierObjects.PREORDER_SEARCH_BUTTON, "Clicking On Search Button.");
		Thread.sleep(3000);
		if(!isElementPresent(ElsevierObjects.preOrderTable) && !isElementPresent(ElsevierObjects.NO_PREORDER)){
			Reporters.failureReport("Verifying report can be run without selecting one of the status values", "No preorder results are displayed without selecting a status when searching only by ISBN: " + ISBN);
		}
		else{
			Reporters.SuccessReport("Verifying report can be run without selecting one of the status values", "Preorder results are displayed without selecting a status when searching only by ISBN: " + ISBN);
		} 
		Thread.sleep(3000);
		if(click(ElsevierObjects.EVOLVE_BUTTON, "click on the MyEvolve button")){
			Reporters.SuccessReport("Clicking on Evolve Admin Link.", "Successfully Clicked On Evolve Admin Link.");
		}
		else{
			Reporters.failureReport("Clicking on Evolve Admin Link.", "Failed To Click On Evolve Admin Link.");
		}
		Thread.sleep(3000);
		searchPreOrder();
		Thread.sleep(3000);
	}
		catch(Exception e){
			sgErrMsg=e.getMessage();
		}
	return flag;
	}

public static boolean verifyISBN(String preOrderStatus,String orderID,String username,String year) throws Throwable{
	boolean flag=false;
	try{
		click(ElsevierObjects.ORDER_SUBMIT_STARTDATE_CALENDER, "Clickin On Start Dtae Calender.");
		Thread.sleep(3000);
		selectByVisibleText(ElsevierObjects.CALENDER_STARTDATE_YEAR,year, "Select Start Date Year");
		Thread.sleep(3000);
		click(ElsevierObjects.SELECT_STARTDATE, "Selecting Start Date.");
		Thread.sleep(3000);
		click(ElsevierObjects.ORDER_SUBMIT_ENDDATE_CALENDER, "Clickin On End Dtae Calender.");
		Thread.sleep(3000);
		click(ElsevierObjects.SELECT_ENDDATE, "Selecting End Date.");
		Thread.sleep(3000);
		click(ElsevierObjects.PREORDER_FULFILLMENT_STARTDATE_CALENDER, "Clickin On Start Dtae Calender.");
		
		Thread.sleep(3000);
		selectByVisibleText(ElsevierObjects.CALENDER_STARTDATE_YEAR,year, "Select Start Date Year");
		Thread.sleep(3000);
		click(ElsevierObjects.SELECT_STARTDATE, "Selecting Start Date.");
		Thread.sleep(3000);
		click(ElsevierObjects.PREORDER_FULFILLMENT_ENDDATE_CALENDER, "Clickin On End Dtae Calender.");
		Thread.sleep(3000);
		click(ElsevierObjects.SELECT_ENDDATE, "Selecting End Date.");
		Thread.sleep(3000);
		selectByValue(ElsevierObjects.STATUS_INPUT, preOrderStatus, "select the input status");
		Thread.sleep(3000);
		type(ElsevierObjects.ORDERID_INPUT,orderID,"Enter Order ID");
		Thread.sleep(3000);
		type(ElsevierObjects.USERNAME_INPUT,username, "Enter UserName");
		Thread.sleep(3000);
		click(ElsevierObjects.PREORDER_SEARCH_BUTTON, "Clicking On Search Button.");
		Thread.sleep(3000);
		if(isElementPresent(ElsevierObjects.preOrderTable) || isElementPresent(ElsevierObjects.NO_PREORDER)){
			Reporters.SuccessReport("Verifying ISBN is not a required field","Selected status : "+preOrderStatus+" And Entered Username :"+username+" And Entered OrderID :"+orderID+".Clicked On Search Button.</br>Without Entering ISBN Value Page is navigated To Pre Order Details Page.");
		}
		else{
			Reporters.failureReport("Verifying ISBN is not a required field", "Without Entering ISBN Value unable to navigate to Pre Order Details Page");
		}  
		if(click(ElsevierObjects.EVOLVE_BUTTON, "click on the MyEvolve button")){
			Reporters.SuccessReport("Clicking on Evolve Admin Link.", "Successfully Clicked On Evolve Admin Link.");
		}
		else{
			Reporters.failureReport("Clicking on Evolve Admin Link.", "Failed To Click On Evolve Admin Link.");
		}
		searchPreOrder();
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
	}
	
	return flag;
}
public static boolean verifyOrderID(String preOrderStatus,String ISBN,String username,String year) throws Throwable{
	boolean flag=false;
	try{
		click(ElsevierObjects.ORDER_SUBMIT_STARTDATE_CALENDER, "Clickin On Start Dtae Calender.");
		Thread.sleep(3000);
		selectByVisibleText(ElsevierObjects.CALENDER_STARTDATE_YEAR,year, "Select Start Date Year");
		Thread.sleep(3000);
		click(ElsevierObjects.SELECT_STARTDATE, "Selecting Start Date.");
		Thread.sleep(3000);
		click(ElsevierObjects.ORDER_SUBMIT_ENDDATE_CALENDER, "Clickin On End Dtae Calender.");
		Thread.sleep(3000);
		click(ElsevierObjects.SELECT_ENDDATE, "Selecting End Date.");
		Thread.sleep(3000);
		click(ElsevierObjects.PREORDER_FULFILLMENT_STARTDATE_CALENDER, "Clickin On Start Dtae Calender.");
		selectByVisibleText(ElsevierObjects.CALENDER_STARTDATE_YEAR,year, "Select Start Date Year");
		Thread.sleep(3000);
		click(ElsevierObjects.SELECT_STARTDATE, "Selecting Start Date.");
		Thread.sleep(3000);
		click(ElsevierObjects.PREORDER_FULFILLMENT_ENDDATE_CALENDER, "Clickin On End Dtae Calender.");
		Thread.sleep(3000);
		click(ElsevierObjects.SELECT_ENDDATE, "Selecting End Date.");
		Thread.sleep(3000);
		selectByValue(ElsevierObjects.STATUS_INPUT, preOrderStatus, "select the input status");
		Thread.sleep(3000);
		type(ElsevierObjects.ISBN_INPUT, ISBN, "Entering ISBN Value.");
		Thread.sleep(3000);
		type(ElsevierObjects.USERNAME_INPUT,username, "Enter UserName");
		Thread.sleep(3000);
		click(ElsevierObjects.PREORDER_SEARCH_BUTTON, "Clicking On Search Button.");
		Thread.sleep(3000);
		if(isElementPresent(ElsevierObjects.preOrderTable) || isElementPresent(ElsevierObjects.NO_PREORDER)){
			Reporters.SuccessReport("Verifying Order Id is not a required field","Selected status : "+preOrderStatus+" And Entered Username :"+username+" And Entered ISBN :"+ISBN+".Clicked On Search Button.</br>Without Entering Order Id Value Page is navigated To Pre Order Details Page.");
		}
		else{
			Reporters.failureReport("Verifying Order Id not a required field", "Without Entering Order Id unable to navigate to Pre Order Details Page");
		}  
		if(click(ElsevierObjects.EVOLVE_BUTTON, "click on the MyEvolve button")){
			Reporters.SuccessReport("Clicking on Evolve Admin Link.", "Successfully Clicked On Evolve Admin Link.");
		}
		else{
			Reporters.failureReport("Clicking on Evolve Admin Link.", "Failed To Click On Evolve Admin Link.");
		}
		Thread.sleep(3000);
		searchPreOrder();
		Thread.sleep(3000);
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
	}
	
	return flag;
}
public static boolean verifyUsername(String preOrderStatus,String ISBN,String orderID,String year) throws Throwable{
	boolean flag=false;
	try{
		click(ElsevierObjects.ORDER_SUBMIT_STARTDATE_CALENDER, "Clickin On Start Dtae Calender.");
		Thread.sleep(3000);
		selectByVisibleText(ElsevierObjects.CALENDER_STARTDATE_YEAR,year, "Select Start Date Year");
		Thread.sleep(3000);
		click(ElsevierObjects.SELECT_STARTDATE, "Selecting Start Date.");
		Thread.sleep(3000);
		click(ElsevierObjects.ORDER_SUBMIT_ENDDATE_CALENDER, "Clickin On End Dtae Calender.");
		Thread.sleep(3000);
		click(ElsevierObjects.SELECT_ENDDATE, "Selecting End Date.");
		Thread.sleep(3000);
		click(ElsevierObjects.PREORDER_FULFILLMENT_STARTDATE_CALENDER, "Clickin On Start Dtae Calender.");
		Thread.sleep(3000);
		selectByVisibleText(ElsevierObjects.CALENDER_STARTDATE_YEAR,year, "Select Start Date Year");
		Thread.sleep(3000);
		click(ElsevierObjects.SELECT_STARTDATE, "Selecting Start Date.");
		Thread.sleep(3000);
		click(ElsevierObjects.PREORDER_FULFILLMENT_ENDDATE_CALENDER, "Clickin On End Dtae Calender.");
		Thread.sleep(3000);
		click(ElsevierObjects.SELECT_ENDDATE, "Selecting End Date.");
		Thread.sleep(3000);
		selectByValue(ElsevierObjects.STATUS_INPUT, preOrderStatus, "select the input status");
		Thread.sleep(3000);
		type(ElsevierObjects.ISBN_INPUT, ISBN, "Entering ISBN Value.");
		Thread.sleep(3000);
		type(ElsevierObjects.ORDERID_INPUT,orderID,"Enter Order ID");
		Thread.sleep(3000);
		click(ElsevierObjects.PREORDER_SEARCH_BUTTON, "Clicking On Search Button.");
		Thread.sleep(3000);
		if(isElementPresent(ElsevierObjects.preOrderTable) || isElementPresent(ElsevierObjects.NO_PREORDER)){
			Reporters.SuccessReport("Verifying Username is not a required field","Selected status : "+preOrderStatus+" And Entered OrderID :"+orderID+" And Entered ISBN :"+ISBN+".Clicked On Search Button.</br>Without Entering Username Value Page is navigated To Pre Order Details Page.");
		}
		else{
			Reporters.failureReport("Verifying Username not a required field", "Without Entering Username unable to navigate to Pre Order Details Page");
		} 
		Thread.sleep(3000);
		if(isEnabled(ElsevierObjects.PREORDER_SEARCH_BUTTON, "Verifying Search Button is in Enabled State or Not.")){
			Reporters.SuccessReport("Verifying Search Button Is Enabled Or Not.","Search Button Is In Enabled State.");
		}
		else{
			Reporters.failureReport("Verifying Search Button Is Enabled Or Not.", "Search Button Is Not In Enabled State.");
		}
		Thread.sleep(3000);
		if(click(ElsevierObjects.EVOLVE_BUTTON, "click on the Evolve button")){
			Reporters.SuccessReport("Clicking on Evolve Admin Link.", "Successfully Clicked On Evolve Admin Link.");
		}
		else{
			Reporters.failureReport("Clicking on Evolve Admin Link.", "Failed To Click On Evolve Admin Link.");
		}
		Thread.sleep(3000);
		searchPreOrder();
		Thread.sleep(3000);
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
	}
	
	return flag;
}
public static boolean verifyPreOrderDetails() throws Throwable{
	boolean flag=true;
	try{
		click(ElsevierObjects.ORDER_SUBMIT_STARTDATE_CALENDER, "Clickin On Start Date Calender.");
		Thread.sleep(3000);
		click(ElsevierObjects.CALENDER_TODAYSDATE, "Clicking On Todays Date in StartDate Calender.");
		Thread.sleep(3000);
		click(ElsevierObjects.ORDER_SUBMIT_ENDDATE_CALENDER, "Clickin On End Dtae Calender.");
		Thread.sleep(3000);
		click(ElsevierObjects.CALENDER_TODAYSDATE, "Clicking on Todays Date In End Date Calender.");
		Thread.sleep(3000);
		click(ElsevierObjects.PREORDER_SEARCH_BUTTON, "Clicking On Search Button.");
		Thread.sleep(3000);
		
		List<WebElement> element=driver.findElements(By.xpath(".//*[@id='preOrderSearchResults']/table/thead/tr[1]/th//button"));
		int buttonsCount=element.size();
		System.out.println("buttonsCount:"+buttonsCount);
		if(buttonsCount >5){
			List<WebElement> element1=driver.findElements(By.xpath(".//*[@id='preOrderSearchResults']/table/tbody//tr"));
			int tablesize=element1.size();
			if(tablesize==100){
				Reporters.SuccessReport("Verifying PreOrder Results Paginates For Every 100 Preorders.", "Successfully Verified PreOrder Results Paginates For Every 100 Preorders And The Size Of The Table is :"+tablesize);
			}
			else{
				Reporters.failureReport("Verifying PreOrder Results Paginates For Every 100 Preorders.", "Failed To Verify PreOrder Results Paginates For Every 100 Preorders And The Size Of The Table is :"+tablesize);
			}
		}
		else{
			List<WebElement> element2=driver.findElements(By.xpath(".//*[@id='preOrderSearchResults']/table/tbody//tr"));
			int tablesize1=element2.size();
			if(tablesize1>0){
				Reporters.SuccessReport("Verifying PreOrder Results Paginates For Every 100 Preorders.", "There Are Less than 100 Preorders in the corresponding search And The Size Of The Table is :"+tablesize1);
			}
			else{
				Reporters.failureReport("Verifying PreOrder Results Paginates For Every 100 Preorders.", "Failed To Verify PreOrder Results.");
			}
		}
	}
	catch(Exception e){
		
		sgErrMsg=e.getMessage();
		
	}
	return flag;
}
public static boolean verifyDateError(String futureyear) throws Throwable{
	boolean flag=true;
	try{
		click(ElsevierObjects.ORDER_SUBMIT_STARTDATE_CALENDER, "Clickin On Start Date Calender.");
		Thread.sleep(medium);
		selectByVisibleText(ElsevierObjects.CALENDER_STARTDATE_YEAR,futureyear, "Select Start Date Year");
		Thread.sleep(3000);
		click(ElsevierObjects.SELECT_STARTDATE, "Selecting Start Date.");
		Thread.sleep(medium);
		click(ElsevierObjects.ORDER_SUBMIT_ENDDATE_CALENDER, "Clickin On End Date Calender.");
		Thread.sleep(medium);
		click(ElsevierObjects.CALENDER_TODAYSDATE, "Clicking on Todays Date In End Date Calender.");
		Thread.sleep(medium);
		click(ElsevierObjects.PREORDER_SEARCH_BUTTON, "Clicking On Search Button.");
		Thread.sleep(veryhigh);
		String errorMessage=getText(ElsevierObjects.PREORDER_ERRORMSSG, "Fetching Date Error Message");
		if(errorMessage != null){
			
			Reporters.SuccessReport("Should get an error message saying that 'From date should be prior to  To date", "Successfully Selected the From date later than To date And Cliked on search button.</br>Verified Error Message :"+errorMessage);
		}
			else{
			Reporters.failureReport("Should get an error message saying that 'From date should be prior to  To date", "Failed To Select the From date later than To date And Failed To click on search button.");
		}
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
	}
	return flag;
	
}

public static void searchOrderswithUsername(String username) throws Throwable {
	try
	{
	if(click(ElsevierObjects.EVOLVE_BUTTON, "click on the evolve button")){
		Reporters.SuccessReport("Clicking on Evolve Admin Link.", "Successfully Clicked On Evolve Admin Link.");
	}
	else{
		Reporters.failureReport("Clicking on Evolve Admin Link.", "Failed To Click On Evolve Admin Link.");
	}
	Thread.sleep(3000);
	searchPreOrder();
	type(ElsevierObjects.USERNAME_INPUT,username, "Enter UserName");
	Thread.sleep(3000);
	click(ElsevierObjects.PREORDER_SEARCH_BUTTON, "Clicking On Search Button.");
	Thread.sleep(3000);
}
	catch( Exception e){sgErrMsg="Failed to check the results"+e;}
}
public static void verifyTitleInEvolve(String Title,String noTitle) throws Throwable{
	try
	{
	if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
		flag=false;
	}
	Thread.sleep(4000);
	if(!click(ElsevierObjects.Kno_refresh_lnk,"Click on refresh link in evolve page")){
		flag=false;
	}
	Thread.sleep(4000);
	waitForVisibilityOfElement(ElsevierObjects.ONLINE_COURSE_LINK, "Course link");
	String titleineEvolve=getText(ElsevierObjects.ONLINE_COURSE_LINK, "Course link");
	if(titleineEvolve.contains(Title)){
		Reporters.SuccessReport("Verifying there is only one link  for Evolve Resource.", "Successfully Verified Title in My Evolve Page: "+titleineEvolve);
	}else{
		Reporters.failureReport("Verifying there is only one link  for Evolve Resource.", "Failed to Verify Title in My Evolve Page: "+titleineEvolve);
	}
	Thread.sleep(4000);
	if(!(driver.getPageSource()).contains(noTitle))
	{
		Reporters.SuccessReport("Verifying there is no link or placeholder for the "+noTitle+" as the item was cancelled in preorder status  not present in the page","Successfully Verified There Is no Link for the title : "+noTitle);
		
	}
	else 
	{
		Reporters.failureReport("Verifying there is no link or placeholder for the "+noTitle+" as the item was cancelled in preorder status  not present in the page","Failed To Verify link for title.");
	}
	
	
	Thread.sleep(4000);
}
	catch( Exception e){sgErrMsg="Failed to check the results"+e;}
	
}
public static boolean verifyISBNDetails(String Orderid,String ISBN,String OrderDate,String AvilabilityDate,String Status,String Username,String Packaged,String OriginalPrice,String DiscountedPrice,String PromotionDiscount,String AccessCode,String AccessCodeDiscount) throws Throwable
{
       try
       {
    	/*if(click(ElsevierObjects.EVOLVE_BUTTON, "")){
   			Reporters.SuccessReport("Clicking on Evolve Admin Link.", "Successfully Clicked On Evolve Admin Link.");
   		}
   		else{
   			Reporters.failureReport("Clicking on Evolve Admin Link.", "Failed To Click On Evolve Admin Link.");
   		}
   		Thread.sleep(3000);
   		searchPreOrder();*/
    	   
	   List <WebElement>totalrows=driver.findElements(By.xpath(".//*[@id='preOrderSearchResults']/table/tbody/tr"));
	   int flag=1;
	   for(int i=0;i<totalrows.size();i++)
	   {
	       String Orderid_Actual=totalrows.get(i).findElement(By.xpath(".//td[2]/span")).getText();
	      
	       if(Orderid_Actual.equalsIgnoreCase(Orderid))
	       {
	    	   
	       flag=0;
	       
	       String ISBN_Actual=totalrows.get(i).findElement(By.xpath(".//td[1]//a")).getText();
	    b=true;
	       CompareString(ISBN_Actual, ISBN, "ISBN value:");
	      
		   Calendar c = Calendar.getInstance();
		   Date d=c.getTime();
		   DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
			   
		   String CurrentDate=formatter.format(d);
	       
	       String OrderDate_Actual=totalrows.get(i).findElement(By.xpath(".//td[3]//span")).getText();
	       CompareString(OrderDate_Actual, CurrentDate, "Actual Date is:");
	     
	       
	       String AvilabilityDate_Actual=totalrows.get(i).findElement(By.xpath(".//td[4]//span")).getText();
	       
	       String s=AvilabilityDate;
	       SimpleDateFormat ft = new SimpleDateFormat("MM/dd/yyyy");
		   Date d1=new SimpleDateFormat("yyyyMMdd").parse(s);
		   String verifydate=ft.format(d1);
		   CompareString(AvilabilityDate_Actual, verifydate, "Actual Date is:");
	       
	       String Status_Actual=totalrows.get(i).findElement(By.xpath(".//td[5]//span")).getText();
	       CompareString(Status_Actual, Status, "Order Status");
	       
	       String Username_Actual=totalrows.get(i).findElement(By.xpath(".//td[6]//span")).getText();
	       CompareString(Username_Actual, Username,"Username");
	       
	       String Packaged_Actual=totalrows.get(i).findElement(By.xpath(".//td[7]//span")).getText();
	       CompareString(Packaged_Actual, Packaged,"Packaged Status");
	       
	       String OriginalPrice_Actual=totalrows.get(i).findElement(By.xpath(".//td[8]//span//div")).getText();
	       if(OriginalPrice_Actual.equals("-"))
	       {
	    	   OriginalPrice_Actual="0";
	    	   
	       }
	       double originalPriceInTable = Double.parseDouble(OriginalPrice_Actual);
	       
	       String modifiedOriginalPrice=OriginalPrice.replace("$", ""); 
	       double originalPrice= Double.parseDouble(modifiedOriginalPrice);
	       
	       CompareNumber(originalPriceInTable, originalPrice,"Order Price");
	       
	     
	       
	       String DiscountedPrice_Actual=totalrows.get(i).findElement(By.xpath(".//td[9]//span//div")).getText();
	       if(DiscountedPrice_Actual.equals("-"))
	       {
	    	   DiscountedPrice_Actual="0";
	    	   
	       }
	       double discountPriceInTable = Double.parseDouble(DiscountedPrice_Actual);
	       String modifiedDiscountPrice=DiscountedPrice.replace("$", "");
	       double discountPrice = Double.parseDouble(modifiedDiscountPrice);
	       CompareNumber(discountPriceInTable, discountPrice,"Discounted Price");
	       
	     /*  String PromotionDiscount_Actual=totalrows.get(i).findElement(By.xpath(".//td[10]//span//div")).getText();
	       CompareString(PromotionDiscount_Actual, PromotionDiscount,"Promotion Discount");*/
	       
	       String AccessCode_Actual=totalrows.get(i).findElement(By.xpath(".//td[11]//span")).getText();
	     
	     /*  if(AccessCode_Actual.equals("-"))
	       {
	    	   AccessCode_Actual="";
	       }*/
	       CompareString(AccessCode_Actual, AccessCode,"Access Code");
	       System.out.println("");
	       String AccessCodeDiscount_Actual=totalrows.get(i).findElement(By.xpath(".//td[12]//span//div")).getText();
	       CompareString(AccessCodeDiscount_Actual, AccessCodeDiscount,"Access Code Discount");
	       b=false;
	       }
	 }
      if(flag==1)
      {
         Reporters.failureReport("Order is not Avilable :"+Orderid, "Order  is not present in the Results");
         return false;

      }
      else{   return true;}
       }catch( Exception e){sgErrMsg="Failed to check the results"+e; return false;}
       
       
}


/*public static void verifyISBNDetails() throws Throwable{
	
	
	
	
}*/
}
