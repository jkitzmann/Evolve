package com.cigniti.automation.BusinessFunctions;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;
import com.thoughtworks.selenium.webdriven.commands.Click;

public class Promotion_CreatePromotionMarketingPageSinglePercentage_15582 extends EvolveCommonBussinessFunctions{
	

	public static boolean globalPromotionExclusions() throws Throwable
	{
		try

		{
			boolean flag = true;
			isElementPresent1(ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNTextBox, "ISBN Text box");
			type(ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNTextBox, isbnForFutureUse1, "Enter the ISBN :");
			Reporters.SuccessReport("Add ISBN : "+ isbnForFutureUse1+ "to the ISBN Text Box ", "ISBN : "+ isbnForFutureUse1+ " is added to the text box successfully");
			click(ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExclude, "Click on the Exclude Button");
			String sucMsg=getText(ElsevierObjects.marketingPageSinglePercentage_PrmPgeSucMsg, "");
			if(verifyText(ElsevierObjects.marketingPageSinglePercentage_PrmPgeSucMsg, "The Promotion Exclusion is successfully saved.", "The Success Message is Displayed")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
			}

			
			isElementPresent1(ElsevierObjects.marketingPageSinglePercentage_PrmPge_VerfyElement, "Exclude");
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}
	
	
	public static boolean ISBNExclude(String isbn) throws Throwable
	{
		try
		{
			boolean flag = true;
			//type(ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExcludeTxtBox, isbn, "");
			
			type(ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExcludeTxtBox, isbn, "Enter the ISBN to Exclude");
	
			Thread.sleep(medium);
			click(ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExludeBtn, "Click on the exclude button");
			/*String sucMsg=getText(ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExludeSucMsg, "");
			if(verifyText(ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExludeSucMsg, "The Promotion Exclusion is successfully saved. ", "The Promotion Exclusion is successfully saved.")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
			}*/
			Reporters.SuccessReport("ISBN Id : "+isbn+" is added to the ISBN Exclusion textbox", "ISBN Id : "+isbn+" is added to the ISBN Exclusion textbox <br> The ISBN now shows in the ISBN exclusion list to the right.");
			//isElementPresent(ElsevierObjects.marketingPageSinglePercentage_PrmPge_Verify, "Table Data", driver.getCurrentUrl());
			
			return flag;
		}catch(Exception e){
			sgErrMsg=e+" is Failed due to this exception";return false;}

	}
	
	/*else{
		if(user.equalsIgnoreCase("variablePercentage")){
			type(ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExcludeTxtBox, isbnForFutureUse2, "Enter the ISBN to Exclude");
			type(ElsevierObjects.Evolve_Admin_Prmlnk_ISBNpercent, percentage, "Enter the Percentage");
			click(ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExludeBtn, "Click on the exclude button");
			verifyText(ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExludeSucMsg, "The Promotion Exclusion is successfully saved. ", "The Promotion Exclusion is successfully saved.");
			
		}*/
	
	
	
}
