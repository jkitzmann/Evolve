package com.cigniti.automation.Test;



import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.ChangeRosterTitle_10440;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.SelfEnrollLOCourseHomePage_10302;
import com.cigniti.automation.BusinessFunctions.SelfEnrollLOCourseHomePage_10303;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class ChangeRosterTilte_script_10440 extends ChangeRosterTitle_10440
{

	@Test
	public static void changeRosterTitle_10440()throws Throwable
	{
		
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		CID=ReadingExcel.columnDataByHeaderName("CourseId","TC-15565",configProps.getProperty("TestData"));
		try
		{
			//==================Step1 and Step2=======================//
			CreateRosterforLOcourse_Byrosteredinstructor_Script_15565.createRosterforLOcourse_Byrosteredinstructor_15565();

			//====faculty user name and password from 15565======//
			rostered_facultyUserName=ReadingExcel.columnDataByHeaderName("roster_facultyUserName","TC-15565",testDataPath);
			rostered_facultyPassword=ReadingExcel.columnDataByHeaderName("roster_facultyPassword","TC-15565",testDataPath);

			//====student user name and password from 15565
			selfSUserName=ReadingExcel.columnDataByHeaderName("selfStudentUserName","TC-15565",testDataPath);
			selfSPassword=ReadingExcel.columnDataByHeaderName("selfStudentPassword","TC-15565",testDataPath);

			stepReport("Create new Student user and get details");
			launchUrl(configProps.getProperty("URL4"));
			EvolveCommonBussinessFunctions.CreateNewUser("STUDENT");
			Thread.sleep(low);
			newSName = EvolveCommonBussinessFunctions.credentials[0];
			newSPwd = EvolveCommonBussinessFunctions.credentials[1];

			writeReport(ChangeRosterTitle_10440.studentDetails(), "create new student and get the roster information from the 'CreateRosterforLOcourse_Byrosteredinstructor_Script_15565' ", 
					"Sucessfully created new student and his details are :</br>Student First Name   :   "+sFirstName+"</br>Student LastName   :   "+sLastName+"</br>Student Email   :   "+sEmail+" "+"and</br>New student username   :   "+newSName+"</br>new student password   :   "+newSPwd+"<br/>And The Roster Users details are :</br>RosterCourseID   :   "+CID+"<br/> rostered instructor's username   :   "+rostered_facultyUserName+"<br/> and rostered instructor's password   :   "+rostered_facultyPassword+"<br/>rostered student's username   :   "+selfSUserName+"<br/>rostered student's and password   :   "+selfSPassword, 
			"failed to create new student");
			Thread.sleep(low);
			System.out.println("New student details are::"+sFirstName+","+sLastName+","+sEmail+","+newSName+","+newSPwd);
			User_BusinessFunction.Logout();


			//=====Step3: Log into Evolve cert using Rostered instructor credentials=========//

			System.out.println("rostered faculty login details are::>>"+rostered_facultyUserName+","+rostered_facultyPassword);

			stepReport("Login to Evolve as instructor added to roster");
			if(User_BusinessFunction.Educatorlogin(rostered_facultyUserName,rostered_facultyPassword))

			{				
				Thread.sleep(high);
				isElementPresent(ElsevierObjects.Myevolve, "MyEvolve link");
				Reporters.SuccessReport("Log into evolvecert with the rostered instructor and verify the User in and is on the My Evolve tab.", "sucessfully Logged into evolve cert using rostered Instructor's credentials and verifies the presence of 'MyEvolve' tab:</br>Rostered Instructor userName   :   "+rostered_facultyUserName+"</br>Rostered Instructor password   :   "+rostered_facultyPassword);
			}
			else
			{
				Reporters.failureReport("Log into evolve cert with the rostered instructor and verify the User in and is on the My Evolve tab.", "Failed to verify that the User is log in");
			}
			b=true;
			click(ElsevierObjects.lnkmyevolve, "the 'MyEvolve' link");
			b=false;

			//==========Step4: Finding the courseID link which is associated with CourseID in step1=========//
			stepReport("Verify My Evolve includes the course and open it");
			verifyTitle(ReadingExcel.columnDataByHeaderName("TitleForEdit","TC-15565",testDataPath));

			//=========Step5: Editing the course Title and Saved it==============================//
			stepReport("Edit the title of the course");
			editTitle();

			//=======Step:6 to step:9 log into evolvecert.com with the self-enrolled student from step:1====//
			stepReport("Verify the newest student sees the new title");
			checkChangedCourseTitleInStudentPage();
			stepReport("Verify the instructor sees the new title");
			checkChangedCourseTitleInFacultyPage();

			//==Step:11 Log out of evolve cert.Using the course ID from this test case complete Step #2 - #10 of 'Self enroll into LO course through ecommerce - Home page'===\\
			stepReport("Create new Student user");
			if(SelfEnrollLOCourseHomePage_10303_Script.CreateNewUser("student"))
			{
				//=====step:2 from 'Self enrol into LO course through e-commerce - Home page' 
				String newStUserinSelf=EvolveCommonBussinessFunctions.credentials[0];
				String newStpwdinSelf=EvolveCommonBussinessFunctions.credentials[1];
				System.out.println("created student details from selfEnrollments are::<br/>StudentUserNmae>>>>>> "+newStUserinSelf+"<br/>Student Password>>>>>>>> "+newStpwdinSelf);
				
				Reporters.SuccessReport("Using courseID from this test case in<br/>'Self enroll into LO course through ecommerce - Home page'.<br/>And verify the new student is created and has been self-enrolled into this course","Using courseID from this test case complete Step #2 - #10 of the following test case:<br/>'Self enroll into LO course through ecommerce - Home page.<br/>and new student is created who has been self-enrolled into this course.<br/>His details are:<br/>StudentUserName: " +newStUserinSelf+"<br/>Student Password: " +newStpwdinSelf);
			}
			else
			{
				Reporters.failureReport("Using courseID from this test case in<br/>'Self enroll into LO course through ecommerce - Home page'.<br/>And verify the new student is created and has been self-enrolled into this course", "failed to verify the creation of new student and he enrolled into this course");
			}

			//====step:3 from 'Self enrol into LO course through e-commerce - Home page'
			stepReport("Enroll in course through course ID");
			EvolveCommonBussinessFunctions.verifyHoneyPot();

			//====Step:4 & 5:'Self enrol into LO course through e-commerce - Home page'.
			
			SelfEnrollLOCourseHomePage_10303.verifySearchNumber();
			
			SelfEnrollLOCourseHomePage_10302.selfEnrollNavigate(CID,SelfEnrollLOCourseHomePage_10303.ISBNPkg,COURSETITLE);

			//Step6 : On "My Cart" page, select the radio button to pay with credit card.  Press "Checkout".
			SelfEnrollLOCourseHomePage_10303.isbnInReceiptPage =SelfEnrollLOCourseHomePage_10303.ISBNPkg;
			//SelfEnrollLOCourseHomePage_10303.titleInReceiptPage ="Medical Terminology Online for Mastering Healthcare Terminology, 3rd Edition";
			titleInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chktitle,"Price in Receipt page");
			//System.out.println("Isbn and Title in the ReceiptPage are: <br/>isbn is:"+SelfEnrollLOCourseHomePage_10303.ISBNPkg+",br/>title is: "+titleInReceiptPage);
			stepReport("Verify contents of My Cart");
			SelfEnrollLOCourseHomePage_10303.verifyMyCart();


			String courseId="Course ID";
			SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentCourseInfo(CID, courseId);

			String Title="Title";
			SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentCourseInfo(newtitle,Title);

			stepReport("Submit order");
			SelfEnrollLOCourseHomePage_10303.verifyCheckout();

			//Step7&8 verify review/submit checkout, Address validation pop up
			EvolveCommonBussinessFunctions.updateVSTandKNOAccount("student","","false","");



			//Step 9 and 10:Enter credit card details , Review and Submit
			String creditCardType=ReadingExcel.columnDataByHeaderName("cardType", "TC-15597", configProps.getProperty("TestData"));
			String creditCardNum=ReadingExcel.columnDataByHeaderName("cardNumber", "TC-15597", configProps.getProperty("TestData"));
			String creditCardCvv=ReadingExcel.columnDataByHeaderName("cardCVV", "TC-15597", configProps.getProperty("TestData"));
			String creditCardName=ReadingExcel.columnDataByHeaderName("cardName", "TC-15597", configProps.getProperty("TestData"));
			String creditCardExpYr=ReadingExcel.columnDataByHeaderName("cardExpYear", "TC-15597", configProps.getProperty("TestData"));
			String creditCardExpMnth=ReadingExcel.columnDataByHeaderName("cardExpMonth", "TC-15597", configProps.getProperty("TestData"));

			SelfEnrollLOCourseHomePage_10303.creditCardData(creditCardType,creditCardNum,creditCardCvv,creditCardName,creditCardExpMnth,creditCardExpYr);
			Thread.sleep(veryhigh);

			SelfEnrollLOCourseHomePage_10303.StudentReviewandSubmit();
			Thread.sleep(veryhigh);

			EvolveCommonBussinessFunctions.courseID1 =CID;

			stepReport("Verify receipt page");
			SelfEnrollLOCourseHomePage_10303.verifyReceiptPage();

			//Step#11 & Step#12 Click on My evolve and check the course id appears under 0content list
			stepReport("Verify student can access course through My Evolve");
			if(SelfEnrollLOCourseHomePage_10303.verifyMyEvolveCourseId())
			{
				User_BusinessFunction.Logout();
				Reporters.SuccessReport("Verify the title of this course is changed or not","Sucessfully verifies title of this course is changed:<br/>And the changed Title is>>::" +newtitle.toString());
			}
			else
			{
				Reporters.failureReport("Verify the title of this course is changed or not","failed to verify the Changed Title");
			}

			//==Step#13 to Step#16 login as an instructor from step #1
			stepReport("Login as original instructor and submit roster");
			User_BusinessFunction.Educatorlogin(rostered_facultyUserName, rostered_facultyPassword);
			Thread.sleep(medium);
			EvolveCommonBussinessFunctions.getStundentIntoYourCourse();
			rostersubmission();
			Thread.sleep(high);

			//====Step#17 Log out of evolve cert and back in with the created student in Step #2====//
			stepReport("Login as new student and verify new title");
			stuRelogin();
			verifyTitle(ReadingExcel.columnDataByHeaderName("EditwithTitle","TC-15565",testDataPath));

		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
		}

	}
}
