package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.QuickEnrollfromPortalAdmin_15599;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;

public class QuickEnrollfromPortalAdmin_Script_15599 extends QuickEnrollfromPortalAdmin_15599 {
  @Test
  public void quickEnrollfromPortalAdmin_15599() throws Throwable {
	  SwitchToBrowser(ElsevierObjects.studentBrowserType);
	  CouId= ReadingExcel.columnDataByHeaderName("CourseId","TC-10438",configProps.getProperty("TestData"));
	  newstudentuser = ReadingExcel.columnDataByHeaderName("userName","TC-10438", configProps.getProperty("TestData"));
	  newstudentPassword =  ReadingExcel.columnDataByHeaderName("password","TC-10438", configProps.getProperty("TestData"));
	  newEmail = ReadingExcel.columnDataByHeaderName("Email","TC-10438", configProps.getProperty("TestData"));
	 
	  writeReport(QuickEnrollfromPortalAdmin_15599.AccountCreation(),"Create Roster Submission from within course and create new accounts for Student and faculty",
			                                                         "Created Roster Submission from within course and get courseID" +CouId+ "</br> RosterStudent Username is:" +newstudentuser+ "<br> Password is :"+newstudentPassword+
			                                                         "</br> Created two student users and 1st student details are :</br>Lastname :"+Lastname+"</br>Firstname : "+Firstname+"<br>EmailId :"+Email+"</br> Username:"+username+"</br> Password :"+Password+
			                                                         "</br> 2nd Student details are : </br> Lastname :"+sLastname+"</br>Firstname : "+sFirstname+"<br>EmailId :"+sEmail+"</br> Username:"+username1+"</br> Password :"+Password1+
			                                                         "</br> Faculty details are </br>Lastname :"+lastname+"</br>Firstname : "+firstname+"<br>EmailId :"+email+"</br> Username:"+username2+"</br> Password :"+Password2,
			                                                         "Failed to create Roster Submission from within course and create new accounts for Student and faculty");
	 
	  Thread.sleep(medium);
	  QuickEnrollfromPortalAdmin_15599.Rostercreation();
	  Thread.sleep(medium);
	  QuickEnrollfromPortalAdmin_15599.StudentEnroll();
	  Thread.sleep(medium);
	  QuickEnrollfromPortalAdmin_15599.FacultyEnroll();
	  Thread.sleep(medium);
	  QuickEnrollfromPortalAdmin_15599.UnEnroll();
	  Thread.sleep(medium);
	  QuickEnrollfromPortalAdmin_15599.StudentRelogin();
	  Thread.sleep(medium);
	  QuickEnrollfromPortalAdmin_15599.Studentlogin();
	  Thread.sleep(medium);
	  QuickEnrollfromPortalAdmin_15599.FacultyRelogin();
	  Thread.sleep(medium);
	  QuickEnrollfromPortalAdmin_15599.newuserRelogin();
	  
	  
  }
}
