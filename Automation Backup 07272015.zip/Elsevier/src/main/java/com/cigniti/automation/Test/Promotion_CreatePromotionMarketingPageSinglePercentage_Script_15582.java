package com.cigniti.automation.Test;

import java.util.Random;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.Promotion_CreatePromotionMarketingPageSinglePercentage_15582;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class Promotion_CreatePromotionMarketingPageSinglePercentage_Script_15582 extends Promotion_CreatePromotionMarketingPageSinglePercentage_15582{

	Random ra = new Random( System.currentTimeMillis() );
	//public static String DMCodeFinal;
	@Test
	public void createPromotionMarketingPageSinglePercentage_15582() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			//ElsevierObjects.adminBrowserType="firefox";
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String DMCodeFinal=ReadingExcel.columnDataByHeaderName("DMcode", "PromotionTestData",configProps.getProperty("TestData"))+Integer.toString((1 + ra.nextInt(2)) * 100000 + ra.nextInt(100000));
			String PromotionCode=ReadingExcel.columnDataByHeaderName("PromotionCode", "PromotionTestData",configProps.getProperty("TestData"));
			String DiscountType1=ReadingExcel.columnDataByHeaderName("DiscountType1", "PromotionTestData",configProps.getProperty("TestData"));
			String CampaignCode=ReadingExcel.columnDataByHeaderName("CampaignCode", "PromotionTestData",configProps.getProperty("TestData"));
			String PromotionName=ReadingExcel.columnDataByHeaderName("PromotionName", "PromotionTestData",configProps.getProperty("TestData"));
			String TerritoryCode=ReadingExcel.columnDataByHeaderName("TerritoryCode", "PromotionTestData",configProps.getProperty("TestData"));
			String percentageOff=ReadingExcel.columnDataByHeaderName("PercentageOff", "PromotionTestData",configProps.getProperty("TestData"));
			String percentageOff1=ReadingExcel.columnDataByHeaderName("PercentageOff1", "PromotionTestData",configProps.getProperty("TestData"));
			String invalidPercentage=ReadingExcel.columnDataByHeaderName("invalidPercentage", "PromotionTestData",configProps.getProperty("TestData"));
			String percentage=ReadingExcel.columnDataByHeaderName("percentage", "PromotionTestData",configProps.getProperty("TestData"));		
			String healthNursing=ReadingExcel.columnDataByHeaderName("SearchProduct", "PromotionTestData", testDataPath);
			//String percentageCDROM=ReadingExcel.columnDataByHeaderName("percentageCDROM", "TC-15582", testDataPath);
			
			writeReport(User_BusinessFunction.Studentlogin(sStudentUser, sStudentPassword),"Login to Application Using Student User Credentials : "+sStudentUser,
                    "Launching the URL for Student User is successful </br > Login to Application Using Student User credentails :"+sStudentUser+" is Successful",
                       "Launching and Login to Application Using Student User credentails : "+ sStudentUser+" is Failed");
			Thread.sleep(medium);
			writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as Student User",
                    "Navigating to CATALOG page is Successful",
                    "Navigating to CATALOG Page is failed");
			Thread.sleep(medium);
			writeReport(productSearch(healthNursing),"Searching for Value:"+healthNursing,
                      "Searching for "+healthNursing+" is Successful ",
                      "Unable to Search for : "+ healthNursing+ " hence search results failed");
			Thread.sleep(medium);
			writeReport(clickDVDHardcover(),"Filter by DVD and Hardcover Product Types",
            "Successfully Filtered the DVD Product type and HardCover product type on the page ",
            "Failed to Filter the DVD Product type and HardCover product type on the page  ");
		
			writeReport(productClick(), "Verifying the Captured ISBNs", "Verifying the Captured ISBNs are unique All the ISBNs captured are unique <br>There are no duplicates", "The Captured ISBNs are not unique  <br>There are duplicates");
			
			/*writeReport(productClick(),"Click on the DVD Product's and <br>Navigate to the Next Page and Verify the presence of ADD TO CART button",
                    "Successfully Clicked on the DVD Product and  <br>Navigate to the Next Page and Verify the presence of ADD TO CART button </br > Click on the First DVD Product",
                    "Unable to Click on the Product DVD element ");*/
			
			Thread.sleep(medium);
			//SwitchToBrowser(ElsevierObjects.adminBrowserType);
			writeReport(evolveAdminlogin(),"Login to Application Using Admin Credentials :"+adminUser,
                    "Launching the URL for Admin Credentials is successful </br > Login to Application Using Admin Credentials :"+adminUser+" is Successful",
                       "Launching and Login to Application Using Admin Credentials : "+ adminUser+" is Failed");
			
			Thread.sleep(medium);
			checkPromotionLink();
			Thread.sleep(medium);
			String isbn=isbnForFutureUse1;
			String isbn2=isbnForFutureUse2;
			String isbn4=isbnForFutureUse4;
			ISBNExcludeGlobalPromotion(isbn);
			Thread.sleep(medium);
			click(ElsevierObjects.marketingPageSinglePercentage_PrmPge_EvlAdmnLnk, "Click on the Evolve Admin Bread Crumb");
			Thread.sleep(medium);
			addPromotionLink();
			Thread.sleep(medium);
			
			String user="singlePercentage";
			writeReport(inputValuesInPromotionCode(user,DMCodeFinal, "", "", DiscountType1, "", PromotionName, TerritoryCode, percentageOff),  
					"Fill all the mandatory fields in Promotion Type under Add Promotion", 
					"Details are filled successfully: DM Code : "+DMCodeFinal+"<br> Discount Type : "+user+ "<br> Promotion Name : "+PromotionName+"<br> Territory Code : "+TerritoryCode+"<br> Promotion Name : "+percentageOff+"<br> Promotion successfully saved. ",
					"Failed to fill Details : DM Code : "+DMCodeFinal+"<br> Discount Type : "+user+ "<br> Promotion Name : "+PromotionName+"<br> Territory Code : "+TerritoryCode+"<br> Promotion Name : "+percentageOff+"<br> Promotion successfully saved. ");
			Thread.sleep(medium);
			String percentageDVD=null;
			writeReport(globalPromotionDVD(user, percentageDVD),  
					"Select the DVD product type", 
					"DVD Product type is selected successful </br>and Validated by checking for the product added to the right side in a table", 
					"DVD Product type is not selected successful");
			
			ISBNExclude(isbn2);
			
			Thread.sleep(medium);
			//String user1="variablePercentage";
			writeReport(viewMarketingPage(),  
					"View Marketing Page link is successfully clicked and navigated to the next page", 
					"View Marketing Page link is successfully clicked and navigated to the next page </br> Bread Crumb is present", 
					"View Marketing Page link is failed to click on the link </br> Bread Crumb is not present");
			Thread.sleep(medium);
			writeReport(detailsForFutureUse(),  
					"Details are stored for future use", 
					"The unique URL is : "+uniqueUrl+"<br>Details ISBN, Title and Price for 4 items are successfully saved for future use </br> DM Code is : "+DMCodeFinal+"</br>"
					+"</br> The Titles are : "+titleforfutureuse1+ "</br>"+titleforfutureuse2 + "</br>"+titleforfutureuse3 + "</br>"+titleforfutureuse4 
					+"ISBNs are : "+isbnForFutureUse1+ "," +isbnForFutureUse2+"," +isbnForFutureUse3+","+isbnForFutureUse4
					+ "</br>"+priceforfutureuse1+"," +priceforfutureuse2 +"," +priceforfutureuse3 +"," +priceforfutureuse4, 
					"Details ISBN, Title and Price for 4 items are failed to save for future use");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
