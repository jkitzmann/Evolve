package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.FraudTestCases_Lib;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentFaculty_15243;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class TC_17129_ORDER_2 extends FraudTestCases_Lib{
	@Test
	public void tc17129_ORDER_2() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		EvolveCommonBussinessFunctions.SwitchToBrowser(ElsevierObjects.adminBrowserType);
		
		String sUserName = ReadingExcel.columnDataByHeaderName("DynamicStudentUsername", "FraudTestCases", testDataPath);
		String sPassword = ReadingExcel.columnDataByHeaderName("DynamicUserPassword", "FraudTestCases", testDataPath);
		String sISBN1 = ReadingExcel.columnDataByHeaderName("ISBN1", "FraudTestCases", testDataPath);
		String sISBN2 = ReadingExcel.columnDataByHeaderName("ISBN2", "FraudTestCases", testDataPath);
		String sISBN3 = ReadingExcel.columnDataByHeaderName("ISBN3", "FraudTestCases", testDataPath);
		String sISBN4 = ReadingExcel.columnDataByHeaderName("ISBN4", "FraudTestCases", testDataPath);
		String ISBN1Price = ReadingExcel.columnDataByHeaderName("ISBN1Price", "FraudTestCases", testDataPath);
		String ISBN2Price = ReadingExcel.columnDataByHeaderName("ISBN2Price", "FraudTestCases", testDataPath);
		String ISBN3Price = ReadingExcel.columnDataByHeaderName("ISBN3Price", "FraudTestCases", testDataPath);
		
/*		String InstCountry = ReadingExcel.columnDataByHeaderName("InstCountry", "FraudTestCases", testDataPath);
		String InstState = ReadingExcel.columnDataByHeaderName("InstState", "FraudTestCases", testDataPath);
		String InstCity = ReadingExcel.columnDataByHeaderName("InstCity", "FraudTestCases", testDataPath);
		String InstName = ReadingExcel.columnDataByHeaderName("InstName", "FraudTestCases", testDataPath);
		String ProgramType = ReadingExcel.columnDataByHeaderName("ProgramType", "FraudTestCases", testDataPath);
		
		String Year = ReadingExcel.columnDataByHeaderName("Year", "FraudTestCases", testDataPath);
		String ShipStreet = ReadingExcel.columnDataByHeaderName("ShipStreet", "FraudTestCases", testDataPath);
		String ShipCity = ReadingExcel.columnDataByHeaderName("ShipCity", "FraudTestCases", testDataPath);
		String ShipState = ReadingExcel.columnDataByHeaderName("ShipState", "FraudTestCases", testDataPath);
		String ShipZIP = ReadingExcel.columnDataByHeaderName("ShipZIP", "FraudTestCases", testDataPath);
	
		String BillStreet = ReadingExcel.columnDataByHeaderName("BillStreet", "FraudTestCases", testDataPath);
		String BillCity = ReadingExcel.columnDataByHeaderName("BillCity", "FraudTestCases", testDataPath);
		String BillState = ReadingExcel.columnDataByHeaderName("BillState", "FraudTestCases", testDataPath);
		String BillZip = ReadingExcel.columnDataByHeaderName("BillZip", "FraudTestCases", testDataPath);*/
		
		String creditCardType=ReadingExcel.columnDataByHeaderName("CCType", "FraudTestCases", testDataPath);
		String creditCardNum=ReadingExcel.columnDataByHeaderName("CC", "FraudTestCases", testDataPath);
		String creditCardCvv=ReadingExcel.columnDataByHeaderName("CVV", "FraudTestCases", testDataPath);
		String creditCardName=ReadingExcel.columnDataByHeaderName("CCUser", "FraudTestCases", testDataPath);
		String creditCardExpYr=ReadingExcel.columnDataByHeaderName("CCYear", "FraudTestCases", testDataPath);
		String creditCardExpMnth=ReadingExcel.columnDataByHeaderName("CCMonth", "FraudTestCases", testDataPath);	
		int col=35;		
			
		stepReport("Launch the URL : "+configProps.getProperty("URL4"));
		if(launchUrl(configProps.getProperty("URL4"))){
			Reporters.SuccessReport("Launch the URL "+configProps.getProperty("URL4"), "Successfully Launched URL "+configProps.getProperty("URL4"));
		}else{
			Reporters.failureReport("Launch the URL "+configProps.getProperty("URL4"), "Failed to Launch URL "+configProps.getProperty("URL4"));
		}
		
		stepReport("Login into the Application as Student User");
		evolveLogin(sUserName, sPassword);
		evolveCatalogClick();
		
		stepReport("Search for the ISBN : "+sISBN1+" from the catalog page, add the product to the cart and validate the price");
		searchAndAddProductFromCartSearch(sISBN1, "Add to cart");
		validateProductinCart(sISBN1);
		comparePriceinCart("",sISBN1,ISBN1Price);
		
		stepReport("Search for the ISBN "+sISBN2+" search text box displayed in the header of 'My Cart' screen and Validate the price");
		searchAndAddProductFromCartSearch(sISBN2, "Add to cart");
		comparePriceinCart("",sISBN2,ISBN2Price);
		
		stepReport("Search for the ISBN "+sISBN3+" search text box displayed in the header of 'My Cart' screen and Validate the price");
		searchAndAddProductFromCartSearch(sISBN3, "Pre-order");
		comparePriceinCart("preorder",sISBN3,ISBN3Price);
		
		stepReport("Search for the ISBN "+sISBN4+" search text box displayed in the header of 'My Cart' screen and Validate the price");
		searchAndAddProductFromCartSearch(sISBN4, "Register");
		comparePriceinCart("equals",sISBN4,ISBN3Price);
		checkout();
		//instituteAddress(InstCountry, InstState, InstCity, InstName, ProgramType, Year);
		//shippingAddress(ShipStreet, ShipCity, ShipState, ShipZIP);
		//billingAddress(BillStreet, BillCity, BillState, BillZip);
		//profileSubmit();
		//submitOrder();
		stepReport("Submit the order");
		creditCardData(creditCardType,creditCardNum,creditCardCvv,creditCardName,creditCardExpMnth,creditCardExpYr);
		submit();
		
		stepReport("Capture the ordernumber and save it for future use");
		orderNumber(col);
		Thread.sleep(2000);
		
		stepReport("Logout from the evolve user");
		evolveLogout();
		
		stepReport("Email verification ");
		if(EvolveCommonBussinessFunctions.emailLogin()){
			Reporters.SuccessReport("Login into the EvolveQA Mail", "Successfully logged into the EvolveQA mail");
		}

		LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(StdEmail);
		
		getEmailBody();
		
		
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
