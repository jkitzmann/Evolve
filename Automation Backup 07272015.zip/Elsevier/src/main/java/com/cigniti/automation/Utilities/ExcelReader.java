package com.cigniti.automation.Utilities;

import java.io.File;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader

{
	FileInputStream inpFile;
	File file;
	HSSFWorkbook hssfWorkbook;
	XSSFWorkbook xssfWorkbook;
	Sheet sheet = null;
	String workbookName;
	String sheetName;
	int sheetNo;

	HashMap<String, Integer> colIndex = new HashMap<String, Integer>();

	public ExcelReader(String workbookName, String sheetName, int sheetNo) {
		this.workbookName = workbookName;
		this.sheetName = sheetName;
		this.sheetNo = sheetNo;

	}

	/*public static void main(String[] args) {

		ExcelReader ereader = new ExcelReader("C:\\Users\\IN00462\\Desktop\\data-source.xlsx", "Scenario5", 4);
		
		System.out.println(ereader.getClass());
		
		
		ereader.getColData("Assert Text Present", 1);
	}*/

	public void readData() {

		try {

			inpFile = new FileInputStream(workbookName);
			file = new File(workbookName);

			if (file.getCanonicalPath().endsWith(".xls")) {
				/*
				 * Get the workbook instance for XLS file. Get sheet from the
				 * workbook
				 */

				hssfWorkbook = new HSSFWorkbook(inpFile);
				sheet = hssfWorkbook.getSheet(sheetName);

			} else if (file.getCanonicalPath().endsWith(".xlsx")) {
				/*
				 * Get the workbook instance for XLSX file. Get sheet from the
				 * workbook
				 */
				xssfWorkbook = new XSSFWorkbook(inpFile);
				sheet = xssfWorkbook.getSheetAt(sheetNo);

			}

			} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	
	public String getColData(String colName, int rowno) {
		readData();	
		Row row = null;
		Cell cell = null;
		List colData = new ArrayList();
		int colNo = 0 ;
		int noOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
		//System.out.println("Index is "+noOfColumns);
		
		
		for(int i=0;i<noOfColumns;i++)
		{
			row = sheet.getRow(0);

			cell = row.getCell(i);
			
			if(cell.toString().equalsIgnoreCase(colName))
			{
				colNo=i;
				break;
			}
		}
	
		try {

			row = sheet.getRow(rowno);

			cell = row.getCell(colNo);
			if (cell != null) {
				
				//System.out.println(cell.getStringCellValue());
				return cell.getStringCellValue();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cell.getStringCellValue();
	}

	
}