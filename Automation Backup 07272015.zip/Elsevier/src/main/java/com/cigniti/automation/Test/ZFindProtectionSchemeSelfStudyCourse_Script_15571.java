package com.cigniti.automation.Test;

import java.util.Random;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.ZFindProtectionSchemeSelfStudyCourse_15571;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class ZFindProtectionSchemeSelfStudyCourse_Script_15571 extends ZFindProtectionSchemeSelfStudyCourse_15571{

	Random ra = new Random( System.currentTimeMillis() );
	@Test
	public void findProtectionSchemeSelfStudyCourse_15571(String courseID, String user) throws Throwable
	{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		

		ZFindProtectionSchemeSelfStudyCourse_15571.loginEcertAdminPortal();
		Thread.sleep(medium);
		writeReport(ZFindProtectionSchemeSelfStudyCourse_15571.protectionSchemeSelfStudyCourse(courseID,user), "Find protection scheme for self study course", 
				"Find protection scheme for self study course and Capture it for future use is successfull",
				"Find protection scheme for self study course and Capture it for future use is failed");

	}	
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
