package com.cigniti.automation.BusinessFunctions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;


public class SelfEnrollLOCourseHomePage_10302 extends EvolveCommonBussinessFunctions{
		
	//Click on the Access Code Package link and verify	
	public static String ISBNPkg;
	public static boolean selfEnrollLO() throws Throwable{
		boolean flag = true;
		Thread.sleep(medium);
		driver.manage().deleteAllCookies();
		if(!launchUrl(configProps.getProperty("URL"))){
			flag = false;
		}
		driver.manage().deleteAllCookies();
		driver.navigate().refresh();
		Thread.sleep(medium);
		if(!click(ElsevierObjects.home_student_lnkstudent,"i am student")){
			 flag=false;
		}
		
		return flag;
	}
	
	public static boolean verifySearchNumber() throws Throwable{
		boolean flag = true;
		ISBNPkg="";
		ReadingExcel re =new ReadingExcel();
		ISBNPkg =re.columnDataByHeaderName("searchNumber", "TC-10410", configProps.getProperty("TestData"));
		
		if(ISBNPkg == ""){
			Thread.sleep(medium);
			flag = false;
		}
		
		return flag;
	}
	public static boolean EvolveBreadCrumb() throws Throwable{
		boolean flag=true;
		try{
		//click on My evolve link 
		if(click(ElsevierObjects.EvolveAdmin, "Click on Evolve Admin link")){
			Reporters.SuccessReport("Clicking On Evolve Admin Link In Bread Crumb.", "Successfully Clicked On Evolve Admin Link In Bread Crumb. ");
		}
		else{
			Reporters.failureReport("Clicking On Evolve Admin Link In Bread Crumb.", "Failed TO Clicki On Evolve Admin Link In Bread Crumb.");
		}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	public static boolean selfEnrollNavigate(String courseid, String isbn, String title) throws Throwable{
		boolean flag = true;
		
		if(type(ElsevierObjects.enrollResourceId, courseid, "Input Course Id ")){
			Reporters.SuccessReport("Entering CourseID in Enroll TextBox.", "Entered CourseID "+courseid+" in Enroll TextBox.");
		}
		else{
			Reporters.failureReport("Entering CourseID in Enroll TextBox.", "Failed To Enter CourseID "+courseid+" in Enroll TextBox.");
		}	
		
		Thread.sleep(high);
		if(click(ElsevierObjects.enrollContinue, "Click on Continue Button")){
			Reporters.SuccessReport("Clicking On Submit Button After Entering CourseID.", "Successfully Clicked On Submit Button.</br>Navigated To Mycart Page.");
		}
		else{
			Reporters.failureReport("Clicking On Submit Button After Entering CourseID.", "Failed To Click On Submit Button.</br>Failed To Navigate To Mycart Page.");
		}
		Thread.sleep(medium);
		
		return flag;
	}
	
	public static boolean verifyCheckout() throws Throwable{
		boolean flag=true;
		
		if(!click(ElsevierObjects.btnRedeem,"Click on My Cart checkout Button")){
			flag=false;
		}
		Thread.sleep(medium);

		return flag;
	}
	
	public static boolean verifyMyEvolveCourseId() throws Throwable{
		boolean flag=true;
		
		if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
			flag=false;
		}
		Thread.sleep(high);
		
		if(!click(ElsevierObjects.Kno_refresh_lnk,"Click on refresh content list")){
			flag=false;
		}
		Thread.sleep(medium);
		
		
		if(!click(ElsevierObjects.educator_courseSearch_title,"Click on COurse Title.")){
			flag=false;
		}
		Thread.sleep(medium);

		return flag;
	}
	
	public static boolean verifyCoursePage() throws Throwable{
		boolean flag=true;
		
		//click on course content list in course page
		if(!click(ElsevierObjects.educator_CoursePage_Courselink, "Click on course link present in course details page.")){
			flag=false;
		}
		Thread.sleep(medium);
		
		
		//check for subfolders
		if(!waitForElementPresent(ElsevierObjects.educator_CoursePage_SubFolders, "Course folder contains sub folders.")){
					flag=false;
				}
				Thread.sleep(medium);

				return flag;
	}
	
	public static boolean verifyMyEvolveAdmin(String courseid) throws Throwable{
		boolean flag=true;
		
		//click on My evolve link 
		if(!click(ElsevierObjects.Admin_Evolve_lnk, "Click on Evolve Admin link")){
			flag = false;
		}
		Thread.sleep(medium);
		
		//click on View Edit User Profile link 
		if(!click(ElsevierObjects.Admin_ViewEdit_UserProfile, "Click on View/Edit Evolve User PRofile")){
			flag = false;
		}
		Thread.sleep(medium);
		
		
		Map<String, String> values=readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData"));
		String userName=values.get("UserName");
		if(!type(ElsevierObjects.Admin_SearchUser_UserName, userName, "Input UserNamed ")){
			Thread.sleep(medium);
			flag = false;
		}
		Thread.sleep(medium);
		
		if(!click(ElsevierObjects.Admin_SearchUser_SearchButton, "Click on Search Button")){
			flag = false;
		}
		Thread.sleep(medium);
		
		if(!click(ElsevierObjects.Admin_CourseParReport_Search_Results_Row2, "Click on Search Results")){
			flag = false;
		}
		Thread.sleep(medium);
		if(!click(ElsevierObjects.parBtn, "Click on Search Results")){
			flag = false;
		}
		Thread.sleep(medium);
		
		//check for courseid
		if(!selectByVisibleText(ElsevierObjects.enrollCourseId,courseid ,"Check Course id Exists")){
					flag=false;
				}
				Thread.sleep(medium);

				return flag;
	}
	
	
	public static boolean productSearchResultPage(String isbn) throws Throwable{
		boolean flag = true;
		if(click(ElsevierObjects.MaintainPrdct_prdctSerachReslut_isbn,"Click on isbn num in product result page")){
		    Reporters.SuccessReport("Clicking On ISBN In Product Search Result Page.", "Successfully Clicked On ISBN "+isbn+" In Product Search Result Page.");
		   }
		   else{
		    Reporters.failureReport("Clicking On ISBN In Product Search Result Page.","Failed To Click On ISBN In Product Search Result Page.");
		   }
		Thread.sleep(medium);
		return flag;
	}
	
	public static boolean verifySchemeIdAndCreateAccessCode() throws Throwable{
		  boolean flag=true;
		  try{
		   if(click(ElsevierObjects.createAccessCode, "Click on create access code")){
			   Reporters.SuccessReport("Clicking On Create AccessCode Link.", "Successfully Clicked On Create access code link.");
		   }
		   else{
		    Reporters.failureReport("Clicking On Create AccessCode Link.", "Failed To Click On Create access code link.");
		   }
		    Thread.sleep(medium);
		    String schemeID=getText(ElsevierObjects.createAccessCodeSchemeID, "");
		    if(protectionSchemeID.trim().equals(schemeID.trim())){
		    	 Reporters.SuccessReport("Verifying Scheme ID.", "Successfully Verified Scheme ID:The SchemeId in Admin Is:"+schemeID+",Protection Scheme Id Fetched From LO:"+protectionSchemeID);
		    	 Random ra = new Random( System.currentTimeMillis() );
		    	 String CodeSetName = readcolumns.twoColumns(0, 1, "Tc-15228", configProps.getProperty("TestData")).get("CodeSetName")+Integer.toString((1 + ra.nextInt(2)) * 100 + ra.nextInt(10000));
			   	 //ReadingExcel.updateCellValue(2, 1, configProps.getProperty("TestData"), 17);
			   	 if(type(ElsevierObjects.CreateAccessCode_codesetname, CodeSetName , "Code set name")){
					  Reporters.SuccessReport("Entering Code Set Name To Create AccessCodes.", "Successfully Entered CodeSet Name:"+CodeSetName+" Code Set Name Text Box.");
				  }
			   	 else{
			   		 Reporters.failureReport("Entering Code Set Name To Create AccessCodes.", "Failed To Enter Code Set Name:"+CodeSetName+" in Code Set Name Text Box.");
			   	 }
			   	 Thread.sleep(medium);
			   	 String codeSetNum=readcolumns.twoColumns(0, 1, "Tc-15228", configProps.getProperty("TestData")).get("newCodeSetNumber");
			   	 if(type(ElsevierObjects.CreateAccessCode_codeNumber,codeSetNum , "Code set number")){
			   		 Reporters.SuccessReport("Entering Code Set Number To Create AccessCodes.", "Successfully Entered CodeSet Number:"+codeSetNum+" Code Set Number Text Box.");
				  }
			   	 else{
			   		 Reporters.failureReport("Entering Code Set Number To Create AccessCodes.", "Failed To Enter Code Set Number:"+codeSetNum+" in Code Set Number Text Box.");
			   	 }
			   	 Thread.sleep(medium);
			   	 if(click(ElsevierObjects.CreateAccessCode_Submit, "Click on Create access code submit button")){
			   		 Reporters.SuccessReport("Clicking On Save Button To Create AccessCode.", "Successfully Clicked On Save Button.");
			   	 }
			   	 else{
				  	Reporters.failureReport("Clicking On Save Button To Create AccessCode.", "Failed To Click On Save Button.");
		   	
			   	 }
			   	 Thread.sleep(high);
		    }
		  
		   ImplicitWait();
		  }
		  catch(Exception e){
			   System.out.println(e.getMessage());
			  }
			  return flag;
			 }
	public static boolean  verifyTextPresent(String text) throws Throwable{  
		boolean flag=false;
		String bool=configProps.getProperty("OnSuccessReports");
		boolean b=Boolean.parseBoolean(bool);
		if(!(driver.getPageSource()).contains(text))
		{
		
			Reporters.SuccessReport("VerifyTextPresent",text+" is not present in the page");
			flag= true;
		}
		else if(b && flag)
		{
			Reporters.failureReport("VerifyTextPresent",text+" is present in the page");
			flag= false;
			
		}
		return flag;
	}

}
