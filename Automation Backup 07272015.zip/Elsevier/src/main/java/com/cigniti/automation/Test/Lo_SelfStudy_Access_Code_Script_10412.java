package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;










import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.LO_Selfstudy_Access_Code_10412_Bussiness_Function;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class Lo_SelfStudy_Access_Code_Script_10412 extends LO_Selfstudy_Access_Code_10412_Bussiness_Function{

	@Test
	public void lo_SelfStudy_AccessCode_10412() throws Throwable{
		
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		//ElsevierObjects.browserType ="Firefox";
		String isbn=ReadingExcel.columnDataByHeaderName("isbn", "TC-10412", testDataPath);
		String courseID=ReadingExcel.columnDataByHeaderName("courseID", "TC-10412", testDataPath);
		String protectionSchemeid=ReadingExcel.columnDataByHeaderName("protectionScheme", "TC-10412", testDataPath);
		
		//String courseID=ReadingExcel.columnDataByHeaderName("courseID", "TC-15571",configProps.getProperty("TestData"));
		stepReport("Get course protection scheme from Evolve Portal Admin");
		ZFindProtectionSchemeSelfStudyCourse_Script_15571 zFind = new ZFindProtectionSchemeSelfStudyCourse_Script_15571();
		zFind.findProtectionSchemeSelfStudyCourse_15571(courseID,"loSelfStudy");
		
		System.out.println("Protection Scheme==>"+protectionSchemeID);
		
		protectionScheme =protectionSchemeid;
		
		stepReport("Login to Evolve Admin and create access code");
		adminLogin();
		
		createAccessCode();
		
		stepReport("Create new student user");
		launchUrl(configProps.getProperty("URL4"));
		//launchUrl("https://evolvecert.elsevier.com/cs/store?role=student");
		if(CreateNewUser(ElsevierObjects.STUDENT))
		{
			Reporters.SuccessReport("Create New Student user and log into the application", "Successfully Created new student user with the credentials : <br> Username : "+credentials[0]+"<br> Password : "+credentials[1]+" <br>Successfully logged in as New Student user");
		}
		else
		{
			Reporters.failureReport("Create New Student user and log into the application", "Failed to login as New Student user");
		}
		String studentUserName = EvolveCommonBussinessFunctions.credentials[0];
		String studentPasswrod = EvolveCommonBussinessFunctions.credentials[1];
		
		System.out.println(studentUserName +","+ studentPasswrod);
		
		//User_BusinessFunction.Studentlogin("nuser2536", "bac")
		
		stepReport("Search for course and add to cart");
		searchISBNNumber(isbn);

		stepReport("Enter access code and submit order");
		enterAccessCode(isbn,true);
		
		stepReport("Verify course link and content");
		evolveCatalog(isbn, courseID);
		
		stepReport("Login to Evolve Admin");
		adminLogin();
		
		stepReport("Verify student's PAR report");
		coursePARReport(courseID, studentUserName);
		
		stepReport("Verify the access code can no longer be used");
		launchUrl(configProps.getProperty("URL4"));
		
		searchISBNNumber(isbn);

		enterAccessCode(isbn,false);
	}

	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
