package com.cigniti.automation.Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EComm_Preorde_MyEvolve_Page15594_BussinessFunctions;
import com.cigniti.automation.BusinessFunctions.ECommercePackagependingcourseid_15461;
import com.cigniti.automation.BusinessFunctions.Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;
import com.cigniti.automation.datadriven.ReadResourceData;

public class ECommercePackagependingcourseid_15461_Script extends ECommercePackagependingcourseid_15461{
	@Test
	public void eCommercePackagependingcourseid_15461() throws Throwable
	{
	try{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		String streetAddress=ReadingExcel.columnDataByHeaderName("StreetAddress","TC-15588",configProps.getProperty("TestData"));
		String zip=ReadingExcel.columnDataByHeaderName("ZipCode","TC-15588",configProps.getProperty("TestData"));
		String cityAddress=ReadingExcel.columnDataByHeaderName("CityAddress", "TC-15588",configProps.getProperty("TestData"));
		String stateAddress=ReadingExcel.columnDataByHeaderName("StateAddress","TC-15588",configProps.getProperty("TestData"));
		
		String isbn1=ReadingExcel.columnDataByHeaderName("ISBN1", "TC-15461", testDataPath);
		String isbn2=ReadingExcel.columnDataByHeaderName("ISBN2", "TC-15461", testDataPath);
		String discount1=ReadingExcel.columnDataByHeaderName("Discount1", "TC-15461", testDataPath);
		String discount2=ReadingExcel.columnDataByHeaderName("Discount2", "TC-15461", testDataPath);
		String product=ReadingExcel.columnDataByHeaderName("ProductID", "TC-15461", testDataPath);
		String discountType=ReadingExcel.columnDataByHeaderName("DiscountType1", "TC-15461", testDataPath);
		String course1=ReadingExcel.columnDataByHeaderName("course1", "TC-15461", testDataPath);
		String course2=ReadingExcel.columnDataByHeaderName("course2", "TC-15461", testDataPath);
				
		stepReport("Login to Evolve Admin");
		writeReport(evolveAdminlogin(),"Login to Application Using User Credentials"+adminUser,
                "Launching the URL for User is successful </br > Login to Application Using User credentails :"+adminUser+" is Successful",
                   "Launching and Login to Application Using User credentails : "+ adminUser+" is Failed");
		
		stepReport("Verify UI of the add ecom package page");
		verifyEcommerceLink();
		
		stepReport("Create and save the package details");
		if(inputPackageData()){
     		Reporters.SuccessReport("Input the Package Data", "The data is correctly entered into the fields");
		}else{			
			Reporters.failureReport("Input the Package Data", "The data is Not correctly entered into the fields");
		}
		
		stepReport("Add ISBNs to the package");
		isbnEntry( isbn1, discountType, discount1);
		ImplicitWait();
		Thread.sleep(medium);
		isbnEntry( isbn2, discountType, discount2);
		ImplicitWait();
		Thread.sleep(medium);
				
		stepReport("Add specific product type discount through Cross Promotions tab");
		if(crossPromotionTab()){
     		Reporters.SuccessReport("Validating Cross Promotion Tab", "Successfully clicked on the Cross promotion tab and added the data to the table");
		}else{
			Reporters.failureReport("Validating Cross Promotion Tab", "failed to click on the Cross promotion tab and failed to add the data to the table");
		}
		
		stepReport("Create marketing page for the package");
		if(marketingPageTab()){
	 		Reporters.SuccessReport("Validating Marketing Tab", "Marketing tab validations are Successfully Done");
		}else{			
			Reporters.failureReport("Validating Marketing Tab", "Marketing tab validations are failed");
		}
		String user="";
		String checkbox="selectFeatureRadioButton";
		
		stepReport("Add cross promotion items to marketing page");
		if(ECommercePackagependingcourseid_15461.crossPromoteItems(user, checkbox, "TC-15461", 7)){
	 		Reporters.SuccessReport("Validating Cross Promote Items", "Cross Promote items are Successfully Validated");
		}else{			
			Reporters.failureReport("Validating Cross Promote Items", "Cross Promote items are Validation failed");
		}
		
		Thread.sleep(high);
		String uniqueMarketingURL=EvolveCommonBussinessFunctions.uniqueUrl;
		System.out.println(uniqueMarketingURL);
		
		CreateLOUniqueCourseFaculty_Script_15583 louniqueCourse=new CreateLOUniqueCourseFaculty_Script_15583();
		
		stepReport("Faculty creates new course for the first ISBN");
		louniqueCourse.uniqueCourseLOFaculty("TC-15461",isbn1, 5);
		Thread.sleep(high);
		
		stepReport("Faculty creates new course for the second ISBN");
		louniqueCourse.uniqueCourseLOFaculty("TC-15461",isbn2, 6);
		
		
		Thread.sleep(high);
		stepReport("Create new student user");
		writeReport(User_BusinessFunction.CreateNewUser("Student"), "Create New Student user and log into the application", "Successfully Created new student user with the credentials : <br> Username : "+credentials[0]+"<br> Password : "+credentials[1]+" <br>Successfully logged in as New Student user", "Failed to Create new user");
		//User_BusinessFunction.Studentlogin("tuser1243", "abc@123");
		String url=ReadingExcel.columnDataByHeaderName("uniqueURL", "TC-15461", testDataPath);
		
		stepReport("Go to marketing URL and add package to cart");
		launchAndAddtoCart(url);
		
		//launchAndAddtoCart("https://evolvecert.elsevier.com/automationtesting257117");
		
		stepReport("Complete checkout and submit order");
		newstudentBilling("iteration",streetAddress, cityAddress, stateAddress, zip);
		Thread.sleep(veryhigh);
		
		stepReport("Verify the courses appear under My Evolve with the correct buttons");
		clickEvolveAndVerifyUserContent();	
		VerifyContentpagewithinputs("Online Course",course1,"Enter Instructor's Course ID","","Yes");
		VerifyContentpagewithinputs("Simulations - SimChart",course2,"Enter Instructor's Course ID","","Yes");
		
		stepReport("Login to Evolve Admin");
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),ReadResourceData.getResourceData("TC-10214-1", configProps.getProperty("AdminUser")),
				ReadResourceData.getResourceData("TC-10214-2", configProps.getProperty("AdminUser")),
				ReadResourceData.getResourceData("TC-10214-3", configProps.getProperty("AdminUser")));
		
		stepReport("Revoke student's access");
		adminPARVerify(credentials[0]);
		
		stepReport("Verify My Evolve after revoking access");
		verifyContent();
		VerifyContentpagewithinputs("Online Course",course1,"Enter Instructor's Course ID","","No");
		System.out.println("Evolve");
		
		//repeating steps 8-10
		stepReport("Go to marketing URL and add package to cart");
		launchAndAddtoCart(url);
		
		stepReport("Complete checkout and submit order");
		newstudentBilling("",streetAddress, cityAddress, stateAddress, zip);
		
		stepReport("Verify the courses appear under My Evolve with the correct buttons");
		clickEvolveAndVerifyUserContent();
		VerifyContentpagewithinputs("Online Course",course1,"Enter Instructor's Course ID","","No");
		VerifyContentpagewithinputs("Simulations - SimChart",course2,"Enter Instructor's Course ID","","Yes");
		Thread.sleep(high);
		EComm_Preorde_MyEvolve_Page15594_BussinessFunctions.courseDetailsPage(ElsevierObjects.contentLink1,"contentHome");
		Thread.sleep(high);
		String courseID1=ReadingExcel.columnDataByHeaderName("CourseID1", "TC-15461", testDataPath);
		String courseID2=ReadingExcel.columnDataByHeaderName("CourseID2", "TC-15461", testDataPath);
		
		stepReport("Submit course IDs and validate courses");
		validateProduct(course2, courseID2, ElsevierObjects.contentLink2);
		
		validateProduct(course1, courseID1, ElsevierObjects.contentLink1);
		
	}catch(Exception e){
		System.out.println(e.getMessage());
	}
	
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
