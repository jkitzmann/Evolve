package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.CreateFacultyUserfromSplashPage_9799;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class CreateStudentUserfromStudentPageScript_9800 extends EvolveCommonBussinessFunctions{
	@Test
	public void CreateStudentUserfromStudentPage_9800() throws Throwable{
		try{	
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			stepReport("Verify the appearance of the login form");
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String user="student";
			verifyLogin(user);
			String page="studentpage";
			
			stepReport("Verify registration form error handling");
			createAnAccountWithEmptyFields(user,page);
			
			stepReport("Create a new student user");
			createAnAccountWithCorrectDetails(user,page);
			
			if(getAccountDetailsforRoster()){}
			
			stepReport("Log out and back in");
			if(instructorLogout()){
				Reporters.SuccessReport("Student logout:", "Successfully logged out the student aplication.");
			}
			else{
				Reporters.failureReport("Student logout:", "Failed to logout the student application.");
			}
			userReLogin(user);
			//SwitchToBrowser("Chrome");
			
			stepReport("Verify email");
			if(emailLogin()){
				Reporters.SuccessReport("Email login:", "Successfully logged into User Email.");
			}
			else{
				Reporters.failureReport("Email Login:", "Failed to login into User Email.");
			}
			String Title=tc_9798.get("Title");
			CreateFacultyUserfromSplashPage_9799.emailBodyVerification(Title,user);
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}