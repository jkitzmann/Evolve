package com.cigniti.automation.BusinessFunctions;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;


public class EcommercePKGCrossPromoteExclusions5_15560 extends EvolveCommonBussinessFunctions  {
	PromotionVariablePercentageInclusions_10227 e=new PromotionVariablePercentageInclusions_10227();
	// click on cross promotions
	public static boolean crossPromotionTab() throws Throwable{
		boolean flag=true;		
		try{
			if(click(ElsevierObjects.Evolve_Admin_Ecom_CrossProm, "Click on Cross Promotion Tab")){
				Reporters.SuccessReport("Click on the Cross Promotion tab", "Successfully Clicked on the Cross promotion Tab");
			}else{
				Reporters.failureReport("Click on the Cross Promotion tab", "Failed to Click on the Cross promotion Tab");
			}
			Thread.sleep(medium);
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}
		return flag;
	}
	
	//Verify Exclude Products
	public static boolean verifyExcludeProducts() throws Throwable{
		boolean flag=true;		
	try{	
		flag=verifyTextForExcludeProducts(ElsevierObjects.Admin_Evolve_Ecom_ExcludeProducts, ElsevierObjects.Admin_Evolve_Ecom_Reference, 
				ElsevierObjects.Admin_Evolve_Ecom_Text, ElsevierObjects.Admin_Evolve_Ecom_Trade,
				ElsevierObjects.Admin_Evolve_Ecom_Annual, ElsevierObjects.Admin_Evolve_Ecom_pkgsuccess);
	}
	catch(Exception e)
	{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		return false;
	}
		return flag;
	}
	
   
    // profit centre 
    public static boolean validateProfitCenter() throws Throwable {
		boolean flag = true;
	try{	
		if(isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_Combo, "The Combo Box is present")){
			Reporters.SuccessReport("Verify the presence of Combo Box", "The Combo Box is present on the page");
		}else{
			Reporters.failureReport("Verify the presence of Combo Box", "The Combo Box is not present on the page");
		}
	
		flag= validateAllSections(ElsevierObjects.comboprofitEX,ElsevierObjects.xpathExProfit,ElsevierObjects.Admin_Evolve_Ecom_Excludepc, 
		ElsevierObjects.Admin_Evolve_Ecom_AltMsg, ElsevierObjects.Admin_Evolve_Ecom_SelectOption, 
		ElsevierObjects.Admin_Evolve_Ecom_Addsucmsg, ElsevierObjects.Admin_Evolve_Ecom_Messg, 
		ElsevierObjects.Admin_Evolve_Ecom_RmvBtn, ElsevierObjects.Admin_Evolve_Ecom_RmvBtnViewAll, 
		ElsevierObjects.Admin_Evolve_Ecom_SelectOption1, ElsevierObjects.Admin_Evolve_Ecom_SelectOption2, 
		ElsevierObjects.Admin_Evolve_Ecom_SelectOption3, ElsevierObjects.Admin_Evolve_Ecom_SelectOption4); 
		
		/*flag= validateViewAll(ElsevierObjects.Admin_Evolve_Ecom_ViewAllMsg, ElsevierObjects.Admin_Evolve_Ecom_ViewNewPageMsg, 
				ElsevierObjects. Admin_Evolve_Ecom_CrsPrm_RmvData, ElsevierObjects. Admin_Evolve_Ecom_CrsPrm_VwBack, 
				ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData);
		*/
		flag= validateViewAll(ElsevierObjects.Admin_Evolve_Ecom_ViewAllMsg, ElsevierObjects.Admin_Evolve_Ecom_ViewNewPageMsg, 
				ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
				ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData , VerifyText1,"");
    }
	catch(Exception e)
	{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		return false;
	}
		return flag;
    }
    
    //major subject
    public static boolean validateMajorSubjectCodeSection() throws Throwable{
		boolean flag=true;
	try{	
		if(isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MajSub_Combo, "The Combo Box is present")){
			Reporters.SuccessReport("Verify the presence of Combo Box", "The Combo Box is present on the page");
		}else{
			Reporters.failureReport("Verify the presence of Combo Box", "The Combo Box is not present on the page");
		}
		
		flag = validateAllSections(ElsevierObjects.combomajorEX,ElsevierObjects.xpathMajorEX,ElsevierObjects.Admin_Evolve_Ecom_Excludems, 
				ElsevierObjects.Admin_Evolve_Ecom_MajSub_AltMsg, ElsevierObjects.Admin_Evolve_Ecom_MajSub_SelectOption, 
				ElsevierObjects.Admin_Evolve_Ecom_MajSub_Addsucmsg, ElsevierObjects.Admin_Evolve_Ecom_MajSub_Messg, 
				ElsevierObjects.Admin_Evolve_Ecom_MajSub_RmvBtn, ElsevierObjects.Admin_Evolve_Ecom_MajSub_RmvBtnViewAll, 
				ElsevierObjects.Admin_Evolve_Ecom_MajSub_SelectOption1, ElsevierObjects.Admin_Evolve_Ecom_MajSub_SelectOption2, 
				ElsevierObjects.Admin_Evolve_Ecom_MajSub_SelectOption3, ElsevierObjects.Admin_Evolve_Ecom_MajSub_SelectOption4);
		
		/*flag = validateViewAll(ElsevierObjects.Admin_Evolve_Ecom_MajSub_ViewAllMsg, ElsevierObjects.Admin_Evolve_Ecom_MajSub_ViewNewPageMsg, 
				ElsevierObjects.Admin_Evolve_Ecom_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_VwBack, 
				ElsevierObjects.Admin_Evolve_Ecom_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData );
		
		*/flag= validateViewAll(ElsevierObjects.Admin_Evolve_Ecom_MajSub_ViewAllMsg, ElsevierObjects.Admin_Evolve_Ecom_ViewNewPageMsg, 
				ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
				ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData , VerifyText1,"");
    }
	catch(Exception e)
	{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		return false;
	}
		return flag;
	}
    
   	//product type
    public static boolean validateProductTypeCodeSection() throws Throwable{
		boolean flag=true;
	try{	
		if(isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_PrdTyp_Combo, "The Combo Box is present")){
			Reporters.SuccessReport("Verify the presence of Combo Box", "The Combo Box is present on the page");
		}else{
			Reporters.failureReport("Verify the presence of Combo Box", "The Combo Box is not present on the page");
		}
		
		flag= validateAllSections(ElsevierObjects.comboproductEX,ElsevierObjects.xpathProductEX,ElsevierObjects.Admin_Evolve_Ecom_Excludept, 
				ElsevierObjects.Admin_Evolve_Ecom_PrdTyp_AltMsg, ElsevierObjects.Admin_Evolve_Ecom_PrdTyp_SelectOption, 
				ElsevierObjects.Admin_Evolve_Ecom_PrdTyp_Addsucmsg, ElsevierObjects.Admin_Evolve_Ecom_PrdTyp_Messg, 
				ElsevierObjects.Admin_Evolve_Ecom_PrdTyp_RmvBtn, ElsevierObjects.Admin_Evolve_Ecom_PrdTyp_RmvBtnViewAll, 
				ElsevierObjects.Admin_Evolve_Ecom_PrdTyp_SelectOption1, ElsevierObjects.Admin_Evolve_Ecom_PrdTyp_SelectOption2, 
				ElsevierObjects.Admin_Evolve_Ecom_PrdTyp_SelectOption3, ElsevierObjects.Admin_Evolve_Ecom_PrdTyp_SelectOption4);
		
		/*flag= validateViewAll(ElsevierObjects.Admin_Evolve_Ecom_PrdTyp_ViewAllMsg, ElsevierObjects.Admin_Evolve_Ecom_PrdTyp_ViewNewPageMsg, 
				ElsevierObjects.Admin_Evolve_Ecom_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_VwBack, 
				ElsevierObjects.Admin_Evolve_Ecom_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData);
		*/
		flag= validateViewAll(ElsevierObjects.Admin_Evolve_Ecom_PrdTyp_ViewAllMsg, ElsevierObjects.Admin_Evolve_Ecom_ViewNewPageMsg, 
				ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
				ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData , VerifyText1,"");
    }
	catch(Exception e)
	{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		return false;
	}
		return flag;
	}
    
    
    public static boolean validateViewAll(By viewall, By viewNewpage, By viewRem, By viewBack,By viewChkbox, By viewTxtVrfy, By remAll) throws Throwable{
		boolean flag=true;
	try{
		String sucMsg=getText(viewall, "viewall");
		if(isElementPresent(viewall, "View All Link is present")){
			Reporters.SuccessReport("Verify the element is present or not", "The View All Link is successfully displayed");	
		}else{
			Reporters.failureReport("Verify the element is present or not", "The View All Link is failed to display");
		}	
		if(!click(viewall, "Click on View All Link")){
			flag = false;
		}
		Thread.sleep(medium);
		if(isElementPresent(viewNewpage, "Promotion Inclusion - View All Link is present")){
			Reporters.SuccessReport("Verify the element is present or not", "The Promotion Inclusion - View All Link is successfully displayed");	
		}else{
			Reporters.failureReport("Verify the element is present or not", "The Promotion Inclusion - View All Link is failed to display");
		}			
		if(isElementPresent(viewRem, "Remove Button is present")){
			Reporters.SuccessReport("Verify the element is present or not", "The Remove Button is present ");	
		}else{
			Reporters.failureReport("Verify the element is present or not", "The Remove Button is not present");
		}	
		if(isElementPresent(viewBack, "Back Button is present")){
			Reporters.SuccessReport("Verify the element is present or not", "The Back Button is displayed on the page");	
		}else{
			Reporters.failureReport("Verify the element is present or not", "The Back Button is not present on the page");
		}			
		if(driver.findElement(viewRem).isEnabled())
		{
			Reporters.failureReport("Verifying the Remove button is Enabled or Disabled", "Remove Button is Enabled");
		}else
		{
			Reporters.SuccessReport("Remove button", "Remove Button is Disabled");
		}
		Thread.sleep(medium);
		if(!click(viewChkbox, "Click on CheckBox")){
			flag = false;
		}
		Thread.sleep(high);
		String verifyTextPresent=driver.findElement(viewTxtVrfy).getText();
		//Thread.sleep(medium);
		if(!click(remAll, "Click on remove button")){
			flag = false;
		}
		Thread.sleep(medium);
		if(!Alert()){
			flag=false;
		}				
		Thread.sleep(high);			
		/*if(verifyTextPresent.contains(VerifyText)){
			Reporters.failureReport("Remove Record", "Product is not removed");
		}else{
			Reporters.SuccessReport("Remove Record", "Product is successfully removed");
		}	*/	
		if(!click(viewBack, "Click on Back Button")){
			flag = false;
		}
		Thread.sleep(medium);
	}
	catch(Exception e)
	{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		return false;
	}
		return flag;
	}

    
    
   
  //Common method for Validating All the three sections ie. Profit Center, Major Subject Code and Product type code
	public static boolean validateAllSections( By comboBox,By xpath,By excludeBtn, By errMsgBy, By selectionOptionBy, By sucMsgBy, By cnfrmMsgBy, By rmvBttnBy, By rmvAllBttn, By sel1, By sel2, By sel3, By sel4) throws Throwable{
			
		boolean flag=true;
		try{
		Thread.sleep(low);
			String comboSize=getAttribute(comboBox, "size", "size");
			System.out.println(comboSize);
			if(comboSize.contains("5")){
				Reporters.SuccessReport("Profit Centers shows 5", "Profit Centers shows 5");
			}else{
				Reporters.failureReport("Profit Centers shows 5", "Profit Centers shows 5");
			}			
			
			String [] Values1=new String[5];
			List<WebElement> selectOption=driver.findElements(xpath);
			for(int i =0;i<5;i++)
			{
			  Values1[i]=selectOption.get(i).getText();  	
			//	System.out.println(option.getText());
			}				
			verifysort(Values1);
			
			
			if(isElementPresent(excludeBtn, "The Exclude button is present")){
				Reporters.SuccessReport("Verify the element is present or not", "The exclude Button : "+excludeBtn+" is successfully displayed");	
			}else{
				Reporters.failureReport("Verify the element is present or not", "The exclude Button : "+excludeBtn+" is failed to display");
			}				
			Thread.sleep(medium);
			if(!click(excludeBtn, "Click on Exclude Button")){
				flag = false;
			}
			Thread.sleep(medium);
			String errMsg=getText(errMsgBy, "");
			if(verifyText(errMsgBy, "Please select product group to add to the promotion.", "Error Message")){
				Reporters.SuccessReport("The Error Message Validation", "The Error message : "+errMsg+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Error Message Validation", "The Error message : "+errMsg+" is failed to display");
			}
			
			driver.findElement(selectionOptionBy).click();				
			Thread.sleep(low);
			if(!click(excludeBtn, "Click on Exclude Button")){
				flag = false;
			}
			/*Thread.sleep(medium);		
			if(!Alert()){
				flag=false; 
			}	*/							
			//step 7 start
				
			Thread.sleep(medium);			
			driver.findElement(selectionOptionBy).click();
			driver.findElement(selectionOptionBy).click();
			Thread.sleep(medium);
			if(!click(excludeBtn, "Click on Exclude Button")){
				flag = false;
			} 
			Thread.sleep(medium);
			String sucMsg=getText(sucMsgBy, "");
			if(verifyText(sucMsgBy, "The Promotion Inclusion is successfully saved.", "Success Message")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
			}

			Thread.sleep(medium);
			if(!isElementPresent1(cnfrmMsgBy, "Success Message")){
				flag = false;
			}
			Thread.sleep(medium);					
			if(!isElementPresent1(rmvBttnBy, "Remove button")){
				flag = false;
			}								
			Thread.sleep(medium);										
			//step 7 end
							
			//step 8 start				
			if(!click(rmvBttnBy, "Click on remove Button")){
				flag = false;
			}
			Thread.sleep(medium);		
			if(!Alert()){
				flag=false;
			}							
			Thread.sleep(medium);							
			//add more than 4 inclusions
			//dataproviders need to be used
			//Step 9 Starts
			//0th iteration				
			driver.findElement(selectionOptionBy).click();
			driver.findElement(selectionOptionBy).click();
			Thread.sleep(medium);
			if(!click(excludeBtn, "Click on Exclude Button")){
				flag = false;
			}
			Thread.sleep(medium);
			String sucMsg1=getText(sucMsgBy, "");
			if(verifyText(sucMsgBy, "The Promotion Inclusion is successfully saved.", "Success Message")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg1+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg1+" is failed to display");
			}

			Thread.sleep(medium);
			if(!isElementPresent1(cnfrmMsgBy, "success message")){
				flag = false;
			}
			Thread.sleep(medium);					
			if(!isElementPresent1(rmvBttnBy, "Remove button")){
				flag = false;
			}								
			Thread.sleep(medium);		
			
			//1st iteration
			driver.findElement(selectionOptionBy).click();
			driver.findElement(sel1).click();
			Thread.sleep(medium);
			if(!click(excludeBtn, "Click on Exclude Button")){
				flag = false;
			}
			Thread.sleep(medium);
			String sucMsg3=getText(sucMsgBy, "");
			if(verifyText(sucMsgBy, "The Promotion Inclusion is successfully saved.", "Success Message")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg3+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg3+" is failed to display");
			}
			Thread.sleep(medium);
			if(!isElementPresent1(cnfrmMsgBy, "success message")){
				flag = false;
			}
			Thread.sleep(medium);					
			if(!isElementPresent1(rmvAllBttn, "Remove button")){
				flag = false;
			}								
			Thread.sleep(medium);						
			//2nd iteration
			driver.findElement(sel1).click();
			driver.findElement(sel2).click();
			Thread.sleep(medium);
			if(!click(excludeBtn, "Click on Exclude Button")){
				flag = false;
			}
			Thread.sleep(medium);
			String sucMsg4=getText(sucMsgBy, "");
			if(verifyText(sucMsgBy, "The Promotion Inclusion is successfully saved.", "Success Message")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg4+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg4+" is failed to display");
			}
			Thread.sleep(medium);
			if(!isElementPresent1(cnfrmMsgBy, "success message")){
				flag = false;
			}
			Thread.sleep(medium);					
			if(!isElementPresent1(rmvAllBttn, "Remove button")){
				flag = false;
			}								
			Thread.sleep(medium);						
			//3rd iteration
			driver.findElement(sel2).click();
			driver.findElement(sel3).click();
			Thread.sleep(medium);
			if(!click(excludeBtn, "Click on Exclude Button")){
				flag = false;
			}
			Thread.sleep(medium);
			String sucMsg5=getText(sucMsgBy, "");
			if(verifyText(sucMsgBy, "The Promotion Inclusion is successfully saved.", "Success Message")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg5+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg5+" is failed to display");
			}
			Thread.sleep(medium);
			if(!isElementPresent1(cnfrmMsgBy, "success message")){
				flag = false;
			}
			Thread.sleep(medium);					
			if(!isElementPresent1(rmvAllBttn, "Remove button")){
				flag = false;
			}								
			Thread.sleep(medium);					
			//4th iteration
			driver.findElement(sel3).click();
			driver.findElement(sel4).click();
			Thread.sleep(medium);
			if(!click(excludeBtn, "Click on Exclude Button")){
				flag = false;
			}
			Thread.sleep(medium);
			String sucMsg6=getText(sucMsgBy, "");
			if(verifyText(sucMsgBy, "The Promotion Inclusion is successfully saved.", "Success Message")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg6+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg6+" is failed to display");
			}
			Thread.sleep(medium);
			if(!isElementPresent1(cnfrmMsgBy, "success message")){
				flag = false;
			}
			Thread.sleep(medium);					
			if(!isElementPresent1(rmvAllBttn, "Remove button")){
				flag = false;
			}								
			Thread.sleep(medium);		
		}
			catch(Exception e)
			{
				sgErrMsg=e.getMessage();
				System.out.println(e.getMessage());
				return false;
			}
			return flag;
	}

	public static boolean validateISBNSection() throws Throwable{
		try{
			boolean flag=true;
			flag=validateISBNSection(ElsevierObjects.Admin_Evolve_Ecom_ISBNtxt, 
					ElsevierObjects.Admin_Evolve_Ecom_Excludeisbn, 
					ElsevierObjects.Admin_Evolve_Ecom_ISBNErrMsg, ElsevierObjects.Admin_Evolve_Ecom_ISBNSucMsg,
					ElsevierObjects.Admin_Evolve_Ecom_ISBNAddList, ElsevierObjects.Admin_Evolve_Ecom_ISBNRem, 
					readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("InvalidISBN"));	
			
			
			return flag;
		}
			catch(Exception e)
			{
				sgErrMsg=e.getMessage();
				System.out.println(e.getMessage());
				return false;
			}	}
	
	
	
	//Validating ISBN Section
			public static boolean validateISBNSection(By ISBNText, By ISBNAdd, By ISBNErrMsg, By ISBNSucMsg, By ISBNAddList, By ISBNRem, String invalidISBN) throws Throwable {
				
			boolean flag = true;				
			try{
			if(!isElementPresent(ISBNText, "ISBN Text Box is Present")){
					flag = false;
				}				
							
				if(!isElementPresent(ISBNAdd, "ISBN Text Box is Present")){
					flag = false;
				}				
				driver.findElement(ISBNText).clear();
				Thread.sleep(medium);
				
				if(!type(ISBNText, invalidISBN /*readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("InvalidISBN") */,"Enter Invalid ISBN into the Text Box")){
					flag = false;
				}	
							
				if(!click(ISBNAdd, "Click on Add Button")){
					flag = false;
				}	
				Thread.sleep(medium);
				if(!verifyText(ISBNErrMsg, "The ISBN does not exist, please enter new ISBN.", "Error Message")){
					flag = false;
				}	
				System.out.println("");
				driver.findElement(ISBNText).clear();
				Thread.sleep(medium);
				//driver.findElement(ElsevierObjects.Evolve_Admin_Prmlnk_CampaignCode).click();
				ReadingExcel re=new ReadingExcel();
				List<String> ISBNdata=re.columnData(5, "Ecom_TCID_10217", configProps.getProperty("TestData"));

				for(String ISBN:ISBNdata){	
					System.out.println(ISBN);
					
					driver.findElement(ISBNText).clear();
					driver.findElement(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNUplPercent).click();
					if(!type(ISBNText, ISBN ,"Enter valid ISBN into the Text Box")){
						flag = false;
					}
					
					if(!click(ISBNAdd, "Click on Add Button")){
						flag = false;
					}
					Thread.sleep(medium);					
					if(!verifyText(ISBNSucMsg, "The Promotion Inclusion is successfully saved.", "Success Message")){
						flag = false;
					}				
					if(!isElementPresent(ISBNAddList, "ISBN is Added successfully")){
						flag = false;
					}							
				}				
				if(!click(ISBNRem, "Click on Remove Button for the ISBN")){
					flag = false;
				}	
				if(!Alert()){
					flag = false;
				}
				Thread.sleep(medium);	
			}
				catch(Exception e)
				{
					sgErrMsg=e.getMessage();
					System.out.println(e.getMessage());
					return false;
				}
				return flag;			
			}
	
	
	//Validating CSV file upload section
			public static boolean uploadCSVFile(By ISBNBrowseBtn,By uploadBtn, By sucMsg) throws Throwable{				
				boolean flag = true;				
				try{
				String filePath = ReadingExcel.getAbsoulteFilePath(readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("UploadCSVFile"));
				
				uploadFile(ISBNBrowseBtn, filePath, "Upload File");
				Thread.sleep(high);			   
				if(!click(uploadBtn, "Click on Upload Button")){
					flag = false;
				}
				Thread.sleep(high);		
				String sucMsg1=getText(sucMsg, "Success Message");
				if(verifyText(sucMsg, "The file is uploaded successfully.", "Success Message")){
					Reporters.SuccessReport("Validate CSV ISBN File Upload Section", "The success message : "+sucMsg1+" is displayed <br> CSV file is uploaded from solution and the path is : \\TestData\\ISBNFile.csv");	
				}else{
					Reporters.failureReport("Validate CSV ISBN File Upload Section", "The failure message : "+sucMsg1+" is displayed <br> CSV file is failed to upload from solution and the path is : \\TestData\\ISBNFile.csv");	
				}
				 
				//Reporters.SuccessReport("", "");
				}catch(Exception e)
				{
					sgErrMsg=e.getMessage();
					System.out.println(e.getMessage());
					return false;
				}
				return flag;
			}
			
			
			//Validating the ISBN Upload Section
			public static boolean uploadCSVFile() throws Throwable{
				boolean flag=true;
				try{
					flag=uploadCSVFile(ElsevierObjects.Admin_Evolve_Ecom_ISBNBrowse, 
					ElsevierObjects.Admin_Evolve_Ecom_ISBNUplBtn, ElsevierObjects.Admin_Evolve_Ecom_ISBNUplSucMsg);
					removeVerify(ElsevierObjects.Admin_Evolve_Ecom_ISBNRemoveLink, ElsevierObjects.remove_a, ElsevierObjects.remove_b);
					Thread.sleep(medium);
					
				}catch(Exception e){
					sgErrMsg=e.getMessage();
					System.out.println(e.getMessage());return false;
				}
				return flag;
			}

			public static boolean removeVerify(By remLnk, String rem1, String rem2) throws Throwable{
				boolean flag=true;
				try{
					
				List<WebElement> element=driver.findElements(remLnk);
				int getSize=element.size();
				for (int i = 1; i < getSize+1; i++) {
					String row1=getText(By.xpath(rem1+i+rem2), "");
					//driver.findElement(By.xpath(ElsevierObjects.remove1+i+ElsevierObjects.remove2)).getText();
					System.out.println(row1);
					if(row1.contains("remove")){
						System.out.println(row1);
						Reporters.SuccessReport("Remove link", "Remove Link is present for inclusion item : "+element.get(i).getText());
					}else{

						Reporters.failureReport("Remove link", "Remove Link is not present for inclusion : "+element.get(i).getText());
					}
				}	
				}catch(Exception e){
					sgErrMsg=e.getMessage();
					System.out.println(e.getMessage());return false;}
				return flag;
			}
			
			
	
	
	public static boolean validateUploadISBNSection() throws Throwable {
		boolean flag = true;				
		try{
		flag= validateViewAll(ElsevierObjects.Admin_Evolve_Ecom_ISBNViewAllLnk, ElsevierObjects.Admin_Evolve_Ecom_ISBNViewNewPageMsg, 
				ElsevierObjects.Admin_Evolve_Ecom_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_VwBack, 
				ElsevierObjects.Admin_Evolve_Ecom_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_RmvData);			
		
		Thread.sleep(high);				
		if(!click(ElsevierObjects.Admin_Evolve_Ecom_ISBNViewAllLnk, "Click on View All Link")){
			flag = false;
		}		
		Thread.sleep(medium);
		if(!click(ElsevierObjects.Admin_Evolve_Ecom_VwChkBox, "Click on CheckBox")){
			flag = false;
		}
		Thread.sleep(high);
		if(!click(ElsevierObjects.Admin_Evolve_Ecom_RmvData, "Click on remove button")){
			flag = false;
		}
		
		Thread.sleep(medium);
		
		org.openqa.selenium.Alert alert;
		alert = driver.switchTo().alert();
		alert.dismiss();	
		
		Thread.sleep(medium);
		if(!click(ElsevierObjects.Admin_Evolve_Ecom_VwBack, "Click on Back Button")){
			flag = false;
		}
		Thread.sleep(medium);
		
		if(!click(ElsevierObjects.Evolve_Admin_Ecom_TabEcommerce, "Click on Cross Promotion Tab")){
			flag = false;
		}
		Thread.sleep(medium);
		
		if(!click(ElsevierObjects.Evolve_Admin_Ecom_CrossProm, "Click on Cross Promotion Tab")){
			flag = false;
		}
		Thread.sleep(medium);
		 if(!isElementPresent1(ElsevierObjects.Admin_Evolve_Ecom_ISBNViewAllLnk, "View All Link")){
				flag = false;
			}
		}
		 catch(Exception e)
			{
				sgErrMsg=e.getMessage();
				System.out.println(e.getMessage());
				return false;
			}
		return flag;						
	}

	public static void setClipboardData(String string) {
	try{
		StringSelection stringSelection = new StringSelection(string);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
	}
	catch(Exception e)
	{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
	}
	}
}
    
