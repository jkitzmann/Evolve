package com.cigniti.automation.Test;

import java.util.Random;

import jxl.Sheet;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class SearchResults_DisciplineSpecialtycategory_15041 extends User_BusinessFunction {
	
	//**************************** Declarations *****************************************************
 	public static Sheet inputSheetObj =null;
	Random ra = new Random( System.currentTimeMillis() );
	@Test
	public void SearchResults_DisciplineSpecialtycategory() throws Throwable
	
	{
	       //HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		writeReport(SwitchToBrowser(ElsevierObjects.studentBrowserType),"Launching Browser to Portal User","Launching Browser to Portal User is succesful","Lanching Browser to Portal User is failed");
		
		String Input1=ReadingExcel.columnDataByHeaderName( "Special Category", "TC-15041",configProps.getProperty("TestData"));
		
		
		
        System.out.println("*********************************Launch As Student View****************************");


       writeReport(User_BusinessFunction.LaunchStudent(),"Launch URL navigate to Student View",
                                                       "Launching the URL for Student is successful </br > Navigate to Student View is Successful",
                                                       "Launching the URL for Student is not successful </br> OR </br > Navigate to Student View is not Successful");
/******************
       writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as:"+sStudentUser,
                                                              "Navigating to CATALOG page is Successful",
                                                              "Navigating to CATALOG Page is failed");
********************************/
       writeReport(User_BusinessFunction.NavigateResultsfromsplcategory(Input1),"Navigating to Discipline and Special Category: "+Input1,
                                                                                 "Clicking the icon that says 'Save on Elsevier Products' in the bottom middle of the page. </br> Navigate to Save Money When You Shop on Evolve! Page is Successful </br> Clicking on 'Browse our products by discipline' Link  is Successful </br> Navigate to Browser Products is Successful </br>Clicking on "+Input1+"  is Successful",
                                                                                 "Navigating to Discipline and Special Category is failed");

      writeReport(User_BusinessFunction.Verifysplcategory(), "Verifying to Navigating to Search results from Discipline and Special Category:" +Input1, "Navigating to Search Results is Successuful </br> For "+Input1+" Search Criteria  "+sActualValues + "</br> The Appeared Results are Greater Than Zero", "Navigate to Search Results page is failed");    
	}
    
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
	/*@AfterClass
	public static void browserStop()
	{
		driver.close();
	}*/
	
	

