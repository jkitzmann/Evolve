package com.cigniti.automation.Test;


import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.Evolve_StudentLogin_9795;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.BusinessFunctions.Z_LO_SelfEnrollLOAccessCodeThroughCart_15585;

public class Z_LO_SelfEnrollLOAccessCodeThroughCart_15585_Script extends Z_LO_SelfEnrollLOAccessCodeThroughCart_15585{
	
	@Test
	public void Z_LO_SelfEnrollLOAccessCodeThroughCart() throws Throwable{
    String courseid, isbn, title;
	try{
		
		//Step 1:Complete test cases:  LO Unique Course Fulfillment-Faculty and capture the product id
		LO_Unique_CourseFulfillment_Faculty_Script_10410 k=new LO_Unique_CourseFulfillment_Faculty_Script_10410();
		k.loUniqueCoursefulfillmentFaculty_10410();
		
		//un-comment below line to run without step1 for debugging purpose
		//courseid="104882_einstein_1083";
		courseid=EvolveCommonBussinessFunctions.courseID1;
		
		isbn=EvolveCommonBussinessFunctions.adoptionRequest_Isbn;
		//un-comment below line to run without step1 for debugging purpose
		//isbn="9780323055536";
		
		title=EvolveCommonBussinessFunctions.title;
		//un-comment below line to run without step1 for debugging purpose
		//title="Medical Terminology Online for Mastering Healthcare Terminology";
		testCaseName ="Z_LO_SelfEnrollLOAccessCodeThroughCart_15585_Script";
		//SwitchToBrowser(ElsevierObjects.studentBrowserType);
		
		
		//Step 2 : Log into evolve admin cert.  Maintain Products.Search for the ISBN from step #1.Click on the ISBN.Click on the Create Access Code tab.
		//Step 3 : Enter a unique value for "Code Set Name" field Uses per Code = 1	Number to generate = 10.	SAVE 
		writeReport(User_BusinessFunction.Logout(),"Logout","Logout user successful","Logout User failed");
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login into Admin.", 
				"Successfully logged into Admin portal.", 
				"'Failed to login into Admin portal.");
		writeReport(Z_LO_SelfEnrollLOAccessCodeThroughCart_15585.verifyMaintainProduct(isbn),"Clicl on Maintain Product","Maintain Product verification Success","Maintain Product verification failed");
		writeReport(createAccessCode(),"Create access Code","Create access code successful","Create access code failed");
		

		//Step 4:Create Student User from Student Page 
		writeReport(EvolveCommonBussinessFunctions.CreateNewUser("student"),"Create Student user", "Sudent creation Successful", "Student creation failed");
				
		//Step 5 : Click on Catalog tab. Click online course honeypot and choose to enroll into a course. 
		//Enter the course ID from Step #1 and submit
		writeReport(EvolveCommonBussinessFunctions.verifyHoneyPot(),"Click Honey Pot","HoneyPort click scucessful","HoneyPort click failed");

		
		//Step6 : Verify the correct self enrollment course info displays in the cart.
		writeReport(Z_LO_SelfEnrollLOAccessCodeThroughCart_15585.verifySelfEnrollNavigate(courseid,isbn,title),"SelfEnroll course displayed","Displayed course enrolled successfully","Displayed course enrollement failed");
		writeReport(Z_LO_SelfEnrollLOAccessCodeThroughCart_15585.verifyCheckout(),"Verify checkout","checkout successful","checkout failed");
		
		//Step7&8 verify review/submit checkout, Address validation popup
		writeReport(EvolveCommonBussinessFunctions.updateVSTandKNOAccount("student","","false",""),"Billing address enter and submit","Billing address enter success","Billing address enter failed");
		
		//Step 9 and 10:Enter credit card details , Review and Submit
		writeReport(Evolve_StudentLogin_9795.evolve_StudentCreditCardDetails(),"Credit card details","redit card details entered successfully","redit card details enter failed");
		writeReport(Evolve_StudentLogin_9795.evolve_StudentReviewandSubmit(),"Review and Submit","Review and submit success","Review and submit failed");
		
		//Step 11 and 12: Click on My evolve and chk the course id appears under 0content list
		writeReport(Z_LO_SelfEnrollLOAccessCodeThroughCart_15585.verifyMyEvolveCourseId(),"course id check","Courseid found under evolve link","Courseid not found under evolve link");
		
		//step 13: click on the library folder titled course
		writeReport(Z_LO_SelfEnrollLOAccessCodeThroughCart_15585.verifyCoursePage(),"sub folders check under course","sub folders found under the course","no sub folders found for the course");
		
		//Step 14: Logout of evlove cert and login as admin
		writeReport(User_BusinessFunction.Logout(),"Logout","Logout Successful","Logout Failed");
		 
	}catch(Exception e){
		System.out.println(e.getMessage());
	}
	
	}
	/*@AfterClass
	public static void browserStop()
	{
		driver.close();
	}*/
	
	
}
