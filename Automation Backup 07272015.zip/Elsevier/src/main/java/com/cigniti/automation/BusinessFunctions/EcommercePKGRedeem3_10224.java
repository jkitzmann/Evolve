package com.cigniti.automation.BusinessFunctions;

import java.text.DecimalFormat;
import java.util.List;

import javax.crypto.Mac;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Accessories;
import com.cigniti.automation.Utilities.Reporters;


public class EcommercePKGRedeem3_10224 extends EvolveCommonBussinessFunctions{
	public static String titleOfCDROM;


	public static boolean crossPromoteItems() throws Throwable{
		boolean flag=true;	
		try
		{
			if(!click(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SltFeatureRadBtn, "Click on Feature Selected Resources radio button")){
				flag = false;
			}	
			if(!type(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ISBN, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("ISBN"), "Type title  ")){

				flag = false;
			}		
			if(!click(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ISBNAdd, "Click on Add Button")){
				flag = false;
			}
			Thread.sleep(medium);		
			if(!type(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Title, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("TitleCrossPromote"), "Type title  ")){

				flag = false;
			}					
			if(!type(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Description, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("BodyCrossPromote"), "Type URL  ")){

				flag = false;
			}		
			if(!click(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SaveAndPublish, "Click on Marketing Page Tab")){
				flag = false;
			}				
			Thread.sleep(medium);	
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(sgErrMsg);
		}
		return flag;
	}



	public static boolean verifyCart() throws Throwable{
		boolean flag = true;
		try{
			Thread.sleep(high);

			//Step - 3
			if(!javaClick(ElsevierObjects.Admin_Evolve_Ecom_AddtoCart, "Click on request this product")){
				flag = false;
			}
			//Thread.sleep(high);
			//TODO Check for exception, since it is throwing org.openqa.selenium.NoSuchElementException
			//clickOnEnterLaterButtonIfVisible();
			//Thread.sleep(medium);	
			//clickOnOkButtonIfVisible();
			Thread.sleep(medium);
			List<WebElement> items=driver.findElements(ElsevierObjects.Admin_Evolve_Ecom_MyCartTitle);
			for(WebElement s:items){
				System.out.println(s.getText());
			}
			String packageName=readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("PackageName");

			String title=getText(ElsevierObjects.Admin_Evolve_Ecom_MyCartTitle, "");
			if(title.contains(packageName)){	
				Reporters.SuccessReport(title, "Title is present in MyCart , Title is : "+title);
			}else{
				Reporters.failureReport(title, "Title is not present in MyCart :"+title);
			}

			//Verify the Price.
			//String xpath = Accessories.fetchDynamicLocator(ElsevierObjects.Student_product_Edition_Title.toString(), ElsevierObjects.ReplaceString1, readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("ISBNTextBox1"));
			/*if(!waitForElementPresent(By.xpath(xpath),"title of the edition")){
			flag=false;
		}*/
			String actualTitle1=getText(ElsevierObjects.Admin_Evolve_Ecom_studenttitle1, "");
			String expectedTitle1=EvolveCommonBussinessFunctions.title1;
			if(actualTitle1.contains(expectedTitle1)){
				Reporters.SuccessReport("Verify the Titles are correct", "The titles are matched with each other <br> Actual Title is : "+actualTitle1+" <br> Expected title is : "+expectedTitle1);	
			}else{
				Reporters.failureReport("Verify the Titles are correct", "The titles are not matched with each other <br> Actual Title is : "+actualTitle1+" <br> Expected title is : "+expectedTitle1);	
			}

			String actualTitle2=getText(ElsevierObjects.Admin_Evolve_Ecom_studenttitle2, "");
			String expectedTitle2=EvolveCommonBussinessFunctions.title2;
			if(actualTitle1.contains(expectedTitle1)){
				Reporters.SuccessReport("Verify the Titles are correct", "The titles are matched with each other <br> Actual Title is : "+actualTitle2+" <br> Expected title is : "+expectedTitle2);	
			}else{
				Reporters.failureReport("Verify the Titles are correct", "The titles are not matched with each other <br> Actual Title is : "+actualTitle2+" <br> Expected title is : "+expectedTitle2);	
			}

			//verifyText(ElsevierObjects.Admin_Evolve_Ecom_studenttitle2, EvolveCommonBussinessFunctions.title2, "");
			String studentprice1=getText(ElsevierObjects.Admin_Evolve_Ecom_studentprice1, "price in student module");
			String adminprice1=EvolveCommonBussinessFunctions.adminprice;		
			float admprice1=Float.parseFloat(adminprice1.replace("$", ""));
			String adminprice2=EvolveCommonBussinessFunctions.adminprice1;	
			float admprice2=Float.parseFloat(adminprice2.replace("$", ""));
			float admpricetotal=admprice1+admprice2;		
			float studentfinprice=Float.parseFloat(studentprice1.replace("$", ""));
			if(admpricetotal==studentfinprice){
				Reporters.SuccessReport("Validate the Prices in admin and Student", "The original and discounted prices are correct per the pricing listed with the ecommerce package setup page in Admin <> The Price in Admin module is : "+admpricetotal+"<br> The Price in the Student Module is : "+studentfinprice);
			}else{
				Reporters.SuccessReport("Validate the Prices in admin and Student", "The original and discounted prices are not correct per the pricing listed with the ecommerce package setup page in Admin <> The Price in Admin module is : "+admpricetotal+"<br> The Price in the Student Module is : "+studentfinprice);
			}
			String dmcode=EvolveCommonBussinessFunctions.DMCode;
			String PromotionCode=getAttribute(ElsevierObjects.Admin_Evolve_Ecom_PromotionCode, "value", "DM Code");
			if(dmcode.contains(PromotionCode)){
				Reporters.SuccessReport("DM Code is shown as Promotion Code", "DM Code is Shown as Promotion Code <br> Promotion Code is : "+PromotionCode+"<br> DM Code is : "+dmcode);
			}else{
				Reporters.failureReport("DM Code is shown as Promotion Code", "DM Code is not Shown as Promotion Code <br> Promotion Code is : "+PromotionCode+"<br> DM Code is : "+dmcode);
			}

			//Step - 4
			searchAndGo(readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("SearchItem"));
			Thread.sleep(high);


			if(!javaClick(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomclick, "Click on CD ROM Item")){
				flag=false;
			}
			ImplicitWait();
			titleOfCDROM=getText(By.xpath(".//*[@id='tab-relayout']/div/div/h1"), "Unable to get title");
			float cdromOrgPrc=convertPrice(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomprice);
			Thread.sleep(medium);
			if(!javaClick(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomAddtoCart, "Click on Add to Cart")){
				flag=false;
			}


			try{
				flag=true;
				float cdDscPrice=convertPrice(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomDiscPrice);

				Thread.sleep(1500);
				float finalPriceCDROM=cdromOrgPrc/2;		
				if(finalPriceCDROM==cdDscPrice){
					Reporters.SuccessReport("Verify that the price on this CD-Rom in the cart <br>displays as 50% off of the original price", "The final price of CD ROM is having a discount of 50 % <br> CD ROM Original Price is : "+cdromOrgPrc+"Final Price of CD ROM is :"+finalPriceCDROM);
				}else{
					Reporters.failureReport("Verify that the price on this CD-Rom in the cart <br>displays as 50% off of the original price", "The final price of CD ROM is not having a discount of 50 % <br> CD ROM Original Price is : "+cdromOrgPrc+"Final Price of CD ROM is :"+finalPriceCDROM);
				}		
				float totalDscPrice=convertPrice(ElsevierObjects.Admin_Evolve_Ecom_TotalDiscount);	
				float totalPrice1=convertPrice(ElsevierObjects.Admin_Evolve_Ecom_TtlPriPkg1);
				//DecimalFormat df = new DecimalFormat("##.00");
				//df.setMaximumFractionDigits(2);
				float totalPrice2=convertPrice(ElsevierObjects.Admin_Evolve_Ecom_TtlPriPkg2);
				float subTotal=convertPrice(ElsevierObjects.Admin_Evolve_Ecom_SubTotal);
				String expSubtotal=""+subTotal;
				float originalFinalPrice=totalPrice1+totalPrice2;
				//float FinalPrice=(float)(OriginalFinalPrice-totalDscPrice);
				float finalPrice=originalFinalPrice-totalDscPrice;

				DecimalFormat df = new DecimalFormat();
				df.setMaximumFractionDigits(2);
				String expPrice=df.format(finalPrice);

				/*DecimalFormat df = new DecimalFormat("#.##");
			String formatted = df.format(finalPrice); 
			System.out.println(formatted); */

				float finalprice=Math.round(finalPrice*100)/100;
				//df.format(finalPrice);
				if(expPrice.contains(expSubtotal)){
					Reporters.SuccessReport("Validate The discount/promotion field show display a total of discount the user received in the cart", "The discount/promotion field show display a total of discount the user received in the cart <br> Final Expected Price is : "+finalPrice+"<br> Final Actual Price is : "+subTotal);			
				}else{
					Reporters.failureReport("Validate The discount/promotion field show display a total of discount the user received in the cart", "The discount/promotion field failed to display a total of discount the user received in the cart <br> Final Expected Price is : "+finalPrice+"<br> Final Actual Price is : "+subTotal);	
				}
			}catch(Exception e){System.out.println(sgErrMsg);
			System.out.println("CD Rom products are not displaying as 50% off");
			//Reporters.failureReport("Verify that the price on this CD-Rom in the cart <br>displays as 50% off of the original price", "The final price of CD ROM is not having a discount of 50 % ");
			//return false;
			}


			//Step - 5
			String user="student";
			String name=null;
			if(!click(ElsevierObjects.Hesi_Student_Reedembutton, "Click on Redeem/Checkout Button")){
				flag=false;
			}
			String sucMsg=getText(ElsevierObjects.Admin_Evolve_Ecom_NewToEvolve, "");
			if(verifyText(ElsevierObjects.Admin_Evolve_Ecom_NewToEvolve, "New to Evolve? Create an account!", "Success Message")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
			}

			existingStudentLogin();
			Thread.sleep(medium);
			//updateVSTandKNOAccount(user, name, null, null);
			//shippingAddress();

			/*if(!click(ElsevierObjects.Student_Register_Continue_btn, "Click on continue button")){
			flag = false;
		}*/
			
			EvolveCommonBussinessFunctions.creditCardDetails();
			Thread.sleep(high);
			
			String reviewAndSubmit=getText(ElsevierObjects.reviewAndSubmit, "Get the value review and submit to a string");
			if(reviewAndSubmit.contains("2. REVIEW & SUBMIT")){
				Reporters.SuccessReport("The REVIEW & SUBMIT page is presented", "The REVIEW & SUBMIT page is successfully displayed");
			}else{
				Reporters.failureReport("The REVIEW & SUBMIT page is not present", "The REVIEW & SUBMIT page is failed to display");
			}
			if(!click(ElsevierObjects.instructor_chk, "Check Box Clicked")){
				flag = false;
			}
			/*if(!type(ElsevierObjects.instructor_checkoutcvv,readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("student_CardCvv"), "Card Name")){
				flag = false;
			}*/
			if(!javaClick(ElsevierObjects.instructor_submit, "Clicked on submit")){
				flag = false;
			}}catch(Exception e){
				System.out.println(e.getMessage());return false;
			}
			return flag;
	}

	/** Validate the values from confirmation page. 
	 * @param By Locator
	 * @return
	 * @throws Throwable
	 */
	public static boolean validateConfirmationPage() throws Throwable{
		boolean flag=true;
		try{
			String expTitle1=readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("PackageName");
			String expTitle2=EvolveCommonBussinessFunctions.title1;
			String expTitle3=EvolveCommonBussinessFunctions.title2;
			String expTitle4=titleOfCDROM;

			List<WebElement> titles=driver.findElements(By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class,'carttitle')]"));

			for(WebElement e: titles){
				if(e.getText().contains(expTitle1) || e.getText().contains(expTitle2) || e.getText().contains(expTitle3) || e.getText().contains(expTitle4)){
					Reporters.SuccessReport("Verify All the Titles are correct", "The titles are matched with each other <br> Actual Titles are : "+e.getText());	
				}else{
					Reporters.failureReport("Verify the Titles are correct", "The titles are not matched with each other <br> Actual Title is : "+e.getText());	
				}
			}

			/*for (int i = 0; i < titles.size(); i++) {
				if(titles.get(i).getText().contains(expTitle1) || titles.get(i).getText().contains(expTitle2) || titles.get(i).getText().contains(expTitle3)){
					Reporters.SuccessReport("Verify All the Titles are correct", "The titles are matched with each other <br> Actual Titles are : "+actTitle1+" <br> Expected title is : "+expTitle1);	
				}else{
					Reporters.failureReport("Verify the Titles are correct", "The titles are not matched with each other <br> Actual Title is : "+actTitle1+" <br> Expected title is : "+expTitle1);	
				}
			}*/
			/*String actTitle1=getText(ElsevierObjects.Admin_Evolve_Ecom_Confirmtitle1, "");
			String actTitle2=getText(ElsevierObjects.Admin_Evolve_Ecom_Confirmtitle2, "");
			String title2=titles.get(2).getText();
			String actTitle3=getText(ElsevierObjects.Admin_Evolve_Ecom_Confirmtitle3, "");*/



			//verifyText(ElsevierObjects.Admin_Evolve_Ecom_Confirmtitle1, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("PackageName"), "");
			//verifyText(ElsevierObjects.Admin_Evolve_Ecom_Confirmtitle2, EvolveCommonBussinessFunctions.title1, "");
			//verifyText(ElsevierObjects.Admin_Evolve_Ecom_Confirmtitle3, EvolveCommonBussinessFunctions.title1, "");
			/*Thread.sleep(medium);
		if(actTitle1.contains(expTitle1)){
			Reporters.SuccessReport("Verify the Titles are correct", "The titles are matched with each other <br> Actual Title is : "+actTitle1+" <br> Expected title is : "+expTitle1);	
		}else{
			Reporters.failureReport("Verify the Titles are correct", "The titles are not matched with each other <br> Actual Title is : "+actTitle1+" <br> Expected title is : "+expTitle1);	
		}
		Thread.sleep(medium);
		if(actTitle2.contains(expTitle2) || actTitle2.contains(expTitle3)){
			Reporters.SuccessReport("Verify the Titles are correct", "The titles are matched with each other <br> Actual Title is : "+actTitle2+" <br> Expected title is : "+expTitle2);	
		}else{
			Reporters.failureReport("Verify the Titles are correct", "The titles are not matched with each other <br> Actual Title is : "+actTitle2+" <br> Expected title is : "+expTitle2);	
		}
		Thread.sleep(medium);
		if(actTitle3.contains(expTitle3) || actTitle3.contains(expTitle2)){
			Reporters.SuccessReport("Verify the Titles are correct", "The titles are matched with each other <br> Actual Title is : "+actTitle3+" <br> Expected title is : "+expTitle3);	
		}else{
			Reporters.failureReport("Verify the Titles are correct", "The titles are not matched with each other <br> Actual Title is : "+actTitle3+" <br> Expected title is : "+expTitle3);	
		}*/
			Thread.sleep(medium);
			String orderNo=getText(ElsevierObjects.Admin_Evolve_Ecom_OrdNo, "Order Number");
			if(orderNo!=null){
				Reporters.SuccessReport("Order No.", "ÖrderNo. is : " +orderNo);
			}else{
				Reporters.failureReport("Order No.", "Örder is not submitted");
			}
			String billingAddress=getText(ElsevierObjects.Admin_Evolve_Ecom_Billing, "Billing Address");
			String shipping=getText(ElsevierObjects.Admin_Evolve_Ecom_Shipping, "Shipping Address");
			String creditCard=getText(ElsevierObjects.Admin_Evolve_Ecom_CreditCard, "");

			String billingAdd=readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("User_StreetAddress");
			if(billingAddress.contains(billingAdd)){
				Reporters.SuccessReport("Billing address", "Billing address is correct <br>"+billingAddress);
			}else{
				Reporters.failureReport("Billing address", "Billing address is not correct");
			}

			String shippingAdd=readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("User_StreetAddress");
			if(shipping.contains(shippingAdd)){
				Reporters.SuccessReport("Shipping address", "Shipping address is correct <br>"+shipping);
			}else{
				Reporters.failureReport("Shipping address", "Shipping address is not correct");
			}
			if(creditCard.equalsIgnoreCase("visa"))	{
				Reporters.SuccessReport("Credit card details", "Credit card details are correct");
			}else{
				Reporters.failureReport("Credit card details", "Credit card details are not correct");
			}

			List<WebElement> testdata= driver.findElements(ElsevierObjects.Admin_Evolve_Ecom_pricelist);

			String freeShip=testdata.get(0).getText();

			float freeShipping=Float.parseFloat(freeShip.replace("$", ""));

			String subTot=testdata.get(1).getText();
			float subTotal=Float.parseFloat(subTot.replace("$", ""));

			String disc=testdata.get(2).getText();
			float discount=Float.parseFloat(disc.replace("$", ""));

			String tax=testdata.get(3).getText();
			float taxpayable=Float.parseFloat(tax.replace("$", ""));

			String total=testdata.get(4).getText();
			float finalPrice=Float.parseFloat(total.replace("$", ""));

			//TODO change the decimal places to two digit

			float expected=freeShipping + subTotal-discount+taxpayable;
			DecimalFormat df = new DecimalFormat();
			df.setMaximumFractionDigits(2);
			String expPrice=df.format(expected);
			float actual=finalPrice;
			String actPri=df.format(actual);
			if(expPrice.contains(actPri)){
				Reporters.SuccessReport("Validate the sub total, discount/promotion, and total prices are all calculated as expected", "the sub total, discount/promotion, and total prices are all calculated as expected <br> The Actual Total Price is : "+expected+"<br> The Expected price is : "+actual);
			}else{
				Reporters.failureReport("Validate the sub total, discount/promotion, and total prices are all calculated as expected", "prices are not as expected.");
			}

			/* for (int i = 0; i < testdata.size(); i++) {
	    	 String data=testdata.get(i).getText();
	    	 String price=data.replace("$", "");
	    	 priceValue=Float.parseFloat(price); 
	    	 System.out.println(priceValue);
	     }

			 */
			// System.out.println(data);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	//TODO 
	//validation step 8 Need to do
	public static boolean myEvolveLink() throws Throwable{
		boolean flag=true;
		try{
			if(javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				Reporters.SuccessReport("Click on the My Evolve link", "Successfully Clicked on the My Evolve link");
			}else{
				Reporters.failureReport("Click on the My Evolve link", "Failed to Click on the My Evolve link");
			}
			String globalCourseID=getText(By.xpath(".//*[@id='set']/li[2]//div[contains(@class,'item platform_product')]/span[contains(@class,'resource info')]"), "");
			String globalCourseTitle=getText(By.xpath(".//*[@id='set']/li[2]//div[contains(@class,'item platform_product')]/span[contains(@class,'resource info')]//following-sibling::*"), "");
			/*String expTitle3=EvolveCommonBussinessFunctions.title2;
			if(globalCourseTitle.contains(expTitle3)){*/
			//String expTitle3=EvolveCommonBussinessFunctions.title2;
			if(globalCourseTitle!=null){
				System.out.println("title is present");
				Reporters.SuccessReport("User should see a link in their content list for the global course", "User can see a link in their content list for the global course : "+globalCourseTitle);
			}else{
				System.out.println("no course id present");
				Reporters.failureReport("User should see a link in their content list for the global course", "User is not able to see a link in their content list for the global course : "+globalCourseTitle);
			}
		}catch(Exception e){
			System.out.println(sgErrMsg);return false;
		}
		return flag;
	}




	/** Enter the Shipping Details. 
	 * 
	 * @return
	 * @throws Throwable
	 */
	public static boolean shippingAddress() throws Throwable{
		boolean flag = true;
		try{			
			if(!type(ElsevierObjects.evolve_User_street,readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("User_StreetAddress"),"Enter user street address")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.evolve_User_City,readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("User_City"),"Enter user city name")){
				flag=false;
			}
			if(!selectByVisibleText(ElsevierObjects.evolve_User_State,readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("User_State"),"Enter user state name")){
				flag=false;
			}
			if(!type(ElsevierObjects.evolve_User_Postal,readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("User_Zip"),"Enter User Postal code")){
				flag=false;
			}
			if(!switchToFrameByLocator(ElsevierObjects.Student_register_frame, "Switch to frame")){
				flag=false;
			}
			if(!click(ElsevierObjects.Student_register_UseAdress_btn,"Click on use this address button")){
				flag=false;
			}
			Thread.sleep(medium);
		}catch (NoSuchElementException e1) {
			System.out.println("'Main Page' link is not displayed.");
			//Note: Don't make "flag=false;" in 'catch' block, since application display's 'Main Page' links only some times.
		}
		return flag;
	}


}

