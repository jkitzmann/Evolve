package com.cigniti.automation.BusinessFunctions;


import java.util.Arrays;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;


public class AR_BusinessFunction extends EvolveCommonBussinessFunctions
{


	// Add a product to Cart...
			public static boolean addToCart() throws Throwable{
			try{
				boolean flag = true;
				Thread.sleep(high);
				if(!click(ElsevierObjects.btnaddtocart, "Click on request this product")){
					flag = false;
				}
				try{
					driverwait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='cboxClose']")));
					ImplicitWait();
					if(driver.findElement(By.xpath("//div[@id='cboxClose']")).isDisplayed()){
						if(!switchToFrameByLocator(ElsevierObjects.frame,"framename")){
							flag = false;
						}
						if(!waitForElementPresent(ElsevierObjects.evolvebutton,"Evolve button")){
							flag = false;
						}
						if(!click(ElsevierObjects.apply, "Apply button")){
							flag = false;
						}
						if(!switchToDefaultFrame()){
							flag = false;
						}
						Thread.sleep(medium);
					}
				}
				catch(Exception e){sgErrMsg=e.getMessage(); return false;}
				Thread.sleep(high);
				try{
				price=getText(ElsevierObjects.price, "price");
			//	String TotalPrice=driver.findElement(By.xpath(".//td[@class='totalamount strong']")).getText();
				expectedPrice="$0.00";
				//Thread.sleep(medium);
				
				if(price.contains(expectedPrice)){
					if(!click(ElsevierObjects.checkout, "Redeem Checkout")){
						sgErrMsg="Failed to Click on Checout button , Please check the object repository or run the test again";
						flag = false;
					}
					return flag;
				}
				return flag;}catch(Exception e){sgErrMsg="Current Values is $0.00 or Due to:"+e;return false;}
			}
			catch(Exception e){
				sgErrMsg=e.getMessage();return false;
			}
			}
		
			public static boolean studentLogin(String Username,String Password) throws Throwable{
				boolean flag = true;
				try{
					if(!type(ElsevierObjects.existingLogin_username,Username, "Student Name")){
						flag = false;
					}
					if(!type(ElsevierObjects.existingLogin_password, Password, "Password")){
						flag = false;
					}
					if(!click(ElsevierObjects.educator_btnLogin,"Clicked On login")){
				   		 flag = false;
				   	 }
					/*if(!click(ElsevierObjects.educator_chkInstution,"Clicked On Checkbox")){
				   		 flag = false;
				   	 }
					if(!click(ElsevierObjects.educator_form_btnContinue,"Clicked on Continue Button")){
			   		 	flag = false;
			   	 	 }*/
				}
				catch(Exception e){
					sgErrMsg=e.getMessage();return false;
				}
				return flag;
			}
			public static boolean educatorlogin(String Username,String Password) throws Throwable{
				
				Thread.sleep(veryhigh);
				
				boolean flag = true;
			try{	
				if(!type(ElsevierObjects.existingLogin_username, Username, "User Name")){
					flag = false;
				}
				if(!type(ElsevierObjects.existingLogin_password,  Password, "Password")){
					flag = false;
				}
				if(!click(ElsevierObjects.educator_btnLogin,"Clicked On login")){
			   		 flag = false;
			   	 }
				/*if(!click(ElsevierObjects.educator_chkInstution,"Clicked On Checkbox")){
			   		 flag = false;
			   	 }
				if(!click(ElsevierObjects.educator_form_btnContinue,"Clicked on Continue Button")){
		   		 	flag = false;
		   	 	 }*/
			}
			catch(Exception e){
				sgErrMsg=e.getMessage();return false;
			}
				return flag;
			}
			

			public static boolean instructorLogin(String Username,String Password) throws Throwable{
				boolean flag = true;
				try{
					driver.manage().deleteAllCookies();
					driver.navigate().refresh();	
					if(!launchUrl(configProps.getProperty("URL3"))){
						flag = false;
					}
					driver.manage().deleteAllCookies();
					driver.navigate().refresh();
					/*if(!clickOnMainPageLink()){
						flag=false;
					}
					Thread.sleep(medium);
					if(!click(ElsevierObjects.iameducator, "Clicked on Educator")){
						flag = false;
					} 
					 */
					if(!javaClick(ElsevierObjects.login, "login link")){
						flag = false;
					} 
					Thread.sleep(medium);
					if(!type(ElsevierObjects.email,Username,"User Name")){
						flag = false;
					}
					if(!type(ElsevierObjects.password,Password, "UserPassword")){
						flag = false;
					}
					Thread.sleep(medium);
					if(click(ElsevierObjects.submit, "login submit")){
						Reporters.SuccessReport("Log into evolvecert.elsevier.com as any previously used faculty user", "Successfully Logged into evolvecert.elsevier.com as any previously used faculty user <br> Username : "+configProps.getProperty("MailUserName")+"<br> Password : "+configProps.getProperty("MailpassWord"));
					}else{
						Reporters.failureReport("Log into evolvecert.elsevier.com as any previously used faculty user", "Failed to Log into evolvecert.elsevier.com as any previously used faculty user <br> Username : "+configProps.getProperty("MailUserName")+"<br> Password : "+configProps.getProperty("MailpassWord"));
					}
					Thread.sleep(medium);
				}catch(Exception e){
					System.out.println(e.getMessage());
					sgErrMsg=e.getMessage();return false;
				}
				return flag;
			}

	public static boolean addToCartStudent() throws Throwable{
				
				boolean flag = true;
			
				
				try{
					Thread.sleep(high);
					
					if(!click(ElsevierObjects.btnaddtocart, "Click on request this product")){
						flag = false;
					}
				//	driverwait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='cboxClose']")));
				//	ImplicitWait();
					if(driver.findElement(By.xpath("//div[@id='cboxClose']")).isDisplayed()){
						if(!switchToFrameByLocator(ElsevierObjects.frame,"framename")){
							flag = false;
						}
						if(!waitForElementPresent(ElsevierObjects.evolvebutton,"Evolve button")){
							flag = false;
						}
						if(!click(ElsevierObjects.apply, "Apply button")){
							flag = false;
						}
						if(!switchToDefaultFrame()){
							flag = false;
						}
						Thread.sleep(medium);
					}
				}
				catch(Exception e){ return false;}
				Thread.sleep(high);
				try{
				By Totalresult=By.xpath(".//*[@id='pageLayout-body-inner-most']//td[@class='totallabel']/following-sibling::td");
				price=getText(Totalresult, "price");
			//	String TotalPrice=driver.findElement(By.xpath(".//td[@class='totalamount strong']")).getText();
				//expectedPrice="$0.00";
				//Thread.sleep(medium);
				
				//if(price.contains(expectedPrice))
				
					if(!click(ElsevierObjects.checkout, "Redeem Checkout")){
						sgErrMsg="Failed to Click on Checout button , Please check the object repository or run the test again";
						flag = false;
					}
					return flag;
				
				//return flag;
				}catch(Exception e){sgErrMsg="Current Values is $0.00 or Due to:"+e;return false;}
			}
	
	//Review And Submit for educator......
			public static boolean reviewAndSubmit() throws Throwable{
				
				try
				{
				boolean flag = true;
				Thread.sleep(medium);
				sgErrMsg="";
				if(!click(ElsevierObjects.checkbox1, "registered"))
				{
					sgErrMsg="'Yes, I am an instructor' Check box is not appeared";
					flag = false;
				}
				
				Thread.sleep(medium);
				if(!click(ElsevierObjects.checkbox2, "instructor")){
					sgErrMsg ="'Yes, I accept the Registered User Agreement' Check box is not appeared";
					flag = false;
				}

				price=getText(ElsevierObjects.price, "price");
				expectedPrice="$0.00";
				Thread.sleep(medium);
				if(price.contains(expectedPrice)){
					Thread.sleep(medium);
					if(!click(ElsevierObjects.submitbutton, "submit at final")){
						flag = false;
						Thread.sleep(veryhigh);
					}
					Thread.sleep(medium);
				}
			    
				Ordernumber =driver.findElement(By.xpath(".//*[@id='pageLayout-body-inner-most']//div[@class='sidebar-list rounded']//h4/following-sibling::div")).getText();
				Thread.sleep(high);
				return flag;
				}catch(Exception e){sgErrMsg="Review Submit failed due to"+e;return false;}
			}

		public static boolean reviewAndSubmit_Student() throws Throwable{
				
				try
				{boolean flag = true;
				Thread.sleep(medium);
				
				if(isElementPresent(ElsevierObjects.CreditCardNum)){
					creditCardDetails();
					
					if(!click(ElsevierObjects.checkbox1, "registered")){
						sgErrMsg="'Yes, I accept the Registered User Agreement' Check box is not appeared";
						flag = false;
					}
					
					if(isElementPresent(ElsevierObjects.checkbox2)){
						sgErrMsg="'Yes, I am instructor' Check box is not appeared";
						flag = false;
					}
					
					Thread.sleep(medium);
				}
				
				else{
					if(!click(ElsevierObjects.checkbox1, "registered")){
						sgErrMsg="'Yes, I accept the Registered User Agreement' Check box is not appeared";
						flag = false;
					}
					
					if(isElementPresent(ElsevierObjects.checkbox2)){
						sgErrMsg="'Yes, I am instructor' Check box is not appeared";
						flag = false;
					}
					
					Thread.sleep(medium);
					
					By CVV=By.xpath(".//*[@id='checkout-cvv']");
					type(CVV,"123","CVV Details");
				}
				
				if(!click(ElsevierObjects.submitbutton, "submit at final")){
					flag = false;
					Thread.sleep(veryhigh);
				}
				
			    Thread.sleep(veryhigh);
				Ordernumber =driver.findElement(By.xpath(".//*[@id='pageLayout-body-inner-most']//div[@class='sidebar-list rounded']//h4/following-sibling::div")).getText();
				Thread.sleep(high);
				return flag;
				}catch(Exception e){sgErrMsg="Review Submit failed due to"+e;return false;}
			}

		public static boolean reviewAndSubmit_NewStudent() throws Throwable{
			
			try
			{boolean flag = true;
			Thread.sleep(medium);
			if(!click(ElsevierObjects.checkbox1, "registered")){
				sgErrMsg="'Yes, I am an instructor' Check box is not appeared";
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.submitbutton, "submit at final")){
				flag = false;
				Thread.sleep(medium);
		
		}
	
			Thread.sleep(high);
		    
			Ordernumber =driver.findElement(By.xpath(".//*[@id='pageLayout-body-inner-most']//div[@class='sidebar-list rounded']//h4/following-sibling::div")).getText();
			Thread.sleep(high);
			return flag;
			}catch(Exception e){sgErrMsg="Review Submit failed due to"+e;return false;}
		}
	
			//Click on the Adoption Request Link
			public static boolean clickAdoptionRequest(String username) throws Throwable{
				try{
				boolean flag=true;
				Thread.sleep(medium);
				if(!click(ElsevierObjects.searchAR,"Adoption Requests"))
				{
					flag = false;
				}
				
				
				selectByVisibleText(ElsevierObjects.selectdays, "Today", "Select Today's locator");
				
				if(!waitForElementPresent(ElsevierObjects.btndatesearch_AR, "search button")){
					flag = false;
				}
				
				Thread.sleep(medium);
				if(!click(ElsevierObjects.btndatesearch_AR, "ToDay date Radio button")){
					flag = false;
				}
				Thread.sleep(medium);
				
				/*if(type(ElsevierObjects.Adoption_userId, username, "Adoption search User Id")){
				   Reporters.SuccessReport("Entering UserID In Search Results Page..", "Successfully Entered UserID:"+getAccountDetailsUserName);
			   }
			   else{
				   Reporters.failureReport("Entering UserID In Search Results Page..", "Failed Enter UserID:"+getAccountDetailsUserName);
			   }*/
				if(!click(ElsevierObjects.Searchon, "search button")){
					flag = false;
				}
			Thread.sleep(veryhigh);
				/*if(!waitForElementPresent(ElsevierObjects.lnkorderedAR, "order AR")){
					flag = false;
				}*/
				return flag;
				}catch(Exception e){sgErrMsg=e.getMessage();return false;}
			}
			public static boolean VerifyContentByUsingHeadertitleforTableandclick(By locator,String[] Headers,String[] Values) throws Throwable  
			{


				try
				{
					Thread.sleep(veryhigh);
				    Thread.sleep(veryhigh);
				    Thread.sleep(veryhigh);
				    Thread.sleep(veryhigh);
				String str1=driver.findElement(By.xpath(".//*[@id='resultTable']//tbody//tr[1]//td//div[@id='name']")).getText();
				String str2=driver.findElement(By.xpath(".//*[@id='resultTable']//tbody//tr[1]//td//div[@id='status']")).getText();
				if((str1.equals(Values[0])) && (str2.equals(Values[1])))
				{
					driver.findElement(By.xpath(".//*[@id='resultTable']//tbody//tr[1]//td//div[@id='status']")).click();
					return true;
				
				}
				else
				{
				return false;
				}
				}catch(Exception e){sgErrMsg="The Values: "+Arrays.toString(Values)+"are not matching"+e; return false;}
									
				
				
				
		}
			
			public static boolean VerifyNoContent(By locator,String[] Headers,String[] Values) throws Throwable  
			{


				try
				{
			    Thread.sleep(veryhigh);
			    Thread.sleep(veryhigh);
			 //   Thread.sleep(veryhigh);
			   // Thread.sleep(veryhigh);
			    
			    if(isElementPresent(By.xpath(".//*[@id='resultTable']//tbody")))
			    {
				String str1=driver.findElement(By.xpath(".//*[@id='resultTable']//tbody//tr[1]//td//div[@id='name']")).getText();
				String str2=driver.findElement(By.xpath(".//*[@id='resultTable']//tbody//tr[1]//td//div[@id='status']")).getText();
				if((str1.equals(Values[0])) && (str2.equals(Values[1])))
				{
					return false;
				
				}
				else
				{
				return true;
				}
			    }
			    
			    //if(isElementPresent(By.partialLinkText("No adoptions")))
			    if(isElementPresent(By.xpath(".//*[@id='pageBody']//p//b[contains(text(),'No adoptions')]")))
			    {
			    return true;	
			    }
			    else
			    {
			    	return false;
			    }
			    
			    		    
			    
				}catch(Exception e){sgErrMsg="The Values: "+Arrays.toString(Values)+"are not matching or No Results Found"+e	; return false;}
									
				
				
				
		}
			
			public static boolean verifyAdoptionRequestpage(String ISBN,String LoValue,String Firstname,String Lastname) throws Throwable{
				try
				{
			
		          String Format=driver.findElement(By.xpath(".//tr//td[contains(text(),'Format')]/following-sibling::td")).getText();
		          String Firstname_actual=driver.findElement(By.xpath(".//tr//td[contains(text(),'First Name')]/following-sibling::td")).getText();
		          String Lastname_actual=driver.findElement(By.xpath(".//tr//td[contains(text(),'Last Name')]/following-sibling::td")).getText();
					
					if((isVisible(By.xpath(".//*[@id='adoptionReqDetails']/table/tbody//div[contains(text(),'"+ISBN+"')]"), "ISBN not avilable"))||LoValue.equals(Format)||Firstname.equalsIgnoreCase(Firstname_actual )||Lastname.equals(Lastname_actual))
					{				
					    sActualValues ="ISBN Value is :"+ISBN+"</br> Format Displayed is:"+Format+"</br> Last Name Displayed is:"+Lastname_actual+"</br> First Name Displayed is:"+Firstname_actual;
						return true;
					
					}
					sActualValues ="ISBN Value is :"+ISBN+"</br> Format Displayed is:"+Format+"</br> Last Name Displayed is:"+Lastname_actual+"</br> First Name Displayed is:"+Firstname_actual;
					sgErrMsg="The Value are not Present in the Adoption Request Detailed Page";
					return false;		}
				catch(Exception e)
				{
					sgErrMsg=e.getMessage();
					return false;
					}
			
				}
			public static boolean ClickonAR() throws Throwable  
				{
				try{
					By e=By.xpath(".//*[@id='resultTable']//tbody//tr[1]//td[@headers='AR']");
					if(!click(e, "Credit Card Submit"))
					{return false;					}
					return true;
				}
			catch(Exception e)
			{
				sgErrMsg=e.getMessage();
				return false;
			}
			}
			
			public static boolean getUsernameandDetails() throws Throwable{
				try
				{
				boolean flag=true;

				if(!click(ElsevierObjects.myAccount,"click on my account")){
					flag=false;
				}
				Thread.sleep(high);
				if(!click(ElsevierObjects.myAccount_AccountSettings,"click on account settings.")){
					flag=false;
				}
				Thread.sleep(medium);
				//String firstName=getText(ElsevierObjects.educator_form_txtFirstName, "Get first name");

				getAccountDetailsUserName =getAttribute(ElsevierObjects.educator_form_UserName, "value", "User Name");
				getAccountDetailsFirstName=getAttribute(ElsevierObjects.educator_form_txtFirstName, "value", "Get first name");
				getAccountDetailsLastName=getAttribute(ElsevierObjects.educator_form_txtLastName,"value","Get Last Name");
				return flag;
				}catch(Exception e){sgErrMsg=e.getMessage();
				return false;}
			}

			public static boolean UpdateAccountDetails(String EvolveId,String Firstname,String Lastname,String Password,String Emailid,String Instution,String Mobile,String Address1,String Address2,String Country,String State,String City,String ZipCode,String Program) throws Throwable{
				boolean flag=true;
			    b=true;
				try{

					type(ElsevierObjects.User_form_txtFirstName, Firstname, "first name");
					type(ElsevierObjects.User_form_txtLastName,Lastname,"Last Name");
					type(ElsevierObjects.User_form_txtEmail,Emailid,"email id");
					type(ElsevierObjects.User_form_txtConformEmail,Emailid,"Confirm email id");
					type(ElsevierObjects.User_form_password,Password,"Password");
					type(ElsevierObjects.User_form_Confpassword,Password,"Password");
					//click(ElsevierObjects.User_form_ddInstutionCountry, "Country");
					//Thread.sleep(low);
					//driver.findElement(By.xpath(".//*[@id='institution-country']/option[contains(text(),'"+Country+"')]")).click();
					//Country="US";
			        Thread.sleep(low);

					selectByVisibleText(ElsevierObjects.User_form_ddInstutionCountry,Country, "Institution country");
			        Thread.sleep(low);
			        //driver.findElement(ElsevierObjects.User_form_ddInstutionCountry).sendKeys(Keys.ENTER);
			        //click(ElsevierObjects.User_form_State, "State");
			        selectByVisibleText(ElsevierObjects.User_form_State,State, "Institution state");
			        //driver.findElement(ElsevierObjects.User_form_State).sendKeys(Keys.ENTER);				
					type(ElsevierObjects.User_form_City,City, "Street Adress");
					driver.findElement(ElsevierObjects.User_form_City).sendKeys(Keys.TAB);
					Thread.sleep(low);

					type(ElsevierObjects.User_form_txtInstution, Instution,"Institution name");
			        Thread.sleep(low);

					type(ElsevierObjects.User_form_txtAddPhone,Mobile,"phone number");
			        Thread.sleep(low);
				
					type(ElsevierObjects.User_form_txtAddress1,Address1, "Street Adress1");
			        Thread.sleep(low);

					type(ElsevierObjects.User_form_txtAddress2,Address2, "Street Adress2");
			        Thread.sleep(low);
    
					type(ElsevierObjects.User_form_txtAddPostalCode,ZipCode, "Enter Postal Code");
			        Thread.sleep(low);

			        selectBySendkeys(ElsevierObjects.User_form_txtddprogramType,Program, "Program type");
			        
					Thread.sleep(medium);
					if(!click(ElsevierObjects.User_form_btnContinue,"Click on my Submit")){
						flag=false;
					}
					b=false;
					Thread.sleep(medium);
				}
				catch(Exception e){sgErrMsg="The Values are Not Submitted"+e;
					System.out.println(e.getMessage());return false;
				}
				return flag;
			}
			public static boolean isElementPresent_AR(By by, String locatorName)
					throws Throwable {
				boolean flag=false;	
				try {
					driver.findElement(by);
					flag = true;
					return true;
				} catch (Exception e) {
					sgErrMsg=e.getMessage();
					System.out.println(e.getMessage());
					return false;
				} 
			}
			public static boolean UpdateAccountDetails_Student(String EvolveId,String Firstname,String Lastname,String Password,String Emailid,String Instution,String Mobile,String Address1,String Address2,String Country,String State,String City,String ZipCode,String Program,String Year) throws Throwable{
				boolean flag=true;
			    b=true;
				try{

                    //driver.switchTo().defaultContent();
					type(ElsevierObjects.User_form_txtFirstName, Firstname, "first name");
					type(ElsevierObjects.User_form_txtLastName,Lastname,"Last Name");
					type(ElsevierObjects.User_form_txtEmail,Emailid,"email id");
					type(ElsevierObjects.User_form_txtConformEmail,Emailid,"Confirm email id");
					type(ElsevierObjects.User_form_password,Password,"Password");
					type(ElsevierObjects.User_form_Confpassword,Password,"Confirm Password");
					Thread.sleep(low);
					//driver.findElement(By.xpath(".//*[@id='institution-country']/option[contains(text(),'"+Country+"')]")).click();
					//click(ElsevierObjects.User_form_ddInstutionCountry, "Country");
					//Thread.sleep(low);
					//Country="US";
					selectByVisibleText(ElsevierObjects.User_form_ddInstutionCountry,Country, "country of institution.");
			        Thread.sleep(low);
			        //driver.findElement(ElsevierObjects.User_form_ddInstutionCountry).sendKeys(Keys.ENTER);
			        //click(ElsevierObjects.User_form_State, "State");
			        selectByVisibleText(ElsevierObjects.User_form_State,State, "Select State institution.");
			        //driver.findElement(ElsevierObjects.User_form_State).sendKeys(Keys.ENTER);	
					type(ElsevierObjects.User_form_City,City, "Get Street Adress");
					driver.findElement(ElsevierObjects.User_form_City).sendKeys(Keys.TAB);
					Thread.sleep(low);

					type(ElsevierObjects.User_form_txtInstution, Instution,"Institution name");
			        Thread.sleep(low);
                    By GradYear=By.xpath(".//*[@id='select-graduation-year']");
					//type(	ElsevierObjects.User_form_txtAddPhone,Mobile,"phone number");
			        Thread.sleep(low);
//			        Year="2014";
			        selectByVisibleText(GradYear,Year, "country of institution");
			        selectBySendkeys(ElsevierObjects.User_form_txtddprogramType,Program, "country of institution.");
			        
					type(ElsevierObjects.BillingAddress1,Address1, "Street Adress1");
			        Thread.sleep(low);

					type(ElsevierObjects.BillingAddress2,Address2, "Street Adress2");
			        Thread.sleep(low);

					click(ElsevierObjects.BillingAddressState, "State");
			        selectByVisibleText(ElsevierObjects.BillingAddressState,State, "Select State institution.");
			        //driver.findElement(ElsevierObjects.BillingAddressState).sendKeys(Keys.ENTER);
					type(ElsevierObjects.BililngCity,City, "City  Adress");
 
					type(ElsevierObjects.BililngPostalCode ,ZipCode, "Postal Code");
			        Thread.sleep(low);
					Thread.sleep(medium);
					if(!click(ElsevierObjects.User_form_btnContinue,"Click on my Submit")){
						flag=false;
					}
					Thread.sleep(veryhigh);
					Thread.sleep(veryhigh);
					b=false;
				  if(isElementPresent_AR(ElsevierObjects.Student_register_frame, "Studentframe"))
						
				  {
				  //   driver.switchTo().frame(0);
					if(!switchToFrameByLocator(ElsevierObjects.Student_register_frame, "Switch to frame")){
						flag=false;
					}
					By Usethisaddress=By.xpath("html/body/div[3]/p[3]/button[1]");
					click(Usethisaddress,"Use this address");
				 }
					b=false;
					Thread.sleep(medium);
				}
				catch(Exception e){sgErrMsg="The Values are Not Submitted"+e;
					System.out.println(e.getMessage());return false;
				}
				return flag;
			}
}



