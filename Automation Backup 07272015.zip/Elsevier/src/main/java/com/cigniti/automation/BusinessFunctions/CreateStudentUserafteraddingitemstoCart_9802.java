package com.cigniti.automation.BusinessFunctions;

import org.openqa.selenium.Keys;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class CreateStudentUserafteraddingitemstoCart_9802 extends EvolveCommonBussinessFunctions {
	public static String isbn;
	public static String Firstname;
	public static String Lastname;
	public static String EmailId;
	public static String Password;
	public static String ConformPassword;
	public static String Country;
	public static String State;
	public static String City;
	public static String Institution;
	public static String StreetAddress;
	public static String Zipcode;
	public static String ProgramType;
	public static String Year;
	public static String username;
	public static String CityAddress;
	public static String StateAddress;
	public static String price;
	public static String PbcISBN;
	public static String Pbctitle;
	public static String PbcTotal;
	
	public static boolean Studentcreateafteraddingcart() throws Throwable{
		boolean flag = true;
		try
			{
		 
			 launchUrl(configProps.getProperty("URL4"));
			 Thread.sleep(medium);
			 /*click(ElsevierObjects.Simulation_courses,"Click on simulation courses");
			 Thread.sleep(low);*/
			 type(ElsevierObjects.Search_Online_Courses,isbn,"Enter the isbn number in the searchbox");
			 Thread.sleep(medium);
			 click(ElsevierObjects.Search_Button,"Click on search button");
			 Thread.sleep(medium);
			 price = getText(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomprice,"Get the price present there");
			 float p=convertStringToPrice(price);
			 float e=convertStringToPrice(ExpectedPrice);
			 if(p>e){
				   Reporters.SuccessReport("Verify price of the product","Price of The Product Is Greater Than Zero in product page:"+p);
			  }else{
				   Reporters.failureReport("Verify price of the product","Failed to verify Price of The Product.");
			  }
			 Thread.sleep(medium);
			 
			 click(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomAddtoCart,"Click on Request this product now button");
			 Thread.sleep(medium);
			 if(isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MyCartTitle,"Check Mycart title")){
				 Reporters.SuccessReport("Verify MyCart title", "MyCart title is present");
			 }else{
				 Reporters.failureReport("Verify MyCart title", "MyCart title is not present");
			 }
			 Thread.sleep(low);
			 Pbctitle = getText(ElsevierObjects.Pbc_title,"Get title of the product");
			 Reporters.SuccessReport("Verify the title of the product","Title of the product is verified and title is :"+Pbctitle);
			 Thread.sleep(low);
			 PbcISBN = getText(ElsevierObjects.Pbc_Isbn_number,"Get the ISBN number present there");
			 Reporters.SuccessReport("Verify the ISBN of the product","ISBN of the product is verified and ISBN is :"+PbcISBN);	  
			 Thread.sleep(low);
			 String Pbcprice = getText(ElsevierObjects.Pbc_price,"Get the price present there");
			 if(price.contains(Pbcprice)){
				 Reporters.SuccessReport("Verify price of the product","Prices are compared successfully :<br> Expected Price is : "+Pbcprice+"<br> Actual price is:"+price);
			 }else{
				 Reporters.failureReport("Verify price of the product","Prices comparison is failed :<br> Expected Price is:  "+Pbcprice+ "<br> Actual price is:"+price);
			 }
			 Thread.sleep(low);
			 Reporters.SuccessReport("Verify price of product","Price is Greater than ZERO");
			 click(ElsevierObjects.Hesi_Student_Reedembutton,"Click on Reedem/Checkout button");
			 Thread.sleep(medium);
		 }
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}	
	return flag;
	}	 
	public static boolean Registeringdetails() throws Throwable{
		 boolean flag = true;
		try
	    {
		
		 String h = ReadingExcel.columnDataByHeaderName("h","TC-15588",configProps.getProperty("TestData"));
		 String header =getText(ElsevierObjects.Admin_Evolve_Ecom_NewToEvolve,"Get the header in the page");
		 if(h.contains(header)){
			 Reporters.SuccessReport("Verify the header of the page","Successfully headers are verified :<br>Expected header is :"+header+"<br> Actual header is :"+h);
		 }else{
			 Reporters.failureReport("Verify the header of the page","Failed to verify the headers :<br>Expected header is :"+header+"<br> Actual header is :"+h);
		 }
		 Thread.sleep(low);
		 String h1 = ReadingExcel.columnDataByHeaderName("h1","TC-15588",configProps.getProperty("TestData"));
		 String header1=getText(ElsevierObjects.Header1,"Get the Section in the page");
		 if(h1.contains(header1)){
			 Reporters.SuccessReport("Verify the Section of the page","Section is verified Successfully :<br>Expected Section is :"+header1+"<br> Actual Section is :"+h1);
		 }else{
			 Reporters.failureReport("Verify the Section of the page","Failed to verify the Section :<br>Expected Section is :"+header1+"<br> Actual Section is :"+h1);
		 }
		 Thread.sleep(low);
		 String h2 = ReadingExcel.columnDataByHeaderName("h2","TC-15588",configProps.getProperty("TestData"));
		 String header2 = getText(ElsevierObjects.Header2,"Get the Section in the page");
		 if(h2.contains(header2)){
			 Reporters.SuccessReport("Verify the Section of the page","Section is verified Successfully :<br>Expected Section is :"+header2+"<br> Actual Section is :"+h2);
		 }else{
			 Reporters.failureReport("Verify the Section of the page","Failed to verify the Section :<br>Expected Section is :"+header2+"<br> Actual Section is :"+h2);
		 }
		 Thread.sleep(low);
		 String h3 = ReadingExcel.columnDataByHeaderName("h3","TC-15588",configProps.getProperty("TestData"));
		 String header3 = getText(ElsevierObjects.Header3,"Get the Section in the page");
		 if(h3.contains(header3)){
			 Reporters.SuccessReport("Verify the Section of the page","Section is verified Successfully :<br>Expected Section is :"+header3+"<br> Actual Section is :"+h3);
		 }else{
			 Reporters.failureReport("Verify the Section of the page","Failed to verify the Section :<br>Expected Section is :"+header3+"<br> Actual Section is :"+h3);
		 }
		 Thread.sleep(low);
		 if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
			 Reporters.SuccessReport("Click on continue","Fields are left blank and clicked on continue button");
		 }else{
			 Reporters.failureReport("Click on continue","Failed to click on continue button");
		 }
		 Thread.sleep(low);
		 String Err =ReadingExcel.columnDataByHeaderName("Err","TC-15588",configProps.getProperty("TestData"));
		 // was createNewAccnt_EmptyField_Error
		 String error = getText(ElsevierObjects.registration_form_error,"Get error message");
		 if(Err.trim().contains(error.trim())){
			 Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully  :<br>Expected Error is :"+error+"<br> Actual Error is :"+Err);
		 }else{
			 Reporters.failureReport("Verify the Error in the page","Failed to verify the Errors :<br>Expected Error is :"+error+"<br> Actual Error is :"+Err);
		 }
		 Thread.sleep(low);
		 type(ElsevierObjects.educator_form_txtFirstName,Firstname,"Enter Firstname in the textbox");
		 Thread.sleep(low);
		 type(ElsevierObjects.educator_form_txtLastName,Lastname,"Enter Lastname in the textbox");
		 Thread.sleep(low);
		 type(ElsevierObjects.educator_form_txtEmail,EmailId,"Enter Email in the textbox");
		 Thread.sleep(low);
		 if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
			 Reporters.SuccessReport("Enter and click","Details are entered Confirm Email, Password fields left blank and clicked on continue </br> Firstname :"+Firstname+"</br>"+"Lastname :"+Lastname+"</br>"+"Email :"+EmailId);
		 }else{
			 Reporters.failureReport("Enter and click","Failed to enter details and click on continue button");
		 }
		 Thread.sleep(low);
		 String Err1 = ReadingExcel.columnDataByHeaderName("Err1","TC-15588",configProps.getProperty("TestData"));
		 // was createNewAccnt_EmptyField_Error
		 String error1 = getText(ElsevierObjects.registration_form_error,"Get error message");
		 if(Err1.contains(error1)){
			 Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully :<br>Expected Error is :"+error1+"<br> Actual Error is :"+Err1);
		 }else{
			 Reporters.failureReport("Verify the Error in the page","Failed to verify the errors :<br>Expected Error is :"+error1+"<br> Actual Error is :"+Err1);
		 }
		 Thread.sleep(low);
		 type(ElsevierObjects.educator_form_txtConformEmail,EmailId,"Enter Conform Email in the textbox");
		 Thread.sleep(low);
		 if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
			 Reporters.SuccessReport("Enter and click","Details are entered and Password field left blank and clicked on continue </br>"+"Confirm Email :"+EmailId);
		 }else{
			 Reporters.failureReport("Enter and click","Failed to enter details and click on continue button");
		 }
		 Thread.sleep(low);
		 String Err2 =ReadingExcel.columnDataByHeaderName("Err2","TC-15588",configProps.getProperty("TestData"));
		 // was createNewAccnt_EmptyField_Error
		 String error2 = getText(ElsevierObjects.registration_form_error,"Get error message");
		 if(Err2.contains(error2)){
			 Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully :<br>Expected Error is :"+error2+"<br> Actual Error is :"+Err2);
		 }else{
			 Reporters.failureReport("Verify the Error in the page","Failed to verify the errors :<br>Expected Error is :"+error2+"<br> Actual Error is :"+Err2);
		 }
		 Thread.sleep(low);
		 type(ElsevierObjects.educator_form_txtPassword,Password,"Enter Password in the textbox");
		 Thread.sleep(low);
		 type(ElsevierObjects.educator_form_txtConformPassword,ConformPassword,"Enter confirm Password in the textbox");
		 Thread.sleep(low);
		 if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
			 Reporters.SuccessReport("Enter and click","Details are entered and Entered different password and clicked on continue button </br>"+"Password :"+Password+"</br>"+"ConformPassword :"+ConformPassword);
		 }else{
			 Reporters.failureReport("Enter and click", "Failed to enter details and click on continue button");
		 }
		 Thread.sleep(low);
		 String Err3 = ReadingExcel.columnDataByHeaderName("Err3","TC-15588",configProps.getProperty("TestData"));
		 // was createNewAccnt_EmptyField_Error
		 String error3 =getText(ElsevierObjects.registration_form_error,"Get error message");
		 if(Err3.contains(error3)){
			 Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully :<br>Expected Error is :"+error3+"<br> Actual Error is :"+Err3);
		 }else{
			 Reporters.failureReport("Verify the Error in the page","Failed to verify the errors :<br>Expected Error is :"+error3+"<br> Actual Error is :"+Err3);
		 }
		 Thread.sleep(low);
	     type(ElsevierObjects.educator_form_txtPassword,Password,"Enter Password in the textbox");
		 Thread.sleep(low);
		 type(ElsevierObjects.educator_form_txtConformPassword,Password,"Enter Confirm Password in the textbox");
		 Thread.sleep(low);
		 if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
			 Reporters.SuccessReport("Enter and click","Details are entered and leave Institution details blank and clicked on continue button </br>"+"Password :"+Password+"</br>"+"ConfirmPassword :"+Password);
		 }else{
			 Reporters.failureReport("Enter and click","Failed to enter details and click on continue button");
		 }
		 Thread.sleep(low);
		 String Err4 = ReadingExcel.columnDataByHeaderName("Err4","TC-15588",configProps.getProperty("TestData"));
		 // was Error_msg1
		 String error4 = getText(ElsevierObjects.registration_form_error,"Get error message");
		 if(Err4.contains(error4)){
			 Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully :<br>Expected Error is :"+error4+"<br> Actual Error is :"+Err4);
		 }else{
			 Reporters.failureReport("Verify the Error in the page","Failed to verify the errors :<br>Expected Error is :"+error4+"<br> Actual Error is :"+Err4);
		 }
		 Thread.sleep(low);
		 selectByVisibleText(ElsevierObjects.Hesi_Student_country,Country,"Select Country Name from the list");
		 Thread.sleep(medium);
		 selectByVisibleText(ElsevierObjects.Hesi_Student_state,State,"Select State name from the list");
		 Thread.sleep(medium);
		 b= true;
		 if(selectBySendkeys(ElsevierObjects.Hesi_Student_City,City,"Enter City name")){
		    Reporters.SuccessReport("Get Cityname","Cityname is :" +City);
		 }else{
			 Reporters.failureReport("Get Cityname", "Failed to get cityname");
		 }
		 Thread.sleep(medium);
		 driver.findElement(ElsevierObjects.Hesi_Student_City).sendKeys(Keys.ENTER);
		 Thread.sleep(medium);
		 if(selectBySendkeys(ElsevierObjects.Hesi_Student_institute,Institution,"Enter Institute name")){
		    Reporters.SuccessReport("Get Institutename","Institutename is :" +Institution);
		 }else{
			Reporters.failureReport("Get Institutename", "Failed to get Institutename");
		 }
		 b=false;
		 Thread.sleep(medium);
		 selectByVisibleText(ElsevierObjects.educator_form_txtddprogramType,ProgramType,"Select programtype from list");
		 Thread.sleep(medium);
		 selectBySendkeys(ElsevierObjects.Hesi_Student_year,Year,"Select the year from the list");
		 Thread.sleep(medium);
		 if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
			 Reporters.SuccessReport("Enter and click","Details are entered and leave billing address blank and clicked on continue button </br>"+"Country :"+Country+"</br>"+"State :"+State+"</br>"+"City :"+City+"</br>"+"Institute :"+Institution+"</br>"+"Programtype :"+ProgramType+"<br>"+"Year :"+Year);
		 }else{
			 Reporters.failureReport("Enter and click","Failed to enter details anc click on continue button");
		 }
		 Thread.sleep(medium);
		 String Err5 =  ReadingExcel.columnDataByHeaderName("Err4","TC-15588",configProps.getProperty("TestData"));
		 // was Error_msg2
		 String error5 = getText(ElsevierObjects.registration_form_error,"Get error message");
		 if(Err5.contains(error5)){
			 Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully :<br>Expected Error is :"+error5+"<br> Actual Error is :"+Err5);
		 }else{
			 Reporters.failureReport("Verify the Error in the page","Failed to verify the errors :<br>Expected Error is :"+error5+"<br> Actual Error is :"+Err5);
		 }
		 Thread.sleep(low);
		 type(ElsevierObjects.student_billingAddress,StreetAddress,"Enter the Street Address in the box");
		 Thread.sleep(low);
	     type(ElsevierObjects.student_billingAddress_city,CityAddress,"Enter City in the textbox");
	     Thread.sleep(low);
	     selectByVisibleText(ElsevierObjects.student_billingAddress_state,StateAddress,"Enter State in the textbox");
	     Thread.sleep(low);
	     type(ElsevierObjects.student_billingAddress_zip,Zipcode,"Enter Zipcode in the textbox");
	     Thread.sleep(low);
	     Reporters.SuccessReport("Enter and click","billing address is entered successfully and Details entered in billing address:</br>"+"Street Address :"+StreetAddress+"</br>"+"CityAddress :"+CityAddress+"</br>"+"StateAddress :"+StateAddress+ "</br>"+"Zipcode :"+Zipcode);
	     click(ElsevierObjects.educator_form_btnContinue,"Click on continue button");
		 Thread.sleep(veryhigh);
		 Thread.sleep(veryhigh);
		 switchToFrameByLocator(ElsevierObjects.Admin_Evolve_Ecom_framename,"Switch to iframe");
		 Thread.sleep(low);
		 String Popupheader = ReadingExcel.columnDataByHeaderName("PopUp", "TC-15588",configProps.getProperty("TestData"));
		 String Popheader = getText(ElsevierObjects.Popup_header,"Get header of the frame");
		 if(Popheader.contains(Popupheader)){
			 Reporters.SuccessReport("Verify the header of Frame","PopupHeader is Successfully verified : </br> Expected Header is :"+Popheader+" </br> Actual Header is :"+Popupheader);
		 }else{
			 Reporters.failureReport("Verify the header of Frame","Failed to verify headers : </br> Expected Header is :"+Popheader+" </br> Actual Header is :"+Popupheader);
		 }
		 Thread.sleep(medium);
		 if(click(ElsevierObjects.Use_this_address,"Click on use this address")){
			 Reporters.SuccessReport("Click on Use this Address","Successfully clicked on Use this Address");
		 }else{
			 Reporters.failureReport("Click on Use this Address","Failed to click on Use this Address");
		 }
		 Thread.sleep(veryhigh);
		 String Creditheader = ReadingExcel.columnDataByHeaderName("Creditheader", "TC-15588",configProps.getProperty("TestData"));
		 String cardheader = getText(ElsevierObjects.Creditcard_header,"Get header of the Page");
		 if(cardheader.contains(Creditheader)){
			 Reporters.SuccessReport("Verify the header of page","Creditcard Header is Successfully verified : </br> Expected Header is :"+cardheader+" </br> Actual Header is :"+Creditheader);
		 }else{
			 Reporters.failureReport("Verify the header of page","Failed to verify headers : </br> Expected Header is :"+cardheader+" </br> Actual Header is :"+Creditheader);
		 }
		 Thread.sleep(medium);
		 if(creditCardDetails()){
			Reporters.SuccessReport("Enter Details and verify","Creditcard details are entered and User is Successfully taken to Review and Submit Page"); 
		 }else{
			 Reporters.failureReport("Enter Details and verify","User is Failed to enter creditcard details and to take Review and Submit page");
		 }
		 Thread.sleep(veryhigh);
		 String title = getText(ElsevierObjects.Pbc_isbn_title,"Get the name of product");
		 if(title.contains(Pbctitle)){
			 Reporters.SuccessReport("Verify the Title of the product","Titles are verified Successfully :<br>Expected title is :"+Pbctitle+"<br> Actual title is :"+title);
		 }else{
			 Reporters.failureReport("Verify the Title of the product","Failed to verify the Titles :<br>Expected title is :"+Pbctitle+"<br> Actual title is :"+title);
		 }
		 Thread.sleep(low);
	     String ActualISBN = getText(ElsevierObjects.Pbc_Isbn_number,"Get the ISBN of product");
	     if(ActualISBN.contains(PbcISBN)){
			 Reporters.SuccessReport("Verify the ISBN of the product","ISBN's compared Successfully :<br>Expected ISBN is : "+PbcISBN+"<br> Actual ISBN is :"+ActualISBN);	 
		 }else{
			 Reporters.failureReport("Verify the ISBN of the product","ISBN's comparision is Failed :<br>Expected ISBN is : "+PbcISBN+"<br> Actual ISBN is :"+ActualISBN);
		 }
	     Thread.sleep(low);
		 String  Price = getText(ElsevierObjects.Pbc_price,"Get the price of product");
		 float p=convertStringToPrice(Price);
		 if(price.contains(Price)){
			 Reporters.SuccessReport("Verify the price of the product","Prices are verified Successfully :<br>Expected price is :"+price+"<br> Actual Price is :"+Price);
		 }else{
			 Reporters.failureReport("Verify the price of the product","Failed to verify the Prices:<br>Expected price is :"+price+"<br> Actual Price is :"+Price);
		 }
		 Thread.sleep(low);
		 String tax = getText(ElsevierObjects.Pbc_Estimatetax,"Get the Estimatedtax");
		 float estimatetax=convertStringToPrice(tax);
		 float Totalprice =p+estimatetax;
		 Reporters.SuccessReport("Verify the tax of the product","EstimatedTax is verified and Tax is "+tax);
		 Thread.sleep(low);
		 PbcTotal = getText(ElsevierObjects.Pbc_total_price,"Get Totalprice");
		 String PbcPrice=PbcTotal.replace("$", "");
		 float Pbcprc=convertStringToPrice(PbcPrice);
		 if((Pbcprc==Totalprice)){
			 Reporters.SuccessReport("Verify TotalPrice of the product","TotalPrices are compared successfully :<br> Expected Price is : "+Totalprice+"<br> Actual Price is :"+Pbcprc);
		 }else{
			 Reporters.failureReport("Verify TotalPrice of the product","TotalPrices to compare prices :<br> Expected Price is : "+Totalprice+"<br> Actual Price is :"+Pbcprc);		
		 }
		 Thread.sleep(low);
		 click(ElsevierObjects.checkbox1,"Click on checkbox");
		 Thread.sleep(medium);
		 click(ElsevierObjects.instructor_submit,"Click on submit button");
		 Thread.sleep(low);
         }
	  catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}		 
	  return flag;
	  }	 
		 
		 //verification step 18
	public static boolean ConfirmationRelogin()throws Throwable{
		boolean flag = true;
		try
	    {
		 
		 String title = getText(ElsevierObjects.Pbc_verify_title,"Get the name of product");
		 if(title.contains(Pbctitle)){
			 Reporters.SuccessReport("Verify the Title of the product","Titles are verified Successfully :<br>Expected title is :"+Pbctitle+"<br> Actual title is :"+title);
		 }else{
			 Reporters.failureReport("Verify the Title of the product","Failed to verify the Titles :<br>Expected title is :"+Pbctitle+"<br> Actual title is :"+title);
		 }
		 Thread.sleep(low);
		 String  ActualISBN = getText(ElsevierObjects.Pbc_verify_isbn,"Get ISBN of product");
		 if(ActualISBN.contains(PbcISBN)){
			 Reporters.SuccessReport("Verify the ISBN of the product","ISBN's compared Successfully :<br>Expected ISBN is : "+PbcISBN+"<br> Actual ISBN is :"+ActualISBN);	 
		 }else{
			 Reporters.failureReport("Verify the ISBN of the product","ISBN's comparision is Failed :<br>Expected ISBN is : "+PbcISBN+"<br> Actual ISBN is :"+ActualISBN);
		 }
		 Thread.sleep(low);
		;
	     String Totalprice=getText(ElsevierObjects.Pbc_verify_total_price,"Get Totalprice");
	     if(PbcTotal.contains(Totalprice)){
			 Reporters.SuccessReport("Verify Totalprice of the product","Totalprices are compared Successfully :<br> Expected Totalprice is : "+Totalprice+"<br> Actual Totalprice is :"+PbcTotal);
		 }else{
			 Reporters.failureReport("Verify Totalprice of the product","Failed to compare Totalprices :<br> Expected Totalprice is : "+Totalprice+"<br> Actual Totalprice is :"+PbcTotal);
		 }
	     Thread.sleep(veryhigh);
		 if(click(ElsevierObjects.Myevolve,"Click on my Evolve")){
			 Reporters.SuccessReport("click on My Evolve","Successfully clicked on My Evolve");
		 }else{
			 Reporters.failureReport("click on My Evolve","failed to click on My Evolve");
		 }
		 Thread.sleep(low);
		 click(ElsevierObjects.Pbc_Refresh,"Click on Refresh");
		 Thread.sleep(low);
		 String CourseId =  ReadingExcel.columnDataByHeaderName("CourseId","TC-15588",configProps.getProperty("TestData"));
		 String C = getText(ElsevierObjects.Pbc_courseid,"Get Courseid");
		 if(CourseId.contains(C)){
			 Reporters.SuccessReport("Verify the courseid of the product","Courseid compared Successfully :<br> Expected Id is : "+C+"<br> Actual Id is :"+CourseId);
		 }else{
			 Reporters.failureReport("Verify the courseid of the product","Failed to compare Courseid :<br> Expected Id is : "+C+"<br> Actual Id is :"+CourseId);
		 }
		 Thread.sleep(low);
		 String ActualTitle =  ReadingExcel.columnDataByHeaderName("ProductTitle","TC-15588",configProps.getProperty("TestData"));
		 String Titlelink = getText(ElsevierObjects.Pbc_courseid_link,"Get Courseid link");
		 if(ActualTitle.contains(Titlelink)){
			 Reporters.SuccessReport("Verify the Titlelink of the product","Titlelink is verified Successfully :<br>Expected Title is :"+Titlelink+"<br> Actual Title is :"+ActualTitle);
		 }else{
			 Reporters.failureReport("Verify the Titlelink of the product","Failed to verify the Titlelink :<br>Expected Title is :"+Titlelink+"<br> Actual Title is :"+ActualTitle);
		 }
		 Thread.sleep(low);
		 click(ElsevierObjects.myAccount,"Click on MyAccount");
		 Thread.sleep(low);
		 click(ElsevierObjects.myAccount_AccountSettings,"Click on Account settings");
		 Thread.sleep(low);
		 username=getAttribute(ElsevierObjects.Accountsettings_username, "value", "Get attribute of username");
		 getAccountDetailsUserName=getAttribute(ElsevierObjects.educator_form_UserName, "value", "Get first name");
		 getAccountDetailsFirstName=getAttribute(ElsevierObjects.educator_form_txtFirstName, "value", "Get first name");
		getAccountDetailsLastName=getAttribute(ElsevierObjects.educator_form_txtLastName,"value","Get Last Name");
		getAccountDetailsEmail=getAttribute(ElsevierObjects.educator_form_txtEmail,"value","Get email id.");
		 if(username!=null){
			 Reporters.SuccessReport("Get Username","Click on Account settings Successfully and Username is :" +username);
		 }else{
			 Reporters.failureReport("Get Username", "Failed to click on Account settings and get username");
		 }
		 Thread.sleep(low);
		 click(ElsevierObjects.myAccount,"Click on MyAccount");
		 Thread.sleep(low);
		 if(click(ElsevierObjects.Student_Logout,"Click on logout button")){
			 Reporters.SuccessReport("Click on logout","User is Successfully logout");
		 }else{
			 Reporters.failureReport("Click on logout","User is failed to logout");
		 }
		 Thread.sleep(low);
		 if(click(ElsevierObjects.Student_Home_Login,"Click on login button")){
			 Reporters.SuccessReport("Click on login", "User is Successfully login with the created student details");
		 }else{
			 Reporters.failureReport("Click on login", "User is failed to login with the created student details");
		 }
		 Thread.sleep(low);
		 type(ElsevierObjects.common_login_userName,username,"Enter username in the textbox");
		 Thread.sleep(low);
		 type(ElsevierObjects.common_login_passWord,Password,"Enter Password in the textbox");
		 Thread.sleep(low);
		 click(ElsevierObjects.catalog,"Click on Catalog link");
		 Thread.sleep(low);
		 type(ElsevierObjects.Search_Online_Courses,isbn,"Enter the ISBN number in the searchbox");
		 Reporters.SuccessReport("Enter ISBN","Isbn is entered Successfully and Product is searched from Simulation Honeypot "+isbn);
		 Thread.sleep(medium);
		 click(ElsevierObjects.Search_Button,"Click on search button");
		 Thread.sleep(medium);
		 String price = getText(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomprice,"Get the price present there");
		 float p=convertStringToPrice(price);
		 float e=convertStringToPrice(ExpectedPrice);
		 if(p>e){
			  Reporters.SuccessReport("Verify price of the product","Price of The Product Is Greater Than Zero:"+p);
		 }else{
			  Reporters.failureReport("Verify price of the product","Failed to verify Price of The Product.");
		 }
		 Thread.sleep(low);
		 }
	  catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}	
	  return flag;
     }

	public static boolean emailVerification() throws Throwable{
		 boolean flag=true;
		try
	    { 
		
		 launchUrl(configProps.getProperty("EmailURL"));
		 Thread.sleep(medium);
		 type(ElsevierObjects.emailaddress,configProps.getProperty("verifyemail_username"),"Enter email id");	
		 Thread.sleep(medium);
		 type(ElsevierObjects.emailpassword,configProps.getProperty("verifyemail_password"),"Enter password");
		 Thread.sleep(medium);
		 click(ElsevierObjects.emaillogin, "Click on Login Button.");	
		 Thread.sleep(medium);
		 click(ElsevierObjects.email_Icon,"Click on Email icon.");
		 Thread.sleep(medium);
		 click(ElsevierObjects.email_dropdown,"Click on Dropdown.");
		 Thread.sleep(medium);
		 click(ElsevierObjects.email_dropdown_Fromchk,"Click on From check box.");
		 Thread.sleep(medium);
		 click(ElsevierObjects.email_dropdown_Tochk,"Click on To checkbox.");
	 	 Thread.sleep(medium);
		 type(ElsevierObjects.email_SearchBox,EmailId,"Enter the email id.");
	     Thread.sleep(medium);
		 click(ElsevierObjects.email_SearchIcon,"Click on search icon.");
		 Thread.sleep(high);
		 click(ElsevierObjects.Email_selection,"Click on welcome to evolve");
		 Thread.sleep(medium);
		 switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
		 Thread.sleep(medium);
		 String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
		 if(emailBody.contains(Firstname) && emailBody.contains(Lastname) && emailBody.contains(EmailId) && emailBody.contains(username) && emailBody.contains(Password)){
		 driver.switchTo().defaultContent();
		 if(click(ElsevierObjects.email_logout,"Click on logout."))
		 {
			Reporters.SuccessReport("Verifying User details In Email Body.</br>Clicking On Logout Button.","Successfully Verified Username: "+username+"</br>Password: "+Password+"</br>Firstname: "+Firstname+" </br>Lastname: "+Lastname+"</br>Email:"+EmailId+"</br>Successfully Clicked On Logout Button </br></br> Email Body Is: "+emailBody+"</br>");
		 }else{
			Reporters.failureReport("Verifying User details In Email Body.</br>Clicking On Logout Button.", "Failed To Verify User Details.</br>Failed To Click On Logout Button.  Email Body Is: "+emailBody+"</br>");
		 }
	    }
		else{
	 		Reporters.failureReport("Verifying User details In Email Body.", "Failed To Verify User Details in Email Body.");
	    }	 
	 	}
	 catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}		
	 return flag;
	}	 
}
