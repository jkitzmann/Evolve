package com.cigniti.automation.BusinessFunctions;

import java.util.concurrent.TimeUnit;

import org.apache.commons.exec.ExecuteException;
import org.openqa.selenium.By;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class CreateRosterforLOcourse_Byrosteredinstructor_15565 extends EvolveCommonBussinessFunctions {
	public static String lastname;
	public static String firstname;
	public static String email;
	public static String Studentdetails;
	public static String username;
	public static String Password;
	public static String CourseCodeId;
	public static String LoEmail;


	public static boolean newStudentCreation() throws Throwable{
		boolean flag = true;
		try
		{
			CreateNewUser("STUDENT");
			Thread.sleep(1000);
			getAccountDetailsforRoster();
			lastname = getAccountDetailsLastName;
			firstname = getAccountDetailsFirstName;
			email = getAccountDetailsEmail;
			Studentdetails = lastname+","+firstname+","+email;
			System.out.println(Studentdetails);
			username = getAccountDetailsUserName;
			ReadingExcel.updateCellInSheet(1,3,testDataPath, "TC-15565",username);
			Password = credentials[1];
			ReadingExcel.updateCellInSheet(1,4,testDataPath, "TC-15565",Password);
			EvolveCommonBussinessFunctions.instructorLogout();
			
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}	  
		return flag;
	}
	
	
	//==============================End of the Method========================================//
	
	
	

	public static boolean RosterforLoCreation() throws Throwable{
		boolean flag = true;
		try
		{
			
			
			EvolveCommonBussinessFunctions.getStundentIntoYourCourse();
			//CourseCodeId=ReadingExcel.columnDataByHeaderName("CourseId","TC-15565",configProps.getProperty("TestData"));
			// ReadingExcel.updateCellInSheet(1,2,configProps.getProperty("TestData"), "TC-10438",CourseId);
			ImplicitWait();
			b=true;
			type(ElsevierObjects.txtcourseID,CourseCodeId,"Enter unique courseId in the 'CourseID' TextField and ");
			Thread.sleep(1000);
			b=false;
			driver.findElement(ElsevierObjects.txtArea).clear();
			driver.findElement(ElsevierObjects.txtArea).sendKeys(Studentdetails);		
			Thread.sleep(4000);
			if(click(ElsevierObjects.btnpreiviewroster,"click on preview and Roster")){
				Reporters.SuccessReport("Enter student info in rosterfield and submit", "Sucessfully Enter the student info from Step #2 into the roster text box in the format of 'Last Name, First Name, Email Address' and </br> clicked on 'Preview Roster & Assign Roles' button then </br> User is brought to a second screen that shows the user listed with a dropdown next to the username to assign a role to the enrollee.");
			}else{
				Reporters.failureReport("Enter student info in rosterfield and submit", "unable to click on 'Preview Roster & Assign Roles' button");	
			}
			b=true;
			selectByValue(ElsevierObjects.Role_selection, "student", "Select the Student("+username+") role as a 'STUDENT'");
			b=false;
			Thread.sleep(1000);
			
			if(click(ElsevierObjects.Email_only_me,"selecting the 'Email the roster to only me and I will distribute the usernames & passwords to my students.' radio button")){
				Reporters.SuccessReport("select Radio button", " sucessfully selecting the 'Email the roster to only me and I will distribute the usernames & passwords to my students.' radio button");
			}
			else{
				Reporters.failureReport("select Radio button", "sucessfully selecting the 'Email the roster to only me and I will distribute the usernames & passwords to my students.' radio button");
			}
			
			
			if(click(ElsevierObjects.btnsubmitroster,"click on the 'Submit this Roster' Button"))
			{
				Reporters.SuccessReport("click on Submit roster button", "Sucessfully clicked on the 'Submit This Roster'Button");
			}
			else
			{
				Reporters.failureReport("click on Submit roster button", "failed to click on 'Submit This Roster'Button");
			}
			String successMsg="Success!";
			String s=getText(ElsevierObjects.sucess_Message,"Verify the success message");
			if(s.contains(CourseCodeId)&&s.contains(successMsg)){
				Reporters.SuccessReport("Verify Success Message","User will see a success message: " +s);
			} else{
				Reporters.failureReport("Verify Success Message","User will unable to see a success message: " +s);	
			}
			click(ElsevierObjects.Roster_done,"Click on Done button");
			}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}  
		return flag;
	}
	
	
	
	//==============================End of the Method========================================//
	
	
	

	public static boolean courseIDSearch(String ID1) throws Throwable{
		boolean flag=true;
		try{
			if(ID1.equalsIgnoreCase("true")){
				waitForVisibilityOfElement(By.xpath(".//*[@id='set']/li/div/div/span[text()='COURSE ID: "+CourseCodeId+"']"),"Verify course id1 present.");
			}
			if(click(By.xpath("//*[@id='set']/li/div/div/span[text()='COURSE ID: "+CourseCodeId+"']/following-sibling::a"),"Click on Course Title."))
			{
			Thread.sleep(60000);
			//driver.manage().timeouts().implicitlyWait(600, TimeUnit.SECONDS);
			Reporters.SuccessReport("Get in to the content List page", "Sucessfully get into the ContentList page");
			}
			else
			{
				
				Reporters.failureReport("Get in to the content List", "Failed to get in to the content list page ");
			}
			
			if(click(ElsevierObjects.roster_And_Teams_lnk,"Rosters and Teams"))
			{
				Reporters.SuccessReport("click on the 'Roster_and_Teams'Link and Verify that, new student enrollee is displayed and has the student role.", "Sucessfully clicked in the 'Roster_And_Teams'link.");
			}
			else
			{
				Reporters.failureReport("click on the 'Roster_and_Teams'Link and Verify that, new student enrollee is displayed and has the student role.", "failed to click on the roster and teams link");
			}
			
			Thread.sleep(1000);
			
			switchToFrameById("embeddedTool");
			String user = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+username+"')]"),"Get the Student Username");
			if(user!=null){
				Reporters.SuccessReport("Verify Student Username from the table","Successfully Student Username is verified </br>" +user);
			}else{
				Reporters.failureReport("Verify Student Username from the table","Failed to verify Student Username");
			}
			String role = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+username+"')]/following-sibling::td[contains(text(),'Student')]"),"Get the Role of user");
			if(role!=null){
				Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +role);
			}else{
				Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
			}
			switchToDefaultFrame();
			EvolveCommonBussinessFunctions.instructorLogout();
		} 
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}
		return flag;	
	}
	
	
	
	//==============================End of the Method========================================//
	
	
	

	public static boolean StudentRelogin() throws Throwable{
		boolean flag = true;
		try
		{
			
			launchUrl("https://evolvetest.elsevier.com/cs/store?role=student");
			Thread.sleep(medium);
			b=true;
			click(ElsevierObjects.Student_Home_Login,"log into'evolvecert.elsevier.com'as a student created in step#2,and click 'Login' button for enter credentials");
			Thread.sleep(1000);
			type(ElsevierObjects.common_login_userName,username,"Enter username in the textbox");
			Thread.sleep(1000);
			type(ElsevierObjects.common_login_passWord,Password,"Enter Password in the textbox");
			Thread.sleep(1000);
			b=false;
			if(click(ElsevierObjects.submit,"Click on login button")){
				Reporters.SuccessReport("Click on login", "User is Successfully login with the created student details");
			}else{
				Reporters.failureReport("Click on login", "User is failed to login with the created student details");
			}
			Thread.sleep(1000);
			b=true;
			click(ElsevierObjects.Myevolve,"My Evolve");
			Thread.sleep(1000);
			b=false;
			String Id = getText(ElsevierObjects.Roster_Evolve_CourseId,"Get Unique CourseId");
			if(Id!=null){
				Reporters.SuccessReport("Verify Unique CourseId","User is Successfully verified</br>Unique "+Id);
			}else{
				Reporters.failureReport("Verify Unique CourseId","User is failed to verify unique CourseId");
			}
			Thread.sleep(1000);
			String Courselink = getText(ElsevierObjects.Roster_Evolve_Courselink,"Get Unique CourseId link");
			if(Courselink!=null){
				Reporters.SuccessReport("Verify Unique CourseId link","User is Successfully verified CourseId link </br>" +Courselink);
			}else{
				Reporters.failureReport("Verify Unique CourseId link","User is failed to verify CourseId link");
			}
			EvolveCommonBussinessFunctions.instructorLogout();
			
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}
		return flag;
	}
	
	
	//==============================End of the Method========================================//
	
	
	
	
	public static boolean Emailverification() throws Throwable {
		boolean flag = true;
		try
		{
			
			if(launchUrl(configProps.getProperty("EmailURL")))
			{
			Thread.sleep(3000);
			type(ElsevierObjects.emailaddress,configProps.getProperty("verifyemail_username"),"Enter email id");
			Thread.sleep(3000);
			type(ElsevierObjects.emailpassword,configProps.getProperty("verifyemail_password"),"Enter password");
			Thread.sleep(2000);
			click(ElsevierObjects.emaillogin, "Click on Login Button.");
			Reporters.SuccessReport("Login into designated email account for the instructor", "Sucessfully Logged into designated email account for the instructor who submitted this roster ");
			}
			else
			{
				Reporters.failureReport("Login into designated email account for the instructor", "failed to log into designated account ");
			}
			Thread.sleep(4000);
			click(ElsevierObjects.email_Icon,"Click on Email icon.");
			Thread.sleep(1000);
			click(ElsevierObjects.email_dropdown,"Click on Dropdown.");
			Thread.sleep(1000);
			click(ElsevierObjects.email_dropdown_Fromchk,"Click on From check box.");
			Thread.sleep(1000);
			click(ElsevierObjects.email_dropdown_Tochk,"Click on To checkbox.");
			Thread.sleep(2000);
			type(ElsevierObjects.email_SearchBox,LoEmail,"Enter the EmailAddress.");
			Thread.sleep(1000);
			click(ElsevierObjects.email_SearchIcon,"Click on search icon.");
			Thread.sleep(4000);
			String EmailTitle = getText(ElsevierObjects. titleInEmail,"Verify the Subject of the Email");
			if(EmailTitle!=null){
				Reporters.SuccessReport("Verify Subject of Email","Successfully Email subject is verified </br> "+EmailTitle);
			}else{
				Reporters.failureReport("Verify Subject of Email","Failed to verify Email subject.");
			}
			switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
			driver.switchTo().defaultContent();
			b=true;
			click(ElsevierObjects.email_logout,"Logout button");	 
			b = false;
			
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}	
		return flag;
	}
	
	
	//==============================End of the Method========================================//
	
	

	public static boolean RostersearchinginAdmin() throws Throwable{
		boolean flag = true;
		try
		{
			
			b= true;
			click(ElsevierObjects.Admin_Search_Rosters,"Search Rosters");
			Thread.sleep(1000);
			type(ElsevierObjects.Roster_Course_ID,CourseCodeId,"Enter the CourseId in the textbox");
			Thread.sleep(1000);
			click(ElsevierObjects.Roster_Search,"Search button");
			Thread.sleep(1000);
			click(ElsevierObjects.Course_ID_Link,"Courseid link of the Roster now created");
			Thread.sleep(1000);
			b= false;
			String sUser =getText(By.xpath(".//*[@id='pageBody']//tr//td[contains(text(),'"+username+"')]"),"Get student Usename from table");
			if(sUser!=null){
				Reporters.SuccessReport("Verify Student Username from the table","Successfully Student Username is verified </br>" +sUser);
			}else{
				Reporters.failureReport("Verify Student Username from the table","Failed to verify Student Username");
			}
			String sRole =getText(By.xpath(".//*[@id='pageBody']//tr//td[contains(text(),'"+username+"')]/following-sibling::td[contains(text(),'Student')]"),"Get the Role of user");
			if(sRole!=null){
				Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +sRole);
			}else{
				Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
			}
			
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}
		return flag;
		//==============================End of the Method========================================//
	}   
}
