package com.cigniti.automation.BusinessFunctions;

import java.text.DecimalFormat;

import org.openqa.selenium.Keys;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class CreateStudentUserafteraddingitemstoCart_Hardgood_15588 extends EvolveCommonBussinessFunctions{
	
	public static String ISBN;
	public static String Firstname;
	public static String Lastname;
	public static String EmailId;
	public static String Password;
	public static String ConformPassword;
	public static String Country;
	public static String State;
	public static String City;
	public static String Institution;
	public static String StreetAddress;
	public static String Zipcode;
	public static String ProgramType;
	public static String Year;
	public static String username;
	public static String isbn;
	public static String CityAddress;
	public static String StateAddress;
	public static String title;
	public static String Isbn;
	public static String price;
	public static String guytonTotalprice;
	
	public static boolean Studentafteraddingtocart() throws Throwable{
		 boolean flag = true;
		try
		{
      
	       launchUrl(configProps.getProperty("URL4"));
	  	   Thread.sleep(low);
	  	   type(ElsevierObjects.evolve_Serach_txt,ISBN,"Enter the isbn number in the searchbox");
		   Thread.sleep(medium);
		   click(ElsevierObjects.gobutton,"Click on GO button");
		   Thread.sleep(medium);
		   price = getText(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomprice,"Get the price present there");
		   float p=convertStringToPrice(price);
		   float e=convertStringToPrice(ExpectedPrice);
		   if(p>e){
				Reporters.SuccessReport("Verify price of the product","Price of The Product Is Greater Than Zero in product page:"+p);
		   }else{
			    Reporters.failureReport("Verify price of the product","Failed to verify Price of The Product.");
		   }
		   Thread.sleep(low);
		   click(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomAddtoCart,"Click on AddtoCart");
		   Thread.sleep(medium);
		   if(isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MyCartTitle,"Check Mycart title")){
			   Reporters.SuccessReport("Verify MyCart title", "MyCart title is present");
		   }else{
			   Reporters.failureReport("Verify MyCart title", "MyCart title is not present");
		   }
		   Thread.sleep(low);
		   title = getText(ElsevierObjects.Guyton_Title,"Get title of the product");
		   Reporters.SuccessReport("Verify the title of the product","Title of the product is verified and title is :"+title);
		   Thread.sleep(low);
		   Isbn = getText(ElsevierObjects.Guyton_ISBN,"Get isbn number present there");
	       Reporters.SuccessReport("Verify the ISBN of the product","ISBN of the product is verified and ISBN is :"+ISBN);	  
		   Thread.sleep(low);
		   String Guytonprice = getText(ElsevierObjects.Guyton_Price,"Get the price for product");
		   if(Guytonprice.contains(price)){
				Reporters.SuccessReport("Verify price of the product","Prices are compared successfully :<br> Expected price is : "+price+"<br>Actual price is :"+Guytonprice);
		   }else{
			    Reporters.failureReport("Verify price of the product","Prices are compared successfully :<br> Expected price is : "+price+"<br>Actual price is :"+Guytonprice);
		   }
		   Thread.sleep(low);
		   Reporters.SuccessReport("Verify price of product","Price is Greater than ZERO");
		   Thread.sleep(low);
		   click(ElsevierObjects.Hesi_Student_Reedembutton,"Click on Reedem/Checkout button");
		   Thread.sleep(medium);
		}
		catch(Exception e)
		{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		return false;
		}	
    return flag;
	}
	public static boolean AccountRegistration()throws Throwable{
		boolean flag = true;	
		try
		{
	   
	   String h = ReadingExcel.columnDataByHeaderName("h","TC-15588",configProps.getProperty("TestData"));
	   String header =getText(ElsevierObjects.Admin_Evolve_Ecom_NewToEvolve,"Get the header in the page");
	   if(header.contains(h)){
		   Reporters.SuccessReport("Verify the header of the page","Successfully headers are verified :<br>Expected header is :"+h+"<br>Actual header is :"+header);
	   }else{
		   Reporters.failureReport("Verify the header of the page","Failed to verify the headers :<br>Expected header is :"+h+"<br>Actual header is :"+header);
	   }
	   Thread.sleep(low);
       String h1 = ReadingExcel.columnDataByHeaderName("h1","TC-15588",configProps.getProperty("TestData"));
	   String header1=getText(ElsevierObjects.Header1,"Get the Section in the page");
	   if(header1.contains(h1)){
		    Reporters.SuccessReport("Verify the Section of the page","Successfully Section are verified :<br>Expected Section is :"+h1+"<br>Actual Section is :"+header1);
	   }else{
			Reporters.failureReport("Verify the Section of the page","Failed to verify the Section :<br>Expected Section is :"+h1+"<br>Actual Section is :"+header1);
	   }
	   Thread.sleep(low);
	   String h2 = ReadingExcel.columnDataByHeaderName("h2","TC-15588",configProps.getProperty("TestData"));
	   String header2 = getText(ElsevierObjects.Header2,"Get the Section in the page");
	   if(header2.contains(h2)){
		   Reporters.SuccessReport("Verify the Section of the page","Successfully Section are verified :<br>Expected Section is :"+h2+"<br>Actual Section is :"+header2);
	   }else{
		   Reporters.failureReport("Verify the Section of the page","Failed to verify the Section :<br>Expected Section is :"+h2+"<br>Actual Section is :"+header2);
	   }
	   Thread.sleep(low);
	   String h3 = ReadingExcel.columnDataByHeaderName("h4","TC-15588",configProps.getProperty("TestData"));
	   String header3 = getText(ElsevierObjects.Header3,"Get the Section in the page");
	   if(header3.contains(h3)){
		    Reporters.SuccessReport("Verify the Section of the page","Successfully Section are verified :<br>Expected Section is :"+h3+"<br>Actual Section is :"+header3);
	   }else{
		   Reporters.failureReport("Verify the Section of the page","Failed to verify the Section :<br>Expected Section is :"+h3+"<br>Actual Section is :"+header3);
	   }
	   Thread.sleep(low);
	   String h4 = ReadingExcel.columnDataByHeaderName("h3","TC-15588",configProps.getProperty("TestData"));
	   String header4 = getText(ElsevierObjects.Header4,"Get the Section in the page");
	   if(header4.contains(h4)){
		    Reporters.SuccessReport("Verify the Section of the page","Successfully Section are verified :<br>Expected Section is :"+h4+"<br>Actual Section is :"+header4);
	   }else{
		   Reporters.failureReport("Verify the Section of the page","Failed to verify the Section :<br>Expected Section is :"+h4+"<br>Actual Section is :"+header4);
	   }
	   Thread.sleep(low);
	   if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
			 Reporters.SuccessReport("Click on continue","Fields are left blank and clicked on continue button");
	   }else{
			 Reporters.failureReport("Click on continue","Failed to click on continue button");
	   }
	   Thread.sleep(low);
	   String Err = ReadingExcel.columnDataByHeaderName("Err","TC-15588",configProps.getProperty("TestData"));
	   // was createNewAccnt_EmptyField_Error
	   String error = getText(ElsevierObjects.registration_form_error,"Get error message");
	   if(error.contains(Err)){
		   Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully  :<br>Expected Error is :"+Err+"<br>Actual Error is :"+error);
	   }else{
		   Reporters.failureReport("Verify the Error in the page","Failed to verify the Errors :<br>Expected Error is :"+Err+"<br>Actual Error is :"+error);
	   }
	   Thread.sleep(low);
	   type(ElsevierObjects.educator_form_txtFirstName,Firstname,"Enter Firstname in the textbox");
	   Thread.sleep(low);
	   type(ElsevierObjects.educator_form_txtLastName,Lastname,"Enter Lastname in the textbox");
	   Thread.sleep(low);
	   type(ElsevierObjects.educator_form_txtEmail,EmailId,"Enter Email in the textbox");
	   Thread.sleep(low);
	   if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
			 Reporters.SuccessReport("Enter and click","Details are entered Confirm Email,Password field left blank and clicked on continue </br> Firstname :"+Firstname+"</br>"+"Lastname :"+Lastname+"</br>"+"Email :"+EmailId);
	   }else{
			 Reporters.failureReport("Enter and click","Failed to enter details and click on continue button");
	   }
	   Thread.sleep(low);
	   String Err1 = ReadingExcel.columnDataByHeaderName("Err1","TC-15588",configProps.getProperty("TestData"));;
	   // was createNewAccnt_EmptyField_Error
	   String error1 = getText(ElsevierObjects.registration_form_error,"Get error message");
	   if(error1.contains(Err1)){
		   Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully :<br>Expected Error is :"+Err1+"<br>Actual Error is :"+error1);
	   }else{
		   Reporters.failureReport("Verify the Error in the page","Failed to verify the errors :<br>Expected Error is :"+Err1+"<br>Actual Error is :"+error1);
	   }
	   Thread.sleep(low);
	   type(ElsevierObjects.educator_form_txtConformEmail,EmailId,"Enter Conform Email in the textbox");
	   Thread.sleep(low);
	   if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
			 Reporters.SuccessReport("Enter and click","Details are entered Password fields are left blank and clicked on continue </br>"+"Confirm Email :"+EmailId);
	   }else{
			 Reporters.failureReport("Enter and click","Failed to enter details and clicked on continue button");
	   }
	   Thread.sleep(low);
	   String Err2 =ReadingExcel.columnDataByHeaderName("Err2","TC-15588",configProps.getProperty("TestData"));
	   // was createNewAccnt_EmptyField_Error
	   String error2 = getText(ElsevierObjects.registration_form_error,"Get error message");
	   if(error2.contains(Err2)){
		   Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully :<br>Expected Error is :"+Err2+"<br>Actual Error is :"+error2);
	   }else{
		   Reporters.failureReport("Verify the Error in the page","Failed to verify the errors :<br>Expected Error is :"+Err2+"<br>Actual Error is :"+error2);
	   }
	   Thread.sleep(low);
	   type(ElsevierObjects.educator_form_txtPassword,Password,"Enter Password in the textbox");
	   Thread.sleep(low);
	   type(ElsevierObjects.educator_form_txtConformPassword,ConformPassword,"Enter conform Password in the textbox");
	   Thread.sleep(low);
	   if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
			 Reporters.SuccessReport("Enter and click","Details are entered and Entered different password and clicked on continue button </br>"+"Password :"+Password+"</br>"+"ConformPassword :"+ConformPassword);
	   }else{
			 Reporters.failureReport("Enter and click", "Failed to enter details and click on continue button");
	   }
	   Thread.sleep(low);
	   String Err3 = ReadingExcel.columnDataByHeaderName("Err3","TC-15588",configProps.getProperty("TestData"));
	   // was createNewAccnt_EmptyField_Error
	   String error3 =getText(ElsevierObjects.registration_form_error,"Get error message");
	   if(error3.contains(Err3)){
		  Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully :<br>Expected Error is :"+Err3+"<br>Actual Error is :"+error3);
	   }else{
		  Reporters.failureReport("Verify the Error in the page","Failed to verify the errors :<br>Expected Error is :"+Err3+"<br>Actual Error is :"+error3);
	   }
	   Thread.sleep(low);
       type(ElsevierObjects.educator_form_txtPassword,Password,"Enter Password in the textbox");
	   Thread.sleep(low);
	   type(ElsevierObjects.educator_form_txtConformPassword,Password,"Enter confirm Password in the textbox");
	   Thread.sleep(low);
	   if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
			 Reporters.SuccessReport("Enter and click","Details are entered and leave Institute details blank and clicked on continue button </br>"+"Password :"+Password+"</br>"+"ConfirmPassword :"+Password);
	   }else{
			 Reporters.failureReport("Enter and click","Failed to enter details and click on continue button");
	   }
	   Thread.sleep(low);
	   String Err4 =  ReadingExcel.columnDataByHeaderName("Err4","TC-15588",configProps.getProperty("TestData"));
	   // was Error_msg1
	   String error4 = getText(ElsevierObjects.registration_form_error,"Get error message");
	   if(error4.contains(Err4)){
		   Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully  :<br>Expected Error is :"+Err4+"<br>Actual Error is :"+error4);
	   }else{
		   Reporters.failureReport("Verify the Error in the page","Failed to verify the errors :<br>Expected Error is :"+Err4+"<br>Actual Error is :"+error4);
	   }
	   Thread.sleep(low);
	   selectByVisibleText(ElsevierObjects.Hesi_Student_country,Country,"Select country name from the list");
	   Thread.sleep(medium);
	   selectByVisibleText(ElsevierObjects.Hesi_Student_state,State,"Select State name from the list");
	   b= true;
	   if(selectBySendkeys(ElsevierObjects.Hesi_Student_City,City,"Enter City name")){
		    Reporters.SuccessReport("Get Cityname","Cityname is :" +City);
	   }else{
			Reporters.failureReport("Get Cityname", "Failed to get cityname");
	   }
	   Thread.sleep(medium);
	   driver.findElement(ElsevierObjects.Hesi_Student_City).sendKeys(Keys.ENTER);
	   Thread.sleep(medium);
	   if(selectBySendkeys(ElsevierObjects.Hesi_Student_institute,Institution,"Enter Institute name")){
		   Reporters.SuccessReport("Get Institutename","Institutename is :" +Institution);
	   }else{
		   Reporters.failureReport("Get Institutename", "Failed to get Institutename");
	   }
	   b=false;
	   Thread.sleep(medium);
	   selectByVisibleText(ElsevierObjects.educator_form_txtddprogramType,ProgramType,"Select programtype from list");
	   Thread.sleep(medium);
	   selectBySendkeys(ElsevierObjects.Hesi_Student_year,Year,"Select the year from the list");
	   Thread.sleep(low);
	   if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
			 Reporters.SuccessReport("Enter and click","Details are entered and leave billing address blank and clicked on continue button </br>"+"Country :"+Country+"</br>"+"State :"+State+"</br>"+"City :"+City+"</br>"+"Institute :"+Institution+"</br>"+"Programtype :"+ProgramType+"<br>"+"Year :"+Year);
	   }else{
			 Reporters.failureReport("Enter and click","Failed to enter details anc click on continue button");
	   }
	 
	   String Err5 =  ReadingExcel.columnDataByHeaderName("Err4","TC-15588",configProps.getProperty("TestData"));
	   // was Errmsg
	   String error5 = getText(ElsevierObjects.registration_form_error,"Get error message");
	   if(error5.contains(Err5)){
		    Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully :<br>Expected Error is :"+Err5+"<br>Actual Error is :"+error5);
	   }else{
		    Reporters.failureReport("Verify the Error in the page","Failed to verify the errors :<br>Expected Error is :"+Err5+"<br>Actual Error is :"+error5);
	   }
	   Thread.sleep(low);
	   type(ElsevierObjects.Student_Shipping_Addr1,StreetAddress,"Enter the Street Address in the box");
	   Thread.sleep(low);
       type(ElsevierObjects.Student_Shipping_City,CityAddress,"Enter City in the textbox");
       Thread.sleep(low);
       selectByVisibleText(ElsevierObjects.Student_Shipping_State,StateAddress,"Enter State in the textbox");
       Thread.sleep(low);
       type(ElsevierObjects.Student_Shipping_Zip,Zipcode,"Enter Zipcode in the textbox");
       Thread.sleep(low);
       Reporters.SuccessReport("Enter and click","billing address is entered successfully and Details entered in billing address:</br>"+"Street Address :"+StreetAddress+"</br>"+"CityAddress :"+CityAddress+"</br>"+"StateAddress :"+StateAddress+ "</br>"+"Zipcode :"+Zipcode);
       if(click(ElsevierObjects.educator_form_btnContinue,"Click on continue button")){
			 Reporters.SuccessReport("Enter and click","Details are entered and leave shipping address blank and clicked on continue button");
	   }else{
			 Reporters.failureReport("Enter and click","Failed to enter details anc click on continue button");
	   }
	   Thread.sleep(medium);
	   String Err6 =  ReadingExcel.columnDataByHeaderName("Err4","TC-15588",configProps.getProperty("TestData"));
	   // was Error_msg5
	   String error6 = getText(ElsevierObjects.registration_form_error,"Get error message");
	   System.out.println(error6);
	   if(error6.contains(Err6)){
			Reporters.SuccessReport("Verify the Error in the page","Errors are verified Successfully :<br>Expected Error is :"+Err6+"<br>Actual Error is :"+error6);
	   }else{
			Reporters.failureReport("Verify the Error in the page","Failed to verify the errors :<br>Expected Error is :"+Err6+"<br>Actual Error is :"+error6);
	   }
	   Thread.sleep(low);
	   type(ElsevierObjects.student_billingAddress,StreetAddress,"Enter the Street Address in the box");
	   Thread.sleep(medium);
       type(ElsevierObjects.student_billingAddress_city,CityAddress,"Enter City in the textbox");
       Thread.sleep(medium);
       selectByVisibleText(ElsevierObjects.student_billingAddress_state,StateAddress,"Enter State in the textbox");
       Thread.sleep(medium);
       type(ElsevierObjects.student_billingAddress_zip,Zipcode,"Enter zipcode in the textbox");
       Thread.sleep(medium);
       Reporters.SuccessReport("Enter and click","Shipping address is entered successfully and Details entered in shipping address:</br>"+"Street Address :"+StreetAddress+"</br>"+"CityAddress :"+CityAddress+"</br>"+"StateAddress :"+StateAddress+ "</br>"+"Zipcode :"+Zipcode);
       click(ElsevierObjects.educator_form_btnContinue,"Click on continue button");
	   Thread.sleep(medium);
	   switchToFrameByLocator(ElsevierObjects.Admin_Evolve_Ecom_framename,"Switch to iframe");
	   Thread.sleep(low);
	   String Popupheader = ReadingExcel.columnDataByHeaderName("PopUp", "TC-15588",configProps.getProperty("TestData"));
	   String Popheader = getText(ElsevierObjects.Popup_header,"Get header of the frame");
	   if(Popheader.contains(Popupheader)){
		   Reporters.SuccessReport("Verify the header of Frame","PopupHeader is Successfully verified : </br> Expected Header is :"+Popupheader+" </br> Actual Header is :"+Popheader);
	   }else{
		   Reporters.failureReport("Verify the header of Frame","Failed to verify headers : </br> Expected Header is :"+Popupheader+" </br> Actual Header is :"+Popheader);
	   }
	   Thread.sleep(medium);
	   if(click(ElsevierObjects.Use_this_address,"Click on use this address")){
		   Reporters.SuccessReport("Verify Use this Address","Successfully clicked on Use this Address");
	   }else{
		   Reporters.failureReport("Verify Use this Address","Failed to click on Use this Address");
	   }
	   Thread.sleep(medium);
	   String Creditheader = ReadingExcel.columnDataByHeaderName("Creditheader", "TC-15588",configProps.getProperty("TestData"));
	   String cardheader = getText(ElsevierObjects.Creditcard_header,"Get header of the Page");
	   if(cardheader.contains(Creditheader)){
			Reporters.SuccessReport("Verify the header of page","Creditcard Header is Successfully verified : </br> Expected Header is :"+Creditheader+" </br> Actual Header is :"+cardheader);
	   }else{
		    Reporters.failureReport("Verify the header of page","Failed to verify headers : </br> Expected Header is :"+Creditheader+" </br> Actual Header is :"+cardheader);
	   }
	   Thread.sleep(medium);
	   if(creditCardDetails()){
		   Reporters.SuccessReport("Enter Details and verify","Creditcard details are entered and User is Successfully taken to Review and Submit Page"); 
	   }else{
		   Reporters.failureReport("Enter Details and verify","User is Failed to enter creditcard details and to take Review and Submit page");
	   }
	   Thread.sleep(medium);
	   String Title = getText(ElsevierObjects.Item_name,"Get the Title of the product");
	   if(Title.contains(title)){
			 Reporters.SuccessReport("Verify the title in the page","Successfully titles are verified :<br>Expected title is :"+title+"<br>Actual title is :"+Title);
	   }else{
			 Reporters.failureReport("Verify the title in the page","Failed to verify the titles :<br>Expected title is :"+title+"<br>Actual title is :"+Title);
	   }
	   Thread.sleep(low);
	   String ISBN = getText(ElsevierObjects.Guyton_ISBN,"Get the isbn number present there");
	   if(ISBN.contains(Isbn)){
			Reporters.SuccessReport("Verify the ISBN of the product","ISBN's compared Successfully :<br>Expected ISBN is : "+ISBN+"<br>Actual ISBN is :"+Isbn);	 
	   }else{
			Reporters.failureReport("Verify the ISBN of the product","ISBN's comparision is Failed :<br>Expected ISBN is : "+ISBN+"<br>Actual ISBN is :"+Isbn);
	   }
	   Thread.sleep(low);
	   String Price = getText(ElsevierObjects.Guyton_Price,"Get the price of product");
	   float p=convertStringToPrice(Price);
	   if(Price.contains(price)){
			 Reporters.SuccessReport("Verify the Itemprice of the product","Successfully prices are verified:<br>Expected price is :"+Price+"<br>Actual price is :"+price);
	   }else{
			 Reporters.failureReport("Verify the Itemprice of the product","Failed to verify the prices:<br>Expected price is :"+Price+"<br>Actual price is :"+price);
	   }
	   Thread.sleep(low);
	   String tax = getText(ElsevierObjects.estimatedtax,"Get the Estimatedtax");
	   float estimatetax=convertStringToPrice(tax);
	   float Totalprice =p+estimatetax;
	   DecimalFormat df = new DecimalFormat();
	   df.setMaximumFractionDigits(2);
	   String expPrice=df.format(Totalprice);
	   
	   Reporters.SuccessReport("Verify the tax of the product","EstimatedTax is verified and Tax is "+tax);
	   Thread.sleep(low);
	   guytonTotalprice = getText(ElsevierObjects.Total_price,"Get TotalPrice");
	   String guytonPrice=guytonTotalprice.replace("$", "");
	   float guytonprc=convertStringToPrice(guytonPrice);
	   float actual=guytonprc;
	   String actPri=df.format(actual);
	   if(expPrice.contains(actPri)){
		  Reporters.SuccessReport("Verify Totalprice of the product","Totalprices are compared successfully :<br> Expected price is : "+expPrice+"<br>Actual price is :"+actPri);
	   }else{
		  Reporters.failureReport("Verify Totalprice of the product","Totalprices to compare prices :<br> Expected price is : "+expPrice+"<br>Actual price is :"+actPri);		
	   }
	   Thread.sleep(low);
	   click(ElsevierObjects.checkbox1,"Click on checkbox");
	   Thread.sleep(medium);
	   click(ElsevierObjects.instructor_submit,"Click on submit button");
	   Thread.sleep(low);
	  }
	catch(Exception e)
	{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		return false;
	}
		return flag;
	}  
	public static boolean confirmationpage()throws Throwable{
		boolean flag = true;
		try
		{
	   
	   String Guytontitle = getText(ElsevierObjects.Admin_Evolve_Ecom_Confirmtitle1,"Get the Title of product");
	   if(Guytontitle.contains(title)){
		    Reporters.SuccessReport("Verify the title in the page","Successfully titles are verified :<br>Expected title is :"+Guytontitle+"<br>Actual title is :"+title);
	   }else{
		    Reporters.failureReport("Verify the title in the page","Failed to verify the titles :<br>Expected title is :"+Guytontitle+"<br>Actual title is :"+title);
	   }
	   Thread.sleep(low);
	   String ISBN = getText(ElsevierObjects.Isbn_number,"Get the Isbn number of the product");
	   if(ISBN.contains(Isbn)){
    	   Reporters.SuccessReport("Verify the ISBN of the product","ISBN's compared Successfully :<br> Expected ISBN is :"+ISBN+"<br>Actual ISBN is :"+Isbn);
       }else{
    	   Reporters.failureReport("Verify the ISBN of the product","ISBN's comparision is failed :<br> Expected ISBN is :"+ISBN+"Actual ISBN is :"+Isbn);
       }
	   Thread.sleep(low);
	   String Price =getText(ElsevierObjects.Pro_price,"Get the Price of Product");
	   if(Price.contains(price)){
		   Reporters.SuccessReport("Verify the Itemprice of the product","Prices are compared successfully :<br> Expected price is : "+Price+"<br>Actual price is :"+price);
	   }else{
		   Reporters.failureReport("Verify the Itemprice of the product","Prices comparision is failed :<br> Expected price is : "+Price+"<br>Actual price is :"+price);
	   }
	   Thread.sleep(low);
	   String Totalprice=getText(ElsevierObjects.Verify_Total_price,"Get totalprice present there");
	   if(Totalprice.contains(guytonTotalprice)){
		    Reporters.SuccessReport("Verify Totalprice of the product","Totalprices are compared successfully :<br> Expected Totalprice is : "+Totalprice+"<br>Actual Totalprice is :"+guytonTotalprice);
	   }else{
			Reporters.failureReport("Verify Totalprice of the product","Failed to compare Totalprices :<br> Expected Totalprice is : "+Totalprice+"<br>Actual Totalprice is :"+guytonTotalprice);
	   }
	   Thread.sleep(low);
	   click(ElsevierObjects.myAccount,"Click on MyAccount");
	   Thread.sleep(low);
	   click(ElsevierObjects.myAccount_AccountSettings,"Click on Account settings");
	   Thread.sleep(low);
	   username=getAttribute(ElsevierObjects.Accountsettings_username, "value", "Get attribute of username");
	   getAccountDetailsUserName=getAttribute(ElsevierObjects.educator_form_UserName, "value", "Get first name");
		 getAccountDetailsFirstName=getAttribute(ElsevierObjects.educator_form_txtFirstName, "value", "Get first name");
		getAccountDetailsLastName=getAttribute(ElsevierObjects.educator_form_txtLastName,"value","Get Last Name");
		getAccountDetailsEmail=getAttribute(ElsevierObjects.educator_form_txtEmail,"value","Get email id.");
	   if(username!=null){
		   Reporters.SuccessReport("Get Username","Click on Account settings Successfully and Username is :" +username);
	   }else{
		   Reporters.failureReport("Get Username", "Failed to click on Account settings and get username");
	   }
	   Thread.sleep(low);
	   click(ElsevierObjects.myAccount,"Click on MyAccount");
	   if(click(ElsevierObjects.Student_Logout,"Click on logout button")){
		    Reporters.SuccessReport("Click on logout","User is Successfully logout");
	   }else{
			Reporters.failureReport("Click on logout","User is failed to logout");
	   }
	   Thread.sleep(low);
	   if(click(ElsevierObjects.Student_Home_Login,"Click on login button")){
			Reporters.SuccessReport("Click on login", "User is Successfully login with the created student details");
	   }else{
		    Reporters.failureReport("Click on login", "User is failed to login with the created student details");
	   }
	   type(ElsevierObjects.common_login_userName,username,"Enter username in the textbox");
	   Thread.sleep(low);
	   type(ElsevierObjects.common_login_passWord,Password,"Enter Password in the textbox");
	   Thread.sleep(low);
	   click(ElsevierObjects.submit,"Click Login button.");
	   Thread.sleep(medium);
	   click(ElsevierObjects.catalog,"Click on Catalog link");
	   Thread.sleep(medium);
	   type(ElsevierObjects.Search_Online_Courses,isbn,"Enter the ISBN number in the searchbox");
	   Reporters.SuccessReport("Enter ISBN","Isbn is entered Successfully and Product is searched from Simulations Honeypot "+isbn);
	   Thread.sleep(medium);
	   click(ElsevierObjects.Search_Button,"Click on search button");
	  Thread.sleep(medium);
	  String price = getText(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomprice,"Get the price present there");
	  float p=convertStringToPrice(price);
	  float e=convertStringToPrice(ExpectedPrice);
	   if(p>e){
		    Reporters.SuccessReport("Verify price of the product","Price of The Product Is Greater Than Zero:"+p);
	   }else{
		    Reporters.failureReport("Verify price of the product","Failed to verify Price of The Product.");
	   }
	   Thread.sleep(low);
	  
      }
	catch(Exception e)
	{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		return false;
	}
	 return flag;
	}
	 
	 public static boolean emailVerification() throws Throwable{
		 boolean flag=true;
		 try
	    { 
		 
	   	 launchUrl(configProps.getProperty("EmailURL"));
	   	 Thread.sleep(medium);
		 type(ElsevierObjects.emailaddress,configProps.getProperty("verifyemail_username"),"Enter email id");
		 Thread.sleep(medium);
	     type(ElsevierObjects.emailpassword,configProps.getProperty("verifyemail_password"),"Enter password");
		 Thread.sleep(medium);
		 click(ElsevierObjects.emaillogin, "Click on Login Button.");
		 Thread.sleep(medium);
		 click(ElsevierObjects.email_Icon,"Click on Email icon.");
		 Thread.sleep(medium);
		 click(ElsevierObjects.email_dropdown,"Click on Dropdown.");
	     Thread.sleep(medium);
		 click(ElsevierObjects.email_dropdown_Fromchk,"Click on From check box.");
		 Thread.sleep(medium);
		 click(ElsevierObjects.email_dropdown_Tochk,"Click on To checkbox.");
	   	 Thread.sleep(medium);
		 type(ElsevierObjects.email_SearchBox, EmailId,"Enter the email id.");
		 Thread.sleep(medium);
		 click(ElsevierObjects.email_SearchIcon,"Click on search icon.");
		 Thread.sleep(high);
		 click(ElsevierObjects.Email_selection,"Click on welcome to evolve");
		 Thread.sleep(medium);
		 switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
		 Thread.sleep(medium);
		 String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
		 if(emailBody.contains(Firstname) && emailBody.contains(Lastname) && emailBody.contains(EmailId) && emailBody.contains(username) && emailBody.contains(Password)){
		 driver.switchTo().defaultContent();
		 if(click(ElsevierObjects.email_logout,"Click on logout."))
		 {
			Reporters.SuccessReport("Verifying User details In Email Body.</br>Clicking On Logout Button.","Successfully Verified Username: "+username+"</br>Password: "+Password+"</br>Firstname: "+Firstname+" </br>Lastname: "+Lastname+"</br>Email:"+EmailId+"</br>Successfully Clicked On Logout Button </br></br> Email Body Is: "+emailBody+"</br>");
		 }else{
			Reporters.failureReport("Verifying User details In Email Body.</br>Clicking On Logout Button.", "Failed To Verify User Details.</br>Failed To Click On Logout Button.  Email Body Is: "+emailBody+"</br>");
		 }
	    }
		else{
	 		Reporters.failureReport("Verifying User details In Email Body.", "Failed To Verify User Details in Email Body.");
	    }	 
		}
	 catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}
	 return flag;
	}
}
