package com.cigniti.automation.Test;

import java.util.Random;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class Search_RemoveCancelledandRemoveOutofPrintProducts_UserSearchNoResults_15477and15595 extends EvolveCommonBussinessFunctions{
	Random ra = new Random( System.currentTimeMillis() );
	@Test
	public void Search_RemoveCancelledandRemoveOutofPrintProducts_UserSearchNoResultsISBN_15477and15595() throws Throwable{
		try 
		{       //HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			
			stepReport("Search for first product as student");
			writeReport(SwitchToBrowser(ElsevierObjects.studentBrowserType),"Launching Browser to Portal User","Launching Browser to Portal User is succesful","Lanching Browser to Portal User is failed");

			Thread.sleep(low);
			String Catalogs1=ReadingExcel.columnDataByHeaderName("SearchElement1", "UserTC-15477and15595", configProps.getProperty("TestData"));
			String ISBN1=ReadingExcel.columnDataByHeaderName("ISBN1", "UserTC-15477and15595", configProps.getProperty("TestData"));
			String FullNameofISBN1=ReadingExcel.columnDataByHeaderName("Title1", "UserTC-15477and15595", configProps.getProperty("TestData"));
			
			System.out.println("*********************************Login As Student****************************");
			
			writeReport(User_BusinessFunction.Studentlogin(sStudentUser, sStudentPassword),"Login to Application Using User Credentials"+sStudentUser,
	        		                                                                           "Launching the URL for User is successful </br > Login to Application Using User credentails :"+sStudentUser+" is Successful",
	        		           		                                                           "Launching and Login to Application Using User credentails : "+ sStudentUser+" is Failed");
			Thread.sleep(medium);
			writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as:"+sStudentUser,
	                                                                 "Navigating to CATALOG page is Successful",
	                                                                 "Navigating to CATALOG Page is failed");
			Thread.sleep(medium);
			
			writeReport(User_BusinessFunction.HESI_Search(Catalogs1),"Searching for Value:"+Catalogs1,
	                                                                   "Entered "+Catalogs1+" to Search </br > Click on Go Button",
	                                                                   "Unable to Search for : "+ Catalogs1);
		    
				
			Thread.sleep(medium);	
			
			writeReport(!User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,FullNameofISBN1),"Verifying Title Values: "+FullNameofISBN1+" Present in Results",
                     "The Acutal Value from  Application is : "+sActualValues+", is Not Present in the results",
                     "The Acutal Value from  Application is : "+sActualValues+" ,is  Presented in the results");
			Thread.sleep(medium);
			
			writeReport(User_BusinessFunction.HESI_Search(ISBN1),"Searching for Value:"+ISBN1,
                     "Entered "+Catalogs1+" to Search </br > Click on Go Button",
                     "Unable to Search for : "+ Catalogs1);
			Thread.sleep(medium);	
			
			writeReport(User_BusinessFunction.VerifyNoResults(),"Verifying Title Values: "+FullNameofISBN1+" and ISBN is: "+ISBN1+" in Results",
                     "Search Results page  displayed 'No results found!' in center section and </br>'0 Results found!' displayed, Hence Test is Passed ",
                     "The Search Results Displayed and Total Results are : "+sActualValues);
			Thread.sleep(medium);
			
			writeReport(User_BusinessFunction.Logout(),"Clicking on Logout",
			     "Clicking on Logout is Successful",
			     "Clicking on Logout is not Successful");

			stepReport("Search for first product as educator"); 
			writeReport(User_BusinessFunction.LaunchEducator(),"Launch URL navigate to Educator View",
                     "Launching the URL for Educator is successful </br > Navigate to Educator View is Successful",
                     "Launching the URL for Educator is Not successful or </br > Navigate to Educator View is Not Successful");
			Thread.sleep(medium);
			
			writeReport(User_BusinessFunction.HESI_Search(Catalogs1),"Searching for Value:"+Catalogs1,
		                                                                   "Entered "+Catalogs1+" to Search </br > Click on Go Button",
		                                                                   "Unable to Search for : "+ Catalogs1);
			Thread.sleep(medium);	
			
			writeReport(!User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,FullNameofISBN1),"Verifying Title Values: "+FullNameofISBN1+" Present in Results",
	                     "The Acutal Value from  Application is : "+sActualValues+", is Not Present in the results",
	                     "The Acutal Value from  Application is : "+sActualValues+" ,is  Presented in the results");
			Thread.sleep(medium);
			
			writeReport(User_BusinessFunction.HESI_Search(ISBN1),"Searching for Value:"+ISBN1,
	                     "Entered "+Catalogs1+" to Search </br > Click on Go Button",
	                     "Unable to Search for : "+ Catalogs1);
			Thread.sleep(medium);
			
			writeReport(User_BusinessFunction.VerifyNoResults(),"Verifying Title Values: "+FullNameofISBN1+" and ISBN is: "+ISBN1+" in Results",
	                     "Search Results page  displayed 'No results found!' in center section and </br>'0 Results found!' displayed, Hence Test is Passed ",
	                     "The Search Results Displayed and Total Results are : "+sActualValues);
			Thread.sleep(medium);
			
			stepReport("Search for second product as student");
			Catalogs1=ReadingExcel.columnDataByHeaderName("SearchElement2", "UserTC-15477and15595", configProps.getProperty("TestData"));
			ISBN1=ReadingExcel.columnDataByHeaderName("ISBN2", "UserTC-15477and15595", configProps.getProperty("TestData"));
			FullNameofISBN1=ReadingExcel.columnDataByHeaderName("Title2", "UserTC-15477and15595", configProps.getProperty("TestData"));
			Thread.sleep(medium);
			
			writeReport(User_BusinessFunction.Studentlogin(sStudentUser, sStudentPassword),"Login to Application Using User Credentials"+sStudentUser,
					"Launching the URL for User is successful </br > Login to Application Using User credentails :"+sStudentUser+" is Successful",
					"Launching and Login to Application Using User credentails : "+ sStudentUser+" is Failed");
			Thread.sleep(medium);
			
			writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as:"+sStudentUser,
					"Navigating to CATALOG page is Successful",
					"Navigating to CATALOG Page is failed");
			Thread.sleep(medium);
			
			writeReport(User_BusinessFunction.HESI_Search(Catalogs1),"Searching for Value:"+Catalogs1,
					"Entered "+Catalogs1+" to Search </br > Click on Go Button",
					"Unable to Search for : "+ Catalogs1);
			Thread.sleep(medium);	
			
			writeReport(!User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,FullNameofISBN1),"Verifying Title Values: "+FullNameofISBN1+" Present in Results",
					"The Acutal Value from  Application is : "+sActualValues+", is Not Present in the results",
					"The Acutal Value from  Application is : "+sActualValues+" ,is  Presented in the results");
			
			writeReport(User_BusinessFunction.HESI_Search(ISBN1),"Searching for Value:"+ISBN1,
					"Entered "+Catalogs1+" to Search </br > Click on Go Button",
					"Unable to Search for : "+ Catalogs1);
			
			Thread.sleep(medium);	
			writeReport(User_BusinessFunction.VerifyNoResults(),"Verifying Title Values: "+FullNameofISBN1+" and ISBN is: "+ISBN1+" in Results",
					"Search Results page  displayed 'No results found!' in center section and </br>'0 Results found!' displayed, Hence Test is Passed ",
					"The Search Results Displayed and Total Results are : "+sActualValues);
			Thread.sleep(medium);	
			
			writeReport(User_BusinessFunction.Logout(),"Clicking on Logout",
					"Clicking on Logout is Successful",
					"Clicking on Logout is not Successful");
			
			stepReport("Search for second product as educator");
			writeReport(User_BusinessFunction.LaunchEducator(),"Launch URL navigate to Educator View",
					"Launching the URL for Educator is successful </br > Navigate to Educator View is Successful",
					"Launching the URL for Educator is Not successful or </br > Navigate to Educator View is Not Successful");
			Thread.sleep(medium);
			
			writeReport(User_BusinessFunction.HESI_Search(Catalogs1),"Searching for Value:"+Catalogs1,
					"Entered "+Catalogs1+" to Search </br > Click on Go Button",
					"Unable to Search for : "+ Catalogs1);
			Thread.sleep(medium);	
			
			writeReport(!User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Title ,FullNameofISBN1),"Verifying Title Values: "+FullNameofISBN1+" Present in Results",
					"The Acutal Value from  Application is : "+sActualValues+", is Not Present in the results",
					"The Acutal Value from  Application is : "+sActualValues+" ,is  Presented in the results");
			
			writeReport(User_BusinessFunction.HESI_Search(ISBN1),"Searching for Value:"+ISBN1,
					"Entered "+Catalogs1+" to Search </br > Click on Go Button",
					"Unable to Search for : "+ Catalogs1);
			
			writeReport(User_BusinessFunction.VerifyNoResults(),"Verifying Title Values: "+FullNameofISBN1+" and ISBN is: "+ISBN1+" in Results",
					"Search Results page  displayed 'No results found!' in center section and </br>'0 Results found!' displayed, Hence Test is Passed ",
					"The Search Results Displayed and Total Results are : "+sActualValues);
			
			stepReport("Search for third product as student");
			ISBN1=ReadingExcel.columnDataByHeaderName("ISBN3", "UserTC-15477and15595", configProps.getProperty("TestData"));
			Thread.sleep(medium);
			
			writeReport(User_BusinessFunction.Studentlogin(sStudentUser, sStudentPassword),"Login to Application Using User Credentials"+sStudentUser,
					"Launching the URL for User is successful </br > Login to Application Using User credentails :"+sStudentUser+" is Successful",
					"Launching and Login to Application Using User credentails : "+ sStudentUser+" is Failed");
			Thread.sleep(medium);
			
			writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as:"+sStudentUser,
					"Navigating to CATALOG page is Successful",
					"Navigating to CATALOG Page is failed");
			Thread.sleep(medium);
			
			writeReport(User_BusinessFunction.HESI_Search(ISBN1),"Searching for Value: "+ISBN1,
					"Entered " + ISBN1 + " to Search </br >Click on Go Button",
					"Unable to Search for: "+ ISBN1);
			
			Thread.sleep(medium);	
			writeReport(User_BusinessFunction.VerifyNoResults(),"Verifying ISBN is: "+ISBN1+" in Results",
					"Search Results page  displayed 'No results found!' in center section and </br>'0 Results found!' displayed, Hence Test is Passed ",
					"The Search Results Displayed and Total Results are : "+sActualValues);
			Thread.sleep(medium);	
			
			writeReport(User_BusinessFunction.Logout(),"Clicking on Logout",
					"Clicking on Logout is Successful",
					"Clicking on Logout is not Successful");
			
			stepReport("Search for third product as educator");
			writeReport(User_BusinessFunction.LaunchEducator(),"Launch URL navigate to Educator View",
					"Launching the URL for Educator is successful </br > Navigate to Educator View is Successful",
					"Launching the URL for Educator is Not successful or </br > Navigate to Educator View is Not Successful");
			Thread.sleep(medium);
			
			writeReport(User_BusinessFunction.HESI_Search(ISBN1),"Searching for Value: "+ISBN1,
					"Entered " + ISBN1 + " to Search </br >Click on Go Button",
					"Unable to Search for: "+ ISBN1);
			
			writeReport(User_BusinessFunction.VerifyNoResults(),"Verifying ISBN is: " + ISBN1 + " in Results",
					"Search Results page  displayed 'No results found!' in center section and </br>'0 Results found!' displayed, Hence Test is Passed ",
					"The Search Results Displayed and Total Results are : "+sActualValues);
				 
		}
		
		
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
