package com.cigniti.automation.BusinessFunctions;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class CreateFacultyUserfromSplashPage_9799 extends EvolveCommonBussinessFunctions {

	
	//Common Business logic for Tc-9800,Tc-9801,8798,9799
		public static boolean emailBodyVerification(String Title,String user) throws Throwable{
			boolean flag=true;
			  String reLoginUser=EvolveCommonBussinessFunctions.dynamicUserName;
			  String reLoginPassword=EvolveCommonBussinessFunctions.dynamicPassword;

			try{
			//String email=tc_9798.get("user_email");
			if(type(ElsevierObjects.email_SearchBox,getAccountDetailsEmail,"Enter the email id.")){
				Reporters.SuccessReport("Searching The EmailId.", "Successfully Entered email: "+emailAdress);
			}
			else{
				Reporters.failureReport("Searching The EmailId.", "Failed To Enter email: "+emailAdress);
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.email_SearchIcon,"Click on search icon.")){
				flag=false;
			}
			Thread.sleep(veryhigh);
			titleInEmail=getText(ElsevierObjects.titleInEmail, "Get title in evolve email page.");
			System.out.println( "titleInEmail:"+titleInEmail);
			if(titleInEmail.contains(Title)){
				Reporters.SuccessReport("Verifying Title In Email Body.", "Successfully Verified Title: "+titleInEmail+" in email.");
			}
			else{
				Reporters.failureReport("Verifying Title In Email Body.", "Failed To Verify Title In Email Body. Actual Title is:"+titleInEmail+"Expected Title is:"+Title);
			}
			
				if(!switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame")){
				flag=false;
			}
			Thread.sleep(medium);
			String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
			emailBody=emailBody.replaceAll("<", "| ");
			emailBody=emailBody.replace(">", "  |");	
			//String firstName=tc_9798.get("user_firstname");
			//String studentlastName=tc_9798.get("student_lastname");
			//String facultyLastName=tc_9798.get("faculty_lastname");
			if(user.equalsIgnoreCase("educator")){
				if(emailBody.trim().contains(getAccountDetailsFirstName.trim()) && emailBody.trim().contains(getAccountDetailsLastName.trim())&& emailBody.trim().contains(getAccountDetailsEmail.trim()) && emailBody.trim().contains(reLoginUser.trim()) && emailBody.trim().contains(reLoginPassword.trim())){
					System.out.println("Check user details in email.");
					driver.switchTo().defaultContent();
					if(click(ElsevierObjects.email_logout,"Click on logout.")){
						
						Reporters.SuccessReport("Verifying User details In Email Body.</br>Clicking On Logout Button.","Successfully Verified Username: "+reLoginUser+"</br>Password: "+reLoginPassword+"</br>Firstname: "+getAccountDetailsFirstName+" </br>Lastname: "+getAccountDetailsLastName+"</br>Email:"+getAccountDetailsEmail+"</br>Successfully Clicked On Logout Button </br></br> Email Body Is: "+emailBody+"</br>");
					}
					else{
						Reporters.failureReport("Verifying User details In Email Body.</br>Clicking On Logout Button.", "Failed To Verify User Details.</br>Failed To Click On Logout Button.  Email Body Is: "+emailBody+"</br>");
					}
				}
				else{
					Reporters.failureReport("Verifying User details In Email Body.", "Failed To Verify User Details in Email Body.");
				}
			}
			if(user.equalsIgnoreCase("student")){
				if(emailBody.trim().contains(getAccountDetailsFirstName.trim()) && emailBody.trim().contains(getAccountDetailsLastName.trim()) && emailBody.trim().contains(getAccountDetailsEmail.trim()) && emailBody.trim().contains(reLoginUser.trim()) && emailBody.trim().contains(reLoginPassword.trim())){
					System.out.println("Check user details in email.");
					driver.switchTo().defaultContent();
					if(click(ElsevierObjects.email_logout,"Click on logout.")){
						Reporters.SuccessReport("Verifying User details In Email Body.</br>Clicking On Logout Button.", "Email Body Is: "+emailBody+"</br>Successfully Verified username: "+reLoginUser+",password: "+reLoginPassword+",firstname: "+getAccountDetailsFirstName+",lastname: "+getAccountDetailsLastName+",email:"+getAccountDetailsEmail+"</br>Successfully Clicked On Logout Button.");
					}
					else{
						Reporters.failureReport("Verifying User details In Email Body.</br>Clicking On Logout Button.", "Failed To Verify User Details.</br>Failed To Click On Logout Button.");
					}
				}
				else{
					Reporters.failureReport("Verifying User details In Email Body.", "Failed To Verify User Details in Email Body.");
				}
				}
			
			}
			catch(Exception e){
				sgErrMsg=e.getMessage();
				System.out.println(e);return false;
			}
		return flag;
		}
}
