package com.cigniti.automation.BusinessFunctions;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Accessories;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class LO_GlobalCourse_9826 extends EvolveCommonBussinessFunctions{



	//Add product to Cart.
	public static boolean addProductToCart() throws Throwable{
		//String product = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("Product"); 
		//return LO_GlobalStudent.addProductToCart(product);
		return LO_GlobalStudent_8571.addProductToCart(readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")));
	}

	//Checkout the product.
	public static boolean checkOut() throws Throwable{
		return LO_GlobalStudent_8571.checkOut();
	}

	//Fill 'Update Your Account" Form.
	public static boolean formFill(String user) throws Throwable{
		try
		{
			Map<String, String> formMap = new HashMap<String, String>();
			String[] testDataArr = new String[]{"FirstName","LastName","CountryValue", "InstutionName", "InstutionAdd", "InstutionAdd2",
					"Town", "Province", "PostalCode", "PhoneNumber", "ProgramValue", "GraduationYear"};

			for(String testData : testDataArr){
				formMap.put(testData, readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get(testData));
			}

			//ReadingExcel.updateCellValue(6, 1, configProps.getProperty("TestData"), 18);
			Random ra = new Random( System.currentTimeMillis() );
			//String StdEmail = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("Email")+Integer.toString((1 + ra.nextInt(2)) * 1000 + ra.nextInt(1000))+"@evolveqa.info";
			String StdEmail = "automationEvolveqa"+Integer.toString((1 + ra.nextInt(2)) * 1000 + ra.nextInt(1000))+"@evolveqa.info";
			formMap.put("Email", StdEmail);

			//ReadingExcel.updateCellValue(7, 1, configProps.getProperty("TestData"), 18);
			formMap.put("ConfirmEmail", StdEmail);

			return LO_GlobalStudent_8571.formFill(formMap, user);
		}
		catch(Exception e)

		{

			sgErrMsg=e.getMessage();

			return false;
		}
	}

	public static boolean submitOrder(String user) throws Throwable{
		return LO_GlobalStudent_8571.submitOrder(user);
	}


	public static boolean checkIsEnabled(By locator, String locatorName) throws Throwable {
		//Boolean value = false;
		boolean flag=false;
		try {
			if (driver.findElement(locator).isEnabled()) {
				flag=true;

			}

		} catch (Exception e) {

			flag=false;
		}return flag;
	}
	public static boolean check_Approvedstatus() throws Throwable {
		boolean flag=true;
		try
		{
			String s1=getText(ElsevierObjects.Admin_Apprstatus_BeforeChk,"Status");
			Thread.sleep(medium);
			if(click(ElsevierObjects.Admin_AdoptionSerach_Approve_chk,"Adoption checkbox click")){
				Reporters.SuccessReport("Clicking On Approved Checkbox.", "Sucessfully Clicked On Approved Checkbox.");
			}
			else{
				Reporters.failureReport("Clicking On Approved Checkbox.","Failed To Click On Approved Checkbox." );

			}

			Thread.sleep(medium);
			if(click(ElsevierObjects.Admin_Submit_btn,"submit button click")){
				Reporters.SuccessReport("Clicking On Submit Button After Clicking Checking Approved Checkbox.", "Sucessfully Clicked On Submit Button After Clicking Checking Approved Checkbox.</br>Status is changed from Pending To Approved.");
			}
			else{
				Reporters.failureReport("Clicking On Submit Button After Clicking Checking Approved Checkbox..","Failed To Click On Submit Button." );
			}
			Thread.sleep(medium);
			if(checkIsEnabled(ElsevierObjects.Admin_AdoptionSerach_Approve_chk, "")){
				Reporters.failureReport("Verifying Whether Adoption Checkbox is Disabled Or Not.", "Approved CheckBox is in Enabled state.");
			}
			else{
				Reporters.SuccessReport("Verifying Whether Adoption Checkbox is Disabled Or Not.", "Approved Checkbox is in Disabled state.");
			}
			if(isChecked(ElsevierObjects.Admin_AdoptionSerach_Approve_chk, "")){
				Reporters.SuccessReport("Verifying Whether Adoption Checkbox is Checked Or Not.", "Approved Checkbox is Checked.");
			}
			else{
				Reporters.failureReport("Verifying Whether Adoption Checkbox is Checked Or Not.", "Approved CheckBox is not Checked.");
			}
			String s2=getText(ElsevierObjects.Admin_Apprstatus_AfterChk,"Status");
			System.out.println(s2);

			if(s1!=s2){
				if(click(ElsevierObjects.Admin_Fulfil_chk,"Fullfilled checkbox click")){
					Reporters.SuccessReport("Clicking On Fulfilled Checkbox.", "Sucessfully Clicked On Fulfilled Checkbox.");
				}
				else{
					Reporters.failureReport("Clicking On Fulfilled Checkbox.","Failed To Click On Fulfilled Checkbox." );
				}
				Thread.sleep(medium);
				if(click(ElsevierObjects.Admin_Submit_btn,"submit button click")){
					Reporters.SuccessReport("Clicking On Submit Button After Clicking Checking Fulfill And Email Checkbox.", "Sucessfully Clicked On Submit Button After Clicking Checking Fulfill And Email Checkbox.</br>Status is changed from Approved To Fulfilled.");
				}
				else{
					Reporters.failureReport("Clicking On Submit Button After Clicking Checking Fulfill And Email Checkbox..","Failed To Click On Submit Button." );
				}
				Thread.sleep(medium);
				if(checkIsEnabled(ElsevierObjects.Admin_Fulfil_chk, "")){
					Reporters.failureReport("Verifying Whether Fulfilled Checkbox is Disabled Or Not.", "Fulfilled CheckBox is in Enabled state.");
				}
				else{
					Reporters.SuccessReport("Verifying Whether Fulfilled Checkbox is Disabled Or Not.", "Fulfilled Checkbox is in Disabled state.");
				}
				Thread.sleep(medium);
				if(isChecked(ElsevierObjects.Admin_Fulfil_chk, "")){
					Reporters.SuccessReport("Verifying Whether Fulfilled Checkbox is Checked Or Not.", "Fulfilled Checkbox is Checked.");
				}
				else{
					Reporters.failureReport("Verifying Whether Fulfilled Checkbox is Checked Or Not.", "Fulfilled CheckBox is not Checked.");
				}
				Thread.sleep(medium);
			}
		}
		catch(Exception e)

		{

			sgErrMsg=e.getMessage();

			return false;
		}
		return flag;
	}
	/*public static boolean check_Approvedstatus() throws Throwable{
		boolean flag = true;

	   	 if(!LO_Global_Instructor_AR_8572.check_Approvedstatus(trial)){
	   		 flag = false;
	   	 }

	   	 if(!click(ElsevierObjects.Admin_Evolve_lnk,"Click 'Evolve Admin' link.")){
	   		 flag = false;
	   	 }
		return flag;
	}*/

	public static boolean searchAdoptionRequest() throws Throwable{
		Map<String, String> formMap = new HashMap<String, String>();
		formMap.put("FirstName", readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("FirstName"));
		formMap.put("SearchDate", readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("SearchDate"));
		return searchAdoptionRequest(formMap);
	}

	//Click on the Adoption Request Link
	public static boolean searchAdoptionRequest(Map<String, String> formMap) throws Throwable{
		boolean flag=true;
		Thread.sleep(medium);

		if(click(ElsevierObjects.searchAR,"Adoption Requests")){
			Reporters.SuccessReport("Clicking On Search Adoption Requests.", "Successfully Clicked On Search Adoption Request Link.");
		}
		else{
			Reporters.failureReport("Clicking On Search Adoption Requests.", "Failed To Click On Search Adoption Request Link.");
		}
		if(!waitForElementPresent(ElsevierObjects.btndatesearch, "search button")){
			flag = false;
		}
		if(click(ElsevierObjects.rbtndate, "date Radio button")){
			Reporters.SuccessReport("Clicking On Todays Radio Button.", "Successfully Clicked On Todays Radio Button.");
		}
		else{
			Reporters.failureReport("Clicking On Todays Radio Button.", "Failed Clicked On Todays Radio Button.");
		}
		Thread.sleep(medium);

		if(!click(ElsevierObjects.btndatesearch_AR, "ToDay date Radio button")){
			flag = false;
		}
		selectByVisibleText(ElsevierObjects.selectdays, "Today", "Select Today's locator");

		if(!waitForElementPresent(ElsevierObjects.btndatesearch_AR, "search button")){
			flag = false;
		}
		
		/*if(!click(ElsevierObjects.btndatesearch, "Search button")){
			flag = false;
		}*/



		/*		 String daysBack = formMap.get("SearchDate");
		 if(daysBack!=null){
			 if(!selectByVisibleText(ElsevierObjects.Admin_SearchAR_DaysBack, daysBack, "'"+daysBack+"' is not available in the drop down")){
				 flag = false;
			 }


	   	 }
	 	if(!click(ElsevierObjects.rbtndate, "date Radio button")){
	   		flag = false;
	   	}*/
		if(formMap.get("FirstName")!=null){
			if(!type(ElsevierObjects.Admin_SearchAR_FirstName,formMap.get("FirstName"), "text to search by first name.")){
				flag = false;
			}		   		 
		}else{
			System.out.println("INFO: Search is not done using 'First Name'.");
		}

		if(formMap.get("UserName")!=null){
			if(!type(ElsevierObjects.Adoption_userId, formMap.get("UserName"), "Adoption search User Id")){
				flag = false;
			}	   		 
		}else{
			System.out.println("INFO: Search is not done using 'User Name'.");
		}


		if(!click(ElsevierObjects.btndatesearch, "search button")){
			flag = false;
		}
		if(!waitForElementPresent(ElsevierObjects.lnkorderedAR, "ordered AR")){
			flag = false;
		}
		if(!click(ElsevierObjects.lnkorderedAR, "ordered AR")){
			flag = false;
		}
		return flag;
	}

	//Verify CourseList contains courseId.
	public static boolean verifyCourseListContainsCourseID() throws Throwable{
		String courseId = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("CourseID");
		return LO_GlobalStudent_8571.verifyCourseListContainsCourseID(courseId);
	}

	//Click on the contentLink.
	public static boolean clickContentLink() throws Throwable{
		String courseId = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("CourseID");
		return LO_GlobalStudent_8571.clickContentLink(courseId);
	}

	//Verify's courseTitle.
	public static boolean verifyCourseTitle() throws Throwable{
		String courseTitle = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("CourseTitle");
		return LO_GlobalStudent_8571.verifyCourseTitle(courseTitle);
	}	

	/** Generic method for searching the user profile.
	 * 
	 * @param searchMap
	 * @return
	 * @throws Throwable
	 */
	public static boolean viewUserProfile(String username) throws Throwable{
		boolean flag = true;
		try
		{
			if(click(ElsevierObjects.Admin_ViewEdit_UserProfile, "Click on View/Edit Evolve User PRofile")){
				Reporters.SuccessReport("Clicking On View/Edit Evolve User Profile link.", "Successfully Clicked On View/Edit User Profile Link.");
			}
			else{
				Reporters.failureReport("Clicking On View/Edit Evolve User Profile link.", "Failed To Click On View/Edit User Profile Link.");
			}
			Thread.sleep(medium);

			if(type(ElsevierObjects.Admin_SearchUser_UserName, username, "Input UserName")){
				Reporters.SuccessReport("Entering userName in View/Edit Evolve User Profile Page.", "Entered userName "+username+" in View/Edit Evolve User Profile Page.");
			}
			else{
				Reporters.failureReport("Entering userName in View/Edit Evolve User Profile Page.", "Failed To Enter userName "+username+" in View/Edit Evolve User Profile Page.");
			}	
			Thread.sleep(medium);
			if(click(ElsevierObjects.Admin_SearchUser_SearchButton, "Click on Search Button")){
				Reporters.SuccessReport("Clicking On Search Button After Entering Username.", "Successfully Clicked On Search Button.");
			}
			else{
				Reporters.failureReport("Clicking On Search Button After Entering Username.", "Failed To Click On Search Button.");
			}

			/*Thread.sleep(low);
	   	if(!click(ElsevierObjects.Admin_ViewEdit_UserProfile, "click link 'View/Edit Evolve User Profile'")){
	   		 flag = false;
	   	 }		

		Thread.sleep(medium);
		if(searchMap.get("FirstName")!=null){
			if(!type(ElsevierObjects.Admin_SearchUser_FirstName,searchMap.get("FirstName"), "First Name")){
				flag = false;
			}			
		}else{
			System.out.println("INFO: Search is not performed using First name.");
		}

		if(searchMap.get("UserName")!=null){
			if(!type(ElsevierObjects.Admin_SearchUser_UserName,searchMap.get("UserName"), "User Name")){
				flag = false;
			}			
		}else{
			System.out.println("INFO: Search is not performed using User name.");
		}		

	   	if(!click(ElsevierObjects.Admin_SearchUser_SearchButton, "search button")){
	   		 flag = false;
	   	 }
			 */
		}
		catch(Exception e)

		{

			sgErrMsg=e.getMessage();

			return false;
		}
		return flag;
	}

	/*//Search User Profile
	public static boolean searchUserProfile() throws Throwable{
		Map<String, String> searchUserMap = new HashMap<String, String>();
		searchUserMap.put("UserName", readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData")).get("UserName"));
		return searchUserProfile(searchUserMap);
	}*/

	public static boolean editUserProfilePage(Map<String, String> editUserMap){
		boolean flag = true;
		try
		{
			String selectedAngelSystemRole = editUserMap.get("AngelSystemRoleSelected");

			//Verify the default value selected in the 'Angel System Role' drop down.
			Select select = new Select(driver.findElement(ElsevierObjects.Admin_EditUserProfileAngleSystemRole));
			if(select.getFirstSelectedOption().getText().equalsIgnoreCase(selectedAngelSystemRole)){

			}
		}
		catch(Exception e)

		{

			sgErrMsg=e.getMessage();

			return false;
		}

		return flag;
	}

	//Open user profile.
	public static boolean openEditUserProfilePage() throws Throwable{
		String userName = readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData")).get("UserName");
		String userNameXpath = Accessories.fetchDynamicLocator(ElsevierObjects.Admin_EditUserProfileUsingUserName.toString(), ElsevierObjects.ReplaceString1,userName);
		try
		{
			if(click(By.xpath(userNameXpath), "Click UserName to open UserProfile page.")){
				Reporters.SuccessReport("Clicking On Row in the search results that corresponds to this username.", "Successfully Clicked on The Username: "+userName);
			}
			else{
				Reporters.failureReport("Clicking On Row in the search results that corresponds to this username.", "Failed To Click on The Username: "+userName);
			}
			String angelSystemRole=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("AngelSystemRoleSelected");



			//Verify the default value selected in the 'Angel System Role' drop down.
			Select select = new Select(driver.findElement(ElsevierObjects.Admin_EditUserProfileAngleSystemRole));
			if(select.getFirstSelectedOption().getText().equalsIgnoreCase(angelSystemRole)){			
				Reporters.SuccessReport("On the user's profile page, verify the value in the Angel System Role dropdown.", "The Angel System Role for this user should now displayed as Faculty");
			}
			else{
				Reporters.failureReport("On the user's profile page, verify the value in the Angel System Role dropdown. ", "The Angel System Role for this user should now displayed as Faculty");
			}
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;
		}
		return flag;
	}



}
