package com.cigniti.automation.BusinessFunctions;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Accessories;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class LO_SelfStudy extends EvolveCommonBussinessFunctions{

	//Search Product.
	public static boolean searchProduct() throws Throwable{
		String product = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15570", configProps.getProperty("TestData")).get("Product"); 
		return LO_GlobalStudent_8571.searchProduct(product,null);
	}

	//Add product to Cart.
	public static boolean addProductToCart() throws Throwable{
		//String product = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15570", configProps.getProperty("TestData")).get("Product"); 
		//return LO_GlobalStudent.addProductToCart(product);
		return LO_GlobalStudent_8571.addProductToCart(readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15570", configProps.getProperty("TestData")));
	}
	
	//Fill 'Update Your Account" Form.
	public static boolean formFill(String user) throws Throwable{
		
		Map<String, String> formMap = new HashMap<String, String>();
		String[] testDataArr1 = new String[]{"FirstName","LastName","CountryValue", "InstutionName",
								"ProgramValue","GraduationYear","StudentID"};
		String[] testDataArr2 = new String[]{"BillingAdd", "BillingAdd2","BillingCity","BillingState","BillingZipCode","BillingAddressButtonToProceed"};
		
		Map<String, String> testDataMap1 = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData"));
		for(String testData : testDataArr1){
			formMap.put(testData, testDataMap1.get(testData));
		}
		
		Map<String, String> testDataMap2 = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15570", configProps.getProperty("TestData"));
		for(String testData : testDataArr2){
			formMap.put(testData, testDataMap2.get(testData));
		}

		//ReadingExcel.updateCellValue(6, 1, configProps.getProperty("TestData"), "TC-8571 & 9826");
		formMap.put("Email", readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("Email"));
		
		//ReadingExcel.updateCellValue(7, 1, configProps.getProperty("TestData"), "TC-8571 & 9826");
		formMap.put("ConfirmEmail", readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("ConfirmEmail"));
		
		return LO_GlobalStudent_8571.formFill(formMap, user);
	}		
	
	/** Generic method for verifying the data in Billing Address dialog.
	 * 
	 * @param billMap
	 * @return
	 * @throws Throwable
	 */
	public static boolean verifyBillingAddress(HashMap<String, String> billMap) throws Throwable{
		boolean flag = true;
	try{	
		Thread.sleep(medium);
		//At present the logic contains only for clicking the button.
		//Based on the test cases, more logic's will be implemented in the method.
		if(switchToFrameByLocator(ElsevierObjects.Student_BillingAdd_ModalDialog, "Switch to IFrame")){
			Reporters.SuccessReport("Verify Address Validation Pop Up displays to user", "Address Validation Pop Up is displayed to user successfully");
		}else{
			Reporters.failureReport("Verify Address Validation Pop Up displays to user", "Address Validation Pop Up is not displayed to user");
		}
		
		String buttonToClick = billMap.get("BillingAddressButtonToProceed");
		if(buttonToClick!=null){
			buttonToClick = buttonToClick.trim();
			String xpath = Accessories.fetchDynamicLocator(ElsevierObjects.Student_BillingAdd_ModalDialogButtons.toString(), ElsevierObjects.ReplaceString1, buttonToClick);
		   	 if(click(By.xpath(xpath),"Click '"+buttonToClick+"' button.")){
		   		Reporters.SuccessReport("If Address Validation Pop Up comes on screen click on either Use this Address button. ", "Clicked on the 'Use this Address button' successfully");
			}else{
				Reporters.failureReport("If Address Validation Pop Up comes on screen click on either Use this Address button. ", "Failed to Click on the 'Use this Address button' successfully");
			}			
		}
		
		if(!switchToDefaultFrame()){
			flag = false;
		}
		Thread.sleep(medium);
	}
	
	catch(Exception e){sgErrMsg=e.getMessage();
	System.out.println(e);return false;
	}
		return flag;
	}
	
	//Click on 'Use This Address' button.
	public static boolean verifyBillingAddress() throws Throwable{
		HashMap<String, String> billMap = new HashMap<String, String>();
		billMap.put("BillingAddressButtonToProceed", readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15570", configProps.getProperty("TestData")).get("BillingAddressButtonToProceed"));
		return verifyBillingAddress(billMap);
	}
	
	//Verify CourseList contains courseId.
	public static boolean verifyCourseListContainsCourseID() throws Throwable{
		String courseId = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15570", configProps.getProperty("TestData")).get("CourseID");
		return LO_GlobalStudent_8571.verifyCourseListContainsCourseID(courseId);
	}
	
	//Click on the contentLink.
	public static boolean clickContentLink() throws Throwable{
		String courseId = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15570", configProps.getProperty("TestData")).get("CourseID");
		return LO_GlobalStudent_8571.clickContentLink(courseId);
	}
	
	//Verify's courseTitle.
	public static boolean verifyCourseTitle() throws Throwable{
		String courseTitle = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15570", configProps.getProperty("TestData")).get("CourseTitle");
		return LO_GlobalStudent_8571.verifyCourseTitle(courseTitle);
	}	
	
	public static boolean verifyResourcesSubFoldersVisible() throws Throwable{
		boolean flag = true;
		try{
		Thread.sleep(medium);
		if(!click(ElsevierObjects.Student_Content_ResourcesFolder,"Click on Course Content.")){
			flag=false;
		}
		
		Thread.sleep(medium);
		String[] subfolderNames = (readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15570", configProps.getProperty("TestData")).get("ResourceSubFolderNames")).split(",");
		
		//Verify SubFolder names in Resource Folder.
		if(!LO_GlobalStudent_8571.verifyResourcesSubFolderNames(subfolderNames)){
			flag=false;
		}
		}
		catch(Exception e){sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
		return flag;
	}
	
	public static boolean openResourcesSubFoldersVisible(String folderName) throws Throwable{
		boolean flag = true;
		try{
		/*Thread.sleep(medium);
		int resourceSubFolderList = getElements(ElsevierObjects.Student_Update_Account_ResourcesFolder_SubfolderList).size();
		
		//Click/open the folder
		flag = false;
		for(int index=1; index<=resourceSubFolderList; index++){
			String xpath = Accessories.fetchDynamicLocator(ElsevierObjects.Student_Update_Account_ResourcesFolder_SubfolderName.toString(),ElsevierObjects.ReplaceString1, index+"");
			if(getText(By.xpath(xpath), "Fetch folder names").equalsIgnoreCase(folderName)){
				if(click(By.xpath(xpath), "click folder")){
					flag = true;
				}
			}
		}
		
		 Set<String> window = driver.getWindowHandles();
		 for(String s : window){
			 System.out.println("s>>>> "+s);
		 }*/
		Reporters.failureReport("Verify user has access to the protected content in this folder ", "Issue with the application, need to implement after gettting clarification.");
		}
		catch(Exception e){sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
		return flag;
	}	
	
	public static boolean openResourcesSubFoldersVisible() throws Throwable{
		try{
		String folderName = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15570", configProps.getProperty("TestData")).get("OpenResourceFolder");
		return openResourcesSubFoldersVisible(folderName);
		}
		catch(Exception e){sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
	}
	
	public static boolean studentLogout() throws Throwable{
		try{
		return instructorLogout(); 
	}
	
	catch(Exception e){sgErrMsg=e.getMessage();
	System.out.println(e);return false;
}
	}
	
	/** Generic method for searching the user name in the method.
	 * 
	 * @param searchMap
	 * @return
	 * @throws Throwable
	 */
	public static boolean searchCourseParReport(Map<String, String> searchMap) throws Throwable{
		boolean flag = true;
		try{
		Thread.sleep(medium);
		if(!click(ElsevierObjects.Admin_CourseParReport_Link,"Click on link 'Course PAR Report'.")){
			flag=false;
		}
		
		Thread.sleep(medium);
		if(searchMap.get("Course_ID") != null){
			if(!type(ElsevierObjects.Admin_CourseParReport_SearchField,searchMap.get("Course_ID"), "courseId")){
				flag = false;
			}			
		}
		
		if(!click(ElsevierObjects.Admin_CourseParReport_Search_Go,"Click on 'Go' button.")){
			flag=false;
		}
		
		Thread.sleep(medium);
		List<WebElement> list = getElements(ElsevierObjects.Admin_CourseParReport_Search_Results);
		
		if(searchMap.get("UserName") != null){
			flag = false;
			for(WebElement we : list){
				String userName = we.findElements(By.tagName("td")).get(0).findElement(By.tagName("span")).getText();
				System.out.println("INFO: User Name -"+userName);
				if(searchMap.get("UserName").trim().equalsIgnoreCase(userName)){
					flag = true;
					break;
				}
			}			
		}
		Thread.sleep(500);
	}
	catch(Exception e){sgErrMsg=e.getMessage();
	System.out.println(e);return false;
}
		return flag;
	}
	
	public static boolean searchCourseParReport() throws Throwable{
		Map<String, String> searchMap = new HashMap<String, String>();
		searchMap.put("Course_ID",readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15570", configProps.getProperty("TestData")).get("Course_ID"));
		searchMap.put("UserName",readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData")).get("UserName"));
		return searchCourseParReport(searchMap);
	}
	
}
