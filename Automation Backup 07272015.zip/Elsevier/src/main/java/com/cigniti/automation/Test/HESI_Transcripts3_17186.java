package com.cigniti.automation.Test;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class HESI_Transcripts3_17186 extends EvolveCommonBussinessFunctions{

	@Test
	public void HESI_Transcript3_17186() throws Throwable{
		
		try {
			
stepReport("Create new student user");
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String user = "student";
			EvolveCommonBussinessFunctions.CreateNewUser(user);
			
			if(click(ElsevierObjects.catalog,"Click Catalog link")){
				Reporters.SuccessReport("Click Catalog link", "Successfully Clicked on Catalog link");
			}else{
				Reporters.failureReport("Click Catalog link", "Failed to Click on Catalog link");}
				
				Thread.sleep(low);
			
stepReport("Validate HESI Transcript Link");
			
			if(click(ElsevierObjects.HESI_TRANSCRIPTS,"Click HESI Transcripts link")){
				Reporters.SuccessReport("Click HESI Transcripts link", "Successfully Clicked on HESI Transcripts link");
			}else{
				Reporters.failureReport("Click HESI Transcripts link", "Failed to Click on HESI Transcripts link");}
				
				Thread.sleep(low);
				
			if(click(ElsevierObjects.btnRegister,"Click Register Button")){
				Reporters.SuccessReport("Click REGISTER button", "Successfully Clicked on REGISTER button");
			}else{
				Reporters.failureReport("Click REGISTER button", "Failed to Click on REGISTER button");
			}
			Thread.sleep(low);
			
stepReport("Shopping Cart Validations");
			
			String transcriptISBN=ReadingExcel.columnDataByHeaderName("TRANSCRIPT_ISBN", "HESI_Transcript", testDataPath);
			String transcriptTitle=ReadingExcel.columnDataByHeaderName("TRANSCRIPT_TITLE", "HESI_Transcript", testDataPath);
			String transcriptSubmissionMSG=ReadingExcel.columnDataByHeaderName("TRANSCRIPT_SUBMISSION_MSG", "HESI_Transcript", testDataPath);
			
			String transcriptISBNfromCart = getText(ElsevierObjects.HESI_TRANSCRIPT_ISBN,"HESI Transcript ISBN from Cart");
			String transcriptTitlefromCart = getText(ElsevierObjects.HESI_TRANSCRIPT_TITLE,"HESI Transcript Title from Cart");
			
			//System.out.println(transcriptISBN);
			//System.out.println(transcriptTitle);
			//System.out.println(transcriptISBNfromCart);
			//System.out.println(transcriptTitlefromCart);
			
			Thread.sleep(low);
			
			if(transcriptISBNfromCart.contains(transcriptISBN)){
				Reporters.SuccessReport("Validate the ISBNs are equal", "ISBN is validated successfully <br> Expected ISBN is : "+transcriptISBN+"<br>  Actual ISBN is : "+transcriptISBNfromCart);
			}else{
				Reporters.failureReport("Validate the ISBNs are equal", "ISBNs do not match <br> Expected ISBN is : "+transcriptISBN+"<br> Actual ISBN is : "+transcriptISBNfromCart);
			}
			if(transcriptTitlefromCart.contains(transcriptTitle)){
				Reporters.SuccessReport("Validate Title contains HESI Transcript", "Title successfully contains HESI Transcript <br> Expected Title is : "+transcriptTitle+"<br>  Actual Title is : "+transcriptTitlefromCart);
			}else{
				Reporters.failureReport("Validate Title contains HESI Transcript", "Title does not display HESI Transcript <br> Expected Title is : "+transcriptTitle+"<br> Actual Title is : "+transcriptTitlefromCart);
			}
				
stepReport("Go to Review & Submit Page");		
				
			if(javaClick(ElsevierObjects.evolve_checkout_btn,"Click Redeem checkout button")){
				Reporters.SuccessReport("Click On Redeem CheckOut Button.", "Successfully clicked on Redeem Checkout Button."); 
			}
			else{
				Reporters.failureReport("Click On Redeem CheckOut Button.", "Failed to click on Redeem Checkout Button.");
			}
			Thread.sleep(low);
			
			stepReport("Update Profile");
			
			updateVSTandKNOAccount("student", "","false","");
			
			Thread.sleep(medium);
			
			if(creditCardDetails()){
				Reporters.SuccessReport("Submitted Credit Card Info", "Successfully submitted Credit Card Info."); 
			}
			else{
				Reporters.failureReport("Submitted Credit Card Info.", "Failed to submitted Credit Card Info.");
			}
			
			Thread.sleep(low);
			
stepReport("Checkout");
			
		transcriptISBNfromCart = getText(ElsevierObjects.HESI_TRANSCRIPT_ISBN,"HESI Transcript ISBN from Cart");
		transcriptTitlefromCart = getText(ElsevierObjects.HESI_TRANSCRIPT_TITLE,"HESI Transcript Title from Cart");
		
		Thread.sleep(low);
		
		if(transcriptISBNfromCart.contains(transcriptISBN)){
			Reporters.SuccessReport("Validate the ISBNs are equal", "ISBN is validated successfully <br> Expected ISBN is : "+transcriptISBN+"<br>  Actual ISBN is : "+transcriptISBNfromCart);
		}else{
			Reporters.failureReport("Validate the ISBNs are equal", "ISBNs do not match <br> Expected ISBN is : "+transcriptISBN+"<br> Actual ISBN is : "+transcriptISBNfromCart);
		}
		if(transcriptTitlefromCart.contains(transcriptTitle)){
			Reporters.SuccessReport("Validate Title contains HESI Transcript", "Title successfully contains HESI Transcript <br> Expected Title is : "+transcriptTitle+"<br>  Actual Title is : "+transcriptTitlefromCart);
		}else{
			Reporters.failureReport("Validate Title contains HESI Transcript", "Title does not display HESI Transcript <br> Expected Title is : "+transcriptTitle+"<br> Actual Title is : "+transcriptTitlefromCart);
		}
		
		if(click(ElsevierObjects.chkaccept,"Checkmark Registered User Agreement")){
			Reporters.SuccessReport("Checkmark Registered User Agreement", "Successfully checkmarked Registered User Agreement."); 
		}
		else{
			Reporters.failureReport("Checkmark Registered User Agreement", "Failed to checkmark Registered User Agreement.");
		}
		if(click(ElsevierObjects.btnsubmit,"Click Submit Order button")){
			Reporters.SuccessReport("Click Submit Order button", "Successfully clicked Submit Order button."); 
		}
		else{
			Reporters.failureReport("Click Submit Order button", "Failed to click Submit Order button.");
		}
		Thread.sleep(medium);
		
stepReport("Validate Order Submission");

		String transcriptMSGfromConfPage = getText(ElsevierObjects.TRANSCRIPT_SUBMISSION_MSG,"HESI Transcript Submission Message");

		if(transcriptSubmissionMSG.equals(transcriptMSGfromConfPage)){
			Reporters.SuccessReport("Validate HESI Transcript Confirmation Message matches expected", "HESI Transcript Confirmation Message is as expected <br> Expected message is : "+transcriptSubmissionMSG+"<br>  Actual message is : "+transcriptMSGfromConfPage);
		}else{
			Reporters.failureReport("Validate HESI Transcript Confirmation Message matches expected", "HESI Transcript Confirmation Message DOES NOT appear as expected <br> Expected message is : "+transcriptSubmissionMSG+"<br> Actual message is : "+transcriptMSGfromConfPage);
		}
		
		System.out.println(transcriptSubmissionMSG);
		System.out.println(transcriptMSGfromConfPage);
		
	}
		catch (Exception e) {
			System.out.println(e.getMessage());	
		}
	}}

