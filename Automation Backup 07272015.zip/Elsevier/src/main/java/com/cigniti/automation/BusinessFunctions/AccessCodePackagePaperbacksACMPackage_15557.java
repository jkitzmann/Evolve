package com.cigniti.automation.BusinessFunctions;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class AccessCodePackagePaperbacksACMPackage_15557 extends EvolveCommonBussinessFunctions{


	public static boolean  verifyTextPresent(String text) throws Throwable
	{  
		boolean flag=false;
		try{
			String bool=configProps.getProperty("OnSuccessReports");
			boolean b=Boolean.parseBoolean(bool);
			if(!(driver.getPageSource()).contains(text))
			{
				Reporters.SuccessReport("VerifyTextPresent",text+" is Not present in the page then click on ");
	
				flag= false;
			}
			else if(b && flag)
			{
	
				Reporters.failureReport("VerifyTextPresent",text+" is present in the page");
				flag= true;
	
			}
		}
		catch(Exception e){
		sgErrMsg=e.getMessage();return false;
		}
		return flag;
	}

	public static boolean studentShippingOrder(String street, String city, String state, String zip, String VSTPass, String secQue, String secAns, String KNOPass) throws Throwable{

	boolean flag=true;
	try{
		Thread.sleep(medium);
		if(!click(ElsevierObjects.Student_Shipping_Chk,"Click checkbox")){
			flag=false;
		}
		if(!type(ElsevierObjects.Student_Shipping_Addr1, street,"Enter student Street")){
			flag=false;
		}
		if(!type(ElsevierObjects.Student_Shipping_City,city,"Enter student City")){
			flag=false;
		}

		if(!selectByValue(ElsevierObjects.Student_Shipping_State,state, "State name")){
			flag=false;
		}

		if(!type(ElsevierObjects.Student_Shipping_Zip,zip,"Enter student Zipcode")){
			flag=false;
		}

		if(!type(ElsevierObjects.Student_Shipping_VKnoPwd,VSTPass,"Enter VKNO Password")){
			flag=false;
		}

		if(!selectByVisibleText(ElsevierObjects.Student_Shipping_SecurityQue,secQue, "Select Security Question")){
			flag=false;
		}

		if(!type(ElsevierObjects.Student_Shipiing_SecurityAns,secAns,"Enter student Security Answer")){
			flag=false;
		}

		if(!type(ElsevierObjects.Student_Shipping_KNOPwd, KNOPass,"Enter KNO Password")){
			flag=false;
		}

		if(isChecked(ElsevierObjects.Student_Shipping_AccpChk, "Click Check Box to Accept")){
			if(click(ElsevierObjects.Student_Shipping_ContBtn,"Click Continue Button")){
				Reporters.SuccessReport("Verify the user is asked to enter Shipping Address when the package contains paperbacks.", "User is successfully asked to enter the Shipping address<br> Shipping address is successfully entered with the following details: <br> "
						+ "Street Address : "+street+"<br> City : "+city+"<br> State : "+state+"<br> Zip : "+zip+"<br> VST Password : "+VSTPass+"<br> Security Question : "+secQue+"<br> Security Answer : "+secAns+"<br> KNO Password : "+KNOPass);
			}else{
				Reporters.failureReport("Verify the user is asked to enter Shipping Address when the package contains paperbacks.", "User is not asked to enter the Shipping address<br> Shipping address is failed to enter with the following details: <br> "
						+ "Street Address : "+street+"<br> City : "+city+"<br> State : "+state+"<br> Zip : "+zip+"<br> VST Password : "+VSTPass+"<br> Security Question : "+secQue+"<br> Security Answer : "+secAns+"<br> KNO Password : "+KNOPass);
			}
		}else
		{
			flag=true;
			click(ElsevierObjects.Student_Shipping_AccpChk,"Click Continue Button");
			if(click(ElsevierObjects.Student_Shipping_ContBtn,"Click Continue Button")){
				Reporters.SuccessReport("Verify the user is asked to enter Shipping Address when the package contains paperbacks.", "User is successfully asked to enter the Shipping address<br> Shipping address is successfully entered with the following details: <br> "
						+ "Street Address : "+street+"<br> City : "+city+"<br> State : "+state+"<br> Zip : "+zip+"<br> VST Password : "+VSTPass+"<br> Security Question : "+secQue+"<br> Security Answer : "+secAns+"<br> KNO Password : "+KNOPass);
			}else{
				Reporters.failureReport("Verify the user is asked to enter Shipping Address when the package contains paperbacks.", "User is not asked to enter the Shipping address<br> Shipping address is failed to enter with the following details: <br> "
						+ "Street Address : "+street+"<br> City : "+city+"<br> State : "+state+"<br> Zip : "+zip+"<br> VST Password : "+VSTPass+"<br> Security Question : "+secQue+"<br> Security Answer : "+secAns+"<br> KNO Password : "+KNOPass);
			}
		}

		Thread.sleep(veryhigh);
		Thread.sleep(veryhigh);
		if(!switchToFrameByLocator(ElsevierObjects.Student_register_frame,"Switch to frame")){
			flag=false;
		}
		Thread.sleep(medium);
		if(!click(ElsevierObjects.Student_register_UseAdress_btn,"Click UsethisAdress Button")){
			flag=false;
		}

		Thread.sleep(veryhigh);
		if(!javaClick(ElsevierObjects.Student_Shipping_Accept, "Click on Accept Button")){
			flag=false;
		}
		Thread.sleep(high);
		if(javaClick(ElsevierObjects.Student_Shipping_Submit, "Click on Submit Button")){
			Reporters.SuccessReport("Click on the Submit button", "Successfully clicked on the submit button");
		}else{
			Reporters.failureReport("Click on the Submit button", "Failed to click on the submit button");
		}
		Thread.sleep(veryhigh);
		Thread.sleep(veryhigh);
		String sucMsg=getText(ElsevierObjects.Student_Shipping_Comfirm, "Student Shipping Confirm Message.");
		if(verifyText(ElsevierObjects.Student_Shipping_Comfirm, "Thank you for your request! This product is now available in your Evolve  account. ", "Success Message")){
			Reporters.SuccessReport("The Order Confirmation Message ", "The Shipping Confirm Message : "+sucMsg+" is displayed");		
 		}else{
 			Reporters.failureReport("The Order Confirmation Message ", "The Shipping Confirm Message : "+sucMsg+" is failed to display");
 		}
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();return false;
	}
		return flag;
		
	}
	
	

	public static boolean verifyCopyToExcel() throws Throwable{
		boolean flag = true;
	try{
			UpdateColDataExcel ex=new UpdateColDataExcel();
	
			ex.UpdateColData(configProps.getProperty("excelpath"), configProps.getProperty("textpath"), "sheet1");
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
		return flag;
	
		}

	public static boolean evolve_StudentLogout() throws Throwable{

		boolean flag=true;
		try{
			if(!click(ElsevierObjects.Student_Logout,"Click Checkbox")){
				flag=false;
			}
		}
			catch(Exception e){
				sgErrMsg=e.getMessage();return false;
			}
		return flag;
	}
	
	public static boolean SignInAsDifferentUser(String Username,String Password) throws Throwable
	{
		try
		{
			boolean flag = true;
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			Thread.sleep(medium);
			if(!launchUrl(configProps.getProperty("URL"))){
				flag = false;
			}
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			Thread.sleep(medium);
			//clickOnMainPageLink();
			Thread.sleep(medium);
			if(!click(ElsevierObjects.home_student_lnkstudent,"Clicked On student Link")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.student_login,"Clicked On student LogIn")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.email,Username,"Email")){
				flag = false;
			}
			if(!type(ElsevierObjects.password,Password,"Email")){
				flag = false;
			}
			
			if(!click(ElsevierObjects.submit,"Clicked on Login Button")){
				flag = false;
			}
			Thread.sleep(medium);
			return flag;
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
	}
	public static boolean emailVerification(String email) throws Throwable{
		boolean flag=true;
		try{
		
			if(!type(ElsevierObjects.email_SearchBox,email,"Enter the email id.")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.email_SearchIcon,"Click on search icon.")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame")){
				flag=false;
			}
			Thread.sleep(medium);
			String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
			// changed .contains(email) to .contains(credentials[0]) && .contains(credentials[1])
			if(emailBody.contains(email)){
			//if(emailBody.contains(credentials[0]) && emailBody.contains(credentials[1])){
				Reporters.SuccessReport("Order Confirmation email", "Successfully received email from evolve. <br> Email body content is : "+emailBody);
			}else{
				Reporters.failureReport("Order Confirmation email", "failed to receive email from evolve. <br> Email body content is : "+emailBody);
			}
			
			switchToDefaultFrame();
			Thread.sleep(high);
			/*if(javaClick(ElsevierObjects.email_logout,"Click on logout.")){
				Reporters.SuccessReport("Click on the Logout button", "Successfully Logged out from the Evolve outlook mail");
			}else{
				Reporters.failureReport("Click on the Logout button", "Failed to Logged out from the Evolve outlook mail");
			}*/
			Thread.sleep(high);
		}catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
		return flag;
	}
}
