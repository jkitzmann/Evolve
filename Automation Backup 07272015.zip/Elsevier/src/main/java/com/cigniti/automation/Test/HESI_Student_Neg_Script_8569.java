package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;

public class HESI_Student_Neg_Script_8569 extends EvolveCommonBussinessFunctions {
  @Test
  public void HESI_Student_Neg_8569()throws Throwable {
	  try 
	   {
		  SwitchToBrowser(ElsevierObjects.studentBrowserType);
		  String user = "student";
		  String userName = ReadingExcel.columnDataByHeaderName("StudentUserName", "TC-8567", configProps.getProperty("TestData"));
		  String password = ReadingExcel.columnDataByHeaderName("StudentPassword", "TC-8567", configProps.getProperty("TestData"));
   	 
		  HesiNegISBN =ReadingExcel.columnDataByHeaderName("HesinegISBN","TC-8567",configProps.getProperty("TestData"));
		
		  stepReport("Login to Evolve as existing student");
		  writeReport(EvolveCommonBussinessFunctions.existingUserLogin (user,userName,password),"Login to the application as a student user",
                                                                           "Successfully EvolveCert URL is Launched and Entered as a student user </br>" +userName,
                                                                           "Failed to Launch URL an enter as a student");
		  
		  stepReport("Verify no results for HESI ISBN search");
		  writeReport(EvolveCommonBussinessFunctions.SearchNegProduct(),"Enter ISBN in searchbox,click on GO button and check the result",
                                                                       "Successfully Isbn is Entered in searchbox,clicked on Go button and NO result is found for HESI ISBN: </br>" +HesiNegISBN,
                                                                       "Failed to enter Isbn in searchbox and unable to get result");
	   	}
	    catch(Exception e){
	    	 System.out.println(e);
	     }
  	}
}
