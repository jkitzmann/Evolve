package com.cigniti.automation.BusinessFunctions;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;

public class StudentView_InstructorLogIn_Neg_8564 extends EvolveCommonBussinessFunctions {
	
	public static float product_price=0;
	public static float product_price1=0;
	public static float expectedproduct_price=0;

	public static boolean studentSearch() throws Throwable{
		boolean flag = true;
		driver.manage().deleteAllCookies();
		if(!launchUrl(configProps.getProperty("URL"))){
			flag = false;
		}
		driver.manage().deleteAllCookies();
		driver.navigate().refresh();
		Thread.sleep(medium);
		if(!click(ElsevierObjects.home_student_lnkstudent,"Clicked On student Link")){
	   		 flag = false;
	   	 }
		if(!type(ElsevierObjects.txtproductsearch,readcolumns.twoColumns(0, 1, "Tc-10216 & 8565", configProps.getProperty("TestData")).get("searchNumber"), "text to search")){
			flag = false;
		}
		if(!click(ElsevierObjects.gobutton, "search button")){
			flag = false;
		}
		if(!waitForElementPresent(ElsevierObjects.btnaddtocart,"Request this product now")){
			flag = false;
		}
		
		return flag;
	}
	
	public static boolean srarchPrice() throws Throwable{
		boolean flag = true;
		
		if(!click(ElsevierObjects.btnaddtocart, "Click on request this product")){
			flag = false;
		}
		
		if(configProps.getProperty("browserType").equalsIgnoreCase("ie")){
			flag=true;
			   driverwait().until(ExpectedConditions.visibilityOfElementLocated(ElsevierObjects.ReqApply));
			   ImplicitWait();
			    if(driver.findElement(ElsevierObjects.ReqApply).isDisplayed()){
			     if(!switchToFrameByLocator(ElsevierObjects.frame,"framename")){
			      flag = false;
			     }
			     if(!waitForElementPresent(ElsevierObjects.evolvebutton,"Evolve button")){
			      flag = false;
			     }
			     if(!click(ElsevierObjects.apply, "Apply button")){
			      flag = false;
			     }
			     if(!switchToDefaultFrame()){
			      flag = false;
			     }
			     Thread.sleep(medium);
			    }
			    return flag;
			  }
		
		//for handling the delay in the product delvry
		/*  if(!click(ElsevierObjects.Mycart_alert, "Alert")){
		   flag = false;
		  }*/
		  Thread.sleep(medium);
		product_price=  Float.parseFloat(getText(ElsevierObjects.student_product_price, "Product Price").substring(1));
		if(product_price > expectedproduct_price){
			if(!click(ElsevierObjects.checkout, "Redeem Checkout")){
 				flag = false;
 			}
		}
		
		if(!type(ElsevierObjects.checkout_login_username, configProps.getProperty("Faculty_User"), "Instructor Name")){
			flag = false;
		}
		if(!type(ElsevierObjects.checkout_login_password, configProps.getProperty("Faculty_Pwd"), "Instructor Password")){
			flag = false;
		}
		if(!click(ElsevierObjects.educator_btnLogin, "Instructor Login")){
				flag = false;
			}
		return flag;
	}
	
}
