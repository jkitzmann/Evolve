package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarte_Student_SplitOrders1_15597;
import com.cigniti.automation.BusinessFunctions.Instructor_ViewStudentLogIn_8563;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class Instructor_ViewStudentLogIn_Script_8563 extends Instructor_ViewStudentLogIn_8563{
	
	@Test
	public void InstructorViewStudentLogIn_8563() throws Throwable{
	
		try {
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			stepReport("Go to Evolve Educator homepage");
			if(searchBeforeLogin())
			{
				Reporters.SuccessReport("Search Product Befor Login ", "Currently on Educator page through Evolve home page");
			}
	       else{
				Reporters.failureReport("Search Product Befor Login", "Failed Opening Educator page through Evolve home page"); 
			}
			stepReport("Search for course, add to cart, and enter checkout");
			if(searchCourseBeforeAdd())
			{
				Reporters.SuccessReport("Search Course page ", "Currently on Search page through Evolve home page");
			}
	       else{
				Reporters.failureReport("Search Course page  ", "Failed Opening Educator page through Evolve home page");
				
			}	
			if(addToCart())
			{
				Reporters.SuccessReport("Add the searched product to cart ", "Successfully Added the searched product to cart");
			}
	       else{
	    	 
	    	   Reporters.failureReport("Add the searched product to cart ", "Failed to Add the searched product to cart");
			}
			stepReport("Login as existing Student user during checkout");
			if(studentLogin())
			{
				Reporters.SuccessReport("Student Login: ", "Successfully Login as Student User");
			}
	       else{
	    	 
	    	   Reporters.failureReport("Student Login:", "Failed to Login as Student User");
			}
			stepReport("Submit order");
			if(reviewAndSubmit())
			{
				Reporters.SuccessReport("Review and submit Page", "Successfully in Review and submit Page");
			}
	       else{
	    	 
	    	   Reporters.failureReport("Review and submit Page", "Failed to open Review and submit Page");
			}
			Thread.sleep(veryhigh);
			ECommercePreorderALaCarte_Student_SplitOrders1_15597.getStudentAccountDetails();
			if(instructorLogout())
			{
				Reporters.SuccessReport("Student Log out:", "Student Loged Out Successfully");
			}
	       else{
				Reporters.failureReport("Student Log out:", "Student Log out Failed."); 
			}
			Thread.sleep(high);
			
			stepReport("Login to Evolve Admin");
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			if(evolveAdminlogin())
			{
				Reporters.SuccessReport("Admin login ", "Successfully Reviewed and Submitted");
			}
	       else{

	    	   Reporters.failureReport("Review and submit ", "Failed to Review and Submit");
			}
			
			String username=ECommercePreorderALaCarte_Student_SplitOrders1_15597.getAccountDetailsUserName;
			stepReport("Verify AR details");
			if(clickAdoptionRequest(username))
			{
				Reporters.SuccessReport("Click on the AR", "AR Search results page is displayed");
			}
			else{
				Reporters.failureReport("Click on the AR", "AR Search results page are not displayed");
			}
			
			Thread.sleep(medium);
			if(adminLogout())
			{
	     		Reporters.SuccessReport("Clicked on Logout", "Successfully Logedout as admin");
			}
			else
			{
				Reporters.failureReport("Clicked on Logout", "Failed to Logedout as admin ");
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	/*@AfterClass
	public static void browserStop()
	{
		driver.close();
	}*/
	
}
