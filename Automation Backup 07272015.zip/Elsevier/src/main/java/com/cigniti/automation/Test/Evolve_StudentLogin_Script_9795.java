package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.Evolve_StudentLogin_9795;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class Evolve_StudentLogin_Script_9795 extends Evolve_StudentLogin_9795 {
	@Test
	public void evolveStudentLoginScript_9795() throws Throwable{
		try{
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			stepReport("Add product to cart and enter checkout");
			if (evolve_StudentSearch()) {
				Reporters.SuccessReport("login to the application as student","Successfully searched the application");
			}
			else {
				Reporters.failureReport("login to the application as student","Failed to search the application");	
			}
			stepReport("Complete registration");
			if (evolve_StudentRegistration()) {
				Reporters.SuccessReport("login to the application as student","Successfully Registerd into the application");
			} 
			else {
				Reporters.failureReport("login to the application as student","Failed to register to the application");
			}
			stepReport("Complete checkout");
			if (evolve_StudentCreditCardDetails()) {
				Reporters.SuccessReport("login to the application as student","Successfully logged with credentials into the application");
			} 
			else {
				Reporters.failureReport("login to the application as student","Failed to login with credentials into the application");	
			}
			if (evolve_StudentReviewandSubmit()) {
				Reporters.SuccessReport("login to the application as student","Successfully logged with credentials into the application");
			} 
			else {
				Reporters.failureReport("login to the application as student","Failed to login with credentials into the application");	
			}
			Thread.sleep(veryhigh);
			if (evolve_StudentLogout()) {
				Reporters.SuccessReport("Click logout:","Successfully clicked on logout");
			} 
			else {
				Reporters.failureReport("Click logout:","Failed to click on logout");	
			}
			Thread.sleep(high);
			stepReport("Login to Evolve Admin");
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			if (evolveAdminlogin()) {
				Reporters.SuccessReport("login to the admin","Successfully logged into admin");
			} 
			else {
				Reporters.failureReport("login to the admin","Failed to login into admin");	
			}
			stepReport("Verify no AR was created");
			if (admin_Adoptionsearch_verifytext()) {
				Reporters.SuccessReport("Verify text adoption search","Successfully verified adoption search");
			} 
			else {
				Reporters.failureReport("Verify text adoption search","Failed to verify adoption search");	
			}
			if(adminLogout()){
				Reporters.SuccessReport("Logout Successful", "Successfully logout from admin");
			}
			else{	
				Reporters.SuccessReport("Logout Successful", "logout failed from admin");
			}
		}
	     catch(Exception e){
	    	 System.out.println(e);
	     }
		}
	/*@AfterClass
	public static void browserStop()
	{
		driver.close();
	}*/
	
}




	

