package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarteFaculty1_15459;
import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarte_Student_SplitOrders1_15597;
import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarte_Student_SplitOrders2_15597;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.LO_Global_Instructor_AR_8572;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Database;

public class ECommercePreorderALaCarteFacultyScript2_15459 extends ECommercePreorderALaCarteFaculty1_15459 {
	@Test
	public void eCommercePreorderALaCarteFaculty15459_2() throws Throwable{
		
		try{
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String educatoruser=ReadingExcel.columnDataByHeaderName("educatorUser", "TC_15459", testDataPath);
			String resoursetitle=ReadingExcel.columnDataByHeaderName("resourcetitle", "TC-15597", testDataPath);
			String onlinetitle=ReadingExcel.columnDataByHeaderName("Onlinetitle", "TC-15597", testDataPath);
			
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials"+adminUser,
		            "Launching the URL for User is successful </br > Login to Application Using User credentails :"+adminUser+" is Successful",
		            "Launching and Login to Application Using User credentails : "+ adminUser+" is Failed");
			
			ECommercePreorderALaCarteFaculty1_15459.Adoptionsearch(educatoruser);
			
		   	ECommercePreorderALaCarteFaculty1_15459.checkApprovedstatus(onlinetitle,resoursetitle);
			
			String password=ReadingExcel.columnDataByHeaderName("educatorPwd", "TC_15459", testDataPath);
			
			writeReport(User_BusinessFunction.Educatorlogin(educatoruser, password),"Launching The URL And Login As Educator User.",
					"Successfully Logged In Into Educator Application As :"+educatoruser,
					"Failed To Login Into Application As Educator :"+educatoruser);
			
			
			ECommercePreorderALaCarteFaculty1_15459.verifyTitles(onlinetitle,resoursetitle);
			
			writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the Educator page.", 
					"Sucecssfully logged out the Educator page.", 
					"Failed to logout the Educator page.");
			
			stepReport("Preorder database cleanup");
			Database.preorderDBCleanup();
			
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
		}
}
}
