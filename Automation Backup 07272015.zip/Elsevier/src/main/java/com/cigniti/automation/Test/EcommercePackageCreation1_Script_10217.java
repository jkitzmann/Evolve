package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;


public class EcommercePackageCreation1_Script_10217 extends EvolveCommonBussinessFunctions{

	@Test
	public void ecommercePackageCreation1_10217() throws Throwable
	{
		try{
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			stepReport("Verify current product details");
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			isbnVerify("Ecom_TCID_10217",tc10217_a.get("ISBNTextBox1"), 17, 18, 19, 1);
			isbnVerify("Ecom_TCID_10217",tc10217_a.get("ISBNTextBox2"), 20, 21, 22, 1);
			isbnVerify("Ecom_TCID_10217",tc10217_a.get("ISBNTextBox3"), 23, 24, 25, 1);
			
			stepReport("Login to Evolve Admin");
			writeReport(evolveAdminlogin(),"Login to Application Using User Credentials"+adminUser,
                    "Launching the URL for User is successful </br > Login to Application Using User credentails :"+adminUser+" is Successful",
                       "Launching and Login to Application Using User credentails : "+ adminUser+" is Failed");
			
			stepReport("Verify UI of the add ecom package page");
			verifyEcommerceLink();
			
			if(viewTopViewAddPakage())
			{
	     		Reporters.SuccessReport("Validate the 'Package Items section' of the page ", "All fields are available in Package item section");
			}
			else
			{	
				Reporters.failureReport("Validate the 'Package Items section' of the page ", "All fields are not available in Package item section");
			}
			
			cloneEnabled();
			
			stepReport("Create and save the package details");
			if(inputPackageData())
			{
	     		Reporters.SuccessReport("Input the Package Data", "The data is correctly entered into the fields");
			}
			else
			{
				
				Reporters.failureReport("Input the Package Data", "The data is Not correctly entered into the fields");
			}
			
			stepReport("Add ISBNs to the package");
			verifyAndAddISBNPackages();
			
			stepReport("Add specific product type discount through Cross Promotions tab");
			crossPromotionTab();
			
			 writeReport(EvolveCommonBussinessFunctions.adminLogout(),"Clicking on Logout",
	                 "Clicking on Logout is Successful",
	                 "Clicking on Logout is not Successful");
		}catch(Exception e){
			System.out.println(e.getMessage());
		}	
	}
	@AfterTest
	public void closeBtrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}

	

