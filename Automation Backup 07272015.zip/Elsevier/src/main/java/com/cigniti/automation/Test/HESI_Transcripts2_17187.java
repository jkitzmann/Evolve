package com.cigniti.automation.Test;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.Review_SubmitStudentInstructor_Cancel;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class HESI_Transcripts2_17187 extends EvolveCommonBussinessFunctions{

	@Test
	public void HESI_Transcript2_17187() throws Throwable{
		
		try {
			stepReport("Open Evolve as a Student");
		    SwitchToBrowser(ElsevierObjects.studentBrowserType);
		    //as student - positive scenario
		    if(launchUrl(configProps.getProperty("URL4"))){
				Reporters.SuccessReport("Launch the URL "+configProps.getProperty("URL4"), "Successfully Launched URL "+configProps.getProperty("URL4"));
			}else{
				Reporters.failureReport("Launch the URL "+configProps.getProperty("URL4"), "Failed to Launch URL "+configProps.getProperty("URL4"));
			}
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			
			if(studentLoginGeneral())
			{
				Reporters.SuccessReport("Student Logged in Successfully", "Student Login Page");
			}else{
				Reporters.failureReport("Student Not Logged in", "Student Login Page"); 
			}
			
			stepReport("Validate HESI Transcript Link");
			
			if(click(ElsevierObjects.HESI_TRANSCRIPTS,"Click HESI Transcripts link")){
				Reporters.SuccessReport("Click HESI Transcripts link", "Successfully Clicked on HESI Transcripts link");
			}else{
				Reporters.failureReport("Click HESI Transcripts link", "Failed to Click on HESI Transcripts link");}
				
				Thread.sleep(low);
				
			if(click(ElsevierObjects.btnRegister,"Click Register Button")){
				Reporters.SuccessReport("Click REGISTER button", "Successfully Clicked on REGISTER button");
			}else{
				Reporters.failureReport("Click REGISTER button", "Failed to Click on REGISTER button");
			}
			Thread.sleep(low);
			
			stepReport("Shopping Cart Validations");
			
			String transcriptISBN=ReadingExcel.columnDataByHeaderName("TRANSCRIPT_ISBN", "HESI_Transcript", testDataPath);
			String transcriptTitle=ReadingExcel.columnDataByHeaderName("TRANSCRIPT_TITLE", "HESI_Transcript", testDataPath);
			String valTranscriptQTY=ReadingExcel.columnDataByHeaderName("VALID_TRANSCRIPT_QTY", "HESI_Transcript", testDataPath);
			String invalTranscriptQTY=ReadingExcel.columnDataByHeaderName("INVALID_TRANSCRIPT_QTY", "HESI_Transcript", testDataPath);
			String transcriptMSG=ReadingExcel.columnDataByHeaderName("TRANSCRIPT_MSG", "HESI_Transcript", testDataPath);
			
			String transcriptISBNfromCart = getText(ElsevierObjects.HESI_TRANSCRIPT_ISBN,"HESI Transcript ISBN from Cart");
			String transcriptTitlefromCart = getText(ElsevierObjects.HESI_TRANSCRIPT_TITLE,"HESI Transcript Title from Cart");
			
			//System.out.println(transcriptISBN);
			//System.out.println(transcriptTitle);
			//System.out.println(valTranscriptQTY);
			//System.out.println(transcriptTitle);
			//System.out.println(transcriptMSG);
			//System.out.println(invalTranscriptQTY);
			//System.out.println(transcriptTitlefromCart);
			
			Thread.sleep(low);
			
			if(transcriptISBNfromCart.contains(transcriptISBN)){
				Reporters.SuccessReport("Validate the ISBNs are equal", "ISBN is validated successfully <br> Expected ISBN is : "+transcriptISBN+"<br>  Actual ISBN is : "+transcriptISBNfromCart);
			}else{
				Reporters.failureReport("Validate the ISBNs are equal", "ISBNs do not match <br> Expected ISBN is : "+transcriptISBN+"<br> Actual ISBN is : "+transcriptISBNfromCart);
			}
			if(transcriptTitlefromCart.contains(transcriptTitle)){
				Reporters.SuccessReport("Validate Title contains HESI Transcript", "Title successfully contains HESI Transcript <br> Expected Title is : "+transcriptTitle+"<br>  Actual Title is : "+transcriptTitlefromCart);
			}else{
				Reporters.failureReport("Validate Title contains HESI Transcript", "Title does not display HESI Transcript <br> Expected Title is : "+transcriptTitle+"<br> Actual Title is : "+transcriptTitlefromCart);
			}
			
			stepReport("Cart - Update HESI Transcript QTY to be invalid number");
			
			if(type(ElsevierObjects.HESI_TRANSCRIPTS_QTY_FIELD, invalTranscriptQTY, "Entered invalid HESI Transcript quantity")){
				Reporters.SuccessReport("Entered invalid HESI Transcript quantity" ,"Successfully entered HESI Transcript quantity.");
			}else{
				Reporters.failureReport("Entered invalid HESI Transcript quantity", "Failed to enter HESI Transcript quantity.");
			} 
			
			if(click(ElsevierObjects.UPDATE_QTY_BUTTON,"Click Update Quantity button")){
				Reporters.SuccessReport("Click On Update Quantity Button.", "Successfully clicked on Update Quantity Button."); 
			}
			else{
				Reporters.failureReport("Click On Update Quantity Button.", "Failed to click on Update Quantity Button.");
			}
			Thread.sleep(low);
			
			String transcriptMessagefromCart = getText(ElsevierObjects.TRANSCRIPT_ERROR_MSG,"HESI Transcript ISBN from Cart");
			//System.out.println(transcriptMessagefromCart);
			
			if(transcriptMessagefromCart.contains(transcriptMSG)){
				Reporters.SuccessReport("Validate transcript message matches", "Transcript message matches successfully<br> Expected message is : "+transcriptMSG+"<br>  Actual message is : "+transcriptMessagefromCart);
			}else{
				Reporters.failureReport("Validate transcript message matches", "Transcript message does not match expected<br> Expected message is : "+transcriptMSG+"<br> Actual message is : "+transcriptMessagefromCart);
			}
				
				stepReport("Cart -Update HESI Transcript QTY to be valid number");
				
				if(type(ElsevierObjects.HESI_TRANSCRIPTS_QTY_FIELD, valTranscriptQTY, "Entered valid HESI Transcript quantity")){
					Reporters.SuccessReport("Entered valid HESI Transcript quantity" ,"Successfully entered HESI Transcript quantity.");
				}else{
					Reporters.failureReport("Entered valid HESI Transcript quantity", "Failed to enter HESI Transcript quantity.");
				} 
				
				Thread.sleep(low);
				
				if(click(ElsevierObjects.UPDATE_QTY_BUTTON,"Click Update Quantity button")){
					Reporters.SuccessReport("Click On Update Quantity Button.", "Successfully clicked on Update Quantity Button."); 
				}
				else{
					Reporters.failureReport("Click On Update Quantity Button.", "Failed to click on Update Quantity Button.");
				}
				
				Thread.sleep(low);
				
				if(!isElementPresent(ElsevierObjects.TRANSCRIPT_ERROR_MSG)){
					Reporters.SuccessReport("Validate transcript message does not display","No message present");
				}else{
					Reporters.failureReport("Validate transcript message does not display", "Message incorrectly displays");
				}
				
		    stepReport("Go to Review & Submit Page");		
				
			if(javaClick(ElsevierObjects.evolve_checkout_btn,"Click Redeem checkout button")){
				Reporters.SuccessReport("Click On Redeem CheckOut Button.", "Successfully clicked on Redeem Checkout Button."); 
			}
			else{
				Reporters.failureReport("Click On Redeem CheckOut Button.", "Failed to click on Redeem Checkout Button.");
			}
			Thread.sleep(low);
			if(creditCardDetails()){
				Reporters.SuccessReport("Submitted Credit Card Info", "Successfully submitted Credit Card Info."); 
			}
			else{
				Reporters.failureReport("Submitted Credit Card Info.", "Failed to submitted Credit Card Info.");
			}
			
			Thread.sleep(low);
			
			stepReport("Review & Submit - Update HESI Transcript QTY to be invalid number");
			
			if(type(ElsevierObjects.HESI_TRANSCRIPTS_QTY_FIELD, invalTranscriptQTY, "Entered invalid HESI Transcript quantity")){
				Reporters.SuccessReport("Entered invalid HESI Transcript quantity" ,"Successfully entered HESI Transcript quantity.");
			}else{
				Reporters.failureReport("Entered invalid HESI Transcript quantity", "Failed to enter HESI Transcript quantity.");
			} 
			
			if(click(ElsevierObjects.UPDATE_QTY_BUTTON,"Click Update Quantity button")){
				Reporters.SuccessReport("Click On Update Quantity Button.", "Successfully clicked on Update Quantity Button."); 
			}
			else{
				Reporters.failureReport("Click On Update Quantity Button.", "Failed to click on Update Quantity Button.");
			}
			Thread.sleep(low);
			
			transcriptMessagefromCart = getText(ElsevierObjects.TRANSCRIPT_ERROR_MSG_REVIEW,"HESI Transcript Message from Cart");
			
			if(transcriptMessagefromCart.contains(transcriptMSG)){
				Reporters.SuccessReport("Validate transcript message matches", "Transcript message matches successfully <br> Expected message is : "+transcriptMSG+"<br>  Actual message is : "+transcriptMessagefromCart);
			}else{
				Reporters.failureReport("Validate transcript message matches", "Transcript message does not match expected<br> Expected message is : "+transcriptMSG+"<br> Actual message is : "+transcriptMessagefromCart);
			}
				
				stepReport("Review & Submit - Update HESI Transcript QTY to be valid number");
				
				if(type(ElsevierObjects.HESI_TRANSCRIPTS_QTY_FIELD, valTranscriptQTY, "Entered valid HESI Transcript quantity")){
					Reporters.SuccessReport("Entered valid HESI Transcript quantity" ,"Successfully entered HESI Transcript quantity.");
				}else{
					Reporters.failureReport("Entered valid HESI Transcript quantity", "Failed to enter HESI Transcript quantity.");
				} 
				
				Thread.sleep(low);
				
				if(click(ElsevierObjects.UPDATE_QTY_BUTTON,"Click Update Quantity button")){
					Reporters.SuccessReport("Click On Update Quantity Button.", "Successfully clicked on Update Quantity Button."); 
				}
				else{
					Reporters.failureReport("Click On Update Quantity Button.", "Failed to click on Update Quantity Button.");
				}
				
				Thread.sleep(low);
				
				if(!isElementPresent(ElsevierObjects.TRANSCRIPT_ERROR_MSG_REVIEW)){
					Reporters.SuccessReport("Validate transcript message does not display","No message present");
				}else{
					Reporters.failureReport("Validate transcript message does not display", "Message incorrectly displays");
				}
				
				stepReport("Cancel Order - Data Cleanup");
				
				if(Review_SubmitStudentInstructor_Cancel.cancelOrder()){
					Reporters.SuccessReport("Cancel Order","Order cancelled successfully");
				}else{
					Reporters.failureReport("Cancel Order", "Order not cancelled");
				}
				Thread.sleep(high);
			
			
			//as faculty - negative scenario
			stepReport("Open Evolve as an Educator");
			
			if(launchUrl(configProps.getProperty("URL3"))){
				Reporters.SuccessReport("Launch the URL "+configProps.getProperty("URL3"), "Successfully Launched URL "+configProps.getProperty("URL3"));
			}else{
				Reporters.failureReport("Launch the URL "+configProps.getProperty("URL3"), "Failed to Launch URL "+configProps.getProperty("URL3"));
			}
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			
			stepReport("Validate HESI Transcript");
			
			if(!isElementPresent(ElsevierObjects.HESI_TRANSCRIPTS,"Click HESI Transcripts link")){
				Reporters.SuccessReport("Verify HESI Transcripts link as Educator", "Verified HESI Transcripts link not present for Educator");
			}else{
				Reporters.failureReport("Verify HESI Transcripts link as Educator", "HESI Transcripts link incorrectly found for Educator");
			}
		}
		
		catch (Exception e) {
			System.out.println(e.getMessage());	
		}
	}}

