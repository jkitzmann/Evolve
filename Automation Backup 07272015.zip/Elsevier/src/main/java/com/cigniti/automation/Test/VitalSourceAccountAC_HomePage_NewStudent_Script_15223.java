package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.VitalSourceAccountAC_HomePage_StudentExists_VST;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class VitalSourceAccountAC_HomePage_NewStudent_Script_15223 extends VitalSourceAccountAC_HomePage_StudentExists_VST {
	
	@Test 
	public void vitalSourceAccountAC_HomePage_NewStudent_15223() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String username=ReadingExcel.columnDataByHeaderName( "VST_StudentUsername", "VST",configProps.getProperty("TestData"));
			String password=ReadingExcel.columnDataByHeaderName( "VST_StudentPassword", "VST",configProps.getProperty("TestData"));
			
			String user = "student";
			String knoUser="";
			if(CreateNewUser(user))
			{
	     		Reporters.SuccessReport("Login into Application ", "Successfully logged in as Student user");
			}
			else
			{
				Reporters.failureReport("Login into Application ", "Failed to login as Student user");
			}
			if(pageBurstReedem1()){
				Reporters.SuccessReport("Page burst Reddem access page", "Succesfully navigated to page burst reedeem access page");
			}
			else{
				Reporters.failureReport("Page burst Reddem access page", "Failed to navigated to page burst reedeem access page");
			}
			String name = "VST"; 
			String accessCode = "true";
			if(updateVSTandKNOAccount(user,name,accessCode, knoUser))
			{
	     		Reporters.SuccessReport("Account Updated Successfully", "Account Updation was successfully");
			}
			else
			{
				Reporters.failureReport("Failed to Update Account", "Failed to Update Account.");
			}
			AccessCodeReviewandSubmitVST(user);
			String accessCodeUser = "student";
			if(pageburstVstLink(accessCodeUser,"","")){
				Reporters.SuccessReport("PageBurstLink :", "Succesfully Clicked on PageBurst Link.");
			}else{
				Reporters.failureReport("PageBurstLink :", "Failed to  Clicked on PageBurst Link.");
			}
			if(instructorLogout())
			{
				Reporters.SuccessReport("Student Log out:", "Student Loged Out Successfully");
			}
	       else{
				Reporters.failureReport("Student Log out:", "Student Log out Failed."); 
			}
			reLogingForAccessCodeRedeem(username, password);
			
			ReadingExcel.removeUsedVSTCode(VSTDataPath, "VSTCodes");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ReadingExcel.removeUsedVSTCode(VSTDataPath, "VSTCodes");
		}
	}
	@AfterTest
	public void closeBrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
	
}
