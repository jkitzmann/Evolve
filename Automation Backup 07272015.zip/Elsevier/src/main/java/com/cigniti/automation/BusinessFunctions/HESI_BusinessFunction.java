package com.cigniti.automation.BusinessFunctions;


import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;
import org.yaml.snakeyaml.events.Event.ID;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;


public class HESI_BusinessFunction extends EvolveCommonBussinessFunctions
{

	
	public static boolean getAccountDetails() throws Throwable{
		boolean flag=true;

		try{
			Thread.sleep(5000);

			if(!click(ElsevierObjects.myAccount,"click on my account")){
				flag=false;
			}
			Thread.sleep(5000);
			if(!click(ElsevierObjects.myAccount_AccountSettings,"click on account settings.")){
				flag=false;
			}
			Thread.sleep(5000);
			ImplicitWait();
			driver.navigate().refresh();
			Thread.sleep(3000);
			//String firstName=getText(ElsevierObjects.educator_form_txtFirstName, "Get first name");
			getAccountDetailsUserName=getAttribute(ElsevierObjects.educator_form_UserName, "value", "first name");
			getAccountDetailsFirstName=getAttribute(ElsevierObjects.educator_form_txtFirstName, "value", "first name");
			getAccountDetailsLastName=getAttribute(ElsevierObjects.educator_form_txtLastName,"value","Last Name");
			getAccountDetailsEmail=getAttribute(ElsevierObjects.educator_form_txtEmail,"value","email id.");
			getAccountDetailsInstitution=getAttribute(ElsevierObjects.educator_form_txtInstution, "value","Institution name");
			getAccountDetailsPhone=getAttribute(ElsevierObjects.educator_form_txtAddPhone,"value","Phone number");
			getAccountDetailsStreetAddress=getAttribute(ElsevierObjects.educator_form_txtAddress,"value", "Street Adress");
			getAccountDetailsStreetAddress2=getAttribute(ElsevierObjects.educator_form_txtAddress2,"value", "Street Adress2");
			ImplicitWait();
			
			getAccountDetailsCountry=getFirstSelectedOption(ElsevierObjects.educator_form_InstutionCountry, "country of institution.");
			if(getAccountDetailsCountry.equalsIgnoreCase("Institution Country"))
			{
				getAccountDetailsCountry="";		
			}
			getAccountDetailsState=getFirstSelectedOption(ElsevierObjects.educator_form_State, "State");
			if(getAccountDetailsState.equalsIgnoreCase("Institution State"))
			{
				getAccountDetailsState="";		
			}
			getAccountDetailsTown=getAttribute(ElsevierObjects.educator_form_Town,"value", "Town");
			getAccountDetailsZipcode=getAttribute(ElsevierObjects.educator_form_txtAddPostalCode,"value", "Postal Codes");
			
			Thread.sleep(3000);
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(2000);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	public static boolean emailBodyVerification(String Title,String user) throws Throwable{
		boolean flag=true;
		//String UserName = EvolveCommonBussinessFunctions.credentials[0];
		//   String Password = EvolveCommonBussinessFunctions.credentials[1];
		/*String reLoginUser=tc_9798a.get("Username");
		String reLoginPassword=tc_9798a.get("Password");*/
		  String reLoginUser=EvolveCommonBussinessFunctions.dynamicUserName;
		  String reLoginPassword=EvolveCommonBussinessFunctions.dynamicPassword;

		try{
		//String email=tc_9798.get("user_email");
		if(type(ElsevierObjects.email_SearchBox,user,"Enter the email id.")){
			Reporters.SuccessReport("Searching The EmailId.", "Successfully Entered email: "+emailAdress);
		}
		else{
			Reporters.failureReport("Searching The EmailId.", "Failed To Enter email: "+emailAdress);
		}
		Thread.sleep(3000);
		if(!click(ElsevierObjects.email_SearchIcon,"Click on search icon.")){
			flag=false;
		}
		Thread.sleep(3000);
		titleInEmail=getText(ElsevierObjects.titleInEmail, "Get title in evolve email page.");
		System.out.println( "titleInEmail:"+titleInEmail);
		if(titleInEmail.contains(Title)){
			Reporters.SuccessReport("Verifying Title In Email Body.", "Successfully Verified Title: "+titleInEmail+" in email.");
			String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
			emailBody=emailBody.replaceAll("<", "| ");
			emailBody=emailBody.replace(">", "  |");	
			Reporters.SuccessReport("Printing Email Body for reference","Email Body Is: "+emailBody+"</br>");
			
		}
		else{
			Reporters.failureReport("Verifying Title In Email Body.", "Failed To Verify Title In Email Body.");
		}
		
			if(!switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame")){
			flag=false;
		}
		Thread.sleep(3000);
				}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	return flag;
	}

	public static boolean CompareaferhesiupdateinCERT(String firstname,String lastname,String emailid,String Phonenumber) throws Throwable
	{flag=true;
		try
	{
			if(!CompareString(getAccountDetailsFirstName, firstname, "First Name"))
			{
				flag=false;
			}
			
			if(!CompareString(getAccountDetailsLastName, lastname, "Last Name"))
			{
				flag=false;
			}
			
			if(!CompareString(getAccountDetailsEmail, emailid, "Email id"))
			{
				flag=false;
			}
			
			if(!CompareString(getAccountDetailsPhone, Phonenumber, "Phone Number"))
			{
				flag=false;
			}
			
			return flag;
	}catch(Exception e){sgErrMsg="Failed to Compare Values";return false;}
	}
	
	public static boolean verifyProducttypeandclick(String Prodcutypeinput) throws Throwable
	{
	try
	{
		List<WebElement> TotalConentlist=driver.findElements(By.xpath(".//*[@id='set']/li/div/div/a"));
		int flag=0;
		String Productype="";
		Thread.sleep(100);
		for(int i=0;i<TotalConentlist.size();i++)
			
		{
		 Productype=TotalConentlist.get(i).getText();
		    
		 if(Productype!=null)
			{
				if(Productype.contains(Prodcutypeinput))
				{
					TotalConentlist.get(i).click();	
			   Reporters.SuccessReport("Verifying  and Clicking on Faculty Access Link Under  HESI Assessment: " +Prodcutypeinput , "Faculty Access Link Under  HESI Assessment is  avilable");
				
			    return true;
			    
				}
				else
				{
					flag=1;
			       
				}
			

			}
				
		}	
		
		if(flag==1)
		{
		 Reporters.failureReport("Verifying Product type Details Sequence:"+Prodcutypeinput, "Product Type name is not Present in Content list:"+Prodcutypeinput);
		 		
		 return false;
		
		}
	}catch(Exception e){sgErrMsg="Failed to verify content list"+e;return false;}


	return flag;
	}

	
public static boolean HESI_Login(String HESI,String HESIPASSWORD) throws Throwable
{try
{
	//SwitchToBrowser("firefox");
	driver.manage().deleteAllCookies();
	Thread.sleep(3000);
	flag=true;
	if(!launchUrl(configProps.getProperty("HESI_URL")))
	{
		flag = false;
	}
	if(!type(ElsevierObjects.Hesi_username, HESI,"HESI Portal UserName"))
	{
		flag=false;
	
	}
	if(!type(ElsevierObjects.Hesi_Password, HESIPASSWORD,"HESI Portal Password"))
	{
		flag=false;
	
	}
	if(!click(ElsevierObjects.Hesi_LoginSubmit,"HESI Login Button"))
	{
		flag=false;
	
	}
	//sgErrMsg="Unable to launch URL or Entering Email id/PasswordFailed";
	return flag;
	}catch(Exception e){sgErrMsg="Unable to launch URL or Entering Email id/PasswordFailed due to"+e;return false;}
	}

public static boolean EvolveAddbutton(String User) throws Throwable
{try
{
	Thread.sleep(3000);
	flag=true;
	if(!click(ElsevierObjects.CreateNewfacultyAccount,"Create New Faculty Account"))
	{
		flag=false;
	
	}
	if(!type(ElsevierObjects.HESI_EvolveId, User,"HESI Newly Created Faculty Id"))
	{
		flag=false;
	
	}
	if(!click(ElsevierObjects.EvolveAddbutton,"Evolve Button"))
	{
		flag=false;
	
	}
	//sgErrMsg="Unable to launch URL or Entering Email id/PasswordFailed";
	return flag;
	}catch(Exception e){sgErrMsg="Unable to Add Faculty user due to :</br>"+e;return false;}
	}

public static boolean NavigatingtoAccountManagmentPage() throws Throwable 
{
	try
	{
		Thread.sleep(3000);
        flag=true;
		if(!click(ElsevierObjects.Accountlink,"HESI Account link on Main Menu"))
		{
			flag=false;
		}
		if(!click(ElsevierObjects.FacultyProgramslink,"HESI FacultyandPrograms Link on Drop Down"))
		{
			flag=false;
		}

		//sgErrMsg="Unable to Click on Accounts and Faculty Programs Link";
		return flag;
		
	}
	catch(Exception e)
	{sgErrMsg="Unable to Click on Accounts and Faculty Programs Link"+e;
		return false;}
 }

public static boolean NavigatingtoStudentAccountManagmentPage() throws Throwable 
{
	try
	{
		Thread.sleep(3000);
		b=true;
        flag=true;
		if(!click(ElsevierObjects.Accountlink,"HESI Account link on Main Menu"))
		{
			flag=false;
		}
		if(!click(ElsevierObjects.StudentAccountlink,"HESI Student Account Link on Drop Down"))
		{
			flag=false;
		}

		//sgErrMsg="Unable to Click on Accounts and Faculty Programs Link";
		b=false;
		return flag;
		
	}
	catch(Exception e)
	{sgErrMsg="Unable to Click on Accounts and Stundent Account Programs Link"+e;
		return false;}
 }


public static boolean SearchStudnetuser(String Studentuser) throws Throwable 
{
	try
	{
		Thread.sleep(3000);
		b=true;
        flag=true;
        //driver.switchTo().frame(0);
		if(!type(ElsevierObjects.HESI_Enter_Text,Studentuser,"Enter Student User"))
		{
			flag=false;
		}

		if(!selectByVisibleText(ElsevierObjects.HESI_Stud_Select,"Equals","Enter Student User"))
		{
			flag=false;
		}

		
        if(!click(ElsevierObjects.HESI_Stud_Gobutton,"Go Button"))
		{
			flag=false;
		}
		
		//sgErrMsg="Unable to Click on Accounts and Faculty Programs Link";
		b=false;
		return flag;
		
	}
	catch(Exception e)
	{sgErrMsg="Unable to Click on Accounts and Faculty Programs Link"+e;
		return false;}
 }

public static boolean NavigatingtoAccountManagmentPage(String user) throws Throwable 
{
	try
	{
		Thread.sleep(3000);
        flag=true;
		if(!click(ElsevierObjects.Accountlink,"HESI Account link on Main Menu"))
		{
			flag=false;
		}
		if(!click(ElsevierObjects.FacultyProgramslink,"HESI FacultyandPrograms Link on Drop Down"))
		{
			flag=false;
		}
		click(By.id("CrtFacLnk"), "");

		//sgErrMsg="Unable to Click on Accounts and Faculty Programs Link";
		return flag;
		
	}
	catch(Exception e)
	{sgErrMsg="Unable to Click on Accounts and Faculty Programs Link"+e;
		return false;}
 }


public static boolean AddUser(String EvolveUserID) throws Throwable 
{
	try
	{
		Thread.sleep(4000);
		//driver.switchTo().defaultContent();

        flag=true;
        driver.switchTo().frame("Account Mgmt");
		if(!click(ElsevierObjects.CreateNewfacultyAccount,"HESI Create New faculty link "))
		{
			flag=false;
		}
//		  switchToFrameByName("Account Mgmt");
		Thread.sleep(2000);
	//	driver.findElement(ElsevierObjects.EvolveAddbutton);
		List<WebElement>e=driver.findElements(By.xpath(".//*[@id='TB_ajaxContent']/div[3]/span[2]"));
		System.out.println(e.size());
		/*if(!click(ElsevierObjects.HESI_EvolveId,"Enter Evolve User id"))
		{
			flag=false;
		}*/
		/*if(!type(ElsevierObjects.HESI_EvolveId,EvolveUserID,"Enter Evolve User id"))
		{
			flag=false;
		}*/
		/*Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_TAB);
		Thread.sleep(3000);
		robot.keyRelease(KeyEvent.VK_ENTER);*/
		
		System.out.println(EvolveUserID);
		
		driver.findElement(By.xpath("//input[@id='EvlName']")).sendKeys(EvolveUserID.trim());
		//JavascriptExecutor executor = (JavascriptExecutor) driver;
		//System.out.println("$('#EvlName').val('"+EvolveUserID.trim()+"');");
		//executor.executeScript("$('#EvlName').val('"+EvolveUserID.trim()+"');");
		//javaClick(ElsevierObjects.HESI_EvolveId, "");
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath(".//*[@id='popupWithEvlName']")).click();
		//driver.findElement(By.xpath(".//*[@id='popupWithEvlName']/b")).click();
		
//		driver.findElement(By.xpath("//input[@id='EvlName']")).sendKeys(EvolveUserID);
//		driver.findElement(By.xpath("//span[/a[@id='FacWithEvlName']]")).click();
		
		//driver.findElement(By.xpath(".//*[@id='FacWithEvlName']")).sendKeys(EvolveUserID);
		/*
		StringSelection stringSelection = new StringSelection(EvolveUserID);
	    Thread.sleep(1000);
	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection,null);
	    Robot r=new Robot();
	    r.keyPress(KeyEvent.VK_CONTROL);
	    r.keyPress(KeyEvent.VK_V);
	    r.keyRelease(KeyEvent.VK_CONTROL);*/
		/*if(!type(ElsevierObjects.HESI_EvolveId,EvolveUserID,"Enter Evolve User id"))
		{
			flag=false;
		}*/
		
		/*Thread.sleep(5000);
		driver.findElement(By.xpath(".//*[@id='popupWithEvlName']/b")).click();
		Alert();
		if(!type(ElsevierObjects.HESI_EvolveId,EvolveUserID,"Enter Evolve User id"))
			
		{
			flag=false;
		}
		driver.findElement(By.xpath(".//*[@id='popupWithEvlName']/b")).click();*/
		/*
		driver.switchTo().defaultContent();
		driver.switchTo().frame("Account Mgmt");
		
		driver.findElement(ElsevierObjects.EvolveAddbutton).click();
		
		
		driver.switchTo().defaultContent();

        flag=true;
        driver.switchTo().frame("Account Mgmt");
		if(!click(ElsevierObjects.CreateNewfacultyAccount,"HESI Create New faculty link "))
		{
			flag=false;
		}
//		  switchToFrameByName("Account Mgmt");
		Thread.sleep(2000);
	//	driver.findElement(ElsevierObjects.EvolveAddbutton);
		if(!type(ElsevierObjects.HESI_EvolveId,EvolveUserID,"Enter Evolve User id"))
		{
			flag=false;
		}
		Thread.sleep(5000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame("Account Mgmt");
		Thread.sleep(10000);
		driver.findElement(ElsevierObjects.EvolveAddbutton).click();

		//driver.findElement(By.linkText("Add")).click();
		//driver.findElement(By.xpath(".//*[@id='popupWithEvlName']/b")).click();
		
		//driver.findElement(ElsevierObjects.HESI_EvolveId).sendKeys(Keys.TAB);
		//Robot r=new Robot();
		//r.keyPress(KeyEvent.VK_ENTER);
		//javaClick(By.cssSelector("#FacWithEvlName"), "");
		
		/*WebElement el = driver.findElement(By.cssSelector("#FacWithEvlName"));

		     Actions builder = new Actions(driver);
		     builder.moveToElement( el ).click( el ).perform();
		     driver.findElement(By.cssSelector("#FacWithEvlName")).submit();*/
		//Robot r = new Robot();
		//r.mouseMove(130, 15);
		//r.keyPress(KeyEvent.KEY_PRESSED);
		//r.keyPress(KeyEvent.KEY_RELEASED);
		//r.mouseRelease(InputEvent.BUTTON1_MASK);
		// click Save File 
		//String locator = cssLocator;
		//JavascriptExecutor js;
		
		  //  js = (JavascriptExecutor)driver;
			//	js.executeScript("javascript:newFacWithEvlName(0,"+EvolveUserID+");");
	     //((JavascriptExecutor) driver).executeAsyncScript("javascript:newFacWithEvlName(0,this)");
	     //builder.perform();
		/*if(!click(ElsevierObjects.EvolveAddbutton,""))
		{
			flag=false;
		}*/
		//driver.findElement(By.xpath(".//*[@id='popupWithEvlName']/b")).click();
		Thread.sleep(3000);
		//driver.switchTo().defaultContent();
//		sgErrMsg="Unable to Click on Accounts and Faculty Programs Link";
		return flag;
		
	}
	catch(Exception e)
	{sgErrMsg="Unable to Click on Accounts and Faculty Programs Link"+e;
		return false;}
 }

public static boolean SearchUser(String EvolveUserID) throws Throwable 
{
	try
	{
		Thread.sleep(3000);
		driver.switchTo().frame("Account Mgmt");
        flag=true;
		if(!type(ElsevierObjects.SearchEvolve_id, EvolveUserID,"Enter Evolve User id"))
		{
			flag=false;
		}

		if(!click(ElsevierObjects.Search_Results ,"Click on  Search Button"))
		{
			flag=false;
		}
		sgErrMsg="Unable Check Evolve User Details and Search Button";
		return flag;
	
	}catch(Exception e)
	{sgErrMsg="Unable Check Evolve User Details and Search Button"+e;
	 return false;}
 }

public static boolean CompareValuesintheResultsandClickonResults(String EvolveId,String firstname,String lastname,String Email) throws Throwable
{
try
{       String AppEvolveId="";
		String AppFirstname="";
		String AppLastName="";
		String AppEmail="";
	    List<WebElement> tr = driver.findElements(By.xpath(".//*[@id='list']/tbody/tr"));
	    int TotalResults=tr.size()-1;
	    if(tr.size()>=2)
	    {
	    	for(int i=2;i<=tr.size();i++)
	    	{
	    		AppEvolveId=driver.findElement(By.xpath(".//*[@id='list']/tbody/tr["+i+"]/td[1]")).getText();
	    		AppFirstname=driver.findElement(By.xpath(".//*[@id='list']/tbody/tr["+i+"]/td[2]")).getText();
	    		AppLastName=driver.findElement(By.xpath(".//*[@id='list']/tbody/tr["+i+"]/td[3]")).getText();
	    		AppEmail=driver.findElement(By.xpath(".//*[@id='list']/tbody/tr["+i+"]/td[4]")).getText();
	    		
	    	if(EvolveId.equals(AppEvolveId)&&(firstname.equals(AppFirstname )&&(lastname.equals(AppLastName))&&Email.equals(AppEmail)))
     			{
	    		Reporters.SuccessReport("Verifying the Values in The Appeared Results", "Total Results:"+TotalResults+""
	    				+ "</br> Expected Evovle Id: "+EvolveId+" Actual Evovle Id:"+AppEvolveId 
	    				+ "</br> Expected FirstName is: "+firstname+"Acutual First Name is: "+AppFirstname
	    				+ "</br> Expected Last Name is : "+lastname+"Expected Last Name:"+AppLastName 
	    				+" </br> Expected Mail id: "+Email+" Actual Mail id:"+AppEmail);
	    		click(By.xpath(".//*[@id='list']/tbody/tr/td/span/span[contains(text(),'"+EvolveId+"')]"), "Clicking on Evolve ID");
	    	    Thread.sleep(5000);
	    		return true;
	    		}
	    	}
	    }
	    sgErrMsg="No Results Displayed";
		return false;
}catch(Exception e){sgErrMsg="No Results Displayed or Failed to Click on EvolveID Due to "+e;return false;}	}

public static boolean getAccountDetails(String user) throws Throwable{
	boolean flag=true;
    b=false;
	try{


		if(!click(ElsevierObjects.myAccount,"click on my account")){
			flag=false;
		}
		Thread.sleep(5000);
		if(!click(ElsevierObjects.myAccount_AccountSettings,"click on account settings.")){
			flag=false;
		}
		Thread.sleep(3000);
		if(user.equalsIgnoreCase("studentUpdate")){
		//String firstName=getText(ElsevierObjects.User_form_txtFirstName, "Get first name");
		getAccountDetailsUserName=getAttribute(ElsevierObjects.User_form_UserName, "value", "Get first name");
		getAccountDetailsFirstName=getAttribute(ElsevierObjects.User_form_txtFirstName, "value", "Get first name");
		getAccountDetailsLastName=getAttribute(ElsevierObjects.User_form_txtLastName,"value","Get Last Name");
		getAccountDetailsEmail=getAttribute(ElsevierObjects.User_form_txtEmail,"value","Get email id.");
		//getAccountDetailsInstitution=getAttribute(ElsevierObjects.User_form_txtInstution, "value","Get Institution name");
		//getAccountDetailsPhone=getAttribute(ElsevierObjects.User_form_txtAddPhone,"value","Get phone number");
		//getAccountDetailsStreetAddress=getAttribute(ElsevierObjects.User_form_txtAddress1,"value", "Get Street Adress");
		//getAccountDetailsStreetAddress2=getAttribute(ElsevierObjects.User_form_txtAddress2,"value", "Get Street Adress");
		//getAccountDetailsCountry=getAttribute(ElsevierObjects.User_form_ddInstutionCountry,"value", "Get country of institution.");
		Thread.sleep(2000);
		if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
			flag=false;
		}
		}else{
			String firstName=getText(ElsevierObjects.User_form_txtFirstName, "Get first name");
			getAccountDetailsUserName=getAttribute(ElsevierObjects.User_form_UserName, "value", "Get first name");
			getAccountDetailsFirstName=getAttribute(ElsevierObjects.User_form_txtFirstName, "value", "Get first name");
			getAccountDetailsLastName=getAttribute(ElsevierObjects.User_form_txtLastName,"value","Get Last Name");
			getAccountDetailsEmail=getAttribute(ElsevierObjects.User_form_txtEmail,"value","Get email id.");
			getAccountDetailsInstitution=getAttribute(ElsevierObjects.User_form_txtInstution, "value","Get Institution name");
			getAccountDetailsPhone=getAttribute(ElsevierObjects.User_form_txtAddPhone,"value","Get phone number");
			getAccountDetailsStreetAddress=getAttribute(ElsevierObjects.User_form_txtAddress1,"value", "Get Street Adress");
			getAccountDetailsStreetAddress2=getAttribute(ElsevierObjects.User_form_txtAddress2,"value", "Get Street Adress");
			getAccountDetailsCountry=getAttribute(ElsevierObjects.User_form_ddInstutionCountry,"value", "Get country of institution.");
			Thread.sleep(2000);
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
		}
		Thread.sleep(2000);
	}
	catch(Exception e){
		System.out.println(e.getMessage());
	}
	return flag;
}


public static boolean CompareHESIFacDetails(String EvolveId,String Firstname,String Lastname,String Emailid,String Instution,String Mobile,String Address1,String Address2,String Country,String State,String City,String ZipCode) throws Throwable
{
	boolean flag=true;
    b=true;
	try
	{
		String HESI_Fac_Firstname=getAttribute(ElsevierObjects.HESI_Fac_Firstname, "value", "Faculty_Firstname");
		CompareString(HESI_Fac_Firstname, Firstname, "Faculty Firstname");
		
		String HESI_Fac_Lastname=getAttribute(ElsevierObjects.HESI_Fac_Lastname, "value", "Faculty_Lastname");
		CompareString(HESI_Fac_Lastname, Lastname, "Faculty Last Name");
	
		String HES_Fac_Email=getAttribute(ElsevierObjects.HES_Fac_Email, "value", "Faculty_Email");
		CompareString(HES_Fac_Email, Emailid, "Faculty Email");
	
		String HES_Fac_EvolveID=getAttribute(ElsevierObjects.HES_Fac_EvolveID, "value", "Evolve ID");
		CompareString(HES_Fac_EvolveID, EvolveId, "Evolve ID");
	
		String HES_Fac_cOUNTRY=getFirstSelectedOption(ElsevierObjects.HES_Fac_cOUNTRY,"Country");
		CompareString(HES_Fac_cOUNTRY, Country, "Country");
	
		String HES_Fac_Address1=getAttribute(ElsevierObjects.HES_Fac_Address1, "value", "Address1");
		CompareString(HES_Fac_Address1, Address1, "Address1");
	
		String HES_Fac_Address2=getAttribute(ElsevierObjects.HES_Fac_Address2, "value", "Address2");
		CompareString(HES_Fac_Address2, Address2, "Address2");
	
		String HES_Fac_ZipCode=getAttribute(ElsevierObjects.HES_Fac_ZipCode, "value", "ZipCode");
		CompareString(HES_Fac_ZipCode, ZipCode, "ZipCode");
	
		String HES_Fac_City=getAttribute(ElsevierObjects.HES_Fac_City, "value", "City");
		CompareString(HES_Fac_City, City, "City");
	
		String HES_Fac_State=getAttribute(ElsevierObjects.HES_Fac_State, "value", "State");
		CompareString(HES_Fac_State, State, "State");
	
		/*
		String HES_Fac_CountryCode=getAttribute(ElsevierObjects.HES_Fac_CountryCode, "value", "Country Code");
		CompareString(HES_Fac_CountryCode, Emailid, "Country Code");
	
		*/
		return flag;
	}catch(Exception e){sgErrMsg="Failed to get the values"+e; return false;}

}

public static boolean CompareHESINewFacDetails(String EvolveId,String Firstname,String Lastname,String Emailid,String Instution,String Mobile,String Address1,String Address2,String Country,String State,String City,String ZipCode) throws Throwable
{
	boolean flag=true;
    b=false;
	try
	{
		String HESI_Fac_Firstname=getAttribute(ElsevierObjects.HESI_Firstname, "value", "Faculty_Firstname");
		CompareString(HESI_Fac_Firstname, Firstname, "Faculty Firstname");
		
		String HESI_Fac_Lastname=getAttribute(ElsevierObjects.HESI_Lastname, "value", "Faculty_Lastname");
		CompareString(HESI_Fac_Lastname, Lastname, "Faculty Last Name");
	
		String HES_Fac_Email=getAttribute(ElsevierObjects.HESI_UserMailid, "value", "Faculty_Email");
		CompareString(HES_Fac_Email, Emailid, "Faculty Email");
	
		String HES_Fac_EvolveID=getAttribute(ElsevierObjects.HESI_FacEvolveId, "value", "Evolve ID");
		CompareString(HES_Fac_EvolveID, EvolveId, "Evolve ID");
	
		String HES_Fac_cOUNTRY=getFirstSelectedOption(ElsevierObjects.HESI_Country,"Country");
		if(HES_Fac_cOUNTRY.equalsIgnoreCase("Select Country"))
		{
			HES_Fac_cOUNTRY="";
		}
		CompareString(HES_Fac_cOUNTRY, Country, "Country");
	
		String HES_Fac_Address1=getAttribute(ElsevierObjects.HESI_Address1, "value", "Address1");
		CompareString(HES_Fac_Address1, Address1, "Address1");
	
		String HES_Fac_Address2=getAttribute(ElsevierObjects.HESI_Address2, "value", "Address2");
		CompareString(HES_Fac_Address2, Address2, "Address2");
	
		String HES_Fac_ZipCode=getAttribute(ElsevierObjects.HESI_ZipCode, "value", "ZipCode");
		CompareString(HES_Fac_ZipCode, ZipCode, "ZipCode");
	
		String HES_Fac_City=getAttribute(ElsevierObjects.HESI_City, "value", "City");
		CompareString(HES_Fac_City, City, "City");
	
		String HES_Fac_State=getAttribute(ElsevierObjects.HESI_State, "value", "State");
		CompareString(HES_Fac_State, State, "State");
	
		/*
		String HES_Fac_CountryCode=getAttribute(ElsevierObjects.HES_Fac_CountryCode, "value", "Country Code");
		CompareString(HES_Fac_CountryCode, Emailid, "Country Code");
	
		*/
		return flag;
	}catch(Exception e){sgErrMsg="Failed to get the values"+e; return false;}

}



public static boolean UpdateExistingFac(String Areacode,String Phonenumber) throws Throwable
{
	boolean flag=true;
    //b=true;
	try
	{
				if(!type(By.id("txtfacAreaCode"), Areacode, "Area Code"))
		{
			 flag=false;
		}

		if(!type(By.id("txtfacContact1"), Phonenumber, "PhoneNumber"))
		{
			 flag=false;
		}

				return flag;
				
	}catch(Exception e){sgErrMsg="Failed to update the values"+e; return false;}

}

public static boolean UpdateHESIFac(String Firstname,String Lastname,String Emailid,String Areacode,String Phonenumber,String Comments) throws Throwable
{
	boolean flag=true;
    b=true;
	try
	{
		if(!type(ElsevierObjects.HESI_Fac_Firstname, Firstname, "Faculty_Firstname"))
		{
			 flag=false;
		}
		
		if(!type(ElsevierObjects.HESI_Fac_Firstname, Firstname, "Faculty_Firstname"))
				{
					 flag=false;
				}
				
		if(!type(ElsevierObjects.HESI_Fac_Lastname, Lastname, "Faculty_Lastname"))
				{
					 flag=false;
				}
				
		if(!type(ElsevierObjects.HES_Fac_Email, Emailid, "Faculty_Email"))
		{
			 flag=false;
		}

		
		if(!type(ElsevierObjects.HES_Fac_AreaCode, Areacode, "Area Code"))
		{
			 flag=false;
		}

		if(!type(ElsevierObjects.HES_Fac_PhoneNumber, Phonenumber, "PhoneNumber"))
		{
			 flag=false;
		}

		if(!type(ElsevierObjects.Hes_Fac_Comments, Comments, "Comments"))
		{
			 flag=false;
		}

		if(!click(ElsevierObjects.Hes_Fac_Save, "Save"))
		{
			 flag=false;
		}
		Thread.sleep(veryhigh);
     Alert();
		 
		return flag;
	}catch(Exception e){sgErrMsg="Failed to get the values"+e; return false;}

}

public static boolean UpdateNewFac(String Comments,String Organization,String Roles) throws Throwable
{
	boolean flag=true;
    b=false;
    Thread.sleep(100);
	try
	{
		
		if(!type(ElsevierObjects.HESI_comments, Comments, "Comments"))
		{
			 flag=false;
		}
		
		if(!click(ElsevierObjects.Hes_Fac_Next, "Next"))
		{
			 flag=false;
		}
	    Thread.sleep(high);

		if(!type(ElsevierObjects.HES_Add_organization, Organization, "Organization"))
		{
			 flag=false;
		}
		
		
		driver.findElement(ElsevierObjects.HES_Add_organization).sendKeys(Keys.DOWN);
		driver.findElement(ElsevierObjects.HES_Add_organization).sendKeys(Keys.ENTER);
		Thread.sleep(1000);
		driver.findElement(ElsevierObjects.HES_Add_organization).sendKeys(Keys.TAB);
		Thread.sleep(10000);
		if(!click(ElsevierObjects.lableoforganization, "Lable of Organization"))
		{
			 flag=false;
		}
	    
	    Thread.sleep(20000);
	    
	    if(!selectByVisibleText_New(ElsevierObjects.listoforganizations, Organization, "Organization"))
	    {
	    	 flag=false;	
	    }
	    

	    if(!click(ElsevierObjects.Addorg, "Move to Faculty button"))
		{
			 flag=false;
		}
	    
	    Thread.sleep(10000);
	    if(!selectByVisibleText(ElsevierObjects.RolesinHESI, Roles, "Roles in HESI"))
	    {
	    	 flag=false;	
	    }
		Thread.sleep(10000);
		Alert();

		if(!click(ElsevierObjects.Hes_Fac_Next, "Next"))
		{
			 flag=false;
		}
		
		
        Alert();

		Thread.sleep(1000);
        Alert();

        Thread.sleep(1000);
        return flag;
	}catch(Exception e){sgErrMsg="Failed to get the values"+e; return false;}

}

public static boolean UpdateAccountDetails(String Firstname,String Lastname,String Emailid,String Instution,String Mobile,String Address1,String Address2,String Country,String State,String City,String ZipCode,String Program) throws Throwable{
	boolean flag=true;
    //b=true;
	try{


		if(!click(ElsevierObjects.myAccount,"click on my account")){
			flag=false;
		}
		Thread.sleep(5000);
		if(!click(ElsevierObjects.myAccount_AccountSettings,"click on account settings.")){
			flag=false;
		}
		Thread.sleep(2000);
		//String firstName=getText(ElsevierObjects.User_form_txtFirstName, "Get first name");
//		type(ElsevierObjects.User_form_UserName, EvolveId, "Get first name");
		type(ElsevierObjects.User_form_txtFirstName, Firstname, "First name");
		type(ElsevierObjects.User_form_txtLastName,Lastname,"Last Name");
		
		if(Emailid!=null)
		{
		type(ElsevierObjects.User_form_txtEmail,Emailid,"Email id.");
		type(ElsevierObjects.User_form_txtConformEmail,Emailid,"Confirm Email id.");
		}
		selectByVisibleText(ElsevierObjects.User_form_ddInstutionCountry,Country, "Institution Country.");
        Thread.sleep(1000);
        driver.findElement(ElsevierObjects.User_form_ddInstutionCountry).sendKeys(Keys.TAB);
		selectByVisibleText(ElsevierObjects.User_form_State,State, "State institution.");
		
		type(ElsevierObjects.User_form_City,City, "Get Street Adress");
		driver.findElement(ElsevierObjects.User_form_City).sendKeys(Keys.TAB);
		Thread.sleep(300);

		type(ElsevierObjects.User_form_txtInstution, Instution,"Institution name");
        Thread.sleep(300);
        if(Mobile!=null)
    	{
		type(ElsevierObjects.User_form_txtAddPhone,Mobile,"Phone number");
        Thread.sleep(300);
        }
		type(ElsevierObjects.User_form_txtAddress1,Address1, "Street Adress1");
        Thread.sleep(300);

		type(ElsevierObjects.User_form_txtAddress2,Address2, "Street Adress2");
        Thread.sleep(300);

		type(ElsevierObjects.User_form_txtAddPostalCode,ZipCode, "Postal Code");
        Thread.sleep(300);

        selectBySendkeys(ElsevierObjects.User_form_txtddprogramType,Program, "Program Type.");
        
		Thread.sleep(2000);
		if(!click(ElsevierObjects.User_form_btnContinue,"Submit")){
			flag=false;
		}
		Thread.sleep(2000);
	}
	catch(Exception e){sgErrMsg="The Values are Not Submitted"+e;
		System.out.println(e.getMessage());return false;
	}
	return flag;
}

public static boolean StudentUpdateAccountDetails(String Firstname,String Lastname,String Emailid) throws Throwable{
	boolean flag=true;
    b=true;
	try{


		if(!click(ElsevierObjects.myAccount,"click on my account")){
			flag=false;
		}
		Thread.sleep(5000);
		if(!click(ElsevierObjects.myAccount_AccountSettings,"click on account settings.")){
			flag=false;
		}
		Thread.sleep(2000);
		//String firstName=getText(ElsevierObjects.User_form_txtFirstName, "Get first name");
//		type(ElsevierObjects.User_form_UserName, EvolveId, "Get first name");
		type(ElsevierObjects.User_form_txtFirstName, Firstname, "First name");
		type(ElsevierObjects.User_form_txtLastName,Lastname,"Last Name");
		type(ElsevierObjects.User_form_txtEmail,Emailid,"Email id.");
		type(ElsevierObjects.User_form_txtConformEmail,Emailid,"Confirm Email id.");
				if(!click(ElsevierObjects.User_form_btnContinue,"Submit Button" )){
			flag=false;
		}
		Thread.sleep(high);
	}
	catch(Exception e){sgErrMsg="The Values are Not Submitted"+e;
		System.out.println(e.getMessage());return false;
	}
	return flag;
}

public static boolean getStudnetDetailsandCompare(String Evolve_id,String firstname,String lastname,String Email )throws Throwable
{
boolean flag=true;
try
	{
	Thread.sleep(300);
	waitForElementPresent(ElsevierObjects.HESI_Stud_Evolveid, "Results");
	String 	HESI_Stuid=getText(ElsevierObjects.HESI_Stud_Evolveid,"Student Id");
	if(Evolve_id.equalsIgnoreCase(HESI_Stuid))
	{
		Reporters.SuccessReport("Verify User ID", "User Id from CERT:"+Evolve_id+"</br> User id from HESI Results:"+HESI_Stuid);
		//flag=false;
	}
	else
	{
		Reporters.failureReport("Verify User ID", "User Id from CERT:"+Evolve_id+"</br> User id from HESI Results:"+HESI_Stuid);
		flag=false;
	}
	String 	HESI_Stud_Firstname=getText(ElsevierObjects.HESI_Stud_Firstname,"First Name");
	if(firstname.equalsIgnoreCase(HESI_Stud_Firstname))
	{
		Reporters.SuccessReport("Verify First name", "First name from CERT:"+firstname+"</br> First name from HESI Results:"+HESI_Stud_Firstname);
		
	}
	else
	{
		Reporters.failureReport("Verify First name", "First name from CERT:"+firstname+"</br> First name from HESI Results:"+HESI_Stud_Firstname);
		flag=false;
	}
	
	String 	HESI_Stud_Lastname=getText(ElsevierObjects.HESI_Stud_Lastname,"Last Name");
	if(lastname.equalsIgnoreCase(HESI_Stud_Lastname))
	{
		Reporters.SuccessReport("Verify Last name", "Last name from CERT:"+lastname+"</br> Last name from HESI Results:"+HESI_Stud_Lastname);
	}
	else
	{
		Reporters.failureReport("Verify Last name", "Last name from CERT:"+lastname+"</br> Last name from HESI Results:"+HESI_Stud_Lastname);
		flag=false;
	}
	
	String 	HESI_Stud_Email=getText(ElsevierObjects.HESI_Stud_Email,"Email");
	if(Email.equalsIgnoreCase(HESI_Stud_Email))
	{
		Reporters.SuccessReport("Verify Email", "Email from CERT:"+Email+"</br> Email from HESI Results:"+HESI_Stud_Email);
	}
	else
	{
		Reporters.failureReport("Verify Email", "Email from CERT:"+Email+"</br>Email from HESI Results:"+HESI_Stud_Email);
		flag=false;
	}
	
	return flag;
	}catch(Exception e){sgErrMsg="Failed to get the Details"+e;return false;}
}
public static boolean hesiGetDetails() throws Throwable{
	boolean flag=true;
	try{
		      /*List<WebElement> frames=driver.findElements(By.tagName("iframe"));
		      for(WebElement e: frames){
		      System.out.println(e.getText());}
		      switchToFrameByName("Account Mgmt");
		      //String firstnam=getText(ElsevierObjects.Firstname, "");
		      String fn=driver.findElement(By.xpath(".//*[@id='txtfacLastName']")).getAttribute("value");*/
		//driver.switchTo().defaultContent();
		driver.switchTo().alert();
        String firstName=getAttribute(ElsevierObjects.HESI_Firstname, "value", "First Name");
        String lastName=getAttribute(ElsevierObjects.HESI_Lastname, "value", "Last Name");
        String userMailID=getAttribute(ElsevierObjects.HESI_UserMailid, "value", "Email");
        String country=getAttribute(ElsevierObjects.HESI_Country, "value", "Country");
        String countryCode=getAttribute(ElsevierObjects.HESI_CountryCode, "value", "Country Code");
        String areaCode=getAttribute(ElsevierObjects.HESI_Areacode, "value", "Area Code");
        String phoneNum=getAttribute(ElsevierObjects.HESI_Phonenumber, "value", "Phone Number");
        String address1=getAttribute(ElsevierObjects.HESI_Address1, "value", "Address1");
        String address2=getAttribute(ElsevierObjects.HESI_Address2, "value", "Address2");
        String zipCode=getAttribute(ElsevierObjects.HESI_ZipCode, "value", "ZipCode");
        String city=getAttribute(ElsevierObjects.HESI_City, "value", "City");
        String state=getAttribute(ElsevierObjects.HESI_State, "value", "State");
        
        /*getAccountDetailsUserName=getAttribute(ElsevierObjects.User_form_UserName, "value", "Get first name");
		getAccountDetailsFirstName=getAttribute(ElsevierObjects.User_form_txtFirstName, "value", "Get first name");
		getAccountDetailsLastName=getAttribute(ElsevierObjects.User_form_txtLastName,"value","Get Last Name");
		getAccountDetailsEmail=getAttribute(ElsevierObjects.User_form_txtEmail,"value","Get email id.");
		getAccountDetailsInstitution=getAttribute(ElsevierObjects.User_form_txtInstution, "value","Get Institution name");
		getAccountDetailsPhone=getAttribute(ElsevierObjects.User_form_txtAddPhone,"value","Get phone number");
		getAccountDetailsStreetAddress=getAttribute(ElsevierObjects.User_form_txtAddress1,"value", "Get Street Adress");
		getAccountDetailsStreetAddress2=getAttribute(ElsevierObjects.User_form_txtAddress2,"value", "Get Street Adress");
		getAccountDetailsCountry=getAttribute(ElsevierObjects.User_form_ddInstutionCountry,"value", "Get country of institution.");*/
		Thread.sleep(2000);
        
		if (getAccountDetailsFirstName.contains(firstName) && getAccountDetailsLastName.contains(lastName) && getAccountDetailsEmail.contains(userMailID)
				&& getAccountDetailsPhone.contains(phoneNum) && getAccountDetailsStreetAddress.contains(address1) && getAccountDetailsStreetAddress2.contains(address2)
				&& getAccountDetailsCountry.contains(country)) {
			System.out.println("all details are correct");
			
		}else{
			System.out.println("details are not correct");
		}
        
        
        
	}catch(Exception e){
		System.out.println("exception occured");return false;
	}
	return flag;
}

public static boolean section2()throws Throwable{
	boolean flag = true;
	type(By.xpath(".//*[@id='txtfacComments']"), "HESI automation testing","Comment");
	click(By.xpath(".//*[@id='facSaveBtn']"), "Click on next button");
	
	return flag;
}

}





