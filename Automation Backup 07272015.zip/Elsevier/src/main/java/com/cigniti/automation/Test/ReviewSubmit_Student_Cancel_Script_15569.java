package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.Review_SubmitStudentInstructor_Cancel;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class ReviewSubmit_Student_Cancel_Script_15569 extends Review_SubmitStudentInstructor_Cancel {

	@Test 
	public void reviewSubmitStudentCancel_15569() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String username=ReadingExcel.columnDataByHeaderName("Student", "ReviewAndSubmit",configProps.getProperty("TestData"));
			String password=ReadingExcel.columnDataByHeaderName("StudentPassword", "ReviewAndSubmit",configProps.getProperty("TestData"));
			
				String user = "student";
				String reviewAndSubmit = "false";
				writeReport(User_BusinessFunction.Studentlogin(username, password),"Login to Application Using Educator Credentials"+username,
						"Launching the URL for Educator is successful </br > Login to Application Using Educator credentails :"+username+" is Successful",
						"Launching and Login to Application Using Educator credentails : "+ username+" is Failed");
				Thread.sleep(medium);
				if(isElementPresent(ElsevierObjects.evolveCatalog)){
					click(ElsevierObjects.evolveCatalog, "Click on Catalog");
				}
				
				Thread.sleep(medium);
				click(ElsevierObjects.clickOnCart, "Clicked on Cart Icon");
				Thread.sleep(medium);
				String cartItems=getText(ElsevierObjects.noCartItems, "");
				if(cartItems!=null){
					Reporters.SuccessReport("Check for the No items are present in the cart.", "There are no items in the cart is displayed <br> The message printed is : "+cartItems);
				}else{
					Reporters.failureReport("Check for the No items are present in the cart.", "items are available in the cart");
				}
				instructorLogout();
				checkCart(user, reviewAndSubmit);
				String searchPaperback=ReadingExcel.columnDataByHeaderName("searchData", "ReviewAndSubmit",configProps.getProperty("TestData"));
				searchAndAddproduct(reviewAndSubmit, searchPaperback);
				
				if(EvolveCommonBussinessFunctions.creditCardDetails())
					Reporters.SuccessReport("Entering credit card details.", "Credit card details entered successfully.");
				else
					Reporters.failureReport("Entering credit card details.", "Failed to enter credit card details.");
				
				validteReviewPage();
				cancelOrder();
				Thread.sleep(high);
				if(instructorLogout()){
					Reporters.SuccessReport("Click on Logout", "Successfully Logged out from user");
				}else{
					Reporters.failureReport("Click on Logout", "Successfully Logged out from user");
				}
				
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
