package com.cigniti.automation.BusinessFunctions;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadTextFile;
import com.cigniti.automation.Utilities.Reporters;

public class SelfenrollintomanualcoursewithvalidLOaccessthroughcart_15574 extends EvolveCommonBussinessFunctions {
	
 public static String ProIsbn;
 public static String Title;
 public static String sIsbn;
 public static String User;
 public static String AccessCode;
 public static String ErrorMsg;
 public static String CourId;
 public static String ProschemeId; 
 public static String firstname;
 public static String lastname;
 public static String Instname;
 public static String Courtitle;  
 public static String ProductPrice;
 public static String Usepercode;
    
	public boolean createAccessCode(String isbNumber,String sUsesPerCode,String sNumberOfGenerated) throws Throwable {
	try
	   {
		boolean flag =true;
		b=true;
		click(ElsevierObjects.maintainProd,"Maintain Products");
		type(ElsevierObjects.searchTitle,isbNumber,"Enter ISBN number");
		click(ElsevierObjects.btnserchTitle,"Search button");
		Thread.sleep(medium);
	    click(By.xpath("//a[text()='"+isbNumber+"']"),"ISBN number of the Product");
		Thread.sleep(medium);
		b=false;
		createAccessCode(sUsesPerCode,sNumberOfGenerated);
		
		if(!click(ElsevierObjects.DOWNLOAD_ACCESS_CODE, "")){
			flag =false;
		}
		if(!click(ElsevierObjects.DOWNLOAD_ACCESS_CODE_TXT, "")){
			flag =false;
		}
        Thread.sleep(medium);
		if(ElsevierObjects.browserType.equalsIgnoreCase("firefox")){
			r = new Robot();
			r.keyPress(KeyEvent.VK_DOWN);
			r.keyPress(KeyEvent.VK_TAB);
			r.keyPress(KeyEvent.VK_TAB);
			r.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(low);
			r.keyPress(KeyEvent.VK_ENTER);
		}
		return flag;}
	    catch(Exception e){return false;}
	}

  public boolean createAccessCode(String sUsesPerCode,String sNumberOfGenerated) throws Throwable{
	boolean flag=true;
	try{
		b=true;
		click(ElsevierObjects.createAccessCode, "Create access code");
		b=false;
		Thread.sleep(medium);
		
		// changed 'ProschemeId' to 'protectionSchemeID' in the if statement
		if(getText(ElsevierObjects.schemeId, "").equalsIgnoreCase(protectionSchemeID)){
			Reporters.SuccessReport("Verify  the Scheme Id", "Verified the Scheme Id value displayed on the Create Access Code tab matches the protection scheme saved for the course ID");
		}else{
			Reporters.failureReport("Verify  the Scheme Id", "Verify that the Scheme Id value displayed on the Create Access Code tab doesn't matches the protection scheme saved for the course ID");
		}
		Thread.sleep(low);
		
		Date today = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
		Random ra = new Random( System.currentTimeMillis() );
		String CodeSetName = readcolumns.twoColumns(0, 1, "Tc-15235", configProps.getProperty("TestData")).get("CodeSetName")+Integer.toString((1 + ra.nextInt(2)) * 100 + ra.nextInt(10000)) + "-" + sdf.format(today);
		
		EvolveCommonBussinessFunctions.ACCESS_CODE =CodeSetName;
		b=true;
		type(ElsevierObjects.CreateAccessCode_codesetname, CodeSetName , "Code set name");
		b=false;
		Thread.sleep(medium);
		//driver.findElement(ElsevierObjects.Admin_Useper_code).clear();
		//Thread.sleep(medium);
		/*b=true;
		type(ElsevierObjects.Admin_Useper_code,sUsesPerCode,"Uses per code");
		b=false;*/
		driver.findElement(ElsevierObjects.CreateAccessCode_codeNumber).clear();
		Thread.sleep(low);
		b=true;
		type(ElsevierObjects.CreateAccessCode_codeNumber,sNumberOfGenerated,"Number to Generate");
		Thread.sleep(low);
		click(ElsevierObjects.CreateAccessCode_Submit, "Create access code submit button");
	    b=false;
		Thread.sleep(high);
		if(isElementPresent(ElsevierObjects.Success_MSG_for_AccessCode, "The Access Code Set was successfully created message")){
			Reporters.SuccessReport("Verify success message for access code creation ", "Successfully Created access code.</br>AccessCode Set Name Is: "+CodeSetName +"<br/> Success Message :The Access Code Set was successfully created");
		}
		else{
			Reporters.failureReport("Creating AccessCode.","Failed To Create access code.");
		}
		Thread.sleep(high);
		ImplicitWait();
	}
	catch(Exception e){
		System.out.println(e.getMessage());
	}
	return flag;
  }

  public boolean AccountCreation() throws Throwable {
  try{
	  boolean flag = true;
	  CreateNewUser(ElsevierObjects.STUDENT);
	  User = credentials[0];
	  String Pass = credentials[1];
	  if(User!=null){
		  Reporters.SuccessReport("Create Student User from Student Page","Created Student User from Student Page and logged into evolve cert as a student with credentials.</br> Username :"+User+ "</br> Password :"+Pass);
	  }else{
		  Reporters.failureReport("Create Student User from Student Page","Failed to Create Student User from Student Page");
	  }
	  Thread.sleep(low);
	  b=true;
	  click(ElsevierObjects.catalog,"Catalog");
	  Thread.sleep(low);
	  
	  // this no longer applies with new design
	  /*click(ElsevierObjects.Online_courses,"Online courses Honeypot");
	  Thread.sleep(low);
	  click(ElsevierObjects.Enroll_into_Course,"Enroll into a Course");
	  Thread.sleep(low);*/
	  
	  type(ElsevierObjects.Enroll_courseid_searchbox,CourId,"");
	  Thread.sleep(low);
	  click(ElsevierObjects.Enroll_continue,"Continue button");
	  Thread.sleep(low);
	  b=false;
	  if(isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MyCartTitle,"Check Mycart title")){
		    Reporters.SuccessReport("Verify MyCart page title", "User is in MyCart Page.");
	  }else{
		    Reporters.failureReport("Verify MyCart page title", "User is unable to navigate MyCart page.");
	 }
	  Thread.sleep(low);
	  Title = getText(ElsevierObjects.Medical_title,"Get title of the product");
	  if(Title!=null){
	       Reporters.SuccessReport("Verify the title of the product","Title of the product is verified and title is :"+Title);
	  }
	  Thread.sleep(low);
      sIsbn = getText(ElsevierObjects.Evolve_Isbn_Number,"Get the ISBN of the product");
      if(sIsbn!=null){
           Reporters.SuccessReport("Verify the ISBN of the product","ISBN of the product is verified and ISBN is :"+sIsbn);	  
      }
      Thread.sleep(low);
	  ProductPrice = getText(ElsevierObjects.Evolve_price,"Get the price present there");
	  if(ProductPrice!=null){
		  Reporters.SuccessReport("Verify the price of the product","Prices are verified Successfully and Price is :"+ProductPrice);
	  }
	  String Subtotal = getText(ElsevierObjects.Mycart_subtotal,"Get the total price present there");
	  if(ProductPrice.contains(Subtotal)){
		  Reporters.SuccessReport("Verify the price and totalprice","Total Prices are compared Successfully :<br> Product Price is : "+ProductPrice+"<br> Total Price is :"+Subtotal);
	  }else{
		  Reporters.failureReport("Verify the price and totalprice","Total Prices comparision is Failed :<br> Product Price is : "+ProductPrice+"<br> Total Price is :"+Subtotal);
	  }
	  String fullname = firstname+" "+lastname;
	  Courtitle = "Medical Terminology Online for Mastering Healthcare Terminology";
	  System.out.println(fullname);
	  System.out.println(Courtitle);
	  String SelfCourse = getText(ElsevierObjects.CourseId_details,"Get the correct self enrollment course info displays in the cart");
	  if(SelfCourse.contains(CourId) && SelfCourse.contains(Courtitle) && SelfCourse.contains(fullname) && SelfCourse.contains(Instname)){
		  Reporters.SuccessReport("Verify the correct self enrollment course info displays in the cart","Successfully Self Enrollment Course details are verified and details are :</br>" +SelfCourse);
	  }else{
		  Reporters.failureReport("Verify the correct self enrollment course info displays in the cart","Failed to Verify Self Enrollment Course details");
	  }
		return flag;}
       catch(Exception e){return false;}
  }
  
	  
  public void studnetCheckOut(boolean isStudentHaveAccessCode,String isbnNumber) throws Throwable{
   boolean flag = true;
   String errorMessage = "";
   try{
	   if(isStudentHaveAccessCode){
			if(click(By.id("ac-radio-apply-"+isbnNumber+""), "Click on radio button")){
				Reporters.SuccessReport("Select the radio button 'I have an access code:'", "'I have an access code:' radio button is selected");
			}else{
				Reporters.failureReport("Select the radio button 'I have an access code:'", "'I have an access code:' radio button is not selected");
			}
			Thread.sleep(high);
		    
			// my version
			//String path = readcolumns.twoColumnsBasedOnSheetName(0, 1, "Tc-15235", configProps.getProperty("TestData")).get("Filepath") + EvolveCommonBussinessFunctions.ACCESS_CODE;
			//AccessCode = ReadTextFile.readTextFile(path);
			
			// original
			AccessCode = ReadTextFile.readTextFile(EvolveCommonBussinessFunctions.ACCESS_CODE);

			if(type(ElsevierObjects.ACCESS_CODE, AccessCode, "Enter Access code")){
				Reporters.SuccessReport("Enter the access code", "Access code is entered. <br> Access Code : "+AccessCode);
			}else{
				Reporters.failureReport("Enter the access code", "Access code is not entered. ");
			}
			if(!click(By.id("ac-apply-"+isbnNumber), "")){
				flag = false;
			}
			Thread.sleep(high);
			String Accesserr = getText(ElsevierObjects.Access_error,"Get the Error for Access code");
			if(Accesserr==null){
				 Reporters.failureReport("Verify the Error for used Access code","Attempt to apply the same access code that was used then it should display error message as:"+Accesserr);
			}else{
				 Reporters.SuccessReport("Verify the Error for used Access code","Access code was unused");
			}
			Thread.sleep(low);
		   String totalAmount = getText(ElsevierObjects.SUB_TOTAL, "Get Total price");
		   if(totalAmount.contains("$0.00")){
			    Reporters.SuccessReport("Verify Total price","Price is verified successfully. The Total Price is 0");
		   }else{
				Reporters.failureReport("Verify Total price","The Total Price is Not Zero "+ totalAmount);
		   }
		   Thread.sleep(low);
		   String AccessReedem = getText(ElsevierObjects.Access_code_reedemption,"Get Access Code Redeemption price");
		   if(AccessReedem.contains(ProductPrice)){
				Reporters.SuccessReport("Verify Access Code Redeemption price","The Access Code Redeemption amount is same as the product cost before applying the access code and it is : " +AccessReedem);
		   }else{
				Reporters.failureReport("Verify Access Code Redeemption price","The Access Code Redeemption amount is not same as the product cost before applying the access code");
		   }
		   b=true;
		   if(!click(ElsevierObjects.btnRedeem,"Redeem Checkout Button and User is taken to the 'Update your Account' page.")){
			   flag = false;
		   }
		   Thread.sleep(medium);
           click(ElsevierObjects.Student_Shipping_Chk,"'I'm not affiliated with an institution");
		   Thread.sleep(high);
		   click(ElsevierObjects.btnprofilesubmit,"Hit Continue");
		   b=false;
		   }
	       Reporters.SuccessReport("Review and Submit Page","User is brought to Review and Submit Page");
		   String title = getText(ElsevierObjects.Product_title,"Get the product title");
		   if(title.contains(Title)){
				Reporters.SuccessReport("Verify the title of the product","Title's are compared successfully :<br> Expected title is :"+title+"<br> Actual title is :"+Title);
		   }else{
				Reporters.failureReport("Verify the title of the product","Title's comparision is failed :<br> Expected title is :"+title+"<br> Actual title is :"+Title);
		   }
		   Thread.sleep(low);
		   String ProductISBN = getText(ElsevierObjects.Evolve_Isbn_Number,"Get the ISBN of the product");
		   if(ProductISBN.contains(sIsbn)){
		    	Reporters.SuccessReport("Verify the ISBN of the product","ISBN's compared Successfully :<br> Expected ISBN is :"+ProductISBN+"<br> Actual ISBN is :"+sIsbn);
		   }else{
		    	Reporters.failureReport("Verify the ISBN of the product","ISBN's comparision is failed :<br> Expected ISBN is :"+ProductISBN+"<br> Actual ISBN is :"+sIsbn);
		   }
		   Thread.sleep(low);
		   String Price = getText(ElsevierObjects.Review_price,"Get the price of the product");
		   if(Price.contains("$0.00")){
				Reporters.SuccessReport("Verify the price of the product","Prices are compared successfully :<br> price of the product is :"+Price);
		   }else{
				Reporters.failureReport("Verify the price of the product","Prices comparision is failed");
		   }
		   String TotalPrice = getText(ElsevierObjects.Review_total_price,"Get the total price of the Product");
		   if(TotalPrice.contains("$0.00")){
				Reporters.SuccessReport("Verify the Totalprice of the product","Totalprices are compared successfully :<br> Total price of the Product is :"+TotalPrice);
		   }else{
				Reporters.failureReport("Verify the Totalprice of the product","Totalprices comparision is failed ");
		   }
		   Thread.sleep(low);
		   b=true;
		   click(ElsevierObjects.checkbox1,"'Yes, I accept the Registered User Agreement' checkbox");
		   Thread.sleep(medium);
		   click(ElsevierObjects.instructor_submit,"Submit button");
		   Thread.sleep(low);
		   b=false;
		   }catch(Exception e){
			errorMessage = e.getMessage();
		   }
	 finally{
			if(flag){
				Reporters.SuccessReport("Verify Confirmation page","User Sucessfully brought to Confirmation Page");
			}else{
				Reporters.failureReport("Verify Confirmation Page","User Unable to brought to Confirmation page Reason "+errorMessage);
			}
		}
  }
  
  public static boolean Confirmationpage()throws Throwable{
  try
	 {
	   boolean flag = true;	
	   String producttitle = getText(ElsevierObjects.Admin_Evolve_Ecom_Confirmtitle1,"Get Title of the product");
	   if(Title.contains(producttitle)){
			Reporters.SuccessReport("Verify the title of the product", "Title's are compared successfully :<br> Expected title is :"+Title+"<br> Actual title is :"+producttitle);
	   }else{ 
			Reporters.failureReport("Verify the title of the product", "Title's comparision is failed :<br> Expected title is :"+Title+"<br> Actual title is :"+producttitle);
	   }
	   Thread.sleep(low);
	   String Isbn = getText(ElsevierObjects.Isbn_number,"Get Isbn number");
	   if(Isbn.contains(sIsbn)){
	        Reporters.SuccessReport("Verify the ISBN of the product","ISBN's compared Successfully :<br> Expected ISBN is :"+Isbn+"<br> Actual ISBN is :"+sIsbn);
	   }else{
	    	Reporters.failureReport("Verify the ISBN of the product","ISBN's comparision is failed :<br> Expected ISBN is :"+Isbn+"<br> Actual ISBN is :"+sIsbn);
	   }
	   Thread.sleep(low);
	   String Price =getText(ElsevierObjects.price,"Get the Price of product");
	   if(Price.contains("$0.00")){
		    Reporters.SuccessReport("Verify the Item price of the product","prices are compared successfully :<br> price of the product is :"+Price);
	   }else{
			Reporters.failureReport("Verify the Item price of the product","prices comparision is failed ");
	   }
	   Thread.sleep(low);
	   String TotalPrice = getText(ElsevierObjects.confirm_total_price,"Get Totalprice of the product");
	   if(TotalPrice.contains("$0.00")){
			Reporters.SuccessReport("Verify the Totalprice of the product","Totalprices are compared successfully :<br> Toatl price of the product is :"+TotalPrice);
	   }else{
			Reporters.failureReport("Verify the Totalprice of the product","Totalprices comparision is failed ");
	   } 
	   Thread.sleep(low);
	   b=true;	   
	   click(ElsevierObjects.Myevolve,"My Evolve link");
	   Thread.sleep(low);
	   b=false;
	   String Id = getText(ElsevierObjects.Roster_Evolve_CourseId,"Get Unique CourseId");
	   if(Id.contains(CourId)){
		     Reporters.SuccessReport("Verify Unique CourseId","User is Successfully verified CourseId </br> Actual CourseId is :"+CourId+"</br> Expected CourseId is: "+Id);
	   }else{
			 Reporters.failureReport("Verify Unique CourseId","User is failed to verify CourseId");
	   }
	   Thread.sleep(low);
	   String Courselink = getText(ElsevierObjects.Course_link,"Get Unique CourseId link");
	   if(Courselink!=null){
			 Reporters.SuccessReport("Verify Unique CourseId link","User is Successfully verified CourseId link </br>" +Courselink);
	   }else{
			 Reporters.failureReport("Verify Unique CourseId link","User is failed to verify CourseId link");
	   }
	   Thread.sleep(low);
	   b=true;
	   click(ElsevierObjects.Roster_Evolve_Courselink,"Unique CourseId link");
	   Thread.sleep(low);
	   click(ElsevierObjects.Courses,"Courses");
	   b=false;	
	   Thread.sleep(low);
	   List<WebElement> s=driver.findElements(ElsevierObjects.educator_CoursePage_SubFolders);
		  for(WebElement subFolder:s){
	   if(waitForElementPresent(ElsevierObjects.educator_CoursePage_SubFolders, "Course folder contains sub folders.")){
		     Reporters.SuccessReport("Verifying subfolders.", "Verified Subfolders of Course Folder.</br>SubFolder is:"+subFolder.getText());
	    }else{
		     Reporters.failureReport("Verifying subfolders.", "Failed To Verify Subfolders of Course Folder.");
		}
		   }
	    EvolveCommonBussinessFunctions.instructorLogout(); 
		   
	    return flag;}
		catch(Exception e){return false;}
	}
  
  public boolean AdminVerification()throws Throwable{
  try
    {
	 boolean flag =true;
	 //Step 14
	 b=true;
	 click(ElsevierObjects.Course_PAR_report,"Course PAR Report link");
	 Thread.sleep(low);
	 type(ElsevierObjects.Course_Id_searchbox,CourId,"");
	 Thread.sleep(low);
	 click(ElsevierObjects.Course_Id_go,"Go button");
	 Thread.sleep(low);
	 b=false;
	 String username = getText(By.xpath(".//*[@id='usageReportContainer']//table//tbody//tr//span[contains(text(),'"+User+"')]"),"");
	 if(username.contains(User)){
		 Reporters.SuccessReport("Verify Username in the table","Student Username :" +User+ "</br> Username in table :"+username);
	 }else{
		 Reporters.failureReport("Verify Username in the table","Failed to verify username");
	 }
	 Thread.sleep(low);
	 String Accesscode = getText(By.xpath(".//*[@id='usageReportContainer']//table//tbody//tr//span[contains(text(),'"+AccessCode+"')]"),"");
	 if(Accesscode.contains(AccessCode)){
		 Reporters.SuccessReport("Verify Accesscode in the table","Actual Accesscode is :" +AccessCode+ "</br> Access code in table :"+Accesscode);
	 }else{
		 Reporters.failureReport("Verify Accesscode in the table","Failed to verify Accesscode");
	 }
	 Thread.sleep(low);
	 DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
       Date date = new Date();
	   System.out.println(dateFormat.format(date));
	 String date1=""+dateFormat.format(date);
	 
	 String Applicationdate = getText(By.xpath(".//*[@id='usageReportContainer']/table/tbody/tr[1]/td[3]"),"");
	 if(Applicationdate.contains(date1)){
		 Reporters.SuccessReport("Verify date in the table","Redeemption Date :"+Applicationdate+"</br> Current Date is :"+date1);
	 }else{
		 Reporters.failureReport("Verify date in the table","Failed to verify date");
	 }
	 Thread.sleep(low);
	 //Step 15
	 b=true;
	 click(ElsevierObjects.Admin_Evolve_lnk,"Evolve Admin link");
	 Thread.sleep(low);
	 click(ElsevierObjects.Edit_evolve_user,"View/Edit Evolve User Profile link");
	 Thread.sleep(low);
	 type(ElsevierObjects.Search_Username,User,"Enter Student Username");
	 Thread.sleep(low);
	 click(ElsevierObjects.Search_button,"Search button"); 
	 Thread.sleep(low);
	 click(ElsevierObjects.PAR_username,"Username of the student");
	 Thread.sleep(low);
	 click(ElsevierObjects.Par_btn,"PAR button");
	 Thread.sleep(low);
	 b=false;
	 if(isElementPresent(By.xpath("//strong[text()='Manage Protected Access Rights']"),"")){
		 Reporters.SuccessReport("Verify Manage Protected Access Rights page", "User is taken to Manage Protected Access Rights Page");
     }else{
		Reporters.failureReport("Verify Manage Protected Access Rights page", "User is unable to take Manage Protected Access Rights Page");
     }
	 Thread.sleep(low);
	 String Co_Id = getText(ElsevierObjects.Manage_access_courseId,"Get CourseID from the table");
	 if(Co_Id.contains(CourId)){
		  Reporters.SuccessReport("Verify CourseId in the table","CourseId's are compared Successfully </br> Actual CourseId :"+CourId+"</br> Expected CourseId :"+Co_Id);
	 }else{
		  Reporters.failureReport("Verify CourseId in the table","Failed to verify CourseId");
	 }
	 Thread.sleep(low);
	 String tabledate = getText(ElsevierObjects.Redemption_date,"Get date in the table");
	 if(tabledate.contains(date1)){
		 Reporters.SuccessReport("Verify date in the table","Redeemption Date :"+tabledate+"</br> Current Date is :"+date1);
	 }else{
		 Reporters.failureReport("Verify date in the table","Failed to verify date");
	 }
	 Thread.sleep(low);
	 //Step 16
	 b=true;
	 click(ElsevierObjects.EVOLVE_BUTTON,"Evolve Admin link");
	 Thread.sleep(low);
	 click(ElsevierObjects.Admin_Search_AccessCodeLnk,"Search Access Codes link");
	 Thread.sleep(low);
	 type(ElsevierObjects.Admin_Seach_Code,AccessCode,"Enter used access code from this test case.");
	 Thread.sleep(low);
	 click(ElsevierObjects.Admin_Search_Submit,"Search button");
	 Thread.sleep(low);
	 b=false;
	 String Redeem = getText(By.xpath("//span[text()='Redeemed']"),"Get Status of the Access Code");
	 if(Redeem!=null){
		 Reporters.SuccessReport("Verify Status of the Access Code","User Verified Status of Access Code and it is :"+Redeem);
	 }else{
		 Reporters.failureReport("Verify Status of the Access Code","Failed to verify status of Access code");
	 }
	 Thread.sleep(low);
	 EvolveCommonBussinessFunctions.adminLogout();
     return flag;}
     catch(Exception e){return false;}
  }
  
  //Step 17
  public boolean Reverification(String isbnNumber) throws Throwable {
  try{
	  boolean flag = true;
	  CreateNewUser(ElsevierObjects.STUDENT);
	  String Usernam = credentials[0];
	  String Pass = credentials[1];
	  EvolveCommonBussinessFunctions.instructorLogout();
	  if(click(ElsevierObjects.Student_Home_Login,"Click on login button")){
		  Reporters.SuccessReport("Click on login", "Launched Evolvecert URL Successfully and clicked on login");
	  }else{
		  Reporters.failureReport("Click on login", "Failed to Launch Evolvecert URL and click on login");
	  }
	  Thread.sleep(low);
	  b=true;
	  type(ElsevierObjects.common_login_userName,Usernam,"Enter username");
	  Thread.sleep(low);
	  type(ElsevierObjects.common_login_passWord,Pass,"Enter Password");
	  Thread.sleep(low);
	  b=false;
	  if(click(ElsevierObjects.submit,"Click on login button")){
	       Reporters.SuccessReport("Click on login", "User is Succcessfully logged into Evolvecert with the created student details");
	  }else{
		   Reporters.failureReport("Click on login", "Failed to login with the student details");
	  }
	  Thread.sleep(low); 
	  b=true;
	  click(ElsevierObjects.catalog,"Catalog");
	  Thread.sleep(low);
	  
	  // no longer applies with new design
	  /*click(ElsevierObjects.Online_courses,"Online courses Honeypot");
	  Thread.sleep(low);
	  click(ElsevierObjects.Enroll_into_Course,"Enroll into a Course");
	  Thread.sleep(low);*/
	  
	  type(ElsevierObjects.Enroll_courseid_searchbox,CourId,"");
	  Thread.sleep(low);
	  click(ElsevierObjects.Enroll_continue,"Continue button");
	  Thread.sleep(low);
	  b=false;
	  if(isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MyCartTitle,"Check Mycart title")){
		  Reporters.SuccessReport("Verify MyCart page title", "User is in MyCart Page.");
	 }else{
		  Reporters.failureReport("Verify MyCart page title", "User is unable to navigate MyCart page.");
	 }
	 Thread.sleep(low);
	 Title = getText(ElsevierObjects.Medical_title,"Get title of the product");
	 Reporters.SuccessReport("Verify the title of the product","Title of the product is verified and title is :"+Title);
	 Thread.sleep(low);
     sIsbn = getText(ElsevierObjects.Evolve_Isbn_Number,"Get the ISBN of the product");
     Reporters.SuccessReport("Verify the ISBN of the product","ISBN of the product is verified and ISBN is :"+sIsbn);	  
     Thread.sleep(low);
	 String ProductPrice = getText(ElsevierObjects.Evolve_price,"Get the price present there");
	
		 Reporters.SuccessReport("Verify the price of the product","Prices are verified Successfully and Price is :"+ProductPrice);
	
	 String Subtotal = getText(ElsevierObjects.Mycart_subtotal,"Get the total price present there");
	 if(ProductPrice.contains(Subtotal)){
		 Reporters.SuccessReport("Verify the price and totalprice","Prices are compared Successfully :<br> Product Price is : "+ProductPrice+"<br> Total Price is :"+Subtotal);
	 }else{
		 Reporters.failureReport("Verify the price and totalprice","Prices comparision is Failed :<br> Product Price is : "+ProductPrice+"<br> Total Price is :"+Subtotal);
	 }
	 
	 String fullname = firstname+" "+lastname;
	 Courtitle = "Medical Terminology Online for Mastering Healthcare Terminology";
	 String SelfCourse = getText(ElsevierObjects.CourseId_details,"");
	 if(SelfCourse.contains(CourId) && SelfCourse.contains(Courtitle) && SelfCourse.contains(fullname) && SelfCourse.contains(Instname)){
		 Reporters.SuccessReport("Verify Self Enrollment Course details","Successfully Self Enrollment Course details are verified and details are :</br>" +SelfCourse);
	 }else{
		 Reporters.failureReport("Verify Self Enrollment Course details","Failed to Verify Self Enrollment Course details");
	 }
	 
	  if(click(By.id("ac-radio-apply-"+isbnNumber+""), "")){
		    Reporters.SuccessReport("Select the radio button 'I have an access code:'", "'I have an access code:' radio button is selected");
	  }else{
			Reporters.failureReport("Select the radio button 'I have an access code:'", "'I have an access code:' radio button is not selected");
	  }
	  Thread.sleep(high);
	  
	  if(type(ElsevierObjects.ACCESS_CODE, AccessCode, "")){
			 Reporters.SuccessReport("Enter the access code", "Access code is entered. <br> Access Code : "+AccessCode);
	  }else{
			 Reporters.failureReport("Enter the access code", "Access code is not entered. ");
	  }
	  if(!click(By.id("ac-apply-"+isbnNumber), "click on Apply button")){
		  flag = false;
	  }
	  Thread.sleep(medium);
	  String Accesserr = getText(ElsevierObjects.Access_error,"");
	  if(Accesserr!=null){
		  Reporters.SuccessReport("Verify the Error for used Access code","Attempt to apply the same access code that was used and it displays error message as:"+Accesserr);
	  }else{
		  Reporters.failureReport("Verify the Error for used Access code","Access code was unused");
	  }
	  EvolveCommonBussinessFunctions.instructorLogout();
	  return flag;}
      catch(Exception e){return false;}
  }
  
  
  
  }
