package com.cigniti.automation.BusinessFunctions;

import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class Evolve_StudentLogin_9795 extends EvolveCommonBussinessFunctions{



	public static boolean evolve_StudentSearch() throws Throwable{

		boolean flag=true;
		try
		{
			driver.manage().deleteAllCookies();
			if(!launchUrl(configProps.getProperty("URL"))){
				flag = false;
			}
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			Thread.sleep(medium);
			if(!click(ElsevierObjects.home_student_lnkstudent,"i am student")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.txtproductsearch,readcolumns.twoColumns(0, 1, "T-9795", configProps.getProperty("TestData")).get("online_courseId"),"Search package")){
				flag=false;
			}
			if(!click(ElsevierObjects.gobutton,"Click go button")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Student_RequestProduct_btn,"Click the Request product now")){
				flag=false;
			}
			Thread.sleep(high);
			if(!clickOnOkButtonIfVisible()){
				flag=false;
			}

			Thread.sleep(medium);

			if(!waitForElementPresent(ElsevierObjects.Student_Page_MyCart,"My Cart")){
				flag=false;
			}
			if(!waitForElementPresent(ElsevierObjects.Student_MyCart_Price_txt,"Text Price")){
				flag=false;
			}
			if(!waitForElementPresent(ElsevierObjects.Student_MyCart_Price,"Price of Edition")){
				flag=false;
			}
			if(!click(ElsevierObjects.Student_MyCart_Checkout_btn,"click the checkout button")){
				flag=false;
			}
			Thread.sleep(medium);
		}
		catch(Exception e)

		{

			sgErrMsg=e.getMessage();

			return false;
		}
		return flag;
	}

	public static boolean evolve_StudentLogout() throws Throwable{

		boolean flag=true;
		try{
			if(!click(ElsevierObjects.myAccount, "Click MyAccount"))
				flag = false;
			
			if(!click(ElsevierObjects.Logout,"Click Logout")){
				flag=false;
			}
		}
			catch(Exception e){
				sgErrMsg=e.getMessage();return false;
			}
		return flag;
	}
	

	public static boolean evolve_StudentRegistration() throws Throwable{

		boolean flag=true;
		try
		{
			if(!type(ElsevierObjects.Student_Register_Firstname_txt,readcolumns.twoColumns(0, 1, "T-9795", configProps.getProperty("TestData")).get("student_firstname"),"enter student first name")){
				flag=false;
			}

			if(!type(ElsevierObjects.Student_Register_Lastname_txt,readcolumns.twoColumns(0, 1,"T-9795", configProps.getProperty("TestData")).get("student_Lastname"),"enter student last name")){
				flag=false;
			}
			Thread.sleep(medium);

			Random ra = new Random( System.currentTimeMillis() );
			String stdMail = readcolumns.twoColumns(0, 1, "T-9795", configProps.getProperty("TestData")).get("student_Email")+Integer.toString((1 + ra.nextInt(2)) * 10000 + ra.nextInt(10000))+"@evolveqa.info";

			//ReadingExcel.updateCellValue(4, 1, configProps.getProperty("TestData"), 7);
			if(!type(ElsevierObjects.Student_Register_Email_txt, stdMail ,"enter student email")){
				flag=false;
			}
			if(!type(ElsevierObjects.Student_Register_Confirmemail_txt, stdMail,"Reenter student email")){
				flag=false;
			}
			if(!type(ElsevierObjects.Student_Register_Pwd_txt,readcolumns.twoColumns(0, 1, "T-9795", configProps.getProperty("TestData")).get("student_pwd"),"Enter student password")){
				flag=false;
			}
			if(!type(ElsevierObjects.Student_Register_ConfirmPwd_txt,readcolumns.twoColumns(0, 1, "T-9795", configProps.getProperty("TestData")).get("student_pwd"),"Reenter student Password")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Student_Register_Chk,"Click check box")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.Student_Register_Street_txt,readcolumns.twoColumns(0, 1, "T-9795", configProps.getProperty("TestData")).get("student_StreetAdress"),"Enter student Street")){
				flag=false;
			}
			if(!type(ElsevierObjects.Student_Register_City_txt,readcolumns.twoColumns(0, 1, "T-9795", configProps.getProperty("TestData")).get("student_City"),"Enter student City")){
				flag=false;
			}
			if(!selectByValue(ElsevierObjects.Student_Register_State_Dropdwn,readcolumns.twoColumns(0, 1,"T-9795", configProps.getProperty("TestData")).get("student_State"), "Country name")){
				flag=false;
			}
			if(!type(ElsevierObjects.Student_Register_Zipcode_txt,readcolumns.twoColumns(0, 1, "T-9795", configProps.getProperty("TestData")).get("student_ZipCode"),"Enter student Zipcode")){
				flag=false;
			}
			if(!click(ElsevierObjects.Student_Register_Continue_btn,"Click Continue Button")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!switchToFrameByLocator(ElsevierObjects.Student_register_frame,"Switch to frame")){
				flag=false;
			}
			Thread.sleep(high);
			//waitForElementPresent(ElsevierObjects.Student_register_UseAdress_btn, "");
			if(!click(ElsevierObjects.Student_register_UseAdress_btn,"Click UsethisAdress Button")){
				flag=false;
			}
			Thread.sleep(medium);
		}

		catch(Exception e)

		{

			sgErrMsg=e.getMessage();

			return false;
		}
		return flag;
	}

	public static boolean evolve_StudentCreditCardDetails() throws Throwable{

		boolean flag=true;
		try
		{
			Thread.sleep(low);
			String cardType=readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("student_CardType");
			if(!selectByVisibleText(ElsevierObjects.Student_CardType_txt,cardType,"Student credit card")){
				flag=false;
			}
			String cardNumber=readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("student_CardNum");
			Thread.sleep(low);
			if(!type(ElsevierObjects.Student_CardNumber_txt,cardNumber,"Enter card number")){
				flag=false;
			}
			String cardCVV=readcolumns.twoColumns(0, 1,"Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("student_CardCvv");
			Thread.sleep(low);
			if(!type(ElsevierObjects.Student_Cardcvv_txt,cardCVV,"Enter card CVV number")){
				flag=false;
			}
			String cardName=readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("studentCardName");
			Thread.sleep(low);
			if(!type(ElsevierObjects.Student_Cardname_txt,cardName,"Enter card name")){
				flag=false;
			}
			if(!selectByVisibleText(ElsevierObjects.Student_CardExpMnth_txt,readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("CreditCardMonth"),"Credit card month expire date")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!selectByVisibleText(ElsevierObjects.Student_CardExpYr_txt,readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("CreditCardYear"),"Credit card expire year")){
				flag=false;
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.Student_Card_continue_btn,"Click Continue Button")){
				Reporters.SuccessReport("Input Credit Card details", "Credit Card details are successfully entered: <br> Card Type : "+cardType+"<br>Card Number : "+cardNumber+"<br>Card CVV : "+cardCVV+"<br>Card Name : "+cardName);
			}else{
				Reporters.failureReport("Input Credit Card details", "Credit Card details are failed to enter");
			}
			Thread.sleep(medium);
		}

		catch(Exception e)

		{

			sgErrMsg=e.getMessage();

			return false;
		}
		return flag;
	}

	public static boolean evolve_StudentReviewandSubmit() throws Throwable{

		boolean flag=true;
		try
		{
			if(!waitForElementPresent(ElsevierObjects.Student_Review_price,"Price text should be there")){
				flag=false;
			}

			if(!waitForElementPresent(ElsevierObjects.Student_Review_Totalprice,"Total price")){
				flag=false;
			}
			if(!click(ElsevierObjects.Student_accept_chk,"Click Check box")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Student_Review_Submit,"Click Submit button")){
				flag=false;
			}
			Thread.sleep(medium);
		}

		catch(Exception e)

		{

			sgErrMsg=e.getMessage();

			return false;
		}
		return flag;
	}




	public static boolean admin_Adoptionsearch_verifytext() throws Throwable{
		boolean flag=true;
		try
		{
			if(!click(ElsevierObjects.searchAR,"Adoption Requests")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!waitForElementPresent(ElsevierObjects.btndatesearch, "search button")){
				flag = false;
			}
			if(!click(ElsevierObjects.rbtndate, "date Radio button")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.Adoption_userId, readcolumns.twoColumns(0, 1, "T-9795", configProps.getProperty("TestData")).get("AdoptionUserId"), "Adoption search User Id")){
				flag = false;
			}
			if(!click(ElsevierObjects.btndatesearch, "search button")){
				flag = false;
			}
			Thread.sleep(high);
			if(!verifyText(ElsevierObjects.Admin_Adoption_verifytxt,"No adoptions found.","verify text NO adoption search found")){
				flag=false;
			}
		}
		catch(Exception e)

		{

			sgErrMsg=e.getMessage();

			return false;
		}
		return flag;
	}
}

