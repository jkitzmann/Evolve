package com.cigniti.automation.BusinessFunctions;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.openqa.selenium.NoAlertPresentException;






import org.openqa.selenium.support.ui.WebDriverWait;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class AdminMaintainProductsUpdateHistory_15465 extends EvolveCommonBussinessFunctions {
	
 public String techSpecs=readcolumns.twoColumnsBasedOnSheetName(0,1, "Tc-15465", configProps.getProperty("TestData")).get("TecnicalSpecsShortText");
 public String username=configProps.getProperty("AdminUser");
 public String env=readcolumns.twoColumnsBasedOnSheetName(0,1, "Tc-15465", configProps.getProperty("TestData")).get("env");
 public String notes=readcolumns.twoColumnsBasedOnSheetName(0,1, "Tc-15465", configProps.getProperty("TestData")).get("notes");
 public String sHeading=readcolumns.twoColumnsBasedOnSheetName(0,1, "Tc-15465", configProps.getProperty("TestData")).get("sheading");
 public String fHeading=readcolumns.twoColumnsBasedOnSheetName(0,1, "Tc-15465", configProps.getProperty("TestData")).get("fheading");
 public boolean verifyHistory()	throws Throwable{
		boolean flag=true;
		try{
			String bookFinder=getText(ElsevierObjects.maintainPdct_Bookfinder_lnk, "MaintainPdct Bookfinder link");
			if(waitForElementPresent(ElsevierObjects.maintainPdct_Bookfinder_lnk, "Book finder link is right side of the Save & publish button.")){
				Reporters.SuccessReport("Verifying BookFinder Link is link is located to the right of the 'Save & Publish To Production' button.", "Successfully Verified:"+bookFinder+" Link located to the right of the 'Save & Publish To Production' button");
			}
			else{
				Reporters.failureReport("Verifying BookFinder Link is link is located to the right of the 'Save & Publish To Production' button.", "Failed To Verify Book Finder Link Is located to the right of the 'Save & Publish To Production' button");
			}
			Thread.sleep(medium);
			String modified=getText(ElsevierObjects.maintainPdct_ModifiedInfo, "Maintain Product Modified information");
			if(waitForElementPresent(ElsevierObjects.maintainPdct_ModifiedInfo, "Modified by user information link.")){
				Reporters.SuccessReport("Verifying the last modified by information is where the existing Book Finder link was.", "Successfully Verified :"+modified+" link is existing where Book Finder was.");
			}
			else{
				Reporters.SuccessReport("Verifying the last modified by information is where the existing Book Finder link was.", "Failed To Verify:"+modified+" link is existing where Book Finder was.");
			}
			Thread.sleep(medium);
			String history=getText(ElsevierObjects.maintainPdct_History, "History");
			if(waitForElementPresent(ElsevierObjects.maintainPdct_History, "History link is present.")){
				Reporters.SuccessReport("Verifying there is a 'History' link under the last modified by information.", "Successfully Verified "+history+" link under the last modified by information.");
			}
			else{
				Reporters.failureReport("Verifying there is a 'History' link under the last modified by information.", "Failed To Verify "+history+" link under the last modified by information.");
			}
			Thread.sleep(medium);
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
		}
		return flag;
	}
		
		public boolean studentUpadateHistory()	throws Throwable{
			boolean flag=true;
		try{
			if(click(ElsevierObjects.maintainPdct_StudentTab, "Click on student tab.")){
				Reporters.SuccessReport("Clicking On Student Production tab.", "Successfully Clicked On Student Production Tab.");
			}
			else{
				Reporters.failureReport("Clicking On Student Production tab.", "Failed To Click On Student Production Tab.");
			}
			Thread.sleep(high);
			if(click(ElsevierObjects.studentTab_SaveAsWip, "Click on Save AS Wip ")){
				Reporters.SuccessReport("Clicking On Save As WIP Tab.", "Successfully Clicked On Save As WIP Tab.");
			}
			else{
				Reporters.failureReport("Clicking On Save As WIP Tab.", "Failed To Click On Save As WIP Tab.");
			}
			
			Thread.sleep(high);
			try{
				
				Alert();
					
				/*Robot r=new Robot();
				r.keyPress(KeyEvent.VK_E);*/
				
			}
			catch(NoAlertPresentException e){
				sgErrMsg=e.getMessage();
				System.out.println(e);	
			}
			Thread.sleep(high);
			if(!isElementPresent(ElsevierObjects.studentTab_StudentWIP_Tab, "Student WIP Tab present.")){
				flag=false;
			}
			Thread.sleep(medium);
			if(type(ElsevierObjects.StudentWIPTab_TechSpecsShort_txt,techSpecs,"Enter Text in TecnicalSpecsShort Text Box.")){
				Reporters.SuccessReport("Editing the text in the Tecnical Specs Short section.", "Successfully Edited The Text In Tecnical Specs Short section And Entered Automation Test Text.");
			}
			else{
				Reporters.failureReport("Editing the text in the Tecnical Specs Short section.", "Failed To Edit The Text In Tecnical Specs Short section And Failed To Enter Automation Test Text.");
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.StudentWIPTab_Save, "Click on Save Button")){
				Reporters.SuccessReport("Clicking On Submit Button.", "Successfully Clicked On Submit Button.");
			}
			else{
				Reporters.failureReport("Clicking On Submit Button.", "Failed To Click On Submit Button.");
			}
			Thread.sleep(medium);
			Calendar currentdate = Calendar.getInstance();
	        DateFormat formatter = new SimpleDateFormat("MM/dd/yy hh:mm a");
	        TimeZone obj = TimeZone.getTimeZone("CST");
	        formatter.setTimeZone(obj);
	        //System.out.println("Local:: " +currentdate.getTime());
	        Date date1 = new Date();
	        Calendar c = Calendar.getInstance();
	        c.setTime(date1);
	        c.add(Calendar.MINUTE,-1);
	        System.out.println("CST:: "+ formatter.format(currentdate.getTime()));
	        
	        String s = formatter.format(currentdate.getTime());
	        String s1=formatter.format(c.getTime().getTime());
			Thread.sleep(medium);
			if(click(ElsevierObjects.studentTab_SaveAsWip_History, "Click on History link.")){
				Reporters.SuccessReport("Clicking On History Link.", "Successfully Clicked On History Link.");
			}
			else{
				Reporters.failureReport("Clicking On History Link.", "Failed To Click On History Link.");
			}
			Thread.sleep(high);
			
			if(verifyText(ElsevierObjects.history_PopUp_heading,sHeading , "Verify the Heading in popuu.")){
				Reporters.SuccessReport("Verifying Heading In Student History Popup.", "Successfully Verified Heading:"+sHeading+" in Student History Popup.");
			}
			else{
				Reporters.failureReport("Verifying Heading In Student History Popup.", "Failed To Verify Heading:"+sHeading+" in Student History Popup.");
		
			}
		
			String dateAndTime=getText(ElsevierObjects.history_PopUp_DateAndTime,"Get Date And Time.").trim();
			System.out.println("dateAndTime:"+dateAndTime);
	        if((dateAndTime.contains(s))||(dateAndTime.contains(s1)))
	        {
	        	Reporters.SuccessReport("Verifying Date Format whether dispalying Current Date And Time Or Not.", "Successfully Verified Date Format.</br>The Actual Date And Time in Popup Is :"+dateAndTime+", The Current Date And Time:"+s);
	        }
	        else{
	        	 Reporters.failureReport("Verifying Date Format whether dispalying Current Date And Time Or Not.", "Failed To Verify Date And Time Format.</br>The Actual Date And Time in Popup Is :"+dateAndTime+", The Current Date And Time:"+s);
	        }
	        if(verifyText(ElsevierObjects.history_PopUp_User, username,"Verify user")){
				Reporters.SuccessReport("Should Show The Name of Admin User Logged, in Student Popup.","Name of the Admin user:"+username+" is Displayed In Popup.");
			}
	        else{
	        	 Reporters.failureReport("Should Show The Name of Admin User Logged,in Student Popup.", "Failed To Verify The Name OF The Admin User Logged In Is Displayed In Popup.");
	        }
			Thread.sleep(medium);
			if(verifyText(ElsevierObjects.history_PopUp_Env, env, "Verify Env text.")){
				Reporters.SuccessReport("Verifying The Name Of The Environment in Student History Popup.", "Sucessfully Verified Name Of The Environment:"+env+" in Student History Popup.");
			}
			else{
				Reporters.failureReport("Verifying The Name Of The Environment in Student History Popup.", "Failed To Verify Name Of The Environment in Student History Popup.");
			}
			
			
			if(verifyText(ElsevierObjects.history_PopUp_Notes,notes , "Verify Env text.")){
				Reporters.SuccessReport("Verifying The Notes in Student History Popup.", "Sucessfully Verified Notes:"+notes+" in Student History Popup.");
			}
			else{
				Reporters.failureReport("Verifying The Notes in Student History Popup.", "Failed To Verify Notes in Student History Popup.");
			}
			
			if(javaClick(ElsevierObjects.studentWIP_history_close,"Click on close button.")){
				Reporters.SuccessReport("Clicking On 'X' On Top Corner Of Popup.", "Successfully Clicked On 'X' On Top Corner In Popup.</br>Student History Popup Closes And User Is Still In S-WIP Tab.");
			}
			else{
				Reporters.failureReport("Clicking On 'X' On Top Corner Of Popup.", "Failed To Click On 'X' On Top Corner In Popup");
			}
			Thread.sleep(medium);
			if(type(ElsevierObjects.StudentWIPTab_TechSpecsShort_txt, "", "Enter null value")){
				Reporters.SuccessReport("Removing Text From Technical Specs Short field.", "Successfully Removed Text From Technical Specs Short field.");
			}
			else{
				Reporters.failureReport("Removing Text From Technical Specs Short field.", "Failed To Remove Text From Technical Specs Short field.");
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.StudentWIPTab_Save, "Click on Save Button")){
				Reporters.SuccessReport("Clicking On Save Button.", "Successfully Clicked On Save Button.</br>The Page Returned To its Normal state.");
			}
			else{
				Reporters.failureReport("Clicking On Save Button.", "Failed To Click On Save Button.");
			}
			Thread.sleep(veryhigh);
		}
		catch(Exception e1){
			sgErrMsg=e1.getMessage();
			System.out.println(e1.getMessage());
		}
		return flag;
	}
		public boolean facultyUpadateHistory()	throws Throwable{
			boolean flag=true;
			try{
				if(click(ElsevierObjects.facultyTab, "Click on faculty tab.")){
					Reporters.SuccessReport("Clicking On Faculty Production tab.", "Successfully Clicked On Faculty Production Tab.");
				}
				else{
					Reporters.failureReport("Clicking On Faculty Production tab.", "Failed To Click On Faculty Production Tab.");
				}
				Thread.sleep(high);
				if(click(ElsevierObjects.facultyTab_SaveAsWip, "Click on Save AS Wip ")){
					Reporters.SuccessReport("Clicking On Save As WIP Tab.", "Successfully Clicked On Save As WIP Tab.");
				}
				else{
					Reporters.failureReport("Clicking On Save As WIP Tab.", "Failed To Click On Save As WIP Tab.");
				}
				Thread.sleep(high);
				try{
					
					Alert();
					
					/*Robot r=new Robot();
					r.keyPress(KeyEvent.VK_E);*/
					
				}
				catch(NoAlertPresentException e){
					sgErrMsg=e.getMessage();
					System.out.println(e);	
				}
				Thread.sleep(high);
				if(!isElementPresent(ElsevierObjects.facultyTab_facultyWIP_Tab, "Faculty WIP Tab present.")){
					flag=false;
				}
				Thread.sleep(medium);
				if(type(ElsevierObjects.facultyWIPTab_TechSpecsShort_txt,techSpecs,"Enter Text in TecnicalSpecsShort Text Box.")){
					Reporters.SuccessReport("Editing the text in the Tecnical Specs Short section.", "Successfully Edited The Text In Tecnical Specs Short section And Entered Automation Test Text.");
				}
				else{
					Reporters.failureReport("Editing the text in the Tecnical Specs Short section.", "Failed To Edit The Text In Tecnical Specs Short section And Failed To Enter Automation Test Text.");
				}
				Thread.sleep(medium);
				if(click(ElsevierObjects.facultyWIPTab_Save, "Click on Save Button")){
					Reporters.SuccessReport("Clicking On Save Button.", "Successfully Clicked On Save Button.");
				}
				else{
					Reporters.failureReport("Clicking On Save Button.", "Failed To Click On Save Button.");
				}
				Thread.sleep(medium);
				Calendar currentdate = Calendar.getInstance();
		        DateFormat formatter = new SimpleDateFormat("MM/dd/yy hh:mm a");
		        TimeZone obj = TimeZone.getTimeZone("CST");
		        formatter.setTimeZone(obj);
		        //System.out.println("Local:: " +currentdate.getTime());
		        Date date1 = new Date();
		        Calendar c = Calendar.getInstance();
		        c.setTime(date1);
		        c.add(Calendar.MINUTE,-1);
		        System.out.println("CST:: "+ formatter.format(currentdate.getTime()));
		        
		        String s = formatter.format(currentdate.getTime());
		        String s1=formatter.format(c.getTime().getTime());
				
		        System.out.println("CST:: "+ formatter.format(currentdate.getTime()));
		        
				if(click(ElsevierObjects.facultyWIPTab_SaveAsWip_History, "Click on History link.")){
					Reporters.SuccessReport("Clicking On History Link.", "Successfully Clicked On History Link.");
				}
				else{
					Reporters.failureReport("Clicking On History Link.", "Failed To Click On History Link.");
				}
				Thread.sleep(high);
				
				if(verifyText(ElsevierObjects.history_PopUp_heading,fHeading , "Verify the Heading in popuu.")){
					Reporters.SuccessReport("Verifying Heading In Faculty History Popup.", "Successfully Verified Heading:"+fHeading+" in Faculty History Popup.");
				}
				else{
					Reporters.failureReport("Verifying Heading In Faculty History Popup.", "Failed To Verify Heading:"+fHeading+" in Faculty History Popup.");
			
				}

				String dateAndTime=getText(ElsevierObjects.history_PopUp_DateAndTime,"Get Date And Time.").trim();
				System.out.println("dateAndTime:"+dateAndTime);
		        if((dateAndTime.contains(s))||(dateAndTime.contains(s1)))
		        {
		        	
		        	Reporters.SuccessReport("Verifying Date Format whether dispalying Current Date And Time Or Not.", "Successfully Verified Date Format.</br>The Actual Date And Time in Popup Is :"+dateAndTime+", The Current Date And Time:"+s);
		        }
		        else{
		        	Reporters.failureReport("Verifying Date Format whether dispalying Current Date And Time Or Not.", "Failed To Verify Date And Time Format.</br>The Actual Date And Time in Popup Is :"+dateAndTime+", The Current Date And Time:"+s);
		        }
				if(verifyText(ElsevierObjects.history_PopUp_User, username,"History Popup username")){
					Reporters.SuccessReport("Should Show The Name of Admin User Logged, in Faculty Popup.","Name of the Admin user:"+username+" is Displayed In Popup.");
				}
		         else{
		        	 Reporters.failureReport("Should Show The Name of Admin User Logged,in Faculty Popup.", "Failed To Verify The Name OF The Admin User Logged In Is Displayed In Popup.");
		         }
				Thread.sleep(medium);
				if(verifyText(ElsevierObjects.history_PopUp_Env,"WIP" , "Env text.")){
					Reporters.SuccessReport("Verifying The Name Of The Environment in Faculty History Popup.", "Sucessfully Verified Name Of The Environment:"+env+" in Faculty History Popup.");
				}
				else{
					Reporters.failureReport("Verifying The Name Of The Environment in Faculty History Popup.", "Failed To Verify Name Of The Environment in Faculty History Popup.");
				}
				if(verifyText(ElsevierObjects.history_PopUp_Notes,notes , "History Notes")){
					Reporters.SuccessReport("Verifying The Notes in Faculty History Popup.", "Sucessfully Verified Notes:"+notes+" in Faculty History Popup.");
				}
				else{
					Reporters.failureReport("Verifying The Notes in Faculty History Popup.", "Failed To Verify Notes in Faculty History Popup.");
				}
				if(javaClick(ElsevierObjects.facultyPopup_close,"close button.")){
					Reporters.SuccessReport("Clicking On 'X' On Top Corner Of Popup.", "Successfully Clicked On 'X' On Top Corner In Popup.</br>Faculty History Popup Closes And User Is Still In F-WIP Tab.");
				}
				else{
					Reporters.failureReport("Clicking On 'X' On Top Corner Of Popup.", "Failed To Click On 'X' On Top Corner In Popup");
				}
				Thread.sleep(medium);
				if(type(ElsevierObjects.facultyWIPTab_TechSpecsShort_txt, "", "Enter null value")){
					Reporters.SuccessReport("Removing Text From Technical Specs Short field.", "Successfully Removed Text From Technical Specs Short field.");
				}
				else{
					Reporters.failureReport("Removing Text From Technical Specs Short field.", "Failed To Remove Text From Technical Specs Short field.");
				}
				Thread.sleep(medium);
				if(click(ElsevierObjects.facultyWIPTab_Save, "Click on Save Button")){
					Reporters.SuccessReport("Clicking On Save Button.", "Successfully Clicked On Save Button.</br>The Page Returned To its Normal state.");
				}
				else{
					Reporters.failureReport("Clicking On Save Button.", "Failed To Click On Save Button.");
				}
				Thread.sleep(veryhigh);
			}
			catch(Exception e){
				sgErrMsg=e.getMessage();
				System.out.println(e.getMessage());
				return false;
			}
			return flag;
		}
		 public static boolean maintainProductLink() throws Throwable{
			  boolean flag=true;
			  try{
			   if(!click(ElsevierObjects.admin_MaintainProduct_lnk,"click on maintain product link")){
			    flag=false;
			   }
			   Thread.sleep(medium);
			  String Isbn=readcolumns.twoColumns(0, 1,"Tc-15465",configProps.getProperty("TestData")).get("ISBN");

			   if(!type(ElsevierObjects.admin_MaintainProduct_Knotxt,Isbn,"Enter Kno number in product page")){
			    flag=false;
			   }
			   Thread.sleep(medium);
			   if(!click(ElsevierObjects.admin_MaintainProduct_Submit,"Click on search button")){
			    flag=false;
			   }
			   Thread.sleep(medium);
			   if(click(ElsevierObjects.MaintainPrdct_prdctSerachReslut_isbn,"Click on isbn num in product result page")){
			    Reporters.SuccessReport("Clicking On Maintain Product Link And Searching For The ISBN: "+Isbn, "Successfully Clicked On Maintain Product Page Link.</br>Successfully Searched For ISBN: "+Isbn);
			   }
			   else{
			    Reporters.failureReport("Clicking On Maintain Product Link And Searching For The ISBN: "+Isbn,"Failed To Click On Maintain Product Page Link.</br>Failed To Search For ISBN: "+Isbn);
			   }
			   Thread.sleep(medium);
			  }
			  catch(Exception e){
				  sgErrMsg=e.getMessage();
			   System.out.println(e.getMessage());
			   return false;
			  }
			  return flag;
			 }
}
