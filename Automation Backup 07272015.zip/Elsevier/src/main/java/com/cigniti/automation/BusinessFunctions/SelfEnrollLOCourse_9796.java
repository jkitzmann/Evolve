package com.cigniti.automation.BusinessFunctions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;


public class SelfEnrollLOCourse_9796 extends EvolveCommonBussinessFunctions{
		
	//Click on the Access Code Package link and verify	
	public static String ISBNPkg;
	public static boolean selfEnrollLO() throws Throwable{
		boolean flag = true;
		Thread.sleep(medium);
		driver.manage().deleteAllCookies();
		if(!launchUrl(configProps.getProperty("URL"))){
			flag = false;
		}
		driver.manage().deleteAllCookies();
		driver.navigate().refresh();
		Thread.sleep(medium);
		if(!click(ElsevierObjects.home_student_lnkstudent,"i am student")){
			 flag=false;
		}
		
		return flag;
	}
	
	public static boolean verifySearchNumber() throws Throwable{
		boolean flag = true;
		ISBNPkg="";
		ReadingExcel re =new ReadingExcel();
		ISBNPkg =re.columnDataByHeaderName("searchNumber", "TC-10410", configProps.getProperty("TestData"));
		
		if(ISBNPkg == ""){
			Thread.sleep(medium);
			flag = false;
		}
		
		return flag;
	}
	
	public static boolean verifySelfEnrollNavigate(String courseid, String isbn, String title) throws Throwable{
		boolean flag = true;
		
		if(!(driver.getPageSource()).contains(courseid)){
			Thread.sleep(medium);
			flag=false;
		}
		
		Thread.sleep(500);
		
		if(!(driver.getPageSource()).contains(isbn)){
			Thread.sleep(medium);
			flag=false;
		}
		

		//if(!verifyTextPresent(courseid)){
		//	System.out.println("courseid not found");
		//	Thread.sleep(medium);
		//	flag=false;
		//}
		
		//if(!verifyTextPresent(isbn)){
		//	System.out.println("isbn not found");
		//	Thread.sleep(medium);
		//	flag=false;
		//}
					
/*		if(!isElementPresent(ElsevierObjects.txtmycart,"")){
			Thread.sleep(medium);
			flag = false;
		}
		
		if(isElementPresent(ElsevierObjects.isbnText,"")){
			if(!(ElsevierObjects.isbnText.equals(isbn))){
				Thread.sleep(medium);
				flag = false;
			}
		} else {
			Thread.sleep(medium);
			flag = false;
		}
		
		if(!waitForTitlePresent(ElsevierObjects.enrollTitle)){
			if(!(ElsevierObjects.enrollTitle.equals(title))){
				Thread.sleep(medium);
				flag = false;
			}
		} else {
			Thread.sleep(medium);
			flag = false;
		}		*/
		return flag;
	}
	
	public static boolean verifyCheckout() throws Throwable{
		boolean flag=true;
		
		if(!click(ElsevierObjects.btnRedeem,"Click on My Cart checkout Button")){
			flag=false;
		}
		Thread.sleep(medium);

		return flag;
	}
	
	public static boolean verifyMyEvolveCourseId() throws Throwable{
		boolean flag=true;
		
		if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
			flag=false;
		}
		Thread.sleep(medium);
		
		if(!click(ElsevierObjects.Kno_refresh_lnk,"Click on refresh content list")){
			flag=false;
		}
		Thread.sleep(low);
		
		//educator_courseSearch_title, educator_CoursePage_Courselink
		if(!click(ElsevierObjects.enrollMyEvolveCourseLinkClick,"Click on COurse Title.")){
			flag=false;
		}
		Thread.sleep(80000);
		Thread.sleep(80000);
		
		return flag;
	}
	
	public static boolean verifyCoursePage() throws Throwable{
		boolean flag=true;
		
		//click on course content list in course page
		//educator_CoursePage_Courselink
		if(!click(ElsevierObjects.Courses, "Click on course link present in course details page.")){
			flag=false;
		}
		Thread.sleep(high);
		
		
		//check for subfolders //educator_CoursePage_SubFolders
		//if(!waitForElementPresent(ElsevierObjects.enrollMyEvolveCourseSubFolders, "Course folder contains sub folders.")){
		//			flag=false;
			//	}
			//	Thread.sleep(veryhigh);

				return flag;
	}
}
