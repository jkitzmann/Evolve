package com.cigniti.automation.Test;

import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.AccessCodePKGRedemption_10220;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.FileDelete;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class AccessCodePKGRedemption_10220_Script extends AccessCodePKGRedemption_10220{
	
	@Test
	public void accessCode_Redemption_10220() throws Throwable{
		try {
		
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			stepReport("Create and upload unassigned access codes.");
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			AccessCodePackageUnassignedAccessCodesUpload_Script_10213 acp=new AccessCodePackageUnassignedAccessCodesUpload_Script_10213();
			acp.accessCodePackageUnassignedAccessCodesUpload_10213();
			
			previousCase();
			
			stepReport("Create new student user.");
			if(CreateNewUser(ElsevierObjects.STUDENT))
			{
	     		Reporters.SuccessReport("Launching the URL And Creating New Student. ", "Successfully Launched URL.</br> Successfully Created New Educator: "+credentials[0]);
			}
			else
			{
				Reporters.failureReport("Launching the URL And Creating New Student. ", "Failed To Launch URL.</br> Failed To Create New Educator: "+credentials[0]);
			}
			//click(ElsevierObjects.evolve_Home_Student, "Clicked on Student");	
			//click(By.xpath(".//*[@id='page']//li[contains(@class,'first ')]/a"), "Click on the Catalog");
			click(ElsevierObjects.evolveCatlog_lnk, "Click on Catalog link.");
			stepReport("Verify error messaging for invalid codes.");
			redemptionInvalid();
			
			stepReport("Enter a valid access code.");
			redemptionValid();
			
			stepReport("Complete checkout.");
			evolve_StudentRegistration();
			if(instructorLogout())
			{
	     		Reporters.SuccessReport("Click on logout", "Successfully Logout from student user");
			}
			else
			{
				Reporters.failureReport("Click on logout", "Failed to Logout from student user");
			}
			FileDelete.deleteFile(downloadFilePath);
		
		} catch (Exception e) {
			System.out.println(e.getMessage());
			FileDelete.deleteFile(downloadFilePath);
		}
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
	
}
