package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.CreateFacultyUserfromSplashPage_9799;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class CreateFacultyUserfromFacultyPageScript_9801 extends EvolveCommonBussinessFunctions{
	@Test
	public void CreateFacultyUserfromFacultyPage_9801() throws Throwable{
		try{
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String user="educator";
			stepReport("Verify the login form");
			verifyLogin(user);
			String page="educatorpage";
			
			stepReport("Verify login form error messaging");
			createAnAccountWithEmptyFields(user,page);
			
			stepReport("Create new account");
			createAnAccountWithCorrectDetails(user,page);
			getAccountDetails();
			
			stepReport("Log out and back in");
			if(instructorLogout()){
				Reporters.SuccessReport("Faculty logout:", "Successfully logged out the Faculty aplication.");
			}
			else{
				Reporters.failureReport("Faculty logout:", "Failed to logout the Faculty application.");
			}
			userReLogin(user);
			//SwitchToBrowser("Chrome");

			stepReport("Verify email");
			if(emailLogin()){
				Reporters.SuccessReport("Evolve Email login:", "Successfully logged into User Email.");
			}
			else{
				Reporters.failureReport("Evolve Email Login:", "Failed to login into User Email.");
			}
			String Title=tc_9798.get("Title");
			CreateFacultyUserfromSplashPage_9799.emailBodyVerification(Title,user);
		}
		catch(Exception e){
			System.out.println(e);
		}
	}

	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
