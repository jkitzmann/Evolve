package com.cigniti.automation.BusinessFunctions;


import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Test.ReadFileExample;
import com.cigniti.automation.Utilities.ReadTextFile;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;


public class Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions extends EvolveCommonBussinessFunctions{
	public static final String CINICAL_MEDICAL_ASSISTING_ONLIN_E ="9780323287029";
	public static final String CINICAL_MEDICAL_ASSISTING_ONLIN_E_1 ="9780323287029";

public boolean createAccessCode(String isbNumber) throws Throwable {
		
		boolean flag =true;
	try{	
		if(!click(ElsevierObjects.EVOLVE_BUTTON, "Evolve Button")){
			flag = false;
		}
		if(!click(ElsevierObjects.maintainProd, "Maintain Products.")){
			flag =false;
		}
		if(!type(ElsevierObjects.searchTitle,isbNumber,"ISBN")){
			flag = false;
		}
		if(!click(ElsevierObjects.btnserchTitle,"Search")){
			flag =false;
		}
		
		if(!click(By.xpath("//a[text()='"+isbNumber+"']"), "ISBN Number")){
			flag =false;
		}
		Thread.sleep(medium);
		
		super.createAccessCode();
		
		if(!click(ElsevierObjects.DOWNLOAD_ACCESS_CODE, "Download Access Code")){
			flag =false;
		}
		Thread.sleep(low);
		if(!click(ElsevierObjects.DOWNLOAD_ACCESS_CODE_TXT, "Download Access Code Text.")){
			flag =false;
		}
		Thread.sleep(high);
		if(ElsevierObjects.adminBrowserType.equalsIgnoreCase("ie")){
			r = new Robot();
			r.keyPress(KeyEvent.VK_ALT);
			r.keyPress(KeyEvent.VK_S);
			r.keyRelease(KeyEvent.VK_S);
			r.keyRelease(KeyEvent.VK_ALT);
			Thread.sleep(low);

			//If browser type other than 'IE'. 
		}
		//If browser type is Firefox, 
		else  
			//if(configProps.getProperty("browserType").equalsIgnoreCase("firefox")){
			if(ElsevierObjects.adminBrowserType.equalsIgnoreCase("firefox")){
				r = new Robot();
				r.keyPress(KeyEvent.VK_DOWN);
				r.keyPress(KeyEvent.VK_TAB);
				r.keyPress(KeyEvent.VK_TAB);
				r.keyPress(KeyEvent.VK_TAB);
				Thread.sleep(low);
				r.keyPress(KeyEvent.VK_ENTER);
			}
	}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}
		return flag;
	}
	
	
	public static void verifyTwoButtons() throws Throwable{
		try{
		if(isElementPresent(ElsevierObjects.ENTER_INSTRUCTORS, "Instructors Course ID Button")){
			Reporters.SuccessReport("Verify Enter Instructor's Course ID Button", "Enter Instructor's Course ID button was displayed Success fully");
		}
		else{
			Reporters.failureReport("Verify Enter Instructor's Course ID Button", "Unable to dispaly Enter Instructor's Course ID Button ");
		}

		if(isElementPresent(ElsevierObjects.ENTER_AS_IND_BUTTON, "Enter as Independent Self-Study Button")){
			Reporters.SuccessReport("Verify Enter as Independent Self-Study Button", "Enter Enter as Independent Self-Study button was displayed Success fully");
		}
		else{
			Reporters.failureReport("Verify Enter as Independent Self-Study Button", "Unable to dispaly Enter as Independent Self-Study Button ");
		}
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			
		}
	}

	public void enterInstructorCourseId(String courseId) throws Throwable{
		try{
		if(click(ElsevierObjects.ENTER_INSTRUCTORS,"Enter Instructor's Course ID button")){
			Reporters.SuccessReport("Click on 'Enter Instructor's Course ID' button ", "Successfully clicked on the 'Enter Instructor's Course ID' button");
		}else{
			Reporters.failureReport("Click on 'Enter Instructor's Course ID' button ", "Failed to click on the 'Enter Instructor's Course ID' button");
		}
		
		Thread.sleep(medium);
		if(isElementPresent(ElsevierObjects.txtcourseID, "")){
			Reporters.SuccessReport("Verify Course ID required prompt is displayed.", "Course ID required prompt is displayed");
		}else{
			Reporters.failureReport("Verify Course ID required prompt is displayed.", "Course ID required prompt is not displayed");
		}

		if(click(ElsevierObjects.ENTER_LATER_BUTTON, "")){
			Thread.sleep(medium);
			if(isElementPresent(ElsevierObjects.evolveCatlog_lnk, "Evolve Catlog")){
				Reporters.SuccessReport("Click on 'Enter Later' button ", "Enter later button worked as expected. Successfully clicked on Enter Later button, and the modal has gone away and no action has occurred.");
			}else{
				Reporters.failureReport("Click on 'Enter Later' button ", "Enter later button not worked as expected. Failed to click on Enter Later button, and the modal is present.");
			}
		}
		Thread.sleep(medium);
		b=true;
		click(ElsevierObjects.ENTER_INSTRUCTORS,"Enter Instructor's Course ID button");
		b=false;
		Thread.sleep(medium);
		if(type(ElsevierObjects.txtcourseID, courseId, "Course ID")){
			Reporters.SuccessReport("Enter valid course ID that was created in step3 using the template.", "Valid Course ID Entered <br/> Course ID : "+courseId);
		}else{
			Reporters.failureReport("Enter valid course ID that was created in step3 using the template.", "Failed to enter Valid Course ID ");
		}
			
		if(click(ElsevierObjects.MODAL_CONTINUE_BUTTON, "MODAL CONTINUE BUTTON")){
			Reporters.SuccessReport("Verify Continue button works as expected and as soon as a valid course ID is entered the user should <br/>see a 'Thank You' modal show as shown in the mockup with OK button.", "Continue button worked as expected and as soon as a valid<br/> course ID is entered the user has seen a 'Thank You' modal with OK button.");
		}else{
			Reporters.failureReport("Verify Continue button works as expected and as soon as a valid course ID is entered the user should <br/>see a 'Thank You' modal show as shown in the mockup with OK button.", "Continue button not worked as expected and as soon as a valid<br/> course ID is entered the user has not seen a 'Thank You' modal with OK button.");
		}
		Thread.sleep(high);
		waitForVisibilityOfElement(ElsevierObjects.OK_MESSAGE, "Thank you Message");
		String tankyouMessage = getText(ElsevierObjects.OK_MESSAGE, "Thank you Message");
		if(tankyouMessage.contains("Thank you")){
			Reporters.SuccessReport("Verify Thank You Message", "Thank You message was success fully dispalyed on modal pop up");
		}else{
			Reporters.failureReport("Verify Thank You Message", "Thank You message was unable  to dispaly on modal pop up");
		}
		Thread.sleep(medium);
		driver.navigate().refresh();
	}
	catch(Exception e)
	{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		
	}
	}
	public void searchISBNNumber(String isBNumber) throws Throwable{
		boolean flag = true;
		String errorMessage ="";
		try{
			if(!click(ElsevierObjects.catalog, "catalog")){
				flag = false;
			}
			Thread.sleep(medium);
			if(type(ElsevierObjects.txtproductsearch, isBNumber, "ISBN")){
				Reporters.SuccessReport("Enter the ISBN into the search field", "Successfully entered the ISBN : "+isBNumber+" into the search box");
			}else{
				Reporters.failureReport("Enter the ISBN into the search field", "Failed to enter the ISBN : "+isBNumber+" into the search box");
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.gobutton, "GO Button")){
				flag = false;
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.btnaddtocart, "Add To Cart")){
				Reporters.SuccessReport("Add the Product to the cart", "The product is successfully added to the cart");
			}else{
				Reporters.failureReport("Add the Product to the cart", "The product is failed to add to the cart");
			}
			Thread.sleep(medium);


			String message = getText(By.xpath("//*[@id='"+isBNumber+"']/div[8]"), "Notification");
			if(message.contains("To review your order at any time")){
				
				Reporters.SuccessReport("Verify Notification Message", getText(By.xpath("//*[@id='"+isBNumber+"']/div[8]"),""));
			}else{
				Reporters.failureReport("Verify Notification Message", "Unable to display Message Reson"+errorMessage);
			}
			
		}catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			
		}
		
		
	}
	@Override
	public boolean adminLogin() throws Throwable {
		super.adminLogin();
		boolean flag = true;
		try{
		if(click(ElsevierObjects.MANAGE_ADMINISTRATORS, "Manage Administrators")){
			Reporters.SuccessReport("Click on Manage Administrators link", "Successfully clicked on Manage Administrators link");
		}else{
			Reporters.failureReport("Click on Manage Administrators link", "Failed to click on Manage Administrators link");
		}
		Thread.sleep(high);
		if(click(ElsevierObjects.ADMIN_USER_NAME_ROW, "Admin Username")){
			Reporters.SuccessReport("Click on the admin user", "Successfully clicked on the admin user ");
		}else{
			Reporters.failureReport("Click on the admin user", "Failed to click on the admin user ");
		}
		Thread.sleep(medium);
		

		if(click(ElsevierObjects.ADMIN_SAVE_BUTTON, "Save Button")){
			Reporters.SuccessReport("Make sure the user has 'Maintain PPM Data Settings' role and Click on save Button", "User has 'Maintain PPM Data Settings' role and successfully clicked on save button");
		}else{
			Reporters.failureReport("Make sure the user has 'Maintain PPM Data Settings' role and Click on save Button", "User has not selected the 'Maintain PPM Data Settings' role and failed to click on save button");
		}
		Thread.sleep(medium);
		String message = getText(ElsevierObjects.ADMIN_EDIT_MEASSAGE, "Edit Message");

		if(message.contains("Account updated successfully")){
			Reporters.SuccessReport("Verify Maintain PPM Data Settings Message", "Admin user is saved successfully");
		}
		else{
			Reporters.failureReport("Verify Maintain PPM Data Settings ", "Admin user is not saved successfully");
		}
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}
		return flag;
		
	}



	public boolean modifyPublicatonDate(String publicationDate,String publishingStatus) throws Throwable{
		boolean flag = true;
		String errorMessage ="";
		try{
			Thread.sleep(medium);
			if(type(ElsevierObjects.PUBLICATION_DATE,publicationDate, "publicationDate")){
				Reporters.SuccessReport("Enter the Publication date", "Successfully entered publication date : "+publicationDate);
			}else{
				Reporters.failureReport("Enter the Publication date", "Failed to enter publication date : "+publicationDate);
			}
			if(selectByValue(ElsevierObjects.PUBLICATION_STATUS, publishingStatus, "publishingStatus")){
				Reporters.SuccessReport("Enter the Publication Status ", "Successfully entered publication Status : "+publishingStatus);
			}else{
				Reporters.failureReport("Enter the Publication Status ", "Failed to enter publication Status : "+publishingStatus);
			}
			Thread.sleep(medium);
			if(click(By.name("btnEdit"), "")){
				Reporters.SuccessReport("Click on the Edit button", "Successfully clicked on the edit button");
			}else{
				Reporters.failureReport("Click on the Edit button", "Failed to click on the edit button");
			}
			Thread.sleep(veryhigh);
			Thread.sleep(veryhigh);

			String message = getText(ElsevierObjects.PRODUCT_RESOURCE_MESSAGE, "Product Resource Message.");
	
			System.out.println("Message===>>>"+message);
			
			if(message.contains("Product Resource is successfully updated")){
				Reporters.SuccessReport("Verify Product Resource Message", "Successfully Modified PublicationDate to future date : "+publicationDate+" <br/>and selected : "+publishingStatus+" from the PublishingStatus drop down. <br> Success Message is Printed : "+message);
			}else{
				Reporters.failureReport("Verify Product Resource Message", "Unable to Update the Product Resource Information Reason "+errorMessage);
			}
		}catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}
		return flag;
	}


	public boolean studnetCheckOut(boolean isStudentHaveAccessCode,String isbnNumber) throws Throwable{
		boolean flag = true;
		String errorMessage = "";
		try{
			System.out.println("");
			if(isStudentHaveAccessCode){
				if(click(By.id("ac-radio-apply-"+isbnNumber+""), "Radio button")){
					Reporters.SuccessReport("Select the radio button 'I have an access code:'", "'I have an access code:' radio button is selected");
				}else{
					Reporters.failureReport("Select the radio button 'I have an access code:'", "'I have an access code:' radio button is not selected");
				}
				Thread.sleep(high);
				//String AccessCode = ReadTextFile.readTextFile(EvolveCommonBussinessFunctions.ACCESS_CODE);
				String filepath=configProps.getProperty("DownLoadFile")+EvolveCommonBussinessFunctions.ACCESS_CODE+".txt";
				 ArrayList<String> columndata = (ArrayList<String>) ReadFileExample.readTxt(filepath);
				String AccessCode=columndata.get(0);
				
				if(type(ElsevierObjects.ACCESS_CODE, AccessCode, "AccessCode")){
					Reporters.SuccessReport("Enter the access code", "Access code is entered. <br> Access Code : "+AccessCode);
				}else{
					Reporters.failureReport("Enter the access code", "Access code is not entered. ");
				}
				if(!click(By.id("ac-apply-"+isbnNumber), "ac apply")){
					flag = false;
				}
				Thread.sleep(high);
				String message = getText(By.xpath("//*[@id='"+isbnNumber+"']/div[@class='notification_box rounded']/span"), "");
				String message2 = getText(By.xpath("//*[@id='"+isbnNumber+"']/div[@class='notification_box rounded']"), "");
				if(message.contains("not yet")){
					Reporters.SuccessReport("Verify  Notification Message ", message);
					//Reporters.SuccessReport("Verify  Notification Message ", message2);
				}else{
					Reporters.failureReport("Verify  Notification Message ", "Unable to display the nofification Message");
				}

				Thread.sleep(medium);
				String totalAmount = getText(ElsevierObjects.SUB_TOTAL, "Sub Total");
				if(totalAmount.contains("$0.00")){
					Reporters.SuccessReport("Verify Total price", "Price is verified successfully. The Total Price is 0");
				}

				else{
					Reporters.failureReport("Verify Total price", "The Total Price is Not Zero "+ totalAmount);
				}
				b=true;
				if(!click(ElsevierObjects.btnRedeem, "Redeem Checkout Button")){
					flag = false;
				}
				
				Thread.sleep(medium);

				if(!click(ElsevierObjects.Student_Shipping_Chk, "'I'm not affiliated with an institution")){
					flag = false;
				}
				Thread.sleep(high);
				click(ElsevierObjects.btnprofilesubmit, "Hit Continue");
				b=false;

				Thread.sleep(high);
				if(!click(ElsevierObjects.REGISTERED_USER_AGGREMENT, "Registered User Agreement.")){
					flag = false;
				}
				Thread.sleep(medium);
				if(!click(ElsevierObjects.btnsubmit, "Submit Button")){
					flag = false;
				}
				Thread.sleep(veryhigh);
				String messag2 = getText(By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class,'notification_box rounded')]/span"), "");
				String message3 = getText(By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class,'notification_box rounded')]"), "");
				if(messag2.contains("not yet")){
					Reporters.SuccessReport("Verify  Notification Message in Confirmation Page", messag2);
					Reporters.SuccessReport("Verify  Notification Message in Confirmation Page", message3);
				}else{
					Reporters.failureReport("Verify  Notification Message ", "Unable to display the nofification Message");
				}
			}
			else{
				if(click(ElsevierObjects.btnRedeem, "Redeem Checkout button")){
					Reporters.SuccessReport("Click on Redeem and Checkout", "Successfully clicked on the Redeem and Checkout");
				}else{
					Reporters.failureReport("Click on Redeem and Checkout", "Failed to click on the Redeem and Checkout");
				}
				Thread.sleep(high);
				
				if(isStudentHaveAccessCode){
					if(!click(ElsevierObjects.REGISTERED_USER_AGGREMENT, "Registered User Agreement.")){
						flag = false;
					}
				}
				Thread.sleep(medium);
				if(!click(ElsevierObjects.Student_Shipping_Chk, "Shipping Check Box")){
					flag = false;
				}

				Thread.sleep(high);
				if(!type(ElsevierObjects.STREET_ADDRESS, "123 Street", "Street")){
					flag = false;
				}

				if(!type(ElsevierObjects.CITY, "Clayton", "City")){
					flag = false;
				}
				if(!selectByValue(ElsevierObjects.STATE, "MO", "State")){
					flag = false;
				}

				if(!type(ElsevierObjects.BILLING_PIN_CODE, "63105", "PIN code")){
					flag = false;
				}

				if(click(ElsevierObjects.btnprofilesubmit, "Submit Button.")){
					Reporters.SuccessReport("Enter Student Shipping address", "Shipping address entered Successfully : <br/> 1851 MCKELVEY HILL DR <br/>Maryland heights<br/>Mo, 63043");
				}else{
					Reporters.failureReport("Enter Student Shipping address", "Failed to enter Shipping address");
				}
				Thread.sleep(veryhigh);
				Thread.sleep(veryhigh);
				if(!switchToFrameByLocator(ElsevierObjects.Student_register_frame, "Switch to frame")){
					flag=false;
				}
				if(!click(ElsevierObjects.Student_register_UseAdress_btn,"Click on use this adress button")){
					flag=false;
				}
				Thread.sleep(high);
				String getTitle = getTitle();
				if(!getTitle.contains("Check Out")){
					flag = false;
				}
			}
		}catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}
		return flag;
	}

	public void  enterCreditCardData(String cardType,String cardNumber,String cvvNumber,String nameOnCard,String expMonth,String expYear,String isbNumber) throws Throwable{
		boolean flag = true;
		String errorMessage ="";
		try {
			if(!selectByVisibleText(ElsevierObjects.lstcardtype, cardType,"Card Type")){
				flag = false;
			}
			if(!type(ElsevierObjects.Student_CardNumber_txt, cardNumber, "Card Number")){
				flag = false;
			}
			if(!type(ElsevierObjects.Student_Cardcvv_txt, cvvNumber, "CVV")){
				flag = false;
			}
			if(!type(ElsevierObjects.Student_Cardname_txt, nameOnCard, "Card Name")){
				flag = false;
			}
			if(!selectByValue(ElsevierObjects.Student_CardExpMnth_txt, expMonth, "Month")){
				flag = false;
			}

			if(!selectByVisibleText(ElsevierObjects.Student_CardExpYr_txt, expYear, "Year")){
				flag = false;
			}

			if(click(ElsevierObjects.Student_Card_continue_btn, "")){
				Reporters.SuccessReport("Enter Credit Card Information", "Credit card details are successfully entered: <br/> Card Type : "+cardType+"<br> Card Number : "+cardNumber+"<br/> CVV Number : "+cvvNumber+"<br/> Name on the Card : "+nameOnCard+"<br/> Exp. Month : "+expMonth+"<br/> Exp. year : "+expYear);
			}else{
				Reporters.failureReport("Enter Credit Card Information", "Credit card details are not entered");
			}
			Thread.sleep(high);
			String message = getText(By.xpath("//*[@id='"+isbNumber+"']/div[8]"), "Message");
			if(!message.contains("To review your order at any time")){
				flag = false;
			}

		}catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			
		}
		finally{
			if(flag){
				Reporters.SuccessReport("Verify Message in Review and Submit Page", getText(By.xpath("//*[@id='"+isbNumber+"']/div[8]"), "Error Message"));
			}else{
				Reporters.failureReport("Verify Message in Review and Submit Page", "Unable to verfiy Message Reason"+errorMessage);
			}
		}
	}

	public void acceptAndContinue() throws Throwable{
		boolean flag = true;
		String errorMessage ="";
		try{
			if(!click(ElsevierObjects.Student_accept_chk, "accepted checkbox")){
				flag = false;
			}
			Thread.sleep(high);
			if(click(ElsevierObjects.Student_Review_Submit, "Review Submit Button")){
				Reporters.SuccessReport("Click on Submit button", "Successfully clicked on the Submit button");
			}else{
				Reporters.failureReport("Click on Submit button", "Failed to click on the Submit button");
			}
			Thread.sleep(high);
			String message = getText(By.xpath("//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[1]/ul/li[2]/div[7]/div"), "");
			if(!message.contains("To review your order at any time")){
				flag = false;
			}
		}catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			
		}

		if(flag){
			Reporters.SuccessReport("Verify Message in Confirmation Page", getText(By.xpath("//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[1]/ul/li[2]/div[7]/div"), ""));
		}else{
			Reporters.failureReport("Verify Message in Confirmation Page", "Unable to verfiy Message Reason"+errorMessage);
		}

	}
	public void enterAsIndepentSelfStudy() throws Throwable{

		try{
			if(!click(ElsevierObjects.ENTER_AS_IND_BUTTON, "Enter As Independent Button")){
				flag = false;
			}
			Thread.sleep(medium);
			String modalText = getText(ElsevierObjects.MODAL_HEADER, "Modal Dialogue");
			if(modalText.contains("Confirm Independent Self-Study")){
				Reporters.SuccessReport("Verify Modal Header", "Modal Header is Successfully dispalys with message" +modalText);
			}else{
				Reporters.failureReport("Verify Modal Header", "Unable to view the modal header message");
			}
	
			String conformMessage = getText(ElsevierObjects.MODAL_CONFORMATION, "Modal Dialogue Confirmation Message.");
			if(conformMessage.contains("")){
				Reporters.SuccessReport("Verify Confirm Message", "Confirm Message is Successfully displays with message" +modalText);
			}else{
				Reporters.SuccessReport("Verify Confirm Message", "Confirm Message is Successfully displays with message" +modalText);
			}
	
			String checkBoxMessage = getText(By.xpath("//*[@id='modalSelfStudy']/form/p[1]/label"), "Check Box Message");
			if(checkBoxMessage.contains(" I want to use this product")){
				Reporters.SuccessReport("Verify Message", " Message is Successfully displays with message" +modalText);
			}else{
				Reporters.SuccessReport("Verify  Message", " Message is Successfully displays with message" +modalText);
			}
	
			if(!click(ElsevierObjects.MODAL_CANCEL_BUTTON, "Modal dialogue Cancel Button")){
				flag = false;
			}
	
			Thread.sleep(medium);
	
			if(!click(ElsevierObjects.ENTER_INSTRUCTORS, "Enter As Instructor Button")){
				flag = false;
			}
			Thread.sleep(medium);
	
			/*if(!click(ElsevierObjects.MODAL_CONFORM_BUTTON, "")){
				flag =false;
			}*/
			if(!click(ElsevierObjects.ENTER_LATER, "Enter Later Button")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.ENTER_AS_IND_BUTTON, "Enter As Independent")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.MODAL_CHECK_BOX, "Modal dialogue Check box")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.MODAL_CONFORM_BUTTON, "Modal Dialogue Confirm Button")){
				flag =false;
			}
			Thread.sleep(medium);
			String courseId = getText(ElsevierObjects.ONLIE_COURSE_ID, "Course ID");
			if(!courseId.equalsIgnoreCase("")){
				Reporters.SuccessReport("Verify Course Id", " CourseId is Successfully dispalys with message" +courseId);
			}else{
				Reporters.SuccessReport("Verify  Course Id", " CourseId is not dispalys");
			}
	
			Thread.sleep(medium);
	
			if(click(ElsevierObjects.ONLINE_COURSE_LINK, "Online Course Link")){
				Thread.sleep(medium);
				if(isElementPresent(ElsevierObjects.COURSE_TITLE, "Course Title.")){
					Reporters.SuccessReport("Verify User navigation", "User Successfully navigates to Catalog Page");
				}else{
					Reporters.SuccessReport("Verify User navigation", "User unable to navigates to Catalog Page");
				}
			}
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			
		}
	}
	public static void editResource(String clincalNumber) throws Throwable{
		boolean flag = true;
		String errorMessage = "";
		try{
			if(click(ElsevierObjects.EVOLVE_BUTTON, "Evolve Button")){
				Reporters.SuccessReport("Click on Evolve Admin", "Successfully Clicked on Evolve Admin");
			}else{
				Reporters.SuccessReport("Click on Evolve Admin", "Failed to Click on Evolve Admin");
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.BASE_PRDORDUCT_RERPORTS, "")){
				Reporters.SuccessReport("Click on Base Product Resource under 'ONIX PPM Load Data Manager'", "Successfully Clicked on Base Product Resource under 'ONIX PPM Load Data Manager'");
			}else{
				Reporters.SuccessReport("Click on Base Product Resource under 'ONIX PPM Load Data Manager'", "Failed to Click on Base Product Resource under 'ONIX PPM Load Data Manager'");
			}
			Thread.sleep(medium);
			if(type(ElsevierObjects.SELECT_IBN_TEXT_BOX, clincalNumber, "ISBN")){
				Reporters.SuccessReport("Select ISBN field enter "+clincalNumber, "Successfully selected isbn text box and entered : " +clincalNumber);
			}else{
				Reporters.SuccessReport("Select ISBN field enter "+clincalNumber, "Failed to selected isbn text box and entered : " +clincalNumber);
			}
			Thread.sleep(medium);
			if(selectByValue(ElsevierObjects.PROCESS_MENu, "3","Edit Resources")){
				Reporters.SuccessReport("Select Edit Resource from the drop down and Hit Go.", "Successfully selected Edit Resource from the drop down and clicked on Go button");
			}else{
				Reporters.failureReport("Select Edit Resource from the drop down and Hit Go.", "Failed to select Edit Resource from the drop down and failed to click on Go button");
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.VIEW_PRODUCT, "View Product")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!isElementPresent(By.xpath("//*[@id='editdatatable']/table/tbody//label[text()='"+clincalNumber+"']"), "Product "+clincalNumber, driver.getCurrentUrl())){
				flag  = false;
			}

		}catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			
		}
		finally{
			if(flag){
				Reporters.SuccessReport("Verify Resource information  ", "Resource information was  displayed successfully ");
			}else{
				Reporters.failureReport("Verify Resource information  ", "Unable to Get the Resource Information for this ISBN Number "+clincalNumber);
			}
		}
	}

	public void verifyOnlineCourseButtons() throws Throwable{

		try{
		if(isElementPresent(ElsevierObjects.ENTER_AS_IND_BUTTON, "Enter As Independent")){
			Reporters.SuccessReport("Verify Enter as Independent Self-Study Button", "Success Fully Finds the Enter as Independent Self-Study");
		}else{
			Reporters.failureReport("Verify Enter as Independent Self-Study Button", "unable to Find the Enter as Independent Self-Study");
		}

		if(isElementPresent(ElsevierObjects.ENTER_INSTRUCTORS, "Enter As Instructor Button")){
			Reporters.SuccessReport("Verify Enter Instructor's Course ID Button" , "Success Fully Finds the Enter Instructor's Course ID");
		}else{
			Reporters.failureReport("Verify Enter Instructor's Course ID Button", "unable to Find the Enter Instructor's Course ID");
		}
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			
		}
	}

	public void enterAsIndependentSelfStudy() throws Throwable{
	try{	
		if(click(ElsevierObjects.ENTER_AS_IND_BUTTON, "Enter as Independent Self-Study button")){
			Reporters.SuccessReport("Click on 'Enter as Independent Self-Study' button for the title", "Successfully Clicked on the 'Enter as Independent Self-Study' button for the title");
		}else{
			Reporters.failureReport("Click on 'Enter as Independent Self-Study' button for the title", "Failed to Click on the 'Enter as Independent Self-Study' button for the title");
		}
		
		Thread.sleep(medium);
		if(isElementPresent(ElsevierObjects.COURSE_CONFORM_BOX, "Modal Dialogue")){
			Reporters.SuccessReport("Verify the user is presented with Confirmation modal popup: with Confirm and Cancel buttons", "The user is successfully presented with Confirmation modal popup: with Confirm and Cancel buttons");
		}else{
			Reporters.failureReport("Verify the user is presented with Confirmation modal popup: with Confirm and Cancel buttons", "The user is not presented with Confirmation modal popup: with Confirm and Cancel buttons");
		}
		Thread.sleep(medium);
		if(isElementPresent(ElsevierObjects.COURSE_CONFORM_BOX, "Modal Dialogue")){
			Reporters.SuccessReport("Verify Dailog box", "Successfully Opens the Dialog box");
		}else{
			Reporters.failureReport("Verify Dailog box", "Unable to Open the Dialog box");
		}
		if(getText(ElsevierObjects.MODAL_HEADER, "MODAL_HEADER").contains("Confirm ")){
			Reporters.SuccessReport("Header: Confirm Independent Self-Study", "Modal header contains the "+getText(ElsevierObjects.MODAL_HEADER, "MODAL_HEADER"));
		}else{
			Reporters.failureReport("Header: Confirm Independent Self-Study", "Modal header contains the "+getText(ElsevierObjects.MODAL_HEADER, "MODAL_HEADER"));
		}

		if(getText(ElsevierObjects.MODAL_CONFORMATION, "MODAL_CONFORMATION").contains("Independent self-study is not facilitated")){
			Reporters.SuccessReport("Verify the Confirmation modal Text should read as below", "Modal Text contains the <br/>"+getText(ElsevierObjects.MODAL_CONFORMATION, "MODAL_CONFORMATION"));
		}else{
			Reporters.failureReport("Verify the Confirmation modal Text should read as below", "Modal header contains the <br>"+getText(ElsevierObjects.MODAL_CONFORMATION, "MODAL_CONFORMATION"));
		}

		if(getText(ElsevierObjects.CHECK_BOX_MESSAGE, "CHECK_BOX_MESSAGE").contains("Yes, I want to use this product")){
			Reporters.SuccessReport("verify Confirmation check box  Text", "Check Box text contains the <br/>"+getText(ElsevierObjects.CHECK_BOX_MESSAGE, "CHECK_BOX_MESSAGE"));
		}else{
			Reporters.failureReport("verify Confirmation check box  Text", "Check Box text contains the <br/>"+getText(ElsevierObjects.CHECK_BOX_MESSAGE, "CHECK_BOX_MESSAGE"));
		}

		
		//click(ElsevierObjects.ENTER_INSTRUCTORS, "");
		Thread.sleep(medium);
		if(click(ElsevierObjects.MODAL_CHECK_BOX, "MODAL_CHECK_BOX")){
			Reporters.SuccessReport("Select the Check box 'Yes, I want to use this product independently for self-study'", "Successfully clicked on the check box "+getText(ElsevierObjects.MODAL_CONFORMATION, ""));
		}else{
			Reporters.failureReport("Select the Check box 'Yes, I want to use this product independently for self-study'", "Failed to click on the check box "+getText(ElsevierObjects.MODAL_CONFORMATION, ""));
		}
		
		Thread.sleep(medium);
		if(click(By.xpath(".//*[@id='modalSelfStudy']/form/p[2]/button[2]"), "")){
			Reporters.SuccessReport("Validate Cancel Button", "Successfully clicked on the Cancel in the corner of the modal, and the modal has gone away and no action occurred.");
		}else{
			Reporters.failureReport("Validate Cancel Button", "Failed to click on the Cancel in the corner of the modal, and the modal is present.");
		}
		
		if(click(ElsevierObjects.ENTER_AS_IND_BUTTON, "Enter as Independent Self-Study button")){
			Reporters.SuccessReport("Click on 'Enter as Independent Self-Study' button for the title", "Successfully Clicked on the 'Enter as Independent Self-Study' button for the title");
		}else{
			Reporters.failureReport("Click on 'Enter as Independent Self-Study' button for the title", "Failed to Click on the 'Enter as Independent Self-Study' button for the title");
		}
		
		Thread.sleep(medium);
		if(isElementPresent(ElsevierObjects.COURSE_CONFORM_BOX, "COURSE_CONFORM_BOX")){
			Reporters.SuccessReport("Verify the user is presented with Confirmation modal popup: with Confirm and Cancel buttons", "The user is successfully presented with Confirmation modal popup: with Confirm and Cancel buttons");
		}else{
			Reporters.failureReport("Verify the user is presented with Confirmation modal popup: with Confirm and Cancel buttons", "The user is not presented with Confirmation modal popup: with Confirm and Cancel buttons");
		}
		Thread.sleep(medium);
		if(isElementPresent(ElsevierObjects.COURSE_CONFORM_BOX, "COURSE_CONFORM_BOX")){
			Reporters.SuccessReport("Verify Dailog box", "Success Fully Opens the Dialog box");
		}else{
			Reporters.failureReport("Verify Dailog box", "Unable to Open the Dialog box");
		}
		if(getText(ElsevierObjects.MODAL_HEADER, "MODAL_HEADER").contains("Confirm ")){
			Reporters.SuccessReport("Header: Confirm Independent Self-Study", "Modal header contains the "+getText(ElsevierObjects.MODAL_HEADER, ""));
		}else{
			Reporters.failureReport("Header: Confirm Independent Self-Study", "Modal header contains the "+getText(ElsevierObjects.MODAL_HEADER, ""));
		}

		if(getText(ElsevierObjects.MODAL_CONFORMATION, "MODAL_CONFORMATION").contains("Independent self-study is not facilitated")){
			Reporters.SuccessReport("Verify the Confirmation modal Text should read as below", "Modal Text contains the <br/>"+getText(ElsevierObjects.MODAL_CONFORMATION, ""));
		}else{
			Reporters.failureReport("Verify the Confirmation modal Text should read as below", "Modal header contains the <br>"+getText(ElsevierObjects.MODAL_CONFORMATION, ""));
		}

		if(getText(ElsevierObjects.CHECK_BOX_MESSAGE, "CHECK_BOX_MESSAGE").contains("Yes, I want to use this product")){
			Reporters.SuccessReport("verify Confirmation check box  Text", "Check Box text contains the <br/>"+getText(ElsevierObjects.CHECK_BOX_MESSAGE, ""));
		}else{
			Reporters.failureReport("verify Confirmation check box  Text", "Check Box text contains the <br/>"+getText(ElsevierObjects.CHECK_BOX_MESSAGE, ""));
		}

		
		//click(ElsevierObjects.ENTER_INSTRUCTORS, "");
		Thread.sleep(medium);
		if(click(ElsevierObjects.MODAL_CHECK_BOX, "MODAL_CHECK_BOX")){
			Reporters.SuccessReport("Select the Check box 'Yes, I want to use this product independently for self-study'", "Successfully clicked on the check box "+getText(ElsevierObjects.MODAL_CONFORMATION, ""));
		}else{
			Reporters.failureReport("Select the Check box 'Yes, I want to use this product independently for self-study'", "Failed to click on the check box "+getText(ElsevierObjects.MODAL_CONFORMATION, ""));
		}
		Thread.sleep(medium);
		if(click(ElsevierObjects.MODAL_CONFORM_BUTTON, "MODAL_CONFORM_BUTTON")){
			Reporters.SuccessReport("Click on the confirm button", "Successfully clicked on Confirm button");
		}else{
			Reporters.failureReport("Click on the confirm button", "Failed to click on Confirm button");
		}
		Thread.sleep(high);
		String courseid=getText(By.xpath(".//*[@id='set']/li/div/div/span[2]"), "Course ID");
		if(courseid!=null){
			Reporters.SuccessReport("Verify course id is present", "Course ID is present : "+courseid);
		}else{
			Reporters.failureReport("Verify course id is present", "Course ID is not present : "+courseid);
		}
		click(By.xpath("//*[@id='set']/li/div/div/a"), "Course ID Link");
			
		
		
		Thread.sleep(medium);
		/*if(isElementPresent(By.xpath("//*[@id='course-sidebar']/ul[2]/li/ul/li[2]/a"), "")){
			Reporters.SuccessReport("Verify Sub Folders", "User was Able to Acess the Sub folders ");
		}else{
			Reporters.failureReport("Veify Sub Floders", "User was un able to Acess the Sub folders");
		}*/
	}
	catch(Exception e)
	{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		
	}
	}

	public void verifySubFloders() throws Throwable{
	try{	
		click(ElsevierObjects.COURSE_LINK_AFTER_ENTER, "COURSE_LINK_AFTER_ENTER");
		Thread.sleep(medium);
		click(ElsevierObjects.COURSE_CONTENT, "COURSE_CONTENT");
		Thread.sleep(medium);
		if(isElementPresent(ElsevierObjects.COURSR_CONTENT_LINK, "COURSR_CONTENT_LINK")){
			Reporters.SuccessReport("Veify Sub Floders", "User was Able to Acess the Sub folders ");
		}
		else{
			Reporters.failureReport("Veify Sub Floders", "User was un able to Acess the Sub folders");
		}
	}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			
		}
	}

	public void verifyInstructorCouseidButton() throws Throwable{
	try{
		isElementPresent(ElsevierObjects.ENTER_INSTRUCTOR_COURSE_ID_BUTTON, "Enter Instructor's Course ID ");
	}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			
		}
	}

	public void verifyEnterLaterButton() throws Throwable{
		try{
		if(click(ElsevierObjects.ENTER_INSTRUCTOR_COURSE_ID_BUTTON, "ENTER_INSTRUCTOR_COURSE_ID_BUTTON")){
			Reporters.SuccessReport("Click on 'Enter Instructor's Course ID' button ", "Successfully clicked on the 'Enter Instructor's Course ID' button");
		}else{
			Reporters.failureReport("Click on 'Enter Instructor's Course ID' button ", "Failed to click on the 'Enter Instructor's Course ID' button");
		}
		Thread.sleep(high);
		if(isElementPresent(ElsevierObjects.txtcourseID, "Course Id")){
			Reporters.SuccessReport("Verfiy Course Id", "Course ID required prompt is displayed ");
		}else{
			Reporters.failureReport("Verfiy Course Id", "Course ID required prompt is not displayed ");
		}

		click(ElsevierObjects.ENTER_LATER_BUTTON, "ENTER_LATER_BUTTON");
		Thread.sleep(high);
		if(isElementPresent(ElsevierObjects.ENTER_INSTRUCTOR_COURSE_ID_BUTTON, "Enter Instructor's Course ID ")){
			Reporters.SuccessReport(" Verify Enter later button works as expected", "Successfully clicked on Enter Later button. The modal gone away and no action occurred.");
		}else{
			Reporters.failureReport(" Verify Enter later button works as expected", "Failed to click on Enter Later button. The modal gone away and no action occurred.");
		}
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			
		}

	}

	public static void enterCourseId(String courseId) throws Throwable{

		try{
		//driver.navigate().refresh();
		Thread.sleep(medium);
		
		//click(ElsevierObjects.ENTER_INSTRUCTOR_COURSE_ID_BUTTON, "");

		//Thread.sleep(medium);
		
		type(ElsevierObjects.txtcourseID, courseId, "Course ID");

		click(ElsevierObjects.MODAL_CONTINUE_BUTTON, "MODAL_CONTINUE_BUTTON");
		Thread.sleep(high);
		waitForVisibilityOfElement(ElsevierObjects.OK_MESSAGE, "Thank you Message");
		String tankyouMessage = getText(ElsevierObjects.OK_MESSAGE, "Thank you Message");
		if(tankyouMessage.contains("Thank you")){
			Reporters.SuccessReport("Verify Thank You Message", "Tank You message was success fully dispalyed on modal pop up");
		}else{
			Reporters.failureReport("Verify Thank You Message", "Tank You message was unable  to dispaly on modal pop up");
		}
		Thread.sleep(medium);
		click(ElsevierObjects.OK_BUTTON, "OK_BUTTON");
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			
		}
	}
	
	public static boolean myevolve()throws Throwable{
		boolean flag=true;
		try{
			b=true;
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(medium);
			click(ElsevierObjects.COURSE_LINK_AFTER_ENTER, "Course");
			Thread.sleep(60000);
			//driver.manage().timeouts().implicitlyWait(600, TimeUnit.SECONDS);
			//Thread.sleep(medium);
			click(ElsevierObjects.COURSE_CONTENT, "Course Content");
			Thread.sleep(medium);
			b=false;
			if(isElementPresent(ElsevierObjects.COURSR_CONTENT_LINK, "Course Content Link", driver.getCurrentUrl())){
				Reporters.SuccessReport("Verify the user is able to access the folders and subfolders within the course.", "user is able to access the folders and subfolders within the course.");
			}
			else{
				Reporters.failureReport("Verify the user is able to access the folders and subfolders within the course.", "user is not able to access the folders and subfolders within the course.");
			}
		}catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}
		return flag;
	}
	
	//Creating New Account For Both FACULTY and STUDENT
		public static boolean CreateNewUser(String user, String testCaseName, String sheetName, int row, int col1, int col2, int col3) throws Throwable{
			boolean flag = true;
			try{
				driver.manage().deleteAllCookies();
				Thread.sleep(medium);
				if(!launchUrl(configProps.getProperty("URL"))){
					flag = false;
				}
				//driver.findElement(ElsevierObjects.StudentMainPage).click();
				driver.manage().deleteAllCookies();
				driver.navigate().refresh();

				/*if(!clickOnMainPageLink()){
					flag=false;
				}
				 */
				if(user.equalsIgnoreCase("educator")){ 
					if(!click(ElsevierObjects.evolve_createNewUser,"Create new account")){
						flag=false;
					}
					if(!switchToFrameByLocator(ElsevierObjects.evolve_newAcount_frame,"Switch to frame")){
						flag=false;
					}
					if(!click(ElsevierObjects.faculty_radio_btn,"Faculty radio button")){
						flag=false;
					}
					registrationForm(testCaseName, sheetName, row, col1, col2, col3);
				}else{
					if(!click(ElsevierObjects.evolve_createNewUser,"Create new account")){
						flag=false;
					}
					if(!switchToFrameByLocator(ElsevierObjects.evolve_newAcount_frame,"Switch to frame")){
						flag=false;
					}
					registrationForm(testCaseName, sheetName, row, col1,col2,col3);
				}
			}catch(Exception e)
			{
				sgErrMsg=e.getMessage();
				System.out.println(e.getMessage());
				return false;
			}
			return flag;
		}
		
		//New Registration form for Both FACULTY And STUDENT
		public static boolean registrationForm(String testCaseName, String sheetName, int row, int col1, int col2, int col3) throws Throwable{

			boolean flag = true;
			try{
				if(!type(ElsevierObjects.evolve_newAccount_firstname,tcVST_KNO.get("user_firstname")/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_firstname")*/,"First Name")){
					flag=false;
				}
				if(!type(ElsevierObjects.evolve_newAcount_Lastname,tcVST_KNO.get("user_lastname")/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_lastname")*/,"Last Name")){
					flag=false;
				}
				Random ra = new Random( System.currentTimeMillis() );
				StdEmail = tcVST_KNO.get("user_email")/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_email")*/+Integer.toString((1 + ra.nextInt(2)) * 10000 + ra.nextInt(10000))+"@evolveqa.info";


				//ReadingExcel.updateCellValue(3, 1, configProps.getProperty("TestData"), 15);
				if(!type(ElsevierObjects.evolve_newAcount_Email, StdEmail ,"Email")){
					flag=false;
				}
				if(!type(ElsevierObjects.evolve_newAcount_Pwd, tcVST_KNO.get("user_pwd")/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_pwd")*/,"Password")){
					flag=false;
				}
				if(!type(ElsevierObjects.evolve_newAcount_ConfirmPwd,tcVST_KNO.get("user_pwd")/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_pwd")*/,"Confirm Password")){
					flag=false;
				}
				if(isChecked(ElsevierObjects.evolve_newAcount_Chkbx, "Check box")){
					if(!click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
						flag=false;
					}
					Thread.sleep(high);
				}
				else{
					if(!click(ElsevierObjects.evolve_newAcount_Chkbx,"Click chk box")){
						flag=false;
					}
					if(!click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
						flag=false;
					}
					Thread.sleep(high);
				}

				Thread.sleep(veryhigh);
				capturCredentials(testCaseName, sheetName, row, col1, col2, col3);

				Thread.sleep(veryhigh);
				if(!click(ElsevierObjects.newAccount_contiue_btn,"Continue button")){
					flag=false;
				}
				Thread.sleep(high);
			}catch(Exception e)
			{
				sgErrMsg=e.getMessage();
				System.out.println(e.getMessage());
				return false;
			}
			return flag;

		}
		
		public static String []  capturCredentials(String testCaseName, String sheetName, int row, int col1, int col2, int col3) throws Throwable{
			
			try{
			Thread.sleep(high);
			Thread.sleep(veryhigh);
			waitForVisibilityOfElement(ElsevierObjects.NonAdmin_UserCredentials, "NonAdmin_UserCredentials");
			Thread.sleep(veryhigh);
			String credentialss = driver.findElement(ElsevierObjects.NonAdmin_UserCredentials).getText();

			String[] credentialsArr = credentialss.split("\n");

			String userName = null;
			String password = null;
			for(String credentials : credentialsArr){
				if(credentials.contains("Username:")){
					userName = credentials.replaceAll("Username:", "").trim();
				}
				if(credentials.contains("Password:")){
					password = credentials.replaceAll("Password:", "").trim();
				}    
			}

			credentials[0] =userName;
			credentials[1] =password;
			ReadingExcel.updateCellInSheet(row,col1,configProps.getProperty("TestData"), sheetName, userName);

			ReadingExcel.updateCellInSheet(row,col2,configProps.getProperty("TestData"), sheetName, password);

			ReadingExcel.updateCellInSheet(row,col3,configProps.getProperty("TestData"), sheetName, testCaseName);
			return credentialsArr;
			}
			catch(Exception e)
			{
				sgErrMsg=e.getMessage();
				System.out.println(e.getMessage());
				return null;

			}
			
		}

	
}
