package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.VitalSourceAccountAC_HomePage_StudentExists_VST;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class VitalSourceAccount_Pageburst_CC_NewStudent_Script_15561 extends EvolveCommonBussinessFunctions{
	@Test 
	public void vitalSourceAccount_Pageburst_CC_NewStudent_15561() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			
			String user = "student";
			writeReport(Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions.CreateNewUser("student", "VitalSourceAccountPageburstCCNewStudent15561", "VSTPageBurstCredentials", 2, 1,2,0), "Create New Student user", "Successfully created new student user with credentials: <br> Username: "+credentials[0]+"<br> Password : "+credentials[1], "Failed to create a new student account");
			/*if(CreateNewUser(user))
			{
	     		Reporters.SuccessReport("Create Faculty User from Faculty Page", "Successfully Created Faculty user with the following credentials: <br> Faculty Username : "+EvolveCommonBussinessFunctions.credentials[0]+"<br> Faculty Password : "+EvolveCommonBussinessFunctions.credentials[1]+"<br> Succussfully logged into the application as faculty user");
			}
			else
			{
				Reporters.failureReport("Create Faculty User from Faculty Page", "Failed to Create Faculty user <br> Failed to logged into the application as faculty user");
			}*/
			String name = "VST";
			String accessCode = "false";
			VSTandKnoSearch(name,accessCode);
			
			String knoUser="";
			updateVSTandKNOAccount(user,name,accessCode,knoUser);
			
			if(creditCardDetails(ElsevierObjects.CreditCardSubmit))
			{
	     		Reporters.SuccessReport("Credit Card Details:", "Credit Card Details Entred Successfully");
			}
			else
			{
				Reporters.failureReport("Credit Card Details Not Entred:", "Failed to Enter Cradit Card.");
			}
			if(userReviewSubmit(user,accessCode,KNOIsbn))
			{
	     		Reporters.SuccessReport("Review and submit page:" ,"Successfully entered to review and submit page");
			}
			else
			{
				Reporters.failureReport("Review and submit page:", "Failed to enter review and submit page");
			}
			String accessCodeUser="student";
			VitalSourceAccountAC_HomePage_StudentExists_VST.pageburstVstLink(accessCodeUser,titleInReceiptPage,"myCartTitle");
			ReadingExcel.removeUsedVSTCode(VSTDataPath, "VSTCodes");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ReadingExcel.removeUsedVSTCode(VSTDataPath, "VSTCodes");
		}
	}
	@AfterTest
	public void closeBrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}

