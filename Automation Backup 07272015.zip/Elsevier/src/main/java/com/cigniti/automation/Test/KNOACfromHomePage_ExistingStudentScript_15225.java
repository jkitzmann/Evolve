package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.KNOACfromMyCart_Instructor_15237;
import com.cigniti.automation.BusinessFunctions.VitalSourceAccountAC_HomePage_StudentExists_VST;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class KNOACfromHomePage_ExistingStudentScript_15225 extends EvolveCommonBussinessFunctions{
	
	@Test
	public void KNOHomeExistingStudent_15225() throws Throwable{
	    
		try{
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			stepReport("Create access code for KNO product in Evolve Admin.");
			if(evolveAdminlogin()){
				Reporters.SuccessReport("Login to Application Using Admin Credentials"+adminUser,"Launching the URL for Admin is successful </br > Login to Application Using Admin credentials :"+adminUser+" is Successful");
			}
			else{
				Reporters.failureReport("Login to Application Using Admin Credentials"+adminUser,"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");
			}
			EvolveCommonBussinessFunctions.maintainProduct();
			
			createAccessCode();
			EvolveCommonBussinessFunctions.manageAccessCode();
			if(adminLogout()){
				Reporters.SuccessReport("Admin logout as "+adminUser,"Successfully logged out "+adminUser+" admin page.");
			}
			else{
				Reporters.failureReport("Admin logout as "+adminUser,"Failed To log out "+adminUser+" admin page.");
			} 
			String user="student";
			String knoUserName=configProps.getProperty("KNO_StudentUser");
			String knoPassword=configProps.getProperty("KNO_StudentPassword");
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String user1="student";
			String username=readcolumns.twoColumns(0, 1,"DynamicCredentials",configProps.getProperty("TestData")).get("UserName");
			String password=readcolumns.twoColumns(0, 1,"DynamicCredentials",configProps.getProperty("TestData")).get("Password");
			
			stepReport("Login to existing student account.");
			VitalSourceAccountAC_HomePage_StudentExists_VST.login(user1,username, password);
			
			stepReport("Enter KNO access code on Evolve catalog page and enter checkout.");
			pageBurstReedem();
			String name="KNO";
			String accessCode="true";
			String knoUser="existinguser";
			KNOACfromMyCart_Instructor_15237.ExistingStudentUpdateAccount();
			
			stepReport("Verify review page and complete checkout.");
			AccessCodeReviewandSubmit();
			
			stepReport("Verify KNO library link in My Evolve.");
			knoLibrary(user,knoUser);
			if(instructorLogout()){
				Reporters.SuccessReport("Logout Student:"+username, "Successfully logged out Student "+username);
			}
			else{
				Reporters.failureReport("Logout Student:"+username, "Failed to logout Student "+username);
			}
			
			stepReport("Verify that the access code redemption is reflected in Evolve Admin.");
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			if(evolveAdminlogin()){
				Reporters.SuccessReport("Login to Application Using Admin Credentials"+adminUser,"Launching the URL for Admin is successful </br > Login to Application Using Admin credentials :"+adminUser+" is Successful");
			}
			else{
				Reporters.failureReport("Login to Application Using Admin Credentials"+adminUser,"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");
			}
			adminAccessCodeSearch();
			if(adminLogout()){
				Reporters.SuccessReport("Admin logout as "+adminUser,"Successfully logged out "+adminUser+" admin page.");
			}
			else{
				Reporters.failureReport("Admin logout as "+adminUser,"Failed To log out "+adminUser+" admin page.");
			} 
			
			stepReport("Verify that the access code used is no longer valid.");
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			reLogingForAccessCodeRedeem();
			String StudentUserName=readcolumns.twoColumns(0, 1, "Tc-15228", configProps.getProperty("TestData")).get("StudentUser");
			if(instructorLogout()){
				Reporters.SuccessReport("Logout Student Page.", "Successfully logged out Student page:"+StudentUserName);
			}
			else{
				Reporters.failureReport("Logout Student Page.", "Failed to logout Student page:"+StudentUserName);
			}
		}
	
		catch(Exception e){
				System.out.println(e);
			}
	}


@AfterTest
public void tear() throws Throwable{
//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
//Base.tearDown();
}
}