package com.cigniti.automation.BusinessFunctions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ImageComparison;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class ECommercePackagependingcourseid_15461 extends EvolveCommonBussinessFunctions{

	public static boolean verifyAndAddISBN(String isbn1,String isbn2, String discount1, String discount2, String discountType) throws Throwable{
		boolean flag=true;	
		try{
			Thread.sleep(3000);
			isbnEntry( isbn1, discountType, discount1);
			ImplicitWait();
			Thread.sleep(3000);
			isbnEntry( isbn2, discountType, discount2);
			ImplicitWait();
			Thread.sleep(3000);
		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	public static void verifyTwoButtons() throws Throwable{

		try{
		if(isElementPresent(ElsevierObjects.ENTER_INSTRUCTORS, "ENTER INSTRUCTORS")){
			Reporters.SuccessReport("Verify Enter Instructor's Course ID Button", "Enter Instructor's Course ID button was displayed Success fully");
		}
		else{
			Reporters.failureReport("Verify Enter Instructor's Course ID Button", "Unable to dispaly Enter Instructor's Course ID Button ");
		}

		/*if(isElementPresent(ElsevierObjects.ENTER_AS_IND_BUTTON, "")){
			Reporters.SuccessReport("Verify Enter as Independent Self-Study Button", "Enter Enter as Independent Self-Study button was displayed Success fully");
		}
		else{
			Reporters.failureReport("Verify Enter as Independent Self-Study Button", "Unable to dispaly Enter as Independent Self-Study Button ");
		}*/
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
		}
	}
	public static boolean verifyContent() throws Throwable{
		boolean flag=true;
		try{
			launchUrl(configProps.getProperty("URL4"));
			//TODO to be tested 
			if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(2000);
			if(!javaClick(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
				flag = false;
			}
			Thread.sleep(2000);
			if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(2000);
			if(!javaClick(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
				flag = false;
			}
			Thread.sleep(2000);
			if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			if(isElementPresent(ElsevierObjects.contentLink1)){
				Reporters.failureReport("Verify the pending course id read only link is removed from the content list.<br/>Verify the Self study link is removed from the content list ", "The pending course id read only link is present in the content list.<br/>The Self study link is present in the content list <br/> Clinical Medical Assisting Online for Clinical Procedures for Medical Assistants, 9th Edition");
			}else{
				Reporters.SuccessReport("Verify the pending course id read only link is removed from the content list.<br/>Verify the Self study link is removed from the content list ", "The pending course id read only link is successfully removed from the content list.<br/>The Self study link is successfully removed from the content list <br/> Clinical Medical Assisting Online for Clinical Procedures for Medical Assistants, 9th Edition");
			}
			if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}
	public static boolean crossPromoteItems(String user, String checkbox, String sheetName, int Col) throws Throwable{
		boolean flag=true;  
		try{
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Items, "Cross Promote Items", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrTitle, "Cross Promote Items title", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrDescrip, "Cross Promote Items page body", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrImg, "Cross Promote Items image header", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ImgPrw, "Cross Promote Items image preview", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrUrl, "Cross Promote URL", driver.getCurrentUrl())){
				flag = false;
			}
			if(checkbox.equalsIgnoreCase("selectFeatureRadioButton")){
				if(click(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SltFeatureRadBtn, "Click on Feature Selected Resources radio button")){
					Reporters.SuccessReport("Click on the Feature Selected Resources Radio Button", "Successfully Clicked on the Selected Feature Radio Button");
					//flag = false;
				}else{
					Reporters.failureReport("Click on the Feature Selected Resources Radio Button", "Failed to Click on the Selected Feature Radio Button");
					System.out.println("Feature Selected Resources Radio Button is not present");
				}
			}
			if(user.equalsIgnoreCase("variablePercentage")){
				marketingPageBookDetails(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ISBN, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("ISBN"), ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ISBNAdd,ElsevierObjects.crossPromoteISBNtableContent , "" );
			}else{
				System.out.println("");
			}
			if(!type(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Title, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("TitleCrossPromote"), "Type title  ")){
				Thread.sleep(2000);
				flag = false;
			}
			if(!type(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Description, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("BodyCrossPromote"), "Type URL  ")){
				Thread.sleep(2000);
				flag = false;
			}
			if(!click(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SaveAndPublish, "Click on Marketing Page Tab")){
				flag = false;
			}
			String sucMsg="Marketing page details are saved successfully.";
			if(sucMsg.contains("Marketing")){
				Reporters.SuccessReport("Marketing Page Details are successfully saved", "Marketing Page Details are successfully saved");
			}else{
				Reporters.failureReport("Marketing Page Details are failed to save", "Marketing Page Details are failed");
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ReqFlds, "Required Fields", driver.getCurrentUrl())){
				flag = false;
			}
			//String UniqueURL = "evolvecert.elsevier.com"+ readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("UniqueURL");
			UniqueURL = "http://evolvetest.elsevier.com"+uniqueURL;
			ReadingExcel.updateCellInSheet(1,Col,configProps.getProperty("TestData"), sheetName, UniqueURL);
			System.out.println(UniqueURL);
			launchUrl(UniqueURL);
			Thread.sleep(3000);
			String actHdrTitle=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrPageTitleVfyTxt, "");
			String actHdrBody=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrPageBodyVfyTxt, "");
			String actTitle=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_TitleVrfy, "");
			String actBody=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_DescVrfy, "");
			String expHdrTitle=readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("PageTitle");
			String expHdrBody=readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("pageBody");
			String expTitle=readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("TitleCrossPromote");
			String expBody=readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("BodyCrossPromote");
			if(actHdrTitle.equalsIgnoreCase(expHdrTitle)){
				Reporters.SuccessReport("Verify the Header Titles are correct", "The titles are matched with each other <br> Actual Title is : "+actHdrTitle+" <br> Expected title is : "+expHdrTitle);	
			}else{
				Reporters.failureReport("Verify the Header Titles are correct", "The titles are not matched with each other <br> Actual Title is : "+actHdrTitle+" <br> Expected title is : "+expHdrTitle);	
			}
			if(actHdrBody.equalsIgnoreCase(expHdrBody)){
				Reporters.SuccessReport("Verify the Header Body correct", "The titles are matched with each other <br> Actual Title is : "+actHdrBody+" <br> Expected title is : "+expHdrBody);	
			}else{
				Reporters.failureReport("Verify the Header Body correct", "The titles are not matched with each other <br> Actual Title is : "+actHdrBody+" <br> Expected title is : "+expHdrBody);	
			}
			if(actTitle.equalsIgnoreCase(expTitle)){
				Reporters.SuccessReport("Verify the Page Titles are correct", "The titles are matched with each other <br> Actual Title is : "+actTitle+" <br> Expected title is : "+expTitle);	
			}else{
				Reporters.failureReport("Verify the Page Titles are correct", "The titles are not matched with each other <br> Actual Title is : "+actTitle+" <br> Expected title is : "+expTitle);	
			}
			if(actBody.equalsIgnoreCase(expBody)){
				Reporters.SuccessReport("Verify the Page Body is correct", "The titles are matched with each other <br> Actual Title is : "+actBody+" <br> Expected title is : "+expBody);	
			}else{
				Reporters.failureReport("Verify the Page Body is correct", "The titles are not matched with each other <br> Actual Title is : "+actBody+" <br> Expected title is : "+expBody);	
			}
			List<WebElement> productTitleOnUrl=driver.findElements(ElsevierObjects.urlISBNTitle);
			title1 = ReadingExcel.columnDataByHeaderName("course1", sheetName, testDataPath);
			for(WebElement title: productTitleOnUrl){
				if(title.getText().contains(title1)){
					Reporters.SuccessReport("Verify the ISBN title on the New Unique URL", "Successfully verified The title of the ISBN on the new Unique URL <br> Title is : "+title.getText());
				}
				title1 = ReadingExcel.columnDataByHeaderName("course2", sheetName, testDataPath);
			}
			String filePath = ReadingExcel.getAbsoulteFilePath(readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("UploadImgFile"));
			ImageComparison.Image_Comparisions(filePath);	
		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	public static boolean launchAndAddtoCart(String url)throws Throwable{
		boolean flag=true;
		try{
			Thread.sleep(3000);
			launchUrl(url);
			Thread.sleep(3000);
			//System.out.println("");
			click(ElsevierObjects.Admin_Evolve_Ecom_AddtoCart, "Click on add to cart button");
			switchToFrameByLocator(ElsevierObjects.frameName, "switch to frame by class name");
			String courseIDRequired=getText(ElsevierObjects.frameCourseIDRequired, "course id required string");
			System.out.println(courseIDRequired);
			if(courseIDRequired!=null){
				Reporters.SuccessReport("Verify course id prompt is presented to the user", "Successfully verified the course id prompt <br/> The message on the couse id prompt is : "+courseIDRequired);
			}else{
				Reporters.failureReport("Verify course id prompt is presented to the user", "Course id prompt is not present <br>Failed to verify the course id prompt ");
			}
			Thread.sleep(4000);
			String course1=getText(By.xpath("html/body/div[3]/p/span"), "Course 1");
			System.out.println(course1);
			if(click(ElsevierObjects.frameEnterLaterButton, "Click on Enter Later Button")){
				Reporters.SuccessReport("Click on Enter Later button", "Successfully clicked on the Enter Later button for the product :"+course1);
			}else{
				Reporters.failureReport("Click on Enter Later button", "Failed to click on the Enter Later button for the product :"+course1);
			}
			driver.switchTo().defaultContent();
			switchToFrameByLocator(ElsevierObjects.frameName, "switch to frame by class name");

			//switchToFrameByLocator(ElsevierObjects.frameName, "switch to frame by class name");
			Thread.sleep(3000);
			String course2=getText(By.xpath("html/body/div[3]/p/span"), "Course 2");
			System.out.println(course2);
			if(click(ElsevierObjects.frameEnterLaterButton, "Click on Enter Later Button")){
				Reporters.SuccessReport("Click on Enter Later button", "Successfully clicked on the Enter Later button for the product : "+course2);
			}else{
				Reporters.failureReport("Click on Enter Later button", "Failed to click on the Enter Later button for the product : "+course2);
			}
			//System.out.println("");
			Thread.sleep(4000);
			driver.switchTo().defaultContent();
			String myCart=getText(ElsevierObjects.Admin_Evolve_Ecom_MyCartTitle, "My cart text");
			if(myCart!=null){
				Reporters.SuccessReport("Verify the package is added to the cart.", "The product is successfully added to My Cart<br/> The product is : "+myCart);
			}else{
				Reporters.failureReport("Verify the package is added to the cart.", "The product is not added to My Cart");
			}



		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	public static boolean newstudentBilling(String user,String streetAddress, String cityAddress, String stateAddress, String zip)throws Throwable{
		boolean flag=true;
		try{
			if(user.equalsIgnoreCase("iteration")){
			click(ElsevierObjects.checkoutBtn, "Click on the Checkout Button");
			Thread.sleep(3000);
			click(ElsevierObjects.Student_Register_Chk, "Click on no institution checkbox");
			Thread.sleep(3000);
			type(ElsevierObjects.student_billingAddress,streetAddress,"Enter the Street Address in the box");
			Thread.sleep(1000);
			type(ElsevierObjects.student_billingAddress_city,cityAddress,"Enter City in the textbox");
			Thread.sleep(1000);
			selectByVisibleText(ElsevierObjects.student_billingAddress_state,stateAddress,"Enter State in the textbox");
			Thread.sleep(1000);
			type(ElsevierObjects.student_billingAddress_zip,zip,"Enter Zipcode in the textbox");
			Thread.sleep(1000);
			Reporters.SuccessReport("Enter and click","billing address is entered successfully and Details entered in billing address:</br>"+"Street Address :"+streetAddress+"</br>"+"CityAddress :"+cityAddress+"</br>"+"StateAddress :"+stateAddress+ "</br>"+"Zipcode :"+zip);
			click(ElsevierObjects.educator_form_btnContinue,"Click on continue button");
			Thread.sleep(1000);
			switchToFrameByLocator(ElsevierObjects.Admin_Evolve_Ecom_framename,"Switch to iframe");
			Thread.sleep(1000);
			String Popupheader = ReadingExcel.columnDataByHeaderName("PopUp", "TC-15588",configProps.getProperty("TestData"));
			String Popheader = getText(ElsevierObjects.Popup_header,"Get header of the frame");
			if(Popheader.contains(Popupheader)){
				Reporters.SuccessReport("Verify the header of Frame","PopupHeader is Successfully verified : </br> Expected Header is :"+Popheader+" </br> Actual Header is :"+Popupheader);
			}else{
				Reporters.failureReport("Verify the header of Frame","Failed to verify headers : </br> Expected Header is :"+Popheader+" </br> Actual Header is :"+Popupheader);
			}
			Thread.sleep(2000);
			if(click(ElsevierObjects.Use_this_address,"Click on use this address")){
				Reporters.SuccessReport("Click on Use this Address","Successfully clicked on Use this Address");
			}else{
				Reporters.failureReport("Click on Use this Address","Failed to click on Use this Address");
			}
			Thread.sleep(2000);
			String Creditheader = ReadingExcel.columnDataByHeaderName("Creditheader", "TC-15588",configProps.getProperty("TestData"));
			String cardheader = getText(ElsevierObjects.Creditcard_header,"Get header of the Page");
			if(cardheader.contains(Creditheader)){
				Reporters.SuccessReport("Verify the header of page","Creditcard Header is Successfully verified : </br> Expected Header is :"+cardheader+" </br> Actual Header is :"+Creditheader);
			}else{
				Reporters.failureReport("Verify the header of page","Failed to verify headers : </br> Expected Header is :"+cardheader+" </br> Actual Header is :"+Creditheader);
			}
			Thread.sleep(2000);
			if(creditCardDetails()){
				Reporters.SuccessReport("Enter Details and verify","Creditcard details are entered and User is Successfully taken to Review and Submit Page"); 
			}else{
				Reporters.failureReport("Enter Details and verify","User is Failed to enter creditcard details and to take Review and Submit page");
			}
			
			Thread.sleep(4000);
			click(ElsevierObjects.Student_accept_chk, "Accept Check box");
			click(ElsevierObjects.Student_Review_Submit, "Review Submit Button");
			Thread.sleep(4000);
			}else{
				click(ElsevierObjects.checkoutBtn, "Click on the Checkout Button");
				Thread.sleep(high);
				creditCardDetails();
				Thread.sleep(veryhigh);
				click(ElsevierObjects.Student_accept_chk, "Accept checkBox");
				click(ElsevierObjects.Student_Review_Submit, "Review Submit Button.");
				Thread.sleep(4000);
			}

		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	public static boolean clickEvolveAndVerifyUserContent()throws Throwable{
		boolean flag=true;
		try{
			Thread.sleep(3000);
			if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(2000);
			if(!javaClick(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
				flag = false;
			}
			Thread.sleep(2000);
			if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(2000);
			if(!javaClick(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
				flag = false;
			}
			Thread.sleep(2000);
			if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}

			Thread.sleep(3000);
			List<WebElement> listUserContent=driver.findElements(ElsevierObjects.userContentList);
			for(WebElement course: listUserContent){
				String courseList=course.getText();
				if(courseList!=null){
					Reporters.SuccessReport("Verify on the user's content list", "User Content list is verified successfully <br/> The Content list contains : "+courseList);
				}else{
					Reporters.failureReport("Verify on the user's content list", "User Content list is verification failed");
				}
			}

		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println("Exception occurred");return false;
		}
		return flag;
	}

	public static boolean adminPARVerify(String userName)throws Throwable{
		boolean flag=true;
		try{
			if(click(ElsevierObjects.VIEWPROFILE_LINK, "Click on view edit profile")){
				Reporters.SuccessReport("Click on view edit profile", "Successfully clicked on the view edit profile");
			}else{
				Reporters.failureReport("Click on view edit profile", "Failed to click on the view edit profile");
			}
			if(type(By.name("username"), userName, "Username")){
				Reporters.SuccessReport("Enter the username in the search field", "Entered the username : "+userName+ " into the search field");
			}else{
				Reporters.failureReport("Enter the username in the search field", "failed to enter the username : "+userName+ " into the search field");
			}
			if(click(By.name("action"), "Search Button")){
				Reporters.SuccessReport("Click on Search button", "Successfully clicked on the Search button");
			}else{
				Reporters.failureReport("Click on Search button", "Failed to click on the Search button");
			}
			Thread.sleep(3000);
			if(click(By.xpath("//*[@id='evolve_usersearchlist_table']/tbody/tr/td[1]"), "Username")){
				Reporters.SuccessReport("Click on username ", "Successfully clicked on the username ");
			}else{
				Reporters.failureReport("Click on username ", "Failed to click on the username ");
			}
			Thread.sleep(3000);
			if(click(By.id("parBtn"), "PAR Button")){
				Reporters.SuccessReport("Click on PAR button ", "Successfully clicked on the PAR button ");
			}else{
				Reporters.failureReport("Click on PAR button ", "Failed to click on the PAR button ");
			}
			Thread.sleep(3000);
			if(isElementPresent(By.xpath("//strong[text()='Manage Protected Access Rights']"),"Manage Protected Access Rights"))
				Reporters.SuccessReport("Verify Manage Protected Access Rights page", "User is taken to Manage Protected Access Rights Page");
			else
				Reporters.failureReport("Verify Manage Protected Access Rights page", "User is unable to take Manage Protected Access Rights Page");

			click(By.xpath(".//*[@id='invalidateOrActivateCodeText'][text()='Revoke']"), "revoke");
			Thread.sleep(5000);
			String sucMsg=getText(By.xpath(".//*[@id='msg-manage-revokeaccessenddate-success']"), "Success Message");
			if(verifyText(By.xpath(".//*[@id='msg-manage-revokeaccessenddate-success']"), "Access is successfully revoked.", "")){
				Reporters.SuccessReport("Verify the PAR is revoked", "PAR is successfully revoked <br/> Success message printed : "+sucMsg);
			}else{
				Reporters.failureReport("Verify the PAR is revoked", "PAR is not revoked <br/> failure message printed : "+sucMsg);
			}
		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println("Exception occurred");return false;
		}
		return flag;
	}


	public static boolean VerifyContentpagewithinputs(String Prodcutypeinput,String coursedetailsinputs,String Button1,String Button2,String Validation) throws Throwable
	{
		try
		{
			click(ElsevierObjects.Myevolve,"Click on my evolve");
			Thread.sleep(3000);
			List<WebElement> TotalConentlist=driver.findElements(By.xpath(".//*[@id='set']/li//div//div[@class='item platform_product']"));
			String Productype="";
			int successflag=0;
			int index=0;
			for(int i=0;i<=TotalConentlist.size();i++)
			{
				String CourseDetails=TotalConentlist.get(i).findElement(By.tagName("a")).getText();
				if(CourseDetails!=null)
				{
					if(CourseDetails.equalsIgnoreCase(coursedetailsinputs))
					{
						Reporters.SuccessReport("Verifying Course Details :"+coursedetailsinputs, "Course Details Present in the Content list is "+CourseDetails);
						successflag=1;
						index=i;
						break;
					}
				}
				else
				{
					Reporters.failureReport("Verifying CourseDetails :"+coursedetailsinputs, "Course Details is not Present in the Content list ");
				}
			}

			if(successflag==1)
			{
				Productype=TotalConentlist.get(index).findElement(By.tagName("span")).getText();

				if(Productype!=null)
				{
					if(Productype.contains(Prodcutypeinput))
					{
						Reporters.SuccessReport("Verifying Product type: " +Prodcutypeinput +" </br> for Course Details :"+coursedetailsinputs , "Product Type name Present in Content list is "+Productype);
					}
				}
				else
				{
					Reporters.failureReport("Verifying Product type Details Sequence:"+Prodcutypeinput, "Product Type name Present in Content list is not valid");
				}

				if(isElementPresent(By.xpath(".//*[@id='set']/li['"+index+"']//div//div[@class='item platform_product']//button")))
				{                    
					List<WebElement> buttons=TotalConentlist.get(index).findElements(By.tagName("button"));

					if(buttons.size()==0)
					{
						if(Validation.equalsIgnoreCase("Yes"))
						{      
							Reporters.failureReport("Verifying Buttons for Course Details :"+coursedetailsinputs, "No  Buttons available ");         
						}
						else
						{
							Reporters.SuccessReport("Verifying Buttons  for Course Details :"+coursedetailsinputs, "No  Buttons available ");
						}
					}
					else
					{
						for(int a=0;a<buttons.size();a++)
						{


							String Button=buttons.get(a).getText();
							if(Button!=null)
							{

								if(Button.equalsIgnoreCase(Button1))
								{      
									Reporters.SuccessReport("Verifying Buttons", "Buttons are available :</br>"+Button+" for Product Type "+Productype);
								}
								else
									if(Button.equalsIgnoreCase(Button2))
									{      
										Reporters.SuccessReport("Verifying Buttons", "Buttons are available :</br>"+Button+" for Product Type "+Productype);
									}
							}
							else
							{
								Reporters.SuccessReport("Verifying Buttons", "Buttons available is "+Button+" is Mismatching and not as expected for Productype :"+Productype);
							}

						}

					}
				}
				else{
					Reporters.SuccessReport("Verifying Buttons", "No  Buttons Avilable ");            }
			}
			else
			{     Reporters.failureReport("Verifying Content list", " Expected values are not Present in the Content list </br>Course details :"+coursedetailsinputs+"</br>Product type "+Prodcutypeinput+"</br> Buttons details are </br>"+Button1+" </br>"+Button2);}


		}catch(Exception e){sgErrMsg="Failed to verify content list"+e;return false;}


		return true;
	}

	public void enterInstructorCourseId(String courseId) throws Throwable{
		try{
		Thread.sleep(3000);

		if(isElementPresent(ElsevierObjects.txtcourseID, "courseID")){
			Reporters.SuccessReport("Verify Courseid", "Course ID required prompt is displayed");
		}else{
			Reporters.failureReport("Verify Courseid", "Course ID required prompt is not displayed");
		}

		if(click(ElsevierObjects.ENTER_LATER_BUTTON, "ENTER_LATER_BUTTON")){
			Thread.sleep(2000);
			if(isElementPresent(ElsevierObjects.evolveCatlog_lnk, "Catalog Link")){
				Reporters.SuccessReport("Verify Enter later button", "Success fully Closes the modal.");
			}else{
				Reporters.failureReport("Verify Enter later button", "unable to  Close the modal");
			}
		}
		click(ElsevierObjects.ENTER_INSTRUCTORS,"ENTER_INSTRUCTORS");
		type(ElsevierObjects.txtcourseID, courseId, "courseId");
		click(ElsevierObjects.MODAL_CONTINUE_BUTTON, "MODAL_CONTINUE_BUTTON");
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
		}
	}
	public static boolean myevolve()throws Throwable{
		boolean flag=true;
		try{
			b=true;
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(2000);
			click(ElsevierObjects.COURSE_LINK_AFTER_ENTER, "Course");
			Thread.sleep(2000);
			click(ElsevierObjects.COURSE_CONTENT, "Course Content");
			Thread.sleep(2000);
			b=false;
			if(isElementPresent(ElsevierObjects.COURSR_CONTENT_LINK, "Course Content Link", driver.getCurrentUrl())){
				Reporters.SuccessReport("Verify the user is able to access the folders and subfolders within the course.", "user is able to access the folders and subfolders within the course.");
			}
			else{
				Reporters.failureReport("Verify the user is able to access the folders and subfolders within the course.", "user is not able to access the folders and subfolders within the course.");
			}
		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println("Error Occurred"); return false;
		}
		return flag;
	}
	
	public static boolean validateProduct(String course, String courseID, By contentLink)throws Throwable{
		boolean flag=true;
		try{
			//Verify the product clinical medical course
			launchUrl(configProps.getProperty("URL4"));
			Thread.sleep(3000);
			if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			
			if(click(By.xpath(".//*[@id='set']/li/div/div/a[contains(text(),'"+course+"')]/following-sibling::*"), course)){
				Reporters.SuccessReport("From user's content list, Click on 'Enter Instructor's Course ID' button for <br/>"+course, "Successfully  Clicked on 'Enter Instructor's Course ID' button for <br/> "+course);
			}else{
				Reporters.failureReport("From user's content list, Click on 'Enter Instructor's Course ID' button for <br/>"+course, "Failed to  Click on 'Enter Instructor's Course ID' button for <br/> "+course);
			}
			String courseID1=ReadingExcel.columnDataByHeaderName(courseID, "TC-15461", testDataPath);
			verifyTwoButtons();
			enterCourseId(courseID1);
			EComm_Preorde_MyEvolve_Page15594_BussinessFunctions.courseDetailsPage(contentLink,"contentHome");
			
		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println("Error Occurred"); return false;
		}
		return flag;
	}
	
	public static void enterCourseId(String courseId) throws Throwable{
		try{
		//driver.navigate().refresh();
		Thread.sleep(3000);
		
		//click(ElsevierObjects.ENTER_INSTRUCTOR_COURSE_ID_BUTTON, "");

		//Thread.sleep(3000);
		
		type(ElsevierObjects.txtcourseID, courseId, "Course ID");

		click(ElsevierObjects.MODAL_CONTINUE_BUTTON, "MODAL_CONTINUE_BUTTON");
		Thread.sleep(6000);
		waitForVisibilityOfElement(ElsevierObjects.OK_MESSAGE, "Thank you Message");
		String tankyouMessage = getText(ElsevierObjects.OK_MESSAGE, "Thank you Message");
		if(tankyouMessage.contains("Thank you")){
			Reporters.SuccessReport("Verify Thank You Message", "Tank You message was success fully dispalyed on modal pop up");
		}else{
			Reporters.failureReport("Verify Thank You Message", "Tank You message was unable  to dispaly on modal pop up");
		}
		Thread.sleep(3000);
		driver.navigate().refresh();
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println("Error Occurred"); 
		}
				
	}

}
