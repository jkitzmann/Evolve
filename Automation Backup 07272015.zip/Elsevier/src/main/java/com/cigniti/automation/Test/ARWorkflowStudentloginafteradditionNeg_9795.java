package com.cigniti.automation.Test;

import java.util.Arrays;
import java.util.Random;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.AR_BusinessFunction;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.HESI_BusinessFunction;
import com.cigniti.automation.BusinessFunctions.Instructor_ViewStudentLogIn_8563;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;
public class ARWorkflowStudentloginafteradditionNeg_9795 extends Instructor_ViewStudentLogIn_8563{
	Random ra = new Random( System.currentTimeMillis() );
	@Test
	public void ARWorkflowStudentloginafteradditionNeg9795() throws Throwable{
	
	//	try 
		{
		 //      HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		  
		        String EvolveId=ReadingExcel.columnDataByHeaderName("Catalogs", "TC-8563AndTC-8565", configProps.getProperty("TestData"));
		        String userFirstName=tc_9798.get("user_firstname");
				String facultyLastName=tc_9798.get("faculty_lastname");
				String studentLastName=tc_9798.get("student_lastname");
				Random ra = new Random( System.currentTimeMillis() );
				emailAdress=tc_9798.get("user_email")+Integer.toString((1 + ra.nextInt(2)) * 10000 + ra.nextInt(10000))+"@evolveqa.info";
				String password=tc_9798.get("user_pwd");
				
		        String Firstname=tc_9798.get("user_firstname");
		        String Lastname=tc_9798.get("student_lastname");
		        String Emailid=tc_9798.get("user_email")+Integer.toString((1 + ra.nextInt(2)) * 10000 + ra.nextInt(10000))+"@evolveqa.info";
		        String Instution=ReadingExcel.columnDataByHeaderName("Institution", "TC-9795", configProps.getProperty("TestData"));
		        String Mobile=ReadingExcel.columnDataByHeaderName("Phone", "TC-9795", configProps.getProperty("TestData"));
		        String Address1=ReadingExcel.columnDataByHeaderName("Address1", "TC-9795", configProps.getProperty("TestData"));
		        String Address2=ReadingExcel.columnDataByHeaderName("Address2", "TC-9795", configProps.getProperty("TestData"));
		        String Country=ReadingExcel.columnDataByHeaderName("Country", "TC-9795", configProps.getProperty("TestData"));
		        String State=ReadingExcel.columnDataByHeaderName("State", "TC-9795", configProps.getProperty("TestData"));
		        String City=ReadingExcel.columnDataByHeaderName("City", "TC-9795", configProps.getProperty("TestData"));
		        String Program=ReadingExcel.columnDataByHeaderName("Program", "TC-9795", configProps.getProperty("TestData"));
		        String ZipCode=ReadingExcel.columnDataByHeaderName("ZipCode", "TC-9795", configProps.getProperty("TestData"));
		        String Year=ReadingExcel.columnDataByHeaderName("Year", "TC-9795", configProps.getProperty("TestData"));
		        
		        stepReport("Go to Evolve Student homepage");
		        writeReport(SwitchToBrowser(ElsevierObjects.studentBrowserType),"Launching Browser to Portal User","Launching Browser to Portal User is succesful","Lanching Browser to Portal User is failed");
			
		    	String Catalogs=ReadingExcel.columnDataByHeaderName("Catalogs", "TC-8563AndTC-8565", configProps.getProperty("TestData"));
			    writeReport(User_BusinessFunction.LaunchStudent(),"Launch URL navigate to Student View",
                    "Launching the URL as Student is successful </br > Navigate to Student View is Successful",
                    "Launching the URL as Student is Not successful or </br > Navigate to Student View is Not Successful");

		    Thread.sleep(medium);
		
			stepReport("Add Online Course to cart and begin checkout");
		    writeReport(User_BusinessFunction.SearchCatalog(Catalogs),"Searching for Value:"+Catalogs,
		                                                                   "Entered "+Catalogs+" to Search </br > Click on Go Button ",
		                                                                   "Unable to Search for : "+ Catalogs);
		    Thread.sleep(medium);	
		    
		    writeReport(User_BusinessFunction.VerifyISBN(Catalogs), "Verify User Navigated to Product Results Page", "Page Navigate to Product Results Page of ISBN :"+Catalogs, "Page Not Navigated to Product Results Page of ISBN:"+Catalogs);
		    writeReport(AR_BusinessFunction.addToCartStudent(),"Add the product from results to cart ", "Successfully Added the "+Catalogs+" product to cart </br> The Product :"+Catalogs+" Price is verified and the Current Price "+price,  "Failed to Add the product to cart "+sgErrMsg);
		    Thread.sleep(medium);	

		   stepReport("Enter account info");
		    writeReport(AR_BusinessFunction.UpdateAccountDetails_Student(EvolveId,Firstname,Lastname,password,Emailid,Instution,Mobile,Address1,Address2,Country,State,City,ZipCode,Program,Year),"Student User Created Successfully","Student User Created Successfully with User FirstName:"+Firstname+"</br>User LastName:"+Lastname+"</br> User Password"+password,"Entered Values are not Submitted");
		    	
		    stepReport("Enter credit card info");
		   if(creditCardDetails())
			{
				Reporters.SuccessReport("Credit Card Details Entred Succesfully ", "Credit Card Details Enterd");
			}
	       else{
				Reporters.failureReport("Credit Card Details Entred Not Succesfully", "Credit Card Details not Enterd"); 
			}
		   Thread.sleep(high); 
		   
		   stepReport("Submit the order");
		   writeReport(AR_BusinessFunction.reviewAndSubmit_NewStudent(),"Reviewing the Order  and  Clicking on Submit:", "Check box  'Yes, I am an instructor' is Present in the page </br> Check Box 'Yes, I accept the Registered User Agreement' is Present in the page</br></br> The Product :"+Catalogs+" Price is verified and the Current Price is $0.00</br> Total Price is: $0.00 </br> The Order  Successfully Reviewed and Submitted</br>The Confirmed Order Number is :"+Ordernumber,  "The Order Failed to Review and Submit");
		    Thread.sleep(high);
			writeReport(AR_BusinessFunction.getUsernameandDetails(), "Fetching Account Details From MyAccount Page.", 
					"Successfully Fetched FirstName: "+getAccountDetailsFirstName+"</br>Successfully Fetched Last name: "+getAccountDetailsLastName+"</br> User Name"+getAccountDetailsUserName, 
					"Failed to Fetch Account Details From MyAccount Page. ");
			writeReport(instructorLogout(),"LogOut as Student User", "Student Loged Out Successfully","Student Log out Failed.");
			Thread.sleep(high);
			
		    stepReport("Login to Evolve Admin and verify no AR was created");
			writeReport(SwitchToBrowser(ElsevierObjects.adminBrowserType),"Launching Browser for Admin User","Launching Browser for Admin User is succesful","Lanching Browser for Admin User is failed");
			writeReport(evolveAdminlogin(),"Admin login ", "Admin Login is Successful","Admin Login is failed");
			writeReport(AR_BusinessFunction.clickAdoptionRequest(getAccountDetailsUserName),"Click on the AR","AR Search results page is displayed","AR Search results page are not displayed");
			Thread.sleep(medium);
			String AliasName=getAccountDetailsLastName+", "+getAccountDetailsFirstName;
         	String[] Headers = {"Name","Status"};
			
			String[] resultsassertions = {AliasName,"Pending"};
			///Thread.sleep(40000);
			
			writeReport(AR_BusinessFunction.VerifyNoContent(ElsevierObjects.Admin_ArResults,Headers,resultsassertions), "Verifying the Status of Adoption Request Results:",
                    "In Results, The Values Under The Title:"+Arrays.toString(Headers)+" And </br> Values: "+Arrays.toString(resultsassertions)+"are Not Maching as Expected", 
                    "In Results, The Values Under The Title:"+Arrays.toString(Headers)+" And </br> Values: "+Arrays.toString(resultsassertions)+"are is Maching as Not Expected");
            Thread.sleep(medium);

            writeReport(adminLogout(),"Clicked on Logout","Successfully Clicked on Logout","Not Clicked on Logout ");
		  
		}	
		
	} 
	@AfterTest
	public void tear() throws Throwable{
	
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
	
