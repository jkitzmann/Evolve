package com.cigniti.automation.Test;


import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.Evolve_StudentLogin_9795;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101;
import com.cigniti.automation.BusinessFunctions.SelfEnrollLOCourseHomePage_10302;
import com.cigniti.automation.BusinessFunctions.SelfEnrollLOCourseHomePage_10303;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class SelfEnrollLOCourseHomePage_10302_Script extends SelfEnrollLOCourseHomePage_10302{
	
	@Test
	public void SelfEnrollLOCourseHomePage10302() throws Throwable{
    String courseid, isbn, title;
	try{
		
	       //HtmlReporters.currentTimeList.add(System.currentTimeMillis());

		//Step 1:Complete test cases:  LO Unique Course Fulfillment-Faculty and capture the product id
		LO_Unique_CourseFulfillment_Faculty_Script_10410 k=new LO_Unique_CourseFulfillment_Faculty_Script_10410();
		k.loUniqueCoursefulfillmentFaculty_10410();
		
		//un-comment below line to run without step1 for debugging purpose
		//courseid="104882_einstein_1083";
		courseid=EvolveCommonBussinessFunctions.courseID1;
		
		isbn=EvolveCommonBussinessFunctions.adoptionRequest_Isbn;
		//un-comment below line to run without step1 for debugging purpose
		//isbn="9780323055536";
		
		title=EvolveCommonBussinessFunctions.title;
		//un-comment below line to run without step1 for debugging purpose
		//title="Medical Terminology Online for Mastering Healthcare Terminology";
		testCaseName ="SelfEnrollLOCourseHomePage_10302_Script";
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		
		
		//Step 2 : Log into evolve admin cert.  Maintain Products.Search for the ISBN from step #1.Click on the ISBN.Click on the Create Access Code tab.
		//Step 3 : Enter a unique value for "Code Set Name" field Uses per Code = 1	Number to generate = 10.	SAVE 
		//writeReport(User_BusinessFunction.Logout(),"Logout","Logout user successful","Logout User failed");
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login to Application Using Admin Credentials"+adminUser,
				"Launching the URL for Admin is successful </br > Login to Application Using Admin credentials :"+adminUser+" is Successful", 
				"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");
		
		writeReport(LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.maintainProductLink(isbn), "Clicking Maintain products link in Admin Page And Searching For ISBN:"+iSBN, 
				"Successfully Clicked on Maintain Product Link in Admin Page. </br> Successfully entered ISBN:"+isbn+" in Search box. </br> Successfully Clicked on Search Button.</br>Successfully Navigated To Product Search Result Page.", 
				"Failed to Click on Maintain Product Link in Admin page.</br>Failed To Search For ISBN:"+isbn);
		
		SelfEnrollLOCourseHomePage_10302.productSearchResultPage(isbn);

		SelfEnrollLOCourseHomePage_10302.verifySchemeIdAndCreateAccessCode();
		
		EvolveCommonBussinessFunctions.manageAccessCode();
		
		writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout as "+adminUser,
				"Successfully logged out admin page.", 
			  	"Failed to logout admin page.");	
		
		//Step 4:Create Student User from Student Page 
		writeReport(EvolveCommonBussinessFunctions.CreateNewUser("student"),"Creating Student User From Student Page.", 
				"Successfully Created New Student User Username:"+credentials[0]+",Password:"+credentials[1]+"</br>User Now logged Into Evolve Cert As A Student.",
				"Failed To Create New Student User.");
				
		
		//Step 5 : Click on Catalog tab. Click online course honeypot and choose to enroll into a course. 
		//Enter the course ID from Step #1 and submit
		EvolveCommonBussinessFunctions.verifyHoneyPot();
		
		//Step6 : Verify the correct self enrollment course info displays in the cart.
		SelfEnrollLOCourseHomePage_10302.selfEnrollNavigate(courseid,isbn,title);
		
		SelfEnrollLOCourseHomePage_10303.verifyMyCart();
		
		String courseId="Course ID";
		SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentCourseInfo(courseID1, courseId);
		
		String Title="Title";
		SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentCourseInfo(newTitle,Title);
		
		String firstname="FirstName";
		String educatorName=getAccountDetailsFirstName+" "+getAccountDetailsLastName;
		String FirstName=getAccountDetailsFirstName;
		SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentFacultyName(educatorName, FirstName,firstname);
		
		String lastname="Lastname"; 
		String LastName=getAccountDetailsLastName;
		SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentFacultyName(educatorName,LastName, lastname);
		
		String institutionName=getAccountDetailsInstitution;
		String Institution="Institution";
		SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentCourseInfo(institutionName, Institution);
		
		String applyAccesscode="true";
		SelfEnrollLOCourseHomePage_10303.applyAccessCodeInMycart(applyAccesscode);
		
		SelfEnrollLOCourseHomePage_10303.verifyCheckout();		
		//Step7&8 verify review/submit checkout, Address validation popup
		//EvolveCommonBussinessFunctions.updateVSTandKNOAccount("student","","false","");
		
		String user="student";
		SelfEnrollLOCourseHomePage_10303.clickNoInstitution(user);
		//Step 9 and 10:Enter credit card details , Review and Submit
		
		SelfEnrollLOCourseHomePage_10303.StudentReviewandSubmit();
		
		SelfEnrollLOCourseHomePage_10303.verifyReceiptPage();
		
		//Step 11 and 12: Click on My evolve and chk the course id appears under 0content list
		SelfEnrollLOCourseHomePage_10303.verifyMyEvolveCourseId();
		
		//step 13: click on the library folder titled course
		SelfEnrollLOCourseHomePage_10303.verifyCoursePage();
		
		//Step 14: Logout of evlove cert and login as admin
		writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the Student page.", 
				"Sucecssfully logged out the Student:"+credentials[0], 
				"Failed to logout the Student page:"+credentials[0]);
		
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login to Application Using Admin Credentials"+adminUser,
				"Launching the URL for Admin is successfull </br > Login to Application Using Admin credentials :"+adminUser+" is Successfull", 
				"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");
		
		String Accesscode="true";
		EvolveCommonBussinessFunctions.verifyCoursePARReport(courseid,Accesscode);
		
		//Step 15 : course validation in Evolve Admin link
		EvolveCommonBussinessFunctions.verifyMyEvolveAdmin(courseid);
		
		SelfEnrollLOCourseHomePage_10302.EvolveBreadCrumb();
		
		adminAccessCodeSearch();
		
		if(adminLogout()){
			Reporters.SuccessReport("Admin logout as "+adminUser,"Successfully logged out admin page.");
		}
		else{
			Reporters.failureReport("Admin logout as "+adminUser,"Failed To log out admin page.");
		} 
	
	//	String user="student";
		String studentUser=ReadingExcel.columnDataByHeaderName("username", "TC-10302", testDataPath);
		String StudentPwd=ReadingExcel.columnDataByHeaderName("password", "TC-10302", testDataPath);
		writeReport(SelfEnrollLOCourseHomePage_10303.studentLogin(studentUser,StudentPwd),"Launching The URL And Login to Application",
				"Launching the URL for User is successfull </br > Login to Application Using User credentials :"+studentUser+" is Successfull",
				  "Launching and Login to Application Using User credentials : "+ studentUser+" is Failed");
		
		EvolveCommonBussinessFunctions.verifyHoneyPot();
		
		//Step6 : Verify the correct self enrollment course info displays in the cart.
		String courseid2=EvolveCommonBussinessFunctions.courseID2;
		SelfEnrollLOCourseHomePage_10302.selfEnrollNavigate(courseid2,isbn,title);
		
		SelfEnrollLOCourseHomePage_10303.verifyMyCart();
		
		String invalidAccesscode="false";
		SelfEnrollLOCourseHomePage_10303.applyAccessCodeInMycart(invalidAccesscode);
		
		writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the Student page.", 
				"Sucecssfully logged out the Student:"+studentUser, 
				"Failed to logout the Student page:"+studentUser);
		
		
	}catch(Exception e){
		System.out.println(e.getMessage());
	}
	
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
	
	
}
