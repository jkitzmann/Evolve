package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.VitalSourceAccountAC_HomePage_StudentExists_VST;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class VitalSourceAccount_Pageburst_CC_NewInstructor_Script_15242 extends EvolveCommonBussinessFunctions {
	
	@Test 
	public void vitalSourceAccount_Pageburst_CC_NewInstructor_15242() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			
			String user = "educator";
			writeReport(Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions.CreateNewUser("educator", "VitalSourceAccountPageburstCCNewInstructor15242", "VSTPageBurstCredentials", 1, 1,2,0), "Create New Faculty user", "Successfully created new Faculty user with credentials: <br> Username: "+credentials[0]+"<br> Password : "+credentials[1], "Failed to create a new Faculty account");
			/*if(CreateNewUser(user))
			{
	     		Reporters.SuccessReport("Create Faculty User from Faculty Page", "Successfully Created Faculty user with the following credentials: <br> Faculty Username : "+EvolveCommonBussinessFunctions.credentials[0]+"<br> Faculty Password : "+EvolveCommonBussinessFunctions.credentials[1]+"<br> Succussfully logged into the application as faculty user");
			}
			else
			{
				Reporters.failureReport("Create Faculty User from Faculty Page", "Failed to Create Faculty user <br> Failed to logged into the application as faculty user");
			}*/
			String name = "VST";
			String accessCode = "false";
			String knoUser="newuser";
			VSTandKnoSearch(name,accessCode);
			
			updateVSTandKNOAccount(user,name,accessCode,knoUser);
			
			creditCardDetails(ElsevierObjects.CreditCardSubmit);
			String KNOIsbn=null;
			if(userReviewSubmit(user,accessCode,KNOIsbn))
			{
	     		Reporters.SuccessReport("Review and submit page:" ,"Successfully entered to review and submit page");
			}
			else
			{
				Reporters.failureReport("Review and submit page:", "Failed to enter review and submit page");
			}
			String accessCodeUser="educator";
			
			VitalSourceAccountAC_HomePage_StudentExists_VST.pageburstVstLink(accessCodeUser,titleInReceiptPage,"myCartTitle");
			ReadingExcel.removeUsedVSTCode(VSTDataPath, "VSTCodes");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ReadingExcel.removeUsedVSTCode(VSTDataPath, "VSTCodes");
		}
	}
	@AfterTest
	public void closeBrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}

