package com.cigniti.automation.Test;

import java.util.Random;

import jxl.Sheet;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.PromotionVariablePercentageExclusions_15581;
import com.cigniti.automation.BusinessFunctions.PromotionVariablePercentageInclusions_10227;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class PromotionVariablePercentageExclusions_Script_15581 extends PromotionVariablePercentageExclusions_15581{

	public static String DMCodeForUse;
	Random ra = new Random( System.currentTimeMillis() );

	@Test
	public void promotionVariablePercentageExclusions_15581() throws Throwable
	{
		SwitchToBrowser(ElsevierObjects.adminBrowserType);

		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		String DMCode=ReadingExcel.columnDataByHeaderName("DMcode", "PromotionTestData",configProps.getProperty("TestData"))+Integer.toString((1 + ra.nextInt(2)) * 100000 + ra.nextInt(100000));
		String PromotionCode=ReadingExcel.columnDataByHeaderName("PromotionCode", "PromotionTestData",configProps.getProperty("TestData"));
		String DiscountType=ReadingExcel.columnDataByHeaderName("DiscountType2", "PromotionTestData",configProps.getProperty("TestData"));
		String CampaignCode=ReadingExcel.columnDataByHeaderName("CampaignCode", "PromotionTestData",configProps.getProperty("TestData"));
		String PromotionName=ReadingExcel.columnDataByHeaderName("PromotionName", "PromotionTestData",configProps.getProperty("TestData"));
		String TerritoryCode=ReadingExcel.columnDataByHeaderName("TerritoryCode", "PromotionTestData",configProps.getProperty("TestData"));
		String percentageOff=ReadingExcel.columnDataByHeaderName("PercentageOff", "PromotionTestData",configProps.getProperty("TestData"));
		String percentageOff1=ReadingExcel.columnDataByHeaderName("PercentageOff1", "PromotionTestData",configProps.getProperty("TestData"));
		String invalidPercentage=ReadingExcel.columnDataByHeaderName("invalidPercentage", "PromotionTestData",configProps.getProperty("TestData"));
		String percentage=ReadingExcel.columnDataByHeaderName("percentage", "PromotionTestData",configProps.getProperty("TestData"));		

		DMCodeForUse=DMCode;
		Reporters.SuccessReport("", "");
		writeReport(evolveAdminlogin(),"Login to Application Using Admin Credentials :"+adminUser,
				"Launching the URL for Admin Credentials is successful </br > Login to Application Using Admin Credentials :"+adminUser+" is Successful",
				"Launching and Login to Application Using Admin Credentials : "+ adminUser+" is Failed");
		Thread.sleep(medium);

		writeReport(PromotionVariablePercentageInclusions_10227.addPromotionLink(), "Adding New Promotions", 
				"Clicking on Promotion Link is successful",
				"Failed to click on Promotion Link");
		Thread.sleep(medium);
		writeReport(PromotionVariablePercentageInclusions_10227.validatePromotionCodeValues(),  "Validate all elements in the Promotion Code Section", "Promotion Code Section elements are validated", "Promotion Code Section elements validation failed");
		Thread.sleep(medium);
		String user="variablePercentage";

		writeReport(inputValuesInPromotionCode(user, DMCode, "", "", DiscountType, "", PromotionName, TerritoryCode, ""),  
				"Fill all the mandatory fields in Promotion Type under Add Promotion", 
				"Details are filled successfully: DM Code : "+DMCode+"<br> Discount Type : "+user+ "<br> Promotion Name : "+PromotionName+"<br> Territory Code : "+TerritoryCode+"<br> Promotion Name : "+percentageOff,
				"Failed to fill Details : DM Code : "+DMCode+"<br> Discount Type : "+user+ "<br> Promotion Name : "+PromotionName+"<br> Territory Code : "+TerritoryCode+"<br> Promotion Name : "+percentageOff+"<br> Promotion successfully saved. ");

		Thread.sleep(medium);

		/*writeReport(EvolveCommonBussinessFunctions.adminLogout(),"Clicking on Logout",
                     "Clicking on Logout is Successful",
                     "Clicking on Logout is not Successful");*/

		Thread.sleep(medium);
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login as Admin User", "Login as amdin user is Successful",
				"Login Failed");

		writeReport(PromotionVariablePercentageExclusions_15581.maintainPromotion(DMCodeForUse),  
				"Click on the Maintain Promotion Link and Navigate to the Next Page", 
				"Maintain Promtion Link is successfully clicked and navigated to the next page</br> Bread Crumb is present and Blank Promotion page is available", 
				"Maintain Promtion Link is failed to click and failed to navigate to the next page</br> Bread Crumb is not present");

		writeReport(PromotionVariablePercentageExclusions_15581.verifyTextExcludeProducts(),  
				"Click on the Maintain Promotion Link and Navigate to the Next Page", 
				"Maintain Promtion Link is successfully clicked and navigated to the next page</br> Bread Crumb is present and Blank Promotion page is available", 
				"Maintain Promtion Link is failed to click and failed to navigate to the next page</br> Bread Crumb is not present");

		String condition="exclusions";

		/*			validateDifferentSection(user, comboBox, addBtn, percentField, percentage1, percentage2, percFailMsg, sucMsg, 
					backgroundColor, selectOption1, selectOption2, rmvLink, anyTextField, percRowValue, selectOptionFinal, viewAllLink)*/
		Reporters.SuccessReport("Validate the Profit Center section.", "Validate the Profit Center section");
		writeReport(PromotionVariablePercentageExclusions_15581.validateDifferentSection("",ElsevierObjects.Promotion_ExclusionVariable_FinalOption,condition,ElsevierObjects.Promotion_ExclusionVariable_ComboBox, 
				ElsevierObjects.Promotion_ExclusionVariable_ExcludeBtn, null, null, 
				null,ElsevierObjects.Promotion_ExclusionVariable_FailureMsg, 
				ElsevierObjects.Promotion_ExclusionVariable_SucMsg, ElsevierObjects.Promotion_ExclusionVariable_Background, 
				ElsevierObjects.Promotion_ExclusionVariable_Option1,ElsevierObjects.Promotion_ExclusionVariable_Option2, 
				ElsevierObjects.Promotion_ExclusionVariable_RemLnk, null, 
				ElsevierObjects.Promotion_ExclusionVariable_RowValue, ElsevierObjects.Promotion_ExclusionVariable_FinalOption, ElsevierObjects.Promotion_ExclusionVariable_Viewall),
				"Validate Include all Product Section","All Products in Profit Center Section are validated successfully", 
				"Include all Products in Profit Center Product Section validation failed");

		Reporters.SuccessReport("Validate the Major Subject Code section.", "Validate the Major Subject Code section.");
		writeReport(PromotionVariablePercentageExclusions_15581.validateDifferentSection("",ElsevierObjects.Promotion_ExclusionVariable_MajFinalOption,condition,ElsevierObjects.Promotion_ExclusionVariable__MjrComboBox, 
				ElsevierObjects.Promotion_ExclusionVariable_MajExcludeBtn, null, null, 
				null,ElsevierObjects.Promotion_ExclusionVariable_FailureMsg, 
				ElsevierObjects.Promotion_ExclusionVariable_SucMsg, ElsevierObjects.Promotion_ExclusionVariable_MajBackground, 
				ElsevierObjects.Promotion_ExclusionVariable_Majoption1,ElsevierObjects.Promotion_ExclusionVariable_MajOption2, 
				ElsevierObjects.Promotion_ExclusionVariable_MajRem, null, 
				ElsevierObjects.Promotion_ExclusionVariable_MajRowValue, ElsevierObjects.Promotion_ExclusionVariable_MajFinalOption, ElsevierObjects.Promotion_ExclusionVariable_MajViewAll),
				"Validate Include all Product Section","All Products in Profit Center Section are validated successfully", 
				"Include all Products in Profit Center Product Section validation failed");

		Reporters.SuccessReport("Validate the Product Type section.", "Validate the Product Type section.");
		writeReport(PromotionVariablePercentageExclusions_15581.validateDifferentSection( "",ElsevierObjects.Promotion_ExclusionVariable_ProFinalOption,condition,ElsevierObjects.Promotion_ExclusionVariable__ProComboBox, 
				ElsevierObjects.Promotion_ExclusionVariable_ProExcludeBtn, null, null, 
				null,ElsevierObjects.Promotion_ExclusionVariable_FailureMsg, 
				ElsevierObjects.Promotion_ExclusionVariable_SucMsg, ElsevierObjects.Promotion_ExclusionVariable_ProBackground, 
				ElsevierObjects.Promotion_ExclusionVariable_Prooption1,ElsevierObjects.Promotion_ExclusionVariable_ProOption2, 
				ElsevierObjects.Promotion_ExclusionVariable_ProRem, null, 
				ElsevierObjects.Promotion_ExclusionVariable_ProRowValue, ElsevierObjects.Promotion_ExclusionVariable_ProFinalOption, ElsevierObjects.Promotion_ExclusionVariable_ProViewAll),
				"Validate Include all Product Section","All Products in Profit Center Section are validated successfully", 
				"Include all Products in Profit Center Product Section validation failed");
		Thread.sleep(medium);
		writeReport(validateISBNSection(),
				"Validate ISBN Section", "Include all Products in ISBN Section are validated is successfully", 
				"Include all Products in ISBN Section validation failed");

		Thread.sleep(medium);
		uploadCSVFile();


		//Thread.sleep(medium);
		//writeReport(PromotionVariablePercentageInclusions.validateSelectAllProducts(),  "Select All Products", "Select All Products section validation is successful", "Select All Products section validation failed");
		//Validating the ISBN Section

	}		

	@AfterClass
	public static void browserStop() throws Throwable
	{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}


