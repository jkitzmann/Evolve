package com.cigniti.automation.BusinessFunctions;



import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class KNOACfromMyCart_Instructor_15237 extends EvolveCommonBussinessFunctions {

	public static boolean updateMyCartAccount(String user) throws Throwable{
	    boolean flag = true; 
	    String knoPassword=readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("Kno&VST_Pwd");
	    try{

		      if(click(ElsevierObjects.student_chkInstution,"Click on NO Institution Check box")){
		    	  Reporters.SuccessReport("Clicking On Not Affiliated Check box for "+user, "Successfully Clicked On Not Afiliated with Institution CheckBox.");
		      }
		      else{
		    	  Reporters.failureReport("Clicking On Not Affiliated Check box for "+user, "Failed To Click On Not Afiliated with Institution CheckBox.");
		      }
		      Thread.sleep(medium);
		      if(type(ElsevierObjects.evolve_User_KnoPwd,knoPassword,"Enter Kno password")){
		      	 Reporters.SuccessReport("Entering KNO Password.", "Successfully Entered KNO Password: "+knoPassword);
		      }
		      else{
		    	  Reporters.failureReport("Entering KNO Password.", "Failed To Enter KNO Password: "+knoPassword);
		      }
		      if(isChecked(ElsevierObjects.evolve_User_chkbx, "Check box")){
		    	 if(click(ElsevierObjects.evolve_User_submitbtn,"Click submit button")){
		    		 	Reporters.SuccessReport("Updating Account Information Of The "+user+".</br>Clicking On Submit Button.", "Successfully Entered Account Information.</br>Successfully Entered The KnoPassword: "+knoPassword+".</br>Successfully Clicked On Submit Button.</br>Successfully Navigated to Review And Submit Page.");
		    	 }
		    	 else{
		    		 	Reporters.failureReport("Updating Account Information Of The "+user+".</br>Clicking On Submit Button.", "Failed To Enter Account Information.</br>Failed To Enter The KnoPassword: "+knoPassword+".</br>Failed To Click On Submit Button.");
		    	 }
		    	 Thread.sleep(medium);
		      }
		      else{
		    	 if(!click(ElsevierObjects.evolve_User_chkbx, "Click check box")){
		    		 flag=false;
		    	 }
		    	 Thread.sleep(medium);
		    	 if(click(ElsevierObjects.evolve_User_submitbtn,"Click submit button")){
		    		 if(click(ElsevierObjects.evolve_User_submitbtn,"Click submit button")){
		    			 	Reporters.SuccessReport("Updating Account Information Of The "+user+".</br>Clicking On Submit Button.", "Successfully Entered Account Information.</br>Successfully Entered The KnoPassword: "+knoPassword+".</br>Successfully Clicked On Submit Button.</br>Successfully Navigated to Review And Submit Page.");
		    		 }
		    		 else{
		    			 	Reporters.failureReport("Updating Account Information Of The "+user+".</br>Clicking On Submit Button.", "Failed To Enter Account Information.</br>Failed To Enter The KnoPassword: "+knoPassword+".</br>Failed To Click On Submit Button.");
		    		 }
		    	 }
		    	 Thread.sleep(medium);
		     	}
		      	/*//for submit button checK
			     if(accessCode.equalsIgnoreCase("false")){
			      if(!switchToFrameByLocator(ElsevierObjects.Student_register_frame, "Switch to frame")){
			       flag=false;
			      }
			      if(click(ElsevierObjects.Student_register_UseAdress_btn,"Click on use this address button")){
			       Reporters.SuccessReport("Clicking On USE THIS ADRESS Button In Popup.", "Successfully Clicked On USE THIS ADRESS Button In Popup.</br>Successfully Navigated To Credit Card Details Page.");
			      }
			      else{
			       Reporters.failureReport("Clicking On USE THIS ADRESS Button In Popup.", "Failed to Click On USE THIS ADRESS Button In Popup.</br>Failed to Navigate To Credit Card Details Page.");
			      }
			      Thread.sleep(medium);
			     }*/
			    }
	    catch(Exception e){
	     System.out.println(e.getMessage());
	    }
	    return flag;
	   }
	public static boolean KnoSearch() throws Throwable{
		   boolean flag = true;
		  try{
		 //  VSTIsbn=readcolumns.twoColumns(0, 1, "createNewaccount", configProps.getProperty("TestData")).get("VST_Number");
		   KNOIsbn=readcolumns.twoColumns(0, 1, "Tc-15228", configProps.getProperty("TestData")).get("kno_num");

		    Thread.sleep(low);
			driver.switchTo().defaultContent();
			Thread.sleep(low);
		   
		   if(click(ElsevierObjects.evolveCatlog_lnk,"Evolve catalog link")){
			   Reporters.SuccessReport("Clicking On Evolve Catalog Link.", "Successfully Clicked On Evolve Catalog Link.</br>Successfully Displayed Honey Pot Page.");
		   }
		   else{
			   Reporters.failureReport("Clicking On Evolve Catalog Link.", "Failed Clicked On Evolve Catalog Link.</br>Failed To Display Honey Pot Page.");
		   }
		   Thread.sleep(medium);
		   //knoNumber=readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("kno_num");
		   if(type(ElsevierObjects.txtproductsearch,KNOIsbn,"Enter KNO Number")){
		      Reporters.SuccessReport("Entering KnoISBN in Search Box.", "Successfully Entered Kno ISBN: "+KNOIsbn+" in Search Box.</br>Successfully Navigated To Product details Page.");
		   }
		   else{
		      Reporters.failureReport("Entering KnoISBN in Search Box.", "Failed To Enter Kno ISBN: "+KNOIsbn+" in Search Box.</br>Failed To Navigate To Product details Page.");
		   }
		   //click on Go button
		   if(!click(ElsevierObjects.gobutton,"Click Go button")){
		    flag=false;
		   }
		   Thread.sleep(medium);
		   price_beforerequest=getText(ElsevierObjects.evolve_Product_pricebeforerequest,"Product price before request");   
		   title_beforerequest=getText(ElsevierObjects.evolve_Product_titlebeforerequest,"Product title");
		   IsbnBeforeRequest=getText(ElsevierObjects.evolve_verify_isbn,"Isbn num");
		   if(KNOIsbn.contains(IsbnBeforeRequest)){
			   try
			   {
				   if(click(ElsevierObjects.evolve_Request_Product,"Click request product button")){
			    	  Reporters.SuccessReport("Verifying KnoISBN And Clicking On Request Product Button.", "Successfully Verified the KnoISBN: "+IsbnBeforeRequest+". </br>Successfully Clicked On Request Product Button.</br> Successfully Navigated To MyCart Page. "); 
				   }
				   else{
			    	  Reporters.failureReport("Verifying KnoISBN And Clicking On Request Product Button.", "Failed To Verify the KnoISBN: "+IsbnBeforeRequest+". </br>Failed To Click On Request Product Button.</br> Failed To Navigate to MyCart Page. ");
				   }
				   Thread.sleep(high);
			   }
			   catch(Exception e){
				   Thread.sleep(medium);
				   if(!click(ElsevierObjects.Mycart_alert,"Click on my cart alert")){
					   flag=false;
			   }
		   }
		   Thread.sleep(high);
		   price_afterRequest=getText(ElsevierObjects.evolve_Product_priceAfterRequest,"Product price after request");
		   title_afterRequest=getText(ElsevierObjects.evolve_Product_titleAfterRequest,"Title After request");
		  
		   //if there is no access code this block is executed
		   if(price_beforerequest.contains(price_afterRequest) && title_afterRequest.trim().contains(title_beforerequest.trim())){
			   if(isChecked(ElsevierObjects.acess_chkbx,"Check radio button")){
				   	if(click(ElsevierObjects.evolve_checkout_btn,"Click Reedem checkout button")){
				   			Reporters.SuccessReport("Verify Product Details in MyCart Page And Clicking On Reedeem CheckOut Button.", "Successfully verified Price: "+price_beforerequest+"</br> Successfully Verified ISBN: "+IsbnBeforeRequest+"</br>Successfully Verified Title: "+title_afterRequest+"</br> Successfully Clicked On Reedeem CheckOut Button.</br> Successfully Navigated to Update Account Page. "); 
				   	}
				   	else{
				   			Reporters.failureReport("Verify Product Details in MyCart Page And Clicking On Reedeem CheckOut Button.", "Failed To verify Price: "+price_beforerequest+"</br> Failed To Verify ISBN: "+IsbnBeforeRequest+"</br>Failed To Verify Title: "+title_afterRequest+"</br> Failed To Click On Reedeem CheckOut Button.</br>Failed To Navigate to Update Account Page.");
				   	}
				   	Thread.sleep(high);
			   }

		   	}
		   }
		  }
		  catch(Exception e){
			  System.out.println(e.getMessage());
		  }
		   return flag;
		  }

public static void ExistingStudentUpdateAccount() throws Throwable{
	try{
		click(ElsevierObjects.student_chkInstution,"Click on NO Institution Check box");
		
		// adding check for kno password field and filling in if present
		if(isElementPresent(ElsevierObjects.evolve_User_KnoPwd)){
			String knoPass = readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("Kno&VST_Pwd");
			if(type(ElsevierObjects.evolve_User_KnoPwd, knoPass, "Enter KNO password")){
				Reporters.SuccessReport("Entering KNO Password.", "Successfully Entered KNO Password: "+ knoPass);
			}
			else{
				Reporters.failureReport("Entering KNO Password.", "Failed To Enter KNO Password: "+ knoPass);
			}
		}
		
		click(ElsevierObjects.evolve_User_submitbtn,"Click submit button");
	}
	catch(Exception e){
		System.out.println(e.getMessage());
	}
}

}
