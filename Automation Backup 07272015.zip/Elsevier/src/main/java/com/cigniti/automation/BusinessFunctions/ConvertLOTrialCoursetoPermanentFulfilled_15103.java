package com.cigniti.automation.BusinessFunctions;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class ConvertLOTrialCoursetoPermanentFulfilled_15103 extends EvolveCommonBussinessFunctions {

	/**Generic method for searching adoption by Adoption Number
	 * 
	 * @return
	 * @throws Throwable
	 */
	public static boolean searchAdoptionByAdoptionNumber(String adoptionNumber) throws Throwable{
		boolean flag=true;
		try{
			type(ElsevierObjects.Admin_searchAdoptionByNumber, adoptionNumber, "Enter Adoption Number.");
			click(ElsevierObjects.Admin_searchAdoptionButton,"click Adoption search search button");
			Thread.sleep(medium);
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
		return flag;
		
	}
	/**Generic method for searching adoption link in admin portal.
	 *  
	 * @return
	 * @throws Throwable
	 */
	public static boolean clickOnSearchAdoptionLink() throws Throwable{
		boolean flag=true;
		try{
		click(ElsevierObjects.searchAR,"Adoption Requests");
		waitForElementPresent(ElsevierObjects.btndatesearch, "search button");
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
		return flag;
	}
	public static boolean verifytextInRosterRoles() throws Throwable{
	boolean flag=true;	
	try{
	String Roles=getText(ElsevierObjects.RosterRoles, "RosterRoles");
	if(Roles !=null){
		Reporters.SuccessReport("User is taken to the Preview Roles page.", "User is Successfully Navigated to Preview Roles Page.<br> Printing any text from the page <br> text : "+Roles);
	}
	else{
		Reporters.failureReport("User is taken to the Preview Roles page.", "User is Failed To Navigate To Preview Roles Page.");
	}
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
	
	return flag;
	}

}
