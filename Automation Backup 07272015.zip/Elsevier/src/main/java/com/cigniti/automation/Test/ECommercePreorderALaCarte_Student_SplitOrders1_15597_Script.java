package com.cigniti.automation.Test;

import java.util.List;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarteFaculty1_15459;
import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarte_Student_SplitOrders1_15597;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.KNO_Pageburst_CC_NewStudent_15231;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentFaculty_15243;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;
import com.cigniti.automation.datadriven.ReadExcel;
import com.thoughtworks.selenium.webdriven.commands.CaptureScreenshotToString;

public class ECommercePreorderALaCarte_Student_SplitOrders1_15597_Script extends ECommercePreorderALaCarte_Student_SplitOrders1_15597 
{
@Test
public void PreorderALaCarte_Student_SplitOrders1_15597() throws Throwable{
	try{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		String user="student";
		String ecommerceISBN1=ReadingExcel.columnDataByHeaderName("ecommerceISBN1", "TC-15597", configProps.getProperty("TestData"));
		String ecommerceISBN2=ReadingExcel.columnDataByHeaderName("ecommerceISBN2", "TC-15597", configProps.getProperty("TestData"));
		String ecommerceISBN3=ReadingExcel.columnDataByHeaderName("ecommerceISBN3", "TC-15597", configProps.getProperty("TestData"));
		String searchISBN4=ReadingExcel.columnDataByHeaderName("searchISBN4", "TC-15597", configProps.getProperty("TestData"));
		String searchISBN5=ReadingExcel.columnDataByHeaderName("searchISBN5", "TC-15597", configProps.getProperty("TestData"));
		//BILLING AND SHIPPING TESTDATA
		String studentStreet=ReadingExcel.columnDataByHeaderName("street", "TC-15597", configProps.getProperty("TestData"));
		String studentState=ReadingExcel.columnDataByHeaderName("state", "TC-15597", configProps.getProperty("TestData"));
		String studentCity=ReadingExcel.columnDataByHeaderName("city", "TC-15597", configProps.getProperty("TestData"));
		String studentZip=ReadingExcel.columnDataByHeaderName("pin", "TC-15597", configProps.getProperty("TestData"));
		
		
		
		
		/*String studentUsernmae=EvolveCommonBussinessFunctions.
		String StudentPassword="";*/
		String publicationDate=ReadingExcel.columnDataByHeaderName("publicationDate", "TC-15597", configProps.getProperty("TestData"));
		String publicationStatus=ReadingExcel.columnDataByHeaderName("PublicationStatus", "TC-15597", configProps.getProperty("TestData"));
	
		writeReport(EvolveCommonBussinessFunctions.CreateNewUser(user),"Creating New Student User","Successfully Created Ner Student User.</br>Username: "+credentials[0]+"</br> Password : "+credentials[1],
				"Failed To Create New Student User.");
		
		
		
		
		String studentUserName = EvolveCommonBussinessFunctions.credentials[0];
		String studentPaswword = EvolveCommonBussinessFunctions.credentials[1];
		ReadingExcel.updateCellInSheet(1, 33, testDataPath, "TC-15597", studentUserName);
		ReadingExcel.updateCellInSheet(1, 35, testDataPath, "TC-15597", studentPaswword);
		
		System.out.println("studentUserName=>>>>>"+EvolveCommonBussinessFunctions.credentials[0]);
		
		writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logging out the student page.", 
					"Succesfully logged out of student page.", 
					"Failed to logout student page.");
		 
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials"+adminUser,
	            "Launching the URL for User is successful </br > Login to Application Using User credentails :"+adminUser+" is Successful",
	            "Launching and Login to Application Using User credentails : "+ adminUser+" is Failed");
		
		manageAdminstrator();
		
		evolveBreadCrumb(); 
		
		editingResource(ecommerceISBN1);
		
		String futuretype="Future";
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.modifyingPublicatonDate(futuretype,publicationDate,publicationStatus);
		
		evolveBreadCrumb();

		editingResource(ecommerceISBN2);
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.modifyingPublicatonDate(futuretype,publicationDate,publicationStatus);
		
		evolveBreadCrumb();
		
		editingResource(ecommerceISBN3);
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.modifyingPublicatonDate(futuretype,publicationDate,publicationStatus);
		
		launchUrl(configProps.getProperty("NoCacheURL"));
		Thread.sleep(medium);
		
		driver.navigate().back();
		
		adminLogout();
	
		writeReport(User_BusinessFunction.Studentlogin(studentUserName, studentPaswword),"Login As Student User.",
				"Successfully Logged In Into Student Application As :"+studentUserName,
				"Failed To Login Into Application As Student :"+studentUserName);
		
		//String mssg="true";
		
		//String noMssg="false"
		String reserveButton=ReadingExcel.columnDataByHeaderName("reserveButton", "TC-15597", configProps.getProperty("TestData"));
		String preOrderButton=ReadingExcel.columnDataByHeaderName("preOrder", "TC-15597", configProps.getProperty("TestData"));
		String addToCartButton=ReadingExcel.columnDataByHeaderName("AddToCartButton", "TC-15597", configProps.getProperty("TestData"));
	
		
		searchISBNNumber(ecommerceISBN1,reserveButton,publicationDate,1);
		searchISBNNumber(ecommerceISBN3,preOrderButton,publicationDate,2);
		searchISBNNumber(searchISBN4,addToCartButton,publicationDate,3);
		searchISBNNumber(ecommerceISBN2,preOrderButton,publicationDate,4);
		searchISBNNumber(searchISBN5,addToCartButton,publicationDate,5);
		
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.Checkout();
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.updateAccount(user,studentStreet, studentCity, studentState, studentZip);
		Thread.sleep(medium);
		
		//CREDIT CARD TESTDATA
			String creditCardType=ReadingExcel.columnDataByHeaderName("cardType", "TC-15597", configProps.getProperty("TestData"));
			String creditCardNum=ReadingExcel.columnDataByHeaderName("cardNumber", "TC-15597", configProps.getProperty("TestData"));
			String creditCardCvv=ReadingExcel.columnDataByHeaderName("cardCVV", "TC-15597", configProps.getProperty("TestData"));
			String creditCardName=ReadingExcel.columnDataByHeaderName("cardName", "TC-15597", configProps.getProperty("TestData"));
			String creditCardExpYr=ReadingExcel.columnDataByHeaderName("cardExpYear", "TC-15597", configProps.getProperty("TestData"));
			String creditCardExpMnth=ReadingExcel.columnDataByHeaderName("cardExpMonth", "TC-15597", configProps.getProperty("TestData"));
		
		writeReport(ECommercePreorderALaCarte_Student_SplitOrders1_15597.CreditCardData(creditCardType,creditCardNum,creditCardCvv,creditCardName,creditCardExpMnth,creditCardExpYr),"Entering Credit Card details.",
				"Successfully Entered Credit Card Type:"+creditCardType+", Name:"+creditCardName+", Number:"+creditCardNum+", CVV:"+creditCardCvv+", Expiry Month:"+creditCardExpMnth+",year:"+creditCardExpYr,
				"Failed to Enter Credit Card Details.");
		
		Thread.sleep(veryhigh);
		verifyMessageInReviewPage(ecommerceISBN1,ecommerceISBN3,searchISBN4,ecommerceISBN2,searchISBN5,publicationDate);
		
		user="student";

		acceptAndContinue("",user);
		
		verifyMessageInReceiptPage(ecommerceISBN1,ecommerceISBN3,searchISBN4,ecommerceISBN2,searchISBN5,publicationDate);
		
		//String isbn="9780323091466"; 
		//fetchOrderNumberfromfirst(isbn);
		
		String subtotal=ReadingExcel.columnDataByHeaderName("subtotal", "TC_15459", testDataPath);
		String discountPrice=ReadingExcel.columnDataByHeaderName("discount", "TC_15459", testDataPath);	
		String tax=ReadingExcel.columnDataByHeaderName("tax", "TC_15459", testDataPath);
		String total=ReadingExcel.columnDataByHeaderName("total", "TC_15459", testDataPath);
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.verifyOrderPricesHeadings(subtotal,discountPrice,tax,total);
		
		
		
		String ISBN1=ecommerceISBN1+","+ecommerceISBN3+","+searchISBN4+","+ecommerceISBN2+","+searchISBN5;

		
	//	String ISBN1="9780323096447,9780323042178,9781437736335,9780323055314,9781455733255";

		fetchOrderNumberfromsecond(ISBN1);
		
		verifyOrderPagerDetails(ecommerceISBN1,ecommerceISBN3,searchISBN4,ecommerceISBN2,searchISBN5,publicationDate);
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.checkorderwithISBN(ordernumber2,ecommerceISBN1,"Yes");
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.checkorderwithISBN(ordernumber3,ecommerceISBN3,"Yes");
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.checkorderwithISBN(ordernumber1,ecommerceISBN2,"Yes");
		
		writeReport(ECommercePreorderALaCarte_Student_SplitOrders1_15597.getStudentAccountDetails(),"Get Account Details from My Account.",
				"Successfully got the account details from My Account page.",
				"Failed to get the account details from the My Account page.");
		
		
		writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the Student page.", 
				"Sucecssfully logged out the Student page.", 
				"Failed to logout the Student page.");
		
		//SwitchToBrowser("chrome");
		writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Login In Into Evolve Email Page.", 
																		  "Successfully login into Evolve Email Page.", 
																		  "Failed to login into Evolve Email Page.");
		String emailid=ECommercePreorderALaCarte_Student_SplitOrders1_15597.getAccountDetailsEmail;
		writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(emailid),"Search email in evolve webmail.",
															"Successfully entered the emailid "+emailid+" in search box.",
															"Failed to enter email id.");
				
		ECommercePreorderALaCarteFaculty1_15459.ordersVerificationInEmailBody(ordernumber1,ordernumber2,ordernumber3);
				
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials"+adminUser,
	            "Launching the URL for User is successful </br > Login to Application Using User credentails :"+adminUser+" is Successful",
	            "Launching and Login to Application Using User credentails : "+ adminUser+" is Failed");
		
		
		
		
		String studentFirstName=EvolveCommonBussinessFunctions.getAccountDetailsFirstName;
		String studentLastName=EvolveCommonBussinessFunctions.getAccountDetailsLastName;
		String UserName=EvolveCommonBussinessFunctions.getAccountDetailsUserName;
		String studentEmail=EvolveCommonBussinessFunctions.getAccountDetailsEmail;
		
		
		
		writeReport(ECommercePreorderALaCarte_Student_SplitOrders1_15597.viewOrEditUserProfile(UserName), "Clicking On View/Edit Profile link.", 
					"Successfully Clicked on View/Edit Profile Link.</br>Successfully Entered Username: "+studentUserName+"</br>Sucessfully Clicked On View Profile Search Button.",
					"Failed to click on View/Edit Profile.");
		
		writeReport(ECommercePreorderALaCarte_Student_SplitOrders1_15597.orderHistoryInAdmin(), "Clicking On OrderHistory Button.", 
					"Successfully Clicked On Oredr History Button.",
					"Failed To Click On Order History Button.");
		
		verifyCancelPreOrderButton(ecommerceISBN1);
		Thread.sleep(medium);
		verifyCancelPreOrderButton(ecommerceISBN3);
		Thread.sleep(medium);
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.cacelPreOrder(ecommerceISBN3);		
		Thread.sleep(medium);
		String popupmessage=ReadingExcel.columnDataByHeaderName("cancelPreOrderMessage", "TC-15597", configProps.getProperty("TestData"));
		String popupNote=ReadingExcel.columnDataByHeaderName("cancelPreOrderNote", "TC-15597", configProps.getProperty("TestData"));
		writeReport(ECommercePreorderALaCarte_Student_SplitOrders1_15597.verifyCancelPreOrderPopup(popupmessage,popupNote),"Verifying The Cancel Pre-order Confirmation popup.",
						"Successfully Verified Header Of The Confirmation popup.</br>Verified Message In Popup :"+popupmessage+"</br>Verified Note In Popup :"+popupNote+"</br>Successfully Verified Save And Cancel Buttons In Popup.",
						"Failed To Verify Header In Popup.Failed To Verify Message And Note InPopup.</br>Failed to Verify Save And Cancel buttons In Popup.");
		
		
		hitCancelButtonInPreOrderPopup();
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.cacelPreOrder(ecommerceISBN3);
		
		hitSaveButtonInCancelPreorder();
		
		verifyErrorMessage();
		
		String message=ReadingExcel.columnDataByHeaderName("message", "TC-15597", configProps.getProperty("TestData"));
	
		enterMessage(message);
		
		hitCancelButtonInPreOrderPopup();
		
		cacelPreOrder(ecommerceISBN3);
		
		enterMessage(message);
		
		hitSaveButtonInCancelPreorder();
		
		verifySaveMessage();
		
		String cancelStatus=ReadingExcel.columnDataByHeaderName("cancelStatus", "TC-15597", configProps.getProperty("TestData"));
		
		verifyStatusAfterCancel(message,cancelStatus);
	
		evolveBreadCrumb();
		
		editingResource(ecommerceISBN3);
		
		String pastpublicationDate=ReadingExcel.columnDataByHeaderName("pastDtae", "TC-15597", configProps.getProperty("TestData"));
		String newpublicationStatus=ReadingExcel.columnDataByHeaderName("newPublicationStatus", "TC-15597", configProps.getProperty("TestData"));
		
		String pasttype="past";
		modifyingPublicatonDate(pasttype,pastpublicationDate,newpublicationStatus);
	
		evolveBreadCrumb();
		
		editingResource(ecommerceISBN2);
	
		modifyingPublicatonDate(pasttype,pastpublicationDate,newpublicationStatus);
	
		evolveBreadCrumb();
		
		editingResource(ecommerceISBN1);
		
		modifyingPublicatonDate(pasttype,pastpublicationDate,newpublicationStatus);
	
		launchUrl(configProps.getProperty("NoCacheURL"));
		Thread.sleep(medium);
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
	}
}
	public void tear() throws Throwable{
	//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
