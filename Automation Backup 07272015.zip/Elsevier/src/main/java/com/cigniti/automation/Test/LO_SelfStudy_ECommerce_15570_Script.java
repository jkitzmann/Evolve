package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.LO_SelfStudy_ECommerce_15570_BussinessFunctions;
import com.cigniti.automation.BusinessFunctions.LO_Selfstudy_Access_Code_10412_Bussiness_Function;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class LO_SelfStudy_ECommerce_15570_Script extends LO_SelfStudy_ECommerce_15570_BussinessFunctions{

	@Test
	public void lo_SelfStudy_ECommerce_15570() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		
		String isbnNumber = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15570", configProps.getProperty("TestData")).get("Product"); 
		String courseId = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15570", configProps.getProperty("TestData")).get("Course_ID");
		String courseTitle  = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15570", configProps.getProperty("TestData")).get("CourseTitle");
		
		if(isbnNumber!=null){
			Reporters.SuccessReport("Use this ISBN for a future step : "+isbnNumber, "ISBN for a future step. : "+isbnNumber+" is successfully saved. ");
		}else{
			Reporters.failureReport("Use this ISBN for a future step : "+isbnNumber, "ISBN for a future step. : "+isbnNumber+" is failed to save. ");
		}
		
		stepReport("Create new student user");
		writeReport(User_BusinessFunction.CreateNewStudentHome(), "Create Student User from Student Page ", "New student user created and login successful<br> User Credentials: <br>Username : "+EvolveCommonBussinessFunctions.credentials[0]+"<br> Password : "+EvolveCommonBussinessFunctions.credentials[1], "New student user failed to create and login failed");
		String studentUserName = EvolveCommonBussinessFunctions.credentials[0];
		String studentPasswrod = EvolveCommonBussinessFunctions.credentials[1];
		System.out.println(studentUserName +","+ studentPasswrod);
		
		stepReport("Search for product and add to cart");
		searchISBNNumber(isbnNumber);
		
		stepReport("Complete checkout and submit order");
		enterBillingInformation(isbnNumber,courseTitle);
		
		stepReport("Verify course link and content");
		LO_Selfstudy_Access_Code_10412_Bussiness_Function.evolveCatalog(isbnNumber, courseId);
		
		stepReport("Verify student's PAR report in Evolve Admin");
		adminLogin();
		
		coursePARReport(courseId,studentUserName);
	}
	
	@AfterTest
	public void closeBrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		//Base.tearDown();
	}
}
