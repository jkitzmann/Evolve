package com.cigniti.automation.BusinessFunctions;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class KNO_Pageburst_CC_NewStudent_15231 extends EvolveCommonBussinessFunctions{


	public static boolean CreateUser(String user) throws Throwable{
		boolean flag=true;
		try{
		    driver.manage().deleteAllCookies();
		    driver.navigate().refresh(); 
		    String evolveCertURL=configProps.getProperty("URL");
		    if(launchUrl(evolveCertURL)){
		    	Reporters.SuccessReport("Launching The URL.", "Successfully Launched The URL: "+evolveCertURL);
		    }
		    else{
		    	Reporters.failureReport("Launching The URL.", "Failed To Launch The URL: "+evolveCertURL);
		    }
		    Thread.sleep(medium);
		    //clickOnMainPageLink();
		    if(user.equalsIgnoreCase("educator"))
		    {
			     if(click(ElsevierObjects.iameducator, "Clicked on Educator")){
			    	 Reporters.SuccessReport("Clicking On Educator Link.", "Successfully Clicked On Educator Link.");
			     }
			     else{
			    	 Reporters.failureReport("Clicking On Educator Link.", "Failed To Click On Educator Link.");
			     }
			     Thread.sleep(high);
		    }
		    else
		    {
			     if(click(ElsevierObjects.evolve_Home_Student,"Click on student link in evolve home page.")){
			    	 Reporters.SuccessReport("Clicking On Student Link.", "Successfully Clicked On Student Link.");
			     }
			     else{
			    	 Reporters.failureReport("Clicking On Student Link.", "Failed To Click On Student Link.");
			     }
		     Thread.sleep(high);
		    }
		    if(click(ElsevierObjects.student_login,"Click on login button.")){
		    		Reporters.SuccessReport("Clicking On Login Link.", "Successfully Clicked On Login Link.");
			    }
			    else{
			    	Reporters.failureReport("Clicking On Login Link.", "Successfully Clicked On Login Link.");
			    }
		    if(user.equalsIgnoreCase("educator")){ 
		    	
		    	if(click(ElsevierObjects.createAnAccount_lnk, "Click on Create An Account link.")){
		    		Reporters.SuccessReport("Clicking On Create An Account Link.", "Successfully Clicked On Create An Account Link.");
		    	}
		    	else{
		    		Reporters.failureReport("Clicking On Create An Account Link.", "Failed To click On Create An Account Link.");
		    	}
				switchToFrameByLocator(ElsevierObjects.evolve_newAcount_frame,"Switch to frame");
				Thread.sleep(medium);
				click(ElsevierObjects.faculty_radio_btn,"Faculty radio button");
				Thread.sleep(medium);
				registrationForm();
				Thread.sleep(medium);
			}
		    if(user.equalsIgnoreCase("student")){
		    	if(click(ElsevierObjects.createAnAccount_lnk, "Click on Create An Account link.")){
		    		Reporters.SuccessReport("Clicking On Create An Account Link.", "Successfully Clicked On Create An Account Link.");
		    	}
		    	else{
		    		Reporters.failureReport("Clicking On Create An Account Link.", "Failed To click On Create An Account Link.");
		    	}
		    	Thread.sleep(medium);
		    	switchToFrameByLocator(ElsevierObjects.evolve_newAcount_frame,"Switch to frame");
		    	Thread.sleep(medium);
		    	registrationForm();
		    	Thread.sleep(medium);
		    }
		   
		   // String NewUserName=readcolumns.twoColumns(1,1,"DynamicCredentials",configProps.getProperty("TestData")).get(userName);
		    if(click(ElsevierObjects.Myevolve,"Click on my evolve")){
		    	Reporters.SuccessReport("Creating New "+user+" User. ", "Successfully created New "+user+" with Username:"+credentials[0]+",Password:"+credentials[1]);
		    }
		    else{
		    	Reporters.failureReport("Creating New "+user+" User. ", "Failed to Created "+user+" user.");

		    }
		    Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	public static boolean ReviewSubmit(String user,String KNOIsbn) throws Throwable{
		try{
		boolean flag = true;
		
		Thread.sleep(low);
		driver.switchTo().defaultContent();
		Thread.sleep(low);
		
		//totalPriceInReviePage=getText(ElsevierObjects.totalPriceInReviewPage, "Total price in review page");
		priceInReviewPage=getText(ElsevierObjects.evolve_Rview_chkprice, "price in review page");
		isbnInReviewPage=getText(ElsevierObjects.evolve_Rview_chkIsbn,"Isbn in review page");
		titleInReviewPage=getText(ElsevierObjects.evolve_Rview_chktitle, "Title in review page");
		//VST_Isbn=readcolumns.twoColumns(0, 1,"createNewaccount",configProps.getProperty("TestData")).get("AccessCode_VST_NUmber");
		//ReadingExcel.updateCellInSheet(11,1,configProps.getProperty("TestData"), "createNewaccount", titleInReviewPage); 
		//KNOIsbn=readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("kno_num");


		List<WebElement> prices=driver.findElements(ElsevierObjects.priceValidation);

		String estimatedTax=prices.get(1).getText();
		String total=prices.get(2).getText();
		float estTax=convertStringToPrice(estimatedTax);
		float tot=convertStringToPrice(total);
		float itemPrice=convertStringToPrice(priceInReviewPage);
		float finalPrice=itemPrice+estTax;

		//If there is access code it enters into this block
		
			//In review and submit page..if there is no access code

			System.out.println("In else Block.....................");

			if( priceInReviewPage.equals(price_beforerequest) &&  isbnInReviewPage.trim().contains(KNOIsbn.trim()) && titleInReviewPage.trim().contains(title_beforerequest.trim()) ){
				System.out.println("In else block and in if...............");
				if(user .equalsIgnoreCase("educator")){
					if(!click(ElsevierObjects.evolveInstructorChk,"Click on Instructor checkbox")){
						flag=false;
					}
					Thread.sleep(medium);
					if(!click(ElsevierObjects.evolveRegisterAcceptChk,"Click on Register checkbox")){
						flag=false;
					}
					Thread.sleep(medium);
				}
				else{
					if(!click(ElsevierObjects.evolveRegisterAcceptChk,"Click on Register checkbox")){
						flag=false;
					}
					Thread.sleep(medium);
				}

				if(tot==finalPrice){
					Reporters.SuccessReport("Verifying Total Price In Review And Submit Page.", "Successfully Fetched Estimated Tax:"+estimatedTax+"</br>Successfully Fetched Item Price:"+priceInReviewPage+"</br>Successfully Verified Total Price As Sum Of Estimated Tax And Item Price:"+estimatedTax+"+"+priceInReviewPage+":"+finalPrice);
				}
				else
				{
					Reporters.failureReport("Verifying Total Price In Review And Submit Page.", "Failed To Verify Total Price In Review And Submit Page."); 
				}

				if(click(ElsevierObjects.instructor_submit,"Click on Instructor Submit button")){
					Reporters.SuccessReport("Verifying Product Details In Review And Submit Page.</br>Clicking On Submit Button In Review Page.", "Successfully verified Price in Review Page: "+price_beforerequest+"</br> Successfully Verified ISBN in Review Page: "+IsbnBeforeRequest+"</br>Successfully Verified Title in Review Page: "+title_afterRequest+"</br>Successfully Clicked On Submit Button.</br> Successfully Navigated Confirmation Page. "); 
				}
				else{
					Reporters.failureReport("Verifying Product Details In Review And Submit Page.</br>Clicking On Submit Button In Review Page.", "Failed To Verify the KnoISBN in Review Page: "+IsbnBeforeRequest+". </br>Failed to Verify ISBN in Review Page: "+IsbnBeforeRequest+"</br>Failed to Verify Title in Review Page: "+title_afterRequest+" </br>Failed to Click On Submit Button.</br> Failed To Navigate to Confirmation Page. ");
				}
			}
			Thread.sleep(veryhigh);
		
		piceInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chkprice,"Price in Receipt page");
		titleInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chktitle,"Price in Receipt page");
		isbnInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chktisbn,"Price in Receipt page");
		productType=getText(ElsevierObjects.ProductType,"Get product type");
		String totalPriceInReceiptPage=getText(ElsevierObjects.totalPriceInReceiptPage,"Total Price In Receipt Page.");
		
			if(piceInReceiptPage.equals(price_beforerequest) && totalPriceInReceiptPage.contains(total) && isbnInReceiptPage.contains(KNOIsbn)  && titleInReceiptPage.contains(title_beforerequest)){
				if(click(ElsevierObjects.Myevolve,"Click on my evolve")){
					Reporters.SuccessReport("Verifying Product Details In Receipt Page And Clicking On My Evolve.", "Successfully Verified the Below validations: <br>Price In Receipt Page:"+piceInReceiptPage+",<br>ISBN In Receipt Page:"+isbnInReceiptPage+",<br>Title In Receipt Page:"+titleInReceiptPage+",<br>Total Price As Same As Item Price:"+total+"</br>Successfully Clicked On My Evolve link.");
				}
				else{
					Reporters.failureReport("Verifying Product Details In Receipt Page And Clicking On My Evolve.", "Failed To Verify Product Details In Receipt Page.</br>Failed To Click On My Evolve link.");
				}
				Thread.sleep(medium);
			}
		
		}catch(Exception e){
			sgErrMsg=e.getMessage();
		}

		return flag;
	}
}
