package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.CreateRosterforLOcourse_Byrosteredinstructor_15565;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;


public class CreateRosterforLOcourse_Byrosteredinstructor_Script_15565 extends CreateRosterforLOcourse_Byrosteredinstructor_15565 {
	@Test
	public static void createRosterforLOcourse_Byrosteredinstructor_15565() throws Throwable {
		//SwitchToBrowser(ElsevierObjects.studentBrowserType);
		//String user="educator";

		//=====Step 1: execute Complete steps of 'Create Roster For LO course'========//
		
		CreateRosterforLOcourse_Script_8561.createRosterforLOcourse_8561();
		CourseCodeId=ReadingExcel.columnDataByHeaderName("CourseId","TC-15565",testDataPath);
		System.out.println("CourseID is::>>"+CourseCodeId);

		LoEmail =ReadingExcel.columnDataByHeaderName("rosteredfacultyEmail","TC-15565",testDataPath);
		System.out.println("Facutly email id is:"+LoEmail);

		//====Step 2: Create new Student from Student Page======================//
		stepReport("Create new student user");
		writeReport(newStudentCreation()," create a new student user",
				"Sucessfully created new Student and Student details are: </br>Student LastName :  "+lastname+"</br>Student FirstName :  "+firstname+"</br>StudentEmail :  "+email+"</br>Student UserName :  "+username+"</br>StudentPassword :  "+Password,
				"Failed to create new user ");
		
		
		//==========Step3: log into evolvecert.com using roster instructor credentials========//
		stepReport("Login to Evolve as instructor added to roster");
		launchUrl(configProps.getProperty("URL3"));
		String rosteredfacultyUsername=ReadingExcel.columnDataByHeaderName("roster_facultyUserName","TC-15565", testDataPath);
		String rosteredfacultyPassword=ReadingExcel.columnDataByHeaderName("roster_facultyPassword","TC-15565", testDataPath);
		Thread.sleep(1000);
		writeReport(User_BusinessFunction.Educatorlogin(rosteredfacultyUsername,rosteredfacultyPassword),"Launching Evolvecert URL And Login to Application.",
				"Sucessfully Launched Evolvecert URL for User and  </br > Login to Application Using instructor's credentials who was Previously rostered in 'Create Roster for LO Course' : </br>Rostered Instructor UserName : "+rosteredfacultyUsername+"</br>Rostered Instructor password :  "+rosteredfacultyPassword+"</br>instructor's EmailId is :  "+LoEmail+"</br> And roster CourseID is :  "+CourseCodeId,
				"Launching and Login to Application Using previously rosterd instructor User credentails :</br>Rostered Instructor UserName:"+ rosteredfacultyUsername+" is Failed");
		Thread.sleep(medium);
		EvolveCommonBussinessFunctions.getAccountDetailsforRoster();
		LoEmail = getAccountDetailsEmail;
		
		//========Step 4,5 and 6 selecting Online Course Honey pot================//
		stepReport("Add newest student to roster");
		RosterforLoCreation();
		String ID1="true";
		stepReport("Verify roster in LO");
		courseIDSearch(ID1);

		stepReport("Verify newest student has course access");
		StudentRelogin();
		
		stepReport("Verify roster email");
		Emailverification();
		Thread.sleep(2000);


		stepReport("Login to Evolve Admin");
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Enter Admin URL and login with the Credentials",
				"Successfully launched with Admin URL and logged in with User credentials",
		"Failed to login with Admin URL and login");

		stepReport("Verify roster in Evolve Admin");
		RostersearchinginAdmin();
		writeReport(EvolveCommonBussinessFunctions.adminLogout(),"Logout from the admin","Successfully logout from the admin","Failed to logout from the admin");



	}
}
