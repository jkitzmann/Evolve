package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.CreateFacultyUserfromSplashPage_9799;
import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarte_Student_SplitOrders1_15597;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class CreateStudentUserfromSplashPageScript_9798 extends EvolveCommonBussinessFunctions{
	@Test
	public void CreateStudentUserfromSplashPage_9798() throws Throwable{
		try{
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			stepReport("Open Evolve Main Page");
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			mainPageLink();
			String user="student";
			String page="splash";
			
			stepReport("Verify registration form error handling");
			createAnAccountWithEmptyFields(user,page);
			
			stepReport("Verify password field error handling");
			createAnAccountWithPwdEmpty(user,page);
			createAnAccountPwdMismatch(user,page);
			
			stepReport("Create new student account");
			createAnAccountWithCorrectDetails(user,page);
			ECommercePreorderALaCarte_Student_SplitOrders1_15597.getStudentAccountDetails();
			
			stepReport("Log out and back in");
			if(instructorLogout()){
				Reporters.SuccessReport("Student logout:", "Successfully logged out the student aplication.");
			}
			else{
				Reporters.failureReport("Student logout:", "Failed to logout the student application.");
			}
			userReLogin(user);
			//SwitchToBrowser("Chrome");
			
			stepReport("Verify email");
			if(emailLogin()){
				Reporters.SuccessReport("Email login:", "Successfully logged into User Email.");
			}
			else{
				Reporters.failureReport("Email Login:", "Failed to login into User Email.");
			}
			String Title=tc_9798.get("Title");
			
			CreateFacultyUserfromSplashPage_9799.emailBodyVerification(Title,user);
			
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
	//	Base.tearDown();
	}
}