package com.cigniti.automation.Test;

import java.util.Arrays;
import java.util.Random;

import jxl.Sheet;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class SearchResults_SORTBY_Titles_9807 extends User_BusinessFunction {
	

 	public static Sheet inputSheetObj =null;

	Random ra = new Random( System.currentTimeMillis() );
 	
	@Test
	public void SearchResults_SORTBY_Title() throws Throwable
	
	{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());

		String ResultsfromPage1="";
		String ResultsfromPage2="";
		String ResultsfromPage3="";

		writeReport(SwitchToBrowser(ElsevierObjects.studentBrowserType),"Launching Browser to Student","Launching Browser to Student is succesful","Lanching Browser to Student is failed");

		String Catalogs=ReadingExcel.columnDataByHeaderName( "Catalogs", "TC-9807",configProps.getProperty("TestData"));		
		System.out.println(Catalogs);
		
		writeReport(User_BusinessFunction.Studentlogin(sStudentUser, sStudentPassword),"Login to Application Using Student Credentials"+sStudentUser,
        		                                                                           "Launching the URL for Student is successful </br > Login to Application Using Student credentails :"+sStudentUser+" is Successful",
        		           		                                                           "Launching and Login to Application Using Student credentails : "+ sStudentUser+" is Failed");
		Thread.sleep(high);
		writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as:"+sStudentUser,
                                                                 "Navigating to CATALOG page is Successful",
                                                                 "Navigating to CATALOG Page is failed");
		Thread.sleep(high);
		writeReport(User_BusinessFunction.HESI_Search(Catalogs),"Searching for Value:"+Catalogs,
                                                                   "Entered "+Catalogs+" to Search </br > Click on Go Button </br> The results Displayed and Relevance Button is selected As default Option",
                                                                   "Unable to Search for : "+ Catalogs);
		Thread.sleep(high);
		 writeReport(User_BusinessFunction.SelectSortingType(ElsevierObjects.SortByTitle),"Searching for Radio button as: Title",
                                                                                               "Select Radio button as Title is successful",
                                                                                               "Unable to select Radio button as Title");
		//driver.get("https://evolvecert.elsevier.com/cs/search?query=Test&role=student&productPage=0&categoryId=&length=25&sortBy=authorSort&selectedTypes=&typeFacets=eaq_ia%2Ccase_study%2Ccase_study_ac%2Cpractice_test%2Chardcover%2Cebook_kno_ia%2Cebook_ia%2Cebook_ac%2Cpaperback%2Cresource%2Csimulation_sls_ia%2Csimulation_sim_chart&selectedFormats=&formatFacets=angel_6x%2Cblackboard_ce_enterprise%2Cbb_enterprise_6x%2Cblackboard_vista_enterprise%2Clo_global%2Clo_unique%2Cangel_unique");
	    Thread.sleep(high);	
		writeReport(User_BusinessFunction.VerifySortorderfor_Page(ElsevierObjects.Title),"Verifying Sorting Order in Ascending format",
                                                                                     "The Actual Sorting order from  Application is: </br>"+sActualValues+"</br> The Expected Values of Sorting order is </br>:"+sExpectedValues +"<br>  Both Values are matching Hence SortingOrder is as expected",
                                                                                     "The Actual Sorting order from  Application is: </br>"+sActualValues+"</br> The Expected Values of Sorting order is </br>:"+sExpectedValues +"<br>  Both Values are not matching Hence SortingOrder is as not expected");
		ResultsfromPage1 =sActualValues;
	
		writeReport(User_BusinessFunction.ClickingOnNext_Button(),"Clicking On Next  Button on the Results Screen",
                                                                     "Clicking on Next button is successful </br> Navigation to Next page is Successful",
                                                                     "Clicking on Next button is failed </br> Navigation to Next page is failed");
	    Thread.sleep(high);	
	    
		writeReport(User_BusinessFunction.VerifySortorderfor_Page(ElsevierObjects.Title),"Verifying Sorting Order in Ascending format",
                                                                                    "The Actual Sorting order from  Application is: </br>"+sActualValues+"</br> The Expected Values of Sorting order is </br>:"+sExpectedValues +"<br>  Both Values are matching Hence SortingOrder is as expected",
                                                                                    "The Actual Sorting order from  Application is: </br>"+sActualValues+"</br> The Expected Values of Sorting order is </br>:"+sExpectedValues +"<br>  Both Values are not matching Hence SortingOrder is as not expected");
		ResultsfromPage2 =sActualValues;
		writeReport(User_BusinessFunction.ClickingOnThridPage_Button(),"Clicking On Third Page  Button on the Results Screen",
                                                                          "Clicking on Third Page button is successful </br> Navigation to Third page is Successful",
                                                                          "Clicking on Third button is failed </br> Navigation to Third page is failed");
		
		Thread.sleep(high);	


		writeReport(User_BusinessFunction.VerifySortorderfor_Page(ElsevierObjects.Title),"Verifying Sorting Order in Ascending format",
                                                                                    "The Actual Sorting order from  Application is: </br>"+sActualValues+"</br> The Expected Values of Sorting order is </br>:"+sExpectedValues +"<br>  Both Values are matching Hence SortingOrder is as expected",
                                                                                    "The Actual Sorting order from  Application is: </br>"+sActualValues+"</br> The Expected Values of Sorting order is </br>:"+sExpectedValues +"<br>  Both Values are not matching Hence SortingOrder is as not expected");
		ResultsfromPage3 =sActualValues;
		
		    ResultsfromPage1=ResultsfromPage1.substring(1, ResultsfromPage1.length()-1);
	        ResultsfromPage2=ResultsfromPage2.substring(1, ResultsfromPage2.length()-1);
	        ResultsfromPage3=ResultsfromPage3.substring(1, ResultsfromPage3.length()-1);
	        String Entirestring=" "+ResultsfromPage1+", "+ResultsfromPage2+", "+ResultsfromPage3;
	       //Entirestring.replaceAll("\\[|\\]", "");
	       // Entirestring.replaceAll("]", "");
	       String[] allStateCapitals = Entirestring.split(",");


     	System.out.println("With ArrayUtil:"+Arrays.toString(allStateCapitals));
	    writeReport(User_BusinessFunction.verifyentiresortorder(allStateCapitals),"Verifying Sorting Order in Ascending format  of all Three page Results  results",
	                "The Actual Sorting order from  Application is: </br>"+sActualValues+"</br> The Expected Values of Sorting order is </br>:"+sExpectedValues +"<br>  Both Values are matching Hence SortingOrder is as expected",
	                "The Actual Sorting order from  Application is: </br>"+sActualValues+"</br> The Expected Values of Sorting order is </br>:"+sExpectedValues +"<br>  Both Values are not matching Hence SortingOrder is as not expected");

		writeReport(User_BusinessFunction.Logout(),"Clicking on Logout",
                                                      "Clicking on Logout is Successful",
                                                      "Clicking on Logout is not Successful");
		
		ResultsfromPage1="";
        ResultsfromPage2="";
        ResultsfromPage3="";
        
		writeReport(SwitchToBrowser(ElsevierObjects.studentBrowserType),"Launching Browser to Portal User","Launching Browser to Portal User is succesful","Lanching Browser to Portal User is failed");
		writeReport(User_BusinessFunction.Educatorlogin(sEducatorUser, sEducatorPassword),"Login to Application Using Educator Credentials"+sEducatorUser,
                                                                                             "Launching the URL for Educator is successful </br > Login to Application Using Educator credentails :"+sEducatorUser+" is Successful",
                                                                                             "Launching and Login to Application Using Educator credentails : "+ sEducatorUser+" is Failed");
		Thread.sleep(6000);

		writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as:"+sEducatorUser,
                                                                 "Navigating to CATALOG page is Successful",
                                                                  "Navigating to CATALOG Page is failed");
		Thread.sleep(high);
        writeReport(User_BusinessFunction.HESI_Search(Catalogs),"Searching for Value:"+Catalogs,
                                                                   "Entered "+Catalogs+" to Search </br > Click on Go Button </br> The results Displayed and Relevance Button is selected As default Option",
                                                                   "Unable to Search for : "+ Catalogs);
        Thread.sleep(high);
        writeReport(User_BusinessFunction.SelectSortingType(ElsevierObjects.SortByTitle),"Searching for Radio button as: Title",
                                                            "Select Radio button as Title is successful",
                                                            "Unable to select Radio button as Title");

        Thread.sleep(high);	
        writeReport(User_BusinessFunction.VerifySortorderfor_Page(ElsevierObjects.Title),"Verifying Sorting Order in Ascending format",
                                                                       "The Actual Sorting order from  Application is: </br>"+sActualValues+"</br> The Expected Values of Sorting order is </br>:"+sExpectedValues +"<br>  Both Values are matching Hence SortingOrder is as expected",
                                                                       "The Actual Sorting order from  Application is: </br>"+sActualValues+"</br> The Expected Values of Sorting order is </br>:"+sExpectedValues +"<br>  Both Values are not matching Hence SortingOrder is as not expected");
        ResultsfromPage1 =sActualValues;
        writeReport(User_BusinessFunction.ClickingOnNext_Button(),"Clicking On Next  Button on the Results Screen",
                                                                     "Clicking on Next button is successful </br> Navigation to Next page is Successful",
                                                                     "Clicking on Next button is failed </br> Navigation to Next page is failed");
        Thread.sleep(high);	

        writeReport(User_BusinessFunction.VerifySortorderfor_Page(ElsevierObjects.Title),"Verifying Sorting Order in Ascending format",
                                                                       "The Actual Sorting order from  Application is: </br>"+sActualValues+"</br> The Expected Values of Sorting order is </br>:"+sExpectedValues +"<br>  Both Values are matching Hence SortingOrder is as expected",
                                                                       "The Actual Sorting order from  Application is: </br>"+sActualValues+"</br> The Expected Values of Sorting order is </br>:"+sExpectedValues +"<br>  Both Values are not matching Hence SortingOrder is as not expected");
        ResultsfromPage2 =sActualValues;
        writeReport(User_BusinessFunction.ClickingOnThridPage_Button(),"Clicking On Third Page  Button on the Results Screen",
                                                                          "Clicking on Third Page button is successful </br> Navigation to Third page is Successful",
                                                                          "Clicking on Third button is failed </br> Navigation to Third page is failed");
        Thread.sleep(high);	


        writeReport(User_BusinessFunction.VerifySortorderfor_Page(ElsevierObjects.Title),"Verifying Sorting Order in Ascending format",
                                                                       "The Actual Sorting order from  Application is: </br>"+sActualValues+"</br> The Expected Values of Sorting order is </br>:"+sExpectedValues +"<br>  Both Values are matching Hence SortingOrder is as expected",
                                                                       "The Actual Sorting order from  Application is: </br>"+sActualValues+"</br> The Expected Values of Sorting order is </br>:"+sExpectedValues +"<br>  Both Values are not matching Hence SortingOrder is as not expected");
				
        ResultsfromPage3 =sActualValues;
        
        ResultsfromPage1=ResultsfromPage1.substring(1, ResultsfromPage1.length()-1);
        ResultsfromPage2=ResultsfromPage2.substring(1, ResultsfromPage2.length()-1);
        ResultsfromPage3=ResultsfromPage3.substring(1, ResultsfromPage3.length()-1);
        Entirestring=" "+ResultsfromPage1+", "+ResultsfromPage2+", "+ResultsfromPage3;
       //Entirestring.replaceAll("\\[|\\]", "");
       // Entirestring.replaceAll("]", "");
        allStateCapitals = Entirestring.split(",");


        System.out.println("With ArrayUtil:"+Arrays.toString(allStateCapitals));
        writeReport(User_BusinessFunction.verifyentiresortorder(allStateCapitals),"Verifying Sorting Order in Ascending format  of all Three page Results  results",
                "The Actual Sorting order from  Application is: </br>"+sActualValues+"</br> The Expected Values of Sorting order is </br>:"+sExpectedValues +"<br>  Both Values are matching Hence SortingOrder is as expected",
                "The Actual Sorting order from  Application is: </br>"+sActualValues+"</br> The Expected Values of Sorting order is </br>:"+sExpectedValues +"<br>  Both Values are not matching Hence SortingOrder is as not expected");



        writeReport(User_BusinessFunction.Logout(),"Clicking on Logout",
                                                      "Clicking on Logout is Successful",
                                                      "Clicking on Logout is not Successful");
		}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
	}
	
	/*@AfterClass
	public static void browserStop()
	{
		driver.close();
	}*/
	
	

