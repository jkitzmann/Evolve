package com.cigniti.automation.Utilities;

import com.cigniti.automation.accelerators.Actiondriver;

public class uploadFile extends Actiondriver{

}
