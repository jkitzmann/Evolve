package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.VitalSourceAccountAC_HomePage_StudentExists_VST;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class VitalSourceAccount_AC_MyCart_Instructor_Script_15241 extends EvolveCommonBussinessFunctions{
	
	@Test 
	public void vitalSourceAccount_AC_MyCart_Instructor_15241() throws Throwable{
		try { 
			System.out.println("************** Started execution for VST My Cart Instructor 15241 *************");
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String username=ReadingExcel.columnDataByHeaderName( "VST_InstructorUser", "VST",configProps.getProperty("TestData"));
			String password=ReadingExcel.columnDataByHeaderName( "VST_InstructorPassword", "VST",configProps.getProperty("TestData"));
			String user = "educator";
			String knoUser="";
			if(CreateNewUser(user))
			{
	     		Reporters.SuccessReport("Create Faculty User from Faculty Page", "Successfully Created Faculty user with the following credentials: <br> Faculty Username : "+EvolveCommonBussinessFunctions.credentials[0]+"<br> Faculty Password : "+EvolveCommonBussinessFunctions.credentials[1]+"<br> Succussfully logged into the application as faculty user");
			}
			else
			{
				Reporters.failureReport("Create Faculty User from Faculty Page", "Failed to Create Faculty user <br> Failed to logged into the application as faculty user");
			}
			String name = "VST";
			String accessCode = "true";
			VSTandKnoSearch(name,accessCode);
			updateVSTandKNOAccount(user,name,accessCode,knoUser);
			if(userReviewSubmit(user, accessCode, KNOIsbn))
			{
	     		Reporters.SuccessReport("Validating the items in Review and submit page" ,"Successfully Validated the items in Review and submit page in the above steps");
			}
			else
			{
				Reporters.failureReport("Validating the items in Review and submit page" ,"Failed to Validate the items in Review and submit page in the above steps");
			}
			String accessCodeUser="educator";
			String beforeTitle=titleInReceiptPage;
			String condition="myCartTitle";
			writeReport(VitalSourceAccountAC_HomePage_StudentExists_VST.pageburstVstLink(accessCodeUser, beforeTitle, condition), "Verify the VST link.", 
					"Succesfully verified the VST link.</br>Successfully Clicked on VST link.</br>Successfully Navigated to VST page.", 
					"Failed to verify the VST link.");
			if(instructorLogout())
			{
				Reporters.SuccessReport("Logged out from Faculty Account", "Successfully Logged out from Faculty Account");
			}
	       else{
				Reporters.failureReport("Logged out from Faculty Account", "Failed to Logged out from Faculty Account");
			}
			if(reCheckingAccessCode(user,username,password))
			{
				Reporters.SuccessReport("ReChecking Access Code", "User is given an error when attempted to enter the used vst access code.  <br>The code is now redeemed so no other user should be able to use this code.  The VST item is not added to the card and the access code is not applied.");
			}
	       else{
				Reporters.failureReport("ReChecking Access Code", "User is failed to give an error message when attempted to enter the used vst access code.  <br>The code is now redeemed so no other user should be able to use this code.  The VST item is not added to the card and the access code is not applied."); 
			}
			ReadingExcel.removeUsedVSTCode(VSTDataPath, "VSTCodes");
			System.out.println("************** Execution Completed for VST My Cart Instructor 15241 *************");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Exception Occured");
			ReadingExcel.removeUsedVSTCode(VSTDataPath, "VSTCodes");
		}
	}
	@AfterTest
	public void closeBrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
