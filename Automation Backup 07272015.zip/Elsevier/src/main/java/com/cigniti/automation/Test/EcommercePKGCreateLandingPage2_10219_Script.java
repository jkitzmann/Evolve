package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class EcommercePKGCreateLandingPage2_10219_Script extends EvolveCommonBussinessFunctions{

	@Test
	public void ecommercePKGCreateLandingPage2_10219() throws Throwable
	{
	try{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//ElsevierObjects.adminBrowserType="chrome";
		stepReport("Login to Evolve Admin");
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		
		writeReport(evolveAdminlogin(),"Login to Application Using User Credentials"+adminUser,
                "Launching the URL for User is successful </br > Login to Application Using User credentails :"+adminUser+" is Successful",
                   "Launching and Login to Application Using User credentails : "+ adminUser+" is Failed");
		
		stepReport("Verify UI of the add ecom package page");
		verifyEcommerceLink();
		
		if(viewTopViewAddPakage())
		{
     		Reporters.SuccessReport("Validate the 'Package Items section' of the page ", "All fields are available in Package item section");
		}
		else
		{	
			Reporters.failureReport("Validate the 'Package Items section' of the page ", "All fields are not available in Package item section");
		}
		
		cloneEnabled();
		
		stepReport("Create and save the package details");
		if(inputPackageData())
		{
     		Reporters.SuccessReport("Input the Package Data", "The data is correctly entered into the fields");
		}
		else
		{
			
			Reporters.failureReport("Input the Package Data", "The data is Not correctly entered into the fields");
		}
		
		stepReport("Add ISBNs to the package");
		verifyAndAddISBNPackages();
		
		stepReport("Add specific product type discount through Cross Promotions tab");
		if(crossPromotionTab()){
     		Reporters.SuccessReport("Validating Cross Promotion Tab", "Successfully clicked on the Cross promotion tab and added the data to the table");
		}
		else{
			Reporters.failureReport("Validating Cross Promotion Tab", "failed to click on the Cross promotion tab and failed to add the data to the table");
		}
		
		stepReport("Create marketing page for the package");
		if(marketingPageTab())
		{
	 		Reporters.SuccessReport("Validating Marketing Tab", "Marketing tab validations are Successfully Done");
		}
		else
		{
			
			Reporters.failureReport("Validating Marketing Tab", "Marketing tab validations are failed");
		}
		
		stepReport("Add cross promotion items to marketing page");
		String user="variablePercentage";
		String checkbox="selectFeatureRadioButton";
		if(crossPromoteItems(user, checkbox))
		{
	 		Reporters.SuccessReport("Validating Cross Promote Items", "Cross Promote items are Successfully Validated");
		}
		else
		{
			
			Reporters.failureReport("Validating Cross Promote Items", "Cross Promote items are Validation failed");
		}
		
		Thread.sleep(medium);
		
		 writeReport(EvolveCommonBussinessFunctions.adminLogout(),"Clicking on Logout",
                 "Clicking on Logout is Successful",
                 "Clicking on Logout is not Successful");
	}catch(Exception e){
		System.out.println(e.getMessage());
	}
	
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}

	

