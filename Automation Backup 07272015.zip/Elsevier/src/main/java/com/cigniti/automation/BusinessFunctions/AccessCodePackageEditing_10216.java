package com.cigniti.automation.BusinessFunctions;

import static org.testng.AssertJUnit.assertTrue;

import java.util.Random;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.Utilities.WritingExcel;


public class AccessCodePackageEditing_10216 extends EvolveCommonBussinessFunctions {

	 	 
	 public static boolean clickMaintainAccessCode() throws Throwable{
		 boolean flag = true;
		try{
			 Thread.sleep(medium);
			
	    	 if(click(ElsevierObjects.searchMAC,"Click the Maintain Access Code Packages link in the Access Code Package Maintenance section ")){
	    		 Reporters.SuccessReport("Click the Maintain Access Code Packages link <br>in the Access Code Package Maintenance section ", "Successfully Clicked on the Maintain Access Code Packages link <br>in the Access Code Package Maintenance section ");
	    	 }else{
	    		 Reporters.failureReport("Click the Maintain Access Code Packages link <br>in the Access Code Package Maintenance section ", "Successfully Clicked on the Maintain Access Code Packages link <br>in the Access Code Package Maintenance section ");
	    	 }
	    	//TODO verify the link header present Search Access Code Packages
	    	 String headerLink=getText(ElsevierObjects.MaintainProductHeaderLink, "Maintain Product Header Link");
	    	 if(verifyText(ElsevierObjects.MaintainProductHeaderLink, "Search Access Code Packages By:", "Search Access Code Packages By:")){
	    		 Reporters.SuccessReport("Verify for the text The Search Access Code Packages By on the page", "The Text : "+headerLink+" is present on the page."+driver.getCurrentUrl());
	    	 }else{
	    		 Reporters.failureReport("Verify for the text The Search Access Code Packages By on the page", "The Text : "+headerLink+" is not present on the page."+driver.getCurrentUrl());
	    	 }
	    	 if(!waitForElementPresent(ElsevierObjects.brudcrum, "Brudcrum Present")){
	    		 flag = false;
	    	 }
	    	 
	    	 if(verifyText(ElsevierObjects.brudcrum, "Evolve Admin > Search Access Code Packages ", "Verify for the Bread crumb : 'Evolve Admin > Search Access Code Packages' ")){
	    		 Reporters.SuccessReport("Verifying the presence of Bread Crumb", "The Bread Crumb 'Evolve Admin > Search Access Code Packages' is present ");
	    	 }else{
	    		 Reporters.failureReport("Verifying the presence of Bread Crumb", "The Bread Crumb 'Evolve Admin > Search Access Code Packages' is not present ");
	    	 }
	    	 
	    	 String packageName1=readcolumns.twoColumns(0, 1, "Tc-10216 & 8565", configProps.getProperty("TestData")).get("PackageIsbn");
	    	 if(type(ElsevierObjects.searchISBN, packageName1, "PackageIsbn")){
	    		 Reporters.SuccessReport("Search for an Access Code Package to edit", "Successfully Entered the Access Code Package : "+packageName1+" into the text box");
	 		 }else{
	 			 Reporters.failureReport("Search for an Access Code Package to edit", "Successfully Entered the Access Code Package : "+packageName1+" into the text box");
	 		 }
	    	 if(!click(ElsevierObjects.btngo,"Clicked on button go")){
	    		 flag = false;
	    	 }
	    	 
	    	 if(isEnabled(ElsevierObjects.packageName, "Package name is Enabled")){
	    		 Reporters.SuccessReport("Validate whether the Element Package Name is editable or not", "The Element Package Name is editable");
	    	 }else{
	    		 Reporters.failureReport("Validate whether the Element Package Name is editable or not", "The Element Package Name is not editable");
	    	 }
	    	 if(isEnabled(ElsevierObjects.btnSave, "Save Button is Enabled")){
	    		 Reporters.SuccessReport("Validate whether the Element Save Button is enabled or not", "The Element Save Button is enabled");
	    	 }else{
	    		 Reporters.failureReport("Validate whether the Element Save Button is enabled or not", "The Element Save Button is not enabled");
	    	 }
	    	 if(isEnabled(ElsevierObjects.isbnText, "ISBN Text is Enabled")){
	    		 Reporters.SuccessReport("Validate whether the Element ISBN Text box is editable or not", "The Element ISBN Text box is editable");
	    	 }else{
	    		 Reporters.failureReport("Validate whether the Element ISBN Text box is editable or not", "The Element ISBN Text box is not editable");
	    	 }
	    	 if(isEnabled(ElsevierObjects.btnRemove, "Remove Button is Enabled")){
	    		 Reporters.SuccessReport("Validate whether the Element Remove Button is enabled or not", "The Element Remove Button is enabled");
	    	 }else{
	    		 Reporters.failureReport("Validate whether the Element Remove Button is enabled or not", "The Element Remove Button is not enabled");
	    	 }
	    	 
	    	 String packageNameBeforeEditing=getAttribute(ElsevierObjects.inputpackagename, "value", "input package name");
	    	 System.out.println(packageNameBeforeEditing);
	    	
	    	 Random ra = new Random( System.currentTimeMillis() );
	         String packageNameAfterEditing = readcolumns.twoColumns(0, 1,"Tc-10216 & 8565", configProps.getProperty("TestData")).get("PackageName")+Integer.toString((1 + ra.nextInt(2)) * 100 + ra.nextInt(100));
	 		
	        if(type(ElsevierObjects.packageName, packageNameAfterEditing, "Package Name")){
	    		 Reporters.SuccessReport("Enter the New PackageName", "Successfully entered the New Package Name into the Text Box : <br> Pakage Name before Editing is : "+packageNameBeforeEditing+"<br>The New Package Name after Editing is : "+packageNameAfterEditing );
	 		 }else{
	 			 Reporters.failureReport("Enter the New PackageName", "Failed to enter the New Package Name into the Text Box : <br> The New Package Name is : "+packageNameAfterEditing );
	 		 }
	    	 if(!click(ElsevierObjects.btnSave,"Clicked on SaveButton")){
	    		 flag = false;
	    	 }
	    	 String sucMsg=getText(ElsevierObjects.edit_message, "");
	    	 if(verifyText(ElsevierObjects.edit_message, "Package successfully saved. ", "edit_message")){
	    		 Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is displayed ");		
	 		}else{
	 			Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
	 		}
	    	 if(!waitForElementPresent(ElsevierObjects.edit_message, "Message Successfully displayed. ")){
	    		 flag = false;
	    	 }
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
		}
    	 return flag;
     }
	 
}
