package com.cigniti.automation.BusinessFunctions;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

	public class LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101 extends EvolveCommonBussinessFunctions {
		
	
	public static String requestTextInMyCart;
	
	
	public static boolean f_prodLinkInMaintainProductPage() throws Throwable{
		boolean flag=true;
		try{	
			click(ElsevierObjects.maintainProducts_FProduction_Lnk,"Click on F-Production tab in product result page");
			Thread.sleep(medium);
		}
		catch(Exception e){sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
		return flag;
	}
	public static boolean f_productionTrialRegistrationTable(String Value1,String Value2,String Value3) throws Throwable{
		boolean flag=true;
		try{	
			String AppValue1=driver.findElement(By.xpath(".//*[@id='faculty-production']//div[@class='email_template_section']/span[contains(text(),'"+Value1+"')]/following-sibling::span[1]/input")).getAttribute("value");
			System.out.println("AppValue1:"+AppValue1);
			/*List<WebElement> AllTitlesfromapplication = driver.findElements(By.xpath(".//*[@id='faculty-production']//span[@class='middle']//input"));
			int totalResults=AllTitlesfromapplication.size();
			System.out.println(totalResults);
			for(int i=0;i<5;i++)
			{
				WebElement Appdatavalues=AllTitlesfromapplication.get(i);
				daysData=Appdatavalues.getAttribute("value");
				System.out.println("The Text values are :"+daysData);
				if(daysData.contains(Value2)){
					Reporters.SuccessReport("Verifying Days Of Trial Notifications:"+Value1,"Successfully Verified Trial Notifications:"+Value1+" Days:"+Value2);
				}
				else{
					Reporters.failureReport("Verifying Days Trial Notifications:"+Value1, "Faile To Verify Trial Notification:"+Value1+" Details.");
				}
				
			}*/
			
			
			Select comboBox = new Select(driver.findElement(By.xpath(".//*[@id='faculty-production']//div[@class='email_template_section']/span[contains(text(),'"+Value1+"')]/following-sibling::span[2]/select")));
			String selectedComboValue1 = comboBox.getFirstSelectedOption().getText();
			System.out.println("AppValue2:"+selectedComboValue1);
			if(Value2.contains(AppValue1) && Value3.contains(selectedComboValue1)){
				Reporters.SuccessReport("Verifying Days And Email Template Of Trial Notifications:"+Value1,"Successfully Verified Trial Notifications:"+Value1+" Days:"+Value2+",Email Template:"+Value3);
			}
			else{
				Reporters.failureReport("Verifying Days And Email Template Of Trial Notifications:"+Value1, "Faile To Verify Trial Notification:"+Value1+" Details.");
			}
			 
		}
		catch(Exception e){sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
		return flag;
	}
	public static boolean compareStartDtaeTrialReg(String Value1,String Value2,String Value3) throws Throwable{
		boolean flag=true;
		try{
			
			String AppValue1=driver.findElement(By.xpath(".//*[@id='faculty-production']//div[@class='email_template_section']/span[contains(text(),'"+Value1+"')]/following-sibling::span[1]")).getText();
			System.out.println("AppValue1:"+AppValue1);
			Select comboBox = new Select(driver.findElement(By.xpath(".//*[@id='faculty-production']//div[@class='email_template_section']/span[contains(text(),'"+Value1+"')]/following-sibling::span[2]/select")));
			String selectedComboValue1 = comboBox.getFirstSelectedOption().getText();
			System.out.println("AppValue2:"+selectedComboValue1);
			if(Value2.trim().contains(AppValue1.trim()) && Value3.trim().contains(selectedComboValue1.trim())){
				Reporters.SuccessReport("Verifying Days And Email Template Of Trial Notifications:"+Value1,"Successfully Verified Trial Notifications:"+Value1+" Days:"+Value2+",Email Template:"+Value3);
			}
			else{
				Reporters.failureReport("Verifying Days And Email Template Of Trial Notifications:"+Value1, "Faile To Verify Trial Notification:"+Value1+" Details.");
			}
			 
		}
		catch(Exception e){sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
		return flag;
	}
	
	public static boolean compareUnEnrollTrialReg(String Value1,String Value2) throws Throwable{
		boolean flag=true;
		try{
			
			List<WebElement> AllTitlesfromapplication = driver.findElements(By.xpath(".//*[@id='faculty-production']//span[@class='middle']//input"));
			int totalResults=AllTitlesfromapplication.size();
			System.out.println(totalResults);
			for(int i=0;i<5;i++)
			{
				WebElement Appdatavalues=AllTitlesfromapplication.get(i);
				daysData=Appdatavalues.getAttribute("value");
				System.out.println("The Text values are :"+daysData);
				if(daysData.contains(Value2)){
					Reporters.SuccessReport("Verifying Days Of Trial Notifications:"+Value1,"Successfully Verified Trial Notifications:"+Value1+" Days:"+Value2);
				}
			}
		}
		catch(Exception e){sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
		return flag;
	}
	
	/*public static boolean CompareProductionTrailReg(String Value1,String Value2,String Value3) throws Throwable
	{
	  String AppValue1=driver.findElement(By.xpath(".//*[@id='faculty-production']//div[@class='email_template_section']/span[contains(text(),'"+Value1+"')]/following-sibling::span[1]")).getText();
	  System.out.println("AppValue1:"+AppValue1);
	  Select comboBox = new Select(driver.findElement(By.xpath(".//*[@id='faculty-production']//div[@class='email_template_section']/span[contains(text(),'"+Value1+"')]/following-sibling::span[2]/select")));
	  String selectedComboValue = comboBox.getFirstSelectedOption().getText();

	  //String AppValue2=driver.findElement(By.xpath(".//*[@id='faculty-production']//div[@class='email_template_section']/span[contains(text(),'"+Value1+"')]/following-sibling::span[2]")).getAttribute("value");
	  System.out.println("AppValue2:"+selectedComboValue);

	  if(Value1.contains(AppValue1)&&Value2.contains(selectedComboValue))
	 {
		 return true;}else
		 {sgErrMsg="Expected Value is :"+Value2+" and "+Value2+"Actual Value is"+AppValue1+"And"+selectedComboValue;return false;}
	}
	*/
	
	
	/*public static boolean CompareProductionTrailReg(String Value1,String Value2) throws Throwable
	{
	  String AppValue1=driver.findElement(By.xpath(".//*[@id='faculty-production']//div[@class='email_template_section']/span[contains(text(),"+Value1+")]/following-sibling::span[1]")).getText();
	
	 if(Value2.contains(AppValue1))
	 {
		 return true;}else
		 {sgErrMsg="Expected Value is :"+Value2+" and "+Value2+"Actual Value is"+AppValue1;return false;}
	}*/
	 
	public static boolean  adminProductsearchResultDaysTable() throws Throwable

	{
		try

		{
			boolean flag = true;

			List<WebElement> AllTitlesfromapplication = driver.findElements(By.xpath(".//*[@id='faculty-production']//span[@class='middle']//input"));
			int totalResults=AllTitlesfromapplication.size();
			System.out.println(totalResults);
			for(int i=0;i<5;i++)
			{
				WebElement Appdatavalues=AllTitlesfromapplication.get(i);
				daysData=Appdatavalues.getAttribute("value");
				System.out.println("The Text values are :"+daysData);
			}
			
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}
	public static boolean compareF_ProductionDetails() throws Throwable{
		Boolean flag=true;
		 try{
			 	//isChecked(ElsevierObjects.F_Production_EnableTrialRegistraion, "verify the enable trial registration checkbox is check");
			 //CompareProductionTrailReg("Warning 1", "", "");
			 adminProductsearchResultDaysTable();
			 	System.out.println(daysData);
			 	
			 	List<String> s = new ArrayList<String>();
			 	
			 	s.add(compareStartDate);
			 	s.add(compareEmailTemplateStartDate);
			 	s.add(compareEmailTemplateWarning1);
			 	s.add(compareEmailTemplateWarning2);
			 	s.add(compareEmailTemplateEnd);
			 	s.add(unEnrollDays);
			 	s.add(warning1Days);
			 	s.add(wraning2Days);
			 	s.add(endDays);
			 	System.out.println(s);
			 	for(String s1: s){
			 		if(s1.contains(data1) && s1.contains(daysData)){
			 			Reporters.SuccessReport("Verifying Enable Registration,Email Template,Start Date,End Date,Warning1,Warning2,Unenroll User Data in F-prod View Product Page.", "Successfully Verified F-prod data:"+data1);
			 		}
			 		else{
			 			Reporters.failureReport("Verifying Enable Registration,Email Template,Start Date,End Date,Warning1,Warning2,Unenroll User Data in F-prod View Product Page.","Failed To Verify F-prob data in View Product Page.");
			 		}	 		
			 	}
		 	}
		 	catch(Exception e){sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
	 return flag;
	 }
	 
	public static boolean request30DayTrial() throws Throwable{
		boolean flag=true;
		try{
			price_beforerequest=getText(ElsevierObjects.evolve_Product_pricebeforerequest,"Product price before request");			
			title_beforerequest=getText(ElsevierObjects.evolve_Product_titlebeforerequest,"Product title");
			IsbnBeforeRequest=getText(ElsevierObjects.evolve_verify_isbn,"Isbn num");
			requestText= getText(ElsevierObjects.evolve_RequestTrial30Days, "Get Request 30 days trial text.");
			if(click(ElsevierObjects.evolve_RequestTrial30Days,"click on request link.")){
				Reporters.SuccessReport("Clicking On Request 30 Day Trial link.", "Successfully Clicked On Request 30 Day Trial Link.</br>Successfully Navigated To Mycart Page.");
			}
			else{
				Reporters.failureReport("Clicking On Request 30 Day Trial link.", "Failed To Click On Request 30 Day Trial Link.</br>Failed To Navigate To Mycart Page.");
			}
		}
		catch(Exception e){sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
		return flag;
	}
	
	
	//Common Logic for 9804,9805,9806,15575,15576,15577,15578,15579......
		public static boolean Mycart(String searchTrial,String TrialRequest) throws Throwable{
		boolean flag=true;
			try{
			Thread.sleep(high);
			Isbn=getText(ElsevierObjects.Student_Product_ISBN,"get isbn number.");
			title=getText(ElsevierObjects.evolve_Rview_chktitle,"Get title of book.");
			author=getText(ElsevierObjects.Course_Author, "Get author name.");
			lmsText=getText(ElsevierObjects.lmsTitle, "Get lms title.");
			myCartPrice=getText(ElsevierObjects.evolve_Product_priceAfterRequest, "Get the product price");
		
			Thread.sleep(medium);
			if(searchTrial.equalsIgnoreCase("true")){
				requestTextInMyCart=getText(ElsevierObjects.evolve_MyCart_RequestTrial30Dayslnk, "Get text of Request 30 days trial link.");
				if(TrialRequest.equalsIgnoreCase(requestTextInMyCart)  && myCartPrice.contains(ExpectedPrice) && title_beforerequest.contains(title) && Isbn.contains(IsbnBeforeRequest)){
					Thread.sleep(medium);
					if(click(ElsevierObjects.Educator_Reedemchkout_btn,"Click on Reedeem Checkout button")){
						Reporters.SuccessReport("Verifying Product Details In Mycart Page.", "Successfully Verified ISBN:"+Isbn+",Title:"+title+",Price:"+myCartPrice+",Trial:"+requestTextInMyCart+"</br>Clicked On Redeem/Checkout Button.</br>Navigated To Review/Submit Page.");
					}
					else{
						Reporters.failureReport("Verifying Product Details In Mycart Page.", "Failed To Verify Product Details In Mycart Page.</br>Failed TO Click On Redeem/Checkout Button.</br>Failed TO Navigate to Review/Submit Page.");
					}
				}
				else{
					if(myCartPrice.contains(ExpectedPrice) && title_beforerequest.contains(title) && Isbn.contains(IsbnBeforeRequest)){	
						if(click(ElsevierObjects.Educator_Reedemchkout_btn,"Click on Reedeem Checkout button")){		
							Reporters.SuccessReport("Verifying Product Details In Mycart Page.", "Successfully Verified ISBN:"+Isbn+",Title:"+title+",Price:"+myCartPrice+"</br>Clicked On Redeem/Checkout Button.</br>Navigated To Review/Submit Page.");
						}
						else{
							Reporters.failureReport("Verifying Product Details In Mycart Page.", "Failed To Verify Product Details In Mycart Page.</br>Failed TO Click On Redeem/Checkout Button.</br>Failed TO Navigate to Review/Submit Page.");
					}
					
				}	
			}
			
			}
			}
			catch(Exception e){sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
			return flag;
		}
		public static boolean verifyTrialLOStatus(String format_LO) throws Throwable{
		 boolean flag=true;
			try{    
		    System.out.println("lmsvalue:"+lmsvalue);
		    System.out.println("adoptionRequest_Format"+adoptionRequest_Format);
		    if(getAccountDetailsFirstName.contains(adoptionRequest_FirstName) && getAccountDetailsLastName.contains(adoptionRequest_LastName) && getAccountDetailsEmail.contains(adoptionRequest_Email) && getAccountDetailsInstitution.contains(adoptionRequest_Institution) && getAccountDetailsPhone.contains(adoptionRequest_Phone) && getAccountDetailsUserName.contains(adoptionRequest_Username) && password.contains(adoptionRequest_Password)){
		      if(title.contains(adoptionRequest_producttitle) && Isbn.contains(adoptionRequest_Isbn) && author.contains(adoptionRequest_Author) && productType.contains(adoptionRequest_ProductType) && adoptionRequest_Format.contains(format_LO) && adoptionRequest_Trial.contains(TrialStatus)){
		    	 Reporters.SuccessReport("Verifying User Information And product Information In Adoption Request Details Page.", "Verified Firstname:"+adoptionRequest_FirstName+",Lastname:"+adoptionRequest_LastName+",Email:"+adoptionRequest_Email+",Institution:"+adoptionRequest_Institution+",Usernmae:"+adoptionRequest_Username+",Password:"+adoptionRequest_Password+",Phone:"+adoptionRequest_Phone+",Country:"+adoptionRequest_Country+",Adress:"+adoptionRequest_Country+"</br>Verified ISBN:"+adoptionRequest_Isbn+",Title:"+adoptionRequest_producttitle+",ProductType:"+adoptionRequest_ProductType+",Author:"+adoptionRequest_Author+",Format:"+adoptionRequest_Format+",Trial:"+adoptionRequest_Trial);
		      }
		      else{
		    	  Reporters.failureReport("Verifying User Information And product Information In Adoption Request Details Page.", "Failed To Verify User Information And product Information In Adoption Request Details Page.");
		      }
		    }
		 }
		 catch(Exception e){sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
		    return flag;
		}
		public static boolean adoptionRequestVerifyMIlestoneDateformat(String startDate) throws Throwable{
			
			 boolean flag=true;
				try{ 
			adoptionRequest_StartDate=getText(ElsevierObjects.AR_F_Production_StartDate, "Get Start date text.");
			adoptionRequest_Warning1=getAttribute(ElsevierObjects.AR_F_Production_Warning1, "origin", "Get Warning1 text.");
			adoptionRequest_Warning2=getAttribute(ElsevierObjects.AR_F_Production_Warning2, "origin", "Get Warning2 text.");
			adoptionRequest_EndDate=getAttribute(ElsevierObjects.AR_F_Production_EndDate, "origin", "Get EndDate text.");
			adoptionRequest_UnenrollUser=getAttribute(ElsevierObjects.AR_F_Production_UnEnrollUser, "origin", "Get UnEnrollUser text.");
			
			Calendar c = Calendar.getInstance();
			Calendar c1= Calendar.getInstance();
			Calendar c2 = Calendar.getInstance();
			Calendar c4=Calendar.getInstance();
			c.add(Calendar.DATE, 10);
			c1.add(Calendar.DATE, 20);
			c2.add(Calendar.DATE, 30);
			c4.add(Calendar.DATE, 31);
			Date d=c.getTime();
			Date d1=c1.getTime();
			Date d2=c2.getTime();
			Date d3=c4.getTime();
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			// Date date = new Date();
			String currentDate_Warning1=dateFormat.format(d);
			String currentDate_Warning2=dateFormat.format(d1);
			String currentDate_EndDate=dateFormat.format(d2);
			String currentDate_UnrollUser=dateFormat.format(d3);
			
			 System.out.println(currentDate_Warning1);
			 System.out.println(currentDate_Warning2);
			 System.out.println(currentDate_EndDate);
			 System.out.println(currentDate_UnrollUser);
			if(startDate.trim().equalsIgnoreCase(adoptionRequest_StartDate.trim()) && currentDate_Warning1.equals(adoptionRequest_Warning1) && currentDate_Warning2.equals(adoptionRequest_Warning2) && currentDate_EndDate.equals(adoptionRequest_EndDate) && currentDate_UnrollUser.equals(adoptionRequest_UnenrollUser)){
				Reporters.SuccessReport("Verify the MIlestone section on the Adoption Request page After Status Fulfilled.", "Verified StartDate:"+adoptionRequest_StartDate+",Warning1:"+adoptionRequest_Warning1+",Warning2:"+adoptionRequest_Warning2+",EndDate:"+adoptionRequest_EndDate+",UnenrollUser:"+adoptionRequest_UnenrollUser);
			}
			else{
				Reporters.failureReport("Verify the MIlestone section on the Adoption Request page After Status Fulfilled.", "Failed To Verify StartDate:"+adoptionRequest_StartDate+",Warning1:"+adoptionRequest_Warning1+",Warning2:"+adoptionRequest_Warning2+",EndDate:"+adoptionRequest_EndDate+",UnenrollUser:"+adoptionRequest_UnenrollUser);
			}
				}
				 catch(Exception e){sgErrMsg=e.getMessage();
					System.out.println(e);return false;
				}
				    return flag;
				}
}
		
		
