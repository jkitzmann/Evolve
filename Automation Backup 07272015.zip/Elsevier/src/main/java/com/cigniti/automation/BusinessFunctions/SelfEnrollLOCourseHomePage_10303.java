package com.cigniti.automation.BusinessFunctions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;


public class SelfEnrollLOCourseHomePage_10303 extends EvolveCommonBussinessFunctions{
		
	//Click on the Access Code Package link and verify	
	public static String ISBNPkg;
	public static boolean selfEnrollLO() throws Throwable{
		boolean flag = true;
		Thread.sleep(medium);
		driver.manage().deleteAllCookies();
		if(!launchUrl(configProps.getProperty("URL"))){
			flag = false;
		}
		driver.manage().deleteAllCookies();
		driver.navigate().refresh();
		Thread.sleep(medium);
		if(!click(ElsevierObjects.home_student_lnkstudent,"i am student")){
			 flag=false;
		}
		
		return flag;
	}
	
	public static boolean verifySearchNumber() throws Throwable{
		boolean flag = true;
		ISBNPkg="";
		ReadingExcel re =new ReadingExcel();
		ISBNPkg =re.columnDataByHeaderName("searchNumber", "TC-10410", configProps.getProperty("TestData"));
		
		if(ISBNPkg == ""){
			Thread.sleep(medium);
			flag = false;
		}
		
		return flag;
	}
	
	public static boolean verifySelfEnrollNavigate(String courseid, String isbn, String title) throws Throwable{
		boolean flag = true;
		
		if(!click(ElsevierObjects.enrollCourse, "Click on Enroll Button")){
			flag = false;
		}
		Thread.sleep(medium);
		if(!waitForTitlePresent(ElsevierObjects.navTitle)){
			flag = false;
		}
		Thread.sleep(medium);
		if(type(ElsevierObjects.enrollInstructorCourseId, courseid, "Input Course Id ")){
			Reporters.SuccessReport("Entering Course ID In Enroll Resourse ID Text Box.", "Successfully Entered CourseID:"+courseid+" In The Enroll ResourseID TextBox.");	
		}
		else{
			Reporters.failureReport("Entering Course ID In Enroll Resourse ID Text Box.", "Failed To Enter Course ID In Enroll Resourse Textbox.");
		}
		Thread.sleep(medium);
		if(click(ElsevierObjects.enrollInstructorCourseIdContinue, "Click on Continue Button")){
			Reporters.SuccessReport("Clicking On Continue Button..", "Successfully Clicked On Continue Button.</br>Navigated To Mycart Page.");
		}
		else{
			Reporters.failureReport("Clicking On Continue Button..", "Failed To Click On Continue Button.</br>Failed to Navigate To Mycart Page.");
		}	
		Thread.sleep(500);
		
		// click Continue button on the confirmation popup
		/*if(click(ElsevierObjects.enrollInstructorCourseIdPopupContinue, "Click Continue to close popup")){
			Reporters.SuccessReport("Clicking Continue to close popup...", "Successfully closed popup");
		}
		else{
			Reporters.SuccessReport("Clicking Continue to close popup...", "Failed to close popup");
		}*/
		
		
		return flag;
	}
	
	public static boolean verifyMyCart() throws Throwable{
		boolean flag=true;
		try{
			Isbn=getText(ElsevierObjects.Student_Product_ISBN,"get isbn number.");
			title=getText(ElsevierObjects.evolve_Rview_chktitle,"Get title of book.");
			newTitle=title.split(",")[0];
			System.out.println("newTitle:"+newTitle);
			myCartPrice=getText(ElsevierObjects.evolve_Product_priceAfterRequest, "Get the product price");
			totalPriceInMyCart=getText(ElsevierObjects.evolve_AccessCode_totalprice,"Fetch total Price");
			if(Isbn.trim().contains(isbnInReceiptPage.trim()) && title.trim().contains(titleInReceiptPage.trim()) && myCartPrice.trim().contains(totalPriceInMyCart.trim()))
			{
				Reporters.SuccessReport("Verifying Product Details In My Cart Page.", "Verified ISBN:"+Isbn+",Title:"+title+",Total Price:"+totalPriceInMyCart+" is Same As Price:"+myCartPrice+" In Mycart Page.");
			}
			else{
				Reporters.failureReport("Verifying Product Details In My Cart Page.", "Failed To Verify Product details In My Cart Page: ISBN:"+Isbn+",Title:"+title+",Total Price:"+totalPriceInMyCart+" is Same As Price:"+myCartPrice+" In Mycart Page.");
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	public static boolean verifyCheckout() throws Throwable{
		boolean flag=true;
		try{
			if(click(ElsevierObjects.btnRedeem,"Click on My Cart checkout Button")){
				Reporters.SuccessReport("Clicking On Checkout Button in Mycart Page.", "Successfully Clicked On Checkout Button In Mycart Page.</br>User Is Navigated To Update Account Page.");
			}
			else{
				Reporters.failureReport("Clicking On Checkout Button in Mycart Page.", "Failed To Click On Checkout Button In Mycart Page.</br>Failed To Navigate To Update Account Page.");
			}
			Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	public static boolean verifySelfEnrollmentCourseInfo(String Value1,String Value2) throws Throwable{
		
	boolean flag=true;
	try{
		String Details=driver.findElement(By.xpath("//div[@class='enrollment rounded']/div/span[text()='"+Value1+"']")).getText();
		if(Details.trim().contains(Value1.trim())){
			Reporters.SuccessReport("Verifying Self Enrollment Course Info:"+Value2, "Successfully verified Self Enrollment Course Info "+Value2+".The Actual Value Is:"+Details+".The Expected Value Is:"+Value1);
		}
		else{
			Reporters.failureReport("Verifying Self Enrollment Course Info:"+Value2, "Failed To Verify self Enrollment Course Info.");
		}
	}
	catch(Exception e){
		System.out.println(e.getMessage());
	}
	
	return flag;
	
	}
	public static boolean verifySelfEnrollmentFacultyName(String Value1,String Value2,String Value3) throws Throwable{
		
		boolean flag=true;
		try{
			String Details=driver.findElement(By.xpath("//div[@class='enrollment rounded']/div/span[text()='"+Value1+"']")).getText();
			if(Details.trim().contains(Value2.trim())){
				Reporters.SuccessReport("Verifying Self Enrollment Course Info:"+Value3, "Successfully verified Self Enrollment Course Info "+Value2);
			}
			else{
				Reporters.failureReport("Verifying Self Enrollment Course Info:"+Value3, "Failed To Verify self enrollment Course Info.");
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		return flag;
		
		}
	public static boolean verifyMyEvolveCourseId() throws Throwable{
		boolean flag=true;
		
		if(click(ElsevierObjects.Myevolve,"Click on my evolve")){
			Reporters.SuccessReport("Clicking On My Evolve Tab.", "Successfully Clicked On My Evolve Tab.");
		}
		else{
			Reporters.failureReport("Clicking On My Evolve Tab.", "Failed To Click On My Evolve Tab.");
		}
		Thread.sleep(high);
		
		if(!click(ElsevierObjects.Kno_refresh_lnk,"Click on refresh content list")){
			flag=false;
		}
		Thread.sleep(medium);
		if(click(By.xpath("//*[@id='set']/li/div/div/span[text()='COURSE ID: "+courseID1+"']/following-sibling::a"),"Click on COurse Title.")){
			Reporters.SuccessReport("Clicking on the new link for the purchased course within the user's content list. ", "Successfully Clicked On Couser Link of CourseID :"+courseID1+".Navigated To Course Details Page.");
		}
		else{
			Reporters.failureReport("Clicking on the new link for the purchased course within the user's content list. ", "Failed To Click On Course Link of CourseID :"+courseID1+" And Failed To Navigate To Course Details Page.");
		}
		
		Thread.sleep(60000);
		//driver.manage().timeouts().implicitlyWait(600, TimeUnit.SECONDS);
		

		return flag;
	}
	
	public static boolean verifyCoursePage() throws Throwable{
		boolean flag=true;
		try{
		
			
			if(click(ElsevierObjects.educator_CoursePage_Courselink, "Click on course link present in course details page.")){
			Reporters.SuccessReport("Clicking On Course Link.", "Clicked On Course Link In content menu.");
				}
			else{
				Reporters.failureReport("Clicking On Course Link.", "Failed To Click On Course Link In content menu.");
			}
			Thread.sleep(high);
			List<WebElement> s=driver.findElements(ElsevierObjects.educator_CoursePage_SubFolders);
			  for(WebElement subFolder:s){
			//String subFolders=getText(ElsevierObjects.educator_CoursePage_SubFolders, "Get All Subfolders Title.");
			
			if(waitForElementPresent(ElsevierObjects.educator_CoursePage_SubFolders, "Course folder contains sub folders.")){
				Reporters.SuccessReport("Verifying subfolders.", "Verified Subfolders of Course Folder.</br>SubFolder is:"+subFolder.getText());
			}
			else{
				Reporters.failureReport("Verifying subfolders.", "Failed To Verify Subfolders of Course Folder.");
			}
			  }
			Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
				return flag;
	}
	
	public static boolean verifyMyEvolveAdmin(String courseid) throws Throwable{
		boolean flag=true;
		
		//click on My evolve link 
		if(!click(ElsevierObjects.Admin_Evolve_lnk, "Click on Evolve Admin link")){
			flag = false;
		}
		Thread.sleep(medium);
		
		//click on View Edit User Profile link 
		if(!click(ElsevierObjects.Admin_ViewEdit_UserProfile, "Click on View/Edit Evolve User PRofile")){
			flag = false;
		}
		Thread.sleep(medium);
		
		
		Map<String, String> values=readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData"));
		String userName=values.get("UserName");
		if(!type(ElsevierObjects.Admin_SearchUser_UserName, userName, "Input UserNamed ")){
			Thread.sleep(medium);
			flag = false;
		}
		Thread.sleep(medium);
		
		if(!click(ElsevierObjects.Admin_SearchUser_SearchButton, "Click on Search Button")){
			flag = false;
		}
		Thread.sleep(medium);
		
		if(!click(ElsevierObjects.Admin_CourseParReport_Search_Results_Row2, "Click on Search Results")){
			flag = false;
		}
		Thread.sleep(medium);
		if(!click(ElsevierObjects.parBtn, "Click on Search Results")){
			flag = false;
		}
		
		//check for courseid
		if(!selectByVisibleText(ElsevierObjects.enrollCourseId,courseid ,"Check Course id Exists")){
					flag=false;
				}
				Thread.sleep(medium);

				return flag;
	}
	public static boolean creditCardData(String cardType,String cardNumber,String cvvNumber,String nameOnCard,String expMonth,String expYear) throws Throwable{
		boolean flag = true;
		//String errorMessage ="";
		try {
			if(!selectByVisibleText(ElsevierObjects.lstcardtype, cardType,"")){
				flag = false;
			}
			if(!type(ElsevierObjects.Student_CardNumber_txt, cardNumber, "")){
				flag = false;
			}
			if(!type(ElsevierObjects.Student_Cardcvv_txt, cvvNumber, "")){
				flag = false;
			}
			if(!type(ElsevierObjects.Student_Cardname_txt, nameOnCard, "")){
				flag = false;
			}
			if(!selectByVisibleText(ElsevierObjects.Student_CardExpMnth_txt, expMonth, "")){
				flag = false;
			}
			
			if(!selectByVisibleText(ElsevierObjects.Student_CardExpYr_txt, expYear, "")){
				flag = false;
			}
			
			if(click(ElsevierObjects.Student_Card_continue_btn, "")){
				Reporters.SuccessReport("Entering Credit Card Details And Clicking On Submit Button.", "Successfully Entered Credit Card Details Card Type:"+cardType+",Card Number:"+cardNumber+",Cvv Number:"+cvvNumber+",Expiry Month:"+expMonth+",Expiry Year:"+expYear+"</br>Clicked On Submit Button.</br>Successfully Navigated To Review And Submit Page.");
			}	
			else{
				Reporters.failureReport("Entering Credit Card Details And Clicking On Submit Button.", "Failed To Enter Credit Card Details.");
			}
			} 
			catch (Exception e) {
				System.out.println(e.getMessage());
			}
		return flag;
	}

	public static boolean  verifyTextPresent(String text) throws Throwable{  
		boolean flag=false;
		String bool=configProps.getProperty("OnSuccessReports");
		boolean b=Boolean.parseBoolean(bool);
		if(!(driver.getPageSource()).contains(text))
		{
		
			Reporters.SuccessReport("VerifyTextPresent",text+" is not present in the page");
			flag= true;
		}
		else if(b && flag)
		{
			Reporters.failureReport("VerifyTextPresent",text+" is present in the page");
			flag= false;
			
		}
		return flag;
	}
	public static boolean StudentReviewandSubmit() throws Throwable{
	    boolean flag = true;
	  try{
	  
		//totalPriceInReviePage=getText(ElsevierObjects.Student_Review_Totalprice, "Total price in review page");
	    priceInReviewPage=getText(ElsevierObjects.evolve_Rview_chkprice, "price in review page");
	    isbnInReviewPage=getText(ElsevierObjects.evolve_Rview_chkIsbn,"Isbn in review page");
	    titleInReviewPage=getText(ElsevierObjects.evolve_Rview_chktitle, "Title in review page");
	  
	    
	    if(priceInReviewPage.contains(myCartPrice) && titleInReviewPage.contains(title) && isbnInReviewPage.trim().contains(Isbn.trim()) /*&& totalPriceInReviePage.contains(priceInReviewPage)*/){
	    	
	        click(ElsevierObjects.evolveRegisterAcceptChk,"Click on Register checkbox");
	        Thread.sleep(medium);
	        if(click(ElsevierObjects.instructor_submit,"Click on Student Submit button")){
	        	Reporters.SuccessReport("Verifying Price,Title,ISBN in Review/Submit Page.clicking On Submit Button", "Successfully Verified Price:"+priceInReviewPage+",ISBN:"+isbnInReviewPage+",Title:"+titleInReviewPage+"  in Review/Submit Page.</br>Successfully Clicked On Checkbox Yes, I accept the Registered User Agreement.</br>Successfully Clicked On Submit Button.</br>Navigated To Receipt Page.");
	        }
	        else{
	        	Reporters.failureReport("Verifying Price,Title,ISBN in Review/Submit Page.clicking On Submit Button", "Failed To Verify Price,ISBN,Title in Review/Submit Page.</br>Failed To Click On Checkbox Yes, I accept the Registered User Agreement Checkbox.</br>Failed To Click On Submit Button.</br>Failed To Navigate To Receipt Page.");
	        }
	       Thread.sleep(medium);
	  }
	  }
	  catch(Exception e){
		System.out.println(e.getMessage());
	  }
	  return flag;
	}
	public static boolean verifyReceiptPage() throws Throwable{
		boolean flag=true;
		try{
			
			String courseIdInReceiptPage=getText(By.xpath("//div[@class='row']//div[@class='enrollment rounded']/div/span[text()='"+courseID1+"']"), "");
			titleInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chktitle,"Price in Receipt page");
			isbnInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chktisbn,"Price in Receipt page");
			PriceinReceiptPage=getText(ElsevierObjects.evolve_Receipt_chkprice,"Price in Receipt page");
			if(isbnInReceiptPage.contains(isbnInReviewPage) && titleInReceiptPage.contains(titleInReviewPage) &&  PriceinReceiptPage.equals(priceInReviewPage) && courseIdInReceiptPage.contains(courseID1)){
				Reporters.SuccessReport("Verifying Product details In Receipt Page.", "Successfully Verified price:"+PriceinReceiptPage+", ISBN:"+isbnInReceiptPage+", Title:"+title+" , CourseID :"+courseIdInReceiptPage+" in Receipt Page.");
			}
			else{
				Reporters.failureReport("Verifying Product details In Receipt Page.", "Failed To Verify Product Details In Receipt Page.");
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	public static boolean studentLogin(String Username,String Password) throws Throwable
	{
		try
		{
			boolean flag = true;
			driver.manage().deleteAllCookies();
			//driver.navigate().refresh();
			if(!launchUrl(configProps.getProperty("URL4"))){
				flag = false;
			}
			Thread.sleep(medium);
			
			driver.manage().deleteAllCookies();
			
			if(!click(ElsevierObjects.student_login,"Clicked On student LogIn")){
				flag = false;
			}
			if(!type(ElsevierObjects.email,Username,"Email")){
				flag = false;
			}
			if(!type(ElsevierObjects.password,Password,"Email")){
				flag = false;
			}
			if(!click(ElsevierObjects.submit,"Clicked on Login Button")){
				flag = false;
			}

            System.out.println("************************* Student login is Completed*************************");
			return flag;
		}catch(Exception e){return false;

		}
	}

	public static void clickNoInstitution(String user) throws Throwable{
		
		if(click(ElsevierObjects.student_chkInstution,"Click on NO Institution Check box")){
			Reporters.SuccessReport("Clicking On Not Affiliated Check box for "+user+" in Update Account Page.", "Successfully Clicked On Not Affiliated with Institution CheckBox.");
		}
		else{
			Reporters.failureReport("Clicking On Not Affiliated Check box for "+user+" in Update Account Page.", "Failed To Click On Not Affiliated with Institution CheckBox.");
		}
		if(click(ElsevierObjects.evolve_User_submitbtn,"Click submit button")){
			Reporters.SuccessReport("Clicking On Submit Button.", "Successfully Clicked On Submit Button.");
		}
		else{
			Reporters.failureReport("Clicking On Submit Button.", "Failed To Click On Submit Button.");
		}
	}
	public static boolean applyAccessCodeInMycart(String applyAccesscode) throws Throwable{
		boolean flag=true;
		try{
			if(click(ElsevierObjects.access_apply_chkbox,"Click on I have access code radio button")){
				Reporters.SuccessReport("Clicking On I Have Access Code Radio Button.", "Successfully Clicked On I Have AccessCode Radio Button.");
			}
			else{
				Reporters.failureReport("Clicking On I Have Access Code Radio Button.", "FailedTo Click On I Have AccessCode Radio Button.");
			}
			Thread.sleep(high);
			
			//String invalidAccessCode=readcolumns.twoColumns(0, 1,"Tc-15228", configProps.getProperty("TestData")).get("invalidaccessCode");
			if(type(ElsevierObjects.accessCode_type,accessCode, "Enter invalid access code")){
				Reporters.SuccessReport("Entering AccessCode in I Have Accesscode Text Box.", "Successfully Entered Accesscode :"+accessCode+" in I Have Accesscode Textbox.");
			}
			else{
				Reporters.failureReport("Entering AccessCode in I Have Accesscode Text Box.", "Failed To Enter Accesscode :"+accessCode+" in I Have Accesscode Textbox.");
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.accessCode_submit, "Click on Access code apply button")){
				Reporters.SuccessReport("Clicking On Accesscode Apply Button.", "Successfully Clicked On Accesscode Apply Button.");
			}
			else{
				Reporters.failureReport("Clicking On Accesscode Apply Button.", "Failed To Click On Accesscode Apply Button.");
			}
			Thread.sleep(medium);
			if(applyAccesscode.equalsIgnoreCase("true")){
				myCartPrice=getText(ElsevierObjects.evolve_Product_priceAfterRequest, "Get the product price");
				if(myCartPrice.equals(ExpectedPrice)){
					Reporters.SuccessReport("Verifying Price After Applying Accesscode.", "Verified Price Redems To "+myCartPrice+" After Applying Accesscode.");
				}
				else{
					Reporters.failureReport("Verifying Price After Applying Accesscode.", "Failed To Verify Price After Applying Accesscode.");
				}
			}
			else{
				String accessCodeErrorMssg=readcolumns.twoColumns(0, 1,"Tc-15228", configProps.getProperty("TestData")).get("accessCodeError");

				if(verifyText(ElsevierObjects.accessCode_Verify, accessCodeErrorMssg, "Verify the error message")){
					Reporters.SuccessReport("Entering AccessCode in AcessCode TextBox.</br> Verifying Error Message.", "Entered AcessCode:"+accessCode+" in AccessCode Text Box.</br>Verified Error Message:"+accessCodeErrorMssg);
				}
				else{
					Reporters.failureReport("Entering AccessCode in AcessCode TextBox.</br> Verifying Error Message.", "Failed To Enter AcessCode in AccessCode Text Box.");
				}
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	
}
