package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.FraudTestCases_Lib;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class TC_17126_CreateNewSTUDENT_User extends FraudTestCases_Lib{

	@Test
	public static void tC_17126_CreateNewSTUDENT_User() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		EvolveCommonBussinessFunctions.SwitchToBrowser(ElsevierObjects.adminBrowserType);
		
		String user = ReadingExcel.columnDataByHeaderName("StudentUser", "FraudTestCases", testDataPath);
		String fName = ReadingExcel.columnDataByHeaderName("FirstName", "FraudTestCases", testDataPath);
		String lName = ReadingExcel.columnDataByHeaderName("LastName", "FraudTestCases", testDataPath);
		String email = ReadingExcel.columnDataByHeaderName("Email", "FraudTestCases", testDataPath);
		String password = ReadingExcel.columnDataByHeaderName("Password", "FraudTestCases", testDataPath);
		
		stepReport("Create a New Student User");
		createNewUser(user, fName, lName, email, password);
		
		stepReport("Logout from student user");
		evolveLogout();
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
