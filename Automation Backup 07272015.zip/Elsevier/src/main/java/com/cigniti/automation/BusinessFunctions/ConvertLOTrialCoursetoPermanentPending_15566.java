package com.cigniti.automation.BusinessFunctions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.testng.Reporter;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class ConvertLOTrialCoursetoPermanentPending_15566 extends EvolveCommonBussinessFunctions{

	//public static Map<String, String> values=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-9804", configProps.getProperty("TestData"));
public static boolean adoptionRequestVerifyMIlestonesData() throws Throwable{
	boolean flag=true;
	try{
		List<String> adoptionRequestMIlestonedata=new ArrayList<String>();
		
		adoptionRequestMIlestonedata.add(adoptionRequest_StartDate);
		adoptionRequestMIlestonedata.add(adoptionRequest_Warning1);
		adoptionRequestMIlestonedata.add(adoptionRequest_Warning2);
		adoptionRequestMIlestonedata.add(adoptionRequest_EndDate);
		adoptionRequestMIlestonedata.add(adoptionRequest_UnenrollUser);
		adoptionRequestMIlestonedata.add(adoptionRequest_EmailTemplate_StartDate);
		adoptionRequestMIlestonedata.add(adoptionRequest_EmailTemplate_Warning1);
		adoptionRequestMIlestonedata.add(adoptionRequest_EmailTemplate_Warning2);
		adoptionRequestMIlestonedata.add(adoptionRequest_EmailTemplate_EndDate);
		
		
		List<String> testData = new ArrayList<String>();
	 	
		testData.add(compareStartDate);
		testData.add(warning1Days);
		testData.add(wraning2Days);
		testData.add(endDays);
		testData.add(unEnrollDays);
		testData.add(compareEmailTemplateStartDate);
		testData.add(compareEmailTemplateWarning1);
		testData.add(compareEmailTemplateWarning2);
		testData.add(compareEmailTemplateEnd);
		
		
	 	System.out.println(testData);
	 	
	 	List<String> compareData = new ArrayList<String>();
	 	for(String compareMIlestoneData: adoptionRequestMIlestonedata){
	 		compareData.add(testData.toString().trim().contains(compareMIlestoneData.toString().trim())? "Yes" : "No");
	 		System.out.println(compareData);
			 
		 }
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
	
	return flag;
}
public static boolean  verifyMIlestoneTextPresent(String text) throws Throwable
{  
	boolean flag=false;
	try{
	
	if(!(driver.getPageSource()).contains(text))
	{
	
		Reporters.SuccessReport("VerifyTextPresent",text+" is not present in the page");
		flag= false;
	}
	else 
	{
		Reporters.failureReport("VerifyTextPresent",text+" is present in the page");
		
		flag= true;
		
	}

}
catch(Exception e){
	sgErrMsg=e.getMessage();
	System.out.println(e);return false;
}

	return flag;
}
/**Generic method for Converting Trial course to permanent in Adoption request page.
 * 
 * @return
 * @throws Throwable
 */
public static boolean adoptionRequestConvertTrialToPermanant() throws Throwable{
	try{
		if(click(ElsevierObjects.adoptionRequest_ConvertToPermanent, "Click on convert to permanent button")){
			Reporters.SuccessReport("Clicking On Convert To Permanent Button In Adoption Request Details Page.","Successfully Cliked On Convert To Permanent Button.");
		}
		else{
			Reporters.failureReport("Clicking On Convert To Permanent Button In Adoption Request Details Page.", "Failed To Click On Convert To Permanent Button.");
		}
		Thread.sleep(medium);
		if(verifyText(ElsevierObjects.adoptionRequest_ConvertMessage, verifymessage, "Verify convert to permanent message.")){
			Reporters.SuccessReport("Verifying Convert Message After Converting To Permanent.", "Successfully Verified Convert Message:"+verifymessage+" After Converting To Permanent.");
		}
		else{
			Reporters.failureReport("Verifying Convert Message After Converting To Permanent.", "Failed To Verify Convert Message.");
		}
		Thread.sleep(medium);
		verifyMIlestoneTextPresent(MIlestone);
		Thread.sleep(medium);
		if(verifyText(ElsevierObjects.adoptionRequest_UpdatedHistoryText, verifymessage, "Verify convert to permanent message.")){
			Reporters.SuccessReport("Verify there is now an entry at the bottom of the Update history that states:"+verifymessage, "Successfully Verified Message In Update History Table.");
		}
		else{
			Reporters.failureReport("Verify there is now an entry at the bottom of the Update history that states:"+verifymessage, "Failed To Verify Message In Update History Table.");
		
		}
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
	
	return true;
	}
		
/**Generic method for changing status to fulfilled in Adoption request page in Admin Portal.
 * 
 * @return
 * @throws Throwable
 */
public static boolean changeStatusToFullfilled(String changeStatus) throws Throwable{	
	try{
		selectByVisibleText(ElsevierObjects.adoptionRequestStatus, changeStatus, "Change status to fullfilled.");
		Thread.sleep(medium);				
		if(click(ElsevierObjects.adoptionRequest_Save,"Click on Save button.")){
			Reporters.SuccessReport("Changing Status And clicking On Save Button.", "Successfully Changed Status To :"+changeStatus+" And Clicked On Save Button");
		}
		else{
			Reporters.failureReport("Changing Status And clicking On Save Button.", "Failed To Change Status To :"+changeStatus+" And Failed To Click On Save Button");
		}
		Thread.sleep(veryhigh);
		click(ElsevierObjects.emailPopup,"Send mail button on popup.");
	
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
	return true;
	}
/**Generic method for clicking on Catalog Link
 * 
 * @return
 * @throws Throwable
 */

public static boolean catalogButton() throws Throwable{
	boolean flag=true;
	try{
		click(ElsevierObjects.Catalog_Header_Link, "Catalog");
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
	
	return flag;
}
public static void myEvolve() throws Throwable{
	click(ElsevierObjects.Myevolve,"Click oN My Evolve");
}
/**Generic method for clicking on OnlineCourse HoneyPot
 * 
 * @return
 * @throws Throwable
 */

public static boolean onlineCourseHoneyPot() throws Throwable{
	boolean flag=true;
	try{
	click(ElsevierObjects.evolve_OnlineCourseHoneypot, "Click on Online Course Honey Pot.");
    Thread.sleep(medium);
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
return flag;
}
public static boolean onlineSubmitStudent(String rosterdetails) throws Throwable{
	boolean flag=true;
	try{
		/*if(javaClick(ElsevierObjects.evolve_OnlineCourse_GetStudentsLink,"Click on Get Students link in online course honeypot.")){
			Reporters.SuccessReport("Choosing 'Get Students Link' In Online Courses Honeypot.", "Successfully Clicked On Get Students Link in Online Course Honeypot.");
		}
		else{
			Reporters.failureReport("Choosing 'Get Students Link' In Online Courses Honeypot.", "Failed To Click On Get Students Link in Online Course Honeypot.");
		}*/
		Thread.sleep(medium);
		if(click(ElsevierObjects.evolve_GetStudentsLink_SubmitLink ,"click on submit roster student link.")){
			Reporters.SuccessReport("Clicking On The Link:'Submitting Your Class Roster'", "Successfully Clicked On 'Submitting Your Class Roster'</br>User is now on Submit your Course Roster page.");
		}
		else{
			Reporters.failureReport("Clicking On The Link:'Submitting Your Class Roster'", "Failed To Click On 'Submitting Your Class Roster'");
		}
		Thread.sleep(medium);
		if(type(ElsevierObjects.evolve_SubmitLink_enterCourseIDTxt,courseID1,"enter course id.")){
			Reporters.SuccessReport("Entering Course ID In Text Box.", "Successfully Entered CourseID:"+courseID1+" In TextBox.");
		}
		else{
			Reporters.failureReport("Entering Course ID In Text Box.", "Failed To Enter CourseID:"+courseID1+" In TextBox.");
		}
		if(type(ElsevierObjects.evolve_SubmitLink_enterRoster, rosterdetails, "Enter details.")){
			Reporters.SuccessReport("Entering RosterDetails Text Box.", "Successfully Entered RosterDetails:"+rosterDetails+" In TextBox.");
		}
		else{
			Reporters.failureReport("Entering RosterDetails Text Box.", "Failed To Enter RosterDetails:"+rosterDetails+" In TextBox.");
		}
		if(click(ElsevierObjects.evolve_SubmitLink_enterRoster_RosterButton, "Click on roster submit button.")){
			Reporters.SuccessReport("Clicking On Submit Button", "Successfully Clicked On Submit Button.");
		}
		else{
			Reporters.failureReport("Clicking On Submit Button", "Failed To Click On Submit Button.");
		}
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
return flag;
}
}
