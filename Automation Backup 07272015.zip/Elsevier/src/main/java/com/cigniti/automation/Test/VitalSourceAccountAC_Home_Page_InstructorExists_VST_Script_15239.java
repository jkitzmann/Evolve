package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.BusinessFunctions.VitalSourceAccountAC_HomePage_StudentExists_VST;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class VitalSourceAccountAC_Home_Page_InstructorExists_VST_Script_15239 extends VitalSourceAccountAC_HomePage_StudentExists_VST{
		
	@Test 
	public void vitalSourceAccountAC_Home_Page_InstructorExists_VST_15239() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String username1=ReadingExcel.columnDataByHeaderName( "VST_StudentUsername", "VST",configProps.getProperty("TestData"));
			String password1=ReadingExcel.columnDataByHeaderName( "VST_StudentPassword", "VST",configProps.getProperty("TestData"));
			
			/*
			String username=readcolumns.twoColumns(0, 1,"DynamicCredentials",configProps.getProperty("TestData")).get("UserName");
			String password=readcolumns.twoColumns(0, 1,"DynamicCredentials",configProps.getProperty("TestData")).get("Password");
*/
			String user1="instructor";
			String username=readcolumns.twoColumns(0,1, "VSTPageBurstCredentials", configProps.getProperty("TestData")).get("VitalSourceAccountPageburstCCNewInstructor15242");
			String password=readcolumns.twoColumns(0,2, "VSTPageBurstCredentials", configProps.getProperty("TestData")).get("VitalSourceAccountPageburstCCNewInstructor15242");
			writeReport(login(user1,username, password), "Login into Existing Instructor", "Successfully logged into the Instructor with the credentials: <br/> Username : "+username+"<br/> Password : "+password, "Failed to log into the application");
			pageBurstReedem1();
			String user = "educator";
			AccessCodeReviewandSubmitVST(user);
			String accessCodeUser = "educator";
			//String beforeTitle=titleInReceiptPage;
			//String condition="myCartTitle";
			String condition="existingStudEducator";
			
			pageburstVstLink(accessCodeUser, acessCode_titleAfterRequest,"validTitle");
			if(instructorLogout())
			{
				Reporters.SuccessReport("Logout from Instructor", "Successfully logged out from instructor");
			}
	       else{
				Reporters.failureReport("Logout from Instructor", "Failed to log out from instructor");
			}
			//String user2="";
			/*if(reCheckingAccessCode(user2))
			{
				Reporters.SuccessReport("ReChecking Access Code", "User is given an error when attempted to enter the used vst access code.  <br>The code is now redeemed so no other user should be able to use this code.  The VST item is not added to the card and the access code is not applied.");
			}
	       else{
				Reporters.failureReport("ReChecking Access Code", "User is failed to give an error message when attempted to enter the used vst access code.  <br>The code is now redeemed so no other user should be able to use this code.  The VST item is not added to the card and the access code is not applied."); 
			}*/
			reLogingForAccessCodeRedeem(username1,password1);
			ReadingExcel.removeUsedVSTCode(VSTDataPath, "VSTCodes");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ReadingExcel.removeUsedVSTCode(VSTDataPath, "VSTCodes");
		}
	}
	@AfterTest
	public void closeBrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
	
}
