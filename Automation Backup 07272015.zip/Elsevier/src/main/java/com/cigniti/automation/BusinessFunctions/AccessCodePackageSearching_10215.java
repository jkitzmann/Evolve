package com.cigniti.automation.BusinessFunctions;



import java.util.List;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadData;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class AccessCodePackageSearching_10215 extends EvolveCommonBussinessFunctions{
	
	public static String Msg=null;
	public static String gErrMsg=null;
	public static String ISBN=null;
	public static String packageISBN;
	public static String searchPackage;
	public static String exPackage;
	public static String addISBN;
	
	public static boolean AcessCodePage() throws Throwable {
		boolean flag = true;
	try{	
		if(!click(ElsevierObjects.maintainaccess, "Maintain Access Code")){
			flag = false;
		  }
		 if(!waitForElementPresent(ElsevierObjects.txtverify, "text to be verified after login")){
			 flag = false;
         }
		 if(!waitForElementPresent(ElsevierObjects.txtBreadCrumb, "BreadCrumb text to be verified after login")){
			 flag = false;
	         }
	}catch(Exception e){
		sgErrMsg=e.getMessage();return false;
	}
		 return flag;
	}

		public static boolean regressionPackageData() throws Throwable{
		
			boolean flag = true;
		try{
			ReadingExcel r=new ReadingExcel();
			  	
				
				List<String> testdata=r.columnData(3,"Tc-10215", configProps.getProperty("TestData"));
				 
				  for(String testString1 : testdata){
					  
				   if(!type(ElsevierObjects.packageIsbntxtbox, testString1, "Enter Package Isbn Number")){
				    flag = false;
				   }
				   int len=testString1.length();
				   System.out.println(len);
				 
				   Pattern p = Pattern.compile("[^A-Za-z0-9]");
				   Matcher m = p.matcher(testString1);
				   boolean b = m.find();
				     if (b || testString1.length()!=13)
				     {
						    System.out.println(len);
							   if(!click(ElsevierObjects.PackageIsbnGo,"Go")){
								 
								   flag = false;
						   }
							   Alert();
							   
				     }
				   else {
					 
					   if(!click(ElsevierObjects.PackageIsbnGo,"Go")){
						    flag = false;

					   			}
				   			}
					 	}
				   	
		}catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
				     return flag;
				  
			}
			
		  public static boolean regressionItemISBN_Data() throws Throwable{
						
					boolean flag = true;
				try{
					ReadingExcel r=new ReadingExcel();
				
					List<String> testdata2=r.columnData(3,"Tc-10215", configProps.getProperty("TestData"));
					
					for(String testString2 : testdata2){
					  if(!type(ElsevierObjects.itemIsbntxtbox, testString2, "Item ISBN Text Box")){
						  flag = false;
				   }
				 
					  Pattern p = Pattern.compile("[^A-Za-z0-9]");
					   Matcher m = p.matcher(testString2);
					   boolean b = m.find();
					   
					   if (b || testString2.length()!=13)
					   {
					   if(!click(ElsevierObjects.itemGo,"Go"))
					   {
						   flag = false;
					   		}
					   Alert();
					   }
					 
					   else{
						   if(!click(ElsevierObjects.itemGo,"Go")){
						   flag = false;

							   }
						   }
					   
				  	}
		  }catch(Exception e){
				sgErrMsg=e.getMessage();return false;
			}
				
			return flag;
		}
		
		public static boolean regressionPackageName() throws Throwable{
			
			boolean flag = true;
		try{
			ReadingExcel r=new ReadingExcel();
			List<String> testdata1=r.columnData(2,"Tc-10215", configProps.getProperty("TestData"));
			
			  for(String testString : testdata1){
			   if(!type(ElsevierObjects.packagenametxtbox, testString, "Enter Package Name")){
			    flag = false;
			   }

			   if(!click(ElsevierObjects.packageNameGo,"Go")){
				   
			    flag = false;
			   }
			   String sucMsg=getText(ElsevierObjects.Packagename_verifytext, "");
			   if(verifyText(ElsevierObjects.Packagename_verifytext,"Search Results","Verift text in Package name page")){
				   Reporters.SuccessReport("The Success Message Validation", "The Message : "+sucMsg+" is successfully displayed");		
		 		}else{
		 			Reporters.failureReport("The Success Message Validation", "The Message : "+sucMsg+" is failed to display");
		 		}
			    Thread.sleep(medium);
			   driver.navigate().back();
			    Thread.sleep(medium);
		  }
		}catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
			  return flag;
		}

		public static boolean verifyPackageISBN(String packageISBN) throws Throwable{
		
			boolean flag = true;
		try{
				if(!type(ElsevierObjects.packageIsbntxtbox,packageISBN,"Enter Package Isbn Number")){
					flag = false;
				}
				
				if(!click(ElsevierObjects.PackageIsbnGo,"Go")){
					flag = false;
				}
				
				if(!isEnabled(ElsevierObjects.checkPackISDN,"Package ISDN textbox")){
					flag = false;
				}
				
				if(!isEnabled(ElsevierObjects.checkPackName,"Package Name textbox")){
					flag = false;
				}
				
				if(!isEnabled(ElsevierObjects.checkISDNAdd,"ISDN Add Button")){
					flag = false;
				}
		
				if(!click(ElsevierObjects.linkEvolve,"Evolve Admin")){
					flag = false;
				}
				if(!click(ElsevierObjects.maintainaccess, "Maintain Access Code")){
					flag = false;
				}
				if(!waitForElementPresent(ElsevierObjects.txtverify, "text to be verified after login")){
					 flag = false;
		        }
				if(!waitForElementPresent(ElsevierObjects.txtBreadCrumb, "BreadCrumb text to be verified after login")){
					 flag = false;
				}
			    if(!type(ElsevierObjects.packagenametxtbox,readcolumns.twoColumns(0,1,"Tc-10215",configProps.getProperty("TestData")).get("ExamplePackage_Name"),"Enter Package Name")){
				flag = false;
			    }
			    if(!click(ElsevierObjects.packageNameGo,"Go")){	
				flag = false;
			    }
			    //Alert();
			    String sucMsg=getText(ElsevierObjects.errorMsg, "");
			    if(verifyText(ElsevierObjects.errorMsg,"There are no packages found based on this criteria.","Package not found")){
			    	Reporters.SuccessReport("The Success Message Validation", "The Error Message : "+sucMsg+" is successfully displayed");		
		 		}else{
		 			Reporters.failureReport("The Success Message Validation", "The Error Message : "+sucMsg+" is failed to display");
		 		}
		}catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
			    return flag;
		}
			  
		public static boolean verify_ItemISBN(String exPackage,String searchPackage,String addISBN) throws Throwable{
					
					boolean flag = true;
			try{		
			    //ISBN text Link
			    if(!type(ElsevierObjects.packageIsbntxtbox,exPackage,"Enter Package ISBN")){
				flag = false;
			    }
			    if(!click(ElsevierObjects.PackageIsbnGo,"Go")){
				flag = false;
			    }
			    String sucMsg=getText(ElsevierObjects.textMsg, "");
			    if(verifyText(ElsevierObjects.textMsg,"Package ISBN not found.","Text Msg")){
			    	Reporters.SuccessReport("The Success Message Validation", "The Error Message : "+sucMsg+" is displayed");		
		 		}else{
		 			Reporters.failureReport("The Success Message Validation", "The Error Message : "+sucMsg+" is failed to display");
		 		}
			    if(!type(ElsevierObjects.itemIsbntxtbox,searchPackage,"Enter Item ISBN")){
				flag = false;
			    }
			    if(!click(ElsevierObjects.itemGo,"Go")){
				flag = false;
			    }
			    if(!waitForElementPresent(ElsevierObjects.isbnpackageKeytxt, "verify text Package name")){
		    	flag = false;
		        }
			    if(!waitForElementPresent(ElsevierObjects.isbnpackageNametxt, "verify text Package name")){
		    	flag = false;
			   	}
			    if(!waitForElementPresent(ElsevierObjects.isbnLastUpdatetxt, "verify text Package name")){
		    	flag = false;
			    }
			    if(!waitForElementPresent(ElsevierObjects.isbnUpdateBytxt, "verify text Package name")){
		    	flag = false;
			    }
			    if(!click(ElsevierObjects.exPackageKey,"Click on PackageKey")){
		    	flag = false;
			    }
			    if(!waitForElementPresent(ElsevierObjects.txtEditpackage, "verify text Edit Package")){
				flag = false;
			    }
			    if(!waitForElementPresent(ElsevierObjects.txtPackagekey, "verify text PackageKey")){
				flag = false;
			    }
			
			    if(!isEnabled(ElsevierObjects.editpackageName,"Edit Package Name textbox")){
				flag = false;
			    }
			    if(!type(ElsevierObjects.addISBNTxtBox,addISBN,"Enter ISBN")){
				flag = false;
			    }
			    if(!click(ElsevierObjects.addButton,"Click Add Button")){
				flag = false;
			    }
			    if(!click(ElsevierObjects.removeLink,"Click Remove Button")){
		    	return false;
			    }
		}catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}		
		return flag;
}

}

