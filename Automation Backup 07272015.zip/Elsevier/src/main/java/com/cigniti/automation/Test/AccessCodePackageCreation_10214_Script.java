package com.cigniti.automation.Test;


import java.util.List;
import java.util.Map;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.AccessCodePackageCreation_10214;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;
import com.cigniti.automation.datadriven.ReadResourceData;

public class AccessCodePackageCreation_10214_Script extends AccessCodePackageCreation_10214{
	//public static Map<String, String> TC10214_RETESTING=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-10214_RETESTING", configProps.getProperty("TestData"));
	ReadingExcel r=new ReadingExcel();
	
	@Test
	public void accessCodePackageCreation_10214() throws Throwable{

	try{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		
		String isbn1=ReadingExcel.getCell(6, 1, testDataPath, "TC-10214");
		String isbn2=ReadingExcel.getCell(7, 1, testDataPath, "TC-10214");
		String isbn3=ReadingExcel.getCell(8, 1, testDataPath, "TC-10214");
		String isbn4=ReadingExcel.getCell(9, 1, testDataPath, "TC-10214");
		String isbn5=ReadingExcel.getCell(10, 1, testDataPath, "TC-10214");
		
		stepReport("Get the current details of the package products.");
		isbnVerify("TC-10214",isbn1, 15, 16, 17, 1);
		isbnVerify("TC-10214",isbn2, 18, 19, 20, 1);
		isbnVerify("TC-10214",isbn3, 21, 22, 23, 1);
		isbnVerify("TC-10214",isbn4, 24, 25, 26, 1);
		isbnVerify("TC-10214",isbn5, 27, 28, 29, 1);
		
		
		
		//String str=readcolumns.twoColumns(0, 1, "TC-10214", configProps.getProperty("TestData")).get("ISBNPkgName");
		String str=ReadingExcel.keyValueBasedOnCommonValue(testDataPath, "GenericValue", 0, 1, 2, "TC-10214").get("ISBNPkgName");
		
		stepReport("Login to Evolve Admin and navigate to Add Access Code Package.");
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),ReadResourceData.getResourceData("TC-10214-1", configProps.getProperty("AdminUser")),
				ReadResourceData.getResourceData("TC-10214-2", configProps.getProperty("AdminUser")),
				ReadResourceData.getResourceData("TC-10214-3", configProps.getProperty("AdminUser")));
		
		writeReport(AccessCodePackageCreation_10214.accessCodePackage(),ReadResourceData.getResourceData("TC-10214-4", "NA"),
				ReadResourceData.getResourceData("TC-10214-5","NA"),
				ReadResourceData.getResourceData("TC-10214-6", "NA"));
		
		stepReport("Verify that the package ISBN is required.");
		writeReport(AccessCodePackageCreation_10214.verifyCreatePackage(str),ReadResourceData.getResourceData("TC-10214-7", "NA"),
				ReadResourceData.getResourceData("TC-10214-8", "NA"),
				ReadResourceData.getResourceData("TC-10214-9", "NA"));
		
		stepReport("Create a new access code package.");
		writeReport(AccessCodePackageCreation_10214.verifyPackageNametxtBox(),ReadResourceData.getResourceData("TC-10214-10", "NA"),
				ReadResourceData.getResourceData("TC-10214-11", "NA"),
				ReadResourceData.getResourceData("TC-10214-12", "NA"));
		
		stepReport("Add ISBNs to the access code package.");
		writeReport(AccessCodePackageCreation_10214.verifyISBNPackage(),ReadResourceData.getResourceData("TC-10214-13", "NA"),
				ReadResourceData.getResourceData("TC-10214-14", "NA"),
				ReadResourceData.getResourceData("TC-10214-15", "NA"));
		
		
		 writeReport(EvolveCommonBussinessFunctions.adminLogout(),ReadResourceData.getResourceData("TC-10214-16", "NA"),
				 ReadResourceData.getResourceData("TC-10214-17", "NA"),
				 ReadResourceData.getResourceData("TC-10214-18", "NA"));
		 
	}catch(Exception e){
		System.out.println(e.getMessage());
	}
	
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
	
}
