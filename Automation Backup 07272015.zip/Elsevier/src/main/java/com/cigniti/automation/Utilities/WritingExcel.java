package com.cigniti.automation.Utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 

public class WritingExcel {

	public static  void writeExcel(String path,String sheet,String value,int rIndex,int cIndex) throws Exception{
		
		 File f = new File(path);
		 try {
				FileInputStream fis = new FileInputStream(f);
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				XSSFSheet s = wb.getSheet(sheet);
				XSSFRow r = s.getRow(rIndex);
				XSSFCell r1c1 = r.getCell(cIndex);
				r1c1.setCellValue(value);
				fis.close();
				FileOutputStream fos =new FileOutputStream(new File(path));
			    wb.write(fos);
			    fos.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	
}
