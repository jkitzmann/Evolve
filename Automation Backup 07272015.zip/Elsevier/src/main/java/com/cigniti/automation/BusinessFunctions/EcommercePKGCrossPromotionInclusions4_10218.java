package com.cigniti.automation.BusinessFunctions;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class EcommercePKGCrossPromotionInclusions4_10218 extends EvolveCommonBussinessFunctions{

	public static String VerifyText1 = "";
	public static String VerifyText2 = "";
	public static String VerifyText3 = "";
	public static String VerifyText4 = "";
	public static String VerifyText5 = "";
	static String user="inclusions";

	//Click on the Cross Promotion Tab
	public static boolean crossPromotionTab() throws Throwable{
		boolean flag=true;
		try
		{
			if(click(ElsevierObjects.Evolve_Admin_Ecom_CrossProm, "Click on Cross Promotion Tab")){
				Reporters.SuccessReport("Click on the Cross Promotion tab", "Successfully Clicked on the Cross promotion Tab");
			}else{
				Reporters.failureReport("Click on the Cross Promotion tab", "Failed to Click on the Cross promotion Tab");
			}
			Thread.sleep(medium);
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();


		}
		return flag;
	}

	//===================End of the Method============================================//


	/*//Verifying the available fields for Profit Centre Section
		public static boolean validateProfitCenterInclusion() throws Throwable {
			boolean flag = true;
			try{
			if(! click(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_AllPrd, "Click on the All Product Radio Button")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!Alert()){
				flag=false;
			}
			click(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_AllPrd, "Check the check box");
			Thread.sleep(medium);
			org.openqa.selenium.Alert alert;
			alert = driver.switchTo().alert();
			String alertMessage=alert.getText();
			Reporters.SuccessReport(alertMessage, "PopUp is present with the Message : " + alertMessage);
			alert.dismiss();
			if(isChecked(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_AllPrd, "")){
				Reporters.failureReport("promotion page with no changes made", "User is not taken back to promotion page with no changes made");				
			}else{
				Reporters.SuccessReport("promotion page with no changes made", "User is taken back to promotion page with no changes made");
			}
			click(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_AllPrd, "Check the check box");
			Alert();

			String AddDisabled=getAttribute(ElsevierObjects.comboprofit, "disabled", "Get the attribute value ");
			if(AddDisabled.contains("true")){
				Reporters.SuccessReport("Promotion Inclusions section is now grayed out/disabled. ", "The rest of the Promotion Inclusions section is now grayed out/disabled. ");
			}else{
				Reporters.failureReport("Promotion Inclusions section is now grayed out/disabled. ", "The rest of the Promotion Inclusions section Enabled. ");
			}

			Thread.sleep(medium);



			String sucMsg=getText(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_succmsg, "");
			if(verifyText(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_succmsg, "The Promotion Inclusion is successfully saved.", "Success Message")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
			}
			String percentage=readcolumns.twoColumns(0, 1,"Ecom_TCID_10217", configProps.getProperty("TestData")).get("Percentage");
			if(type(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Percentage, percentage,"Enter the Percentage")){
				Reporters.SuccessReport("Input the Percentage into the percentage Text box", "Successfully entered percentage : "+percentage+" into the percentage text box");
			}else{
				Reporters.failureReport("Input the Percentage into the percentage Text box", "Failed to enter percentage : "+percentage+" into the percentage text box");
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Save, "Click on save Button")){
				Reporters.SuccessReport("Click on the Save Button", "Successfully Clicked on the save button");
			}else{
				Reporters.failureReport("Click on the Save Button", "Failed to Click on the save button");
			}
			Thread.sleep(medium);
			if(!isElementPresent1(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Msg, "Table Data")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Admin_Evolve_Ecom_PromotionTab, "Click on Select Specific Products radio button")){
				flag = false;
			}		
			Thread.sleep(high);
			if(driver.findElement(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Save).isEnabled())
			{
				Reporters.failureReport("Clone button", "Save Button is Enabled");
			}else
			{
				Reporters.SuccessReport("Clone button", "Save Button is Disabled");
			}

			Thread.sleep(medium);	
			}catch(Exception e){
				System.out.println(sgErrMsg);
			}
			return flag;
		}
	 */



	//Verifying the available fields for Profit Centre Section
	public static boolean validateProfitCenterInclusion() throws Throwable {
		boolean flag = true;
		try
		{

			if(!click(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_AllPrd, "Click on the All Product Radio Button")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!Alert()){
				flag=false;
			}
			Thread.sleep(medium);


			String sucMsg=getText(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_succmsg, "Success Message");
			if(verifyText(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_succmsg, "The Promotion Inclusion is successfully saved.", "Success Message")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
			}
			String percentage=readcolumns.twoColumns(0, 1,"Ecom_TCID_10217", configProps.getProperty("TestData")).get("Percentage");
			if(type(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Percentage, percentage,"Enter the Percentage")){
				Reporters.SuccessReport("Input the Percentage into the percentage Text box", "Successfully entered percentage : "+percentage+" into the percentage text box");
			}else{
				Reporters.failureReport("Input the Percentage into the percentage Text box", "Failed to enter percentage : "+percentage+" into the percentage text box");
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Save, "Click on save Button")){
				Reporters.SuccessReport("Click on the Save Button", "Successfully Clicked on the save button");
			}else{
				Reporters.failureReport("Click on the Save Button", "Failed to Click on the save button");
			}
			Thread.sleep(medium);
			if(!isElementPresent1(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Msg, "Table Data")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Admin_Evolve_Ecom_PromotionTab, "Click on Select Specific Products radio button")){
				flag = false;
			}		
			Thread.sleep(high);
			if(driver.findElement(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Save).isEnabled())
			{
				Reporters.failureReport("Clone button", "Save Button is Enabled");
			}else
			{
				Reporters.SuccessReport("Clone button", "Save Button is Disabled");
			}

			Thread.sleep(high);	
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(sgErrMsg);
		}
		return flag;
	}


	//Validating the Inclusions for Profit Centre Section
	public static boolean validateProfitCenter() throws Throwable {
		boolean flag = true;
		try
		{
			if(!isElementPresent1(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Combo, "Profit Centre ComboBox")){
				flag = false;
			}		
			flag= validateAllSections(ElsevierObjects.comboprofit,ElsevierObjects.xpathProfit,ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_InpPercent, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("Percentage"), ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Add, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_AltMsg, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_SelectOption, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Addsucmsg, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Messg, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvBtn, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvBtnViewAll);

			flag=iterate("variablepercentage",user,ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_SelectOptionfinal, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_InpPercent, 
					readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("Percentage"), ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Add, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Addsucmsg, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Messg, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Rmvfinal, 5, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Anytextbox);



			flag= validateViewAll(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ViewAllMsg, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ViewNewPageMsg, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData , VerifyText1,"");
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(sgErrMsg);
		}
		return flag;
	}



	//Validating the Inclusions for Major Subject Code Section
	public static boolean validateMajorSubjectCodeSection() throws Throwable{
		boolean flag=true;
		try
		{

			if(!isElementPresent1(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Combo, "Major Subject Code ComboBox")){
				flag = false;
			}

			flag= validateAllSections(ElsevierObjects.combomajor,ElsevierObjects.xpathMajor,ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_InpPercent, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("Percentage"), 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_Add, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_AltMsg, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_SelectOption, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_Addsucmsg, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_Messg, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_RmvBtn, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_RmvBtnViewAll);

			flag=iterate("variablepercentage",user,ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_SelectOptionfinal, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_InpPercent, 
					readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("Percentage"), ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_Add, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_Addsucmsg, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_Messg, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_RmvBtnfinal, 5 , ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Anytextbox);



			flag= validateViewAll(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_ViewAllMsg, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_ViewNewPageMsg, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData , VerifyText2, "");
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(sgErrMsg);

		}
		return flag;
	}

	//Validating the Inclusions for Product Type Code Section
	public static boolean validateProductTypeCodeSection() throws Throwable{
		boolean flag=true;
		try{
			if(!isElementPresent1(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Combo, "Product Type ComboBox")){
				flag = false;
			}

			flag= validateAllSections(ElsevierObjects.comboproduct,ElsevierObjects.xpathProduct,ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_InpPercent, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("Percentage"), ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_Add, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_AltMsg, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_SelectOption, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_Addsucmsg, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_Messg, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_RmvBtn, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_RmvBtnViewAll);

			flag=iterate("variablepercentage",user,ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_SelectOptionfinal, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_InpPercent, 
					readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("Percentage"), ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_Add, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_Addsucmsg, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_Messg, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_RmvBtnfinal, 5 , ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_Anytextbox);

			flag= validateViewAll(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_ViewAllMsg, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_ViewNewPageMsg, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, VerifyText3, "");
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	//Validating the ISBN Section
	public static boolean validateISBNSectionFinal() throws Throwable{
		boolean flag=true;
		try
		{

			String condition="ecommerce";
			flag=validateISBNSection(condition,ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNtxt, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNpercent, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNAdd, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNErrMsg, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNSucMsg,
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNAddList, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNRem, 
					readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("InvalidISBN"), 
					readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("Percentage"));

			Thread.sleep(medium);
			/*flag= validateViewAll(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNViewAllLnk, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNViewNewPageMsg, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, VerifyText4, "isbnIncExclusion");
*/
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	//Validating the ISBN Upload Section
	public static boolean uploadCSV() throws Throwable{
		boolean flag=true;
		try
		{
			flag=uploadCSVFile("",ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNBrowse, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNUplPercent, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNUplBtn, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNUplSucMsg);
			flag=removeVerify(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNRemoveLink, ElsevierObjects.rem1, ElsevierObjects.rem2);
			Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	//Validating the ISBN Upload Section Type
	public static boolean uploadCSVSection() throws Throwable{
		boolean flag=true;
		try
		{
			flag= validateViewAll(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNViewAllLnk, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNViewNewPageMsg, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData , VerifyText5, "");			

			flag=validateUploadISBNSection(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNViewAllLnk, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
					ElsevierObjects.Evolve_Admin_Ecom_TabEcommerce, ElsevierObjects.Evolve_Admin_Ecom_CrossProm);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}

		return flag;
	}

	//Validating CSV file upload section
	public static boolean uploadCSVFile(String condition,By ISBNBrowseBtn, By percent, By uploadBtn, By sucMsg) throws Throwable{				
		boolean flag = true;
		try
		{
		/*if(!click(ISBNBrowseBtn, " Click on Browse Button")){
				flag = false;
			}	
		 */
		String filePath = ReadingExcel.getAbsoulteFilePath(readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("UploadCSVFile"));
		/*Robot r=new Robot();			   	  			   
			Thread.sleep(medium);
			r.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(low);
			r.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(low);
			r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(high);			 	   
			setClipboardData(filePath);			 
			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_V);
			r.keyRelease(KeyEvent.VK_V);
			r.keyRelease(KeyEvent.VK_CONTROL);			
			r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(medium);		 */  
		uploadFile(ISBNBrowseBtn, filePath/*readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("UploadCSVFile")*/, "");
		Thread.sleep(high);
		if(!type(percent,  readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("Percentage") ,"Enter Invalid ISBN into the Text Box")){
			flag = false;
		}			   
		if(!click(uploadBtn, " Click on Upload Button")){
			flag = false;
		}
		Thread.sleep(high);		   
		String sucMsg1=getText(sucMsg, "");
		if(verifyText(sucMsg, "The file is uploaded successfully.", "Success Message")){
			Reporters.SuccessReport("Validate CSV ISBN File Upload Section", "The success message : "+sucMsg1+" is displayed <br> CSV file is uploaded from solution and the path is : \\TestData\\ISBNFile.csv");	
		}else{
			Reporters.failureReport("Validate CSV ISBN File Upload Section", "The failure message : "+sucMsg1+" is displayed <br> CSV file is failed to upload from solution and the path is : \\TestData\\ISBNFile.csv");	
		}

		List<WebElement> isbnDataAdded=driver.findElements(ElsevierObjects.isbnTableInclusion);
		int size=isbnDataAdded.size();
		int count=0;
		for(WebElement e: isbnDataAdded)
		{
			if(count<3){
				Reporters.SuccessReport("List of ISBNs added by uploading the CSV file", "ISBN is added by uploading the CSV file is : " + e.getText());
				count++;
			}else{
				System.out.println("Come out from loop");
			}
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return flag;
	}

	public static boolean validateIncludeAllProducts() throws Throwable{

		try{
			boolean flag=true;
			click(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_AllPrd, "Check the check box");
			Thread.sleep(medium);
			org.openqa.selenium.Alert alert;
			alert = driver.switchTo().alert();
			String alertMessage=alert.getText();
			Reporters.SuccessReport(alertMessage, "PopUp is present with the Message : " + alertMessage);
			alert.dismiss();
			if(isCheckedNegative(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_AllPrd, "")){
				Reporters.failureReport("promotion page with no changes made", "User is not taken back to promotion page with no changes made");				
			}else{
				Reporters.SuccessReport("promotion page with no changes made", "User is taken back to promotion page with no changes made");
			}
			click(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_AllPrd, "Check the check box");
			Alert();

			String AddDisabled=getAttribute(ElsevierObjects.comboprofit, "disabled", "Get the attribute value ");
			if(AddDisabled.contains("true")){
				Reporters.SuccessReport("Promotion Inclusions section is now grayed out/disabled. ", "The rest of the Promotion Inclusions section is now grayed out/disabled. ");
			}else{
				Reporters.failureReport("Promotion Inclusions section is now grayed out/disabled. ", "The rest of the Promotion Inclusions section Enabled. ");
			}
			//verifyText(ElsevierObjects.Evolve_Admin_Prmlnk_SucMsgInclude, "All products have been included successfully. ", "Success Message is present");

			click(ElsevierObjects.Admin_Evolve_Ecom_PromotionTab, "Select Specific Radio button");

			return flag;			
		}catch(Exception e){return false;}
	}






}





