package com.cigniti.automation.Test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.cigniti.automation.Utilities.Property;

public class ReadFileExample 
{
	static Property configProps=new Property("config.properties");
	public static BufferedReader bufferReader;
	public static String filepath=configProps.getProperty("textfilepath");
   

   public static List<String> readTxt(String filepath) 
   	{
	   
	   //Name of the file
	   List<String> data=new ArrayList<String>();
	   
	   try{

		   		//Create object of FileReader
		   		FileReader inputFile = new FileReader(filepath);

		   		//Instantiate the BufferedReader Class
		   		bufferReader = new BufferedReader(inputFile);

		   		//Variable to hold the one line data
		   		String line;
 
   		   		// Read file line by line and print on the console
		   		while ((line = bufferReader.readLine()) != null)   {
		   			data.add(line);
		   		}
   
		   		//data.add(line);
		   		for(String s:data){
		   			System.out.println(s);
		   		}
  
		   		//Close the buffer reader
		   		bufferReader.close();
  
	   }catch(Exception e){
           System.out.println("Error while reading file line by line:" 
           + e.getMessage());                      
   }
      
   return data;
   }
 }
