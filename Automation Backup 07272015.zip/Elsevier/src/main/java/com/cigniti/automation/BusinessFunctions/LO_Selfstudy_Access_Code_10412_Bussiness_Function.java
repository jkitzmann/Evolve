package com.cigniti.automation.BusinessFunctions;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadTextFile;
import com.cigniti.automation.Utilities.Reporters;


public class LO_Selfstudy_Access_Code_10412_Bussiness_Function extends Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions {

	public static final  String ISBN_NUMBER ="9780323311663";
	String priceText ="";
	String accessCode = "";
	@Override
	public boolean createAccessCode() throws Throwable {

		boolean flag =true;
		try
		{
			if(!click(ElsevierObjects.EVOLVE_BUTTON, "click on the Evolve button")){
				flag = false;
			}
			if(!click(ElsevierObjects.maintainProd, "click on teh maintain product")){
				flag =false;
			}
			if(!type(ElsevierObjects.searchTitle,ISBN_NUMBER,"enter the ISBN title")){
				flag = false;
			}
			if(!click(ElsevierObjects.btnserchTitle,"searchTitleButton")){
				flag =false;
			}

			if(!click(By.xpath("//a[text()='"+ISBN_NUMBER+"']"), "ISBN Number")){
				flag =false;
			}
			Thread.sleep(medium);
			click(ElsevierObjects.createAccessCode, "Click on the Create Access Code");
			Thread.sleep(medium);
			if(getText(ElsevierObjects.schemeId, "Schem ID").equalsIgnoreCase(protectionScheme)){
				Reporters.SuccessReport("Verify the Scheme Id", "Verify that the Scheme Id value displayed on the Create Access Code tab matches the protection scheme saved for the course ID in Step #2");
			}else{
				Reporters.failureReport("Verify the Scheme Id", "Verify that the Scheme Id value displayed on the Create Access Code tab doesn't matches the protection scheme saved for the course ID in Step #2");
			}

			super.createAccessCode();

			if(!click(ElsevierObjects.DOWNLOAD_ACCESS_CODE, "Download Access Code")){
				flag =false;
			}
			if(!click(ElsevierObjects.DOWNLOAD_ACCESS_CODE_TXT, "Download Access Code Text")){
				flag =false;
			}

			Thread.sleep(medium);
			if(ElsevierObjects.studentBrowserType.equalsIgnoreCase("firefox")){
				r = new Robot();
				r.keyPress(KeyEvent.VK_DOWN);
				r.keyPress(KeyEvent.VK_TAB);
				r.keyPress(KeyEvent.VK_TAB);
				r.keyPress(KeyEvent.VK_TAB);
				Thread.sleep(low);
				r.keyPress(KeyEvent.VK_ENTER);
			}

			/*if(ElsevierObjects.browserType.equalsIgnoreCase("firefox")){
			r = new Robot();
			r.keyPress(KeyEvent.VK_DOWN);
			r.keyPress(KeyEvent.VK_TAB);
			r.keyPress(KeyEvent.VK_TAB);
			r.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(low);
			r.keyPress(KeyEvent.VK_ENTER);
		}*/
		}
		catch(Exception e)

		{

			sgErrMsg=e.getMessage();

			return false;

		}
		return flag;
	}

	@Override
	public void searchISBNNumber(String isBNumber) throws Throwable {

		boolean flag = true;
		String errorMessage ="";
		try{
			if(!click(ElsevierObjects.catalog, "")){
				flag = false;
			}
			Thread.sleep(medium);
			if(type(ElsevierObjects.txtproductsearch, isBNumber, "isbn number")){
				Reporters.SuccessReport("Enter the ISBN into the search box", "Successfully entered the ISBN :  "+isBNumber+" into the search box");
			}else{
				Reporters.failureReport("Enter the ISBN into the search box", "Failed to enter the ISBN :  "+isBNumber+" into the search box");
			}
			Thread.sleep(medium);

			if(click(ElsevierObjects.gobutton, "go button")){
				Reporters.SuccessReport("Search for a product "+isBNumber+" that is setup for LO Self Study Fulfillment.", "Successfully searched for the product "+isBNumber);
			}else{
				Reporters.failureReport("Search for a product "+isBNumber+" that is setup for LO Self Study Fulfillment.", "Failed to search for the product : "+isBNumber);
			}
			Thread.sleep(medium);

			if(isElementPresent(By.xpath("//li//span[text()='"+isBNumber+"']"))){
				Reporters.SuccessReport("Verify Product Page", "User is on the product page for "+isBNumber);
			}else{
				Reporters.failureReport("Verify Product Page", "User is not on the product page for "+isBNumber);
			}

			priceText = getText(ElsevierObjects.priceText, "price text");


			if(click(ElsevierObjects.btnaddtocart, "add to cart button")){
				Reporters.SuccessReport("Register for this product to add it to the cart.", "The product is Successfully added to the cart without any issues");
			}else{
				Reporters.failureReport("Register for this product to add it to the cart.", "The product is not added to the cart ");
			}
			Thread.sleep(medium);

			String title=getText(By.xpath("//div[@class='cartproductdetails']"), "cart product details");
			String price=getText(By.xpath("//div[text()='"+priceText.trim()+"']"), "Price");
			if(title.contains(isBNumber) && isElementPresent(By.xpath("//div[text()='"+priceText.trim()+"']"))){
				Reporters.SuccessReport("Verify Title and ISBN Number", "The Tilte and ISBN Number are correct and prices mathces  what is set up for the product <br/> The details are : "+title+" and " +price);
			}else{
				Reporters.SuccessReport("Verify Title and ISBN Number", "The Tilte and ISBN Number are not");
			}

		}catch(Exception e){

		}
	}

	public void enterAccessCode(String isbNumber,boolean isValidAccessCode) throws Throwable{
		try
		{
			if(!click(By.id("ac-radio-apply-"+isbNumber+""), "isbn number")){
				flag =false;
			}
			Thread.sleep(medium);
			accessCode = ReadTextFile.readTextFile(EvolveCommonBussinessFunctions.ACCESS_CODE);
			Thread.sleep(medium);
			if(type(ElsevierObjects.ACCESS_CODE, accessCode, "Access code")){
				Reporters.SuccessReport("Enter the access code into the text box", "Successfully entered the access code : "+accessCode+" into the text box");
			}else{
				Reporters.failureReport("Enter the access code into the text box", "Failed to enter the access code : "+accessCode+" into the text box");
			}
			if(!click(By.id("ac-apply-"+isbNumber), "")){
				flag =false;
			}
			Thread.sleep(high);
			if(!isValidAccessCode){
				if(getText(By.id("ext-gen5"),"").contains("not valid"))

					Reporters.SuccessReport("Verify Access Code Error Message", "Success Fully displays the Access Code Error Message");

				else
					Reporters.failureReport("Verify Access Code Error Message", "unable to  display the Access Code Error Message");
			}else{

				if(getText(By.xpath("//td[@class='totalamount strong']"),"").contains("0.00")){
					Reporters.SuccessReport("Verify Price and item Total", "Access code is  applied and the price on the item and the total became $0");
				}else{
					Reporters.SuccessReport("Verify Price and item Total", "Access code is not applied and the price on the item");
				}
				isElementPresent(By.xpath("//td[text()='"+priceText+"']"));


				if(click(ElsevierObjects.checkoutBtn, "CheckOut Button")){
					Reporters.SuccessReport("Click on the Redeem Checkout button", "Successfully Clicked on the Redeem/Checkout button");
				}else{
					Reporters.failureReport("Click on the Redeem Checkout button", "Failed to Click on the Redeem/Checkout button");
				}

				Thread.sleep(medium);
				if(!click(ElsevierObjects.Student_Shipping_Chk, "checkout button")){
					flag = false;
				}
				Thread.sleep(medium);
				click(ElsevierObjects.btnprofilesubmit, "profile submit button");

				Thread.sleep(medium);
				if(getText(By.xpath("//div[@class='current']"),"").contains("REVIEW & SUBMIT")){
					Reporters.SuccessReport("Verify User Navigation", "User Success fully Brought to  review and submit page");	
				}else{
					Reporters.failureReport("Verify User Navigation", "User was unable  to navigate   review and submit page");	
				}

				if(getText(By.xpath("//div[@class='cartproductdetails']"), "").contains(isbNumber) && isElementPresent(By.xpath("//td[text()='"+priceText.trim()+"']"))){
					Reporters.SuccessReport("Verify Title and ISBN Number", "The Tilte and ISBN Number are correct and prices mathces  what is set up for the product");
				}else{
					Reporters.SuccessReport("Verify Title and ISBN Number", "The Tilte and ISBN Number are not");
				}

				click(By.id("checkbox-registered"),"registered checkbox");
				Thread.sleep(medium);
				if(click(By.id("submitButton"),"submit button")){
					Reporters.SuccessReport("Click on the Submit button", "Successfully clicked on the Submit button");
				}else{
					Reporters.SuccessReport("Click on the Submit button", "Failed to click on the Submit button");
				}

				Thread.sleep(medium);

				if(getText(By.xpath("//div[@class='current']"),"").contains("CONFIRMATION")){
					Reporters.SuccessReport("Verify User Navigation", "User Success fully Brought to  review and submit page");	
				}else{
					Reporters.failureReport("Verify User Navigation", "User was unable  to navigate   review and submit page");	
				}

				if(getText(By.xpath("//div[@class='cartproductdetails']"), "").contains(isbNumber) && isElementPresent(By.xpath("//td[text()='"+priceText.trim()+"']"))){
					Reporters.SuccessReport("Verify Title and ISBN Number", "The Tilte and ISBN Number are correct and prices mathces  what is set up for the product");
				}else{
					Reporters.SuccessReport("Verify Title and ISBN Number", "The Tilte and ISBN Number are not");
				}
			}
		}
		catch(Exception e)

		{

			sgErrMsg=e.getMessage();

		}
	}

	public static void evolveCatalog(String isbnNUmber, String courseID) throws Throwable{
		try
		{
			click(ElsevierObjects.lnkevolve, "click on the My evolve link");
			if(!javaClick(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!javaClick(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			if(isElementPresent(By.xpath("//span[text()='COURSE ID: "+courseID+"']"),"course ID"))
				Reporters.SuccessReport("Verify User Content List ", "resource in user's content list as: "+ courseID);
			else
				Reporters.failureReport("Verify User Content List ", "unable to see the "+courseID+" in course content list ");

			String sucMsg1=getText(ElsevierObjects.myevolve_pageburstVST_link, "pageburst link");
			if(verifyText(ElsevierObjects.myevolve_pageburstVST_link, "Go to Pageburst on Kno library", "course link")){
				Reporters.SuccessReport("Verify the course link is present", "The Link : "+sucMsg1+" is displayed");	
			}else{
				Reporters.failureReport("Verify the course link is present", "The Link : "+sucMsg1+" is failed to display");
			}

			click(ElsevierObjects.myevolve_pageburstVST_link, "pageburst link");
			ImplicitWait();

			/*if(click(By.xpath(".//*[@id='course-sidebar']//li/a//span[text()='Course']"), "course ID")){
				Reporters.SuccessReport("Click on the Course library folder", "Successfully clicked on the Course library folder ");
			}else{
				Reporters.failureReport("Click on the Course library folder", "Failed to click on the Course library folder ");
			}*/
			
			if(click(ElsevierObjects.Ecert_Admin_ContentHome, "course ID")){
				Reporters.SuccessReport("Click on the Course library folder", "Successfully clicked on the Course library folder ");
			}else{
				Reporters.failureReport("Click on the Course library folder", "Failed to click on the Course library folder ");
			}
			
			List<WebElement> s=driver.findElements(ElsevierObjects.educator_CoursePage_SubFolders);
			for(WebElement subFolder:s){

				if(isElementPresent(ElsevierObjects.educator_CoursePage_SubFolders, "Course folder contains sub folders.")){
					Reporters.SuccessReport("Verifying subfolders.", "Verified Subfolders of Course Folder.</br>SubFolder is:"+subFolder.getText());
				}
				else{
					Reporters.failureReport("Verifying subfolders.", "Failed To Verify Subfolders of Course Folder.");
				}
			}
		}
		catch(Exception e)

		{

			sgErrMsg=e.getMessage();


		}

		/*click(By.xpath(".//*[@id='pageLayout-body-inner-most']/form/div/input"), "Open");
		Set<String> windowName = driver.getWindowHandles();

		for(String s:windowName){
		System.out.println("Window Name===>>>>"+s);
			driver.switchTo().window(s);
			Thread.sleep(medium);
		}
		if(isElementPresent(By.id("logoimg"),""))

			Reporters.SuccessReport("Verify New window", " User Success fully navigates to New window");
		else{
			Reporters.failureReport("Verify New window", " User unable to navigate  New window");
		}
		 */	}

	public void coursePARReport(String courseId,String userName) throws Throwable{
try
{
		click(ElsevierObjects.EVOLVE_BUTTON, "Evolve button");

		Thread.sleep(medium);
		click(ElsevierObjects.COURSE_PAR_REPORT, "Course PAR report");
		Thread.sleep(medium);
		type(ElsevierObjects.txtcourseID_1, courseId, "Course ID");

		click(ElsevierObjects.btncoursego, "serarch courseID button");
		Thread.sleep(medium);
		SimpleDateFormat sfd = new SimpleDateFormat("MM/dd/yyyy");
		String date = sfd.format(new Date());

		boolean found = false;
		int i = 0;
		do{
			if(isElementPresent(By.xpath("//span[text()='"+userName+"']")) && isElementPresent(By.xpath("//span[text()='"+accessCode+"']")) && isElementPresent(By.xpath("//span[text()='"+date+"']"))){
				found = true;
			}
			click(ElsevierObjects.btncoursePARReportNextPage, "Next page");
			i++;
		}
		while(isEnabled(ElsevierObjects.btncoursePARReportNextPage, "") && found == false && i < 6);
		
		if(found){
			Reporters.SuccessReport("Verify Record", "The record displays the student's "+userName+", PAR ="+accessCode+" and the redemption date as the current date");
		}else{
			Reporters.failureReport("Verify Record", "The unable to find the record with the student's "+userName+", PAR ="+accessCode+" and the redemption date as the current date");
		}

		click(ElsevierObjects.EVOLVE_BUTTON, "Evolve button");
		Thread.sleep(medium);
		click(ElsevierObjects.Admin_ViewEdit_UserProfile, "Admin ViewEdit UserProfile");
		Thread.sleep(medium);
		type(By.name("username"),userName, "username");

		click(By.name("action"),"");
		Thread.sleep(medium);
		click(By.xpath("//*[@id='evolve_usersearchlist_table']/tbody/tr/td[1]"), "username in table");

		Thread.sleep(medium);
		click(By.id("parBtn"), "PAR button");
		Thread.sleep(medium);
		if(isElementPresent(By.xpath("//strong[text()='Manage Protected Access Rights']"),"Access rights"))
			Reporters.SuccessReport("Verify Manage Protected Access Rights page", "User is taken to Manage Protected Access Rights Page");
		else
			Reporters.failureReport("Verify Manage Protected Access Rights page", "User is unable to take Manage Protected Access Rights Page");

		if(isElementPresent(By.xpath("//span[text()='"+courseId+"']"),"CourseID"))
			Reporters.SuccessReport("Verify Course Id Table", "The table will have an entry that displays the course id just purchased.  The redemption date will display the current date");
		else
			Reporters.failureReport("Verify Course Id Table", "The table will not have an entry that displays the course id just purchased.  The redemption date will display the current date.");

		click(ElsevierObjects.EVOLVE_BUTTON, "Evolve Button");

		Thread.sleep(medium);

		click(By.xpath("//a[text()='Search Access Code']"), "search access code");
		Thread.sleep(medium);
		type(By.id("query"), accessCode, "access code");

		click(By.id("search"), "search button");

		Thread.sleep(medium);

		if(isElementPresent(By.xpath("//span[text()='Redeemed']"),"Verify Access Code Status"))
			Reporters.SuccessReport("Verify Access Code Status", " the access code now displays as 'Redeemed'");
		else
			Reporters.failureReport("Verify Access Code Status", " the access code not displays as 'Redeemed'");

	
	}
	catch(Exception e)

	{

	sgErrMsg=e.getMessage();
	}
}
}