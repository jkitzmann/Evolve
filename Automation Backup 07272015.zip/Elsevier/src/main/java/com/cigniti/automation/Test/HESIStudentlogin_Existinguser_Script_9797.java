package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.HESIStudentlogin_Existinguser_9797;
import com.cigniti.automation.BusinessFunctions.HESI_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;

public class HESIStudentlogin_Existinguser_Script_9797 extends HESIStudentlogin_Existinguser_9797 {
  @Test
  public void HESIStudentlogin_Existinguser_9797() throws Throwable {
	 
		 SwitchToBrowser(ElsevierObjects.studentBrowserType);
	     ISBN=ReadingExcel.columnDataByHeaderName("ISBN", "TC-9797",configProps.getProperty("TestData"));
	     Country=ReadingExcel.columnDataByHeaderName("Country","TC-9797",configProps.getProperty("TestData"));
		 State=ReadingExcel.columnDataByHeaderName("State","TC-9797",configProps.getProperty("TestData"));
		 City=ReadingExcel.columnDataByHeaderName("City","TC-9797",configProps.getProperty("TestData"));
		 Institute=ReadingExcel.columnDataByHeaderName("Institution","TC-9797",configProps.getProperty("TestData"));
	     Year=ReadingExcel.columnDataByHeaderName("Year","TC-9797", configProps.getProperty("TestData"));
		 Programtype=ReadingExcel.columnDataByHeaderName("ProgramType","TC-9797",configProps.getProperty("TestData"));
		 StreetAddress=ReadingExcel.columnDataByHeaderName("StreetAddress","TC-9797",configProps.getProperty("TestData"));
		 CityAddress=ReadingExcel.columnDataByHeaderName("CityAddress", "TC-9797",configProps.getProperty("TestData"));
		 StateAddress=ReadingExcel.columnDataByHeaderName("StateAddress","TC-9797",configProps.getProperty("TestData"));
		 Zipcode=ReadingExcel.columnDataByHeaderName("ZipCode","TC-9797",configProps.getProperty("TestData"));
		  
		 String user = "Student";
		 stepReport("Create new student user");
		 writeReport(EvolveCommonBussinessFunctions.CreateNewUser(user),"Login to application as a student",
                                                                        "Successfully the EvolveCert URL Launched and new student user is created <br>" +EvolveCommonBussinessFunctions.credentials[0],
                                                                        "Failed to launch the URL and create a new student user");
		 Thread.sleep(medium);
		 writeReport(HESI_BusinessFunction.getAccountDetails("studentUpdate"), "Fetching Account Details From MyAccount Page.", 
					"Successfully Fetched Username: "+getAccountDetailsUserName+"</br>Successfully Fetched FirstName: "+getAccountDetailsFirstName+"</br>Successfully Fetched Lastname: "+getAccountDetailsLastName+"</br>Successfully Fetched Email: "+getAccountDetailsEmail+"</br>Successfully Fetched Institution: "+getAccountDetailsInstitution+"</br>Successfully Fetched PhoneNumber: "+getAccountDetailsPhone+"</br>Successfully Fetched StreetAdreess: "+ getAccountDetailsStreetAddress, 
					"Failed to Fetch Account Details From MyAccount Page. ");
		 Thread.sleep(2000);
		 
		 stepReport("Add item to cart and enter checkout");
		 writeReport(HESIStudentlogin_Existinguser_9797.LO_Creation(),"Click on catalog,search for Lo Course product and register for the product",
				                                                      "Successfully ISBN is entered in searchbox, searched for LO Course product, Product is registered and entered into cart  " +ISBN,
				                                                      "Failed to search for ISBN and get the product in cart");
		 Thread.sleep(high);
		 stepReport("Submit order");
		 writeReport(HESIStudentlogin_Existinguser_9797.UpdateAccount(),"Account is updation and submit the product",
				                                                        "Successfully Account is updated and Order is submitted",
				                                                        "Failed to update account,enter details and submit the order");
		 Thread.sleep(veryhigh);
		 stepReport("Verify receipt page");
		 writeReport(HESIStudentlogin_Existinguser_9797.confirmationpage(),"Verify the LO order details and verify the courseId and product link",
				                                                           "Successfully LO order details,CourseId and Product link is verified",
				                                                           "Failed to Verify the Confirmation Order,CourseId and Productlink");
		 Thread.sleep(high);
		 stepReport("Register student for HESI");
		 writeReport(HESIStudentlogin_Existinguser_9797.Hesiregistration(),"Hesi product is Register and order is submit",
				                                                           "Successfully Hesi product is registered and order is submitted",
				                                                           "Failed to Register the Hesi product and submit the order");
		 Thread.sleep(high);
		 stepReport("Verify HESI email");
		 EvolveCommonBussinessFunctions.HesiEmailVerification(); 
  }
}
