package com.cigniti.automation.Test;

import java.util.Arrays;
import java.util.Random;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.AR_BusinessFunction;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.Instructor_ViewStudentLogIn_8563;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;
public class ARWorkflowStudentlogin_Neg_8566 extends Instructor_ViewStudentLogIn_8563{
	Random ra = new Random( System.currentTimeMillis() );
	@Test
	public void ARWorkflowStudentloginNeg8566() throws Throwable{
	
	//	try 
		{
		     //  HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			stepReport("Login to Evolve as Student user");
		   writeReport(SwitchToBrowser(ElsevierObjects.studentBrowserType),"Launching Browser to Portal User","Launching Browser to Portal User is succesful","Lanching Browser to Portal User is failed");
			
			String Catalogs=ReadingExcel.columnDataByHeaderName("ISBN", "AR_Inputs", configProps.getProperty("TestData"));
			String StudentUsername=ReadingExcel.columnDataByHeaderName("StudentUsername", "AR_Inputs", configProps.getProperty("TestData"));
			 String StudentPassword=ReadingExcel.columnDataByHeaderName("StudentPassword", "AR_Inputs", configProps.getProperty("TestData"));
		
			writeReport(User_BusinessFunction.Studentlogin(StudentUsername, StudentPassword),"Login to Application Using Student Credentials"+sStudentUser,
                    "Launching the URL for User is successful </br > Login to Application Using User credentails :"+sStudentUser+" is Successful",
                       "Launching and Login to Application Using User credentails : "+ sStudentUser+" is Failed");

			Thread.sleep(medium);
			writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as: "+sStudentUser,
	                                                                 "Navigating to CATALOG page is Successful",
	                                                                 "Navigating to CATALOG Page is failed");
			Thread.sleep(medium);
		
			stepReport("Add Online Course to cart");
			writeReport(User_BusinessFunction.SearchCatalog(Catalogs),"Searching for Value:"+Catalogs,
		                                                                   "Entered "+Catalogs+" to Search </br > Click on Go Button ",
		                                                                   "Unable to Search for : "+ Catalogs);
		    Thread.sleep(medium);	
		    
		    writeReport(User_BusinessFunction.VerifyISBN(Catalogs), "Verify User Navigated to Product Results Page", "Page Navigate to Product Results Page of ISBN :"+Catalogs, "Page Not Navigated to Product Results Page of ISBN:"+Catalogs);
		    writeReport(AR_BusinessFunction.addToCartStudent(),"Add the product from results to cart ", "Successfully Added the "+Catalogs+" product to cart </br> The Product :"+Catalogs+" Price is verified and the Current Price is "+price,  "Failed to Add the product to cart, Due to Price is greater than 0.00$ or "+sgErrMsg);
		    
		    stepReport("Submit order");
		    writeReport(AR_BusinessFunction.reviewAndSubmit_Student(),"Reviewing the Order  and  Clicking on Submit:", " Check Box 'Yes, I accept the Registered User Agreement' is Present in the page</br>Check box 'Yes, I an instructor' is not Present </br> The Product :"+Catalogs+"  The Order  Successfully Reviewed and Submitted</br>The Confirmed Order Number is :"+Ordernumber,  "The Order Failed to Review and Submit");
			writeReport(AR_BusinessFunction.getUsernameandDetails(), "Fetching Account Details From MyAccount Page.", 
					"Successfully Fetched FirstName: "+getAccountDetailsFirstName+"</br>Successfully Fetched Last name: "+getAccountDetailsLastName, 
					"Failed to Fetch Account Details From MyAccount Page. ");
			
			writeReport(instructorLogout(),"LogOut as Student User", "Student Loged Out is Successful","Student Log out is  Failed");
			
			Thread.sleep(high);
			
     		stepReport("Login to Evolve Admin");
			writeReport(SwitchToBrowser(ElsevierObjects.adminBrowserType),"Launching Browser for Admin User","Launching Browser for Admin User is succesful","Lanching Browser for Admin User is failed");
			writeReport(evolveAdminlogin(),"Admin login ", "Successfully Reviewed and Submitted","Failed to Review and Submit");
			
			stepReport("Verify no adoption request was created");
			writeReport(AR_BusinessFunction.clickAdoptionRequest(getAccountDetailsUserName),"Click on the AR","AR Search results page is displayed","AR Search results page are not displayed");
			Thread.sleep(medium);
			String AliasName=getAccountDetailsLastName+", "+getAccountDetailsFirstName;
         	String[] Headers = {"Name","Status"};
			
			String[] resultsassertions = {AliasName,"Pending"};
			///Thread.sleep(40000);
			writeReport(AR_BusinessFunction.VerifyNoContent(ElsevierObjects.Admin_ArResults,Headers,resultsassertions), "Verifying the Status of Adoption Request Results:",
                    "In Results, The Values Under The Title:"+Arrays.toString(Headers)+" And </br> Values: "+Arrays.toString(resultsassertions)+"are Not Maching/Present in the results and it is as Expected", 
                    "In Results, The Values Under The Title:"+Arrays.toString(Headers)+" And </br> Values: "+Arrays.toString(resultsassertions)+"are is Maching as Not Expected");
            Thread.sleep(medium);

            writeReport(adminLogout(),"Clicked on Logout","Successfully Clicked on Logout","Not Clicked on Logout ");
		  
		}	
		
	} 
	@AfterTest
	public void tear() throws Throwable{
		
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
	
