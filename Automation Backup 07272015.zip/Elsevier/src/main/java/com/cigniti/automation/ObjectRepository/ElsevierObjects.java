package com.cigniti.automation.ObjectRepository;

import java.util.Map;

import org.openqa.selenium.By;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Actiondriver;

public class ElsevierObjects extends Actiondriver{

	public static String CategoryName = null;
	public static String browserType ="";
	//SCENARIO 1:

	//public static By  iamstudent     = By.xpath("//div[2]/div[1]/a");
	public static By  iamstudent1    = By.xpath("//a[@contains(text(),'student')]");
	public static By  lnkStudentview=By.xpath("//a[contains(text(),'Student View')]");
	public static By btnnotice       =By.id("ext-gen5");
	public static By  btnordersubmit=By.xpath("//form[@id='checkout-form']/div/button");
	public static By lnkevolve  =By.xpath("//li/a[contains(text(),'My Evolve')]");
	//public static By  catalog        = By.xpath("//div/ul/li[2]/a");
	public static By  catalog        = By.xpath(".//li[@class='nav-breadcrumb']/a[text()='Catalog']");
	public static By  angelunique    = By.id("format-angel_6x");
	public static By  review         = By.xpath("//div[contains(text(),'Review')]");
	public static By headUpdateprofile=By.xpath("//div/h1");
	public static By chkremember=By.id("loginForm-remember");
	public static By chkNoinstitution=By.id("no-institution");
	public static By txtcity=By.id("billing-city");
	public static By txtstreetAddress=By.id("billing-address1");
	public static By lststate=By.xpath("//select[@class='select-state billing-address span4']");//form[@id='form-profile']/select
	public static By txtzipcode=By.id("billing-postalCode");
	public static By chkbillingcheckbox=By.id("billing-checkbox");
	public static By btnprofilesubmit=By.id("profile-submit");
	public static By hcreditcardinfm=By.xpath("//form[@id='cc-form']/h3");
	public static By lstcardtype=By.id("cc-type");
	public static By txtcardNum=By.id("cc-number");
	public static By txtcardCVV=By.id("cc-cvv");
	public static By txtCardName=By.id("cc-name");
	public static By lstCExpirymonth=By.id("cc-month");
	public static By lstCExpiryyear=By.id("cc-year");
	public static By btnCcouninue=By.xpath("//form[@id='cc-form']/input[8]");
	public static By txtvCreditcard=By.xpath("//div[@class='span24 cart-flow']/div[2]");
	public static By  ordernumber    = By.xpath("//h4[contains(text(),'Order Number')]");
	public static By newwindow=By.id("page");
	public static By  txtconfirmation=By.xpath("//li[@class='row']/descendant::div[14]");
	public static By  txtorderNum   = By.xpath("//div[@class='sidebar-list rounded']/div[1]/div");
	public static By  rightclick     = By.xpath("//div[3]/div/a");

	//input[@name='dateSearchType' and @type='radio' and not(contains(@id,'dateRangeSearch'))]

	public static By  bottomsearch   = By.id("bottomSearch");
	public static By  lststaus        =By.id("status");
	public static By btnResendnow    =By.id("resendEmail");
	public static By  chkadaption   =By.id("fulfillcheckbox");
	public static By  txtmessege   =By.xpath("//div[@id='messageContainer']/font/b");
	public static By  btnbottomsave =By.id("save");
	public static By  txtupdate    =By.xpath("//td[@id='notification']/font");
	public static By  ARdetails      = By.xpath("//tr/td/h3/strong");
	public static By  txtverifyTitle=By.xpath("//tr/td/div[2][@class='viewTitle']");
	public static By  txtverifyfname=By.xpath("//tbody/tr[14]/td[2][@class='view' and @valign='top']");
	public static By  txtverifylname=By.xpath("//tbody/tr[15]/td[2][@class='view' and @valign='top']");
	public static By  txtverifyunivName=By.xpath("//tbody/tr[17]/td[2][@class='view' and @valign='top']");
	public static By lnkMyevovle=By.xpath("//div[@class='header']/div[2]/div[1]/ul/li[1]/a");
	public static By lnkVST=By.xpath("//a[contains(text(),'Go to Pageburst on VitalSource library')]");
	public static By verifyvstwindow=By.id("news");
	public static By lnkVSTwindow=By.xpath("//div[@id='news']/span/span");
	public static By btnvstlicencesubmit=By.xpath("//div[@id='page']/form//p/button[@class='submit']");


	//SCENARIO 3:
	public static By maintainproducts = By.xpath("//table[2]/tbody/tr[2]/td/a");
	public static By  adminsearchtag   = By.id("query");
	public static By  adminsearch      = By.id("submit");
	public static By  isbn             = By.xpath("//tr/td[4]/span/a");
	public static By  manageaccesscodes= By.xpath("//ul/li[7]/a");
	public static By  knoaccesscodes   = By.xpath("//tr[9]/td/span/div/a");
	public static By  accesscodes      = By.xpath("//tr[2]/td/span/a");
	public static By  textpresent      = By.xpath("noResultsSpan");
	//public static\

	//Scenario3:
	public static By adminLogin       = By.name("userName");
	public static By adminPassword    = By.name("password");
	public static By adminSubmit      = By.cssSelector("input[type="+"image"+"]");
	public static By maintainProd     = By.xpath("//a[contains(text(),'Maintain Products')]");
	public static By searchTitle      = By.id("query");
	public static By btnserchTitle    = By.id("submit");
	public static By productlistClick = By.xpath(".//*[@id='table-container']/table/tbody/tr[1]/td[4]/span/a");
	public static By lblAuthor=By.xpath("//nobr/label[contains(text(),'Author/Editor')]");
	public static By manageAcess      = By.xpath(".//div[@id='product-tabs']/ul/li[7]");//a[contains(text(),'Manage Access Codes')]
	public static By txtaccesscodeset  =By.xpath("//thead/tr[2]/th"); 
	public static By lnkActive   = By.xpath("//div[@id='accessCodeSetsList']//tr/td[3]");
	public static By lnkActivecode   = By.xpath(".//div[@id='accessCodeSetsList']//tr[9]/td[3]");
	public static By lnkKNOTestCodes=By.xpath("//a[contains(text(),'Kno_Test_Codes')]");//div[@id='accessCodeSetsList']//tr[9]/td[1]
	public static By lnkbacktoaccesscodetest=By.id("backToAccessCodeSetsLink");
	public static By txtuserperaccesscode=By.id("userPerCode");
	public static By lblISBNcode=By.id("productId");
	public static By lnkadminlogout=By.xpath(".//span[@id='logoutArea']/span/a");
	public static By lnkActivestart   = By.xpath(".//div[@id='accessCodeSetsList']//tr["); 
	public static By lnkActiveend     = By.xpath("]/td[3]");
	public static By activeStatus     = By.xpath(".//div[@id='accessCodeSetContainer']//tr/td[4]/span");
	public static By accessCode       = By.xpath(".//*[@id='accessCodeSetContainer']/table/tbody/tr/td[1]/span/a");
	public static By lnkpageburstebook=By.xpath(".//div[@id='uppershelf']/table/tbody/tr/td[1]/img");
	public static By lnkRedeemaccesscode=By.xpath("//a[contains(text(),'Redeem an access code')]");
	public static By txtaccesscode=By.name("accessCode");
	public static By btnsubmitaccesscode=By.xpath("//input[@value='SUBMIT']");//div[contains(@id,'ext-gen5')]
	public static By txtwrongaccess=By.xpath("//div[contains(@id,'ext-gen5')]");
	public static By txtmycart=By.xpath("//div[@class='cart-flow']/h1");
	public static By txtprice=By.xpath("//ul/li[2]/div[5]");
	public static By txtISBN =By.xpath("//ul/li[2]/div[3]/div[4]");
	public static By txtvaccesscode=By.id("ac-enter-9781455754373");//input[@name='accessCode']
	public static By chkbxinstitution=By.id("no-institution");
	public static By txtVUpdateAcc=By.xpath(".//div[@class='span18 main-content']/h1");
	public static By txtbxpwdkno=By.id("field-knoPassword");
	public static By chkbxoffers=By.id("offers");
	public static By btncountinue=By.id("profile-submit");
	public static By txtvReviewsubmit=By.xpath(".//div[@class='span24 cart-flow']/div[2]");
	public static By txtVoredrenum=By.xpath(".//div[@class='sidebar-list rounded']/div/div");
	public static By lnkmyevolve=By.xpath("//div/ul/li[1]/a");
	public static By lnkvpageburst=By.xpath(".//a[contains(text(),'Go to Pageburst on Kno library')]");
	public static By imgkno=By.xpath(".//span[@class='logoLink relative']");
	public static By lnkserchAccesscode=By.linkText("Search Access Code");
	public static By txtSearchAccesscode=By.id("query");
	public static By btnSearchAccesscode=By.id("search");
	public static By txtverifyStatus=By.xpath("//tbody/tr[1]/td[5]");
	public static By lnkstudentview=By.xpath(".//a[contains(text(),'Student View')]");
	public static By lnkLogout=By.xpath(".//a[contains(text(),'LOGOUT')]");
	public static By txtfirstname=By.id("field-firstName");
	public static By txtlastname=By.id("field-lastName");
	public static By txtemailid=By.id("field-email");
	public static By txtconfirmemailid=By.id("field-emailConfirm");

	//SCENARIO 5:
	public static By  studentlogin   = By.xpath(".//a[contains(text(),'Login')]");//ul/li[2]/a
	public static By  vstproduct     = By.xpath(".//div[3]/div/div[3]/a");
	public static By  mycart         = By.xpath(".//div/div/h1");
	public static By  ordernum       = By.xpath(".//div[2]/div[2]/div/div/div");
	public static By  dshippingstaus=By.xpath(".//li/div[7]/div");
	public static By  txtcvv            = By.id("checkout-cvv");
	public static By headupdateAcc=By.xpath(".//div/h1");
	public static By txtFname=By.id("field-firstName");
	public static By txtLname=By.id("field-lastName");
	public static By txtEmailAddress=By.id("field-email");
	public static By txtconfirmEmail=By.id("field-emailConfirm");
	public static By lstcountry=By.id("institution-country");
	public static By txtinstitute=By.id("institution-name");
	public static By txtstreetName=By.id("address0-address1");
	public static By txttown=By.id("address0-town");
	public static By txtprovince=By.id("address0-province");
	public static By txtpostal=By.id("address0-postalCode");
	public static By txtphone=By.id("field-phone");
	public static By lstprogramtype=By.id("select-program-type");
	public static By lnklogoutAdmin=By.xpath(".//span[@id='logoutArea']/span/a");
	public static By txtEmail=By.id("Email");
	public static By txtpwd=By.id("Passwd");
	public static By btnsignin=By.id("signIn");
	public static By Vtxtlogin=By.xpath(".//a[contains(text(),'Starred')]");
	public static By headmail=By.xpath(".//td/div[2]/div[1]/div[2]/h1");
	public static By txtverifytime=By.xpath(".//table/tbody/tr[contains(@class,'zA')]/td[8]");
	public static By txtwrongAccesscode=By.xpath(".//p[contains(text(),'One or more access code in your cart has already been')]");

	//scenario4
	public static By  btnOnlecourse   = By.xpath(".//div[@id='lowershelf']/table/tbody/tr/td[4]/img");

	public static By  txtsearch   = By.xpath(".//div[@class='box box6']//input[@id='search-course']");
	public static By btnsearch    = By.xpath(".//div[@class='placeholder-set']//input[@class='b-submit b-red']");

	//	public static By lnkOlinecourse=By.xpath("//div[@id='pageLayout-body-inner-most']//div/div[1]/div[5]/div[2]/div[1]/div/div[3]/a");

	//public static By btnRequest    =By.id("add-to-cart");
	public static By btnRequest = By.xpath(".//*[@id='add-to-cart']//span");
	public static By btnPreOrder = By.xpath(".//*[@id='add-to-cart']//span[contains(text(), 'Pre-order')]");
	public static By btnRegister = By.xpath(".//*[@id='add-to-cart']//span[contains(text(), 'Register')]");

	public static By rbtnEvovle   = By.id("resourcestools");
	public static By lstcourses  = By.id("instanceCount");
	public static By txtEnrollment  =By.id("projectedCourseEnrollment");
	public static By txtcomment  =By.id("comment");
	public static By btnapply    =By.xpath(".//button[@class='button bigorange-noicon bold uppercase']");
	public static By btnRedeem =By.id("checkoutButton");
	public static By txtisbn= By.xpath(".//div[@class='cartproductdetails']");
	public static By txtverifytile=By.xpath(".//div[@class='carttitle']");//ul[@class='receipt']/li[2]/div[3]/div[1]/a
	public static By txtverifyprodtype=By.xpath(".//div[@class='cartprodtype faculty']");
	public static By txtverifyprodauthors=By.xpath(".//div[@class='cartauthor']");

	public static By chkaccept=By.id("checkbox-registered");
	public static By chkaccept2 =By.id("checkbox-instructor");
	public static By btnsubmit =By.id("submitButton");
	public static By txtaccusername =By.id("loginForm-username");
	public static By txtaccpwd =By.id("loginForm-password");
	public static By btnlogin=By.id("signin_submit");
	public static By lblconfirmation=By.xpath(".//div[@class='clearfix']");
	public static By lnkAdaptionrequest=By.xpath(".//a[contains(text(),'Search Adoption Requests')]");
	public static By rbtntoday=By.xpath(".//input[@name='dateSearchType' and not(contains(@id,'dateRangeSearch'))]");//input[@name='dateSearchType' and @type='radio']
	public static By btntodaysearch=By.id("midSearch");
	public static By btnsubmit4=By.id("Submit4");
	public static By lnkAR=By.xpath(".//table[@id='resultTable']//tbody/tr[1]/td[1]");
	public static By lnkfaculty=By.id("name");
	public static By lblAdaptionrequest=By.xpath(".//td/h3[contains(text(),'ADOPTION REQUEST:')]");
	public static By verifytitle=By.xpath(".//td[@class='form']/div[2]");
	public static By verifyISBN=By.xpath(".//td[@class='form']/div[6]");
	public static By verifyproducttype=By.xpath("html/body/table[2]/tbody/tr[2]/td/div/table[1]/tbody/tr[3]/td/form/table/tbody/tr[2]/td/table/tbody/tr[1]/td[1]/table/tbody/tr[2]/td[2]");
	public static By verifyAuthorName=By.xpath(".//td[@class='form']/div[4]");
	public static By lstfullfillStatus=By.id("spanStatus");
	public static By btnsave=By.id("save");
	public static By txtccemail=By.id("ccEmail");
	public static By btncancelemail=By.id("cancelemail");
	public static By txtsuccessfulupdate=By.xpath(".//font[@color='green']/b");


	//scenario2

	public static By lnkstudentenroll=By.xpath(".//div[@class='box box6']//a[contains(text(),'Get students into your course')]");
	public static By lnksubmitroster=By.xpath(".//a[contains(text(),'Submitting your Class Roster')]");
	public static By txtcourseID=By.name("courseId");
	public static By txtArea=By.id("field-roster");
	public static By btnpreiviewroster=By.xpath(".//button[@class='button bold uppercase']");
	public static By txtwrongIDwarning=By.id("ext-gen7");
	public static By rbtnemail=By.id("submit-doemail");
	public static By lstrole=By.name("users.0.roles.0");
	public static By btnsubmitroster=By.xpath(".//button[@class='button bold uppercase']");
	public static By verifyroster=By.xpath(".//p[contains(text(),'Success! Your roster for ')]");
	public static By lnkStudentView=By.xpath(".//a[contains(text(),'Student View')]");
	public static By lnkcourseid=By.xpath(".//ul/li[1]/div[1]");
	public static By chkcourseid=By.xpath(".//ul/li[1]/div/div");
	public static By lnkcoursePARReport=By.linkText("Course PAR Report");
	public static By txtcoursid=By.id("courseid");
	public static By btncoursego=By.id("go");
	public static By btncoursePARReportNextPage = By.xpath(".//button[text()='Next']");
	public static By txtcorsePARreport=By.xpath(".//strong[contains(text(),'Course PAR Report')]");
	public static By txtcourseIDstatus=By.id("noResultsSpan");

	//Test Case ID-10214
	public static By Accesscodelink=By.linkText("Add Access Code Package");
	public static By verifyISBNtextenable=By.xpath(".//*[@id='isbn']");
	public static By verifycreatepackage = By.xpath(".//*[@id='package-details-title']");

	public static By breadcrumb = By.xpath(".//*[@id='pageBody']/table/tbody/tr[1]/td/table/tbody/tr/td");

	public static By inputpackagename = By.xpath(".//*[@id='packagename']");
	public static By savebutton = By.xpath(".//*[@id='saveBookStorePackage']");
	public static By cancelbutton = By.xpath(".//*[@id='cancelPackage']");

	public static By PackageISBN=By.id("packageKey");
	public static By PackageName=By.xpath(".//*[@id='packagename']");
	public static By verifysuccessmesg=By.xpath(".//*[@id='msg-save-success']/b");
	public static By errormesg=By.xpath(".//*[@id='msg-save-failure']/b");

	public static By Admin_Verify_Tableheadings=By.xpath(".//*[@id='packageItems']/tr[1]");

	public static By addbtn=By.xpath(".//*[@id='addBookStorePackageItem']");
	//public static Map<String, String> tc10214=ReadingExcel.keyValueBasedOnCommonValue(testDataPath, "GenericValue", 0, 1, 2, "TC-10214").get("Input_ISBN");
	public static String isbnToRemove=ReadingExcel.keyValueBasedOnCommonValue(testDataPath, "GenericValue", 0, 1, 2, "TC-10214").get("testdata1");
	public static By removelink=By.xpath(".//*[@id='package-details']/table/tbody/tr/td/table/tbody/tr/td[text()='"+isbnToRemove+"']/following-sibling::*/a");
	public static By removeVerify=By.xpath(".//*[@id='package-details']/table/tbody/tr/td/table/tbody/tr");
	public static By logoutadmin=By.xpath(".//*[@id='logoutArea']/span/a");

	public static By VerifyISBNafterRomove=By.xpath(".//*[@id='package-details']/table/tbody/tr[7]/td/table/tbody/tr[4]/td[text()='"+isbnToRemove+"']");

	public static By verifyISBNTable=By.xpath(".//*[@id='packageItems']//tr");
	//Test Case ID-10212
	//public static By unassignedaccesslink=By.xpath(".//*[@id='pageBody']//a[text()='Create Unassigned Codes']");
	//public static By unassignedaccesslink=By.linkText("Create Unassigned Codes");
	public static By verifyunassignedtext=By.xpath(".//*[@id='protectionSchemeSectionDiv']/div[1]/b");
	public static By verifybreadcrumb=By.xpath(".//*[@id='pageBody']/table/tbody[1]/tr/td/table/tbody/tr/td");
	public static By unassignedinputmonth=By.id("month");
	public static By unassignedinputdate=By.id("day");
	public static By unassignedinputyear=By.id("year");
	public static By unassigneddaysofaccess=By.id("daysafteractivation");
	public static By unassignedcodenumbertogenerate=By.id("numbertogenerate");
	public static By unassignedcodesave=By.xpath("//*[@id='accessCodeSubmit']");
	public static By accesscodesuccmesg=By.xpath(".//*[@id='msg-accesscodes-success']");
	public static By accesscodedownloadlink=By.xpath(".//*[@id='download']/strong[text()='Click here to download the access codes']");
	public static By radioinput=By.xpath(".//*[@id='radio1']");
	public static By unassignedcodeclear=By.id("accessCodeReset");

	public static By downloadlink=By.xpath("html/body/div[1]/div[3]/div/button[1]");


	/*......................ACP_PackageSearching":10215 ........................*/

	public static By txtverify=By.xpath(".//*[@id='frmsearch']/table/tbody/tr[2]/td/strong");
	public static By txtBreadCrumb=By.xpath(".//*[@id='pageBody']/table/tbody[1]/tr/td/table/tbody/tr/td/img[1]");
	public static By maintainaccess=By.linkText("Maintain Access Code Packages");
	//public static By maintainaccess=By.xpath(".//*[@id='pageBody']/form/table/tbody/tr[5]/td/table[4]/tbody/tr[3]/td/a[text()='Maintain Access Code Packages']");
	public static By txtpackageIsbn=By.xpath(".//*[@id='frmsearch']/table/tbody/tr[4]/td[1]");
	public static By packageIsbntxtbox=By.xpath(".//*[@id='packageISBN']");
	public static By PackageIsbnGo=By.xpath(".//*[@id='btnPackage']");
	public static By Package_navigate_breadcrumb=By.xpath(".//*[@id='pageBody']//span[text()='Edit Access Code Package']");
	public static By txtpackageName=By.xpath(".//*[@id='frmsearch']/table/tbody/tr[5]/td[1]");
	public static By packagenametxtbox=By.xpath(".//*[@id='packageName']");
	public static By packageNameGo=By.xpath(".//*[@id='btnName']");
	public static By txtItemIsbn=By.xpath(".//*[@id='frmsearch']/table/tbody/tr[6]/td[1]");
	public static By itemIsbntxtbox=By.xpath(".//*[@id='itemISBN']");
	public static By itemGo=By.xpath(".//*[@id='btnItem']");
	public static By Item_Downloadtext=By.xpath(".//*[@id='downloadResults']/a[text()='Download SpreadSheet Report']");

	public static By checkPackISDN=By.xpath(".//*[@id='package-details']/table/tbody/tr[3]/td/table/tbody/tr[1]/td[1]");
	public static By checkPackName=By.xpath(".//*[@id='package-details']/table/tbody/tr[3]/td/table/tbody/tr[2]/td[1]");
	public static By checkISDNAdd=By.xpath(".//*[@id='addBookStorePackageItem']");
	public static By Packagename_verifytext=By.xpath("//*[@id='table-container']//strong[text()='Search Results']");

	public static By linkEvolve=By.xpath(".//*[@id='pageBody']/table/tbody/tr[1]/td/table/tbody/tr/td/a");
	public static By errorMsg=By.xpath(".//*[@id='msg-save-failure']/strong");
	public static By textMsg=By.xpath(".//*[@id='msg-save-failure']/b");
	public static By isbnpackageKeytxt=By.xpath(".//*[@id='table-container']/table/thead/tr[4]/th[1]/strong/span");
	public static By isbnpackageNametxt=By.xpath(".//*[@id='table-container']/table/thead/tr[4]/th[2]/strong/span");
	public static By isbnLastUpdatetxt=By.xpath(".//*[@id='table-container']/table/thead/tr[4]/th[3]/strong/span");
	public static By isbnUpdateBytxt=By.xpath(".//*[@id='table-container']/table/thead/tr[4]/th[4]/strong/span");

	public static By txtEditpackage=By.xpath(".//*[@id='package-details-title']");
	public static By txtPackagekey=By.xpath(".//*[@id='packageKey']");
	public static By editpackageName=By.xpath(".//*[@id='packagename']");
	public static By addISBNTxtBox=By.xpath(".//*[@id='isbn']");
	public static By addButton=By.xpath(".//*[@id='addBookStorePackageItem']");

	public static By exPackageKey=By.xpath(".//*[@id='table-container']/table/tbody/tr[14]/td[1]/span/a");
	public static By removeLink=By.xpath(".//form/div/div[1]/table/tbody/tr[7]/td/table/tbody/tr[7]/td[6]/a");
	public static By verifyIsbn=By.xpath(".//*[@id='item_1837']/td[5]");

	/*..............................Evolve_StudentLogin...................................*/

	//public static By evolve_Home_Student=By.xpath(".//*[@id='page']/div[2]/div[1]/a");
	public static By evolve_Home_Student=By.xpath(".//a[@class='pull-left student']");
	public static By evolve_student_Search=By.xpath(".//*[@id='headerSearch']");
	public static By Student_Search_Go_btn=By.xpath(".//*[@id='headerSearchForm']/button");
	public static By Student_RequestProduct_btn=By.xpath(".//*[@id='add-to-cart']");
	public static By Student_Page_MyCart=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div/h1 ");      
	public static By Student_MyCart_Price_txt=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div/ul/li[1]/div[4]");
	public static By Student_MyCart_Price=By.xpath(".//*[@id='9781416046073']/div[5]");
	public static By Student_MyCart_Checkout_btn=By.xpath(".//*[@id='checkoutButton']");
	//student registration
	public static By Student_Register_Firstname_txt=By.xpath(".//*[@id='field-firstName']");
	public static By Student_Register_Lastname_txt=By.xpath(".//*[@id='field-lastName']");
	public static By Student_Register_Email_txt=By.xpath(".//*[@id='field-email']");
	public static By Student_Register_Confirmemail_txt=By.xpath(".//*[@id='field-emailConfirm']");
	public static By Student_Register_Pwd_txt=By.xpath(".//*[@id='field-password']");
	public static By Student_Register_ConfirmPwd_txt=By.xpath(".//*[@id='field-passwordConfirm']");
	public static By Student_Register_Chk=By.xpath(".//*[@id='no-institution']");
	public static By Student_Register_Street_txt=By.xpath(".//*[@id='billing-address1']");
	public static By Student_Register_City_txt=By.xpath(".//*[@id='billing-city']");
	public static By Student_Register_State_Dropdwn=By.xpath(".//*[@id='billing-address']/select");//*[@id='billing-address']/select
	//public static By Student_Register_Country_Dropdwn=By.xpath("/html/body/div[4]/div[3]/div/div/div/div/div/div/form/div[10]/select/option[45]");
	public static By Student_Register_Zipcode_txt=By.xpath(".//*[@id='billing-postalCode']");
	public static By Student_Register_Continue_btn=By.xpath(".//*[@id='profile-submit']");
	public static By Student_register_frame=By.xpath(".//*[@id='cboxLoadedContent']/iframe");

	//Creditcard details
	public static By Student_CardType_txt=By.xpath(".//*[@id='cc-type']");
	public static By Student_CardNumber_txt=By.xpath(".//*[@id='cc-number']");
	public static By Student_Cardcvv_txt=By.xpath(".//*[@id='cc-cvv']");
	public static By Student_Cardname_txt=By.xpath(".//*[@id='cc-name']");
	public static By Student_CardExpMnth_txt=By.xpath(".//*[@id='cc-month']");
	public static By Student_CardExpYr_txt=By.xpath(".//*[@id='cc-year']");
	public static By Student_Card_continue_btn=By.xpath(".//*[@id='cc-form']/input[8]");
	//Review and submit
	public static By Student_Review_price=By.xpath(".//*[@id='pageLayout-body-inner-most']//ul/li[@class='tableheader noborder row']/div[@class='price span2']");
	public static By Student_Review_Totalprice=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[5]/div[1]/div[3]/table/tbody/tr[3]/td[2]");
	public static By Student_accept_chk=By.xpath(".//*[@id='checkbox-registered']");
	public static By Student_Review_Submit=By.xpath(".//*[@id='submitButton']");
	//Student login
	//public static By Student_Logout=By.xpath(".//*[@id='page']/div[1]/div/div[1]/div[2]/ul/li[3]/a");
	public static By Student_Logout=By.xpath(".//a[text()='LOGOUT']");
	//Adoption search

	public static By Adoption_userId=By.xpath(".//*[@id='userId']");
	public static By Admin_Adoption_verifytxt=By.xpath(".//*[@id='pageBody']//td/table/tbody/tr[2]/td/table/tbody/tr/td/p/b");


	/*..................................Admin_Search_Fullfilled..........................................*/

	public static By Educator_RequestProduct_btn=By.xpath(".//*[@id='add-to-cart']/div[@class='buttoncontent']");
	public static By Educator_RequestPage_btn= By.xpath("html/body//div/div/div/div/div/ul/li[@class='row']/div[@class='price span2']");
	public static By Educator_Reedemchkout_btn= By.xpath(".//*[@id='checkoutButton']//span");
	//public static By Educator_Logout=By.xpath(".//*[@id='page']//a[text()='Logout']");//*[@id='page']//a[text()='Logout']
	public static By Educator_Logout=By.xpath(".//a[text()='LOGOUT']");

	public static By  educator_form_ddInstutionCountry  = By.xpath(".//*[@id='institution-country']/option[2]");
	public static final By Institution_Country = By.id("institution-country");
	/*...............................AR_LO_Global_Student.............................................*/

	//public static By Student_Home_Login=By.xpath(".//*[@id='login-menu']/a[text()='Login']");
	public static By Student_Home_Login=By.xpath(".//a[text()='Login']");
	public static By Student_Home_Username=By.xpath("//*[@id='loginForm-username']");
	public static By Student_Home_Pwd=By.xpath(".//*[@id='loginForm-password']");
	public static By Student_Home_Login_btn=By.xpath(".//*[@id='signin_submit ']");


	/*................................Student Pageburst e books.....................................................*/
	public static By Student_Home_Packard_img=By.xpath(".//*[@id='uppershelf']/table/tbody/tr/td[1]/img");
	public static By Student_Home_Redeem_lnktxt=By.xpath(".//*[@id='uppershelf']/div/ul/li/a[text()='Redeem an access code']");
	public static By Student_Home_Redeem_txtbox=By.name("accessCode");
	//public static By Student_Home_Redeem_Subbtn=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/form/div[4]/input");
	public static By Student_Home_Redeem_Subbtn=By.xpath(".//form[@name='validateCodeForm']/button");
	//public static By Student_Home_Redeem_Invldmsg=By.xpath(".//*[@id='ext-gen5'][text()=' This access code is not valid. For additional information please contact Evolve Support at 1-800-222-9570 or at http://evolvesupport.elsevier.com.']");
	public static By Student_Home_Redeem_Invldmsg=By.xpath(".//*[@class='access-code-validation']");
	public static By Student_Home_Redeem_Chkout=By.xpath(".//*[@id='checkoutButton']");
	public static By Student_Home_NewUser=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div/div/h1[text()='New to Evolve? Create an account!']");
	public static By Student_Home_NewUserKNo=By.xpath(".//*[@id='form-profile']/h3[3][text()='Set up your Pageburst on Kno account:']");

	public static By Student_Home_Reg_VSTPwd=By.id("field-vstPassword");
	public static By Student_Home_Reg_knopw=By.id("field-knoPassword");
	public static By Student_Home_Reg_Cont_btn=By.id("profile-submit");
	public static By Student_Home_Reg_Chkbox=By.id("checkbox-registered");
	public static By Student_Home_Reg_Subbtn=By.id("submitButton");
	public static By Student_Home_verifyOrder=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class,'sidebar-list rounded')]/div/div");


	//Access Code Package Upload Excel Data
	//public static By Admin_Login_Upload_lnk=By.xpath(".//*[@id='pageBody']/form/table/tbody//a[text()='Upload Unassigned Codes']");
	//public static By Admin_Login_Upload_lnk=By.linkText("Upload Unassigned Codes");
	public static By Admin_VerifyUploadTxt=By.xpath(".//*[@id='pageBody']/table/tbody/tr[1]/td");
	public static By Admin_Browse_Btn=By.xpath(".//*[@id='filename']");
	public static By Admin_Upload_Btn=By.xpath(".//*[@id='fileuploadbtn']");
	public static By Admin_Upld_Sucmsg=By.xpath(".//*[@id='msg-upload-success'][text()='Your file was successfully uploaded.']");
	public static By Admin_Evolve_lnk=By.xpath(".//*[@id='pageBody']/table/tbody[1]/tr/td/table/tbody/tr/td/a[text()='Evolve Admin']");

	public static By Admin_Seach_Code=By.id("query");
	public static By Admin_Search_Submit=By.id("search");
	public static By Admin_Evolve_Link=By.xpath(".//*[@id='pageBody']//a[text()='Evolve Admin']");
	public static By Admin_Evolve_AccessCodeAfterSearch=By.xpath(".//*[@id='table-container']/table/tbody/tr/td[1]/span/a");
	public static By Admin_Evolve_AdminLink=By.xpath(".//*[@id='pageBody']/table/tbody[1]/tr/td/table/tbody/tr/td/a[text()='Evolve Admin']");

	//Access code Package Test case - 15557
	public static By Student_Shipping_Chk=By.xpath(".//*[@id='no-institution']");
	public static By Student_Shipping_Addr1=By.id("shipping-address1");
	public static By Student_Shipping_City=By.id("shipping-city");
	public static By Student_Shipping_State=By.xpath(".//*[@id='form-profile']/select[1]");
	public static By Student_Shipping_Zip=By.id("shipping-postalCode");
	public static By Student_Shipping_VKnoPwd=By.id("field-vstPassword");
	public static By Student_Shipping_SecurityQue=By.id("select-vst-question");
	public static By Student_Shipiing_SecurityAns=By.id("field-vstSecurityQuestionAnswer");
	public static By Student_Shipping_KNOPwd=By.id("field-knoPassword");
	public static By Student_Shipping_AccpChk=By.xpath(".//*[@id='offers']");
	public static By Student_Shipping_ContBtn=By.id("profile-submit");
	public static By Student_Shipping_Address=By.xpath(".//*[@id='form-profile']//h3[text()='Enter your shipping address:']");
	public static By Student_Shipping_Accept=By.id("checkbox-registered");
	public static By Student_Shipping_Submit=By.id("submitButton");
	public static By Student_Shipping_Comfirm=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[2]/div[2]");
	public static By Evolve_AccessCodeRedeemMessage=By.xpath(".//*[@id='table-container']/table/tbody/tr/td[1]/following-sibling::td[4]");
	public static By Evolve_AccessCodeLink=By.xpath(".//*[@id='table-container']//td[1]/span/a");
	public static By Evolve_AccessCodeLinkRedeem=By.xpath(".//*[@id='accessCodeInfoDiv']//div[contains(@class, 'reportControls')]/div[contains(@class,'row')]");
	public static By Evolve_AccessCodeRemaingUses=By.xpath(".//*[@id='accessCodeInfoDiv']//div[text()='Remaining Uses']/following-sibling::div");
	public static By Evolve_AccessCodeStatus=By.xpath(".//*[@id='accessCodeInfoDiv']//div[text()='Status']/following-sibling::div");
	//public static By Evolve_AccessCodeNotValid=By.xpath(".//*[@id='ext-gen5']");
	public static By Evolve_AccessCodeNotValid=By.xpath(".//div[@class='redeem-group']/p[@class='access-code-validation']");

	public static By Admin_Search_AccessCodeLnk=By.linkText("Search Access Code");
	public static By Admin_Evolve_Admin_AddAdministrator=By.linkText("Add Administrators");
	public static By Admin_Evolve_Admin_ManageAdmin=By.linkText("Manage Administrators");

	/*........................................ECommerce..................................*/

	//Test ID (10217) - Ecommerce PKG - Package Creation - 1

	//public static By Evolve_Admin_ECommerce_AddEcommerce=By.xpath(".//*[@id='pageBody']//a[text()='Add E-commerce Package']");
	public static By Evolve_Admin_ECommerce_AddEcommerce=By.linkText("Add E-commerce Package");
	public static By Evolve_Admin_Ecom_BreadCrumb=By.xpath(".//*[@id='pageBody']/table/tbody/tr[1]/td/table/tbody/tr/td");
	public static By Evolve_Admin_Ecom_Tabs=By.xpath(".//*[@id='product-tabs']/ul/li");
	public static By Evolve_Admin_Ecom_TabEcommerce=By.xpath(".//*[@id='product-tabs']/ul/li//a[text()='Package']");
	public static By Evolve_Admin_Ecom_DMCode=By.xpath(".//*[@id='package-details']/table/tbody/tr[1]/td[1][text()='DM Code *']");
	public static By Evolve_Admin_Ecom_CampCode=By.xpath(".//*[@id='package-details']/table/tbody/tr[1]/td[text()='Campaign Code ']");
	public static By Evolve_Admin_Ecom_PkgName=By.xpath(".//*[@id='package-details']/table/tbody/tr[1]/td[text()='Package Name']");
	public static By Evolve_Admin_Ecom_StrDte=By.xpath(".//*[@id='package-details']/table/tbody/tr[2]/td[1][text()='Start Date *']");
	public static By Evolve_Admin_Ecom_EndDte=By.xpath(".//*[@id='package-details']/table/tbody/tr[2]/td[text()='End Date']");
	public static By Evolve_Admin_Ecom_State=By.xpath(".//*[@id='package-details']/table/tbody/tr[4]/td[text()='State ']");
	public static By Evolve_Admin_Ecom_City=By.xpath(".//*[@id='package-details']/table/tbody/tr[4]/td[text()='City ']");
	public static By Evolve_Admin_Ecom_Institution=By.xpath(".//*[@id='package-details']/table/tbody/tr[4]/td[text()='Institution ']");
	public static By Evolve_Admin_Ecom_SaveBtn=By.xpath(".//*[@id='savePackage']");
	public static By Evolve_Admin_Ecom_CanclPkg=By.xpath(".//*[@id='cancelPackage']");
	public static By Evolve_Admin_Ecom_Clone=By.id("clonePackage");

	public static By Evolve_Admin_Ecom_DMCodeTxtBox=By.id("dmcode"); 
	public static By Evolve_Admin_Ecom_CampCodTxtBox=By.id("campaigncode"); 
	public static By Evolve_Admin_Ecom_PkgTxtBox=By.id("packagename");
	//public static By Evolve_Admin_Ecom_StrDate=By.xpath(".//*[@id='startdate']");
	public static By Evolve_Admin_Ecom_CalClk=By.xpath(".//*[@id='package-details']/table/tbody/tr[2]/td[1]/a/img"); 
	//public static By Evolve_Admin_Ecom_ClkDate=By.xpath(".//*[@id='scwCell_31']");
	public static By Evolve_Admin_Ecom_ClkDate=By.xpath(".//*[@id='scwFoot']");

	public static By Evolve_Admin_Ecom_Stateinput=By.xpath(".//*[@id='instState']");
	public static By Evolve_Admin_Ecom_SelectState=By.xpath("/html/body/table[2]/tbody/tr[2]/td/div/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr/td/div/div[3]/table/tbody/tr[4]/td[1]/select/option[36]");
	public static By Evolve_Admin_Ecom_CitySelect=By.xpath(".//*[@id='instCity']");
	public static By Evolve_Admin_Ecom_InstituteName=By.xpath(".//*[@id='institute_lookup']");
	public static By Evolve_Admin_Ecom_InstituteAjax=By.xpath(".//*[@id='Autocomplete_1407506807514']/div[text()='Rosati Kain High School-47337']");

	public static By Evolve_Admin_Ecom_SuccMsg=By.xpath(".//*[@id='msg-save-success']/b[text()='Package successfully saved.']");
	public static By Evolve_Admin_Ecom_PkgItms=By.xpath(".//*[@id='package-details']/table/tbody/tr[6]/td/b[text()='Package Items ']");
	public static By Evolve_Admin_Ecom_ISBNTxtBox=By.xpath(".//*[@id='add-item-container']/td[text()='ISBN ']");
	public static By Evolve_Admin_Ecom_DiscTyp=By.xpath(".//*[@id='add-item-container']/td[text()='Discount Type ']");
	public static By Evolve_Admin_Ecom_Discount=By.xpath(".//*[@id='add-item-container']/td[text()='Discount ']");
	public static By Evolve_Admin_Ecom_InstrChkBox=By.xpath(".//*[@id='instructorLed']");
	public static By Evolve_Admin_Ecom_AddPkgBtn=By.xpath(".//*[@id='addPackageItem']");
	public static By Evolve_Admin_Ecom_TextVerifyInPkgname=By.xpath(".//*[@id='packageItems']/tr[2]/td[6]");
	public static By Evolve_Admin_Ecom_VerifyTableHeader=By.xpath(".//*[@id='package-details']/table/tbody/tr[8]/td/table/tbody/tr[1]");
	public static By Evolve_Admin_Ecom_VerifyTblInfo=By.xpath(".//*[@id='package-details']/table/tbody/tr[8]/td/table/tbody/tr/td");
	public static By Evolve_Admin_Ecom_VerifyRem=By.xpath(".//*[@id='packageItems']/tr/td/a[text()='remove']");
	public static By Evolve_Admin_Ecom_Remisbn=By.xpath(".//*[@id='packageItems']/tr/td[text()='9780323057356']/preceding-sibling::td[5]/a");
	public static By Evolve_Admin_Ecom_VerifyISBN=By.xpath(".//*[@id='packageItems']/tr/td[text()='9780323057356']");
	public static By Evolve_Admin_Ecom_VerifyText=By.xpath(".//*[@id='packageItems']/tr/td[text()='By Barbara Lauritsen Christensen, RN, MS & Elaine Oden Kockrow, RN, MS']");

	public static By Evolve_Admin_Ecom_InputISBN=By.id("isbn");
	public static By Evolve_Admin_Ecom_DisType=By.xpath(".//*[@id='discounttype']");
	public static By Evolve_Admin_Ecom_DiscountInput=By.xpath(".//*[@id='discount']");

	public static By Evolve_Admin_Ecom_CrossProm=By.xpath(".//*[@id='product-tabs']/ul/li[2]/a[text()='Cross Promotions']");
	public static By Admin_Evolve_Ecom_PromotionTab=By.xpath(".//*[@id='pckradio2']");

	public static By Admin_Evolve_Ecom_SelPrdTyp=By.xpath(".//*[@id='pckpiproducttypeselect']/option");
	public static By Admin_Evolve_Ecom_Percetage=By.xpath(".//*[@id='pckpiptpercentageoff']");
	public static By Admin_Evolve_Ecom_AddPercen=By.xpath(".//*[@id='pckpiptaddbtn']");
	public static By Admin_Evolve_Ecom_SuccMsg=By.xpath(".//*[@id='msgpck-pi-save-success']");
	public static By Admin_Evolve_Ecom_CrsPltInclution=By.xpath(".//*[@id='pckptpitable']/tbody/tr");


	//Test ID (10218) - Ecommerce PKG - Cross Promotion - Inclusions - 4

	public static By Admin_Evolve_Ecom_CrsPrm_AllPrd=By.xpath(".//*[@id='pckradio1']");
	public static By Admin_Evolve_Ecom_CrsPrm_succmsg=By.xpath(".//*[@id='msgpck-pi-save-success']");
	public static By Admin_Evolve_Ecom_CrsPrm_Percentage=By.xpath(".//*[@id='pckpiallpercentageoff']");
	public static By Admin_Evolve_Ecom_CrsPrm_Save=By.xpath(".//*[@id='pckalladdbtn']");
	public static By Admin_Evolve_Ecom_CrsPrm_Msg=By.xpath(".//*[@id='pckaddalltable']/tbody/tr");
	public static By Admin_Evolve_Ecom_CrsPrm_Anytextbox=By.xpath(".//*[@id='pckpiisbn']");
	public static By savebuttonEcomm=By.xpath(".//*[@id='div-pi-choose-all-products']//td[contains(@class,'promo_inc_add_button')]/div/input");

	public static By isbnTableInclusion=By.xpath(".//*[@id='pckisbnpitable']/tbody/tr/td[3]");
	public static By xpathProfit=By.xpath(".//*[@id='pckpiprofitcenterselect']/option");
	public static By xpathMajor=By.xpath(".//*[@id='pckpimscselect']/option");
	public static By xpathProduct=By.xpath(".//*[@id='pckpimscselect']/option");

	public static By comboprofit=By.xpath(".//*[@id='pckpiprofitcenterselect']");
	public static By combomajor=By.xpath(".//*[@id='pckpimscselect']");
	public static By comboproduct=By.xpath(".//*[@id='pckpimscselect']");
	//public static By 

	//public static By isbnTableInclusion=By.xpath(".//*[@id='pckisbnpitable']/tbody/tr/td[3]");
	public static By xpathExProfit=By.xpath(".//*[@id='pckpeprofitcenterselect']/option");
	public static By xpathMajorEX=By.xpath(".//*[@id='pckpemscselect']/option");
	public static By xpathProductEX=By.xpath(".//*[@id='pckpeproducttypeselect']/option");

	public static By comboprofitEX=By.xpath(".//*[@id='pckpeprofitcenterselect']");
	public static By combomajorEX=By.xpath(".//*[@id='pckpemscselect']");
	public static By comboproductEX=By.xpath(".//*[@id='pckpeproducttypeselect']");

	//Admin_Evolve_Ecom_PromotionTab Validations

	public static By Admin_Evolve_Ecom_CrsPrm_Combo=By.xpath(".//*[@id='div-pi-select-specific-products']/table/tbody/tr[1]/td[1]/div");
	public static By Admin_Evolve_Ecom_CrsPrm_percen=By.id("pubpckpipcpercentageoff");
	public static By Admin_Evolve_Ecom_CrsPrm_AddBtn=By.xpath(".//*[@id='div-pi-select-specific-products']/table/tbody/tr[1]/td[3]/div/input[@type='button']");

	public static By Admin_Evolve_Ecom_CrsPrm_InpPercent=By.xpath(".//*[@id='pckpipcpercentageoff']");
	public static By Admin_Evolve_Ecom_CrsPrm_Add=By.xpath(".//*[@id='pckpipcaddbtn']");
	public static By Admin_Evolve_Ecom_CrsPrm_SelectOptionfinal=By.xpath(".//*[@id='pckpiprofitcenterselect']/option");
	public static By Admin_Evolve_Ecom_CrsPrm_SelectOption=By.xpath(".//*[@id='pckpiprofitcenterselect']/option[text()='ABMS (GMD)']");
	public static By Admin_Evolve_Ecom_CrsPrm_Addsucmsg=By.xpath(".//*[@id='msgpck-pi-save-success'][text()='The Promotion Inclusion is successfully saved.']");
	public static By Admin_Evolve_Ecom_CrsPrm_Messg=By.xpath(".//*[@id='pckpcpitable']/tbody/tr");
	public static By Admin_Evolve_Ecom_CrsPrm_RmvBtn=By.xpath(".//*[@id='pckpcpitable']/tbody/tr[1]/td[text()='ABMS (GMD)']/preceding-sibling::td[2]/a");
	public static By Admin_Evolve_Ecom_CrsPrm_Rmvfinal=By.xpath(".//*[@id='pckpcpitable']/tbody/tr/td/a");
	public static By Admin_Evolve_Ecom_CrsPrm_RmvBtnViewAll=By.xpath(".//*[@id='pckpcpitable']/tbody/tr/td/a");
	public static By Admin_Evolve_Ecom_CrsPrm_AltMsg=By.xpath(".//*[@id='msgpck-pi-save-failure'][text()='Please select product group to add to the promotion.']");
	public static By Admin_Evolve_Ecom_CrsPrm_SelectOption1=By.xpath(".//*[@id='pckpiprofitcenterselect']/option[text()='Allergy']");
	public static By Admin_Evolve_Ecom_CrsPrm_SelectOption2=By.xpath(".//*[@id='pckpiprofitcenterselect']/option[text()='Amirsys']");
	public static By Admin_Evolve_Ecom_CrsPrm_SelectOption3=By.xpath(".//*[@id='pckpiprofitcenterselect']/option[text()='Anesthesiology']");
	public static By Admin_Evolve_Ecom_CrsPrm_SelectOption4=By.xpath(".//*[@id='pckpiprofitcenterselect']/option[text()='Athletic Training']");

	public static By Admin_Evolve_Ecom_CrsPrm_ViewAllMsg=By.xpath(".//*[@id='hlink-container-pckpc-pi']/a[text()='View All Profit Centers...']");
	public static By Admin_Evolve_Ecom_CrsPrm_ViewNewPageMsg=By.xpath(".//*[@id='couponViewAllResults']/table/thead/tr[2]/th/table/tbody/tr/td[1]/strong[text()='Promotion Inclusion - View All Profit Centers']");
	public static By Admin_Evolve_Ecom_CrsPrm_VwNewPageRemove=By.xpath(".//*[@id='pageBody']/table/tbody/tr/td/input[@value='Remove']");
	public static By Admin_Evolve_Ecom_CrsPrm_VwNewPageBack=By.xpath(".//*[@id='pageBody']/table/tbody/tr/td/input[@value='Back']");

	public static By Admin_Evolve_Ecom_CrsPrm_VwChkBox=By.xpath(".//*[@id='couponViewAllResults']/table/tbody/tr[1]/td[1]/span/input");
	public static By Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy=By.xpath(".//*[@id='couponViewAllResults']/table/tbody/tr[1]/td[2]/span");
	public static By Admin_Evolve_Ecom_CrsPrm_VwRowData=By.xpath(".//*[@id='couponViewAllResults']/table/tbody/tr[1]");
	public static By Admin_Evolve_Ecom_CrsPrm_RmvData=By.xpath(".//*[@id='removeallitems_1']");
	public static By Admin_Evolve_Ecom_CrsPrm_VwBack=By.xpath(".//*[@id='viewallback']");

	//Major Subject Code Section Validation

	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_Combo=By.xpath(".//*[@id='div-pi-select-specific-products']/table/tbody/tr[2]/td[1]/div");

	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_InpPercent=By.xpath(".//*[@id='pckpimscercentageoff']");
	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_Add =By.xpath(".//*[@id='pckpimscaddbtn']");
	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_AltMsg=By.xpath(".//*[@id='msgpck-pi-save-failure'][text()='Please select product group to add to the promotion.']");
	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_SelectOption=By.xpath(".//*[@id='pckpimscselect']/option[text()='aaecca']");

	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_SelectOptionfinal=By.xpath(".//*[@id='pckpimscselect']/option");

	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_Addsucmsg=By.xpath(".//*[@id='msgpck-pi-save-success'][text()='The Promotion Inclusion is successfully saved.']");
	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_Messg=By.xpath(".//*[@id='pckmscpitable']/tbody/tr");
	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_RmvBtn=By.xpath(".//*[@id='pckmscpitable']/tbody/tr/td[text()='aaecca']/preceding-sibling::td[2]/a");
	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_RmvBtnfinal=By.xpath(".//*[@id='pckmscpitable']/tbody/tr/td/a");

	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_RmvBtnViewAll=By.xpath(".//*[@id='pckmscpitable']/tbody/tr/td/a");
	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_SelectOption1=By.xpath(".//*[@id='pckpimscselect']/option[2]");
	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_SelectOption2=By.xpath(".//*[@id='pckpimscselect']/option[3]");
	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_SelectOption3=By.xpath(".//*[@id='pckpimscselect']/option[4]");
	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_SelectOption4=By.xpath(".//*[@id='pckpimscselect']/option[5]");

	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_ViewAllMsg=By.xpath(".//*[@id='hlink-container-pckmsc-pi']/a[text()='View All Major Subject Codes...']");
	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_ViewNewPageMsg=By.xpath(".//*[@id='couponViewAllResults']/table/thead/tr/th/table/tbody/tr/td/strong[text()='Promotion Inclusion - View All Major Subject Codes']");
	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_VwNewPageRemove=By.xpath(".//*[@id='pageBody']/table[2]/tbody/tr/td/input[@value='Remove']");
	public static By Admin_Evolve_Ecom_CrsPrm_MajSub_VwNewPageBack=By.xpath(".//*[@id='pageBody']/table[2]/tbody/tr/td/input[@value='Back']");


	//Product Type Code Section Validation

	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_Combo=By.xpath(".//*[@id='div-pi-select-specific-products']/table/tbody/tr[3]/td[1]/div");

	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_InpPercent=By.xpath(".//*[@id='pckpiptpercentageoff']");
	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_Add=By.xpath(".//*[@id='pckpiptaddbtn']");
	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_SelectOption=By.xpath(".//*[@id='pckpiproducttypeselect']/option[1]");

	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_SelectOptionfinal=By.xpath(".//*[@id='pckpiproducttypeselect']/option");

	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_Addsucmsg=By.xpath(".//*[@id='msgpck-pi-save-success'][text()='The Promotion Inclusion is successfully saved.']");
	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_Messg=By.xpath(".//*[@id='pckmscpitable']/tbody/tr");
	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_RmvBtn=By.xpath(".//*[@id='pckptpitable']/tbody/tr/td[text()='CD-ROM']/preceding-sibling::td[2]/a");
	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_RmvBtnfinal=By.xpath(".//*[@id='pckptpitable']/tbody/tr/td/a");
	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_RmvBtnViewAll=By.xpath(".//*[@id='pckptpitable']/tbody/tr/td/a");
	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_AltMsg=By.xpath(".//*[@id='msgpck-pi-save-failure'][text()='Please select product group to add to the promotion.']");
	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_SelectOption1=By.xpath(".//*[@id='pckpiproducttypeselect']/option[2]");
	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_SelectOption2=By.xpath(".//*[@id='pckpiproducttypeselect']/option[3]");
	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_SelectOption3=By.xpath(".//*[@id='pckpiproducttypeselect']/option[4]");
	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_SelectOption4=By.xpath(".//*[@id='pckpiproducttypeselect']/option[5]");

	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_ViewAllMsg=By.xpath(".//*[@id='hlink-container-pckpt-pi']/a[text()='View All Product Types...']");
	public static By Admin_Evolve_Ecom_CrsPrm_PrdTyp_ViewNewPageMsg=By.xpath(".//*[@id='couponViewAllResults']/table/thead/tr[2]/th/table/tbody/tr/td[1]");

	//*[@id='couponViewAllResults']/table/tbody/tr[1]/td[2]/span[text()='10% off - CD-ROM']

	//ISBN Section

	public static By Admin_Evolve_Ecom_CrsPrm_ISBNtxt=By.xpath(".//*[@id='pckpiisbn']");
	public static By Admin_Evolve_Ecom_CrsPrm_ISBNpercent=By.xpath(".//*[@id='pckpiisbnpercentageoff']");
	public static By Admin_Evolve_Ecom_CrsPrm_ISBNAdd=By.xpath(".//*[@id='pckpiisbnaddbtn']");
	public static By Admin_Evolve_Ecom_CrsPrm_ISBNErrMsg=By.xpath(".//*[@id='msgpck-pi-save-failure'][text()='The ISBN does not exist. Please enter new ISBN.']");
	public static By Admin_Evolve_Ecom_CrsPrm_ISBNSucMsg=By.xpath(".//*[@id='msgpck-pi-save-success'][text()='The Promotion Inclusion is successfully saved.']");
	public static By Admin_Evolve_Ecom_CrsPrm_ISBNAddList=By.xpath(".//*[@id='pckisbnpitable']/tbody/tr");
	public static By Admin_Evolve_Ecom_CrsPrm_ISBNRem=By.xpath(".//*[@id='pckisbnpitable']/tbody/tr[1]/td[3]/preceding-sibling::td[2]/a");

	public static By Admin_Evolve_Ecom_CrsPrm_ISBNViewAllLnk=By.xpath(".//*[@id='hlink-container-pckisbn-pi']/a[text()='View All ISBNs...']");
	public static By Admin_Evolve_Ecom_CrsPrm_ISBNViewNewPageMsg=By.xpath(".//*[@id='couponViewAllResults']/table/thead/tr[2]/th/table/tbody/tr/td[1]/strong[text()='Promotion Inclusion - View All ISBNs']");
	public static By Admin_Evolve_Ecom_CrsPrm_ISBNBrowse=By.xpath(".//*[@id='pipckfilename']");
	//public static By Admin_Evolve_Ecom_CrsPrm_ISBNBrowse=By.name("pipckfilename");
	public static By Admin_Evolve_Ecom_CrsPrm_ISBNViewall=By.xpath(".//*[@id='hlink-container-isbn-pi']/a[text()='View All ISBNs...']");

	public static By Admin_Evolve_Ecom_CrsPrm_ISBNUplPercent=By.xpath(".//*[@id='pckpiisbnuploadpercentageoff']");
	public static By Admin_Evolve_Ecom_CrsPrm_ISBNUplBtn=By.xpath(".//*[@id='pckpiisbnuploadbtn']");
	public static By Admin_Evolve_Ecom_CrsPrm_ISBNUplSucMsg=By.xpath(".//*[@id='msgpck-pi-save-success'][text()='The file is uploaded successfully.']");
	public static By Admin_Evolve_Ecom_CrsPrm_ISBNRemoveLink=By.xpath(".//*[@id='pckisbnpitable']/tbody/tr");
	public static String rem1=".//*[@id='pckisbnpitable']/tbody/tr[";
	public static String rem2="]";




	//  VST Test Cases................ TC-15242/15561/15229/15231 ...........................

	//public static By evolve_createNewUser=By.xpath(".//*[@id='signin']//a[text()=' Create an account']");
	public static By evolve_createNewUser=By.xpath(".//a[text()='CREATE ACCOUNT']");
	//public static By evolve_createNewUser=By.xpath("//*[@id='signin']//a[text()='Need help logging in?']");

	public static By faculty_radio_btn=By.xpath(".//*[@id='role-faculty']");
	public static By student_radio_btn=By.xpath(".//*[@id='role-student']");
	public static By evolve_newAccount_firstname=By.xpath(".//*[@id='field-firstName']");
	public static By evolve_newAcount_Lastname=By.xpath(".//*[@id='field-lastName']");
	public static By evolve_newAcount_Email=By.xpath(".//*[@id='field-email']");
	public static By evolve_newAcount_Pwd=By.xpath(".//*[@id='field-password']");
	public static By evolve_newAcount_ConfirmPwd=By.xpath("//*[@id='field-passwordConfirm']");
	public static By evolve_newAcount_Chkbx=By.xpath(".//*[@id='optin']");
	public static By evolve_newAcount_Submit_btn=By.xpath("html//button[text()='Submit']");
	public static By evolve_newAcount_frame=By.xpath(".//*[@id='cboxLoadedContent']/iframe");
	public static By newAccount_contiue_btn=By.xpath("//a[text()='Continue']");
	//public static By evolveCatlog_lnk=By.xpath("//*[@id='div-resources']/div/p/a[text()='Evolve Catalog']");
	public static By evolveCatlog_lnk=By.xpath("//li[@class='nav-breadcrumb']/a[text()='Catalog']");
	//public static By evolve_Serach_txt=By.xpath("//*[@id='headerSearch']");
	public static By evolve_Serach_txt=By.xpath(".//form[@action='/cs/search']/input[@type='text']");
	public static By evolve_Serach_Go_btn=By.xpath("//*[@id='headerSearchForm']/button[text()='GO']");
	public static By evolve_verify_isbn=By.xpath(".//*[@id='pageLayout-body-inner-most']/div//li[1]/span[2]");
	//public static By evolve_Product_pricebeforerequest=By.xpath("//*[@id='tab-relayout']//p/span[@class='price']");
	public static By evolve_Product_pricebeforerequest=By.xpath(".//*[@id='tab-relayout']//div[contains(@class,'cost')]/p/span[1]");
	public static By evolve_Request_Product=By.xpath(".//*[@id='add-to-cart']");//*[@id='add-to-cart']
	public static By evolve_Product_titlebeforerequest=By.xpath(".//*[@id='tab-relayout']/div/div[2]/h1");
	public static By evolve_Product_titleAfterRequest=By.xpath("html/body//div[@class='carttitle']/a");
	public static By evolve_Product_priceAfterRequest=By.xpath("html/body//ul/li[@class='row']/div[@class='price span2']");
	public static By evovle_Product_isbnAfterRequest=By.className("cartproductdetails");
	public static By acess_chkbx=By.xpath("html/body//form/input[@class='ac-purchase']");
	public static By evolve_checkout_btn=By.xpath(".//*[@id='checkoutButton']");
	public static By evolve_Institution_Cntry_txt=By.xpath(".//*[@id='institution-country']");
	public static By evolve_Institution_name=By.xpath(".//*[@id='institution-name']");
	public static By evolve_Institution_street=By.xpath(".//*[@id='address0-address1']");
	public static By evolve_Institution_town=By.xpath(".//*[@id='address0-town']");
	//public static By evolve_Institution_city = By.xpath(".//input[@id='institution-city']");
	public static By evolve_Institution_city = By.xpath(".//input[@id='address0-town']");
	public static By evolve_Institution_state=By.xpath(".//*[@id='address0-province']");
	public static By evolve_Institution_Zipcode=By.xpath(".//*[@id='address0-postalCode']");
	public static By evolve_Institution_Ph=By.xpath(".//*[@id='field-phone']");
	public static By evolve_Programtype=By.xpath(".//*[@id='select-program-type']");
	public static By evolve_User_street=By.xpath(".//*[@id='billing-address1']");
	public static By evolve_User_City=By.xpath(".//*[@id='billing-city']");
	public static By evolve_User_State=By.xpath(".//*[@id='billing-address']/select");
	public static By evolve_User_Postal=By.xpath(".//*[@id='billing-postalCode']");
	public static By evolve_User_KnoPwd=By.id("field-knoPassword");
	public static By evolve_User_VSTPwd=By.id("field-vstPassword");
	public static By evolve_User_chkbx=By.xpath(".//*[@id='offers']");
	public static By evolve_User_submitbtn=By.xpath(".//*[@id='profile-submit']");	
	public static By evolve_Security_Question = By.xpath(".//*[@id='select-vst-question']");
	public static By evolve_Security_Answer = By.xpath(".//*[@id='field-vstSecurityQuestionAnswer']");
	public static By evolve_Rview_chktitle=By.xpath("html/body//ul//div[@class='carttitle']/a");
	public static By evolve_Rview_chkIsbn=By.xpath("html/body//ul//div[@class='cartproductdetails']");
	//public static By evolve_Rview_chkprice=By.xpath("html/body/div[4]//ul/li[@class='row']/div[@class='price span2']");
	public static By evolve_Rview_chkprice=By.xpath(".//ul[@class='receipt']/li[2]/div[@class='price span2']");
	public static By evolveRegisterAcceptChk=By.xpath(".//*[@id='checkbox-registered']");
	public static By evolveInstructorChk=By.xpath(".//*[@id='checkbox-instructor']");
	public static By evolve_Receipt_chktitle=By.xpath(".//*[@id='pageLayout-body-inner-most']//ul//div[@class='carttitle']/a");
	public static By evolve_Receipt_chktisbn=By.xpath(".//*[@id='pageLayout-body-inner-most']//ul//div[@class='cartproductdetails']");
	public static By evolve_Receipt_chkprice=By.xpath(".//*[@id='pageLayout-body-inner-most']//ul/li[@class='row']/div[@class='price span2']");
	//public static By Myevolve=By.xpath(".//*[@id='page']//ul/li[1]/a[text()='My Evolve']");
	public static By Myevolve=By.xpath(".//*[@class='nav-breadcrumb']/a[text()='My Evolve'][1]");
	public static By courseContentLink=By.xpath(".//*[@id='set']/li/div/div/a");



	//public static By evolve_AccessCode_totalprice = By.xpath(".//*[@id='pageLayout-body-inner-most']//td[@class='totalamount strong']");
	public static By evolve_AccessCode_totalprice = By.xpath(".//*[@id='pageLayout-body-inner-most']//td[contains(@class,'totallabel')]//following-sibling::*");
	public static By Kno_refresh_lnk=By.xpath(".//*[@id='el-pane']//div[@class='cl-nav']/a[@class='refresh']");//*[@id='el-pane']/div/div/a[@class='refresh']
	//public static By Kno_library_lnk=By.xpath(".//*[@id='set']/li[@class='set setclosed  ']/div/div/a");
	public static By Kno_library_lnk=By.xpath(".//a[contains(text(),'Kno')]");
	public static By Kno_Home_Instructor=By.xpath("html/body/div[6]/div/div/div[2]/p");
	public static By Kno_Home_Book=By.xpath("html/body/div[1]/div/div/section/div/div[4]/div/div/div[4]/div/div[1]/div[2]/ul/li[2]/div[1]");
	//public static By evolveCatalog=By.xpath(".//*[@id='page']/div[1]/div/div[2]/div/ul/li[2]/a");
	public static By evolveCatalog=By.xpath(".//a[text()='Evolve Catalog']");
	public static By Catalog_Header_Link = By.xpath(".//header//a[text()='Catalog']");
	public static By kno_HomePage = By.xpath(".//*[@id='overall']/div[1]/div/div[2]/ul/li[2]/a/span[text()='Kno Me']"); 
	public static By kno_HomePage_student=By.xpath("html/body/div[6]/div/div/div[1]/p");
	public static By kno_Home_frame=By.id("courseManagerIFrame");

	public static By kno_BookList=By.xpath(".//div[@class='all-my-stuff-container group-holder']//ul[@class='ui-sortable']//p");
	public static By adoptionRequestFulfillStatus=By.xpath(".//*[@id='status']/option[contains(@value,'5')]");
	public static By ORDERNUM_IN_RECEIPT_PAGE=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[2]/div[2]/div/div");

	//.........................//...............................KNO_ACfromHomePage_NewStudent........................................

	public static By admin_MaintainProduct_lnk=By.xpath(".//*[@id='pageBody']/form//td/a[text()='Maintain Products']");
	public static By admin_MaintainProduct_Knotxt=By.id("query");
	public static By admin_MaintainProduct_Submit=By.id("submit");
	public static By MaintainPrdct_prdctSerachReslut_isbn=By.xpath(".//*[@id='table-container']/table/tbody/tr/td[4]/span/a");
	public static By MaintainPrdct_prdctSerach_title=By.xpath(".//*[@id='title-container']");
	public static By MaintainPrdct_MaintainAccesCode=By.xpath(".//*[@id='product-tabs']//a[text()='Manage Access Codes']");

	public static By evolve_Pageburst=By.xpath("//*[@id='uppershelf']/table/tbody/tr/td[1]/img[@class='image1 unclicked']");
	public static By evolve_Pageburst_Reedemlnk=By.xpath(".//*[@id='uppershelf']/div[@class='box box1']//a[text()='Redeem an access code']");
	//public static By evolve_Reedemlnk_AccessCode=By.xpath(".//*[@id='pageLayout-body-inner-most']//form[@class='form-inline']//div/input[@name='accessCode']");
	//public static By evolve_AccessCode_Submitbtn=By.xpath(".//*[@id='pageLayout-body-inner-most']//form/div[4]/input[@value='SUBMIT']");
	public static By evolve_Reedemlnk_AccessCode=By.xpath(".//input[@id='accessCode']");
	public static By evolve_AccessCode_Submitbtn=By.xpath(".//button[@class='submit-button']");
	public static By evolve_Accesscode_isbn=By.xpath("html/body//ul/li[@class='row']//div[@class='cartproductdetails']");
	public static By evolve_AccessCode_afterRequest=By.xpath("html/body//ul/li[@class='row']/form/input[@name='accessCode']");
	//public static By evolve_AccessCode_totalprice=By.xpath(".//*[@id='pageLayout-body-inner-most']//td[@class='totalamount strong']");
	public static By admin_accesscode_status=By.xpath("//*[@id='table-container']/table/tbody/tr/td[5]/span");
	//public static By AccessCode_Error_Msg=By.xpath(".//*[@id='ext-gen5']");
	public static By AccessCode_Error_Msg=By.xpath(".//p[@class='access-code-validation']");
	//public static By Mycart_alert=By.xpath(".//*[@id='toPopup']/button");
	//.................................KNOACfromHomePage_NewInstructor...................................

	public static By createAccessCode=By.xpath(".//*[@id='product-tabs']/ul/li[6]/a[text()='Create Access Codes']");
	public static By CreateAccessCode_codesetname=By.xpath(".//*[@id='acsname']");
	public static By CreateAccessCode_codeNumber=By.xpath(".//*[@id='numbertogenerate']");
	public static By CreateAccessCode_Submit=By.xpath(".//*[@id='accessCodeSubmit']");
	public static By AccessCodeSetTable=By.xpath(".//*[@id='accessCodeSetsList']/table/tbody/tr/td[1]/span/div");
	public static By accessCodeSetName_clk=By.xpath(".//*[@id='accessCodeSetsList']//tr[1]/td[1]/span/div/a[@id='anchoracsinfo']");
	//public static By AccessCodeDownload=By.xpath(".//*[@id='downloadAccessCode']/strong");
	//public static By popupDownload=By.xpath("html/body/div[3]/div[3]/div/button[1]");
	public static By AccessCode=By.xpath(".//*[@id='accessCodeSetContainer']/table/tbody/tr[1]/td[1]/span/a");
	public static By AccessCode_status=By.xpath(".//*[@id='table-container']/table/tbody/tr/td[5]");
	public static By Success_MSG_for_AccessCode=By.xpath(".//*[@id='msg-accesscodes-success'][text()='The Access Code Set was successfully created. ']");

	//.................................KNOACfromMyCartStuden......................................

	//public static By AccessCode_radio_btn=By.xpath("html/body//ul/li[2]/form/input[@class='ac-apply']");


	//TC-1522/15239/15223/15240.................................................................................
	//public static By common_login_userName = By.xpath(".//*[@id='loginForm-username']");
	//public static By common_login_passWord = By.xpath(".//*[@id='loginForm-password']");
	public static By common_login_userName = By.xpath(".//form[@action='/cs/login']/input[@name='username']");
	public static By common_login_passWord = By.xpath(".//form[@action='/cs/login']/input[@name='password']");
	public static By common_login_submit = By.xpath(".//*[@id='signin']/input[@class='btn btn-primary']");
	public static By myevolve_pageburstVST_link = By.xpath(".//*[@id='set']/li/div/div/a");
	public static By myevolve_pageburstVST_link1 = By.xpath(".//*[@id='set']/li/div/div/a[text()='Go to Pageburst on Kno library']");
	public static By vstLink_element = By.xpath(".//*[@id='right']/span[text()='Powered By VitalSource']");
	public static By myevolve_pageburstVST_link2 = By.xpath(".//*[@id='set']/li/div/div/a[text()='Go to Pageburst on VitalSource library']");
	//public static By accessCode_errorMessage = By.xpath(".//*[@id='ext-gen5']");
	public static By accessCode_errorMessage = By.xpath(".//p[@class='access-code-validation']");


	public static By acceptForVSTLink = By.xpath(".//*[@id='page']/form/p/button[@class='submit']");

	// Test Case Id TC-15562/15241...........................................................................

	public static By access_apply_chkbox = By.xpath(".//*[@class='ac-apply']");
	public static By accessCode_type = By.xpath(".//*[@name='accessCode']");
	//public static By accessCode_submit = By.xpath("html/body/div[4]/div[3]/div/div/div/div/div/ul/li[2]/form/input[@value='Apply']");
	public static By accessCode_submit = By.xpath(".//form[@class='accesscoderadios form-inline']/input[@type='submit']");
	public static By accessCode_Verify = By.xpath(".//*[@id='ext-gen5'][text()='The access code is not valid.']");


	public static By StudentMainPage=By.xpath(".//*[@id='page']/div/div/div/div/a[text()='Main Page']");






	/* ...........AccesCode_PKG_10216.............. */ 
	public static By  adminemail     = By.id("userName");
	public static By  adminpassword  = By.id("password");
	public static By  adminlogin     = By.xpath(".//tr[2]/td/input[3]");
	public static By searchMAC       = By.xpath(".//*[@id='pageBody']//a[text()='Maintain Access Code Packages']");
	public static By  brudcrum       = By.xpath(".//*[@id='pageBody']/table/tbody[1]/tr/td/table/tbody/tr/td");
	public static By  searchISBN     = By.xpath(".//*[@id='packageISBN']");
	public static By  btngo          = By.xpath(".//*[@id='btnPackage']");
	public static By  packageName    = By.xpath(".//*[@id='packagename']");
	public static By  btnSave      = By.xpath(".//*[@id='saveBookStorePackage']");
	public static By  isbnText     = By.xpath(".//*[@id='isbn']");
	public static By  btnRemove     = By.xpath(".//td[6]/a[text()='Remove']");
	public static By  edit_message     = By.xpath(".//*[@id='msg-save-success']/b");
	public static By  logout     = By.xpath(".//*[@id='logoutArea']/span/a[text()='Logout']");
	public static By MaintainProductHeaderLink=By.xpath(".//*[@id='frmsearch']//tr[contains(@class,'highlight')]/td/strong");
	/* ................      ................... */

	/* ...........AR_WorkFlow_8565 .............. */ 
	//public static By  iameducator    = By.xpath(".//*[@id='page']/div[2]/div[2]/a");
	public static By  iameducator    = By.xpath(".//a[@class='pull-right educator ed-only']");
	//public static By  login          = By.xpath(".//a[@class='signin relative']");
	public static By  login          = By.xpath(".//a[text()='Login']");
	//public static By  email          = By.id("loginForm-username");
	//public static By  password       = By.id("loginForm-password");
	//public static By  submit         = By.xpath(".//*[@id='signin_submit ']");
	public static By  email          = By.xpath(".//form[@action='/cs/login']/input[@name='username']");
	public static By  password       = By.xpath(".//form[@action='/cs/login']/input[@name='password']");
	public static By  submit         = By.xpath(".//form[@action='/cs/login']//button");
	public static By  lnkevolvecart  = By.xpath(".//*[@id='div-resources']/div/p/a[text()='Evolve Catalog']");
	//public static By  txtproductsearch  = By.id("headerSearch");
	//public static By  gobutton       = By.xpath(".//div[2]/form/button");
	public static By  txtproductsearch  = By.xpath(".//form[@action='/cs/search']/input[@type='text']");
	public static By  gobutton       = By.xpath(".//form[@action='/cs/search']/button");
	public static By  btnaddtocart      = By.id("add-to-cart");
	public static By priceText			= By.xpath(".//span[@class='price']");
	public static By  frame          = By.className("cboxIframe");
	public static By  evolvebutton   = By.id("resourcestools");
	public static By  apply          = By.xpath(".//button[contains(text(),'Apply')]");
	public static By  price          = By.xpath(".//div/ul/li[2]/div[text()='$0.00']");
	public static By  checkout       = By.id("checkoutButton");
	public static By  checkbox1      = By.xpath(".//*[@id='checkbox-registered']");
	public static By  checkbox2      = By.xpath(".//*[@id='checkbox-instructor']");
	public static By  submitbutton   = By.xpath(".//*[@id='submitButton']");
	//public static By  educatorlogout     = By.xpath(".//a[contains(text(),'Logout')]");
	public static By  educatorlogout     = By.xpath(".//a[@class='logout']");
	public static By  searchAR       = By.linkText("Search Adoption Requests");
	//public static By  searchAR       = By.xpath(".//*[@id='pageBody']/form/table/tbody//a[text()='Search Adoption Requests']");	//public static By  btndatesearch  = By.xpath(".//*[@id='mapping']//span[2]/input[@name='dateSearchType']");
	public static By  btndatesearch  = By.xpath(".//*[@id='bottomSearch']");
	//public static By  rbtndate     = By.xpath(".//div/span[2]/input");
	//public static By  rbtndate     = By.xpath(".//*[@id='mapping']//select");
	public static By  rbtndate     = By.xpath(".//*[@id='mapping']//input[@value='dateRangeSearch']");
	public static By  lnkorderedAR      = By.xpath(".//tr/td[8]/div");
	public static By noAdoptionsFoundMessage = By.xpath(".//*[@class='heading1']/b[text()='No adoptions    found.']");
	public static By RosterRoles=By.xpath(".//*[@id='pageLayout-body-inner-most']//a[text()='What are roles?']");
	public static By  btndatesearch_AR  = By.xpath(".//*[@id='mapping']//input[@value='daysBackSearch']");
	public static By selectdays=By.xpath(".//*[@id='mapping']//select[@name='daysBack']");
	//public static By  btndatesearch  = By.xpath(".//*[@id='bottomSearch']");



	/* ................           .............. */	

	/* ...........AR_WorkFlow_9795 .............. */ 

	/* ...........AR_WorkFlow_8563 .............. */ 
	public static By newtoEvol=By.xpath(".//*[@id='pageLayout-body-inner-most']//h1[contains(text(),'New to Evolve? Create an account!')]");
	//public static By  educator_txtStudentUser = By.xpath(".//*[@id='loginForm-username']");
	//public static By  educator_txtStudentPassword = By.xpath(".//*[@id='loginForm-password']");
	public static By  educator_txtStudentUser = By.xpath(".//input[@name='username']");
	public static By checkout_login_username = By.xpath(".//form[@id='signin']//input[@name='username']");
	public static By checkout_login_password = By.xpath(".//form[@id='signin']//input[@name='password']");
	public static By  educator_txtStudentPassword = By.xpath(".//input[@name='password']");
	public static By existingLogin_username = By.xpath(".//form[@id='signin']//input[@name='username']");
	public static By existingLogin_password = By.xpath(".//form[@id='signin']//input[@name='password']");

	public static By  educator_btnLogin = By.xpath(".//*[@id='signin_submit']");
	public static By  educator_chkInstution = By.xpath(".//*[@id='no-institution']");
	public static By searchBillAddress=By.xpath(".//*[@id='form-profile']/h3[text()='Enter your billing address:']");
	/* ................          .............. */	

	/* ...........AR_WorkFlow_8564 .............. */ 

	//public static By home_student_lnkstudent    = By.xpath(".//*[@id='page']/div[@class='getstarted']/div[1]/a");
	public static By home_student_lnkstudent    = By.xpath(".//div[@class='student-faculty clearfix']/a[@class='pull-left student']");
	public static By student_product_price      = By.xpath(".//*[@id='9781416046073']/div[@class='price span2']");
	public static By creditCard_form      = By.xpath(".//*[@id='cc-type']");
	public static By CreditCardNum      = By.xpath(".//*[@id='cc-number']");
	public static By CreditCardCvv      = By.xpath(".//*[@id='cc-cvv']");
	public static By CreditCardName      = By.xpath(".//*[@id='cc-name']");
	public static By CreditCardMonth      = By.xpath(".//*[@id='cc-month']");
	public static By CreditCardyear      = By.xpath(".//*[@id='cc-year']");
	public static By CreditCardSubmit      = By.xpath(".//*[@id='cc-form']/input[@value='Continue']");

	public static By instructor_chk      = By.xpath(".//*[@id='checkbox-registered']");
	public static By instructor_submit      = By.xpath(".//*[@id='submitButton']");
	public static By instructor_checkoutcvv     = By.xpath(".//*[@id='checkout-cvv']");
	public static By ReqApply=By.xpath(".//div[@id='cboxClose']");

	/* ................          .............. */
	public static By HESI_Fac_Firstname=By.xpath(".//*[@id='txtPDFirstName']");
	public static By HESI_Fac_Lastname=By.xpath(".//*[@id='txtPDLastName']");
	public static By HES_Fac_Email=By.xpath(".//*[@id='txtPDEmail']");
	public static By HES_Fac_CountryCode=By.xpath(".//*[@id='txtCountryCode']");
	public static By HES_Fac_AreaCode=By.xpath(".//*[@id='txtPDAreaCode']");
	public static By HES_Fac_PhoneNumber=By.xpath(".//*[@id='txtPDPhoneNumber']");
	public static By HES_Fac_Extension=By.xpath(".//*[@id='txtExtension']");
	public static By HES_Fac_EvolveID=By.xpath(".//*[@id='txtPDEvolveId']");
	public static By HES_Fac_cOUNTRY=By.xpath(".//*[@id='ddPDCountry']");
	public static By HES_Fac_Address1=By.xpath(".//*[@id='txtPDAddress1']");
	public static By HES_Fac_Address2=By.xpath(".//*[@id='txtPDAddress2']");
	public static By HES_Fac_ZipCode=By.xpath(".//*[@id='txtPDZipCode']");
	public static By HES_Fac_City=By.xpath(".//*[@id='txtPDCity']");
	public static By HES_Fac_State=By.xpath(".//*[@id='txtPDState']");
	public static By Hes_Fac_Comments=By.xpath(".//*[@id='txtComments']");
	public static By Hes_Fac_Save=By.xpath(".//*[@id='SaveCancel']/a[contains(text(),'Save')]");
	public static By Hes_Fac_Next=By.xpath(".//*[@id='facSaveBtn']");
	public static By HESI_Firstname=By.xpath(".//*[@id='txtlblFirstName']");
	public static By HESI_Lastname=By.xpath(".//*[@id='txtfacLastName']");
	public static By HESI_UserMailid=By.xpath(".//*[@id='txtfacEmail']");
	public static By HESI_Country=By.xpath(".//*[@id='ddlfacCountry']");
	public static By HESI_CountryCode=By.xpath(".//*[@id='txtfacCountryCode']");
	public static By HESI_Areacode=By.xpath(".//*[@id='txtfacAreaCode']");
	public static By HESI_Phonenumber=By.xpath(".//*[@id='txtfacContact1']");
	public static By HESI_FacEvolveId=By.xpath(".//*[@id='txtfacEvolveId']");
	public static By HESI_Address1=By.xpath(".//*[@id='txtfacAddress1']");
	public static By HESI_Address2=By.xpath(".//*[@id='txtfacAddress2']");
	public static By HESI_ZipCode=By.xpath(".//*[@id='txtfacZipCode']");
	public static By HESI_City=By.xpath(".//*[@id='txtfacCity']");
	public static By HESI_State=By.xpath(".//*[@id='txtfacState']");
	public static By HESI_comments=By.xpath(".//*[@id='txtfacComments']");
	public static By comments=By.xpath(".//*[@id='txtfacComments']");
	public static By NextButton=By.xpath(".//*[@id='facSaveBtn']");

	public static By HESI_Stud_Evolveid=By.xpath(".//*[@id='StdResultGrid']/tbody/tr/td[3]");
	public static By HESI_Stud_Firstname=By.xpath(".//*[@id='StdResultGrid']/tbody/tr/td[5]");
	public static By HESI_Stud_Lastname=By.xpath(".//*[@id='StdResultGrid']/tbody/tr/td[6]");
	public static By HESI_Stud_Email=By.xpath(".//*[@id='StdResultGrid']/tbody/tr/td[7]");

	public static By  User_form_UserName = By.xpath(".//*[@id='form-profile']/div[1]/div[1]/input");
	public static By  User_form_txtFirstName     = By.xpath(".//*[@id='field-firstName']");
	public static By  User_form_txtLastName      = By.xpath(".//*[@id='field-lastName']");
	public static By  User_form_txtEmail    	 = By.xpath(".//*[@id='field-email']");
	public static By  User_form_txtConformEmail   = By.xpath(".//*[@id='field-emailConfirm']");
	public static By  User_form_txtPassword   = By.xpath(".//*[@id='field-password']");
	public static By  User_form_txtConformPassword   = By.xpath(".//*[@id='field-passwordConfirm']");	
	public static By  User_form_txtInstution   = By.xpath(".//*[@id='institution-name']");
	public static By  User_form_txtAddress1   = By.xpath(".//*[@id='address0-address1']");
	public static By  User_form_txtAddress2  = By.xpath(".//*[@id='address0-address2']");
	public static By  User_form_txtAddTown  = By.xpath(".//*[@id='address0-town']");
	public static By  User_form_txtAddProvince  = By.xpath(".//*[@id='address0-province']");
	public static By  User_form_txtAddPostalCode  = By.xpath(".//*[@id='address0-zipCode']");
	public static By  User_form_txtAddPhone  = By.xpath(".//*[@id='field-phone']");
	public static By  User_form_ddInstutionCountry  = By.xpath(".//*[@id='institution-country']");
	public static By  User_form_txtddprogramType  = By.xpath(".//*[@id='select-program-type']");
	public static By  User_form_State=By.xpath(".//*[@id='institution-state']");
	public static By  User_form_City=By.xpath(".//*[@id='institution-city']");
	public static By  User_form_btnContinue = By.xpath(".//*[@id='profile-submit']");


	/* ...........AR_WorkFlow_8566 .............. */ 
	//public static By student_login            = By.xpath(".//*[@id='login-menu']/a[text()='Login']");
	public static By student_login            = By.xpath(".//*[@class='header-link' and text()='Login']");
	public static By student_chkInstution     = By.xpath(".//*[@id='no-institution']");
	public static By btnprofilecontinue       = By.id("profile-submit");

	public static By student_billingAddress    = By.xpath(".//*[@id='billing-address1']");
	public static By student_billingAddress_city    = By.xpath(".//*[@id='billing-city']");
	public static By student_billingAddress_state    = By.xpath(".//*[@id='billing-address']/select");
	public static By student_billingAddress_zip    = By.xpath(".//*[@id='billing-postalCode']");
	public static By Mycart_alert=By.xpath(".//*[@id='toPopup']/button[text()='OK']");
	//*[@id='toPopup']/button
	/* ..................             ........... */

	//Test ID (10219) - Ecommerce PKG - Create Landing Page - 2

	public static By Admin_Evolve_Ecom_MrkPgeTab=By.xpath(".//*[@id='product-tabs']/ul/li[3]/a[text()='Marketing Page']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_StaticPgeHdr=By.xpath(".//*[@id='marketing-details']/table/tbody/tr[1]/td/table[1]/tbody/tr[4]/td/b");
	public static By Admin_Evolve_Ecom_MrkPgeTab_UrlHdr=By.xpath(".//*[@id='marketing-details']/table/tbody/tr[1]/td/table[1]/tbody/tr[6]/td/div/table/tbody/tr[1]/td");
	public static By Admin_Evolve_Ecom_MrkPgeTab_PgeExpDt=By.xpath(".//*[@id='marketing-details']/table/tbody/tr[1]/td/table[1]/tbody/tr[6]/td/div/table/tbody/tr[3]/td");
	public static By Admin_Evolve_Ecom_MrkPgeTab_HdrPgeTitle=By.xpath(".//*[@id='marketing-details']/table/tbody/tr[1]/td/table[1]/tbody/tr[6]/td/div/table/tbody/tr[5]/td");
	public static By Admin_Evolve_Ecom_MrkPgeTab_HdrPgeBdy=By.xpath(".//*[@id='marketing-details']/table/tbody/tr[1]/td/table[1]/tbody/tr[6]/td/div/table/tbody/tr[7]/td");
	public static By Admin_Evolve_Ecom_MrkPgeTab_HdrImg=By.xpath(".//*[@id='marketing-details']/table/tbody/tr[1]/td/table[1]/tbody/tr[6]/td/div/table/tbody/tr[9]/td[1]");
	public static By Admin_Evolve_Ecom_MrkPgeTab_HdrPrw=By.xpath(".//*[@id='marketing-details']/table/tbody/tr[1]/td/table[1]/tbody/tr[6]/td/div/table/tbody/tr[12]/td");

	public static By Admin_Evolve_Ecom_MrkPgeTab_UnqUrlErrMsg=By.xpath(".//*[@id='resultsMessage'][text()='Unique Marketing URL is required.']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_UnqUrl=By.xpath(".//*[@id='marketingUrl']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_Date=By.xpath(".//*[@id='pageExpirationDate']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_PgeTitle=By.xpath(".//*[@id='headerPageTitle']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_PgeBody=By.xpath(".//*[@id='headerTitleBody']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_HdrImgInp=By.xpath(".//*[@id='header_image']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_HdrUrl=By.xpath(".//*[@id='header_image_URL']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrmUrl=By.xpath(".//*[@id='cross_promote_image']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_HdrImgSelf=By.xpath(".//*[@id='header_image_target_self']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_HdrImgBlnk=By.xpath(".//*[@id='header_image_target_blank']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_HdrImgPopUp=By.xpath(".//*[@id='header_image_target_pop_up']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_HdrImgWidth=By.xpath(".//*[@id='header_image_width']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_HdrImgHeight=By.xpath(".//*[@id='header_image_height']");

	//cross promote items
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Items=By.xpath(".//*[@id='crossPromoteItems']/tbody/tr[4]/td/b");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrTitle=By.xpath(".//*[@id='crossPromoteContainer']/div[1]/table/tbody/tr[2]/td");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Title=By.xpath(".//*[@id='crossPromoteTitle']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrDescrip=By.xpath(".//*[@id='crossPromoteContainer']/div[1]/table/tbody/tr[4]/td");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Description=By.xpath(".//*[@id='crossPromoteTitleBody']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SltFeatureRadBtn=By.xpath(".//*[@id='crossPromote_items']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_GenImgRadBtn=By.xpath(".//*[@id='crossPromote_items_image']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrImg=By.xpath(".//*[@id='genricImage']/tbody/tr[2]/td[1]");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ImgBrowse=By.xpath(".//*[@id='cross_promote_image']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ImgPrw=By.xpath(".//*[@id='cross_promote_image_preview']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrUrl=By.xpath(".//*[@id='genricImage']/tbody/tr[5]/td");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Url=By.xpath(".//*[@id='crossPromote_image_URL']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Self=By.xpath(".//*[@id='crossPromote_image_target_self']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Blank=By.xpath(".//*[@id='crossPromote_image_target_blank']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_PopUp=By.xpath(".//*[@id='crossPromote_image_target_pop_up']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Width=By.xpath(".//*[@id='crossPromote_image_width']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Height=By.xpath(".//*[@id='crossPromote_image_height']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SaveAndPublish=By.xpath(".//*[@id='saveMarketingPage']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ReqFlds=By.xpath(".//*[@id='marketing-details']/table/tbody/tr/td[text()='* Required Fields']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ISBN=By.xpath(".//*[@id='crossPromoteIsbn']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ISBNAdd=By.xpath(".//*[@id='addCrossPromoteItem']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SuccMsg=By.xpath(".//*[@id='resultsMessage'][text()='Marketing page details are saved successfully.']");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrPageTitleVfyTxt=By.xpath(".//*[@id='pageLayout-body-inner-most']/div[1]/div/div/h1");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrPageBodyVfyTxt=By.xpath(".//*[@id='pageLayout-body-inner-most']/div[1]/div/div/p[1]");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_TitleVrfy=By.xpath(".//*[@id='pageLayout-body-inner-most']/div[2]/div[2]/div[1]");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_DescVrfy=By.xpath(".//*[@id='pageLayout-body-inner-most']/div[2]/div[2]/div[2]/p");
	public static By Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ProdTitle=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class,'productTitle')]/a");
	public static By urlISBNTitle=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class,'productTitle')]/a");
	//macros
	public static String testresult=null;
	public static String testresultPath=null;
	public static String adminBrowserType=null;
	public static String studentBrowserType=null;


	//student pop up handling
	public static By Admin_Evolve_StdtPopUp=By.xpath(".//div[@id='toPopup']/button");

	//Ecommerce Cross Promotion inclusions 5

	//Test case(15560)
	public static By Admin_Evolve_Ecom_ExcludeProducts=By.xpath(".//*[@id='promotion-package']/tbody/tr[4]/td/table/tbody/tr/td/b");
	public static By Admin_Evolve_Ecom_Reference=By.id("pcktextRefTradeRe");
	public static By Admin_Evolve_Ecom_Text=By.id("pcktextRefTradeTe");
	public static By Admin_Evolve_Ecom_Trade=By.id("pcktextRefTradeTr");
	public static By Admin_Evolve_Ecom_Annual=By.id("pcktextRefTradeAn");
	public static By Admin_Evolve_Ecom_pkgsuccess=By.xpath(".//*[@id='msgpck-pe-save-success']");


	//profit centre

	public static By Admin_Evolve_Ecom_Combo=By.xpath(".//*[@id='promotion-package']/tbody/tr[5]/td/table/tbody/tr[5]/td/table/tbody/tr[1]/td[1]");
	public static By Admin_Evolve_Ecom_Excludepc=By.xpath(".//*[@id='pckpepcexcludebtn']");
	//*[@id='pepcexcludebtn']
	public static By Admin_Evolve_Ecom_SelectOption=By.xpath(".//*[@id='pckpeprofitcenterselect']/option[text()='ABMS (GMD)']");
	public static By Admin_Evolve_Ecom_Addsucmsg=By.xpath(".//*[@id='msgpck-pe-save-success'][text()='The Promotion Exclusion is successfully saved.']");
	public static By Admin_Evolve_Ecom_Messg=By.xpath(".//*[@id='table-container-pckpc-pe']/table/tbody/tr");
	public static By Admin_Evolve_Ecom_RmvBtn=By.xpath(".//*[@id='table-container-pckpc-pe']/table/tbody/tr/td[text()='ABMS (GMD)']/preceding-sibling::td[1]/a");
	public static By Admin_Evolve_Ecom_RmvBtnViewAll=By.xpath(".//*[@id='table-container-pckpc-pe']/table/tbody/tr/td/a");
	public static By Admin_Evolve_Ecom_AltMsg=By.xpath(".//*[@id='msgpck-pe-save-failure'][text()='Please select product group to add to the promotion.']");
	public static By Admin_Evolve_Ecom_SelectOption1=By.xpath(".//*[@id='pckpeprofitcenterselect']/option[text()='Allergy']");
	public static By Admin_Evolve_Ecom_SelectOption2=By.xpath(".//*[@id='pckpeprofitcenterselect']/option[text()='Amirsys']");
	public static By Admin_Evolve_Ecom_SelectOption3=By.xpath(".//*[@id='pckpeprofitcenterselect']/option[text()='Anesthesiology']");
	public static By Admin_Evolve_Ecom_SelectOption4=By.xpath(".//*[@id='pckpeprofitcenterselect']/option[text()='Athletic Training']");

	public static By Admin_Evolve_Ecom_ViewAllMsg=By.xpath(".//*[@id='hlink-container-pckpc-pe']/a");
	public static By Admin_Evolve_Ecom_ViewNewPageMsg=By.xpath(".//*[@id='couponViewAllResults']//td//strong");
	public static By Admin_Evolve_Ecom_VwNewPageRemove=By.xpath(".//*[@id='pageBody']/table/tbody/tr/td/input[@value='Remove']");
	public static By Admin_Evolve_Ecom_VwNewPageBack=By.xpath(".//*[@id='pageBody']/table/tbody/tr/td/input[@value='Back']");

	public static By Admin_Evolve_Ecom_VwChkBox=By.xpath(".//*[@id='couponViewAllResults']/table/tbody/tr[1]/td[1]/span/input");
	public static By Admin_Evolve_Ecom_VwTxtVrfy=By.xpath(".//*[@id='couponViewAllResults']/table/tbody/tr[1]/td[2]/span");
	public static By Admin_Evolve_Ecom_VwRowData=By.xpath(".//*[@id='couponViewAllResults']/table/tbody/tr[1]");
	public static By Admin_Evolve_Ecom_RmvData=By.xpath(".//*[@id='removeallitems_1']");
	public static By Admin_Evolve_Ecom_VwBack=By.xpath(".//*[@id='viewallback']"); 

	// major subjects		

	public static By Admin_Evolve_Ecom_MajSub_Combo=By.xpath(".//*[@id='promotion-package']/tbody/tr[5]/td/table/tbody/tr[5]/td/table/tbody/tr[2]/td[1]");

	public static By Admin_Evolve_Ecom_Excludems=By.id("pckpemscexcludebtn"); 
	public static By Admin_Evolve_Ecom_MajSub_AltMsg=By.xpath(".//*[@id='msgpck-pe-save-failure'][text()='Please select product group to add to the promotion.']");
	public static By Admin_Evolve_Ecom_MajSub_SelectOption=By.xpath(".//*[@id='pckpemscselect']/option[text()='aaecca']");
	public static By Admin_Evolve_Ecom_MajSub_Addsucmsg=By.xpath(".//*[@id='msgpck-pe-save-success'][text()='The Promotion Exclusion is successfully saved.']");
	public static By Admin_Evolve_Ecom_MajSub_Messg=By.xpath(".//*[@id='table-container-pckmsc-pe']/table/tbody/tr");
	public static By Admin_Evolve_Ecom_MajSub_RmvBtn=By.xpath(".//*[@id='table-container-pckmsc-pe']/table/tbody/tr/td[text()='aaecca']/preceding-sibling::td[1]/a");
	public static By Admin_Evolve_Ecom_MajSub_RmvBtnViewAll=By.xpath(".//*[@id='table-container-pckmsc-pe']/table/tbody/tr/td/a");
	public static By Admin_Evolve_Ecom_MajSub_SelectOption1=By.xpath(".//*[@id='pckpemscselect']/option[text()='ACLS Adv Cardiac Life Support']");
	public static By Admin_Evolve_Ecom_MajSub_SelectOption2=By.xpath(".//*[@id='pckpemscselect']/option[text()='Allergy']");
	public static By Admin_Evolve_Ecom_MajSub_SelectOption3=By.xpath(".//*[@id='pckpemscselect']/option[text()='Anatomy']");
	public static By Admin_Evolve_Ecom_MajSub_SelectOption4=By.xpath(".//*[@id='pckpemscselect']/option[text()='Anesthesiology']");

	public static By Admin_Evolve_Ecom_MajSub_ViewAllMsg=By.xpath(".//*[@id='hlink-container-pckmsc-pe']/a[text()='View All Major Subject Codes...']");
	public static By Admin_Evolve_Ecom_MajSub_ViewNewPageMsg=By.xpath(".//*[@id='couponViewAllResults']/table/thead/tr[2]/th/table/tbody/tr/td[1]/strong[text()='Promotion Exclusion - View All Major Subject Codes']");
	public static By Admin_Evolve_Ecom_MajSub_VwNewPageRemove=By.xpath(".//*[@id='pageBody']/table[2]/tbody/tr/td/input[@value='Remove']");
	public static By Admin_Evolve_Ecom_MajSub_VwNewPageBack=By.xpath(".//*[@id='pageBody']/table[2]/tbody/tr/td/input[@value='Back']"); 

	// product type
	public static By Admin_Evolve_Ecom_PrdTyp_Combo=By.xpath(".//*[@id='promotion-package']/tbody/tr[5]/td/table/tbody/tr[5]/td/table/tbody/tr[3]/td[1]");

	public static By Admin_Evolve_Ecom_Excludept=By.id("pckpeptexcludebtn");
	public static By Admin_Evolve_Ecom_PrdTyp_SelectOption=By.xpath(".//*[@id='pckpeproducttypeselect']/option[text()='CD-ROM']");
	public static By Admin_Evolve_Ecom_PrdTyp_Addsucmsg=By.xpath(".//*[@id='msgpck-pe-save-success'][text()='The Promotion Exclusion is successfully saved.']");
	public static By Admin_Evolve_Ecom_PrdTyp_Messg=By.xpath(".//*[@id='table-container-pckpt-pe']/table/tbody/tr");
	public static By Admin_Evolve_Ecom_PrdTyp_RmvBtn=By.xpath(".//*[@id='table-container-pckpt-pe']/table/tbody/tr/td[text()='CD-ROM']/preceding-sibling::td[1]/a");
	public static By Admin_Evolve_Ecom_PrdTyp_RmvBtnViewAll=By.xpath(".//*[@id='table-container-pckpt-pe']/table/tbody/tr/td/a");
	public static By Admin_Evolve_Ecom_PrdTyp_AltMsg=By.xpath(".//*[@id='msgpck-pe-save-failure'][text()='Please select product group to add to the promotion.']");
	public static By Admin_Evolve_Ecom_PrdTyp_SelectOption1=By.xpath(".//*[@id='pckpeproducttypeselect']/option[text()='Custom Online Course']");
	public static By Admin_Evolve_Ecom_PrdTyp_SelectOption2=By.xpath(".//*[@id='pckpeproducttypeselect']/option[text()='Custom Online Course - Access Card']");
	public static By Admin_Evolve_Ecom_PrdTyp_SelectOption3=By.xpath(".//*[@id='pckpeproducttypeselect']/option[text()='Custom Pageburst E-Book on Kno']");
	public static By Admin_Evolve_Ecom_PrdTyp_SelectOption4=By.xpath(".//*[@id='pckpeproducttypeselect']/option[text()='Custom Pageburst E-Book on VitalSource']");

	public static By Admin_Evolve_Ecom_PrdTyp_ViewAllMsg=By.xpath(".//*[@id='hlink-container-pckpt-pe']/a[text()='View All Product Types...']");
	public static By Admin_Evolve_Ecom_PrdTyp_ViewNewPageMsg=By.xpath(".//*[@id='couponViewAllResults']/table/thead/tr[2]/th/table/tbody/tr/td[1]/strong[text()='Promotion Exclusion - View All Product Types']");

	//isbn section 
	public static By Admin_Evolve_Ecom_ISBNtxt=By.xpath(".//*[@id='pckpeisbn']");
	public static By Admin_Evolve_Ecom_Excludeisbn=By.xpath(".//*[@id='pckpeisbnexcludebtn']");
	public static By Admin_Evolve_Ecom_ISBNErrMsg=By.xpath(".//*[@id='msgpck-pe-save-failure']");
	public static By Admin_Evolve_Ecom_ISBNSucMsg=By.xpath(".//*[@id='msgpck-pe-save-success']");
	public static By Admin_Evolve_Ecom_ISBNAddList=By.xpath(".//*[@id='table-container-pckisbn-pe']/table/tbody/tr");
	public static By Admin_Evolve_Ecom_ISBNRem=By.xpath(".//*[@id='table-container-pckisbn-pe']/table/tbody/tr/td[2]/preceding-sibling::td[1]/a");

	public static By Admin_Evolve_Ecom_ISBNViewAllLnk=By.xpath(".//*[@id='hlink-container-pckisbn-pe']/a[text()='View All ISBNs...']");
	public static By Admin_Evolve_Ecom_ISBNViewNewPageMsg=By.xpath(".//*[@id='couponViewAllResults']/table/thead/tr[2]/th/table/tbody/tr/td[1]/strong[text()='Promotion Exclusion - View All ISBNs']");
	public static By Admin_Evolve_Ecom_ISBNBrowse=By.xpath(".//*[@id='pepckfilename']");

	public static By Admin_Evolve_Ecom_ISBNUplBtn=By.xpath(".//*[@id='pckpeisbnuploadbtn']");
	public static By Admin_Evolve_Ecom_ISBNUplSucMsg=By.xpath(".//*[@id='msgpck-pe-save-success'][text()='The file is uploaded successfully.']");
	public static By Admin_Evolve_Ecom_ISBNRemoveLink=By.xpath(".//*[@id='table-container-pckisbn-pe']/table/tbody/tr"); 

	public static String remove_a=".//*[@id='table-container-pckisbn-pe']/table/tbody/tr[";
	public static String remove_b="]";
	// test id 8569,8570
	//public static By Hesi_Search=By.xpath(".//form[@id='headerSearch']");
	//public static By Hesi_Go=By.xpath(".//*[@id='headerSearchForm']/button[text()='GO']");
	public static By Hesi_Search=By.xpath(".//form[@action='/cs/search']/input[@type='text']");
	public static By Hesi_Go=By.xpath(".//form[@action='/cs/search']/button[text()='GO']");
	public static By Hesi_Resultfound=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[3]/div[text()='0 Results found']");


	//Test ID (10224) - Ecommerce PKG - Redeem - 3
	public static By Admin_Evolve_Ecom_UniqISBNLnk=By.xpath(".//*[@id='pageLayout-body-inner-most']/div[2]/div[2]/div[2]/div/div[2]/a");
	public static By Admin_Evolve_Ecom_AddtoCart=By.xpath(".//*[@id='add-bundle']");
	public static By Admin_Evolve_Ecom_MyCart=By.xpath(".//*[@id='pageLayout-body-inner-most']/div[2]/div/div/h1[text()='My Cart']");
	public static By Admin_Evolve_Ecom_BkTtl=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div/ul/li/div/div/a[text()='Regression Testing 1']");
	public static By Admin_Evolve_Ecom_MyCartTitle=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div/h1/following-sibling::ul/li[2]/div[3]/div[1]/a");
	public static By Admin_Evolve_Ecom_MyCartPrice=By.xpath(".//*[@id='pageLayout-body-inner-most']/div[2]/div/div/ul/li[2]/div[5]");

	//public static String isbn=PromotionRedeemSinglePercentageOff_10229.isbnForFutureUse3;
	public static String isbn1="9780323088640";
	//public static By Admin_Evolve_Ecom_isbn3title=By.xpath(".//*[@id='9780323088640']//div[contains(@class,'carttitle')]/a");

	public static By Admin_Evolve_Ecom_isbn3title=By.xpath(".//*[@id='9780323088640']/div[3]/div[1]/a");

	public static By Admin_Evolve_Ecom_PromotionCode=By.xpath(".//*[@id='couponCode-field']");
	public static By Admin_Evolve_Ecom_admintitle1=By.xpath(".//*[@id='packageItems']/tr[2]/td[3]");
	public static By Admin_Evolve_Ecom_admintitle2=By.xpath(".//*[@id='packageItems']/tr[3]/td[3]");
	public static String title1=readcolumns.twoColumns(3, 4, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("ISBNTextBox1");
	public static String title2=readcolumns.twoColumns(3, 4, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("ISBNTextBox2");

	public static By Admin_Evolve_Ecom_studenttitle1=By.xpath(".//*[@id='"+title1+"']/div[3]/div[1]/a");
	public static By Admin_Evolve_Ecom_studenttitle2=By.xpath(".//*[@id='"+title2+"']/div[3]/div[1]/a");

	public static By Admin_Evolve_Ecom_adminprice1=By.xpath(".//*[@id='packageItems']/tr[2]/td[3]/following-sibling::td[6]");
	public static By Admin_Evolve_Ecom_admindisc=By.xpath(".//*[@id='packageItems']/tr[2]/td[3]/following-sibling::td[5]");

	public static By Admin_Evolve_Ecom_studentprice1=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div/ul/li[2]/div[5]");

	public static By Admin_Evolve_Ecom_studentdisc=By.xpath(".//*[@id='pageLayout-body-inner-most']/div[2]/div/div/div[2]/table/tbody/tr[2]/td[2]");

	public static By Admin_Evolve_Ecom_adminprice2=By.xpath(".//*[@id='packageItems']/tr[3]/td[3]/following-sibling::td[6]");


	public static By Admin_Evolve_Ecom_framename=By.xpath(".//*[@id='cboxLoadedContent']/iframe");
	public static By Admin_Evolve_Ecom_framecontinue=By.xpath("html/body/div/form/p/button[text()='Enter Later']");
	public static By Admin_Evolve_Ecom_DMCodeinMarkPge=By.xpath(".//*[@id='marketingDmCode']");

	//public static By Admin_Evolve_Ecom_HeadSearch=By.xpath(".//*[@id='headerSearch']");
	//public static By Admin_Evolve_Ecom_HeadSearchGo=By.xpath(".//*[@id='headerSearchForm']/button");
	public static By Admin_Evolve_Ecom_HeadSearch=By.xpath(".//form[@action='/cs/search']/input[@type='text']");
	public static By Admin_Evolve_Ecom_HeadSearchGo=By.xpath(".//form[@action='/cs/search']/button");
	public static By Admin_Evolve_Ecom_HeadCDRom=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div/div/div/div/div/span/a[text()='CD-ROM']");
	public static By Admin_Evolve_Ecom_HeadCDRomclick=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[5]/div[2]/div[1]/div/div[2]/span/a[text()='CD-ROM']");
	public static By Admin_Evolve_Ecom_HeadCDRomprice=By.xpath(".//*[@id='tab-relayout']/div/div[5]/div[2]/p/span[1]");
	public static By Admin_Evolve_Ecom_HeadCDRomAddtoCart=By.xpath(".//*[@id='add-to-cart']");
	public static By Admin_Evolve_Ecom_HeadCDRomDiscPrice=By.xpath(".//*[@id='9781416029274']/div[3]/div[5]/span[2]");
	//public static String str1="9781416029274";
	//public static By Admin_Evolve_Ecom_HeadCDRomDiscPrice=By.xpath(".//*[@id='"+str1+"']/div[3]/div[5]");

	public static By Admin_Evolve_Ecom_TotalDiscount=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div/div[2]/table/tbody/tr[2]/td[2]");
	public static By Admin_Evolve_Ecom_SubTotal=By.xpath(".//*[@id='pageLayout-body-inner-most']//following-sibling::tr[2]/td[2]");
	public static By Admin_Evolve_Ecom_Total=By.xpath(".//*[@id='pageLayout-body-inner-most']//following-sibling::tr[3]/td[2]");
	//*[@id='checkoutButton']
	public static By Admin_Evolve_Ecom_TtlPriPkg1=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div/ul/li[2]/div[3]/div[3]/span[1]");
	public static By Admin_Evolve_Ecom_TtlPriPkg2=By.xpath(".//*[@id='9781416029274']/div[3]/div[5]/span[1]");
	public static By Admin_Evolve_Ecom_NewToEvolve=By.xpath(".//*[@id='pageLayout-body-inner-most']//h1[text()='New to Evolve? Create an account!']");

	public static By Admin_Evolve_Ecom_Confirmtitle1=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[1]/ul/li[2]/div[3]/div[1]/a");
	public static By Admin_Evolve_Ecom_Confirmtitle2=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[1]/ul/li[2]/div[7]/div/div[3]/div[1]/a");
	public static By Admin_Evolve_Ecom_Confirmtitle3=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[1]/ul/li[2]/div[8]/div/div[3]/div[1]/a");
	public static By Admin_Evolve_Ecom_OrdNo=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[2]/div[2]/div[1]/h4/following-sibling::div");   
	public static By Admin_Evolve_Ecom_Billing=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[2]/div[2]/div[2]/h4/following-sibling::*");  
	public static By Admin_Evolve_Ecom_Shipping=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[2]/div[2]/div[3]/h4/following-sibling::*");   
	public static By Admin_Evolve_Ecom_CreditCard=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[2]/div[2]/div[4]/h4/following-sibling::*");  
	public static By Admin_Evolve_Ecom_pricelist=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[1]/table/tbody/tr/td[2]");


	//have a account login into evolve

	//public static By Admin_Evolve_Ecom_EvoleStuUsername=By.xpath(".//*[@id='loginForm-username']");
	//public static By Admin_Evolve_Ecom_EvoleStuPassword=By.xpath(".//*[@id='loginForm-password']");
	//public static By Admin_Evolve_Ecom_EvoleStuSubmit=By.xpath(".//*[@id='signin_submit']");
	public static By Admin_Evolve_Ecom_EvoleStuUsername=By.xpath(".//input[@name='username']");
	public static By Admin_Evolve_Ecom_EvoleStuPassword=By.xpath(".//input[@name='password']");
	public static By Admin_Evolve_Ecom_EvoleStuSubmit=By.xpath(".//button[@class='login']");


	//*[@id='9781416029274']/div[5]



	//TC-8571 : Global Student.
	public static String ReplaceString1 = "@REPLACE_STRING1@";

	public static final String EDUCATOR = "educator";
	public static final String STUDENT = "student";

	//TC-9826
	public static By Admin_SearchAR_FirstName = By.xpath(".//*[@id='firstName']");
	public static By Admin_SearchAR_DaysBack = By.xpath(".//form[@id='mapping']/div[2]/div/span/div/span[2]/select");
	public static By Admin_ViewEdit_UserProfile = By.linkText("View/Edit Evolve User Profile");
	public static By Admin_SearchUser_FirstName = By.xpath(".//input[@name='firstname']");
	public static By Admin_SearchUser_UserName = By.xpath(".//input[@name='username']");
	public static By Admin_SearchUser_SearchButton = By.xpath(".//form[@name='searchForm']/table/tbody/tr[8]/td/input");
	//public static By NonAdmin_UserCredentials = By.xpath("html/body//div[contains(@class,'modal-div')]//p[2]");
	public static By NonAdmin_UserCredentials = By.xpath(".//div[@class='modal-div']/p[2]");
	public static By Admin_EditUserProfileUsingUserName = By.xpath(".//td[@title='"+ReplaceString1+"']");
	public static By Admin_EditUserProfileAngleSystemRole = By.xpath(".//select[@id='system_role_new']");


	//AdminMaintainProductsUpdateHistory(15465).....................................

	public static By maintainPdct_Bookfinder_lnk=By.xpath(".//*[@id='save_and_pub_product']/following-sibling::a/b[text()='Book Finder']");
	public static By maintainPdct_ModifiedInfo=By.xpath(".//*[@id='product-details']/div[1]/b/div[@class='modifiedbyuser']");
	public static By maintainPdct_History=By.xpath(".//*[@id='history_product']/b/u[text()='History']");
	public static By maintainPdct_StudentTab=By.xpath(".//*[@id='product-tabs']/ul/li[2]/a[text()='Student Production']");
	public static By studentTab_SaveAsWip=By.xpath(".//*[@id='student-production']//button[2][text()='SAVE AS WIP']");
	public static By studentTab_StudentWIP_Tab=By.xpath(".//*[@id='product-tabs']/ul/li[4]/a[text()='Student WIP']");
	public static By StudentWIPTab_TechSpecsShort_txt=By.xpath(".//*[@id='student-wip']//div[@class='commonelements']/p[1]/textarea[@name='technicalSpecsShort']");
	public static By StudentWIPTab_Save=By.xpath(".//*[@id='student-wip']/div[1]/button[2][text()='SAVE']");
	public static By history_PopUp_heading=By.xpath(".//*[@id='history_title']/strong");
	public static By history_PopUp_DateAndTime=By.xpath(".//*[@id='getCommentsPanel']/div/table/tbody/tr[1]/td[1]");
	//public static By history_PopUp_User=By.xpath(".//*[@id='getCommentsPanel']/div/table/tbody/tr[1]/td[1]");
	public static By history_PopUp_User=By.xpath(".//*[@id='getCommentsPanel']/div/table/tbody/tr[1]/td[2]");
	//public static By history_PopUp_Env=By.xpath(".//*[@id='getCommentsPanel']/div/table/tbody/tr[1]/td[1]");
	public static By history_PopUp_Env=By.xpath(".//*[@id='getCommentsPanel']/div/table/tbody/tr[1]/td[3]");
	//public static By history_PopUp_Notes=By.xpath(".//*[@id='getCommentsPanel']/div/table/tbody/tr[1]/td[1]");
	public static By history_PopUp_Notes=By.xpath(".//*[@id='getCommentsPanel']/div/table/tbody/tr[1]/td[4]");
	//public static By history_PopUp_close=By.xpath(".//*[@id='top_row']/td[3]/img");
	public static By history_PopUp_close=By.xpath("html/body/table/tbody/tr[2]/td/div/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[4]/td/div/div[3]/div[2]/table/tbody/tr[1]/td[3]/img");
	public static By studentWIP_history_close = By.xpath(".//div[@id='student-wip']//img[@class='closeCommentContainer']");
	/* ..........................CreateStudentUserfromSplashPageScript..............................*/


	public static By createNewAccnt_studentRadioBtn=By.xpath(".//*[@id='role-student']");
	public static By registration_form_error = By.xpath("(.//p[starts-with(@id, 'ext-gen')])[contains(@style, 'display: block')]");
	public static By createNewAccnt_EmptyField_Error=By.xpath(".//*[@id='ext-gen5']");
	public static By createNewAccnt_PwdEmpty_Error=By.xpath(".//*[@id='ext-gen5']");
	public static By createNewAccnt_SignUpMssg=By.xpath("html/body/div[1]/h1");
	public static By createNewAccnt_username=By.xpath("html/body/div[1]/p[2]/b[1]");
	public static By createNewAccnt_Pwd=By.xpath("html/body/div[1]/p[2]/b[2]");
	//html/body/div[1]/p[3]/a[text()='Continue']
	public static By frame_close=By.xpath(".//*[@id='cboxClose']");
	public static By dynamic_username=By.xpath("html/body/div/p[2]");
	public static By dynamic_pwd=By.xpath("html/body/div/p[2]/text()[2]");

	public static By  emailaddress     = By.id("emaillogin.Username");
	public static By  emailpassword    = By.id("emaillogin.Password");
	public static By  emaillogin       = By.id("save");
	public static By  emailsearch      = By.xpath(".//div[@id='ox-topbar-search']/div/input");
	public static By  emailinbox       = By.xpath(".//div/img[@title='E-Mail']");
	public static By  emailarrow       = By.xpath(".//div[@id='ox-topbar-search']/div/div");
	public static By  emailtobox       = By.xpath(".//div[@class='PopupMenuDiv font-size-small']/div/span[text()='To']/../input");
	public static By  emailsearchicon  = By.xpath("//div[@id='ox-topbar-search']/div/img[1]");
	public static By  emailbody        = By.xpath(".//html/head/body/div/div/div/div/div/iframe/html/body/div[1][contains(text(),'Dear')]");
	public static By  emailsubject     = By.xpath(".//div[@id='mail.hsplit.grid']/div/table[31]/tbody/tr/td[5]");
	public static By  emailwindow      = By.name("OX4");
	public static By  emailtestlink    = By.linkText("exact:http://evolve.elsevier.com");
	public static By emailVerify_firstName=By.xpath("html/body/div/text()[3]");

	/*..........................CreateStudentUserfromStudentPage..............................*/

	//public static By userLogin_btn=By.xpath(".//*[@id='signin_submit ']");
	public static By userLogin_btn=By.xpath(".//form[@action='/cs/login']//button");
	//public static By login_Remember_chk=By.xpath(".//*[@id='loginForm-remember']");
	public static By login_Remember_chk=By.xpath(".//*[@id='remember-me']");

	//public static By needHelpLogin_lnk=By.xpath(".//*[@id='signin']/a[1]");
	//public static By createAnAccount_lnk=By.xpath(".//*[@id='signin']/a[2]");
	public static By needHelpLogin_lnk=By.xpath(".//a[@class='need-help']");
	public static By createAnAccount_lnk=By.xpath(".//a[@class='create-account']");

	//TC- 15570
	public static By Student_BillingAdd_ModalDialogButtons = By.xpath(".//div[@class='modal-div ']/p/button[contains(text(),'"+ReplaceString1+"')]");
	public static By Student_BillingAdd_ModalDialog =By.xpath(".//iframe[@class='cboxIframe']");
	public static By Student_BillingAdd = By.xpath(".//*[@id='billing-address1']");	
	public static By Student_BillingAdd2 = By.xpath(".//*[@id='billing-address2']");
	public static By Student_BillingCity = By.xpath(".//*[@id='billing-city']");
	public static By Student_BillingState = By.xpath(".//select[@name='addresses.2.state']");
	public static By Student_Content_ResourcesFolder =By.xpath(".//*[@id='course-sidebar']/ul/li[4]/a");
	public static By Admin_CourseParReport_Link= By.linkText("Course PAR Report");

	public static By Admin_CourseParReport_SearchField =By.xpath(".//*[@id='courseid']");
	public static By Admin_CourseParReport_Search_Go =By.xpath(".//*[@id='go']");
	public static By Admin_CourseParReport_Search_Results = By.xpath(".//div[@id='usageReportContainer']/table/tbody/tr");

	//TC - 15583
	public static By Faculty_ContentPlus_CourseTools_Chkbx = By.xpath(".//*[@id='resourcestools']");
	public static By Faculty_ContentPlus_LMS_Chkbx = By.xpath(".//*[@id='yourlmsradio']");
	public static By Faculty_ContentPlus_CourseSection = By.xpath(".//select[@id='instanceCount']");
	public static By Faculty_ContentPlus_PCE = By.xpath(".//*[@id='projectedCourseEnrollment']");
	public static By Faculty_ContentPlus_Comment = By.xpath(".//*[@id='comment']");
	public static By Faculty_ContentPlus_CancelButton = By.xpath(".//*[@id='cancel-configure']");
	public static By Faculty_ContentPlus_ApplyButton = By.xpath(".//*[@id='config-form']/p[5]/button");

	public static By OrderProduct_Confirmation_ISBN = By.xpath(".//ul[@class='receipt']/li[2]/div[3]/div[4]");
	public static By OrderProduct_Confirmation_Price = By.xpath(".//ul[@class='receipt']/li[2]/div[3]/div[4]/following-sibling::*");
	public static By OrderProduct_Confirmation_OrderNumber_Label = By.xpath(".//div[@class='sidebar-list rounded']/div/h4[contains(text(),'Order Number')]");
	public static By OrderProduct_Confirmation_OrderNumber = By.xpath(".//div[@class='sidebar-list rounded']/div/h4/following-sibling::*");
	public static By OrderProduct_Confirmation_Title = By.xpath(".//div[@class='current'][contains(text(),'Confirmation')]");
	public static By Adoption_SearchResilts_Email = By.xpath(".//div[@id='email'][contains(text(),'"+ReplaceString1+"')]");
	public static By AdoptionRequestDetails_TABLE = By.xpath(".//form[@id='adoptionReqDetails']/table/tbody/tr[2]/td/table/tbody/tr/td[1]/table");			
	public static By AdoptionRequestDetails_RequestStatus = By.xpath(".//*[@id='status']");
	public static By AdoptionRequestDetails_SaveButton = By.xpath(".//*[@id='save']");
	public static By AdoptionRequestDetails_SendEmailButton = By.xpath(".//input[@id='sendemail']");
	public static By AdoptionRequestDetails_EditEmailButton = By.xpath(".//input[@id='editemail']");
	public static By AdoptionRequestDetails_CancelEmailButton = By.xpath(".//input[@id='cancelemail']");
	public static By AdoptionRequestDetails_EmailSelectionDialog_Title = By.xpath(".//form[@id='selectEmail']/div/h2");
	public static By AdoptionRequestDetails_CourseId = By.xpath(".//td[@class='courseTD']/input");



	public static By email_Icon=By.xpath(".//div[@class='ox-top-module-icons top-icon-mail']/img");
	public static By email_dropdown=By.xpath(".//*[@id='ox-topbar-search']/div/div/img");
	public static By email_dropdown_Fromchk=By.xpath(".//*[@id='body']//div[1]/input[@class='noborder']");
	public static By email_dropdown_Tochk=By.xpath(".//*[@id='body']//div[2]/input[@class='noborder']");
	public static By email_SearchBox=By.xpath(".//*[@id='ox-topbar-search']/div/input");
	public static By email_SearchIcon=By.xpath(".//*[@id='ox-topbar-search']/div/img[1]");



	public static By email_Body_Frame=By.id("mail.hsplit.detail.content");  
	//public static By email_body_text=By.xpath("html/body/div[@class='plainTextContent']");
	public static By email_body_text=By.xpath("html/body/div");
	public static By email_logout=By.xpath(".//*[@id='ox-topbar-logout']//div/div/div/div/div/div[@class='fakeButtonBottomRight']");
	public static By createNewAccnt_PwdMatch_Error=By.xpath(".//*[@class='validation-error validate-field'][text()='Your passwords must match.']");

	//*[@id='history_title']/strong[text()='Faculty History']




	/*........................SchoolHostedFulfillmentAngel6x..................................*/

	//	public static By id='cboxLoadedContent'
	//public static By adoptionRequest=By.xpath("//table[@id='resultTable']/tbody/tr/td");

	//table[@id='resultTable']/tbody/tr/td
	public static By adoptionRequestTitile=By.xpath(".//*[@id='adoptionReqDetails']//table/tbody/tr[1]/td[1]/table/tbody/tr[1]/td/div[2]");
	public static By adoptionRequestproductType=By.xpath(".//*[@id='adoptionReqDetails']/table/tbody/tr[2]/td/table/tbody/tr[1]/td[1]/table/tbody/tr[2]/td[2]");
	public static By adoptionRequestproductFormat=By.xpath(".//*[@id='formatContainer']");
	public static By adoptionRequestproductIsbn=By.xpath(".//*[@id='adoptionReqDetails']/table/tbody/tr[2]/td/table/tbody/tr[1]/td[1]/table/tbody/tr[1]/td/div[6]");
	public static By adoptionRequestAuthor=By.xpath(".//*[@id='adoptionReqDetails']/table/tbody/tr[2]/td/table/tbody/tr[1]/td[1]/table/tbody/tr[1]/td/div[4]");

	//...............................ReView and Submit Scripts( 15568,15569,9835,9838 ).......................

	//public static By clickOnCart = By.xpath(".//*[@id='page']/div[1]/div//a[@class='cart nav-text relative']");
	public static By clickOnCart = By.xpath(".//a[@href='/cs/viewCart']");
	public static By paperbackPrice = By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[5]/div[2]/div[1]/div/div[1]/div[@class='price bold']");
	public static By paperbackPrice2 = By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[5]/div[2]/div[2]/div/div[1]/div[@class='price bold']");
	public static By paperback_click = By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[5]/div[2]/div[1]/div/div[2]/span/a[text()='Paperback']");
	public static By paperback_click2 = By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[5]/div[2]/div[2]/div/div[2]/span/a[text()='Paperback']");
	public static By cancleOrder = By.xpath(".//*[@id='pageLayout-body-inner-most']//div[@class='intnote row']/span[1]/a[@class='cancellink']");
	public static By reviewAndSubmit = By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class,'current')][text()='2. Review & Submit']");
	//public static By itemInCart = By.xpath(".//*[@id='page']/div[1]/div//div[@class=' pull-right nav-cart']/a/span[@class='badge-cart box_shadow']");
	public static By itemInCart = By.xpath(".//div[@class='carttitle']");
	public static By  iamstudent     = By.xpath("//div[2]/div[1]/a");
	public static By catalogPage=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/p");
	public static By homepage_welcome_message = By.xpath(".//div[@class='main-top']//h1");
	public static By itemTitle=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class,'carttitle')]/a");
	public static By edit_BillingAddress = By.xpath(".//*[@id='old-billing']/div[4]/a[text()='Edit']");
	public static By edit_ShippingAddress = By.xpath(".//*[@id='old-shipping']/div[4]/a[text()='Edit']");
	public static By statesShipping=By.xpath(".//*[@id='shipping-state']");
	public static By statesBilling=By.xpath(".//*[@id='billing-state']");
	public static By useThisAddressFrame=By.xpath(".//*[@id='cboxLoadedContent']//iframe[@class='cboxIframe']");
	public static By useThisAddressButton=By.xpath("html/body/div[3]/table/tbody/tr/td[1]/div/button");
	//public static By useThisAddressEducator=By.xpath("html/body/div[3]/p[3]/button[1]");
	public static By useThisAddressEducator=By.xpath(".//button[text()='Use This Address']");
	public static By creditPrev=By.xpath(".//*[@id='old-cc']/div[2]");
	public static By billingPrev=By.xpath(".//*[@id='old-billing']/div[1]");
	public static By shippingPrev=By.xpath(".//*[@id='old-shipping']/div[1]");
	public static By edit_CreditCard = By.xpath(".//*[@id='old-cc']/div[4]/a[text()='Edit']");
	public static By edit_salesRepCode = By.xpath(".//*[@id='salesrep']");
	public static By us_OrdersOnly = By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div//strong[text()='U.S. orders only.']");
	public static By internationalOrder = By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div//span/a[text()='www.elsevier.com']");
	//public static By itemISBN=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class,'cartproductdetails')]");
	public static By estimatedtax = By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[5]/div[1]/div[3]/table/tbody/tr[3]/td[2]");
	public static By getPriceList = By.xpath(".//*/div[@class='price span2'][contains(text(),'$')]");
	public static By noCartItems=By.xpath(".//*[@id='noCartMessage']");

	public static By itemISBN=By.xpath("html/body/div[4]/div[3]/div/div/div/div/div[5]/div[1]/ul/li[2]/div[3]/div[4]");


	//public static By reviewAndSubmit = By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[text()='2. Review & Submit']");
	//public static By itemInCart = By.xpath(".//*[@id='page']/div[1]/div//div[@class=' pull-right nav-cart']/a/span[@class='badge-cart box_shadow']");
	//public static By  iamstudent     = By.xpath("//div[2]/div[1]/a");

	public static By isbnProduct = By.xpath(".//*[@id='pageLayout-body-inner-most']/div//span[@itemprop='isbn']");
	public static By deleteProduct = By.xpath(".//*[@id='9780323086547']//a[text()='Delete']");

	public static String deleteProduct1 = ".//*[@id='";
	public static String deleteProduct2 = "']//a[text()='Delete']";

	public static By creditCard_save = By.xpath(".//*[@id='cc-form']/input[@value='Save']");
	public static By creditCard_cancel = By.xpath(".//*[@id='cc-form']/a[text()='Cancel']");
	public static By billingAddress2 = By.xpath(".//*[@id='billing-address2']");
	public static By selectState = By.xpath(".//*[@id='billing-state']");
	public static By billingAddressSave = By.xpath(".//*[@id='billing-submit']");
	public static By billingAddressCancel = By.xpath(".//*[@id='billing-form']/a[text()='Cancel']");

	public static By shippingAddressAttention = By.xpath(".//*[@id='shipping-attentionName']");
	public static By selectShippingState = By.xpath(".//*[@id='shipping-state']");
	public static By shippingAddressSave = By.xpath(".//*[@id='shipping-submit']");
	public static By shippingAddressCancel = By.xpath(".//*[@id='shipping-form']/a[text()='Cancel']");

	public static By order_Conform = By.xpath(".//*[@id='mail.hsplit.detail.header.subject']");
	public static By evolveEmailWeb = By.xpath(".//*[@id='mail.hsplit.detail.header.to']");
	public static By evolve_login = By.xpath(".//*[@id='tabs-disabled']/ul//a/div[text()='E-mail Login']");

	//.//*[@id='cc-form']/a[text()='Cancel']


	//Test ID (10226) - Promotion - Single Percentage - Inclusions
	public static By GlobalPromotionLink_ISBNTextBox=By.xpath(".//*[@id='glbisbn']");
	public static By GlobalPromotionLink_ISBNBtn=By.xpath(".//*[@id='glbisbnexclude']");
	public static By GlobalPromotionLink_ISBNSucMsg=By.xpath(".//*[@id='msg-glb-save-success']");
	public static By GlobalPromotionLink_ISBNTable=By.xpath(".//*[@id='table-container-isbn-glb']/table/tbody/tr");
	//	public static By Evolve_Admin_Prmlnk=By.linkText("Add Promotion");
	public static By Evolve_Admin_Prmlnk_BreadCrumbVrfy=By.xpath("//*[@id='pageBody']//table[contains(@class,'drkhighlight')]");
	public static By Evolve_Admin_Prmlnk_VrfyPromCode=By.xpath(".//*[@id='pageBody']//b[text()='Promotion Type']");
	public static By Evolve_Admin_Prmlnk_PrmotionCode=By.id("promotioncode");
	public static By Evolve_Admin_Prmlnk_DscSel=By.xpath(".//*[@id='discounttypeselect']");
	public static By Evolve_Admin_Prmlnk_CampaignCode=By.xpath(".//*[@id='campaigncode']");
	public static By Evolve_Admin_Prmlnk_PrmName=By.xpath(".//*[@id='promotionname']");
	public static By Evolve_Admin_Prmlnk_TerritoryCode=By.xpath(".//*[@id='territorycode']");
	public static By Evolve_Admin_Prmlnk_ClkCalender=By.xpath(".//*[@id='couponheaderdetailsdiv']/table/tbody/tr[2]/td[2]/a/img");
	public static By Evolve_Admin_Prmlnk_StartDate=By.xpath(".//*[@id='startdate']");
	public static By Evolve_Admin_Prmlnk_EndDate=By.xpath(".//*[@id='enddate']");
	public static By Evolve_Admin_Prmlnk_Percentage=By.xpath(".//*[@id='percentageoff']");
	public static By Evolve_Admin_Prmlnk_SaveBtn=By.xpath(".//*[@id='save']");
	public static By Evolve_Admin_Prmlnk_CancelBtn=By.xpath(".//*[@id='cancel']");
	public static By Evolve_Admin_Prmlnk_CloneBtn=By.xpath(".//*[@id='clone']");


	public static By xpathProfitcenter=By.xpath(".//*[@id='piprofitcenterselect']/option");
	public static By xpathMajorSubjectCode=By.xpath(".//*[@id='pimscselect']/option");
	public static By xpathProductType=By.xpath(".//*[@id='piproducttypeselect']/option");

	public static By Evolve_Admin_Prmlnk_SucMsg=By.xpath(".//*[@id='msg-save-success'][text()='Promotion successfully saved. ']");
	public static By Evolve_Admin_Prmlnk_IncludeChk=By.xpath(".//*[@id='piradio1']");
	public static By Evolve_Admin_Prmlnk_SucMsgInclude=By.xpath(".//*[@id='msg-pi-save-success'][text()='All products have been included successfully. ']");
	public static By Evolve_Admin_Prmlnk_AddIncludeBtn=By.xpath(".//*[@id='pipcaddbtn']");
	public static By Evolve_Admin_Prmlnk_SelcallRdiobtn=By.xpath(".//*[@id='piradio2']");
	public static By Evolve_Admin_Prmlnk_PrtCetr=By.xpath(".//*[@id='piprofitcenterselect']");
	public static By Evolve_Admin_Prmlnk_PrtCetrSelOption=By.xpath(".//*[@id='piprofitcenterselect']");

	public static By Evolve_Admin_Prmlnk_PerFld=By.xpath(".//*[@id='pipcpercentageoff']");
	public static By Evolve_Admin_Prmlnk_PrtCetrFailMsg=By.xpath(".//*[@id='msg-pi-save-failure'][text()='Please select product group to add to the promotion.']");
	public static By Evolve_Admin_Prmlnk_SelcOption1=By.xpath(".//*[@id='piprofitcenterselect']/option[1]");
	public static By Evolve_Admin_Prmlnk_SelcOption2=By.xpath(".//*[@id='piprofitcenterselect']/option[2]");
	public static By Evolve_Admin_Prmlnk_IncSucMsg=By.xpath(".//*[@id='msg-pi-save-success'][text()='The Promotion Inclusion is successfully saved. ']");
	public static By Evolve_Admin_Prmlnk_IncAdded=By.xpath(".//*[@id='table-container-pc-pi']/table");
	public static By Evolve_Admin_Prmlnk_IncAddedTable=By.xpath(".//*[@id='table-container-pc-pi']/table");

	public static By Evolve_Admin_Prmlnk_SelcOptionFinal=By.xpath(".//*[@id='piprofitcenterselect']/option");

	public static By xpathprofitCenterVariablePerc=By.xpath("");

	public static By Evolve_Admin_Prmlnk_IncRemLnk=By.xpath(".//*[@id='table-container-pc-pi']//a[text()='remove']");
	public static By Evolve_Admin_Prmlnk_PercValue=By.xpath(".//*[@id='table-container-pc-pi']/table/tbody/tr[1]");
	public static By Evolve_Admin_Prmlnk_RemvLink=By.xpath(".//*[@id='table-container-pc-pi']//a[text()='remove']");
	public static String remove1= "//*[@id='table-container-pc-pi']/table/tbody/tr[";
	public static String remove2 ="]";

	public static String remove11= ".//*[@id='table-container-isbn-pe']/table/tbody/tr[";
	public static String remove12 ="]";


	public static By Evolve_Admin_Prmlnk_ViewAllLnk=By.xpath(".//*[@id='hlink-container-pc-pi']/a[text()='View All Profit Centers...']");


	/*ElsevierObjects.Evolve_Admin_Prmlnk_PrtCetr ==== combo box 

					ElsevierObjects.Evolve_Admin_Prmlnk_AddIncludeBtn ==== add button

					ElsevierObjects.Evolve_Admin_Prmlnk_PerFld  ========= percentage field

					ElsevierObjects.Evolve_Admin_Prmlnk_PrtCetrFailMsg   ========= failed alert msg

					ElsevierObjects.Evolve_Admin_Prmlnk_SelcOption1   ========== selectoption 1

					ElsevierObjects.Evolve_Admin_Prmlnk_IncSucMsg   =====scs msg

					ElsevierObjects.Evolve_Admin_Prmlnk_IncAdded  ========= bckgrd color

					ElsevierObjects.Evolve_Admin_Prmlnk_RemvLink  =========== remove link

					ElsevierObjects.Evolve_Admin_Prmlnk_SelcOption2

					ElsevierObjects.Evolve_Admin_Prmlnk_EndDate    ======== anytext box

					ElsevierObjects.Evolve_Admin_Prmlnk_PercValue    ====== row percentage and value

					ElsevierObjects.Evolve_Admin_Prmlnk_SelcOptionFinal  ====final select option*/

	//  Major Subject Code Section

	public static By Evolve_Admin_Prmlnk_MjrCombo=By.xpath(".//*[@id='pimscselect']");
	public static By Evolve_Admin_Prmlnk_MjrAdd=By.xpath(".//*[@id='pimscaddbtn']");
	public static By Evolve_Admin_Prmlnk_MjrPerFld=By.xpath(".//*[@id='pimscercentageoff']");
	//ElsevierObjects.Evolve_Admin_Prmlnk_PrtCetrFailMsg   ========= failed alert msg
	public static By Evolve_Admin_Prmlnk_MjrOption1=By.xpath(".//*[@id='pimscselect']/option[1]");
	public static By Evolve_Admin_Prmlnk_MjrOption2=By.xpath(".//*[@id='pimscselect']/option[2]");
	//ElsevierObjects.Evolve_Admin_Prmlnk_IncSucMsg   =====scs msg
	public static By Evolve_Admin_Prmlnk_MjrBckGrnd=By.xpath(".//*[@id='table-container-msc-pi']/table"); 
	public static By Evolve_Admin_Prmlnk_MjrRemLnk=By.xpath(".//*[@id='table-container-msc-pi']//a[text()='remove']");
	//ElsevierObjects.Evolve_Admin_Prmlnk_EndDate    ======== anytext box
	public static By Evolve_Admin_Prmlnk_MjrPercValue=By.xpath(".//*[@id='table-container-msc-pi']/table/tbody/tr[1]");
	public static By Evolve_Admin_Prmlnk_MjrSelFinal=By.xpath(".//*[@id='pimscselect']/option");
	public static By Evolve_Admin_Prmlnk_MjrViewAll=By.xpath(".//*[@id='hlink-container-msc-pi']/a[text()='View All Major Subject Codes...']");
	//Product Type Section

	public static By Evolve_Admin_Prmlnk_PrdCombo=By.xpath(".//*[@id='piproducttypeselect']");
	public static By Evolve_Admin_Prmlnk_PrdAdd=By.xpath(".//*[@id='piptaddbtn']");
	public static By Evolve_Admin_Prmlnk_PrdPerFld=By.xpath(".//*[@id='piptpercentageoff']");
	//ElsevierObjects.Evolve_Admin_Prmlnk_PrtCetrFailMsg  ========= failed alert msg
	public static By Evolve_Admin_Prmlnk_PrdOption1=By.xpath(".//*[@id='piproducttypeselect']/option[1]");
	public static By Evolve_Admin_Prmlnk_PrdOption2=By.xpath(".//*[@id='piproducttypeselect']/option[2]");
	//ElsevierObjects.Evolve_Admin_Prmlnk_IncSucMsg   =====scs msg
	public static By Evolve_Admin_Prmlnk_PrdBckGrnd=By.xpath(".//*[@id='table-container-pt-pi']/table");
	public static By Evolve_Admin_Prmlnk_PrdRemLnk=By.xpath(".//*[@id='table-container-pt-pi']//a[text()='remove']");
	//ElsevierObjects.Evolve_Admin_Prmlnk_EndDate    ======== anytext box
	public static By Evolve_Admin_Prmlnk_PrdPercValue=By.xpath(".//*[@id='table-container-pt-pi']/table/tbody/tr[1]");
	public static By Evolve_Admin_Prmlnk_PrdSelFinal=By.xpath(".//*[@id='piproducttypeselect']/option");
	public static By Evolve_Admin_Prmlnk_PrdViewAll=By.xpath(".//*[@id='hlink-container-pt-pi']/a[text()='View All Product Types...']");
	//isbn section
	public static By Evolve_Admin_Prmlnk_ISBNtxt=By.xpath(".//*[@id='piisbn']");
	public static By Evolve_Admin_Prmlnk_ISBNpercent=By.xpath(".//*[@id='piisbnpercentageoff']");
	public static By Evolve_Admin_Prmlnk_ISBNAdd=By.xpath(".//*[@id='piisbnaddbtn']");
	public static By Evolve_Admin_Prmlnk_ISBNErrMsg=By.xpath(".//*[@id='msg-pi-save-failure'][text()='The ISBN does not exist. Please enter new ISBN.']");
	//Evolve_Admin_Prmlnk_IncAdded
	public static By Evolve_Admin_Prmlnk_ISBNAddList=By.xpath(".//*[@id='table-container-isbn-pi']/table/tbody/tr[1]");
	public static By Evolve_Admin_Prmlnk_ISBNRem=By.xpath(".//*[@id='table-container-isbn-pi']//td[2]/preceding-sibling::td[1]/a");
	public static By Evolve_Admin_Prmlnk_ISBNViewAll=By.xpath(".//*[@id='hlink-container-pckisbn-pi']/a[text()='View All ISBNs...']");


	//upload csv file
	public static By Evolve_Admin_Prmlnk_ISBNBrowse=By.xpath(".//*[@id='pifilename']");
	public static By Evolve_Admin_Prmlnk_ISBNUplPercent=By.xpath(".//*[@id='piisbnuploadpercentageoff']");
	public static By Evolve_Admin_Prmlnk_ISBNUplBtn=By.xpath(".//*[@id='piisbnuploadbtn']");
	public static By Evolve_Admin_Prmlnk_ISBNUplViewall=By.xpath(".//*[@id='hlink-container-isbn-pi']/a");
	public static By Evolve_Admin_Prmlnk_ISBNUplSucMsg=By.xpath(".//*[@id='msg-pi-save-success'][text()='The file is uploaded successfully. ']");
	public static By Evolve_Admin_Prmlnk_ISBNUplRemlnk=By.xpath(".//*[@id='table-container-isbn-pi']//a[text()='remove']");

	//*[@id='table-container-pc-pe']/table/tbody/tr[1]
	public static By Evolve_Admin_Prmlnk_ISBNUplList=By.xpath(".//*[@id='couponViewAllResults']/table/tbody/tr");
	public static By Evolve_Admin_Prmlnk_ISBNUplafter=By.xpath(".//*[@id='couponViewAllResults']/table/tbody/tr[1]/td[2]/span");
	public static By Evolve_Admin_Prmlnk_ISBNUplbefore=By.xpath(".//*[@id='table-container-isbn-pi']/table/tbody/tr");
	public static By Evolve_Admin_Prmlnk_DscAllOthr=By.xpath(".//*[@id='piallpercentageoff']");
	public static By Evolve_Admin_Prmlnk_DscAdd=By.xpath(".//*[@id='pialladdbtn']");
	public static By Evolve_Admin_Prmlnk_DscAddSucMsg=By.xpath(".//*[@id='msg-pi-save-success'][text()='All products have been included successfully. ']");
	public static By Evolve_Admin_Prmlnk_DscAddRemLnk=By.xpath(".//*[@id='table-container-addall-pi']//a");
	public static By Evolve_Admin_Prmlnk_DscAddRow=By.xpath(".//*[@id='table-container-addall-pi']/table/tbody/tr");


	//Test ID (15571) - Z - Find protection scheme for self study course

	//public static By Ecert_Admin_MyAcc=By.xpath(".//*[@id='account-menu']/span[text()='My Account']");
	public static By Ecert_Admin_MyAcc=By.xpath(".//li[@class='account-icon pull-right']/a");
	//public static By Ecert_Admin_PortalLink=By.xpath(".//*[@id='account-menu']/ul/li/a[text()='Administration Portal']");
	public static By Ecert_Admin_PortalLink=By.xpath(".//a[text()='ADMINISTRATION PORTAL']");
	public static By Ecert_Admin_coursesLink=By.xpath(".//*[@id='adminSite']//a[text()='Courses']");
	public static By Ecert_Admin_GlobalLink=By.xpath(".//*[@id='adminSite']//a[text()='Global Resources']");
	public static By Ecert_Admin_Filter=By.xpath(".//*[@id='input-search']");
	public static By Ecert_Admin_Tableheader=By.xpath(".//*[@id='groupTable_wrapper']//tr");
	public static By Ecert_Admin_TableRow=By.xpath(".//*[@id='groupTable']/tbody/tr");
	public static By Ecert_Admin_TableContent=By.xpath(".//*[@id='groupTable']/tbody/tr/td[1]");
	public static By Ecert_Admin_ContentHome=By.xpath(".//*[@id='course-sidebar']//a[text()='Content Home']");
	public static By Ecert_Admin_Edit=By.xpath(".//*[@id='44460206']/div[3]/a");
	public static By Ecert_Admin_EditAbout=By.xpath(".//*[@id='44460206']//ul/li/a/span[text()='About']");
	public static By Ecert_Admin_ProtectionSchemeID =By.xpath("html/body/div/div[contains(@class,'modal-body')]//dl/dd[contains(@data-ng-show,'aboutingContent.protectionScheme')]");
	//public static By Admin_Evolve_Ecom_EvoleSign=By.xpath(".//*[@id='signin']/input");
	public static By Admin_Evolve_Ecom_EvoleSign=By.xpath(".//form[@action='/cs/login']//button");

	public static By aboutLinkPage=By.xpath("html/body//div[contains(@class,'modal-header')]/h3");
	public static By displayCount=By.xpath(".//*[@id='groupTable_info']");

	public static By AdminPortal=By.xpath(".//*[@id='stdHeader']/h1[text()='Administration Portal']");
	public static By AdminPortalMsg=By.xpath(".//*[@id='stdHeader']/h1");
	/*........................SchoolHostedFulfillmentAngel6x..................................*/

	//	public static By id='cboxLoadedContent'
	public static By popUp_Radio_Btn=By.id("yourlmsradio");
	public static By popUp_dropdown=By.id("yourlms");
	public static By popUp_dropdwn_value=By.xpath(".//*[@id='yourlms']/option[text()='Angel (6.x and higher)']");
	public static By popUp_Apply=By.xpath(".//*[@id='config-form']/p[@class='float_right']/button");
	//public static By lmsTitle=By.xpath("html/body/div[4]/div[3]/div/div/div/div/div/ul/li[2]/div[3]/span");
	public static By lmsTitle=By.xpath(".//div[@class='cartprodtype']//a");
	//public static By lmsTitleInReceiptPage= By.xpath("html/body/div[4]/div[3]/div/div/div/div/div[2]/div[1]/ul/li[2]/div[3]/span");
	public static By lmsTitleInReceiptPage= By.xpath(".//*[@class='configdetails']");
	public static By ProductType= By.xpath(".//*[@id='pageLayout-body-inner-most']//span/a[@class='productTypeLink']");
	//public static By adoptionRequest=By.xpath("html/body/table/tbody/tr[2]/td/div/table[1]/tbody/tr[2]/td/table/tbody/tr[6]/td/table/tbody/tr[1]/td[1]");
	public static By adoptionRequest=By.xpath(".//table[@id='resultTable']//td[@headers='AR']");

	//public static By adoptionRequest=By.xpath("//table[@id='resultTable']/tbody/tr/td");

	//table[@id='resultTable']/tbody/tr/td
	/*public static By adoptionRequestTitile=By.xpath("//*[@id='adoptionReqDetails']//table/tbody/tr[1]/td[1]/table/tbody/tr[1]/td/div[2]");
				public static By adoptionRequestproductType=By.xpath("//*[@id='adoptionReqDetails']/table/tbody/tr[2]/td/table/tbody/tr[1]/td[1]/table/tbody/tr[2]/td[2]");
				public static By adoptionRequestproductFormat=By.xpath("//*[@id='formatContainer']");
				public static By adoptionRequestproductIsbn=By.xpath("//*[@id='adoptionReqDetails']/table/tbody/tr[2]/td/table/tbody/tr[1]/td[1]/table/tbody/tr[1]/td/div[6]");
				public static By adoptionRequestAuthor=By.xpath(".//*[@id='adoptionReqDetails']/table/tbody/tr[2]/td/table/tbody/tr[1]/td[1]/table/tbody/tr[1]/td/div[4]");*/
	public static By adoptionRequestStatus=By.id("status");			
	public static By adoptionRequestafterSave=By.xpath("html/body/table[2]/tbody/tr[2]/td/div/table[1]/tbody/tr[3]/td/form/table/tbody/tr[2]/td/table/tbody/tr[1]/td[2]/table/tbody/tr[9]/td[2]/div[2]/div/select/option[3]");
	//public static By myAccount=By.xpath(".//*[@id='account-menu']/span[text()='My Account']");
	//public static By myAccount_AccountSettings=By.xpath(".//*[@id='account-menu']/ul/li/a[text()='Account Settings']");
	public static By myAccount=By.xpath(".//li[@class='account-icon pull-right']/a");
	public static By myAccount_AccountSettings=By.xpath(".//a[text()='ACCOUNT SETTINGS']");
	public static By Course_Author=By.xpath("//*[@class='descwide span16']/div[@class='cartauthor']");			

	public static By adoptionRequest_DownloadURL=By.xpath(".//*[@id='downloadurl1']");
	public static By adoptionRequest_Save=By.id("save");

	//public static By facultyPopup_close=By.xpath("html/body/table/tbody/tr[2]/td/div/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[4]/td/div/div[4]/div[2]/table/tbody/tr[1]/td[3]/img");
	public static By facultyPopup_close=By.xpath(".//div[@id='faculty-wip']//img[@class='closeCommentContainer']");
	public static By studentTab_SaveAsWip_History=By.xpath(".//*[@id='student-wip']/div/div[2]/div/b");
	public static By facultyTab=By.xpath(".//*[@id='product-tabs']/ul/li[3]/a[text()='Faculty Production']");
	public static By facultyTab_SaveAsWip=By.xpath(".//*[@id='faculty-production']/div[1]/button[text()='SAVE AS WIP']");
	public static By facultyTab_facultyWIP_Tab=By.xpath(".//*[@id='product-tabs']/ul/li[5]/a[text()='Faculty WIP']");
	public static By facultyWIPTab_TechSpecsShort_txt=By.xpath(".//*[@id='faculty-wip']/div[@class='commonelements']/p[1]/textarea");
	public static By facultyWIPTab_Save=By.xpath(".//*[@id='faculty-wip']/div[1]/button[text()='SAVE']");
	public static By facultyWIPTab_SaveAsWip_History=By.xpath(".//*[@id='faculty-wip']/div/div[2]/div/b");
	public static By emailPopup=By.id("sendemail");
	//public static By verifyEmailDownloadURL=By.xpath(".//div[@class='plainTextContent']/a[1]");
	//public static By verifyEmailDownloadURL=By.xpath("/html/body//a[1]");
	public static By verifyEmailDownloadURL = By.xpath("(/html/body//a[contains(@href,'coursewareobjects.elsevier')])[last()]");
	public static By adoptionRequestChkBx=By.xpath(".//*[@id='fulfillcheckbox']");
	public static By adoptionRequestDownloadKey=By.xpath(".//*[@id='downloadKey']");
	public static By adoptionRequestGetComment=By.xpath(".//*[@id='comments']");
	public static By adoptionRequestGetcoursecontent=By.xpath(".//*[@id='courseCount']");




	/*6/09/2014.........................*/

	//public static By popUp_EvolveText=By.xpath(".//*[@id='config-form']//div[@class='pad5 evolve-choice']/label");
	public static By popUp_EvolveText=By.xpath(".//div[@class='modal-div ']/div/h2");
	public static By adoptionRequestCourseId1=By.xpath(".//*[@id='courceId1']");
	public static By adoptionRequestCourseId2=By.xpath(".//*[@id='courceId2']");
	//TC - 15584
	public static By EmailSubject = By.xpath(".//div[@id='mail.hsplit.detail.header.subject']");
	public static By FacultyContentLink = By.xpath(".//*[@id='set']/li/div/div/span[contains(text(),'"+ReplaceString1+"')]/following-sibling::a");



	//...................................LO_Unique_CourseFulfillment_Faculty..............................

	public static String courseid1=ReadingExcel.columnDataByHeaderName("courseid1", "TC-10410", configProps.getProperty("TestData"));
	public static String courseid2=ReadingExcel.columnDataByHeaderName("courseid2", "TC-10410", configProps.getProperty("TestData"));

	//*[@id='set']/li/div/div/span[text()='COURSE ID: 104882_einstein_1035']
	public static By educator_courseSearch_ID1=By.xpath(".//*[@id='set']/li/div/div/span[text()='COURSE ID: "+courseid1+"']");
	public static By educator_courseSearch_ID2=By.xpath(".//*[@id='set']/li/div/div/span[text()='COURSE ID: "+courseid2+"']");
	public static By educator_courseSearch_title=By.xpath(".//*[@id='set']/li/div/div/span[text()='COURSE ID: "+courseid1+"']/following-sibling::a");
	//public static By educator_CoursePage_Courselink=By.xpath(".//*[@id='course-sidebar']//li[1]/a/span[@class='ng-binding']");
	public static By educator_Course_Resource = By.xpath(".//*[@id='course-sidebar']//li[1]/a/span[@class='ng-binding']");
	public static By educator_CoursePage_Courselink=By.xpath(".//div[@id='course-sidebar']//span[text()='Course']");
	public static By courseLink_selfstudy=By.xpath(".//div[@id='course-sidebar']//span[text()='Course']");
	public static By selfstudy_courselink = By.xpath(".//div[@id='course-sidebar']//span[text()='Course (Self-Study)']");
	//public static By educator_CoursePage_LockIcon=By.xpath(".//*[@id='course-sidebar']//li[1]/a/span/i[@class='icon-lock']");
	//public static By educator_CoursePage_LockIcon=By.xpath("(.//span[@class='premium-content pull-left']/i)[2]");
	//public static By educator_CoursePage_LockIcon=By.xpath("(.//*[@id='course-sidebar']//i[@class='icon-lock'])[1]");
	public static By educator_CoursePage_LockIcon=By.xpath(".//div[@id='course-sidebar']//span[text()='Course']/preceding-sibling::span/i[@class='icon-lock']");
	public static By educator_CoursePage_SubFolders=By.xpath(".//*[@class='courseContentRow well clearfix ng-scope']/div[@class='content-info span20']");
	public static By educator_CoursePage_CourseContentLink=By.xpath(".//*[@id='course-sidebar']/ul[@class='nav nav-list']//a[text()='Content Home']");
	public static By educator_CoursePage_CourseLink=By.xpath(".//*[@id='course-sidebar']//li[contains(@class,'ng-scope')]/a/span[text()='Course']");
	//*[@class='courseContentRow well clearfix ng-scope']/div[3]/a[@class='btn']

	//   public static By educator_CoursePage_EditLink=By.xpath("html/body/div[3]/div[3]/div/div/div[2]/div[2]/div[3]/div/div/div[3]/div[3]/ul/li[1]/div[3]/a");
	//public static By educator_CoursePage_EditLink=By.xpath(" //div[3]/ul/li[1]//a/b[@class='caret']");
	//public static By educator_CoursePage_EditLink_About=By.xpath("//div[3]/ul/li[1]//div/ul/li/a/span[text()='About']");
	//public static By educator_CoursePage_EditLink=By.xpath(".//div[@class='edit-content-dropdown dropdown pull-right']/a");
	//public static By educator_CoursePage_EditLink=By.xpath("(.//div[@class='edit-content-dropdown dropdown pull-right']/a)[2]");
	public static By educator_CoursePage_EditLink=By.xpath("(.//div[@class='edit-content-dropdown dropdown pull-right']/a)[last()]");
	//public static By educator_CoursePage_EditLink_About=By.xpath(".//a[@ng-click='aboutContent(content)']/span");
	//public static By educator_CoursePage_EditLink_About=By.xpath("(.//a[@ng-click='aboutContent(content)']/span)[2]");
	public static By educator_CoursePage_EditLink_About=By.xpath("(.//a[@ng-click='aboutContent(content)']/span)[last()]");
	public static By educator_CoursePage_ProtectionSchemeText=By.xpath("//div[@class='modal-body']/dl/dd[4]");
	public static By studentcontenthome=By.xpath(".//*[@id='course-sidebar']/ul//a[contains(text(),'Content Home')]");




	//Test ID (15582) - Promotion - Create Promotion & Marketing Page - Single Percentage

	public static By marketingPageSinglePercentage_DvdType=By.xpath(".//*[@id='type-dvd']");
	public static By marketingPageSinglePercentage_HardcoverType=By.xpath(".//*[@id='type-hardcover']");
	public static By marketingPageSinglePercentage_DvdSearch=By.xpath("//*[@id='pageLayout-body-inner-most']//div[contains(@class, 'item row')]//div[contains(@class, 'cartprodtype student')]//span//a[text()='DVD']");
	public static By marketingPageSinglePercentage_Title=By.xpath(".//*[@id='tab-relayout']/div/div/h1");
	//public static By marketingPageSinglePercentage_ISBN=By.xpath(".//*[@id='pageLayout-body-inner-most']//ul[contains(@class, 'product-copyright')]/li/span[contains(@class,'bold')][text()='ISBN:']//following-sibling::*");
	//public static By marketingPageSinglePercentage_ISBN=By.xpath(".//*[@itemprop='isbn']");
	public static By marketingPageSinglePercentage_ISBN=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div[1]/ul[1]/li[1]/span[2]");
	public static By marketingPageSinglePercentage_Price=By.xpath(".//*[@id='tab-relayout']//div[contains(@class, 'cost')]//span[contains(@class, 'price')]");

	//public static By marketingPageSinglePercentage_PrmPgeGlobalLink=By.linkText("Global Promotion Exclusions");
	//public static By marketingPageSinglePercentage_PrmPgeGlobalLink=By.xpath(".//*[@id='pageBody']//a[text()='Global Promotion Exclusions']");
	public static By marketingPageSinglePercentage_PrmPgeRemoveISBNLink=By.xpath(".//*[@id='table-container-isbn-glb']//a");

	public static By marketingPageSinglePercentage_PrmPgeCount=By.xpath(".//*[@id='pageLayout-body-inner-most']//span[contains(@class,'p-last')]//a[text()='Last']");
	public static By marketingPageSinglePercentage_PrmPgeLnk=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class, 'span17 align_center')]/span[contains(@class, 'p-nums')]/a");
	public static By marketingPageSinglePercentage_PrmPgeSucMsg=By.xpath(".//*[@id='msg-glb-save-success'][text()='The Promotion Exclusion is successfully saved.']");
	public static By marketingPageSinglePercentage_PrmPge_ISBNTextBox=By.xpath(".//*[@id='glbisbn']");
	public static By marketingPageSinglePercentage_PrmPge_ISBNExclude=By.xpath(".//*[@id='glbisbnexclude']");
	public static By marketingPageSinglePercentage_PrmPge_Browse=By.xpath(".//*[@id='glbfilename']");
	public static By marketingPageSinglePercentage_PrmPge_Upload=By.xpath(".//*[@id='glbisbnupload']");
	public static By marketingPageSinglePercentage_PrmPge_VerfyElement=By.xpath(".//*[@id='table-container-isbn-glb']/table/tbody/tr");
	public static By marketingPageSinglePercentage_PrmPge_EvlAdmnLnk=By.xpath(".//*[@id='pageBody']//table[contains(@class,'drkhighlight')]//a");
	public static By marketingPageSinglePercentage_PrmPge_CDROMOption=By.xpath(".//*[@id='piproducttypeselect']/option[1]");
	public static By marketingPageSinglePercentage_PrmPge_tableRow=By.xpath(".//*[@id='table-container-pt-pi']/table//tr");
	public static By marketingPageSinglePercentage_PrmPge_ISBNExcludeTxtBox=By.xpath(".//*[@id='peisbn']");
	public static By marketingPageSinglePercentage_PrmPge_ISBNExludeBtn=By.xpath(".//*[@id='peisbnexcludebtn']");
	public static By marketingPageSinglePercentage_PrmPge_ISBNExludeSucMsg=By.xpath(".//*[@id='msg-pe-save-success']");
	public static By marketingPageSinglePercentage_PrmPge_Verify=By.xpath(".//*[@id='table-container-isbn-pe']/table/tbody/tr");
	public static By marketingPageSinglePercentage_ViewMarketingPageLink=By.xpath(".//*[@id='marketingLink']/a");
	public static By marketingPageSinglePercentage_ViewMarketingPageBreadCrumb=By.xpath(".//*[@id='pageBody']//table[contains(@class,'drkhighlight')]/tbody/tr");
	public static By marketingPageISBNtableContent=By.xpath(".//*[@id='promoteSelectedItems']/tbody/tr[2]/td");
	public static By crossPromoteISBNtableContent=By.xpath(".//*[@id='crossPromoteSelectedItems']/tbody/tr[2]/td");

	public static By marketingPageISBNTextBox=By.xpath(".//*[@id='promoteIsbn']");
	public static By marketingPageISBNAddBtn=By.xpath(".//*[@id='addMarketingPromoteItem']");
	public static By marketingPageSelDVD=By.xpath(".//*[@id='piproducttypeselect']//option[contains(@value,'27')]");



	//.....................................LO Unique Course Trial Fulfillment from Search results page........................

	public static By maintainProducts_FProduction_Lnk=By.xpath(".//*[@id='table-container']/table/tbody/tr/td/span/a[text()='F- Production']");
	public static By F_Production_TrialNotificationTables=By.xpath(".//*[@id='faculty-production']//div[@class='email_template_section']/span");
	public static By F_Production_EnableTrialRegistraion=By.xpath(".//*[@id='faculty-production']//input[@name='enableTrialRegistration']");
	public static By evolve_RequestTrial30Days=By.xpath(".//*[@id='tab-relayout']/div/div/div/a[text()='Request a 30 day trial']");
	public static By maintainProducts_FProduction_EnableRegistraion=By.xpath(".//*[@id='faculty-production']/div[@class='item-container']/form/div/div[4]/table/tbody/tr/td/input[@type='checkbox']");
	public static By maintainProducts_FProduction_StartDate=By.xpath(".//*[@id='faculty-production']/div[@class='notification']/div/div/span[text()='Start Date']");
	//*[@id='faculty-production']/div[@class='notification']/div/div/span[@class='middle']/b
	public static By evolve_MyCart_RequestTrial30Dayslnk=By.xpath(".//*[@class='trialmessage uppercase']");
	public static By titleInEmail=By.xpath(".//*[@id='mail.hsplit.detail.header.subject']");
	public static By AR_F_Production_MileStoneTable=By.xpath("//*[@id='adoptionReqDetails']/table/tbody/tr[2]/td/table/tbody/tr[1]/td[1]/table/tbody/tr[29]/td");
	public static By AR_F_Production_EmailTemplate_StartDate=By.xpath(".//*[@id='eventEmail0']");
	public static By AR_F_Production_EmailTemplate_Warning1=By.xpath(".//*[@id='eventEmail1']");
	public static By AR_F_Production_EmailTemplate_Warning2=By.xpath(".//*[@id='eventEmail2']");
	public static By AR_F_Production_EmailTemplate_EndDate=By.xpath(".//*[@id='eventEmail3']");
	public static By AR_F_Production_StartDate= By.xpath(".//*[@id='milestone-container']/tbody/tr[2]/td[2]");
	public static By AR_F_Production_Warning1=By.xpath(".//*[@id='eventText1']");
	public static By AR_F_Production_Warning2=By.xpath(".//*[@id='eventText2']");
	public static By AR_F_Production_EndDate=By.xpath(".//*[@id='eventText3']");
	public static By AR_F_Production_UnEnrollUser= By.xpath(".//*[@id='eventText4']");
	public static By adoptionRequest_ConvertToPermanent=By.xpath(".//*[@id='trialToPermanent']");
	public static By adoptionRequest_ConvertMessage=By.xpath(".//*[@id='messageContainer']/font/b");
	public static By adoptionRequest_UpdatedHistoryText=By.xpath(".//*[@id='noteDetails']/tbody//td[text()='Trial is converted to full course']");
	public static By AR_F_Production_MIlestone=By.xpath(".//*[@id='milestone-container']//td[text()=' MILESTONE ']");
	public static By evolve_OnlineCourseHoneypot=By.xpath(".//*[@id='lowershelf']/table/tbody/tr//img[@alt='Online Courses']");
	public static By evolve_OnlineCourse_GetStudentsLink=By.xpath(".//*[@id='lowershelf']//a[text()='Get students into your course']");
	//public static By evolve_GetStudentsLink_SubmitLink=By.xpath(".//*[@id='pageLayout-body-inner-most']//a[text()='Submitting your Class Roster']");
	public static By evolve_GetStudentsLink_SubmitLink=By.xpath(".//a[@href='/cs/submitRoster.html']");
	public static By evolve_SubmitLink_enterCourseIDTxt=By.xpath(".//*[@id='pageLayout-body-inner-most']//input[@class='wide']");
	public static By evolve_SubmitLink_enterRoster=By.xpath(".//*[@id='field-roster']");
	public static By evolve_SubmitLink_enterRoster_RosterButton=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/form/button");
	public static By evolve_SubmitLink_enterRoster_Submit=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/form/button");
	//*[@id='pageLayout-body-inner-most']/div/div/button

	public static By Admin_Apprstatus_Trial=By.xpath(".//table/tbody/tr[1]/td[12]/div[@id='trialVal']/span");
	public static By F_productionTable=By.xpath(".//*[@id='faculty-production']//div[@class='email_template_section']/span");
	public static By evolve_SubmitLink_RosteErrorMessg=By.xpath(".//*[@id='ext-gen7']");
	// public static By adoptionRequest_AdoptionNumber=By.xpath("//*[@id='adoptionReqDetails']//table/tbody/tr[1]/td/h3/text()");
	//public static By adoptionRequest_AdoptionNumber=By.xpath(".//*[@id='resultTable']/tbody/tr[1]/td/b");
	public static By adoptionRequest_AdoptionNumber=By.xpath(".//table[@id='resultTable']//td[@headers='AR']");
	public static By adoptionRequest_ConvertToTrial=By.xpath(".//*[@id='requestToTrial']");
	public static By ProtectionSchemeID_OK=By.xpath(".//a[contains(text(),'OK')]");
	/*............................... ConvertLOTrialCoursetoPermanentFulfilled_15103................................*/

	public static By Admin_searchAdoptionByNumber=By.id("srchAdoptionId");
	public static By Admin_searchAdoptionButton=By.id("searchById");


	//Test ID (15580) - Promotion - Single Percentage - Exclusions
	//public static By Promotion_ExclusionVariable_MaintainPromotionLink=By.xpath("//*[@id='pageBody']//a[text()='Maintain Promotions']");
	//public static By Promotion_ExclusionVariable_MaintainPromotionLink=By.linkText("Maintain Promotions");
	public static By Promotion_ExclusionVariable_BreadCrumb=By.xpath(".//*[@id='pageBody']//table[contains(@class,'drkhighlight')]//tr//td");
	public static By Promotion_ExclusionVariable_Searchbox=By.xpath(".//*[@id='query']");
	public static By Promotion_ExclusionVariable_SearchButton=By.xpath("//*[@id='search']");
	//public static By Promotion_ExclusionVariable_MaintainPromotionLink=By.xpath("//*[@id='pageBody']//table[contains(@class,'drkhighlight')]//td");

	public static By Promotion_ExclusionVariable_PrmTxt=By.xpath(".//*[@id='pageBody']//b[text()='Promotion Exclusions']");
	public static By Promotion_ExclusionVariable_ChkBoxReference=By.id("textRefTradeRe");
	public static By Promotion_ExclusionVariable_ChkBoxText=By.id("textRefTradeTe");
	public static By Promotion_ExclusionVariable_ChkBoxTrade=By.id("textRefTradeTr");
	public static By Promotion_ExclusionVariable_ChkBoxAnnual=By.id("textRefTradeAn");
	public static By Promotion_ExclusionVariable_ChkBoxSucMsg=By.xpath(".//*[@id='msg-pe-save-success']");

	public static By Promotion_isbnListValueInclude=By.xpath(".//*[@id='table-container-isbn-pi']/table/tbody/tr/td[2]");
	public static By Promotion_isbnListValueExclude=By.xpath(".//*[@id='table-container-isbn-pe']/table/tbody/tr/td[2]");
	public static By Promotion_variablePercentageInclusion=By.xpath(".//*[@id='table-container-isbn-pi']/table/tbody/tr/td[3]");

	public static By Promotion_ExclusionVariable_ComboBox=By.xpath(".//*[@id='peprofitcenterselect']");   
	public static By Promotion_ExclusionVariable_ExcludeBtn=By.xpath("//*[@id='pepcexcludebtn']");   
	public static By Promotion_ExclusionVariable_FinalOption=By.xpath(".//*[@id='peprofitcenterselect']/option");  
	public static By Promotion_ExclusionVariable_FailureMsg=By.xpath(".//*[@id='msg-pe-save-failure']"); 
	public static By Promotion_ExclusionVariable_Option1=By.xpath(".//*[@id='peprofitcenterselect']/option[1]");  
	public static By Promotion_ExclusionVariable_SucMsg=By.xpath(".//*[@id='msg-pe-save-success']");          
	public static By Promotion_ExclusionVariable_Background=By.xpath(".//*[@id='table-container-pc-pe']/table");  
	public static By Promotion_ExclusionVariable_RemLnk=By.xpath(".//*[@id='table-container-pc-pe']//a");        
	public static By Promotion_ExclusionVariable_Option2=By.xpath(".//*[@id='peprofitcenterselect']/option[2]");
	public static By Promotion_ExclusionVariable_Viewall=By.xpath(".//*[@id='hlink-container-pc-pe']/a[text()='View All Profit Centers...']");
	public static By Promotion_ExclusionVariable_RowValue=By.xpath(".//*[@id='table-container-pc-pe']/table/tbody/tr");  
	public static String remove3= "//*[@id='table-container-pc-pe']/table/tbody/tr[";
	public static String remove4 ="]";
	//*[@id='table-container-isbn-pi']/table/tbody/tr

	public static By Promotion_ExclusionVariable__MjrComboBox=By.xpath(".//*[@id='pemscselect']");
	public static By Promotion_ExclusionVariable_MajExcludeBtn=By.xpath(".//*[@id='pemscexcludebtn']");
	public static By Promotion_ExclusionVariable_MajFinalOption=By.xpath(".//*[@id='pemscselect']/option");
	public static By Promotion_ExclusionVariable_Majoption1=By.xpath(".//*[@id='pemscselect']/option[1]");
	public static By Promotion_ExclusionVariable_MajOption2=By.xpath(".//*[@id='pemscselect']/option[2]");
	public static By Promotion_ExclusionVariable_MajBackground=By.xpath(".//*[@id='table-container-msc-pe']/table");
	public static By Promotion_ExclusionVariable_MajRem=By.xpath(".//*[@id='table-container-msc-pe']//a");
	public static By Promotion_ExclusionVariable_MajViewAll=By.xpath(".//*[@id='hlink-container-msc-pe']/a[text()='View All Major Subject Codes...']");
	public static By Promotion_ExclusionVariable_MajRowValue=By.xpath(".//*[@id='table-container-msc-pe']/table/tbody/tr");

	public static String remove5= "//*[@id='table-container-msc-pe']/table/tbody/tr[";
	public static String remove6 ="]";

	public static By Promotion_ExclusionVariable__ProComboBox=By.xpath(".//*[@id='peproducttypeselect']");
	public static By Promotion_ExclusionVariable_ProExcludeBtn=By.xpath(".//*[@id='peptexcludebtn']");
	public static By Promotion_ExclusionVariable_ProFinalOption=By.xpath(".//*[@id='peproducttypeselect']/option");
	public static By Promotion_ExclusionVariable_Prooption1=By.xpath(".//*[@id='peproducttypeselect']/option[1]");
	public static By Promotion_ExclusionVariable_ProOption2=By.xpath(".//*[@id='peproducttypeselect']/option[2]");
	public static By Promotion_ExclusionVariable_ProViewAll=By.xpath(".//*[@id='hlink-container-pt-pe']/a[text()='View All Product Types...']");
	public static By Promotion_ExclusionVariable_ProBackground=By.xpath(".//*[@id='table-container-pt-pe']/table");
	public static By Promotion_ExclusionVariable_ProRowValue=By.xpath(".//*[@id='table-container-pt-pe']/table/tbody/tr");
	public static By Promotion_ExclusionVariable_ProRem=By.xpath(".//*[@id='table-container-pt-pe']//a");

	public static By Promotion_ExclusionVariable_ProISBNErrorMsg=By.xpath(".//*[@id='msg-pe-save-failure']");
	public static By Promotion_ExclusionVariable_ISBNViewAll=By.xpath(".//*[@id='hlink-container-isbn-pe']/a[text()='View All ISBNs...']");

	public static By Promotion_ExclusionVariable_ISBNAddList=By.xpath(".//*[@id='table-container-isbn-pe']/table/tbody/tr[1]");
	public static By Promotion_ExclusionVariable_ISBNRem=By.xpath(".//*[@id='table-container-isbn-pe']//td[2]/preceding-sibling::td[1]/a");

	public static By Promotion_ExclusionVariable_ISBNBrowse=By.xpath(".//*[@id='pefilename']");
	public static By Promotion_ExclusionVariable_ISBNUpload=By.xpath(".//*[@id='peisbnuploadbtn']");

	public static By Promotion_ExclusionVariable_ISBNUplRem=By.xpath(".//*[@id='table-container-isbn-pe']/table/tbody/tr//a");


	public static By Promotion_SelcAll=By.xpath(".//*[@id='selectall']");
	public static By Promotion_NoPromotionTxt=By.xpath(".//*[@id='noResultsSpan'][text()='There are no promotion inclusion isbn to view.']");



	//Test ID 9796, 10302, 10303
	public static By parBtn = By.id("parBtn");
	public static By enrollCourse=By.id("enroll-in-course");
	public static By navTitle=By.tagName("title");
	//public static By enrollResourceId=By.id("ui-resourceId");
	public static By enrollResourceId=By.id("accessCode");
	public static By enrollInstructorCourseId = By.id("ui-resourceId");
	//public static By enrollContinue=By.xpath(".//*[@class='form-inline']/div[2]/input");
	public static By enrollContinue=By.xpath(".//form[@name='validateCodeForm']/button");
	public static By enrollInstructorCourseIdContinue = By.xpath(".//input[@value='Continue']");
	public static By enrollInstructorCourseIdPopupContinue = By.xpath(".//input[@onclick='close_cbox()']");
	public static By enrollTitle=By.xpath("html/body/div[4]/div[3]/div/div/div/div/div/ul/li[2]/div[8]/div[2]/span");
	public static By enrollLONewUser=By.xpath(".//*[@id='usageReportContainer']/table/tbody/tr[1]/td[1]/span");
	////*[@id='usageReportContainer']/table/tbody/tr[1]/td[1]/span
	public static By enrollCourseId=By.xpath(".//*[@id='protectedaccessrightsdiv']/table/tbody/tr/td[2]");
	public static By enrollHoneyPotImg=By.xpath(".//*[@id='lowershelf']/table/tbody/tr/td[4]/img");
	public static By enrollHoneyPotInstructorCourse=By.xpath("//*[@id='lowershelf']/div[8]/ul/li[2]/a");
	public static By Admin_CourseParReport_Search_Results_Row2 = By.xpath("//*[@id='evolve_usersearchlist_table']/tbody/tr/td[2]");
	public static By enrollCartCourseId=By.xpath(".//*[@id='9780323055536']/div[8]/div[1]/span");
	public static By enrollCoursePopUpContinue=By.xpath(".//*[@id='youreEnrolled']/div/input");
	public static By enrollMyEvolveCourseClick=By.xpath(".//*[@id='course-sidebar']/ul[2]/li[1]/a/span[2]");
	public static By enrollMyEvolveCourseLinkClick=By.xpath(".//*[@id='set']/li/div[1]/div/a");
	public static By enrollMyEvolveCourseSubFolders=By.xpath(".//*[@class='courseContentLink']");
	public static By enrollLOPAR=By.xpath(".//*[@id='usageReportContainer']/table/tbody/tr[1]/td[2]/span");
	public static By enrollLOReedemption=By.xpath(".//*[@id='usageReportContainer']/table/tbody/tr[1]/td[3]/span");
	public static By ManageProtectedRedeemDate=By.xpath(".//*[@id='protectedaccessrightsdiv']/table/tbody/tr[1]/td[4]/span");
	public static By createAccessCodeSchemeID=By.xpath(".//*[@id='protectionschemeselectedid']");
	public static By EvolveAdmin=By.xpath(".//*[@id='pageBody']/table/tbody/tr[1]/td/a[text()='Evolve Admin']");
	public static By Successfulenroll=By.xpath(".//*[@id='youreEnrolled']/div/input");

	//Test ID (15580) - Promotion - Single Percentage - Exclusions


	public static By Promotion_ExclusionSingle_ComboBox=By.xpath(".//*[@id='piprofitcenterselect']");   
	public static By Promotion_ExclusionSingle_ExcludeBtn=By.xpath(".//*[@id='pepcexcludebtn']");  		
	public static By Promotion_ExclusionSingle_FinalOption=By.xpath(".//*[@id='peprofitcenterselect']/option");		
	public static By Promotion_ExclusionSingle_FailureMsg=By.xpath(".//*[@id='msg-pe-save-failure']");		
	public static By Promotion_ExclusionSingle_Option1=By.xpath(".//*[@id='peprofitcenterselect']/option[1]"); 	
	public static By Promotion_ExclusionSingle_SucMsg=By.xpath(".//*[@id='msg-pe-save-success']"); 		
	public static By Promotion_ExclusionSingle_Option2=By.xpath(".//*[@id='peprofitcenterselect']/option[2]");	
	public static String remove8=".//*[@id='table-container-isbn-pi']/table/tbody/tr[";
	public static String remove9="]";

	public static By exclprofit=By.xpath(".//*[@id='peprofitcenterselect']/option");
	//*[@id='peprofitcenterselect']/option
	//*[@id='pckisbnpitable']/tbody/tr[1]/td[1]/a

	//Test ID (10229) - Promotion - Redeem Single Percentage Off
	public static By Promotion_Redeem_title=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class,'productTitle')]/a");
	public static By marketingPageSinglePercentage_DiscountPrice=By.xpath(".//*[@id='tab-relayout']//div[contains(@class, 'cost')]//span[contains(@class, 'price discountprice2')]");
	//public static By marketingPageSinglePercentage_DiscPrice=By.xpath(".//*[@id='pageLayout-body-inner-most']//table[contains(@class,'pull-right totaltable')]//tr[1]/following-sibling::tr[1]/td[2]");
	public static By marketingPageSinglePercentage_DiscPrice=By.xpath(".//*[@id='pageLayout-body-inner-most']//tr[1]/following-sibling::tr[1]/td[2]");
	public static By marketingPageSinglePercentage_orignalPrice=By.xpath(".//*[@id='tab-relayout']//div[contains(@class,'cost')]/p/span[contains(@class,'em2 strikethroughprice2')]");
	public static By marketingPageSinglePercentage_searchProduct=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class,'cartprodtype student')]/span/a");


	/********************************************Sort By Objs***************************************/

	public static By SortyByRelevance=By.xpath(".//*[@id='sortby-relevance']");
	public static By SortByAuthor=By.xpath(".//*[@id='sortby-authorSort']");
	public static By SortByTitle=By.xpath(".//*[@id='sortby-name']");
	public static By SortbylistPrice=By.xpath(".//*[@id='sortby-listPrice']");
	public static By Sortbycopyyear=By.xpath(".//*[@id='sortby-copyYear']");
	public static By SortbyProductType=By.xpath(".//*[@id='sortby-productType']");

	public static By Authorlocator=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class, 'item row')]//div[contains(@class, 'cartauthor')]//span");
	public static By ProductTypeLocatorforFaculty=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class, 'item row')]//div[contains(@class, 'cartprodtype faculty')]//span//a");
	public static By ProductTypeLocatorforStudent=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class, 'item row')]//div[contains(@class, 'cartprodtype student')]//span//a");
	public static By PriceLocator=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class, 'item row')]//div[contains(@class, 'float_right align_right prices')]//div[1]");
	public static By ProductTypeLoactor=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class, 'item row')]//div[contains(@class, 'float_right align_right prices')]//div");
	public static By CopyRightYearLocator=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class, 'item row')]//div[contains(@class, 'cartauthor')]");
	public static By Title=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class, 'item row')]//div[contains(@class, 'carttitle')]");

	//public static By ClickonNextbutton=By.xpath(".//*[@id='pageLayout-body-inner-most']//span[contains(@class,p-next)]//a[contains(text(),'Next')]");
	//public static By ClickonthirdPage=By.xpath(".//*[@id='pageLayout-body-inner-most']//span[contains(@class,p-nums)]//a[contains(text(),'3')]");
	public static By ClickonNextbutton=By.xpath("(.//div[@class='span17 align_center'])[2]/span[@class='p-next']/a");
	public static By ClickonthirdPage=By.xpath("(.//div[@class='span17 align_center'])[2]/span[@class='p-nums']/a[text()='3']");
	//public static By Educator_login    = By.xpath(".//*[@id='page']/div[@class='getstarted']/div[2]/a");
	public static By Educator_login    = By.xpath(".//a[@class='pull-right educator ed-only']");
	//public static By NavigatetoCatalog=By.xpath(".//*[@id='page']/div[1]/div/div[2]/div[1]/ul/li[2]/a");
	public static By NavigatetoCatalog=By.xpath(".//a[text()='Catalog']");
	public static By Booktitle=By.xpath(".//*[@id='tab-relayout']//h1");

	/********************************************End of Sort By Objs***************************************/

	/********************************************Search By Objs***************************************/
	public static By Selecallfilterbyproducttype=By.xpath(".//*[@id='type-selectAll']");
	public static By Selecallfilterbyformat=By.xpath(".//*[@id='format-selectAll']");
	//public static By SaveonElsevierProducts=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[3]/a[2]/img");
	public static By SaveonElsevierProducts=By.xpath(".//div[@class='additional-links']//li[@class='shopping']/a/img");
	//public static By BrowserourProductsbydisciple=By.xpath(".//*[@id='pageLayout-body-inner-most']//a[contains(text(),'Browse our products by discipline')]");
	public static By BrowserourProductsbydisciple=By.xpath(".//a[text()='Browse our products by discipline']");
	public static By SearcResults=By.xpath(".//*[@id='pageLayout-body-inner-most']//h1[contains(text(),'Search Results')]");
	public static By totalresults=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[3]/div[1]");
	public static By SearchcourseinHoneypot=By.xpath(".//*[@id='search-course']");


	/*public static By onlinecoursetextbox=By.xpath(".//*[@id='lowershelf']/div[8]/ul/li[1]/form/div/input[1]");
       public static By simulationstextbox=By.xpath(".//*[@id='lowershelf']/div[6]/ul/li[1]/form/div/input[1]");
       public static By  AdaptiveSolutions=By.xpath(".//*[@id='lowershelf']/div[5]/ul/li[1]/form/div/input[1]");
       public static By  evloveresources=By.xpath("/html/body/div[4]/div[3]/div/div/div/div/div[1]/div[5]/ul/li[1]/form/div/input[1]");
	 */
	public static By onlinecoursetextbox=By.xpath(".//*[@id='lowershelf']/div[8]/ul/li[1]/form/div/input[1]");
	public static By std_onlinecoursetextbox=By.xpath(".//*[@id='search-course']");
	public static By simulationstextbox=By.xpath("//*[@id='search-simulation']");
	public static By  AdaptiveSolutions=By.xpath(".//*[@id='lowershelf']/div[5]/ul/li[1]/form/div/input[1]");
	public static By  evloveresources=By.xpath(".//*[@id='search-resource']");
	public static By pageburst=By.xpath(".//*[@id='search-pbst']");
	/**************Admin*************************/
	//public static By Baseproductreportlink=By.xpath(".//*[@id='pageBody']/form/table/tbody//a[contains(text(),'Base Product Reports')]");
	//public static By Baseproductreportlink=By.linkText("Base Product Reports");
	public static By ISBNText=By.xpath(".//*[@id='txtResourceKey']");
	public static By ProcessMenu=By.xpath(".//*[@id='processMenu']");

	public static By StatusCode=By.xpath(".//*[@id='statusCode']");
	public static By GoButton=By.xpath(".//*[@id='formProduct']/table/tbody/tr[1]/td/input[2]");
	public static By EditButton=By.xpath(".//*[@id='editdatatable']/table/tbody/tr[11]/td[2]/input");
	public static By SuccessMsg=By.xpath(".//*[@id='desc']");
	public static By PublicationDate=By.xpath(".//*[@id='PublicationDate']");
	//public static By MaintainProducts=By.xpath(".//*[@id='pageBody']/form/table/tbody//a[contains(text(),'Maintain Products')]");
	public static By MaintainProducts=By.linkText("Maintain Products");


	public static By SearchISBNinProductSearch=By.xpath(".//*[@id='query']");
	public static By Facproduction=By.xpath(".//*[@id='table-container']/table/tbody/tr/td[5]/span/a[contains(text(),'F- Production')]");
	public static By Stuproduction=By.xpath(".//*[@id='table-container']/table/tbody/tr/td[5]/span/a[contains(text(),'S- Production')]");
	public static By Fac_saveaswip=By.xpath(".//*[@id='faculty-production']//button[contains(text(),'SAVE AS WIP')]");
	public static By Stu_saveaswip=By.xpath(".//*[@id='student-production']//button[contains(text(),'SAVE AS WIP')]");
	public static By facl_save=By.xpath(".//*[@id='faculty-wip']//button[contains(text(),'SAVE')]");
	public static By facl_pubilsh=By.xpath(".//*[@id='faculty-wip']//button[@class='publish']"); 
	public static By stu_save=By.xpath(".//*[@id='student-wip']//button[contains(text(),'SAVE')]");
	public static By stu_pubilsh=By.xpath(".//*[@id='student-wip']//button[@class='publish']");

	public static By StudentTab=By.xpath(".//*[@id='product-tabs']//a[contains(text(),'Student Production')]");


	public static By faculty_Enablereg=By.xpath(".//*[@id='faculty-wip']//input[@name='enableRegistration']");
	public static By faculty_Includeinsearch=By.xpath(".//*[@id='faculty-wip']//input[@name='includeInSearch']");
	public static By faculty_EnableeCommerece=By.xpath(".//*[@id='faculty-wip']//input[@name='enableEcommerce']");


	public static By Std_Enablereg=By.xpath(".//*[@id='student-wip']//input[@name='enableRegistration']");
	public static By Std_Includeinsearch=By.xpath(".//*[@id='student-wip']//input[@name='includeInSearch']");
	public static By Std_EnableeCommerece=By.xpath(".//*[@id='student-wip']//input[@name='enableEcommerce']");


	/******************************************** End of Search By Objs***************************************/

	public static By dmCodeforuse=By.xpath(".//*[@id='marketingDmCode']");
	public static By priceValidation=By.xpath(".//*[@id='pageLayout-body-inner-most']//tbody/tr/td[2]");
	public static String isbnsear=EvolveCommonBussinessFunctions.isbnForFutureUse4;
	//*[@id='9780323088633']/div[3]/div[5]/span[1]

	//public static By isbnsearch=By.xpath(".//*[@id='9780323088633']/div[contains(@class,'price span2')]");
	public static By isbnsearch=By.xpath(".//*[@id='9780323088633']//span[contains(@class,'strikethroughprice2')]");
	static String isb=EvolveCommonBussinessFunctions.isbnForFutureUse4;
	//public static By isbn4=By.xpath(".//*[@id='"+isb+"']//span[contains(@class,'strikethroughprice2')]");

	//public static By isbn4=By.xpath("html/body/div[4]/div[3]/div/div/div/div/div[5]/div[1]/ul/li[2]/div[3]/div[5]/span[1]");
	public static By isbn4=By.xpath(".//*[@class='strikethroughprice2']");
	//PRASANTH>>>>>>>>>>>>>

	public static final By USER_MY_EVOLVE_TAB = By.xpath(".//*[@id='div-resources']//a[text()='Evolve Catalog']");

	// 15591

	public static final By MANAGE_ADMINISTRATORS = By.linkText("Manage Administrators");

	public static final By ADMIN_USER_NAME_ROW = By
			.xpath("//*[@id='evolve_adminlist_table']//tbody//a[text()='schintakindi']");

	public static final By PERORDER_MAINTANCE = By.name("preOrderMaintenance");

	public static final By ADMIN_SAVE_BUTTON = By.name("Save");

	public static final By ADMIN_EDIT_MEASSAGE = By.id("message");

	public static final By EVOLVE_BUTTON = By
			.xpath("//*[@id='pageBody']/table[1]/tbody//a[text()='Evolve Admin']");

	//public static final By BASE_PRDORDUCT_RERPORTS = By.xpath("//*[@id='pageBody']/form//table//td/a[text()='Base Product Reports']");

	public static final By SELECT_IBN_TEXT_BOX = By.id("txtResourceKey");

	public static final By PROCESS_MENu = By.id("processMenu");

	public static final By VIEW_PRODUCT = By.name("btnViewProduct");

	public static final By PUBLICATION_DATE = By.name("PublicationDate");

	public static final By PUBLICATION_STATUS = By.name("PublishingStatus");

	public static final By EDIT_BUTTON_PRORDUCT = By.name("btnEdit");

	public static final By PRODUCT_RESOURCE_MESSAGE = By.id("desc");

	public static final By UN_AFFIILIATED_CHECK_BOX = By.id("unaffiliated");

	public static final By STREET_ADDRESS = By.id("billing-address1");

	public static final By CITY = By.id("billing-city");

	public static final By STATE = By.name("addresses.2.state");

	public static final By BILLING_PIN_CODE = By.id("billing-postalCode");

	public static final By USE_THIS_ADDRESS = By
			.id("//button[text()='Use This Address']");

	public static final By DOWNLOAD_ACCESS_CODE = By.id("download");

	public static final By DOWNLOAD_ACCESS_CODE_TXT = By.xpath(".//button//span[text()='Download']");

	public static final By ACCESS_CODE =By.name("accessCode");

	public static final By SUB_TOTAL = By.xpath(".//*[@id='pageLayout-body-inner-most']//td[@class='totalamount strong']");

	public static final By REGISTERED_USER_AGGREMENT = By.id("checkbox-registered");

	public static final By ENTER_AS_IND_BUTTON = By.xpath(".//*[@id='set']//button[text()='Enter as Independent Self-Study']");

	public static final By MODAL_HEADER = By.xpath(".//*[@id='modalSelfStudy']/h1");

	public static final By MODAL_CONFORMATION = By.xpath(".//*[@id='modalSelfStudy']/p[1]");

	public static final By CHECK_BOX_MESSAGE = By.xpath(".//*[@id='modalSelfStudy']/form/p[1]/label");

	public static final By MODAL_CANCEL_BUTTON = By.xpath("//*[@id='modalSelfStudy']/form/p//button[text()='Cancel']");

	public static final By MODAL_CONFORM_BUTTON = By.id("pendingSelfStudy-confirm");

	public static final By ONLIE_COURSE_ID = By.id(".//*[@id='set']/li[1]//div/span[@class='course_ia info']");

	public static final By ONLINE_COURSE_LINK = By.xpath(".//*[@id='set']/li[1]/div/div/a");
	public static final By COURSE_TITLE = By.id("courseTitle");

	public static final By schemeId = By.id("protectionschemeselectedid"); 

	public static By txtcourseID_1=By.name("courseid");

	public static final By COURSE_PAR_REPORT = By.xpath("//a[text()='Course PAR Report']");

	public static final By accessRedeem=By.xpath(".//*[@id='ajax-modal']/div[2]/form[1]/input[3]");
	//TC15459
	public static By ReserveBtn=By.xpath(".//*[@id='add-to-cart']");
	public static By checkoutBtn=By.xpath(".//*[@id='checkoutButton']");

	//Test ID (15475) - eCommerce Preorder – Order History

	public static By manageAdmin =By.xpath(".//*[@id='pageBody']/form/table/tbody/tr[5]/td/table[9]/tbody/tr[2]/td[1]/a");
	public static By testadmin = By.xpath(".//*[@id='evolve_adminlist_table']/tbody/tr[3]/td[3]/a");	
	public static By maintainPPM= By.xpath(".//*[@id='privileges']/img[22]");
	public static By managePrivileges= By.xpath(".//*[@id='editPrivilegesLink']");
	public static By maintainPPMChkBox= By.xpath(".//*[@id='privileges']/input[22]");
	public static By rolesSaveBtn=By.xpath("html/body/div[1]/div[3]/div/button[1]");
	public static By adminSaveBtn=By.xpath(".//*[@id='editAdmin']/table/tbody/tr[17]/td[2]/input[1]");
	public static By evolveadminLnk=By.xpath(".//*[@id='pageBody']/table[1]/tbody/tr/td/a[1]");

	//	ONIX PPM Load Data Manager objects

	public static By baseProductResourceLnk=By.xpath(".//*[@id='pageBody']/form/table/tbody/tr[5]/td/table[16]/tbody/tr[2]/td/a");
	public static By baseProductResKey=By.xpath(".//*[@id='txtResourceKey']");
	public static By editResourceSelect=By.xpath(".//*[@id='processMenu']");
	public static By goBtn=By.xpath(".//*[@id='formProduct']/table/tbody/tr[1]/td/input[2]");
	public static By publicationDateTxt= By.xpath(".//*[@id='PublicationDate']");
	public static By publishingStatusSelect= By.xpath(".//*[@id='statusCode']");
	public static By resourceEditBtn= By.xpath(".//*[@id='editdatatable']/table/tbody/tr[11]/td[2]/input");

	//student Loging and order history 

	public static By myAccountmenu=By.xpath(".//*[@id='account-menu']/span");
	public static By orderHistorylnk=By.xpath(".//*[@id='account-menu']/ul/li[2]/a");



	//test id 8567
	public static By Hesi_Student_HesiExam=By.xpath(".//*[@id='uppershelf']/table/tbody/tr/td[3]/img");
	//public static By Hesi_Student_HesiRegister=By.xpath(".//*[@id='uppershelf']/div[7]/ul/li[1]/a[text()='Register for HESI']");
	public static By Hesi_Student_HesiRegister=By.xpath(".//a[text()='Register for Results and Remediation']");
	public static By Hesi_Student_Registernow=By.xpath(".//*[@id='add-to-cart']");
	public static By Hesi_Student_ok=By.xpath(".//*[@id='toPopup']/button[text()='OK']");
	public static By Hesi_Student_Cartview=By.xpath(".//*[@id='page']/div[1]/div/div[2]/div[2]/a[@class='cart nav-text relative']");
	public static By Hesi_Student_price=By.xpath(".//*[@id='9781455728916']/div[5][@class='price span2']");
	public static By Hesi_Student_Reedembutton=By.xpath(".//*[@id='checkoutButton']");
	public static By Hesi_Student_chkbox=By.xpath(".//*[@id='no-institution']");
	public static By Hesi_Student_country=By.xpath(".//*[@id='institution-country']");
	public static By Hesi_Student_state=By.xpath(".//*[@id='institution-state']");
	public static By Hesi_Student_City=By.xpath(".//*[@id='institution-city']");
	public static By Hesi_Student_institute=By.xpath(".//*[@id='institution-name']");
	public static By Hesi_Student_prgtype=By.xpath(".//*[@id='select-program-type']");
	public static By Hesi_Student_year=By.xpath(".//*[@id='select-graduation-year']");
	public static By Hesi_Student_Optional=By.xpath(".//*[@id='address0-studentId']");
	public static By Hesi_Student_chk=By.xpath(".//*[@id='offers']");
	public static By Hesi_Student_continue=By.xpath(".//*[@id='profile-submit']");
	public static By Hesi_Student_msg=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[1]/ul/li[2]/div[7]/div");
	public static By Hesi_Student_title=By.xpath(".//*[@id='pageLayout-body-inner-most']//a[text()='HESI Registration, 1st Edition']");
	public static By Hesi_Student_ISBN=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[@class='cartproductdetails']");
	public static By Hesi_Verify_Total=By.xpath("html/body//span[@class='totalamount']");
	public static By Hesi_Student_Access=By.xpath(".//*[@id='set']/li/div/div/a[text()='Student Access']");
	public static By Hesi_Registration_header=By.xpath(".//*[@id='tab-relayout']/div/div[2]/h1[text()='HESI Registration']");
	public static By Hesi_title = By.xpath(".//*[@id='9781455728916']//a[text()='HESI Registration, 1st Edition']");
	public static By Hesi_Student_isbn=By.xpath(".//*[@id='9781455728916']/div[3]/div[4]");

	// test id  9791
	public static By Hesi_Student_username=By.xpath(".//*[@id='loginForm-username']");
	public static By Hesi_Student_password=By.xpath(".//*[@id='loginForm-password']");
	public static By Hesi_Student_login=By.xpath(".//*[@id='signin_submit']");




	/**************Ar-Module*********************/
	public static By  Searchon      = By.xpath(".//*[@id='midSearch']");
	public static By Admin_ArResults=By.xpath(".//*[@id='resultTable']");


	//vst 
	public static By vstLinkTitle=By.xpath(".//*[@id='all_titles_grid']/li/div/a/div[2]");
	/*****************************************************HESI NEW URL **************************************/
	public static By StudentAccountlink=By.xpath(".//*[@id='mainmenu']//a[contains(text(),'Student Account')]");

	public static By HESI_EvolveId=By.xpath(".//*[@id='EvlName']");


	public static By Hesi_username=By.xpath(".//*[@id='username']");
	public static By Hesi_Password=By.xpath(".//*[@id='password']");
	public static By Hesi_LoginSubmit=By.xpath(".//*[@id='mainPopUpContent']//input[@value='Log On']");
	public static By Accountlink=By.xpath(".//*[@id='mainmenu']//a[contains(text(),'Account')]");
	public static By FacultyProgramslink=By.xpath(".//*[@id='mainmenu']//a[contains(text(),'Faculty/Programs')]");
	public static By CreateNewfacultyAccount=By.xpath(".//*[@id='CrtFacLnk']");
	public static By Newdialogframe=By.name("Account Mgmt");
	public static By EvolveId=By.xpath(".//*[@id='EvlName']");
	public static By EvolveAddbutton=By.xpath(".//*[@id='popupWithEvlName']");
	public static By Firstname=By.xpath(".//*[@id='txtlblFirstName']");
	public static By Lastname=By.xpath(".//*[@id='txtfacLastName']");
	public static By UserMailid=By.xpath(".//*[@id='txtfacEmail']");
	public static By Country=By.xpath(".//*[@id='ddlfacCountry']");
	public static By CountryCode=By.xpath(".//*[@id='txtfacCountryCode']");
	public static By Areacode=By.xpath(".//*[@id='txtfacAreaCode']");
	public static By Phonenumber=By.xpath(".//*[@id='txtfacContact1']");

	public static By Address1=By.xpath(".//*[@id='txtfacAddress1']");
	public static By Address2=By.xpath(".//*[@id='txtfacAddress2']");
	public static By ZipCode=By.xpath(".//*[@id='txtfacZipCode']");
	public static By City=By.xpath(".//*[@id='txtfacCity']");
	public static By State=By.xpath(".//*[@id='txtfacState']");


	
	public static By HES_Add_organization=By.xpath(".//*[@id='txtfacAssignOrganization']");
	public static By Addorg=By.xpath(".//*[@id='lnkfacAddProgram']/img");
	public static By listoforganizations=By.xpath(".//*[@id='ddfacOrganizationPrograms']");
	public static By RolesinHESI=By.xpath(".//*[@id='ddl1']");
	public static By lableoforganization=By.xpath(".//*[@id='spanlblfacAssignOrganization']");
	public static By SearchEvolve_id=By.xpath(".//*[@id='strUName']");
	public static By Search_Results=By.xpath(".//*[@id='SrchBtn']");
	public static By HESI_Enter_Text=By.xpath(".//*[@id='txtEVID']");

	public static By HESI_Stud_Select=By.xpath(".//*[@id='ddl_EVID_SC']");
	public static By HESI_Stud_Gobutton=By.xpath(".//*[@id='btnGo']");

	//if new student
	public static By BillingAddress1=By.xpath(".//*[@id='billing-address1']");
	public static By BillingAddress2=By.xpath(".//*[@id='billing-address2']");
	public static By BililngCity=By.xpath(".//*[@id='billing-city']");
	public static By BillingAddressState=By.xpath(".//*[@id='billing-address']/select");
	public static By BililngPostalCode=By.xpath(".//*[@id='billing-postalCode']");

	//if new user
	public static By User_form_password=By.xpath(".//*[@id='field-password']");
	public static By User_form_Confpassword=By.xpath(".//*[@id='field-passwordConfirm']");
	/*public static final By MANAGE_ADMINISTRATORS = By.xpath("//*[@id='pageBody']//form//table//tbody//a[text()='Manage Administrators']");*/

	/*public static final By ADMIN_USER_NAME_ROW = By
        			.xpath("//*[@id='evolve_adminlist_table']//tbody//a[text()='schintakindi']");*/

	/*public static final By PERORDER_MAINTANCE = By.name("preOrderMaintenance");

        	public static final By ADMIN_SAVE_BUTTON = By.name("Save");

        	public static final By ADMIN_EDIT_MEASSAGE = By.id("message");

        	public static final By EVOLVE_BUTTON = By
        			.xpath("//*[@id='pageBody']/table[1]/tbody//a[text()='Evolve Admin']");

        	public static final By BASE_PRDORDUCT_RERPORTS = By
        			.xpath("//*[@id='pageBody']/form//table//td/a[text()='Base Product Reports']");

        	public static final By SELECT_IBN_TEXT_BOX = By.id("txtResourceKey");

        	public static final By PROCESS_MENu = By.id("processMenu");

        	public static final By VIEW_PRODUCT = By.name("btnViewProduct");

        	public static final By PUBLICATION_DATE = By.name("PublicationDate");

        	public static final By PUBLICATION_STATUS = By.name("PublishingStatus");

        	public static final By EDIT_BUTTON_PRORDUCT = By.name("btnEdit");

        	public static final By PRODUCT_RESOURCE_MESSAGE = By.id("desc");

        	public static final By UN_AFFIILIATED_CHECK_BOX = By.name("unaffiliated");

        	public static final By STREET_ADDRESS = By.id("billing-address1");

        	public static final By CITY = By.id("billing-city");

        	public static final By STATE = By.name("addresses.2.state");

        	public static final By BILLING_PIN_CODE = By.id("billing-postalCode");

        	public static final By USE_THIS_ADDRESS = By
        			.id("//button[text()='Use This Address']");

        	public static final By DOWNLOAD_ACCESS_CODE = By.id("download");

        	public static final By DOWNLOAD_ACCESS_CODE_TXT = By.xpath("//button//span[text()='Download']");

        	public static final By ACCESS_CODE =By.name("accessCode");

        	public static final By SUB_TOTAL = By.xpath("//*[@id='pageLayout-body-inner-most']//td[@class='totalamount strong']");

        	public static final By REGISTERED_USER_AGGREMENT = By.id("checkbox-registered");

        	public static final By ENTER_AS_IND_BUTTON = By.xpath("//*[@id='set']//button[text()='Enter as Independent Self-Study']");*/

	public static final By ENTER_INSTRUCTORS = By.xpath(".//*[@id='set']/li/div/div/button[1]");

	public static final By MODAL_CONTINUE_BUTTON = By.xpath(".//*[@id='modalCourseId-enter']//button[text()='Continue']");

	/*public static final By MODAL_HEADER = By.xpath("//*[@id='modalSelfStudy']/h1");

        	public static final By MODAL_CONFORMATION = By.xpath("//*[@id='modalSelfStudy']/p[1]");
	 */
	/*public static final By CHECK_BOX_MESSAGE = By.xpath("//*[@id='modalSelfStudy']/form/p[1]/label");*/

	public static final By MODAL_CHECK_BOX = By.id("pendingSelfStudy-yes");

	/*public static final By MODAL_CANCEL_BUTTON = By.xpath("//*[@id='modalSelfStudy']/form/p//button[text()='Cancel']");

        	public static final By MODAL_CONFORM_BUTTON = By.id("pendingSelfStudy-confirm");

        	public static final By ONLIE_COURSE_ID = By.id("//*[@id='set']/li[1]//div/span[@class='course_ia info']");
	 */
	public static final By ENTER_LATER = By.xpath(".//*[@id='modalCourseId-enter']/form/p/button[2]");

	/*public static final By ONLINE_COURSE_LINK = By.xpath("//*[@id='set']/li[1]/div/div/a");
        	public static final By COURSE_TITLE = By.id("courseTitle");
	 */

	public static final By refresh_Btn=By.xpath(".//*[@id='el-pane']/div/div/a[text()=' Refresh']");
	public static final By courseIDLink_InUsers_ContentList=By.xpath(".//*[@id='set']/li/div/div/a");
	//public static final By refresh_Btn=By.linkText(" Refresh");
	public static final By resources_Library_Lnk=By.xpath(".//*[@id='course-sidebar']/ul[2]/li[2]/a");
	public static final By redeem_AcessCode_txt=By.xpath(".//*[@id='ajax-modal']/div/form[1]/input[3]");
	public static final By protectedContent_PopUp_cancel_Btn=By.xpath(".//*[@id='ajax-modal']/div[3]/button");
	public static final By ENTER_LATER_BUTTON = By.xpath(".//*[@id='modalCourseId-enter']/form/p/button[text()='Enter Later']");
	public static final By MODAL_DIV_H2 = By.id("colorbox");
	public static final By protectedContent_Title=By.id("myModalLabel");
	public static final By REVIEWANDSUBMIT = By.xpath(".//*[@id='pageLayout-body-inner-most']//div[text()='1. Review & Submit']");
	public static final By CONFIRMATION = By.xpath(".//*[@id='pageLayout-body-inner-most']//div[text()='2. Confirmation']");
	public static final By GENERATE_COURSE_ID = By.id("generateCourseId");
	public static final By COURSE_ID_TEXT = By.xpath(".//*[@id='getCommentsPanel']/ul/li");
	public static final By COURSE_ADMIN_COURSE_LINK = By.linkText("Courses");
	public static final By ADD_COURSE_BUTTON = By.id("a-add-group");
	public static final By GROUP_Id = By.name("groupId");
	public static final By GROUP_NAME = By.name("name");
	public static final By GROUP_ADD_LIB = By.name("state");
	public static final By GROUP_LIB =By.name("libraries");
	public static final By GROUP_SYSTEM = By.name("system-new");
	public static final By SEARCH_BOX = By.id("input-search");
	public static final By SUBMIT_BUTTON = By.xpath(".//*[@id='form-group']/fieldset//button[text()='Submit']");
	public static final By LOCK_SYMBOL = By.xpath(".//*[@id='course-sidebar']/ul[2]/li[1]/a/span[1]/i");
	public static final By COURSE_LINK = By.xpath(".//*[@id='course-sidebar']/ul//li/a//span[text()='Course']");
	public static final By Glossary = By.xpath(".//*[@id='course-sidebar']/ul//li/a//span[text()='Glossary']");

	//new objects for course link in content home page
	public static final By Course_in_ContentHome_page=By.linkText("Course");
	public static final By CONTENT_HOME = By.xpath(".//a[text()='Content Home']");
	public static final By COURSE_EDIT = By.xpath(".//a[text()='Edit  ']");

	public static final By COURSE_CONFORM_BOX = By.id("cboxWrapper");

	public static final By CONFIRM_BUTTON  = By.id("pendingSelfStudy-confirm");

	public static final By COURSE_LINK_AFTER_ENTER = By.xpath(".//*[@id='set']/li/div/div/a");

	public static final By COURSE_CONTENT= By.xpath(".//*[@id='course-sidebar']/ul[2]/li/ul/li[2]/a/span[2]");

	public static final By COURSR_CONTENT_LINK = By.xpath(".//*[@id='courseContentLink-73494118']");

	public static By totalPriceInReceiptPage=By.xpath(".//*[@id='pageLayout-body-inner-most']//td/span[@class='totalamount']");

	public static final By ENTER_INSTRUCTOR_COURSE_ID_BUTTON = By.xpath(".//button[@class='bold button content-list-orange']");

	public static final By OK_MESSAGE = By.xpath(".//*[@id='modalCourseId-okay']/h1");
	//
	public static final By OK_BUTTON = By.xpath(".//button[@class='bold button uppercase']");





	//Test ID 9797
	public static By Nursing_course_id=By.xpath(".//*[@id='set']/li/div/div/span[text()='COURSE ID: 1053_global_0001']");
	public static By Nursing_course_link=By.xpath(".//*[@id='set']//a[text()='Nursing Research Online for Understanding Nursing Research, 4th Edition']");

	//gmail login
	//public static By Gmail_total_frame=By.xpath(".//*[@class='a3s']/div/blockquote");
	public static By Gmail_total_frame_top = By.xpath(".//*[@class='a3s']/div/blockquote");
	public static By Gmail_total_frame=By.xpath("(.//*[@class='a3s'])[last() - 1]/div/blockquote");
	public static By Gmail_username =By.xpath(".//*[@id='Email']");
	public static By Gmail_password =By.xpath(".//*[@id='Passwd']");
	public static By Gmail_next = By.xpath(".//*[@id='next']");
	public static By Gmail_login=By.xpath(".//*[@id='signIn']");
	public static By Gmail_Inbox_msg=By.xpath(".//*[@id=':3r']");
	public static By Gmail_Inbox=By.xpath(".//*[@id=':59']");
	public static By Gmail_Signout_button=By.xpath(".//*[@id='gb']/div[1]/div[1]/div/div[3]/div[1]/a[text()='qaevolve@gmail.com']");
	public static By Gmail_Logout=By.xpath(".//*[@id='gb_71']");
	public static By Gmail_searchbox=By.id("gbqfq");
	public static By Gmail_search_button=By.xpath(".//*[@id='gbqfb']");
	public static By Gmail_verify_mail=By.xpath(".//*[@class='xY a4W']/div/div/div[2]/span");
	public static By Gmail_Inbox_frame=By.xpath(".//*[@class='a3s']/div/blockquote/div[1]");
	public static By Gmail_content=By.xpath(".//*[@class='a3s']/div/blockquote/div[1]/span[2]/span/span[1]");
	public static By Gmail_Inbox_clickhere=By.xpath(".//*[@class='a3s']/div/blockquote/div[1]/span[2]/span/span[1]/span[2]/a/span");
	//public static By Email_Inbox_clickhere = By.xpath(".//a[contains(@href,'pwdReset')]");
	public static By Email_Inbox_clickhere = By.xpath(".//*[text()='Click Here']");
	public static By Email_selection=By.xpath(".//*[@id='mail.hsplit.grid']/div[1]/table[30]/tbody/tr");
	public static By Email_forward=By.id("mail-edit-forward");
	public static By Email_Forwarding_To=By.xpath(".//*[@id='to']");
	public static By Email_Send=By.xpath(".//*[@id='mail_new-send']");

	//Test ID 15471
	public static By Admin_Password_reminder=By.xpath(".//*[@id='pageBody']//a[text()='Password Reminder']");
	public static By Admin_Password_firstname=By.xpath(".//*[@id='firstName']");
	public static By Admin_Password_lastname=By.xpath(".//*[@id='lastName']");
	public static By Admin_Password_EmailId=By.xpath(".//*[@id='email']");
	public static By Admin_Password_submit=By.xpath(".//*[@id='userCredential']//input[@type='image']");
	public static By Admin_Password_Errmsg=By.xpath(".//*[@id='userCredential.errors']");
	public static By Admin_Password_Errmsg1=By.xpath(".//*[@id='pageBody']//font[@color='red']");	
	public static By Admin_Password_breadcrumb=By.xpath(".//*[@id='pageBody']/table[@class='drkhighlight']");
	public static By Admin_Password_reset=By.xpath(".//*[@id='pageBody']/form/table/tbody/tr[1]/td[1]/img");
	public static By Admin_Password_username=By.xpath(".//*[@id='pageBody']//strong");
	public static By Admin_Password_newpassword=By.xpath(".//*[@id='pageBody']//input[@name='password']");
	public static By Admin_Password_conformpassword=By.xpath(".//*[@id='pageBody']//input[@name='confirmPassword']");
	public static By Admin_Password_newsubmit=By.xpath(".//*[@id='pageBody']//input[@type='image']");
	public static By Admin_Password_Errmsg2=By.xpath(".//*[@id='pageBody']//font[text()='You have used this password before. Please choose a new password.']");
	public static By Admin_Password_Errmsg3=By.xpath(".//*[@id='pageBody']//font[text()='Your new password cannot contain your name, department or company name. Please try again.']");
	public static By Admin_Password_Errmsg4=By.xpath(".//*[@id='pageBody']//font[text()='Your password must contain at least one digit, one uppercase character and one lowercase character. Please try again']");
	public static By Admin_Password_Errmsg5=By.xpath(".//*[@id='pageBody']//font[text()='Your password must contain at least 7 characters. Please try again.']");
	public static By Admin_Password_Succmsg=By.xpath(".//*[@id='pageBody']//font[text()='Your password has been successfully reset. Please login below.']");
	public static By Admin_Login_password=By.xpath(".//*[@id='password']");


	//testcase - 15476


	public static By Admin_Evolve_Admin_AdminPage=By.xpath(".//*[@id='editAdmin']/table/tbody/tr[1]/td[2]/p/b[text()='Add Administrator']");
	public static By Admin_Evolve_Admin_Enable=By.xpath(".//*[@id='editAdmin']/table/tbody/tr[3]/td[2]/input[@type='checkbox']");
	public static By Admin_Evolve_Admin_Firstname=By.xpath(".//*[@id='editAdmin']/table/tbody/tr[4]/td[2]/input[@name='firstName']");
	public static By Admin_Evolve_Admin_Lastname=By.xpath(".//*[@id='editAdmin']/table/tbody/tr[5]/td[2]/input[@name='lastName']");
	public static By Admin_Evolve_Admin_Email=By.xpath(".//*[@id='editAdmin']/table/tbody/tr[6]/td[2]/input[@name='email']");
	public static By Admin_Evolve_Admin_Dept=By.xpath(".//*[@id='editAdmin']/table/tbody/tr[7]/td[2]/input[@name='department']");
	public static By Admin_Evolve_Admin_User=By.xpath(".//*[@id='editAdmin']/table/tbody/tr[8]/td[2]/input[@name='username']");
	public static By Admin_Evolve_Admin_Password=By.xpath(".//*[@id='editAdmin']/table/tbody/tr[9]/td[2]/input[@name='password']");
	public static By Admin_Evolve_Admin_ForcePW=By.xpath(".//*[@id='editAdmin']/table/tbody/tr[9]/td[3]/input[@name='forcechangepwd']");
	public static By Admin_Evolve_Admin_Roles=By.xpath(".//*[@id='privileges']");
	public static By Admin_Evolve_Admin_Maintainproducts=By.xpath(".//*[@id='privileges']/input[@name='maintainProducts']");
	public static By Admin_Evolve_Admin_Create=By.xpath(".//*[@id='editAdmin']/table/tbody/tr[16]/td[2]/input[@name='Create']");
	public static By Admin_Evolve_Admin_succmsg=By.xpath(".//*[@id='createMessage']/td[2]/p/b/font[text()='Account created successfully.']");

	public static By Admin_Evolve_Admin_Evolvecrumb=By.xpath(".//*[@id='pageBody']/table[1]/tbody/tr/td/a[text()='Evolve Admin']");

	public static By Admin_Evolve_Admin_Enabled=By.xpath(".//*[@id='evolve_adminlist_table']/tbody/tr[9]/td[9][text()='Enabled']");
	public static By Admin_Evolve_Admin_userlink=By.xpath(".//*[@id='evolve_adminlist_table']/tbody/tr/td[3]/a");


	public static By Admin_Evolve_Admin_Editpage=By.xpath(".//*[@id='editAdmin']/table/tbody/tr[1]/td[2]/p/b[text()='Edit Administrator']");
	public static By Admin_Evolve_Admin_Edituser=By.xpath(".//*[@id='editAdmin']/table/tbody/tr[4]/td[2]/strong");
	public static By Admin_Evolve_Admin_Editfirst=By.xpath(".//*[@id='editAdmin']/table/tbody/tr[5]/td[2]/input[@name='firstName']");
	public static By Admin_Evolve_Admin_Editlast=By.xpath(".//*[@id='editAdmin']/table/tbody/tr[6]/td[2]/input[@name='lastName']");
	public static By Admin_Evolve_Admin_Editemail=By.xpath(".//*[@id='editAdmin']/table/tbody/tr[7]/td[2]/input[@name='email']");
	public static By Admin_Evolve_Admin_Editpwd=By.xpath(".//*[@id='passwordlbl']");
	public static By Admin_Evolve_Admin_Editchk=By.xpath(".//*[@id='privileges']/img[2]");
	public static By allProductHeadingsList=By.xpath(".//*[@id='pageBody']//td[contains(@class,'highlight')]/b");
	public static By allProductList=By.xpath(".//*[@id='pageBody']//td/a");
	public static By Admin_Evolve_Manageadmin_table=By.xpath(".//*[@id='evolve_adminlist_table']/tbody/tr");
	public static String user1=".//*[@id='evolve_adminlist_table']/tbody/tr[";
	public static String user2="]/td[3]/a";
	public static String verify1=".//*[@id='evolve_adminlist_table']//td[text()='";
	public static String verify2="']/following-sibling::td[2]";
	public static String verify3="']/following-sibling::td[5]";


	/*public static final By USER_MY_EVOLVE_TAB = By.xpath(".//*[@id='div-resources']//a[text()='Evolve Catalog']");
    public static final By courseIDLink_InUsers_ContentList=By.xpath(".//*[@id='set']/li/div/div/a");
    public static final By refresh_Btn=By.linkText(" Refresh");
    public static final By resources_Library_Lnk=By.xpath("//*[@id='course-sidebar']/ul[2]/li[2]/a/span[2]");
    public static final By redeem_AcessCode_txt=By.xpath("//*[@id='ajax-modal']/div/form[1]/input[3]");
    public static final By protectedContent_PopUp_cancel_Btn=By.xpath(".//*[@id='ajax-modal']/div[3]/button");
	 */



	//---------TC_15565---------------------------------------------------------------------//

	public static final By rostered_CourseId=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/p/span");
	public static final By  Email_Only_To_Me_RadioBtn=By.xpath(".//*[@id='submit-noemail'][@value='false']");
	public static final By done_Btn_In_rosterpage=By.xpath(".//button[text()='Done']");
	public static final By contentList_courseID=By.id("el-pane");
	public static final By listOfCourseIDs=By.xpath(".//*[@id='set']/li[contains(@class,'set setclosed')]/div[contains(@class,'clearfix')]/div[contains(@class,'item platform_product')]/span[contains(@class,'course_ia info')]");
	public static final By listOfProductIDs=By.xpath(".//*[@id='set']/li[contains(@class,'set setclosed')]/div[contains(@class,'clearfix')]/div[contains(@class,'item platform_product')]/span[contains(@class,'course_ia info')]//following-sibling::a");

	//public static By Student_register_UseAdress_btn=By.xpath("html/body/div[@class='modal-div']/table/tbody/tr/td[1]/div/button");//html/body/div[3]/table/tbody/tr/td[1]/div/button


	//================TC-8561=================================

	public final static By ONLINE_COURSE = By.xpath(".//*[@id='lowershelf']//td//img[@class='image6 unclicked']");
	public final static By GET_STUDENT_INTO_YOUR_PATH =By.xpath(".//*[@id='lowershelf']/div[8]/ul/li[2]/a");
	//public final static By CLASS_ROSTER = By.xpath(".//*[@id='pageLayout-body-inner-most']//a[text()='Submitting your Class Roster']");
	public final static By CLASS_ROSTER = By.xpath(".//a[@href='/cs/submitRoster.html']");
	public final static By TC_8561_ErrorMessage = By.id("ext-gen7");
	public final static By TC_8561_CourseID=By.xpath(".//*[@id='set']/li[1]/div[1]/div/span[2]");
	public final static By selection_Of_Role=By.name("users.1.roles.0");
	public final static By Email_To_Me_RadioBtn=By.id("submit-doemail");
	public final static By sucess_Message=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/p");
	public final static By verifyText_In_Email=By.xpath(".//*[@id='mail.hsplit.grid']/div[1]/table[7]/tbody/tr/td[5]");
	public final static By searchroster_lnk=By.linkText("Search Rosters");
	public final static By courseID_inAdminPage=By.xpath(".//*[@id='pageBody']/form/table/tbody/tr/td/table/tbody/tr[8]/td/input[@name='course']");
	public final static By search_Btn_in_Admin=By.xpath(".//*[@id='pageBody']/form/table/tbody/tr[3]/td/table/tbody/tr[9]/td[2]/input");
	public final static By verifyexistence_of_rosteredID=By.xpath(".//*[@id='pageBody']//tr[contains(@valign,'top')]//tr[4]/td/a[contains(@text()='104882_tfaculty208_1018')]");
	public static By educator_courseSearch_title1=By.xpath(".//*[@id='set']/li/div/div/span[text()='COURSE ID: 104882_tfaculty208_1018']/following-sibling::a");
	public final static By roster_And_Teams_lnk=By.linkText("Roster & Teams");
	public static By filter_inbox=By.id("input-search");
	public final static By verifyTextField=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(text(),'Enter your Course ID')]");
	public final static By verifyrosterfield=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[@class='placeholder-set']");
	public final static By Email_only_me=By.xpath(".//div[@class='accesscoderadios rounded']/div/input[@id='submit-noemail']");


	public static By Roster_done=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/button[text()='Done']");

	//public static By Student_register_UseAdress_btn=By.xpath("html/body/div[3]/table/tbody/tr/td[1]/div/button");//html/body/div[3]/table/tbody/tr/td[1]/div/button
	public static By Student_register_UseAdress_btn=By.xpath(".//div[@class='modal-div']//button[1]");
	//Test ID 10437

	public static By administrationPortal_lnk=By.linkText("ADMINISTRATION PORTAL");
	public static By enrollment_Lnk=By.linkText("Enrollments");
	public static int index =0;
	public static By username = By.name("0.username");
	public static By resourceId = By.name("0.resourceId");
	public static By role = By.name("0.role");

	public static By username1 = By.name("1.username");
	public static By resourceId1 = By.name("1.resourceId");
	public static By role1 = By.name("1.role");

	public static By username2 = By.name("2.username");
	public static By resourceId2 = By.name("2.resourceId");
	public static By role2 = By.name("2.role");
	public static By submit_Bt=By.xpath(".//*[@id='enrollForm']/div/input[1]");
	public static By visible_Text=By.xpath(".//*[@id='pageLayout-body-inner-most']/dl/dd[1]/span[2]");
	public static By visible_Text2=By.xpath(".//*[@id='pageLayout-body-inner-most']/dl/dd[2]/span[2]");
	public static By visible_Text3=By.xpath(".//*[@id='pageLayout-body-inner-most']/dl/dd[3]/span[2]");

	//Adoption Search.................
	public static By Admin_Apprstatus_BeforeChk=By.xpath("html/body/table/tbody/tr[2]/td/div/table[1]/tbody/tr[2]/td/table/tbody/tr[6]/td/table/tbody/tr[1]/td[10]/div[text()='Pending']");
	public static By Admin_AdoptionSerach_Approve_chk=By.xpath("html/body/table/tbody/tr[2]/td/div/table[1]/tbody/tr[2]/td/table/tbody/tr[6]/td/table/tbody/tr[1]/td[2]/span[1]/input");
	public static By Admin_Submit_btn=By.id("submitAdoptionSrch");//By.xpath("//*[@id='submitAdoptionSrch']");
	public static By Admin_Apprstatus_AfterChk=By.xpath("html/body/table/tbody/tr[2]/td/div/table[1]/tbody/tr[2]/td/table/tbody/tr[6]/td/table/tbody/tr[1]/td[10]/div[text()='Approved']");
	public static By Admin_Fulfil_chk=By.xpath("html/body/table/tbody/tr[2]/td/div/table[1]/tbody/tr[2]/td/table/tbody/tr[6]/td/table/tbody/tr[1]/td[2]/span[2]/input");
	public static By Admin_Email_chk=By.xpath("html/body/table/tbody/tr[2]/td/div/table[1]/tbody/tr[2]/td/table/tbody/tr[6]/td/table/tbody/tr[1]/td[2]/span[3]/input");
	public static By Educator_CourseId_search=By.xpath(".//*[@id='set']//div/span[text()='COURSE ID: 120489_global_0002']");
	public static By Educator_CourseId_Click=By.xpath(".//*[@id='set']//div/span[text()='COURSE ID: 120489_global_0002']/following-sibling::a");
	public static By Student_CourseId_search=By.xpath(".//*[@id='set']//div/span[text()='COURSE ID: 120489_global_0001']");
	public static By Student_CourseId_Click=By.xpath(".//*[@id='set']//div/span[text()='COURSE ID: 120489_global_0001']/following-sibling::a");

	public static By Educator_CourseId_Title=By.xpath("//*[@id='courseTitle']");
	public static By RequestProduct=By.xpath("//*[@id='add-to-cart']");

	//TC-8571 : Global Student.

	public static By Student_Product_Cost= By.xpath(".//div[@id='tab-relayout']/div/div[5]/div[@class='cost']/p/span");
	public static By Student_product_Edition_Price=By.xpath(".//*[@id='"+ReplaceString1+"']/div[5]");
	public static By Student_product_Edition_Title=By.xpath(".//*[@id='"+ReplaceString1+"']/div[3]/div[1]/a");

	public static By Student_Product_ISBN = By.xpath(".//*[@class='cartproductdetails']");
	public static By Student_Update_Account = By.xpath(".//*[@id='pageLayout-body-inner-most']/div/descendant::*/h1");
	public static By Student_Update_Account_Institute_State = By.xpath(".//*[@id='institution-state']");
	public static By Student_Update_Account_Institute_City = By.xpath(".//*[@id='institution-state']");
	public static By Student_Update_Account_Address2 = By.xpath(".//*[@id='address0-address2']");
	public static By Student_Update_Account_City = By.xpath(".//*[@id='address0-town']");
	public static By Student_Update_Account_State = By.xpath(".//*[@id='address0-province']");
	public static By Student_Update_Account_ZipCode = By.xpath(".//*[@id='address0-zipCode']");
	public static By Student_Update_Account_ReviewAndSubmit_Title = By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]");
	public static By Student_Update_Account_PopUp = By.xpath(".//*[@id='toPopup']/button");
	public static By Student_Update_Account_GraduationYear  = By.xpath("//*[@id='select-graduation-year']");
	public static By Student_Update_Account_StudentID = By.xpath(".//*[@id='address0-studentId']");
	public static By Student_Update_Account_MyEvolveTab = By.xpath(".//li/a[contains(text(),'My Evolve')]");

	public static By Student_Update_Account_UserContentList = By.xpath(".//ul[@class='folder-list']/li");
	public static By Student_Update_Account_UserContent =By.xpath(".//ul[@class='folder-list']/li['"+ReplaceString1+"']/descendant::*/span[2]");
	public static By Student_Update_Account_ContentLink =By.xpath(".//ul[@class='folder-list']/li['"+ReplaceString1+"']/descendant::*/span[2]/following-sibling::*");

	public static By Student_Update_Account_ResourcesFolder =By.xpath(".//*[@id='course-sidebar']//li/a/span[text()='Resources']");
	public static By Student_Update_Account_ResourcesFolder_SubfolderList =By.xpath(".//*[@id='content-area']//div//ul/li//div[contains(@class,'content-info span20')]/a");
	public static By Student_Update_Account_ResourcesFolder_SubFolder =By.xpath(".//*[@id='content-area']//div//ul/li//div[contains(@class,'content-info span20')]/a[text()='Student Resources']");
	public static By Student_Update_Account_ResourcesFolder_SubfolderName =By.xpath(".//div[@ng-show='isListContentView()']/ul/li["+ReplaceString1+"]/descendant::*/following-sibling::*/a");
	public static By Student_Instructor_MainPage =By.xpath(".//div[@class='mainlinks']/a[contains(text(),'Main Page')]");
	public static By Student_ResourcesFolder_SubFolder_Folder=By.xpath(".//*[@id='course-sidebar']//a/span[text()='Glossary']");
	public static By Student_ResourcesFolder_SubFolder_Folder_Heading=By.xpath(".//*[@id='content-area']//h2[contains(@class,'content-title')]/a");
	public static By Student_ResourcesFolder_SubFolder_chapter=By.xpath(".//*[@id='course-sidebar']/ul[2]/li/ul/li[2]/ul/li[3]/a/span[2]");

	//..............E-commerce-15597.......................................
	public static By EVOLVE_ADMIN_VIEWPROFILE_LINK=By.linkText("View/Edit Evolve User Profile");
	//public static By MYACCOUNT_ORDERHISTORY=By.xpath("//*[@id='account-menu']/ul/li/a[text()='Order History']");
	public static By MYACCOUNT_ORDERHISTORY=By.xpath(".//a[text()='ORDER HISTORY']");
	// public static By EVOLVE_ADMIN_VIEWPROFILE_LINK=By.xpath("//*[@id='pageBody']/form/table/tbody/tr[5]/td/table[5]/tbody/tr[2]/td/a");
	public static By ADMIN_VIEWPROFILE_FIRSTNAME=By.xpath(".//*[@id='pageBody']//form[@name='searchForm']//input[@name='firstname']");
	public static By ADMIN_VIEWPROFILE_LASTNAME=By.xpath(".//*[@id='pageBody']//form[@name='searchForm']//input[@name='lastname']");
	public static By ADMIN_VIEWPROFILE_USERNAME=By.xpath(".//*[@id='pageBody']//form[@name='searchForm']//input[@name='username']");
	public static By ADMIN_VIEWPROFILE_EMAIL=By.xpath(".//*[@id='pageBody']//form[@name='searchForm']//input[@name='email']");
	public static By ADMIN_VIEWPROFILE_SEARCH=By.xpath(".//*[@id='pageBody']//form[@name='searchForm']//input[@value='Search']");
	public static By ADMIN_VIEWPROFILE_SEARCHRESULT=By.xpath(".//*[@id='evolve_usersearchlist_table']/tbody/tr/td[1]");
	public static By ADMIN_VIEWPROFILE_ORDERHITSORY=By.xpath(".//*[@id='orderHistoryBtn']");
	public static By MANTAIN_PPM_DATA=By.name("maintainLoadData");
	public static By MANAGEPRIVILEGES=By.id("editPrivilegesLink");
	public static By MANAGEPRIVILEGES_PREORDER=By.xpath(".//*[@id='privileges']/input[23]");
	public static By MANAGEPRIVILEGES_MAINTAIN=By.xpath(".//*[@id='privileges']/input[22]");
	public static By MANAGEPRIVILEGES_SAVE=By.xpath("html/body//div[@class='ui-dialog-buttonset']/button/span[text()='Save']");

	public static final By ISBN_NUMBER = By.xpath(".//*[@id='orderDetails']//table//table//table//table//tr//td/text()");

	//public static By CART=By.xpath(".//*[@id='page']//a[@class='cart nav-text relative']");
	public static By CART=By.xpath(".//a[@href='/cs/viewCart']");
	public static By CARTDELETE=By.xpath(".//*[@class='row']//a[text()='Delete']");
	public static By CANCEL_PREORDER_MESSAGE=By.xpath(".//*[@id='preorder-dialog-confirm']//div[@class='popupLabel1']/b");
	public static By CANCEL_PREORDER_NOTE=By.xpath(".//*[@id='lblProcessingNotes']");
	public static By CANCEL_PREORDER_SAVE=By.xpath("html/body/div[1]/div[3]/div/button[1]");
	public static By CANCEL_PREORDER_CANCEL=By.xpath("html/body/div[1]/div[3]/div/button[2]");
	public static By CANCEL_PREORDER_ENTERMESSAGE=By.xpath(".//*[@id='processingNotes']");
	public static By CANCEL_PREORDER_ERRORMESSAGE=By.xpath(".//*[@id='msg-notes-failure']");
	public static By CANCEL_PREORDER_SAVEMESSAGE=By.xpath(".//*[@id='msg-save-success']");
	public static By CANCEL_PREORDER_BUBBLE=By.xpath(".//*[@id='orderDetails']//td[contains(@align,'right')]/img");
	public static By CANCEL_PREORDER_BUBBLEMESSAGE=By.xpath(".//*[@id='cancelledprocssingnotes']");
	public static By CANCEL_PREORDER_BUBBLECLOSE=By.xpath(".//*[@id='top_row']/td[3]/img");
	public static By CANCEL_PREORDER_STATUS=By.xpath(".//*[@id='orderDetails']//td/span[text()='Cancelled']");
	public static By CANCEL_PREORDER_POPUPHEADER=By.xpath(".//*[@id='ui-dialog-title-preorder-dialog-confirm']");

	// public static By SEARCHPREORDER=By.xpath("//*[@id='pageBody']/form/table/tbody//td/a[text()=' Search Pre-order/Generate Report ']");
	public static By SEARCHPREORDER=By.linkText("Search Pre-order/Generate Report");

	public static By ORDER_SUBMIT_DATE=By.xpath("//*[@id='preorderSearchContent']//b[text()='Order Submit Date']");
	public static By PREORDER_FULFILLMENT_DATE=By.xpath("//*[@id='preorderSearchContent']/div/b[text()='Pre-order Fulfillment Date']");

	public static By ORDER_SUBMIT_STARTDATE_CALENDER=By.xpath(".//*[@id='preorderSearchContent']/div[6]/a/img");
	public static By ORDER_SUBMIT_ENDDATE_CALENDER=By.xpath(".//*[@id='preorderSearchContent']/div[7]/a/img");
	public static By ORDER_SUBMIT_STARTDATE_INPUT=By.xpath(".//*[@id='orderFromDate']");
	public static By ORDER_SUBMIT_ENDDATE_INPUT=By.xpath(".//*[@id='orderToDate']");
	public static By SELECT_STARTDATE=By.id("scwCell_25");           
	public static By SELECT_ENDDATE=By.id("scwCell_30");

	public static By PREORDER_FULFILLMENT_STARTDATE_CALENDER=By.xpath(".//*[@id='preorderSearchContent']/div[13]/a/img");
	public static By PREORDER_FULFILLMENT_ENDDATE_CALENDER=By.xpath(".//*[@id='preorderSearchContent']/div[14]/a/img");
	public static By PREORDER_FULFILLMENT_STARTDATE_INPUT=By.xpath(".//*[@id='fulfillmentFromDate']");
	public static By PREORDER_FULFILLMENT_ENDDATE_INPUT=By.xpath(".//*[@id='fulfillmentToDate']");
	public static By CALENDER_TODAYSDATE=By.xpath(".//*[@id='scw']//tr//td[@id='scwFoot']");
	public static By STATUS=By.xpath(".//*[@id='preorderSearchContent']//b[text()='Status']");
	public static By STATUS_INPUT=By.xpath("//*[@id='status']");
	public static By ORDERID=By.xpath(".//*[@id='preorderSearchContent']//b[text()='Order Id']");
	public static By ORDERID_INPUT=By.id("orderId");
	public static By ISBN=By.xpath(".//*[@id='preorderSearchContent']//b[text()='ISBN']");
	public static By ISBN_INPUT=By.id("isbn");
	public static By USERNAME=By.xpath(".//*[@id='preorderSearchContent']//b[text()='Username']");
	public static By USERNAME_INPUT=By.id("userId");
	public static By PREORDER_SEARCH_BUTTON=By.id("search");
	public static By preOrderTable=By.id("preOrderSearchResults");
	public static By CALENDER_STARTDATE_YEAR=By.xpath(".//*[@id='scwYears']");
	public static By NO_PREORDER=By.xpath(".//*[@id='noResultsSpan']");
	public static By PREORDER_ERRORMSSG=By.xpath(".//*[@id='errorMsgForPreOrderSearch']");
	
	public static By PREORDER_JOB_RESULTS = By.xpath(".//pre");



	//Test Id 10433
	public static By Admin_Useper_code=By.xpath(".//*[@id='usesperkey']");
	public static By Admin_Daysof_Access=By.xpath(".//*[@id='daysafteractivation']");
	public static By Protection_scheme_id=By.xpath(".//*[@id='protectionschemeselectedid']");
	public static By Reedem_success_Msg=By.xpath(".//*[@id='msg-accesscodes-success']");
	public static By Manage_access_codes=By.xpath(".//*[@id='product-tabs']/ul/li[7]/a[text()='Manage Access Codes']");
	public static By Reedem_Access_code=By.xpath(".//*[@id='accessCodeSetContainer']/table/tbody/tr[1]/td[1]/span/a");
	public static By Reedem_button=By.xpath(".//*[@id='ajax-modal']/div[2]/form[1]/button");
	public static By course_title=By.xpath(".//*[@id='courseTitle']");

	//test case 15461
	public static By VIEWPROFILE_LINK=By.linkText("View/Edit Evolve User Profile");
	//public static By VIEWPROFILE_LINK=By.xpath(".//*[@id='pageBody']/form/table/tbody/tr[5]/td/table[5]/tbody/tr[2]/td/a");
	public static By frameName=By.className("cboxIframe");
	public static By frameCourseIDRequired=By.xpath("html/body/div[3]/h1");
	public static By frameEnterLaterButton=By.xpath("html/body/div[3]/form/p[3]/button[2]");
	public static By userContentList=By.xpath(".//*[@id='set']//div[contains(@class,'clearfix')]/div/a");
	public static String course1=ReadingExcel.columnDataByHeaderName("course1", "TC-15461", testDataPath);
	public static String course2=ReadingExcel.columnDataByHeaderName("course2", "TC-15461", testDataPath);
	public static By contentLink1=By.xpath(".//*[@id='set']/li//div[contains(@class,'item platform_product')]/a[text()='"+course1+"']");
	public static By contentLink2=By.xpath(".//*[@id='set']/li//div[contains(@class,'item platform_product')]/a[text()='"+course2+"']");
	//public static By

	//test case 10440
	public static By editableCourseID=By.xpath(".//*[@id='courseTitle']//input[@name='title']");



	//TestID-10438
	public static By Admin_Search_Rosters=By.linkText("Search Rosters");
	public static By Roster_Course_ID=By.xpath(".//*[@id='pageBody']//input[contains(@name, 'course')]");
	public static By Roster_Search=By.xpath(".//*[@id='pageBody']//input[contains(@type,'submit')]");
	public static By Course_ID_Link=By.xpath(".//*[@id='pageBody']/table/tbody/tr[3]/td/table/tbody/tr[3]/td[1]/a");
	//public static By Rosters_Teams=By.xpath(".//*[@id='course-sidebar']/ul[1]/li[4]/a[text()='Roster & Teams']");
	public static By Rosters_Teams=By.xpath(".//a[@href='#/tool/roster']");
	public static By Submit_Roster=By.xpath(".//*[@id='enroll-students']");
	public static By Roster_field=By.xpath(".//*[@id='field-roster']");
	public static By PreviewRoster_AsssignRoles=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/form//button[text()='Preview Roster & Assign Roles']");
	public static By Role_selection=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/form/div[2]/ul/li/select");
	public static By Role_Selection1=By.xpath("//*[@id='pageLayout-body-inner-most']/form/ul/li[1]/select");
	public static By Role_Selection2=By.xpath("//*[@id='pageLayout-body-inner-most']/form/ul/li[2]/select");
	public static By Role_Selection3=By.xpath("//*[@id='pageLayout-body-inner-most']/form/ul/li[3]/select");
	public static By Email_radiobutton=By.xpath(".//*[@id='submit-doemail']");
	public static By Submit_This_Roster=By.xpath(".//*[@id='pageLayout-body-inner-most']/form/div/button[text()='Submit This Roster']");
	public static By Roster_success_message=By.xpath(".//*[@id='pageLayout-body-inner-most']");
	public static By Roster_Cross_button=By.xpath(".//*[@id='submitRosterModal']/div[1]/button");
	public static By Roster_Evolve_CourseId=By.xpath(".//*[@id='set']/li/div/div/span[2]");
	public static By Roster_Evolve_Courselink=By.xpath(".//*[@id='set']/li/div/div/a[text()='Medical Terminology Online for Mastering Healthcare Terminology, 3rd Edition']");
	//public static By Roster_Evolve_Courselink=By.xpath(".//*[@id='set']/li/div/div/a[text()='Medical Terminology Online for Medical Terminology: A Short Course, 6th Edition']");
	//public static By Courses=By.xpath(".//*[@id='course-sidebar']/ul[2]/li[1]/a");
	public static By Courses=By.xpath("(.//*[@id='course-sidebar']//span[contains(text(),'Course')])[2]");
	//public static By Courses=By.xpath(".//*[@id='course-sidebar']//ul[2]/li[2]/a");
	public static By Protected_content=By.xpath(".//*[@id='myModalLabel']");
	public static By Roster_student_details = By.xpath(".//*[@id='pageBody']/form/table/tbody/tr[3]/td/table/tbody/tr/td/table[2]/tbody/tr[2]/td");

	//testID-15599
	//public static By Administration_portal=By.linkText("Administration Portal");
	public static By Administration_portal=By.xpath(".//a[text()='ADMINISTRATION PORTAL']");
	public static By Admin_portal_Courses=By.xpath(".//*[@id='adminSite']//a[text()='Courses']");
	public static By Manage_courses=By.xpath(".//*[@id='stdHeader']");
	public static By Manage_Courses_Filter=By.xpath(".//*[@id='input-search']");
	public static By Group_Id=By.xpath(".//*[@id='groupTable_wrapper']//th[text()='Group Id']");
	public static By Group_Id_details=By.xpath(".//*[@id='groupTable']//tbody//tr");
	//public static By course_tools_Administration=By.xpath(".//*[@id='course-sidebar']//a[text()='Administration']");
	public static By course_tools_Administration=By.xpath(".//*[@id='course-sidebar']//a[@href='#/tool/course-admin']");
	public static By Quick_Enroll=By.xpath(".//*[@id='ui-id-1'][text()='Quick Enroll']");
	public static By Administration_header=By.xpath(".//*[@id='content-area']/div/div[2]/h2[text()='Administration']");
	public static By Administartion_username=By.xpath(".//*[@id='input-users']");
	public static By Administartion_Select_Role=By.xpath(".//*[@id='select-role']");
	public static By Administartion_Default_Role=By.xpath(".//*[@id='select-role']/option[1]");
	public static By Update_Enrollments=By.xpath(".//*[@id='apply-enrollments']");
	//public static By Roster_success=By.xpath("html/body/form[2]/div[1]/span[text()='Success']");
	public static By Roster_success=By.xpath(".//span[text()='Success']");
	//public static By Success_Enroll_update=By.xpath("html/body/form[2]/div[text()='Enrollments updated.']");
	public static By Success_Enroll_update=By.xpath(".//div[text()='Enrollments updated.']");
	//public static By Roster_Ok=By.xpath(".//input[@value='OK']");
	public static By Roster_Ok=By.xpath(".//button[text()='OK']");
	//public static By Rosters_teams=By.xpath(".//*[@id='course-sidebar']/ul[1]/li[4]/a");
	public static By Rosters_teams=By.xpath(".//div[@id='course-sidebar']//li[@id='roster']/a");
	public static By Roster_Oddrow=By.xpath(".//*[@id='rosterTable']/tbody/tr[@class='odd']");
	public static By Roster_evenrow=By.xpath(".//*[@id='rosterTable']/tbody/tr[@class='even']");
	public static By Roster_fullnamecolumn=By.xpath(".//*[@id='rosterTable']/tbody//td[3]");
	public static By Roster_rolecolumn=By.xpath(".//*[@id='rosterTable']/tbody//td[4]");
	public static By Roster_Emailcolumn=By.xpath(".//*[@id='rosterTable']/tbody//td[5]");
	public static By Roster_HasAccesscolumn=By.xpath(".//*[@id='rosterTable']/tbody//td[6]");
	public static By Roster_Table=By.xpath(".//*[@id='rosterTable']/tbody");

	public static By Yescheckbox=By.xpath(".//*[@id='pendingSelfStudy-yes']");
	public static By confirmbutton=By.xpath(".//*[@id='pendingSelfStudy-confirm']");
	public static By courseid_acc=By.xpath(".//*[@id='pendingCourse-courseId']");
	public static By Continue=By.xpath(".//*[@id='modalCourseId-enter']/form/p/button[contains(text(),'Continue')]");
	public static By Okbutton=By.xpath(".//*[@id='modalCourseId-okay']/p[2]/button");
	public static By courseidpendingcoursetext=By.xpath("//*[@id='pendingCourse-courseId']");


	// TestID-9803

	public static By Error_msg2=By.xpath("html/body/div[4]/div[3]/div/div/div/div/div/div[1]/form/div[10]/p[1]");
	public static By Errmsg1=By.xpath("html/body/div[4]/div[3]/div/div/div/div/div/div[1]/form/div[8]/p[2]");
	//public static By Errmsg=By.xpath("html/body/div[4]/div[3]/div/div/div/div/div/div[1]/form/p[3]");
	public static By Errmsg=By.xpath(".//p[@id='ext-gen11']");
	public static By Online_courses=By.xpath(".//*[@id='lowershelf']/table/tbody/tr/td[4]/img");
	//public static By Search_Online_Courses=By.xpath("html/body/div[4]/div[3]/div/div/div/div/div[2]/div[8]/ul/li[1]/form/div/input[1]");
	//public static By Search_Button=By.xpath(".//*[@id='lowershelf']//input[@class='b-submit b-red']");
	public static By Search_Online_Courses=By.xpath(".//form[@action='/cs/search']/input[@type='text']");
	public static By Search_Button=By.xpath(".//form[@action='/cs/search']/button");
	public static By Evolve_Isbn_Number=By.xpath(".//*[@id='pageLayout-body-inner']//div[@class='cartproductdetails']");
	public static By Resource_tool=By.xpath(".//*[@id='resourcestools']");
	public static By Apply=By.xpath(".//*[@id='config-form']/p[5]/button[text()='Apply']");
	public static By Medical_title=By.xpath(".//*[@id='pageLayout-body-inner']//div[@class='carttitle']");
	public static By Evolve_price=By.xpath(".//*[@id='pageLayout-body-inner']//div[@class='price2']");
	public static By Header1=By.xpath(".//*[@id='form-profile']/h3[1]");
	public static By Header2=By.xpath(".//*[@id='form-profile']/h3[2]");
	public static By Error_msg1=By.xpath(".//*[@id='ext-gen9']");
	public static By Institution_Error_msg1=By.xpath(".//*[@id='ext-gen9']");
	public static By Institution_Error_msg2=By.xpath(".//*[@id='ext-gen11']");
	public static By Address_City=By.id("address0-city");
	public static By Address_state=By.id("address0-state");
	public static By Zip_Code=By.xpath(".//*[@id='address0-zipCode']");
	public static By Product_title=By.xpath(".//*[@id='pageLayout-body-inner']//div[@class='carttitle']");
	public static By title = By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[1]/ul/li[2]/div[3]/div[1]/a");
	public static By Isbn_number=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[1]/ul/li[2]/div[3]/div[4]");
	public static By Price =By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[1]/ul/li[2]/div[5]");
	public static By Totalprice=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[4]/div/div[3]/table/tbody/tr[3]/td[2]");
	public static By Total_Price = By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[1]/table/tbody/tr[6]/td[2]/span");
	public static By Accountsettings_username = By.xpath(".//*[@id='form-profile']/div[1]/div[1]/input[@class='span6']"); 
	public static By todays_date=By.xpath(".//*[@id='mapping']/div[2]/div[1]/span/div[1]/span[2]/input[@type='radio']");
	public static By User_Id= By.xpath(".//*[@id='userId']");
	public static By Adoption_label=By.xpath(".//*[@id='labelname']");
	public static By Adoption_request_isbn=By.xpath(".//*[@id='adoptionReqDetails']//div[text()='9780323055536  ']");
	public static By Adoption_request_username=By.xpath(".//*[@id='adoptionReqDetails']/table/tbody/tr[2]/td/table/tbody/tr[1]/td[1]/table/tbody/tr[11]/td[2]");
	//public static By Logout=By.xpath(".//*[@id='page']/div[1]/div/div[1]/div[2]/ul/li[3]/a[text()='Logout']");
	public static By Logout=By.xpath(".//a[@class='logout']");


	//TestID-15588
	public static By Guyton_ISBN=By.xpath(".//*[@id='pageLayout-body-inner']//div[@class='cartproductdetails']");
	public static By Guyton_Price=By.xpath(".//*[@id='pageLayout-body-inner']//div[@class='price2']");
	public static By Header3=By.xpath(".//*[@id='form-profile']/h3[3]");
	public static By Header4=By.xpath(".//*[@id='form-profile']/h3[4]");
	//public static By Error_msg5=By.xpath("html/body/div[4]/div[3]/div/div/div/div/div/div[1]/form/div[16]/p[1]");
	public static By Error_msg5=By.xpath(".//p[@id='ext-gen13']");
	//public static By Use_this_address=By.xpath("html/body/div[3]/p[3]/button[text()='Use This Address']");
	public static By Use_this_address=By.xpath(".//button[1]");
	public static By Item_name=By.xpath(".//*[@id='pageLayout-body-inner']//div[@class='carttitle']");
	public static By Total_price=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[5]/div[1]/div[3]/table/tbody/tr[4]/td[2]");
	public static By Pro_price=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[1]/ul/li[2]/div[5]");
	public static By Verify_Total_price=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[1]/table/tbody/tr[6]/td[2]/span");
	public static By Recommended_Products=By.xpath(".//*[@id='div-recommended']/div[2]");  
	public static By Popup_header=By.xpath("html/body/div[3]/h1[text()='Please Verify Your Address']");
	public static By Creditcard_header=By.xpath(".//*[@id='cc-form']/h3[text()='Enter your credit card information:']");
	public static By Guyton_Title=By.xpath(".//*[@id='pageLayout-body-inner']//div[@class='carttitle']");

	//Test ID-9802
	public static By Simulation_courses=By.xpath(".//*[@id='lowershelf']/table/tbody/tr/td[2]/img");
	public static By Simulation_search=By.id("search-simulation");
	public static By Simulation_search_button=By.xpath(".//*[@id='lowershelf']//input[@class='b-submit b-aqua']");
	public static By Pbc_Isbn_number=By.xpath(".//*[@id='pageLayout-body-inner']//div[@class='cartproductdetails']");
	public static By Pbc_title=By.xpath(".//*[@id='pageLayout-body-inner']//div[@class='carttitle']");		    
	public static By Pbc_price=By.xpath(".//*[@id='pageLayout-body-inner']//div[@class='price2']");
	public static By Pbc_isbn_title=By.xpath(".//*[@id='pageLayout-body-inner']//div[@class='carttitle']");
	public static By Pbc_total_price=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[5]/div[1]/div[3]/table/tbody/tr[3]/td[2]");
	public static By Pbc_verify_title=By.xpath(".//*[@id='pageLayout-body-inner-most']//a[text()='PBC Test - UAT0237 - SimChart eComm (SME), 1st Edition']");
	public static By Pbc_verify_isbn=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[@class='cartproductdetails']");
	public static By Pbc_verify_price=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[text()='$32.95']");
	public static By Pbc_verify_total_price=By.xpath(".//*[@id='pageLayout-body-inner-most']//span[@class='totalamount']");
	public static By Pbc_Refresh=By.xpath(".//*[@id='el-pane']//a[text()=' Refresh']");
	public static By Pbc_courseid_link=By.xpath(".//*[@id='set']//a[text()='PBC Test - UAT0237 - SimChart eComm (SME), 1st Edition']");
	public static By Pbc_courseid=By.xpath(".//*[@id='set']//span[text()='COURSE ID: 166768_selfstudy_0001']");
	public static By Pbc_Estimatetax=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[5]/div[1]/div[3]/table/tbody/tr[2]/td[2]");

	//TC-15574

	public static By Enroll_into_Course=By.xpath(".//*[@id='lowershelf']/div[8]/ul/li[2]/a");
	//public static By Enroll_courseid_searchbox=By.xpath(".//*[@id='ui-resourceId']");
	//public static By Enroll_continue=By.xpath(".//*[@id='pageLayout-body-inner-most']/div[1]/div/div[2]/form/div[2]/input");
	public static By Enroll_courseid_searchbox=By.id("accessCode");
	public static By Enroll_continue=By.xpath(".//form[@name='validateCodeForm']/button");
	public static By Mycart_subtotal=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div/div[2]/table/tbody/tr[2]/td[2]");
	public static By CourseId_details=By.xpath(".//*[@id='pageLayout-body-inner-most']//div[@class='enrollment rounded']");
	//public static By Course_PAR_report=By.xpath(".//*[@id='pageBody']/form/table/tbody/tr[5]/td/table[7]/tbody/tr[3]/td/a");
	public static By Course_PAR_report=By.xpath(".//a[text()='Course PAR Report']");
	public static By Course_Id_searchbox=By.xpath(".//*[@id='courseid']");
	public static By Course_Id_go=By.xpath(".//*[@id='go']");
	public static By Review_price=By.xpath(".//*[@id='pageLayout-body-inner-most']//div/span[@class='discountprice2']");
	public static By Review_total_price=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[4]/div/div[3]/table/tbody/tr[4]/td[2]");
	public static By confirm_total_price=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div[1]/table/tbody/tr[7]/td[2]/span");
	//public static By Edit_evolve_user=By.xpath(".//*[@id='pageBody']/form/table/tbody/tr[5]/td/table[5]/tbody/tr[2]/td/a");
	public static By Edit_evolve_user=By.xpath(".//a[@href='/admin/srchUserProfile']");
	public static By Search_Username=By.xpath(".//*[@id='pageBody']/table/tbody/tr[6]/td/form/table/tbody/tr[5]/td[2]/input");
	public static By Search_button=By.xpath(".//*[@id='pageBody']/table/tbody/tr[6]/td/form/table/tbody/tr[8]/td/input");
	public static By PAR_username=By.xpath(".//*[@id='evolve_usersearchlist_table']/tbody/tr/td[2]");
	public static By Par_btn=By.xpath(".//*[@id='parBtn']");
	public static By Manage_access_rights=By.xpath(".//*[@id='protectedaccessrightsdiv']//strong[text()='Manage Protected Access Rights']");
	public static By Manage_access_courseId=By.xpath(".//*[@id='protectedaccessrightsdiv']/table/tbody/tr/td[2]/span");
	public static By Redemption_date=By.xpath(".//*[@id='protectedaccessrightsdiv']/table/tbody/tr/td[4]/span");
	public static By Course_link=By.xpath(".//*[@id='set']/li/div[1]/div/a");
	//public static By Access_error=By.xpath("html/body/div[4]/div[3]/div/div/div/div/div/ul/li[2]/form/p");
	public static By Access_error=By.xpath(".//p[@class='validation-error validate-form']");
	public static By Access_code_reedemption=By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div/div[2]/table/tbody/tr[1]");

	//form fields
	public static By  educator_form_UserName=By.xpath("//*[@id='form-profile']/div[1]/div[1]/input");
	public static By  educator_form_txtFirstName     = By.xpath(".//*[@id='field-firstName']");
	public static By  educator_form_txtLastName      = By.xpath(".//*[@id='field-lastName']");
	public static By  educator_form_txtEmail    	 = By.xpath(".//*[@id='field-email']");
	public static By  educator_form_txtConformEmail   = By.xpath(".//*[@id='field-emailConfirm']");
	public static By  educator_form_txtPassword   = By.xpath(".//*[@id='field-password']");
	public static By  educator_form_txtConformPassword   = By.xpath(".//*[@id='field-passwordConfirm']");	
	public static By  educator_form_txtInstution   = By.xpath(".//*[@id='institution-name']");
	public static By  educator_form_txtAddress   = By.xpath(".//*[@id='address0-address1']");
	public static By  educator_form_txtAddress2   = By.xpath(".//*[@id='address0-address2']");
	public static By  educator_form_txtAddTown  = By.xpath(".//*[@id='address0-town']");
	public static By  educator_form_txtAddProvince  = By.xpath(".//*[@id='address0-province']");
	public static By  educator_form_txtAddPostalCode  = By.xpath(".//*[@id='address0-postalCode']");
	public static By  educator_form_txtAddZipCode = By.xpath(".//*[@id='address0-zipCode']");
	public static By  educator_form_txtAddPhone  = By.xpath(".//*[@id='field-phone']");
	public static By  educator_form_txtddprogramType  = By.xpath(".//*[@id='select-program-type']");
	public static By  educator_form_btnContinue = By.xpath(".//*[@id='profile-submit']");
	public static By  educator_form_InstutionCountry  = By.xpath(".//*[@id='institution-country']");


	public static By  educator_form_State  = By.xpath(".//*[@id='institution-state']");
	public static By  educator_form_Town = By.xpath(".//*[@id='institution-city']");

	//Modified Xpaths:
	public static By Baseproductreportlink=By.linkText("Base Product Reports");
	public static By Evolve_Admin_Prmlnk=By.linkText("Add Promotion");
	public static By Promotion_ExclusionVariable_MaintainPromotionLink=By.linkText("Maintain Promotions");
	public static By marketingPageSinglePercentage_PrmPgeGlobalLink=By.linkText("Global Promotion Exclusions");
	public static By unassignedaccesslink=By.linkText("Create Unassigned Codes");
	public static By Admin_Login_Upload_lnk=By.linkText("Upload Unassigned Codes");
	public static final By BASE_PRDORDUCT_RERPORTS = By.
			linkText("Base Product Reports");

	//fraud test cases
    
    public final static By LOGIN = By.xpath(".//a[contains(text(),'Login')]");
    public final static By USERNAME_Fraud = By.name("username");
    public final static By PASSWORD = By.name("password");
    public final static By LOGIN_SUBMIT_BUTTON = By.xpath(".//*[@id='login-dropdown']//button[text()='LOGIN']");
    public final static By TEST_COURSES_SCMO_CERT = By.xpath(".//a[contains(text(),'SCMO-CERT')]");
    public final static By EVOLVE_CATALOG=By.xpath(".//a[text()='Evolve Catalog']");
    public final static By SIMCHART_FOR_MEDICAL_OFFICE = By.xpath(".//a[contains(text(),'SimChart for the Medical Office')]");
    public final static By SIMCHART_FOR_MEDICAL_OFFICE_SPAN = By.xpath(".//span[contains(text(),'SimChart for the Medical Office')]");
    public final static By LOGOUT = By.xpath(".//a[text()='Logout']");
    public final static By SEARCH_CATALOG = By.name("query");
    public final static By CATALOG_GO = By.className("go-button");
    public final static By MyCART = By.xpath(".//*[@id='pageLayout-body-inner-most']//h1");
    
    public final static By MAINTAIN_SUSPICIOUS = By.xpath(".//*[@id='pageBody']//b[text()='Maintain Suspicious Orders']");
    public final static By REVIEW_SUSPICIOUS = By.xpath(".//*[@id='pageBody']//a[text()='Review/Approve/Reject Suspicious Orders']");
    public final static By UPDATEACCOUNT_HEADING = By.xpath(".//*[@id='pageLayout-body-inner-most']//h1");
    public final static By ORDER_NUMBER_FORUSE = By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class,'sidebar-list rounded')]//h4[text()='Order Number']//following-sibling::*");
    public final static By ORDER_NUMBER = By.xpath(".//*[@id='orderNbr']");
    public final static By ORDER_SEARCH = By.xpath(".//*[@id='orderSearch']");
    public final static By ORDER_TABLE = By.xpath(".//*[@id='table-container']/table/tbody/tr//td");
    public final static By ORDER_STATUS = By.xpath(".//*[@id='table-container']/table/thead//span[text()='Status']//following::td[2]/span");
    public final static By ORDER_BUBBLE_ICON = By.xpath(".//*[@name='rejectCheckBox']//following::div/img");
    public final static By CONFIDENTIAL_NOTE = By.xpath(".//*[@id='tblcontent']//td/strong[text()='*Confidential Notes']//following::td[4]");
    public final static By ORDER_BUBBLE_ICON_CLOSE = By.xpath(".//*[@id='top_row']/td[3]/img");
    public final static By ORDER_REJECT_CHKBOX = By.name("rejectCheckBox");
    public final static By ORDER_SUBMIT = By.xpath(".//*[@id='submitBtn']");
    public final static By ORDER_REJECTION_MESSAGE = By.xpath(".//*[@id='orderRejectNotes']");
    public final static By ORDER_REJECTION_MESSAGE_SAVE = By.xpath("//button//span[text()='Save']");
    public final static By ORDER_APPROVAL_CHKBOX = By.name("selectapproveall");
    public final static By ORDER_APPROVAL_MESSAGE = By.xpath(".//*[@id='orderApprovalNotes']");
    public final static By ORDER_CHANGE_MESSAGE = By.xpath(".//*[@id='msg-submit-success']");
    public final static By ORDER_SEARCH_USERNAME = By.id("userName");


//HESI Transcripts
    public final static By HESI_TRANSCRIPTS = By.xpath("//div[h2/text() = 'HESI Secured Exams']/descendant::a[text()='HESI Transcripts']");
    public final static By HESI_TRANSCRIPTS_QTY_FIELD = By.xpath("id('9780323324045')/div[4]/form/input[4]");
    public final static By HESI_TRANSCRIPT_ISBN = By.xpath("id('9780323324045')/div[3]/div[4]");
    public final static By HESI_TRANSCRIPT_TITLE = By.xpath("id('9780323324045')/div[3]/div[1]/a");
    public final static By UPDATE_QTY_BUTTON = By.xpath("id('updateQuantityButton')");
    public final static By TRANSCRIPT_ERROR_MSG = By.xpath("id('qtip-1-content')");
    public final static By TRANSCRIPT_ERROR_MSG_REVIEW = By.xpath(".//div[@id='qtip-2' and @aria-hidden='false']/div[@id='qtip-2-content']");
    public final static By TRANSCRIPT_SUBMISSION_MSG = By.xpath("id('pageLayout-body-inner-most')/div[1]/div/div[2]/div[1]/ul/li[2]/div[7]/div");
	
	// Archiving products
	public static By Exclude_Archived = By.xpath(".//input[@id='archived']");
	public static By Exclude_Cancelled = By.xpath(".//input[@id='cancelled']");
	public static By Exclude_OOP = By.xpath(".//input[@id='outofprint']");
	public static By Archived = By.xpath(".//input[@name='archived']");
	public static By Save_and_Publish = By.xpath(".//button[@id='save_and_pub_product']");
	public static By Updated_Successfully_Msg = By.xpath(".//div[@id='msgDiv']");
	public static By Product_Archived_Msg = By.xpath(".//div[@id='product-msg-container']");
	public static By AdminSearchNoResults = By.xpath(".//span[@id='noResultsSpan']");

//Search Adoption Requests
	public final static By AR_DATE_RANGE_RADIO = By.xpath("id('dateRangeSearch')");
	public final static By AR_SEARCH_BTN = By.xpath("id('midSearch')");
	public final static By AR_SHOW_ONLY_TRIALS = By.xpath("//span[contains(.,'Show Only Trials')]/input[@type='checkBox']");
	public final static By AR_EXCLUDE_TRIALS = By.xpath("//span[contains(.,'Exclude Trials')]/input[@type='checkBox']");
	public final static By AR_PENDING_FILTER = By.xpath("//span[contains(.,'Pending')]/input[@type='checkBox']");
	public final static By AR_APPROVED_FILTER = By.xpath("//span[contains(.,'Approved')]/input[@type='checkBox']");
	public final static By AR_FULFILLED_FILTER = By.xpath("//span[contains(.,'Fulfilled')]/input[@type='checkBox']");
	public final static By AR_RESULTS_DATE_SORT = By.xpath("id('date')");
	public final static By AR_RESULTS_ROW_SELECT = By.xpath(".//*[@id='resultTable']//tbody//tr[1]//td//div[@id='name']");
	public final static By AR_DETAILS_NUMBER = By.xpath(".//form[@id='adoptionReqDetails']/table/tbody/tr[2]/td/table/tbody/tr/td[1]/table//td[@class='form']//h3");
	public final static By AR_DETAILS_ISBN = By.xpath("id('adoptionReqDetails')/table/tbody/tr[2]/td/table/tbody/tr[1]/td[1]/table/tbody/tr[1]/td/div[6]");
	public final static By AR_DETAILS_EMAIL = By.xpath("id('adoptionReqDetails')/table/tbody/tr[2]/td/table/tbody/tr[1]/td[1]/table/tbody/tr[25]/td/table/tbody/tr[2]/td[1]");
	public final static By AR_DETAILS_WARN1 = By.xpath("id('milestone-container')/tbody/tr[3]/td[@class='milestone']/input[@type='text']");
	public final static By AR_DETAILS_WARN2 = By.xpath("id('eventText2')");
	public final static By AR_DETAILS_END_DATE = By.xpath("id('eventText3')");
	public final static By AR_DETAILS_DISABLE_DATE = By.xpath("id('eventText4')");
	public final static By ADMIN_BREADCRUMB = By.xpath("id('pageBody')/table[1]/tbody/tr[1]/td/table/tbody/tr/td/a[1]");
	public final static By ADMIN_FACULTY_PROD_TAB = By.xpath("id('product-tabs')//a[@href='#faculty-production']");
	public final static By TRIAL_WARN1_FPROD = By.xpath(".//*[@id='faculty-production']//div[@class='email_template_section']/span[contains(text(),'Warning 1')]/following-sibling::span[1]/input");
	public final static By TRIAL_WARN2_FPROD = By.xpath(".//*[@id='faculty-production']//div[@class='email_template_section']/span[contains(text(),'Warning 2')]/following-sibling::span[1]/input");
	public final static By TRIAL_END_DATE_FPROD = By.xpath(".//*[@id='faculty-production']//div[@class='email_template_section']/span[contains(text(),'End Date')]/following-sibling::span[1]/input");
	public final static By TRIAL_DISABLE_DATE_FPROD = By.xpath(".//*[@id='faculty-production']//div[@class='email_template_section']/span[contains(text(),'Unenroll User')]/following-sibling::span[1]/input");
	public final static By EXTEND_AR_TRIAL = By.xpath("id('extendTrial')");
	
	// LTI
	public static By D2L_Username = By.xpath(".//input[@id='Username']");
	public static By D2L_Password = By.xpath(".//input[@id='Password']");
	public static By D2L_LoginButton = By.xpath(".//input[@name='Login']");
	public static By D2L_AdminTools = By.xpath(".//a[@title='Admin Tools']");
	public static By D2L_CourseManagement = By.xpath(".//a[text()='Course Management']");
	public static By D2L_CreateNewCourseOffering = By.xpath(".//input[@value='Create a New Course Offering or Template']");
	public static By D2L_ExistingTemplateOption = By.xpath(".//input[@name='createType' and @value='ExistingTemplate']");
	public static By D2L_TemplateDropdown = By.xpath(".//select[@name='oldCTId']");
	public static By D2L_NextButton = By.xpath(".//input[@value='Next']");
	public static By D2L_CreateButton = By.xpath(".//input[@value='Create']");
	public static By D2L_DoneButton = By.xpath(".//input[@value='Done']");
	public static By D2L_ContentIFrame = By.xpath(".//iframe");
	public static By D2L_InsertQuicklinkFrame = By.xpath(".//iframe[@class='d2l-dialog-frame']");
	public static By D2L_AccessCodeFrame = By.xpath(".//iframe[contains(@title, 'AutoModule-LTIauto')]");
	public static By D2L_EmbeddedContentFrame = By.xpath(".//iframe[@name='embeddedContent']");
	public static By D2L_EnterCourseName = By.xpath(".//input[@name='courseOfferingName']");
	public static By D2L_EnterCourseCode = By.xpath(".//input[@name='courseOfferingCode']");
	public static By D2L_SemesterDropdown = By.xpath(".//select[@name='semId']");
	public static By D2L_CourseSearch = By.xpath(".//input[@title='Search']");
	public static By D2L_CourseSearchButton = By.xpath(".//a[@title='Search']");
	public static By D2L_EditCourse = By.xpath(".//a/span[text()='Edit Course']");
	public static By D2L_CourseBuilder = By.xpath(".//a[text()='Course Builder']");
	public static By D2L_ExternalLearningTools = By.xpath("(.//a[text()='External Learning Tools'])[2]");
	public static By D2L_NewLinkButton = By.xpath(".//a[text()='New Link']");
	public static By D2L_EnterLinkTitle = By.xpath(".//input[@name='title']");
	public static By D2L_EnterLinkURL = By.xpath(".//input[@name='url']");
	public static By D2L_SecretKeyOption = By.xpath(".//input[@name='signOption' and @value='2']");
	public static By D2L_KeyTextbox = By.xpath(".//input[@name='key']");
	public static By D2L_SecretTextbox = By.xpath(".//input[@name='secret']");
	public static By D2L_AddParameterNumber = By.xpath(".//input[@title='# of custom parameters to add']");
	public static By D2L_AddParameterLink = By.xpath(".//a[text()='Add custom parameters']");
	public static By D2L_SendTool_checkbox = By.xpath(".//input[@name='sendTCInfo']");
	public static By D2L_SendContext_checkbox = By.xpath(".//input[@name='sendContextInfo']");
	public static By D2L_SendUserID_checkbox = By.xpath(".//input[@name='sendUserId']");
	public static By D2L_SendUsername_checkbox = By.xpath(".//input[@name='sendUserName']");
	public static By D2L_SendEmail_checkbox = By.xpath(".//input[@name='sendUserEmail']");
	public static By D2L_SendLinkTitle_checkbox = By.xpath(".//input[@name='sendLinkTitle']");
	public static By D2L_SendLinkDesc_checkbox = By.xpath(".//input[@name='sendLinkDescription']");
	public static By D2L_AddLinkSaveButton = By.xpath(".//a[text()='Save']");
	public static By D2L_EditNewLink = By.xpath(".//a[contains(@href, 'link_newEdit.d2l')]");
	public static By D2L_Parameter1_Name = By.xpath(".//input[@name='name_new_0']");
	public static By D2L_Parameter1_Value = By.xpath(".//input[@name='value_new_0']");
	public static By D2L_Parameter2_Name = By.xpath(".//input[@name='name_new_1']");
	public static By D2L_Parameter2_Value = By.xpath(".//input[@name='value_new_1']");
	public static By D2L_CreateModule = By.xpath(".//img[@alt='Create a module']");
	public static By D2L_CourseLocation = By.xpath(".//a/span[contains(text(), 'LTIauto_')]");
	public static By D2L_CreateModuleName = By.xpath(".//input[@id='z_c']");
	public static By D2L_ModuleCreateButton = By.xpath(".//a[text()='Create']");
	public static By D2L_CreateLink = By.xpath(".//img[@alt='Create a link']");
	public static By D2L_ModuleLocation = By.xpath(".//a/span[contains(text(), 'AutoModule-')]");
	public static By D2L_AddToolToModule = By.xpath(".//div[text()='External Learning Tools']");
	public static By D2L_SelectLTILink = By.xpath(".//div[contains(text(), 'AutoModule-')]");
	public static By D2L_MyHome = By.xpath(".//a/span[text()='My Home']");
	public static By D2L_CourseContentLink = By.xpath(".//a/span[text()='Content']");
	public static By D2L_ExternalContentLink = By.xpath(".//a[contains(@title, 'External Learning Tool')]");
	public static By D2L_Classlist = By.xpath(".//a/span[text()='Classlist']");
	public static By D2L_AddParticipants = By.xpath(".//a/span[text()='Add Participants']");
	public static By D2L_CreateNewUser = By.xpath(".//a/span[text()='Create and enroll a new user']");
	public static By D2L_NewUserFirstName = By.xpath(".//input[@name='fname']");
	public static By D2L_NewUserLastName = By.xpath(".//input[@name='lname']");
	public static By D2L_NewUserID = By.xpath(".//input[@name='orgdefinedid']");
	public static By D2L_NewUserEmail = By.xpath(".//input[@name='email']");
	public static By D2L_NewUserRole = By.xpath(".//select[@name='roleid']");
	public static By D2L_NewUserPass = By.xpath(".//input[@name='pass']");
	public static By D2L_EnrollButton = By.xpath(".//a[text()='Enroll']");
	public static By D2L_ClasslistName = By.xpath(".//a[contains(@title, 'Compose email to ')]");
	public static By D2L_ClasslistEmail = By.xpath(".//label[contains(text(),'@')]");
	public static By D2L_ClasslistRole = By.xpath(".//label[contains(text(),'Student')]");
	public static By D2L_UserMenu = By.xpath(".//span[@class='d2l-menuflyout-text']");
	public static By D2L_Logout = By.xpath(".//a[text()='Log Out']");
	public static By D2L_ExternalLink = By.xpath(".//a[contains(@title, ' - External Learning Tool')]");
	public static By AuthAndIntConnectors = By.xpath(".//a[text()='Authentication and Integration Connectors']");
	public static By AddConnector = By.xpath(".//a[@id='a-add-connector']");
	public static By EvolveSSOClient = By.xpath(".//a[text()='Evolve SSO Client']");
	public static By EnterConnectorID = By.xpath(".//input[@id='systemForm:connectorId']");
	public static By EnterConnectorName = By.xpath(".//input[@id='systemForm:name']");
	public static By CustomParameter = By.xpath(".//input[@name='userIdParameter']");
	public static By SecretKey = By.xpath(".//input[@name='key']");
	public static By CreateSecretKey = By.xpath(".//a[@title='Create']");
	public static By AddConnectorSubmit = By.xpath(".//input[@value='Submit']");
	public static By EditCourse = By.xpath(".//a[@id='action-edit']");
	public static By AddIntegrationSystem = By.xpath(".//select[@name='system-new']");
	public static By AddIntegrationID = By.xpath(".//input[@name='uniqueId-new']");
	public static By EditCourseSubmit = By.xpath(".//button[text()='Submit']");
	public static By LTIurl = By.xpath(".//div[contains(@class,'modal-body')]//a[text()='Right click to copy']");
	public static By AccessCodeRedeemButton = By.xpath(".//button[text()='Redeem']");
	public static By InvalidCodeTitle = By.xpath(".//span[@class='portletHeaderTitle']");
	public static By InvalidCodeMessage = By.xpath(".//div[@class='cp_dialog_body']");
	public static By InvalidCodeOK = By.xpath(".//button[text()='OK']");
	public static By BeginAssessmentButton = By.xpath(".//input[@value='Begin Assessment']");
	public static By AdminGoToGroup = By.xpath(".//a/i[@class='icon-play']");
	
	// BlackBoard Ecom
	public static By BB_Username = By.xpath(".//input[@id='user_id']");
	public static By BB_Password = By.xpath(".//input[@id='password']");
	public static By BB_LoginButton = By.xpath(".//input[@id='entry-login']");
	public static By BB_MyCoursesLink = By.xpath(".//a/span[text()='Courses']");
	public static By BB_CourseLink = By.xpath(".//a[contains(text(), 'Elsevier Extra Large Course 1 QA3')]");
	public static By BB_ToolsLink = By.xpath(".//a/span[@title='Tools']");
	public static By BB_AcademicMaterials = By.xpath(".//a[contains(text(),'Academic Materials')]");
	public static By BB_CourseFilter = By.xpath(".//select[@id='courseFilter']");
	public static By BB_PublisherFilter = By.xpath(".//select[@id='vendorFilter']");
	public static By BB_TypeFilter = By.xpath(".//select[@id='typeFilter']");
}


