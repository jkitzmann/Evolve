package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.ConvertLOCourseToTrial_15567;
import com.cigniti.automation.BusinessFunctions.ConvertLOTrialCoursetoPermanentPending_15566;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;

import com.cigniti.automation.BusinessFunctions.LOUniqueCourseFulfillmentfromSearchResultsPage_LO_15100;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentFaculty_15243;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101;
import com.cigniti.automation.BusinessFunctions.LO_Global_Instructor_AR_8572;
import com.cigniti.automation.BusinessFunctions.LO_Unique_CourseFulfillment_Faculty_10410;
import com.cigniti.automation.BusinessFunctions.LO_Unique_CourseFulfillment_Faculty_15586;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class ConvertLOCourseToTrial_15567_Script extends ConvertLOCourseToTrial_15567 {

@Test
	public void ConvertLOCourseToTrial_15567()throws Throwable{

	try{
		
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());

		String adminUser=configProps.getProperty("AdminUser");
		evolveContent=ReadingExcel.columnDataByHeaderName("content", "TC-15101", configProps.getProperty("TestData"));
		comment="";
		enrollment="";
		iSBN=ReadingExcel.columnDataByHeaderName("iSBN","TC-15101", configProps.getProperty("TestData")) ;
		product=iSBN;
		KNOIsbn=iSBN;
		requestText=ReadingExcel.columnDataByHeaderName("requestText","TC-15101", configProps.getProperty("TestData"));
		String statusAfterEmailSent=ReadingExcel.columnDataByHeaderName("verifyStatusAfterEmailSent", "TC-15101", configProps.getProperty("TestData"));
		String productId=ReadingExcel.columnDataByHeaderName("productID", "TC-15101", configProps.getProperty("TestData"));
		String format_LO=ReadingExcel.columnDataByHeaderName("format_LO", "TC-15101", configProps.getProperty("TestData"));
		TrialEmailTitle=ReadingExcel.columnDataByHeaderName("emailTitle","TC-15101", configProps.getProperty("TestData"));
		TrialStatus=ReadingExcel.columnDataByHeaderName("noTrialStatus","TC-15566", configProps.getProperty("TestData"));
		checkTrialStatus=ReadingExcel.columnDataByHeaderName("checkTrialStatus","TC-15101", configProps.getProperty("TestData"));
		String startDate=ReadingExcel.columnDataByHeaderName("StartDate","TC-15101", configProps.getProperty("TestData"));		
		
		
		compareStartDate=ReadingExcel.columnDataByHeaderName("daysstartDate","TC-15101", configProps.getProperty("TestData"));
		compareEmailTemplateStartDate=ReadingExcel.columnDataByHeaderName("EmailTemlateocTrial","TC-15101", configProps.getProperty("TestData"));
		compareEmailTemplateWarning1=ReadingExcel.columnDataByHeaderName("EmailTemlatewarning1","TC-15101", configProps.getProperty("TestData"));
		compareEmailTemplateWarning2=ReadingExcel.columnDataByHeaderName("EmailTemlatewarning2","TC-15101", configProps.getProperty("TestData"));
		compareEmailTemplateEnd=ReadingExcel.columnDataByHeaderName("EmailTemlateendDate","TC-15101", configProps.getProperty("TestData"));
		unEnrollDays=ReadingExcel.columnDataByHeaderName("unEnrollDays","TC-15101", configProps.getProperty("TestData"));
		warning1Days=ReadingExcel.columnDataByHeaderName("daysWarning1","TC-15101", configProps.getProperty("TestData"));
		wraning2Days=ReadingExcel.columnDataByHeaderName("daysWarning2","TC-15101", configProps.getProperty("TestData"));
		endDays=ReadingExcel.columnDataByHeaderName("endDays","TC-15101", configProps.getProperty("TestData"));
		
		verifymessage=ReadingExcel.columnDataByHeaderName("verifyTrialMessage", "TC-15566", configProps.getProperty("TestData"));
		MIlestone=ReadingExcel.columnDataByHeaderName("milestone", "TC-15566", configProps.getProperty("TestData"));
		rosterDetails=ReadingExcel.columnDataByHeaderName("rosterDetails", "TC-15566", configProps.getProperty("TestData"));
		NoTrialEmailTitle=ReadingExcel.columnDataByHeaderName("noTrialEmailTitle", "TC-15101", configProps.getProperty("TestData"));
		String errorMssg=ReadingExcel.columnDataByHeaderName("rosterErrorMessage", "TC-15566", configProps.getProperty("TestData"));
	
		//*************************************************************************************************************************************************************************//
	
		stepReport("Login to Evolve Admin");
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Launch Admin URL and Login into Admin Page.", 
				   "Successfully Launched the Admin URL </br> Successfully logged into Admin Page as"+adminUser, 
				   "Failed to Launch the Admmin URL </br> Failed to login into Admin Page.");
		
		stepReport("Verify trial dates for course");
		writeReport(LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.maintainProductLink(iSBN), "Clicking Maintain products link in Admin Page And Searching For ISBN:"+iSBN, 
				"Successfully Clicked on Maintain Product Link in Admin Page. </br> Successfully entered ISBN:"+iSBN+" in Search box. </br> Successfully Clicked on Search Button.</br>Successfully Navigated To Product Search Result Page.", 
				"Failed to Click on Maintain Product Link in Admin page.</br>Failed To Search For ISBN:"+iSBN);
		
		writeReport(LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.f_prodLinkInMaintainProductPage(), "Clicking F-Prod link in Product Search Result Page.",
				 "Successfully Clicked on F-prod link in Product Search Result Page.",
				 "Failed to Click on F-Prod Link in Product Search Result Page.");
		
		String value="Start Date";
		LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.compareStartDtaeTrialReg(value,compareStartDate,compareEmailTemplateStartDate);
		String warning1="Warning 1";
		LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.f_productionTrialRegistrationTable(warning1,warning1Days,compareEmailTemplateWarning1);
		String warning2="Warning 2";
		LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.f_productionTrialRegistrationTable(warning2,wraning2Days,compareEmailTemplateWarning2);
		String end="End Date";
		LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.f_productionTrialRegistrationTable(end,endDays,compareEmailTemplateEnd);
		String unenroll="Unenroll User*";
		LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.compareUnEnrollTrialReg(unenroll,unEnrollDays);
	
		writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout.", 
																  "Successfully logged out admin page.", 
																  "Failed to logout admin page.");
		
		stepReport("Login as existing faculty user");
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		String user="educator";
		facultyUser=ReadingExcel.columnDataByHeaderName("Faculty_User", "TC-15101", configProps.getProperty("TestData"));
		facultyPwd=ReadingExcel.columnDataByHeaderName("Faculty_passWord", "TC-15101", configProps.getProperty("TestData"));
		
		writeReport(EvolveCommonBussinessFunctions.existingUserLogin(user,facultyUser,facultyPwd),"Login to Application Using User Credentials",
			   	  "Launching the URL for User is successfull </br > Login to Application Using User Credentials :"+facultyUser+" is Successfull",
				  "Launching and Login to Application Using User Credentials : "+ facultyUser+" is Failed");
		
		writeReport(EvolveCommonBussinessFunctions.getAccountDetails(),"Fetching Account Details from My Account.",
				   "Successfully Fetched account details from My Account page.",
				   "Failed to Fetch the account details from My Account page.");

		stepReport("Search for product and add to cart");
		writeReport(EvolveCommonBussinessFunctions.searchProduct(product,productCost),"Search for the product..",
				  "Successfully Entered ISBN:"+product+" in Search Box.</br>Clicked On Go Button.</br>Navigated To Product Details Page.",
				  "Failed to Enter ISBN:"+product+" in Search Box.");
		
		writeReport(EvolveCommonBussinessFunctions.requestProduct(),"Clicking on the Request Product Button In Product Details Page.",
				"Successfully clicked on Request Product Button.",
				"Failed to click on Request Product Button.");
		writeReport(EvolveCommonBussinessFunctions.hostedAfterRequestPopUp(),"Switching to Course Configuration Popup in Request Product page.",
				 "Successfully switched to Course Configuration Popup in Request Product page.",
				 "Failed to switch to Course Configuration Popup in Request Product page.");
		
		writeReport(EvolveCommonBussinessFunctions.evolveContentInPopUp(evolveContent,comment,enrollment),"Entering Evolve Content In Course Configuration Popup.",
				"Successfully entered evolve content in Course Configuration Popup.</br>Clicked On Apply Button In Popup.</br>Navigated To Mycart Page.",
				"Failed to enter evolve content in Course Configuration Popup.</br>Failed To click On Apply Button In Popup.</br>Failed To Navigate To Mycart Page.");
		
		
		
		/*writeReport(LOUniqueCourseTrialFulfillmentfromSearchResultsPageScript_15101.Mycart(searchTrial),"My Cart Page:", 
																																"Successfully navigated to My Cart Page. </br> Clicked on reedeem checkout button.", 
																															"Failed to Navigate to My Cart Page.");*/
		searchTrial="false";	
		String evolve="true";
		String lmsvalue=null;
		String Trial="";
		//LOUniqueCourseTrialFulfillmentfromSearchResultsPageScript_15101.Mycart(searchTrial,Trial);
		
		stepReport("Verify My Cart and submit order");
		EvolveCommonBussinessFunctions.hostedMycart(lmsvalue,evolve);
		String TrialLink="";
		LO_Unique_CourseFulfillment_Faculty_10410.userReviewSubmit(searchTrial,TrialLink);
		LO_Unique_CourseFulfillment_Faculty_10410.receiptPage(searchTrial,TrialLink);

		writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the educator page.", 
																		"Successfully logged out the educator page.", 
																		"Failed to logout the educator page.");
		
		
		//SwitchToBrowser("chrome");
		stepReport("Verify email");
		writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Login In Into Evolve Email Page.", 
																  "Successfully login into Evole Email Page.", 
																  "Failed to login into Evolve Email Page.");
		
		String emailid=EvolveCommonBussinessFunctions.getAccountDetailsEmail;
		writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(emailid),"Search email in evolve webmail.",
				"Successfully entered the emailid "+emailid+" in search box.",
				"Failed to enter email id.");
		
		verifyTitleInEmailBody(NoTrialEmailTitle);
		/*trial="false";
		writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.verifyEmailBodyAfterRequestProduct(trial), "Verify Email Body.",
															  						      "Successfully verified Title Email body.",
															 						      "Failed to verify title in email body.");*/
		
		stepReport("Login to Evolve Admin");
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Launch Admin URL and Login into Admin Page.", 
				   "Successfully Launched the Admin URL </br> Successfully logged into Admin Page as"+adminUser, 
				   "Failed to Launch the Admmin URL </br> Failed to login into Admin Page.");
		
		stepReport("Verify AR details");
		LO_Global_Instructor_AR_8572.admin_Adoptionsearch();
		
		/*writeReport(EvolveCommonBussinessFunctions.clickAdoptionRequest(),"Clicking on Search Adoption request link in Admin page.",
				  "Successfully clicked on Search Adoption Requests link.</br>Successfully Selected Today Radio Button In Adoption Request Page.</br>Navigated To Adoption Search Results Page.",
				  "Failed to click on Search Adoption Requests link.</br>Failed To Select Today Radio Button In Adoption Request Page.</br>Failed To Navigate To Adoption Search Results Page.");*/
		
		writeReport(ConvertLOCourseToTrial_15567.verifyNoTrial(), "Verifying Trial status is Blank.", 
				"Successfully verified the Trial Status is Blank in Adoption Search Results Page.", 
				"Failed to verified the Trial Status is Blank in Adoption Search Results Page");	
	
		writeReport(EvolveCommonBussinessFunctions.getAdoptionRequestDetails(),"Clicking On Adoption Number</br>Fetching Adoption Details of User and Course in Adoption Request Details page",
				   "Adoption Number:"+adoptionRequest_getAdoptionNum+" is On Top Of The Row.</br>Successfully Clicked On "+adoptionRequest_getAdoptionNum+"</br>Successfully Fetched the details of User And Course from Adoption Request Details Page.",
				   "Failed To Click On Adoption Number:"+adoptionRequest_getAdoptionNum+"</br>Failed to Fetch the details of User And Course from Adoption Request Details Page.");
		
		ConvertLOCourseToTrial_15567.verifyDetailsInAdoptionPage(format_LO);
	
		stepReport("Convert course to trial and fulfill");
		ConvertLOCourseToTrial_15567.checkConvertToTrialPopup();
		
		writeReport(ConvertLOTrialCoursetoPermanentPending_15566.adoptionRequestVerifyMIlestonesData(),"Verifying the Trial MIlestones section within the Adoption Request Details page is as expected.",
				"Successfully Verified Milestone Data.</br> StartDate:"+compareStartDate+",Email Temaplate:"+compareEmailTemplateStartDate+"</br>Warning1:"+warning1Days+",Email Temaplate:"+compareEmailTemplateWarning1+"</br>,Warnimg2:"+wraning2Days+",Email Temaplate:"+compareEmailTemplateWarning2+"</br>,EndDate:"+endDays+",Email Temaplate:"+compareEmailTemplateEnd+"</br>Unenroll User:"+unEnrollDays,
				"Failed To Verify Milestone Data.");
		
		String changeStatus=ReadingExcel.columnDataByHeaderName("changeStatus", "TC-15101", testDataPath);
		ConvertLOTrialCoursetoPermanentPending_15566.changeStatusToFullfilled(changeStatus);
		
		LOUniqueCourseFulfillmentfromSearchResultsPage_LO_15100.getCourseId(statusAfterEmailSent,productId,facultyUser);
		
		LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.adoptionRequestVerifyMIlestoneDateformat(startDate);
		
		writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout.", 
				"Successfully logged out admin page.", 
				"Failed to logout admin page.");
		
		//SwitchToBrowser("chrome");
		stepReport("Verify email");
		writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Login In Into Evolve Email Page.", 
				  "Successfully login into Evolve Email Page.", 
				  "Failed to login into Evolve Email Page.");

		writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(emailid),"Search email in evolve webmail.",
					"Successfully entered the emailid "+emailid+" in search box.",
					"Failed to enter email id.");
	

		String	EmailTitleAfterFullfilled=ReadingExcel.columnDataByHeaderName("trialEmailTitleAfterFullfilled", "TC-15101", configProps.getProperty("TestData"));

		LOUniqueCourseTrialFulfillmentFaculty_15243.verifyEmailBodyAfterRequestFullfill(EmailTitleAfterFullfilled);
	
		
		stepReport("Login as existing faculty user");
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		facultyUserName=ReadingExcel.columnDataByHeaderName("Faculty_User", "TC-15101", configProps.getProperty("TestData"));
		facultyPassword=ReadingExcel.columnDataByHeaderName("Faculty_passWord", "TC-15101", configProps.getProperty("TestData"));
		writeReport(LO_Unique_CourseFulfillment_Faculty_10410.reLogin(facultyUserName, facultyPassword),  "Login to Application Using User Credentials",
																							    	"Launching the URL for User is successfull</br > Login to Application Using User Credentials :"+facultyUserName+" is Successfull",
																							    	"Launching and Login to Application Using User Credentials : "+ facultyUserName+" is Failed");
		String ID1="true";
		String ID2="false";
		
		writeReport(LO_Unique_CourseFulfillment_Faculty_10410.courseIDSearch(ID1,ID2),"Verify course ID's generated in Admin page are in Educator page or not.",
																		  "Successfully verified CourseId "+courseID1+". </br> Clicked on "+courseID1+".", 
																		  	"Failed to verify CourseId "+courseID1);
	
		/*writeReport(LO_Unique_CourseFulfillment_Faculty_15586.courseDetailsPage(),"Verify Course details in Course Details page.",
				"Successfully verified all course details. </br> Succesfully get the protection scheme id.",
				"Failed to verify all course details.");*/
	
		// Course materials aren't showing up right away. After launching the trial course for the first time, going to try
		// logging out and then relaunching it.
		Thread.sleep(veryhigh);
		Thread.sleep(veryhigh);
		EvolveCommonBussinessFunctions.instructorLogout();
		LO_Unique_CourseFulfillment_Faculty_10410.reLogin(facultyUserName, facultyPassword);
		
		stepReport("Verify trial course can be launched by instructor");
		LO_Unique_CourseFulfillment_Faculty_10410.courseIDSearch(ID1,ID2);
		
		LO_Unique_CourseFulfillment_Faculty_10410.courseDetailsPage(searchTrial);
	
		writeReport(ConvertLOTrialCoursetoPermanentPending_15566.catalogButton(), "Clicking on Catalog Button.",
				"Successfully Clicked on Catalog Button.", 
				"Failed to Click on Catalog Button.");
		
		// honey pots removed with new design
		/*writeReport(ConvertLOTrialCoursetoPermanentPending_15566.onlineCourseHoneyPot(), "Clicking on Online Courses Honeypot in evolve page.",
				"Successfully clicked on Online course honey pot.", 
				"Failed to click on Online course honey pot.");*/
		
		stepReport("Verify roster cannot be submitted for trial course");
		ConvertLOTrialCoursetoPermanentPending_15566.onlineSubmitStudent(rosterDetails);
		
		ConvertLOCourseToTrial_15567.rosterErrorMessage(errorMssg);
		
		writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the educator page.", 
				"Successfully logged out the educator:"+facultyUserName, 
				"Failed to logout the educator page:"+facultyUserName);
	}
	
	catch(Exception e){
		System.out.println(e);
	}



}


@AfterTest
public void tear() throws Throwable{
	/*HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
	Base.tearDown();*/
}


}
