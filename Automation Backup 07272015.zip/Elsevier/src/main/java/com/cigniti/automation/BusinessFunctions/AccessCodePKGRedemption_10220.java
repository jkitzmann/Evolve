package com.cigniti.automation.BusinessFunctions;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class AccessCodePKGRedemption_10220 extends EvolveCommonBussinessFunctions{
	public static Map<String, String> tc_10220=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-10220", testDataPath);
	
	public static boolean previousCase() throws Throwable{
		boolean flag = true;
		try{
		String redemptionCodeValid=tc_10220.get("validRedeemCode");
		if(redemptionCodeValid!=null){
			Reporters.SuccessReport("create unassigned access codes and upload the associated access code package isbn to these codes. ", "Successfully created unassigned access codes and uploaded Successfully the associated access code package isbn to code. : "+redemptionCodeValid);
		}else{
			Reporters.failureReport("create unassigned access codes and upload the associated access code package isbn to these codes. ", "Failed to create unassigned access codes and failed to upload the associated access code package isbn to code. : "+redemptionCodeValid);
		}
		}catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
		return flag;
	}
	public static boolean searchBeforeLogin() throws Throwable{
		boolean flag = true;
	try{	
		if(!launchUrl(configProps.getProperty("URL"))){
			flag = false;
		}

		//enter into the site as student
		if(!click(ElsevierObjects.evolve_Home_Student, "Clicked on Student")){
			flag = false;
		}
	}catch(Exception e){
		sgErrMsg=e.getMessage();return false;
	}
		return flag; 
	}

	public static boolean redemptionInvalid() throws Throwable
	{
		//enter into the site as student
		boolean flag = true;
		try{
			Thread.sleep(medium);
			/*if(javaClick(ElsevierObjects.Student_Home_Packard_img, "Clicked on Pageburst eBook")){
				Reporters.SuccessReport("Click on Pageburst eBook honey pot", "Successfully Clicked on Pageburst eBook honey pot.");	
			}else{
				Reporters.failureReport("Click on Pageburst eBook honey pot", "Failed to Click on Pageburst eBook honey pot.");
			}*/
	
			/* Thread.sleep(medium);
			click(ElsevierObjects.Student_Home_Redeem_lnktxt, "Clicked on Pageburst eBook");
	*/
			/* Thread.sleep(medium);
			if(javaClick(ElsevierObjects.Student_Home_Redeem_lnktxt, "Clicked on Pageburst eBook")){
				Reporters.SuccessReport("Click on Redeem your access code link", "Successfully Clicked on Redeem your access code link");	
			}else{
				Reporters.failureReport("Click on Redeem your access code link", "Failed to Click on Redeem your access code link");
			}*/
			 Thread.sleep(medium);
			if(type(ElsevierObjects.Student_Home_Redeem_txtbox, tc_10220.get("invalidRedeemCode")/*readcolumns.twoColumns(0, 1, 2, configProps.getProperty("TestData")).get("invalidRedeemCode")*/, "Text Box")){
				Reporters.SuccessReport("Enter an invalid access code and hit submit button", "Successfully Entered an invalid access code : "+tc_10220.get("invalidRedeemCode"));	
			}else{
				Reporters.failureReport("Enter an invalid access code and hit submit button", "Failed to Enter an invalid access code : "+tc_10220.get("invalidRedeemCode"));
			}
			 Thread.sleep(medium);
			if(javaClick(ElsevierObjects.Student_Home_Redeem_Subbtn, "Clicked on Submit Redeem Button")){
				Reporters.SuccessReport("Click on the submit button", "Successfully Clicked on the submit button");	
			}else{
				Reporters.failureReport("Click on the submit button", "Successfully Clicked on the submit button");	
			}
			try{
				 Thread.sleep(medium);
				String sucMsg=getText(ElsevierObjects.Student_Home_Redeem_Invldmsg, "");
				if(verifyText(ElsevierObjects.Student_Home_Redeem_Invldmsg, "This access code or course ID is not valid. For additional information please contact Evolve Support or call 1-800-222-9570. If you are trying to search for a product, use the other search box above.", "")){
					Reporters.SuccessReport("The Error Message Validation", "The Error message : "+sucMsg+" is successfully displayed");	
				}else{
					Reporters.failureReport("The Error Message Validation", "The Error message : "+sucMsg+" is failed to display");
				}
		}catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}	
		}catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
		return flag;
	}

	public static boolean redemptionValid() throws Throwable
	{
		boolean flag = true;
		try{
			if(!launchUrl(configProps.getProperty("URL"))){
				flag = false;
			}
			click(ElsevierObjects.evolveCatlog_lnk, "Click on Catalog link.");
			Thread.sleep(medium);
			/*if(javaClick(ElsevierObjects.Student_Home_Packard_img, "Clicked on Pageburst eBook")){
				Reporters.SuccessReport("Click on Pageburst eBook honey pot", "Successfully Clicked on Pageburst eBook honey pot.");	
			}else{
				Reporters.failureReport("Click on Pageburst eBook honey pot", "Failed to Click on Pageburst eBook honey pot.");
			}	
			 Thread.sleep(medium);
			if(javaClick(ElsevierObjects.Student_Home_Redeem_lnktxt, "Clicked on Pageburst eBook")){
				Reporters.SuccessReport("Click on Redeem your access code link", "Successfully Clicked on Redeem your access code link");	
			}else{
				Reporters.failureReport("Click on Redeem your access code link", "Failed to Click on Redeem your access code link");
			}
			
			Thread.sleep(medium);*/
			String validRedeemCode=readcolumns.twoColumns(0, 1, "TC-10220", configProps.getProperty("TestData")).get("validRedeemCode");
			if(type(ElsevierObjects.Student_Home_Redeem_txtbox, validRedeemCode/*readcolumns.twoColumns(0, 1, 2, configProps.getProperty("TestData")).get("validRedeemCode")*/, "Enter Redeem code in Text Box")){
				Reporters.SuccessReport("Enter an invalid access code and hit submit button", "Successfully Entered a valid access code : "+tc_10220.get("validRedeemCode"));	
			}else{
				Reporters.failureReport("Enter an invalid access code and hit submit button", "Failed to Enter a valid access code : "+tc_10220.get("validRedeemCode"));
			}
			Thread.sleep(medium);
			if(javaClick(ElsevierObjects.Student_Home_Redeem_Subbtn, "Clicked on Submit Redeem Button")){
				Reporters.SuccessReport("Click on the submit button", "Successfully Clicked on the submit button");	
			}else{
				Reporters.failureReport("Click on the submit button", "Successfully Clicked on the submit button");	
			}
			Thread.sleep(high);
			if(!clickOnOkButtonIfVisible()){
				flag=false;
			}		
			validRedeemProductValidation();
			titleItemsValidation();
			Thread.sleep(medium);	
			if(javaClick(ElsevierObjects.Student_Home_Redeem_Chkout, "Clicked on Submit Redeem/Checkout Button")){
				Reporters.SuccessReport("Click on the Redeem/checkout button", "Successfully Clicked on the Redeem/checkout button");	
			}else{
				Reporters.failureReport("Click on the Redeem/checkout button", "Failed to Click on the Redeem/checkout button");	
			}
			Thread.sleep(medium);	
		}catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
		return flag;
	}

	public static boolean validRedeemProductValidation() throws Throwable{
		boolean flag=true;
		try{
			String packageName=getText(By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div/h1/following-sibling::ul/li[2]/div[3]/div[1]/a"), "");
			String ISBNPackageName="automation";
			if(packageName.contains(ISBNPackageName)){
				Reporters.SuccessReport("Verify the Package Name", "Successfully Verified the Package Name , <br> Expected Package Name is : "+ISBNPackageName+"<br> Actual Package Name is : "+packageName);
			}else{
				Reporters.failureReport("Verify the Package Name", "Failed to Verify the Package Name , <br> Expected Package Name is : "+ISBNPackageName+"<br> Actual Package Name is : "+packageName);
			}
			List<WebElement> bookList=driver.findElements(By.xpath(".//*[@id='pageLayout-body-inner-most']//li[contains(@class,'row')]//div[contains(@class,'carttitle')]"));
			for(WebElement book: bookList){
				if(book!=null){
					System.out.println(book.getText());
					Reporters.SuccessReport("List of Package Name and Book Titles associated with the ISBN Packages", "List of Package Name and Book Titles are : "+book.getText());
				}else{
					Reporters.failureReport("List of Package Name and Book Titles associated with the ISBN Packages", "List of Package Name and Book Titles are : "+book.getText());
				}
			}
			
			float price=convertPrice(ElsevierObjects.Admin_Evolve_Ecom_studentprice1);
			float subTotal=convertPrice(ElsevierObjects.Admin_Evolve_Ecom_SubTotal);

			if(price==subTotal){
				Reporters.SuccessReport("Product Price Validation", "The Product Price : "+price
						+ "<br>The actual Price is : "+price + "<br> The Price in ISBN3 is : "+subTotal);
			}else{
				Reporters.failureReport("Product Price Validation", "The Product Price : "+price+ " is not matched with the isbn3 Price <br>"
						+ "The actual Price is : "+price + "<br> The Price in ISBN3 is : "+subTotal);		
			}
			
			if(price==0.00){
				Reporters.SuccessReport("Validate Access Code Price which will always equal $0.00", "Access Code Price is equal to $0.00");
			}else{
				Reporters.failureReport("Validate Access Code Price which will always equal $0.00", "Access Code Price is not equal to $0.00");
			}
			String quantity=getAttribute(By.xpath(".//*[@id='pageLayout-body-inner-most']//input[contains(@class,'bookstore_textbox rounded numeric')]"), "value", "");
			if(quantity.contains("1")){
				Reporters.SuccessReport("Quantity of the Book", "Package QTY equals to 1 and can not be edited");
			}else{
				Reporters.failureReport("Quantity of the Book", "Package QTY is not equals 1 and can be edited");
			}
		}catch(Exception e){
			System.out.println(sgErrMsg);return false;
		}
		return flag;
	}
	
	public static boolean titleItemsValidation()throws Throwable{
		boolean flag=true;
		try{
			List<WebElement> listData=driver.findElements(By.xpath(".//*[@id='pageLayout-body-inner-most']//li[contains(@class,'row')]/ul/li/div[contains(@class,'descwide span16')]/div"));
			
			for (int i = 0; i < listData.size(); i++) {
				if(i==0||i==5){
				System.out.println("The Title of the Book is : " + listData.get(i).getText()+" <br>The Author of the Book is : " + listData.get(i+1).getText()+"<br>The E-Book is : " + listData.get(i+2).getText()+"Pageburst E-Book on ISBN : " + listData.get(i+3).getText());
				Reporters.SuccessReport("Verify the cart display the following for each item in the package", "The Title of the Book is : " + listData.get(i).getText()+" <br>The Author of the Book is : " + listData.get(i+1).getText()+"<br>The E-Book is : " + listData.get(i+2).getText()+"Pageburst E-Book on ISBN : " + listData.get(i+3).getText());
				}
			}
			
		}catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
		return flag;
	}
	public static boolean evolve_StudentRegistration() throws Throwable{

		boolean flag=true;

		try{
			if(!click(ElsevierObjects.Student_Register_Chk,"Click checkbox")){
				flag=false;
			}
			if(!type(ElsevierObjects.Student_Home_Reg_VSTPwd, tc_10220.get("VST_pwd")/*readcolumns.twoColumns(0, 1, 2, configProps.getProperty("TestData")).get("VST_pwd")*/, "KNO Password Text Box")){
				flag=false;
			}
	
			if(!selectByVisibleText(ElsevierObjects.Student_Shipping_SecurityQue, tc_10220.get("Student_Secu_Que")/*readcolumns.twoColumns(0, 1, 2, configProps.getProperty("TestData")).get("Student_Secu_Que")*/, "Select Security Question")){
				flag=false;
			}
	
			if(!type(ElsevierObjects.Student_Shipiing_SecurityAns, tc_10220.get("Student_Sec_Ans")/*readcolumns.twoColumns(0, 1, 2, configProps.getProperty("TestData")).get("Student_Sec_Ans")*/,"Enter student Security Answer")){
				flag=false;
			}
	
			type(ElsevierObjects.Student_Home_Reg_knopw, "12345678", "kno password");
			
			if(!click(ElsevierObjects.Student_Home_Reg_Cont_btn,"Click on Continue Button")){
				flag=false;
			}
	
			if(!click(ElsevierObjects.Student_Home_Reg_Chkbox,"Click on Checkbox Yes, I accept the Registered User Agreement. Button")){
				flag=false;
			}
	
			if(!click(ElsevierObjects.Student_Home_Reg_Subbtn,"Click on Submit Button")){
				flag=false;
			}
			Thread.sleep(veryhigh);
			String sucMsg=getText(ElsevierObjects.Student_Home_verifyOrder, "Student Home verifyOrder Success Message.");
			if(sucMsg!=null){
				Reporters.SuccessReport("The Registration Completion message", "The Registration Completion message Order Number : "+sucMsg+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Registration Completion message", "The Registration Completion is failed to display");
			}
			/*if(verifyText(ElsevierObjects.Student_Home_verifyOrder, "Your  Pageburst on Kno registration is complete and your content will be available in your Evolve account shortly. ", "Success Message Displayed")){
				Reporters.SuccessReport("The Registration Completion message", "The Registration Completion message Order Number : "+sucMsg+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Registration Completion message", "The Registration Completion is failed to display");
			}*/
	
			if(!javaClick(ElsevierObjects.evolveCatlog_lnk,"Clicked on Evolve Catalog")){
				flag = false;
			}
			 Thread.sleep(medium);
			if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			 Thread.sleep(medium);
			if(!javaClick(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
				flag = false;
			}
			 Thread.sleep(medium);
			if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			 Thread.sleep(medium);
			if(!javaClick(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
				flag = false;
			}
			 Thread.sleep(medium);
			if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			 Thread.sleep(medium);
	
			String sucMsg1=getText(ElsevierObjects.myevolve_pageburstVST_link1, "");
			if(verifyText(ElsevierObjects.myevolve_pageburstVST_link, "Go to Pageburst on Kno library", "Go to Pageburst on Kno library")){
				Reporters.SuccessReport("Go to Pageburst on Kno library Link Validation", "The Link : "+sucMsg1+" is displayed");	
			}else{
				Reporters.failureReport("Go to Pageburst on Kno library Link Validation", "The Link : "+sucMsg1+" is failed to display");
			}
	
		String sucMsg2=getText(ElsevierObjects.myevolve_pageburstVST_link2, "Go to Pageburst on VitalSource library Link");
		if(isElementPresent(ElsevierObjects.myevolve_pageburstVST_link2)){
			Reporters.SuccessReport("Go to Pageburst on VitalSource library Link Validation", "The Link : "+sucMsg2+" is displayed");	
		}else{
			Reporters.failureReport("Go to Pageburst on VitalSource library Link Validation", "The Link : 'Go to Pageburst on VitalSource library' is failed to display");
		}
	}catch(Exception e){
		sgErrMsg=e.getMessage();return false;
	}
	return flag;
	}

}
