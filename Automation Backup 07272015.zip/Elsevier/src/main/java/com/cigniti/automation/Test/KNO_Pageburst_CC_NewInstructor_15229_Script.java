package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.KNOACfromMyCart_Instructor_15237;
import com.cigniti.automation.BusinessFunctions.KNO_Pageburst_CC_NewStudent_15231;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class KNO_Pageburst_CC_NewInstructor_15229_Script extends EvolveCommonBussinessFunctions {

	@Test 
	public void KNOPageburstCCNewInstructor_15229() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			String KnoNumber=readcolumns.twoColumns(0, 1,"Tc-15228", configProps.getProperty("TestData")).get("kno_num");
			
			stepReport("Create new Instructor user");
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String user = "educator";
			EvolveCommonBussinessFunctions.CreateNewUser(user);
			String name = "KNO";
			String accessCode = "false";
			stepReport("Add KNO product to cart and enter checkout");
			KNOACfromMyCart_Instructor_15237.KnoSearch();
			
			String knoUser="newuser";
			stepReport("Complete checkout and submit order");
			EvolveCommonBussinessFunctions.updateVSTandKNOAccount(user, name, accessCode, knoUser);
			
			if(creditCardDetails())
			{
	     		Reporters.SuccessReport("Entering Credit Card Details of "+user, "Credit Card Details of "+user+" Entered Successfully.</br>Successfully Navigated to Review And Submit Page.");
			}
			else
			{
				Reporters.failureReport("Entering Credit Card Details of "+user, "Failed to Enter Credit Card Details of "+user+"</br>Failed to Navigate to Review And Submit Page.");
			}
			KNO_Pageburst_CC_NewStudent_15231.ReviewSubmit(user,KnoNumber);
			
			stepReport("Verify KNO Library link in My Evolve");
			EvolveCommonBussinessFunctions.knoLibrary(user,knoUser);
		
			//String NewUserName=readcolumns.twoColumns(1,1,"DynamicCredentials",configProps.getProperty("TestData")).get(userName);

			if(instructorLogout())
			{
		     	Reporters.SuccessReport("Logout Educator Application:"+credentials[0], "Successfully logged out:"+credentials[0]);
			}
			else
			{
				Reporters.failureReport("Logout Educator Application:"+credentials[0], "Failed to logout:"+credentials[0]);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}

