package com.cigniti.automation.Test;


import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.Evolve_StudentLogin_9795;
import com.cigniti.automation.BusinessFunctions.SelfEnrollLOCourseHomePage_10303;
import com.cigniti.automation.BusinessFunctions.SelfEnrollLOCourse_9796;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;

public class SelfEnrollLOCourse_9796_Script extends SelfEnrollLOCourse_9796{
	
	@Test
	public void SelfEnrollLOCourse9796() throws Throwable{
    String courseid, isbn, title;
	try{
		
		//Step 1:Complete test cases:  LO Unique Course Fulfillment-Faculty and capture the product id
		stepReport("Create and fulfill new LO course for existing instructor.");
		LO_Unique_CourseFulfillment_Faculty_Script_10410 k=new LO_Unique_CourseFulfillment_Faculty_Script_10410();
		k.loUniqueCoursefulfillmentFaculty_10410();
		
		//un-comment below line to run without step1 for debugging purpose
		//courseid="104882_einstein_1083";
		courseid=EvolveCommonBussinessFunctions.courseID1;
		
		isbn=EvolveCommonBussinessFunctions.adoptionRequest_Isbn;
		//un-comment below line to run without step1 for debugging purpose
		//isbn="9780323055536";
		
		title=EvolveCommonBussinessFunctions.title;
		//un-comment below line to run without step1 for debugging purpose
		//title="Medical Terminology Online for Mastering Healthcare Terminology";
		testCaseName ="SelfEnrollLOCourse_9796_Script";
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		
		//Step 2:Create Student User from Student Page 
		//use create new user function
		stepReport("Create new student user.");
		writeReport(EvolveCommonBussinessFunctions.CreateNewUser("student"),"Creating Student User From Student Page.", 
				"Successfuully Created New Student User Username:"+credentials[0]+",Password:"+credentials[1]+"</br>User Now logged Into Evolve Cert As A Student.",
				"Failed To Create New Student User.");
		
		
		//Step 3:In the product search bar, type in the ISBN associated with the course ID in Step #1.
		//Click the button that says "Self Enroll into your Instructor's Course"
		//HESI_Search user business
	   
		//writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigate to Catalog", "Navigate to catalog search page successful", "Navigate to catalog search page failed");
	
		//writeReport(EvolveCommonBussinessFunctions.searchAndGo(isbn),"Search in the ISBN associated with the course ID"+isbn, "Search successful", "Search failed");
		
		stepReport("Search for the ISBN.");
		writeReport(EvolveCommonBussinessFunctions.searchProduct(isbn,productCost),"Serach for the product..",
				  "Successfully Entered ISBN:"+isbn+" in Search Box.</br>Clicked On Go Button.</br>Navigated To Product Details Page.",
				  "Failed to Enter ISBN:"+isbn+" in Search Box.");
		
		//Step 4:Enter the course ID from Step #1 and submit.get serach number from step1 excel
		//Step 5: Verify the correct self enrollment course info displays in the cart.
		//writeReport(EvolveCommonBussinessFunctions.clickEnrollCourse(courseid),"Click on Enroll and search for courseid","Course id search successful","Course id search failed");
		stepReport("Click Enroll and enter the course ID.");
		SelfEnrollLOCourseHomePage_10303.verifySelfEnrollNavigate(courseid,isbn,title);
		
		
		//Step6 : On "My Cart" page, select the radio button to pay with credit card.  Press "Checkout".
		stepReport("Verify details on the My Cart page and click Checkout.");
		SelfEnrollLOCourseHomePage_10303.verifyMyCart();
		
		String courseId="Course ID";
		SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentCourseInfo(courseID1, courseId);
		
		String Title="Title";
		SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentCourseInfo(newTitle,Title);
		
		String firstname="FirstName";
		String educatorName=getAccountDetailsFirstName+" "+getAccountDetailsLastName;
		String FirstName=getAccountDetailsFirstName;
		SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentFacultyName(educatorName, FirstName,firstname);
		
		String lastname="Lastname"; 
		String LastName=getAccountDetailsLastName;
		SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentFacultyName(educatorName,LastName, lastname);
		
		String institutionName=getAccountDetailsInstitution;
		String Institution="Institution";
		SelfEnrollLOCourseHomePage_10303.verifySelfEnrollmentCourseInfo(institutionName, Institution);
		
		SelfEnrollLOCourseHomePage_10303.verifyCheckout();
		
		//Step7 Enter a valid billing address & 8 verify review/submit checkout, Address validation popup
	//	writeReport(EvolveCommonBussinessFunctions.updateVSTandKNOAccount("student","","false",""),"Billing address enter and submit","Billing address enter success","Billing address enter failed");
		stepReport("Complete billing step of checkout.");
		EvolveCommonBussinessFunctions.updateVSTandKNOAccount("student","","false","");
		
		//Step 9 and 10:Enter credit card details , Review and Submit
		String creditCardType=ReadingExcel.columnDataByHeaderName("cardType", "TC-15597", configProps.getProperty("TestData"));
		String creditCardNum=ReadingExcel.columnDataByHeaderName("cardNumber", "TC-15597", configProps.getProperty("TestData"));
		String creditCardCvv=ReadingExcel.columnDataByHeaderName("cardCVV", "TC-15597", configProps.getProperty("TestData"));
		String creditCardName=ReadingExcel.columnDataByHeaderName("cardName", "TC-15597", configProps.getProperty("TestData"));
		String creditCardExpYr=ReadingExcel.columnDataByHeaderName("cardExpYear", "TC-15597", configProps.getProperty("TestData"));
		String creditCardExpMnth=ReadingExcel.columnDataByHeaderName("cardExpMonth", "TC-15597", configProps.getProperty("TestData"));
		
		stepReport("Submit credit card info.");
		SelfEnrollLOCourseHomePage_10303.creditCardData(creditCardType,creditCardNum,creditCardCvv,creditCardName,creditCardExpMnth,creditCardExpYr);
		
		Thread.sleep(veryhigh);
		stepReport("Verify the Review page of checkout.");
		SelfEnrollLOCourseHomePage_10303.StudentReviewandSubmit();
		Thread.sleep(veryhigh);
		
		stepReport("Verify the Receipt page of checkout.");
		SelfEnrollLOCourseHomePage_10303.verifyReceiptPage();
	
		//Step 11 and 12: Click on My evolve link and chk the course id appears under content list
		stepReport("Open the course.");
		SelfEnrollLOCourseHomePage_10303.verifyMyEvolveCourseId();		
		
		//step 13: click on the library folder titled course
		SelfEnrollLOCourse_9796.verifyCoursePage();
		
		//Step 14: Log out of evolvecert and log into evovle admin cert.  Within Admin, click Course PAR Report option.  Search for this course id and enter.
		writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the educator page.", 
				"Sucecssfully logged out the Student:"+credentials[0], 
				"Failed to logout the Student page:"+credentials[0]);
		
		stepReport("Login to Evolve admin.");
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login to Application Using Admin Credentials"+adminUser,
				"Launching the URL for Admin is successfull </br > Login to Application Using Admin credentials :"+adminUser+" is Successfull", 
				"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");
		
		String Accesscode="false";
		stepReport("Verify the Course PAR Report in Evolve admin.");
		EvolveCommonBussinessFunctions.verifyCoursePARReport(courseid,Accesscode);		
		
		//Step 15 : Within Admin, click the View/Edit Evolve User Profile link.	Search by the student's username.  Click on the username on the following page.  
		//Then click the "PAR" button on the Edit User Profile page. 
		stepReport("Verify the student's PAR report in Evolve admin.");
		EvolveCommonBussinessFunctions.verifyMyEvolveAdmin(courseid);
		writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout as "+adminUser,

				"Successfully logged out admin page.", 
			  	"Failed to logout admin page.");	
	}catch(Exception e){
		System.out.println(e.getMessage());
	}
	
	}
	/*@AfterClass
	public static void browserStop()
	{
		driver.close();
	}*/
	
	
}
