package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.VitalSourceAccountAC_HomePage_StudentExists_VST;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class VitalSourceAccountAC_HomePage_NewInstructor_Script_15240 extends VitalSourceAccountAC_HomePage_StudentExists_VST{

	@Test 
	public void vitalSourceAccountAC_HomePage_NewInstructor_15240() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String username=ReadingExcel.columnDataByHeaderName( "VST_StudentUsername", "VST",configProps.getProperty("TestData"));
			String password=ReadingExcel.columnDataByHeaderName( "VST_StudentPassword", "VST",configProps.getProperty("TestData"));
			
			String user = "educator";
			String knoUser="";
			if(CreateNewUser(user))
			{
				Reporters.SuccessReport("Create Faculty User from Faculty Page", "Successfully Created Faculty user with the following credentials: <br> Faculty Username : "+EvolveCommonBussinessFunctions.credentials[0]+"<br> Faculty Password : "+EvolveCommonBussinessFunctions.credentials[1]+"<br> Succussfully logged into the application as faculty user");
			}
			else
			{
				Reporters.failureReport("Create Faculty User from Faculty Page", "Failed to Create Faculty user <br> Failed to logged into the application as faculty user");
			}
			if(pageBurstReedem1()){
				Reporters.SuccessReport("Page burst Reddem access page", "Succesfully navigated to page burst reedeem access page");
			}
			else{
				Reporters.failureReport("Page burst Reddem access page", "Failed to navigated to page burst reedeem access page");
			}
			String name = "VST"; 
			String accessCode = "true";
			if(updateVSTandKNOAccount(user,name,accessCode, knoUser))
			{
	     		Reporters.SuccessReport("Account Updated Successfully", "Account Updation was successfully");
			}
			else
			{
				Reporters.failureReport("Failed to Update Account", "Failed to Update Account.");
			}
			Thread.sleep(medium);
			AccessCodeReviewandSubmitVST(user);
			Thread.sleep(medium);
			String accessCodeUser="educator";
			//String beforeTitle=titleInReceiptPage;
			//String condition="myCartTitle";
			writeReport(VitalSourceAccountAC_HomePage_StudentExists_VST.pageburstVstLink(accessCodeUser, "", ""), "Verify the VST link.", 
					"Succesfully verified the VST link.</br>Successfully Clicked on VST link.</br>Successfully Navigated to VST page.", 
					"Failed to verify the VST link.");
			if(instructorLogout())
			{
				Reporters.SuccessReport("Instructor Log out:", "Successfully logged out as Instructor ");
			}
	       else{
				Reporters.failureReport("Instructor Log out:", "Failed to log out"); 
			}
			Thread.sleep(medium);
			reLogingForAccessCodeRedeem(username,password);
			Thread.sleep(medium);
			ReadingExcel.removeUsedVSTCode(VSTDataPath, "VSTCodes");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ReadingExcel.removeUsedVSTCode(VSTDataPath, "VSTCodes");
		}
	}
	@AfterTest
	public void closeBrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}	
}
