package com.cigniti.automation.Utilities;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadTextFile {
	public static Property configProps=new Property("config.properties");
	public static String readTextFile(String fileName){
		
		StringBuffer readLine =new StringBuffer();
		BufferedReader br = null;
		try 
		{
 
			String sCurrentLine;
			String downloadName = configProps.getProperty("DownLoadFile");
					
					
			br = new BufferedReader(new FileReader(downloadName+fileName+".txt"));
			while ((sCurrentLine = br.readLine()) != null) {
				readLine.append(sCurrentLine);
			}
 
		} catch (IOException e) {
			e.printStackTrace();
		} 
		finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return readLine.toString();
	}
}
