package com.cigniti.automation.Test;

import java.util.Random;

import jxl.Sheet;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.PromotionVariablePercentageInclusions_10227;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class PromotionVariablePercentageInclusions_10227_Script extends PromotionVariablePercentageInclusions_10227{

	public static String DMCodeForUse;

	Random ra = new Random( System.currentTimeMillis() );

	String condition="inclusions";
	@Test
	public void promotionVariablePercentageInclusions_10227() throws Throwable
	{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		String DMCode=ReadingExcel.columnDataByHeaderName("DMcode", "PromotionTestData",configProps.getProperty("TestData"))+Integer.toString((1 + ra.nextInt(2)) * 100000 + ra.nextInt(100000));
		String PromotionCode=ReadingExcel.columnDataByHeaderName("PromotionCode", "PromotionTestData",configProps.getProperty("TestData"));
		String DiscountType=ReadingExcel.columnDataByHeaderName("DiscountType2", "PromotionTestData",configProps.getProperty("TestData"));
		String CampaignCode=ReadingExcel.columnDataByHeaderName("CampaignCode", "PromotionTestData",configProps.getProperty("TestData"));
		String PromotionName=ReadingExcel.columnDataByHeaderName("PromotionName", "PromotionTestData",configProps.getProperty("TestData"));
		String TerritoryCode=ReadingExcel.columnDataByHeaderName("TerritoryCode", "PromotionTestData",configProps.getProperty("TestData"));
		String percentageOff=ReadingExcel.columnDataByHeaderName("PercentageOff", "PromotionTestData",configProps.getProperty("TestData"));
		String percentageOff1=ReadingExcel.columnDataByHeaderName("PercentageOff1", "PromotionTestData",configProps.getProperty("TestData"));
		String invalidPercentage=ReadingExcel.columnDataByHeaderName("invalidPercentage", "PromotionTestData",configProps.getProperty("TestData"));
		String percentage=ReadingExcel.columnDataByHeaderName("percentage", "PromotionTestData",configProps.getProperty("TestData"));		
		DMCodeForUse=DMCode;

		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login as Admin User", "Login as amdin user is Successful",
				"Login Failed");
		Thread.sleep(medium);
		writeReport(PromotionVariablePercentageInclusions_10227.addPromotionLink(), "Adding New Promotions", 
				"Clicking on Promotion Link is successful",
				"Failed to click on Promotion Link");
		Thread.sleep(medium);
		writeReport(PromotionVariablePercentageInclusions_10227.validatePromotionCodeValues(),  "Validate all elements in the Promotion Code Section", "Promotion Code Section elements are validated", "Promotion Code Section elements validation failed");
		Thread.sleep(medium);
		String user="variablePercentage";

		writeReport(PromotionVariablePercentageInclusions_10227.inputValuesInPromotionCode(user,DMCode, "", "", DiscountType, "", PromotionName, TerritoryCode, ""),  
				"Input all the values in Fields and Creating a new Promotion", 
				"All the fields are successfully validated in the above section and Promotion is successfully saved. ", 
				"All the fields are failed to validate in the above section and Promotion is failed to save.");
		Thread.sleep(medium);
		String type="variablepercentage";
		Reporters.SuccessReport("Validate the Profit Center section.", "Validate the Profit Center section");
		writeReport(PromotionVariablePercentageInclusions_10227.validateDifferentSection(type,ElsevierObjects.xpathProfitcenter,condition,ElsevierObjects.Evolve_Admin_Prmlnk_PrtCetr, 
				ElsevierObjects.Evolve_Admin_Prmlnk_AddIncludeBtn, 	ElsevierObjects.Evolve_Admin_Prmlnk_PerFld, percentageOff, 
				percentageOff1,ElsevierObjects.Evolve_Admin_Prmlnk_PrtCetrFailMsg, 
				ElsevierObjects.Evolve_Admin_Prmlnk_IncSucMsg, ElsevierObjects.Evolve_Admin_Prmlnk_IncAdded, 
				ElsevierObjects.Evolve_Admin_Prmlnk_SelcOptionFinal,ElsevierObjects.Evolve_Admin_Prmlnk_SelcOption2, 
				ElsevierObjects.Evolve_Admin_Prmlnk_RemvLink, ElsevierObjects.Evolve_Admin_Prmlnk_EndDate, 
				ElsevierObjects.Evolve_Admin_Prmlnk_PercValue, ElsevierObjects.Evolve_Admin_Prmlnk_SelcOptionFinal, ElsevierObjects.Evolve_Admin_Prmlnk_ViewAllLnk),
				"Validate the Profit Center section","All Products in Profit Center Section are validated successfully", 
				"Profit Center Section validation failed");
		Thread.sleep(medium);
		Reporters.SuccessReport("Validate the Major Subject Code section.", "Validate the Major Subject Code section.");
		writeReport(PromotionVariablePercentageInclusions_10227.validateDifferentSection(type,ElsevierObjects.xpathMajorSubjectCode,condition,ElsevierObjects.Evolve_Admin_Prmlnk_MjrCombo, 
				ElsevierObjects.Evolve_Admin_Prmlnk_MjrAdd, 	ElsevierObjects.Evolve_Admin_Prmlnk_MjrPerFld, percentageOff, 
				percentageOff1, ElsevierObjects.Evolve_Admin_Prmlnk_PrtCetrFailMsg, 
				ElsevierObjects.Evolve_Admin_Prmlnk_IncSucMsg, ElsevierObjects.Evolve_Admin_Prmlnk_MjrBckGrnd, 
				ElsevierObjects.Evolve_Admin_Prmlnk_MjrOption1,ElsevierObjects.Evolve_Admin_Prmlnk_MjrOption2, 
				ElsevierObjects.Evolve_Admin_Prmlnk_MjrRemLnk, ElsevierObjects.Evolve_Admin_Prmlnk_EndDate, 
				ElsevierObjects.Evolve_Admin_Prmlnk_MjrPercValue, ElsevierObjects.Evolve_Admin_Prmlnk_MjrSelFinal, ElsevierObjects.Evolve_Admin_Prmlnk_MjrViewAll),
				"Validate the Major Subject Code section.", "All Products in the Major Subject Code section are validated successfully", 
				"Major Subject Code section validation failed");
		Thread.sleep(medium);
		Reporters.SuccessReport("Validate the Product Type section.", "Validate the Product Type section.");
		writeReport(PromotionVariablePercentageInclusions_10227.validateDifferentSection(type,ElsevierObjects.xpathProductType,condition,ElsevierObjects.Evolve_Admin_Prmlnk_PrdCombo, 
				ElsevierObjects.Evolve_Admin_Prmlnk_PrdAdd, 	ElsevierObjects.Evolve_Admin_Prmlnk_PrdPerFld, percentageOff, 
				percentageOff1,ElsevierObjects.Evolve_Admin_Prmlnk_PrtCetrFailMsg, 
				ElsevierObjects.Evolve_Admin_Prmlnk_IncSucMsg, ElsevierObjects.Evolve_Admin_Prmlnk_PrdBckGrnd, 
				ElsevierObjects.Evolve_Admin_Prmlnk_PrdOption1,ElsevierObjects.Evolve_Admin_Prmlnk_PrdOption2, 
				ElsevierObjects.Evolve_Admin_Prmlnk_PrdRemLnk, ElsevierObjects.Evolve_Admin_Prmlnk_EndDate, 
				ElsevierObjects.Evolve_Admin_Prmlnk_PrdPercValue, ElsevierObjects.Evolve_Admin_Prmlnk_PrdSelFinal, ElsevierObjects.Evolve_Admin_Prmlnk_PrdViewAll),
				"Validate the Product Type section.", "All Products in Product Type Section are validated successfully", 
				"Products in Product Type Section validation failed");

		Thread.sleep(medium);
		writeReport(PromotionVariablePercentageInclusions_10227.validateISBNSection(),
				"Validate ISBN Section", "Include all Products in ISBN Section are validated is successfully", 
				"Include all Products in ISBN Section validation failed");

		Thread.sleep(medium);

		PromotionVariablePercentageInclusions_10227.uploadCSVFile();

		Thread.sleep(medium);
		writeReport(PromotionVariablePercentageInclusions_10227.uploadCSVSection(invalidPercentage, percentageOff1),
				"Validate ISBN Section", "Include all Products in ISBN Section are validated is successfully", 
				"Include all Products in ISBN Section validation failed");
		Reporters.SuccessReport("DM Code for future use : "+DMCodeForUse, "DM Code : "+DMCodeForUse +" is successfully saved for future use : ");
		Thread.sleep(medium);
		writeReport(EvolveCommonBussinessFunctions.adminLogout(),"Clicking on Logout",
				"Clicking on Logout is Successful",
				"Clicking on Logout is not Successful");
	}		

	@AfterClass
	public static void browserStop() throws Throwable
	{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		//Base.tearDown();
	}
}
