package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.HESIStudent_loginexistinguserafteraddtocart_9791;
import com.cigniti.automation.BusinessFunctions.HESI_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;

public class  HESIStudent_loginexistinguserafteraddtocart_Script_9791 extends HESIStudent_loginexistinguserafteraddtocart_9791 {
  @Test
  public void HESIStudent_loginexistinguserafteraddtocart_9791()throws Throwable {
	
		 SwitchToBrowser(ElsevierObjects.studentBrowserType);
	     
		  Country=ReadingExcel.columnDataByHeaderName("Country", "TC-8567",configProps.getProperty("TestData"));
		  State=ReadingExcel.columnDataByHeaderName("State", "TC-8567",configProps.getProperty("TestData"));
		  City=ReadingExcel.columnDataByHeaderName("City", "TC-8567",configProps.getProperty("TestData"));
		  Institute=ReadingExcel.columnDataByHeaderName("InstitutionName","TC-8567",configProps.getProperty("TestData"));
		  Programtype=ReadingExcel.columnDataByHeaderName("Programtype","TC-8567",configProps.getProperty("TestData"));
		  Year=ReadingExcel.columnDataByHeaderName("YearofGraduation","TC-8567",configProps.getProperty("TestData"));
		  StudentId=ReadingExcel.columnDataByHeaderName("StudentId", "TC-8567",configProps.getProperty("TestData")); 
		 
		  stepReport("Create new student user and logout");
		  String user = "student";
		  EvolveCommonBussinessFunctions.CreateNewUser(user);
		  Thread.sleep(2000);
		   
		  EvolveCommonBussinessFunctions.instructorLogout();
		  Thread.sleep(2000);
		  
		  
		  writeReport(EvolveCommonBussinessFunctions.evolve_StudentSearch(),"Enter into application as a student",
				                                                             "EvolveCert URL is launched successfully and entered into application as a student",
				                                                             "Failed to launch the URL and entered into application as a student");
		  Thread.sleep(2000);
		  stepReport("Add HESI to cart, login as student during checkout, and complete order");
		  writeReport(HESIStudent_loginexistinguserafteraddtocart_9791.Hesi_Existing_Student(),"HESIStudent_loginexistinguserafteraddtocart",
                                                                                                "Successfully details are entered in the update page "+     
                                                                                                "</br> Country: "+Country+"</br>"+" State: "+State+"</br>"+ "City: "+City+"</br>"+ "Institute: "+Institute+
                                                                                                "</br>"+"Programtype: "+Programtype+"</br>"+"Year: "+Year+"</br>"+"StudentId:"+StudentId,
                                                                                                "Failed to click on HesiExams,Registration for Hesi and To enter details in the register page");
		  Thread.sleep(2000);
		  stepReport("Verify receipt page");
		  writeReport(HESIStudent_loginexistinguserafteraddtocart_9791.Confirmationpage(),"Verify the details of confirmation page",
				                                                                           "Successfully details in confirmation page is verified",
				                                                                           "Failed to verify the details in confirmation page");
		   
		  writeReport(HESI_BusinessFunction.getAccountDetails("studentUpdate"), "Fetching Account Details From MyAccount Page.", 
					"Successfully Fetched Username: "+getAccountDetailsUserName+"</br>Successfully Fetched FirstName: "+getAccountDetailsFirstName+"</br>Successfully Fetched Lastname: "+getAccountDetailsLastName+"</br>Successfully Fetched Email: "+getAccountDetailsEmail,"Failed to Fetch Account Details From MyAccount Page. ");
			
		  Thread.sleep(2000);
		  stepReport("Verify HESI email");
		  EvolveCommonBussinessFunctions.HesiEmailVerification();
  }
}
