package com.cigniti.automation.BusinessFunctions;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
public class ZFindProtectionSchemeSelfStudyCourse_15571 extends EvolveCommonBussinessFunctions{

	public static boolean loginEcertAdminPortal() throws Throwable{
		try{
			boolean flag=true;
			driver.manage().deleteAllCookies();
			if(!launchUrl(configProps.getProperty("URL"))){
				flag = false;
			}
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			Thread.sleep(medium);
			if(!type(ElsevierObjects.Admin_Evolve_Ecom_EvoleStuUsername, configProps.getProperty("ecertAdminUserID"),"Email")){
				flag = false;
			}
			if(!type(ElsevierObjects.Admin_Evolve_Ecom_EvoleStuPassword, configProps.getProperty("ecertAdminPassword"),"Email")){
				flag = false;
			}
			if(click(ElsevierObjects.Admin_Evolve_Ecom_EvoleSign,"Clicked on Login Button")){
				Reporters.SuccessReport("Log into evolvecert as a Portal Administrator", "Successfully logged into evolvecert as a Portal Administrator with Valid credentials<br>Portal Administrator Username : "+configProps.getProperty("ecertAdminUserID")+"<br> Portal Administrator Password : "+configProps.getProperty("ecertAdminPassword"));
			}else{
				Reporters.failureReport("Log into evolvecert as a Portal Administrator", "Failed to log into evolvecert as a Portal Administrator with Valid credentials<br>Portal Administrator Username : "+configProps.getProperty("ecertAdminUserID")+"<br> Portal Administrator Password : "+configProps.getProperty("ecertAdminPassword"));
			}
			return flag;			
		}catch(Exception e){return false;}
	}

	public static boolean protectionSchemeSelfStudyCourse(String product, String user) throws Throwable{
		boolean flag=true;	

		try{
			System.out.println("");
			if(click(ElsevierObjects.Ecert_Admin_MyAcc, "Click on the My Account Link")){
				Reporters.SuccessReport("Click the My Account link", "Successfully Clicked on the My Account Link");	
			}else{
				Reporters.failureReport("Click the My Account link", "Failed to Click on the My Account Link");
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.Ecert_Admin_PortalLink, "Click on the Administration Portal Link")){
				Reporters.SuccessReport("Click the Portal Administration option from the dropdown", "Successfully Clicked on the Portal Administration option from the dropdown");	
			}else{
				Reporters.failureReport("Click the Portal Administration option from the dropdown", "Failed to Click on the Portal Administration option from the dropdown");
			}
			Thread.sleep(medium);

			String adminPortal=getText(By.xpath(".//*[@id='stdHeader']/h1[text()='Administration Portal']"), "");
			if(adminPortal!=null){
				Reporters.SuccessReport("Validate the User is taken to the Portal Administration screen.", "User is Successfully taken to the Portal Administration screen. "+adminPortal+" is displayed on the page : "+driver.getCurrentUrl());	
			}else{
				Reporters.failureReport("Validate the User is taken to the Portal Administration screen.", "User is not taken to the Portal Administration screen. "+adminPortal+" is displayed on the page : "+driver.getCurrentUrl());
			}
			if(user.equalsIgnoreCase("ecommercePreOrder")){
				if(click(ElsevierObjects.Ecert_Admin_coursesLink, "Click on Global link on the page")){
					Reporters.SuccessReport("Click the Global Resources link.", "Successfully Clicked on the Global Resources link");
				}else{
					Reporters.failureReport("Click the Global Resources link.", "Failed to Click on the Global Resources link");
				}
			}else{
				if(click(ElsevierObjects.Ecert_Admin_GlobalLink, "Click on Global link on the page")){
					Reporters.SuccessReport("Click the Global Resources link.", "Successfully Clicked on the Global Resources link");
				}else{
					Reporters.failureReport("Click the Global Resources link.", "Failed to Click on the Global Resources link");
				}
				String globalResource=getText(ElsevierObjects.AdminPortalMsg, "");
				if(globalResource!=null){
					Reporters.SuccessReport("Validate the User is taken to the Portal Administration screen.", "User is Successfully taken to the Portal Administration screen. "+globalResource+" is displayed on the page : <br>"+driver.getCurrentUrl());	
				}else{
					Reporters.failureReport("Validate the User is taken to the Portal Administration screen.", "User is not taken to the Portal Administration screen. "+globalResource+" is displayed on the page : <br>"+driver.getCurrentUrl());
				}
			}

			Thread.sleep(medium);
			if(type(ElsevierObjects.Ecert_Admin_Filter, product, "Type the product "+product)){
				Reporters.SuccessReport("In the search field, enter the self study course id  : "+product, " Successfully able to enter the self study course id  : "+product);
			}else{
				Reporters.failureReport("In the search field, enter the self study course id  : "+product, " Failed to enter the self study course id");
			}
			Thread.sleep(high);
			List<WebElement> element=driver.findElements(ElsevierObjects.Ecert_Admin_TableRow);
			int size=element.size();
			String resultDisplay=getText(ElsevierObjects.displayCount, "");
			if(user.equalsIgnoreCase("ecommercePreOrder")){
				if(size==1){
					System.out.println("Contains only one row");
					Reporters.SuccessReport("One result should now display in the results.", "Only One result is now display in the results. <br> Results showing is : "+resultDisplay);
				}else{
					System.out.println("Contains more than one row");
					Reporters.failureReport("One result should now display in the results.", "More than One result is now display in the results. <br> Results showing is : "+resultDisplay);
				}
			}
			List<WebElement> tableheaders=driver.findElements(ElsevierObjects.Ecert_Admin_Tableheader);
			int sizeheader=tableheaders.size();

			String tableRow=tableheaders.get(2).getText();
			Reporters.SuccessReport("Results Showing in the Table after Search", "Results are shown in the table are : "+tableRow);

			Actions actions = new Actions(driver);
			WebElement tableContent = driver.findElement(ElsevierObjects.Ecert_Admin_TableContent);

			actions.doubleClick(tableContent).build().perform();

			Thread.sleep(high);

			if(user.equalsIgnoreCase("ecommercePreOrder")){
				//Thread.sleep(medium);
				//driver.manage().timeouts().implicitlyWait(400, TimeUnit.SECONDS);

				//Thread.sleep(veryhigh);
				//Thread.sleep(veryhigh);
				Thread.sleep(60000);
				
				if(click(ElsevierObjects.Ecert_Admin_ContentHome, "Click on the Content Home Link")){
					Reporters.SuccessReport("Click on the Content Home link", "Successfully Clicked on the Content Home link");
				}else{
					Reporters.failureReport("Click on the Content Home link", "Failed to Click on the Content Home link");
				}
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				Thread.sleep(medium);
				driver.navigate().refresh();
				driver.navigate().refresh();
				Thread.sleep(medium);
				/*	List<WebElement> editList  = driver.findElements(By.xpath("//a[text()='Edit  ']"));
				editList.get(1).click();
				if(editList.get(1)!=null){
					Reporters.SuccessReport("In the main window of the page click on the 'Edit' button on the 'Courses' folder.", "In the main window of the page successfully clicked on the 'Edit' button on the 'Courses' folder.");
				}else{
					Reporters.failureReport("In the main window of the page click on the 'Edit' button on the 'Courses' folder.", "In the main window of the page failed to click on the 'Edit' button on the 'Courses' folder.");
				}
				 */
				if(click(By.xpath(".//*[@id='el-pane']//div//a[text()='Course']//self::a//following::div//a[text()='Edit  ']"),"")){
					Reporters.SuccessReport("In the main window of the page click on the 'Edit' button on the 'Courses' folder.", "In the main window of the page successfully clicked on the 'Edit' button on the 'Courses' folder.");
				}else{
					Reporters.failureReport("In the main window of the page click on the 'Edit' button on the 'Courses' folder.", "In the main window of the page failed to click on the 'Edit' button on the 'Courses' folder.");
				}
				Thread.sleep(medium);

				if(click(By.xpath(".//*[@id='el-pane']//div//a[text()='Course']//self::a//following::div//a//span[text()='About']"),"")){
					Reporters.SuccessReport("Choose 'About' from the options. ", "Successfully Choosen 'About' from the options. ");
				}else{
					Reporters.failureReport("Choose 'About' from the options. ", "Failed to Choose 'About' from the options. ");
				}
				/*List<WebElement> e=driver.findElements(By.xpath(".//*[@id='content-area']//div[contains(text(),'Edit')]//following::div[contains(@class,'edit-content-dropdown dropdown pull-right')]/a"));
				e.get(0).click();
				Thread.sleep(medium);
				List<WebElement> e1=driver.findElements(By.xpath(".//*[@id='content-area']//div[contains(text(),'Edit')]//following::div[contains(@class,'edit-content-dropdown dropdown pull-right')]//li//a/span[text()='About']"));
				e1.get(0).click();*/

				Thread.sleep(high);
			}
			if(user.equalsIgnoreCase("loSelfStudy")){
				if(click(ElsevierObjects.Ecert_Admin_ContentHome, "Click on the Content Home Link")){
					Reporters.SuccessReport("Click on the Content Home link", "Successfully Clicked on the Content Home link");
				}else{
					Reporters.failureReport("Click on the Content Home link", "Failed to Click on the Content Home link");
				}
				Thread.sleep(high);
				/*if(click(By.xpath("(.//*[@id='content-area']//a[@class='btn'])[1]"),"")){
					Reporters.SuccessReport("In the main window of the page click on the 'Edit' button on the 'Course' folder.", "In the main window of the page successfully clicked on the 'Edit' button on the 'Course' folder.");
				}else{
					Reporters.failureReport("In the main window of the page click on the 'Edit' button on the 'Course' folder.", "In the main window of the page failed to click on the 'Edit' button on the 'Course' folder.");
				}
				Thread.sleep(medium);*/
				
				if(click(ElsevierObjects.educator_CoursePage_EditLink,"")){
					Reporters.SuccessReport("In the main window of the page click on the 'Edit' button on the 'Course' folder.", "In the main window of the page successfully clicked on the 'Edit' button on the 'Course' folder.");
				}else{
					Reporters.failureReport("In the main window of the page click on the 'Edit' button on the 'Course' folder.", "In the main window of the page failed to click on the 'Edit' button on the 'Course' folder.");
				}
				Thread.sleep(medium);

				/*if(click(By.xpath(".//*[@id='el-pane']//div//a[text()='Course']//self::a//following::div//a//span[text()='About']"),"")){
					Reporters.SuccessReport("Choose 'About' from the options. ", "Successfully Choosen 'About' from the options. ");
				}else{
					Reporters.failureReport("Choose 'About' from the options. ", "Failed to Choose 'About' from the options. ");
				}*/
				
				if(click(ElsevierObjects.educator_CoursePage_EditLink_About,"")){
					Reporters.SuccessReport("Choose 'About' from the options. ", "Successfully Choosen 'About' from the options. ");
				}else{
					Reporters.failureReport("Choose 'About' from the options. ", "Failed to Choose 'About' from the options. ");
				}
			}
			if(user.equalsIgnoreCase("")){
				if(click(ElsevierObjects.Ecert_Admin_ContentHome, "Click on the Content Home Link")){
					Reporters.SuccessReport("Click on the Content Home link", "Successfully Clicked on the Content Home link");
				}else{
					Reporters.failureReport("Click on the Content Home link", "Failed to Click on the Content Home link");
				}
				Thread.sleep(high);
				if(click(By.xpath(".//*[@id='el-pane']//div//a[text()='Course']//self::a//following::div//a[text()='Edit  ']"),"")){
					Reporters.SuccessReport("In the main window of the page click on the 'Edit' button on the 'Courses' folder.", "In the main window of the page successfully clicked on the 'Edit' button on the 'Courses' folder.");
				}else{
					Reporters.failureReport("In the main window of the page click on the 'Edit' button on the 'Courses' folder.", "In the main window of the page failed to click on the 'Edit' button on the 'Courses' folder.");
				}
				Thread.sleep(medium);

				if(click(By.xpath(".//*[@id='el-pane']//div//a[text()='Course']//self::a//following::div//a//span[text()='About']"),"")){
					Reporters.SuccessReport("Choose 'About' from the options. ", "Successfully Choosen 'About' from the options. ");
				}else{
					Reporters.failureReport("Choose 'About' from the options. ", "Failed to Choose 'About' from the options. ");
				}
				Thread.sleep(medium);

			}

			Thread.sleep(medium);
			String protectionSchemeText=getText(ElsevierObjects.Ecert_Admin_ProtectionSchemeID, "Protection scheme text.");
			Thread.sleep(medium);
			String pageLink=getText(ElsevierObjects.aboutLinkPage, "");
			if(pageLink!=null){
				Reporters.SuccessReport("User will be displayed a pop up titled About Link with info on the content. ", "User is Successfully taken to the pop up titled : "+pageLink+" with info on the content." );	
			}else{
				Reporters.failureReport("User will be displayed a pop up titled About Link with info on the content. ", "User is Failed to taken to the pop up titled : About Link with info on the content." );
			}
			//protectionSchemeID=protectionSchemeText.split("\\(")[1].replaceAll("\\)", "");
			int start = protectionSchemeText.indexOf('(');
			int end = protectionSchemeText.indexOf(')');
			protectionSchemeID = protectionSchemeText.substring(start + 1, end);
			ReadingExcel.updateCellInSheet(1,2,configProps.getProperty("TestData"), "TC-15590", protectionSchemeID);
			Thread.sleep(medium);
			System.out.println(protectionSchemeID);
			Reporters.SuccessReport("Protection Scheme saved for future test case", "The Protection Scheme is Successfully saved for future Test cases is : " +protectionSchemeText);
		}catch(Exception e){return false;}
		return flag;
	}

}
