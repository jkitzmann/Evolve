package com.cigniti.automation.BusinessFunctions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class VitalSourceAccountAC_HomePage_StudentExists_VST extends EvolveCommonBussinessFunctions {

	public static String accessCodeSetName;
	public static String AccessCodeTableData;
	public static String accessCode;
	public static String accesscode_price;
	public static String accesscode_Isbn;
	public static String acessCode_afterRequest;
	public static String accessCode_title;
	public static String acessCode_titleAfterRequest;
	public static String accesscodeVST;
	public static String ExpectedPrice="$0.00";

	public static boolean  login ( String user, String userName,String password) throws Throwable{
		boolean flag=true;
		driver.manage().deleteAllCookies();
		Thread.sleep(medium);

		/*if(!clickOnMainPageLink()){
			flag=false;
		}*/
		if(user.equalsIgnoreCase("instructor")){

			/*	if(click(ElsevierObjects.iameducator, "Clicked on Educator")){
				Reporters.SuccessReport("Click on Educator Link", "Successfully Clicked on Educator Link on Main Page");
			} else{
				Reporters.failureReport("Click on Educator Link", "Failed to Click on Educator Link on Main Page");
			}*/
			if(!launchUrl(configProps.getProperty("URL3"))){
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.login, "login link")){
				flag = false;
			} 
			Thread.sleep(medium);
			type(ElsevierObjects.common_login_userName,userName.trim(),"UserName");
			type(ElsevierObjects.common_login_passWord,password.trim(),"Password");
			if(click(ElsevierObjects.submit,"Click on submit")){
				Reporters.SuccessReport("Click on Login button for Educator user", "Successfully clicked on the login button for Instructor User");
			}else{
				Reporters.failureReport("Click on Login button for Educator user", "Successfully clicked on the login button for Instructor User");
			}
			Thread.sleep(medium);
		}else{
			/*if(click(ElsevierObjects.home_student_lnkstudent,"Clicked On student Link")){
				Reporters.SuccessReport("Click on Student Link", "Successfully Clicked on Student Link on Main Page");
			} else{
				Reporters.failureReport("Click on Student Link", "Failed to Click on Student Link on Main Page");
			}*/
			if(!launchUrl(configProps.getProperty("URL4"))){
				flag = false;
			}
			if(!click(ElsevierObjects.student_login,"Clicked On student LogIn")){
				flag = false;
			}
			Thread.sleep(medium);
			type(ElsevierObjects.common_login_userName,userName.trim(),"UserName");
			type(ElsevierObjects.common_login_passWord,password.trim(),"Password");
			if(click(ElsevierObjects.submit,"Click on submit")){
				Reporters.SuccessReport("Click on Login button for Student user", "Successfully clicked on the login button for Student User");
			}else{
				Reporters.failureReport("Click on Login button for Student user", "Successfully clicked on the login button for Student User");
			}
			Thread.sleep(medium);
		}
		return flag;
	} 


	public static boolean pageBurstReedem1() throws Throwable{
		boolean flag=true;
		try{
			if(!click(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
				flag = false;
			}
			
			// this no longer applies with the new design
			/*if(javaClick(ElsevierObjects.evolve_Pageburst,"Click on evolve page brust")){
				Reporters.SuccessReport("Clicked on Pageburst header", "Successfully Clicked on Pageburst header");
			}else{
				Reporters.failureReport("Clicked on Pageburst header", "Failed Clicked on Pageburst header");
			}
			if(javaClick(ElsevierObjects.evolve_Pageburst_Reedemlnk,"Click on Reedem Access code link")){
				Reporters.SuccessReport("Click the 'Redeem an access code' link.", "Successfully Clicked on the 'Redeem an access code' link. <br> User is brought to a Pageburst page where there is access code blank.");
			}else{
				Reporters.failureReport("Click the 'Redeem an access code' link.", "Failed to Click on 'Redeem an access code' link. <br> User is brought to a Pageburst page where there is access code blank.");
			}*/
			//System.out.println("accessCode:"+accessCode);
			//readcolumns.twoColumns(0, 1, 9, configProps.getProperty("TestData")).get("searchNumber")
			//String vstCode=readcolumns.twoColumnsBasedOnSheetName(0, 1, "createNewaccount", configProps.getProperty("TestData")).get("NewAccessCode");
			String vstValid=ReadingExcel.getCell(0, 0, VSTDataPath, "VSTCodes");
			if(type(ElsevierObjects.evolve_Reedemlnk_AccessCode, vstValid ,"Enter Access code")){
				Reporters.SuccessReport("Enter a valid VST access code", "The Valid VST Access Code : "+vstValid+" is entered successfully");
			}else{
				Reporters.failureReport("Enter a valid VST access code", "The Valid VST Access Code : "+vstValid+" is Failed to enter into the text box");
			}
			if(!javaClick(ElsevierObjects.evolve_AccessCode_Submitbtn,"Click on Access code submit button")){
				flag=false;
			}
			accesscode_price=getText(ElsevierObjects.evolve_Product_priceAfterRequest,"Price of access code product");
			accesscode_Isbn=getText(ElsevierObjects.evolve_Accesscode_isbn, "Isbn of product with access code");
			//acessCode_afterRequest=getText(ElsevierObjects.evolve_AccessCode_afterRequest,"Access code");
			acessCode_afterRequest=driver.findElement(ElsevierObjects.evolve_AccessCode_afterRequest).getAttribute("value");
			acessCode_titleAfterRequest=getText(ElsevierObjects.evolve_Product_titleAfterRequest, "title of access code product");
			accessCode_totalPrice=getText(ElsevierObjects.evolve_AccessCode_totalprice, "total product price");
			accesscodeVST = vstValid/*readcolumns.twoColumnsBasedOnSheetName(0, 1, "createNewaccount", configProps.getProperty("TestData")).get("NewAccessCode")*/;


			if(accesscode_price.contains(ExpectedPrice) /*&& accessCode_totalPrice.contains(ExpectedPrice)*/ && accesscodeVST.trim().contains(acessCode_afterRequest.trim())){
				if(javaClick(ElsevierObjects.evolve_checkout_btn,"Click on Access code checkout Button")){
					Reporters.SuccessReport("Verify the item title and access code", "Successfully Clicked on Submit Button and Captured the below details: <br> Price : "+accesscode_price+"<br> Access Code : "+acessCode_afterRequest+"<br> ISBN : "+accesscode_Isbn+"<br> Title is : "+acessCode_titleAfterRequest+"<br> Total Price : "+accessCode_totalPrice);
				}else{
					Reporters.failureReport("Verify the item title and access code", "Failed to Click on Submit Button and Failed to Capture the details of ISBN : "+accesscode_Isbn);
				}
			}
		}catch(Exception e){System.out.println(sgErrMsg);return false;}
		return flag;
	}

	public static boolean accessCodeAccountUpdateVST()  throws Throwable {
		boolean flag=true;

		if(!click(ElsevierObjects.student_chkInstution,"Click on NO Institution Chkbox")){
			flag=false;
		}
		if(!click(ElsevierObjects.evolve_User_submitbtn,"Click submit button")){
			flag=false;
		}

		return flag;

	}

	public static boolean AccessCodeReviewandSubmitVST(String user) throws Throwable{
		boolean flag=true;
		Thread.sleep(high);
		priceInReviewPage=getText(ElsevierObjects.evolve_Rview_chkprice, "price in review page");
		isbnInReviewPage=getText(ElsevierObjects.evolve_Rview_chkIsbn,"Isbn in review page");
		titleInReviewPage=getText(ElsevierObjects.evolve_Rview_chktitle, "Title in review page");

		if(user.equalsIgnoreCase("educator")){

			if(priceInReviewPage.contains(ExpectedPrice) && accessCode_totalPrice.contains(ExpectedPrice)){
				Reporters.SuccessReport("Press Checkout button", "User is brought to the review/submit checkout page where the item is present and info is correct  <br> Price is : "+priceInReviewPage+"<br> Title is : "+titleInReviewPage+"<br> ISBN is : "+isbnInReviewPage);
				if(!click(ElsevierObjects.evolveInstructorChk,"Click on Instructor checkbox")){
					flag=false;
				}
				Thread.sleep(medium);
				if(!click(ElsevierObjects.evolveRegisterAcceptChk,"Click on Register checkbox")){
					flag=false;
				}
				Thread.sleep(medium);
				if(!click(ElsevierObjects.instructor_submit,"Click on Instructor Submit button")){
					flag=false;
				}
			}else{
				Reporters.failureReport("Press Checkout button", "User is failed to brought to the review/submit checkout page where the item is present and info is not correct");
			}
			Thread.sleep(medium);

		}else{

			if(priceInReviewPage.contains(ExpectedPrice) && accessCode_totalPrice.contains(ExpectedPrice)){
				Reporters.SuccessReport("Press Checkout button", "User is brought to the review/submit checkout page where the item is present and info is correct  <br>Expected Total Price is : "+accessCode_totalPrice+"<br> Actual Total Price is : "+ExpectedPrice+"<br> Expected Price is : "+priceInReviewPage+"<br> Actual Price is : "+ExpectedPrice);
				if(!click(ElsevierObjects.evolveRegisterAcceptChk,"Click on Register checkbox")){
					flag=false;
				}
				Thread.sleep(medium);
				if(!click(ElsevierObjects.instructor_submit,"Click on Instructor Submit button")){
					flag=false;
				}
			}else{
				Reporters.failureReport("Press Checkout button", "User is failed brought to the review/submit checkout page where the item is present and info is not correct  <br>Expected Total Price is : "+accessCode_totalPrice+"<br> Actual Total Price is : "+ExpectedPrice+"<br> Expected Price is : "+priceInReviewPage+"<br> Actual Price is : "+ExpectedPrice);
			}
			Thread.sleep(medium);
		}	

		piceInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chkprice,"Price in Receipt page");
		titleInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chktitle,"Price in Receipt page");
		isbnInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chktisbn,"Price in Receipt page");

		if(piceInReceiptPage.contains(ExpectedPrice) && accessCode_totalPrice.contains(ExpectedPrice)){	
			Reporters.SuccessReport("Press Submit button", "User is brought to receipt page where info is correct.  <br>Expected Total Price in Receipt Page is : "+accessCode_totalPrice+"<br> Actual Total Price in Receipt Page is : "+ExpectedPrice+"<br> Expected Price in Receipt Page is : "+piceInReceiptPage+"<br> Actual Price is in Receipt Page is : "+ExpectedPrice);
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Kno_refresh_lnk,"Click on refresh link in evolve page")){
				flag=false;
			}

		}else{
			Reporters.failureReport("Press Submit button", "User is failed to brought to receipt page where info is not correct.  <br>Expected Total Price in Receipt Page is : "+accessCode_totalPrice+"<br> Actual Total Price in Receipt Page is : "+ExpectedPrice+"<br> Expected Price in Receipt Page is : "+piceInReceiptPage+"<br> Actual Price is in Receipt Page is : "+ExpectedPrice);
		}
		return flag;	
	}

	public static boolean pageburstVstLink(String accessCodeUser, String title, String condition) throws Throwable{
		boolean flag = true;

		/*if(waitForVisibilityOfElement(ElsevierObjects.myevolve_pageburstVST_link, "Wait until the VST Link is Present")){
			click(ElsevierObjects.Kno_refresh_lnk, "");
			//driver.navigate().refresh();
		}else{
			if(!click(ElsevierObjects.myevolve_pageburstVST_link,"Click on VST Link in evolve page.")){
				flag=false;
			}
		}*/
		if(!javaClick(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
			flag = false;
		}
		Thread.sleep(medium);
		if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
			flag=false;
		}
		Thread.sleep(medium);
		if(!javaClick(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
			flag = false;
		}
		Thread.sleep(medium);
		if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
			flag=false;
		}
		Thread.sleep(medium);
		String sucMsg=getText(ElsevierObjects.myevolve_pageburstVST_link, "");
		if(verifyText(ElsevierObjects.myevolve_pageburstVST_link, "Go to Pageburst on VitalSource library", "Go to Pageburst on VitalSource library")){
			Reporters.SuccessReport("Go to Pageburst on VitalSource library Link Validation", "The Link : "+sucMsg+" is displayed");	
		}else{
			Reporters.failureReport("Go to Pageburst on VitalSource library Link Validation", "The Link : "+sucMsg+" is failed to display");
		}
		Thread.sleep(high);
		if(click(ElsevierObjects.myevolve_pageburstVST_link,"Click on VST Link in evolve page.")){
			Reporters.SuccessReport("Click on Pageburst on VitalSource library Link ", "The Link : "+sucMsg+" is displayed <br> Successfully clicked on the link : "+sucMsg);	
		}else{
			Reporters.failureReport("Click on Pageburst on VitalSource library Link ", "The Link : "+sucMsg+" is not displayed <br> Failed to click on the link : "+sucMsg);
		}
		Thread.sleep(medium);
		if(accessCodeUser.equalsIgnoreCase("student")|| accessCodeUser.equalsIgnoreCase("educator")){			
			if(javaClick(ElsevierObjects.acceptForVSTLink,"Click on Accept Licence for VST ")){
				Reporters.SuccessReport("Verify User is brought into the VST application without error.", "User is brought into the VST application without error. and Successfully Clicked on Accept Button");
			}	else{
				Reporters.failureReport("Verify User is brought into the VST application without error.", "User is failed to brought into the VST application without error. and Failed to Click on Accept Button");
			}
			Thread.sleep(medium);
		}
		Thread.sleep(high);
		String vstTitle=getText(ElsevierObjects.vstLinkTitle, "");
		List<WebElement> titles=driver.findElements(By.xpath(".//*[@id='all_titles_grid']//li//div[contains(@class,'griditem')]//a//div[contains(@class,'title')]"));
		for(WebElement e: titles){
			String titleofprd=e.getText();
			if(titleofprd!=null){
				Reporters.SuccessReport("Verify the book present in VST application", "The book is present in VST application <br>Title of the Book is : "+titleofprd);
			}else{
				Reporters.failureReport("Verify the book present in VST application", "The book not present in VST application <br>Title of the Book is : "+titleofprd);
			}
		}


		/*if(isElementPresent(ElsevierObjects.vstLinkTitle, "")){
			Reporters.SuccessReport("Verify the book present in VST application", "The book is present in VST application <br>Title of the Book is : "+vstTitle);
		}else{
			Reporters.failureReport("Verify the book present in VST application", "The book not present in VST application <br>Title of the Book is : "+vstTitle);
		}*/
		if(condition.equalsIgnoreCase("myCartTitle")){

			if(title.replace("-", "").trim().contains(titles.get(0).getText().replace("-", "").replace(":", "").trim())){
				Reporters.SuccessReport("Verify the correct book is added for the user", "The book is added in the VST <br>Actual Title of the Book is : "+vstTitle +"<br> Expected Title of the Book is : "+title);
			}else{
				Reporters.failureReport("Verify the correct book is added for the user", "The book is failed to add in the VST <br>Actual Title of the Book is : "+vstTitle +"<br> Expected Title of the Book is : "+title);
			}

			/*if(user1=="existingStdEducator"){
				if(title.replace("-", "").trim().contains(titles.get(1).getText().replace("-", "").replace(":", "").trim())){
					Reporters.SuccessReport("Verify the correct book is added for the user", "The book is added in the VST <br>Actual Title of the Book is : "+title +"<br> Expected Title of the Book is : "+vstTitle);
				}else{
					Reporters.failureReport("Verify the correct book is added for the user", "The book is failed to add in the VST <br>Actual Title of the Book is : "+title +"<br> Expected Title of the Book is : "+vstTitle);
				}
			}*/

		}

		if(condition.equalsIgnoreCase("existingStudEducator")){
			if(title.replace("-", "").trim().contains(titles.get(1).getText().replace("-", "").replace(":", "").trim())){
				Reporters.SuccessReport("Verify the correct book is added for the user", "The book is added in the VST <br>Actual Title of the Book is : "+titles.get(1).getText() +"<br> Expected Title of the Book is : "+title);
			}else{
				Reporters.failureReport("Verify the correct book is added for the user", "The book is failed to add in the VST <br>Actual Title of the Book is : "+titles.get(1).getText() +"<br> Expected Title of the Book is : "+title);
			}
		}

		if(condition.equalsIgnoreCase("validTitle")){
			List<WebElement> titleInVSTPage=driver.findElements(By.xpath(".//*[@id='all_titles_grid']//li//div[contains(@class,'griditem')]//a//div[contains(@class,'title')]"));
			String pageBurstTitle=ReadingExcel.columnDataByHeaderName( "pageBurstTitle", "VST",configProps.getProperty("TestData"));
			//String pageBurstTitle=tcVST_KNO.get("pageBurstTitle");
			String vstTitleinVSTPage=ReadingExcel.columnDataByHeaderName( "vstTitle", "VST",configProps.getProperty("TestData"));
			//String vstTitleinVSTPage=tcVST_KNO.get("vstTitle");
			if(pageBurstTitle.replace("-", "").trim().contains(titleInVSTPage.get(1).getText().replace("-", "").replace(":", "").trim())){
				Reporters.SuccessReport("Verify the correct book is already exits for the user", "The book is already exits in the VST <br>Actual Title of the Book is : "+titles.get(0).getText() +"<br> Expected Title of the Book is : "+pageBurstTitle);
			}else{
				Reporters.failureReport("Verify the correct book is already exits for the user", "The book is failed to add in the VST <br>Actual Title of the Book is : "+titles.get(0).getText() +"<br> Expected Title of the Book is : "+pageBurstTitle);
			}
			if(titleInVSTPage.get(1).getText().contains(vstTitleinVSTPage)){
				Reporters.SuccessReport("Verify the correct book is already exits for the user", "The book is already exits in the VST <br>Actual Title of the Book is : "+titles.get(1).getText() +"<br> Expected Title of the Book is : "+titleInVSTPage.get(1).getText());
			}else{
				Reporters.failureReport("Verify the correct book is already exits for the user", "The book doesnot exists in the VST <br>Actual Title of the Book is : "+titles.get(1).getText() +"<br> Expected Title of the Book is : "+titleInVSTPage.get(1).getText());
			}
		}
		Thread.sleep(medium);
		driver.navigate().to(configProps.getProperty("URL"));
		/*driver.navigate().back();
			driver.navigate().back();*/

		return flag;
	}



	public static boolean reLogingForAccessCodeRedeem(String username, String password) throws Throwable{
		boolean flag = true;
		launchUrl(configProps.getProperty("URL4"));
		/*clickOnMainPageLink();
		if(!click(ElsevierObjects.home_student_lnkstudent,"Clicked On student Link")){
			flag = false;
		}*/
		Thread.sleep(high);
		if(!click(ElsevierObjects.student_login,"Clicked On student LogIn")){
			flag = false;
		}
		Thread.sleep(high);
		if(!type(ElsevierObjects.email,username,"Enter Usernmae")){
			flag = false;
		}

		Thread.sleep(medium);
		if(!type(ElsevierObjects.password,password,"Enter Password")){
			flag = false;
		}
		Thread.sleep(medium);
		if(click(ElsevierObjects.submit,"Clicked on Login Button")){
			Reporters.SuccessReport("Log into the User Portal as Student", "Successfully logged into the application as student user with the valid credentials <br> Student User Name is : "+configProps.getProperty("VST_StudentUsername")+"<br> Student Password is : "+configProps.getProperty("VST_StudentPassword"));
		}else{
			Reporters.failureReport("Log into the User Portal as Student", "Failed to log into the application as student user with the valid credentials <br> Student User Name is : "+configProps.getProperty("VST_StudentUsername")+"<br> Student Password is : "+configProps.getProperty("VST_StudentPassword"));
		}
		Thread.sleep(medium);
		if(!click(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
			flag = false;
		}

		
		// this no longer applies with the new design
		/*if(javaClick(ElsevierObjects.evolve_Pageburst,"Click on evolve page brust")){
			Reporters.SuccessReport("Clicked on Pageburst header", "Successfully Clicked on Pageburst header");
		}else{
			Reporters.failureReport("Clicked on Pageburst header", "Failed Clicked on Pageburst header");
		}
		Thread.sleep(medium);
		if(javaClick(ElsevierObjects.evolve_Pageburst_Reedemlnk,"Click on Reedem Access code link")){
			Reporters.SuccessReport("Click the 'Redeem an access code' link.", "Successfully Clicked on the 'Redeem an access code' link. <br> User is brought to a Pageburst page where there is access code blank.");
		}else{
			Reporters.failureReport("Click the 'Redeem an access code' link.", "Failed to Click on 'Redeem an access code' link. <br> User is brought to a Pageburst page where there is access code blank.");
		}*/
		
		Thread.sleep(medium);
		String vstValid=ReadingExcel.getCell(0, 0, VSTDataPath, "VSTCodes");
		if(type(ElsevierObjects.evolve_Reedemlnk_AccessCode, vstValid/*readcolumns.twoColumnsBasedOnSheetName(0, 1, "createNewaccount", configProps.getProperty("TestData")).get("NewAccessCode") */,"Enter Access code")){
			Reporters.SuccessReport("Enter the VST access code", "Successfully entered VST access code : "+vstValid+" into the access code blank text box");
		}else{
			Reporters.failureReport("Enter the VST access code", "Failed to enter VST access code : "+vstValid+" into the access code blank text box");
		}
		Thread.sleep(medium);
		if(click(ElsevierObjects.evolve_AccessCode_Submitbtn,"Click on Access code submit button")){
			Reporters.SuccessReport("Click on the submit button", "Successfully clicked on the submit button ");
		}else{
			Reporters.failureReport("Click on the submit button", "Failed to click on the submit button ");
		}
		Thread.sleep(medium);
		String errMsg=getText(ElsevierObjects.accessCode_errorMessage, "");
		if(waitForElementPresent(ElsevierObjects.accessCode_errorMessage, "Wait for error message.")){
			Reporters.SuccessReport("Verify the Error Message", "The Error Message is : "+errMsg+" printed successfully");
		}else{
			Reporters.failureReport("Verify the Error Message", "The Error Message is : "+errMsg+" failed to print");
		}
		return flag;
	}
}
