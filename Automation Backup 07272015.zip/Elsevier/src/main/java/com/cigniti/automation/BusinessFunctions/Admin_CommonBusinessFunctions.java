package com.cigniti.automation.BusinessFunctions;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.accelerators.Actiondriver;

public class Admin_CommonBusinessFunctions extends Actiondriver{

	//Click on the Promotion Link on the Admin page and verify for the bread crumb
		public static boolean addPromotionLink() throws Throwable{
			try{
				boolean flag=true;
				click(ElsevierObjects.Evolve_Admin_Prmlnk, "Click on Add Promotion Link");
				isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_BreadCrumbVrfy, "Verify for the presence of Bread Crumb: Evolve Admin > Add Promotion");
				return flag;			
			}catch(Exception e){sgErrMsg=e.getMessage();return false;}
		}
		
		//Validate all the fields are present or not
		public static boolean validatePromotionCodeValues() throws Throwable{
			try{
				boolean flag=true;
				
				isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_VrfyPromCode, "Validating for the element present");
				isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_DMCodeTxtBox, "Validating for the element present");
				isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_PrmotionCode, "Validating for the element present");
				isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_DscSel, "Validating for the element present");
				isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_CampaignCode, "Validating for the element present");
				isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_PrmName, "Validating for the element present");
				isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_TerritoryCode, "Validating for the element present");
				isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_StartDate, "Validating for the element present");
				isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_EndDate, "Validating for the element present");
				isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_Percentage, "Validating for the element present");
				isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_SaveBtn, "Validating for the element present");
				isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_CancelBtn, "Validating for the element present");
				isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_CloneBtn, "Validating for the element present");
				
				return flag;			
			}catch(Exception e){sgErrMsg=e.getMessage();return false;}
		}
								
		//Input all the values in the required fields.
		public static boolean inputValuesInPromotionCode(String DMcode, String PromotionCode, String DiscountType1, String DiscountType2, String CampaignCode, String PromotionName,String TerritoryCode, String PercentageOff) throws Throwable{
			
			try{
				boolean flag=true;
				type(ElsevierObjects.Evolve_Admin_Ecom_DMCodeTxtBox, DMcode, "Enter DM Code");
				selectByValue(ElsevierObjects.Evolve_Admin_Prmlnk_DscSel, DiscountType2, "Select Discount Type");
				type(ElsevierObjects.Evolve_Admin_Prmlnk_PrmName, PromotionName, "Enter Promotion Name");
				type(ElsevierObjects.Evolve_Admin_Prmlnk_TerritoryCode, TerritoryCode, "Enter territory Code");
				click(ElsevierObjects.Evolve_Admin_Prmlnk_ClkCalender, "Click on Calendar");
				click(ElsevierObjects.Evolve_Admin_Ecom_ClkDate, "Click on the current date");
				type(ElsevierObjects.Evolve_Admin_Prmlnk_Percentage, PercentageOff, "Enter the Percentage");
				click(ElsevierObjects.Evolve_Admin_Prmlnk_SaveBtn, "Click on Save Button");
				verifyText(ElsevierObjects.Evolve_Admin_Prmlnk_SucMsg, "Promotion successfully saved. ", "Success Message");
				
				return flag;			
			}catch(Exception e){sgErrMsg=e.getMessage();return false;}
		}
		
}
