package com.cigniti.automation.Test;

import java.util.Map;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarteFaculty1_15459;
import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarte_Student_SplitOrders1_15597;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.KNO_Pageburst_CC_NewStudent_15231;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentFaculty_15243;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class ECommercePreorderALaCarteFacultyScript1_15459 extends ECommercePreorderALaCarteFaculty1_15459{
@Test
public void eCommercePreorderALaCarteFaculty15459() throws Throwable{
	
	try{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		String user="educator";
		writeReport(EvolveCommonBussinessFunctions.CreateNewUser(user),"Creating New Educator User","Successfully Created Ner Educator User.</br>Username: "+credentials[0]+"</br> Password : "+credentials[1],
				"Failed To Create New Educator User.");

		String educatorUserName = EvolveCommonBussinessFunctions.credentials[0];
		String educatorPassword = EvolveCommonBussinessFunctions.credentials[1];
		ReadingExcel.updateCellInSheet(1, 5, testDataPath, "TC_15459", educatorUserName);
		ReadingExcel.updateCellInSheet(1, 6, testDataPath, "TC_15459", educatorPassword);
		
		
		writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Log out the Educator page.", 
				"Succesfully logged out Educator page.", 
				"Failed to logout the Educator page.");
	 
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials"+adminUser,
		        "Launching the URL for User is successful </br > Login to Application Using User credentails :"+adminUser+" is Successful",
		        "Launching and Login to Application Using User credentails : "+ adminUser+" is Failed");
		
		//ISBN TESTDATA
		String ecommerceISBN1=ReadingExcel.columnDataByHeaderName("ecommerceISBN1", "TC-15597", configProps.getProperty("TestData"));
		String ecommerceISBN2=ReadingExcel.columnDataByHeaderName("ecommerceISBN2", "TC-15597", configProps.getProperty("TestData"));
		String ecommerceISBN3=ReadingExcel.columnDataByHeaderName("ecommerceISBN3", "TC-15597", configProps.getProperty("TestData"));
		String publicationDate=ReadingExcel.columnDataByHeaderName("publicationDate", "TC-15597", configProps.getProperty("TestData"));
		String publicationStatus=ReadingExcel.columnDataByHeaderName("PublicationStatus", "TC-15597", configProps.getProperty("TestData"));
		String searchISBN4=ReadingExcel.columnDataByHeaderName("searchISBN4", "TC-15597", configProps.getProperty("TestData"));
		String searchISBN5=ReadingExcel.columnDataByHeaderName("searchISBN5", "TC-15597", configProps.getProperty("TestData"));
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.manageAdminstrator();
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.evolveBreadCrumb();
	
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.editingResource(ecommerceISBN1);
	
		String futuretype="Future";
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.modifyingPublicatonDate(futuretype,publicationDate,publicationStatus);
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.evolveBreadCrumb();
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.editingResource(ecommerceISBN2);
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.modifyingPublicatonDate(futuretype,publicationDate,publicationStatus);
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.evolveBreadCrumb();
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.editingResource(ecommerceISBN3);
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.modifyingPublicatonDate(futuretype,publicationDate,publicationStatus);
		
		launchUrl(configProps.getProperty("NoCacheURL"));
		Thread.sleep(medium);
		
		driver.navigate().back();
		
		adminLogout();
	
		User_BusinessFunction.Educatorlogin(educatorUserName,educatorPassword);
	
		String mssg="true";
		//String noMssg="false";
		String reserveButton=ReadingExcel.columnDataByHeaderName("reserveButton", "TC-15597", configProps.getProperty("TestData"));;
		String preOrderButton=ReadingExcel.columnDataByHeaderName("preOrder", "TC-15597", configProps.getProperty("TestData"));;
		String addToCartButton=ReadingExcel.columnDataByHeaderName("AddToCartButton", "TC-15597", configProps.getProperty("TestData"));;
	
		
		ECommercePreorderALaCarteFaculty1_15459.searchProduct(ecommerceISBN1,reserveButton,publicationDate,1);
		ECommercePreorderALaCarteFaculty1_15459.searchProduct(ecommerceISBN3,reserveButton,publicationDate,2);
		ECommercePreorderALaCarteFaculty1_15459.searchProduct(searchISBN4,addToCartButton,publicationDate,3);
		ECommercePreorderALaCarteFaculty1_15459.searchProduct(ecommerceISBN2,preOrderButton,publicationDate,4);
		ECommercePreorderALaCarteFaculty1_15459.searchProduct(searchISBN5,addToCartButton,publicationDate,5);
		
		ECommercePreorderALaCarteFaculty1_15459.Checkout(); 	
		
		//BILLING AND SHIPPING TESTDATA
		String studentStreet=ReadingExcel.columnDataByHeaderName("street", "TC-15597", configProps.getProperty("TestData"));
		String studentState=ReadingExcel.columnDataByHeaderName("state", "TC-15597", configProps.getProperty("TestData"));
		String studentCity=ReadingExcel.columnDataByHeaderName("city", "TC-15597", configProps.getProperty("TestData"));
		String studentZip=ReadingExcel.columnDataByHeaderName("pin", "TC-15597", configProps.getProperty("TestData"));
	
		//INSTITUTION DETAILS
		String FCountry=ReadingExcel.columnDataByHeaderName("country","TC_15459",configProps.getProperty("TestData"));
		String FState=ReadingExcel.columnDataByHeaderName("state","TC_15459", configProps.getProperty("TestData"));
		String Fcity=ReadingExcel.columnDataByHeaderName("city","TC_15459", configProps.getProperty("TestData"));
		String FInstitution=ReadingExcel.columnDataByHeaderName("institute","TC_15459", configProps.getProperty("TestData"));
		String Fstreet=ReadingExcel.columnDataByHeaderName("Street","TC_15459",configProps.getProperty("TestData"));
		String FZip=ReadingExcel.columnDataByHeaderName("Zip","TC_15459",configProps.getProperty("TestData"));
		String FMobile=ReadingExcel.columnDataByHeaderName("Mobile","TC_15459",configProps.getProperty("TestData"));
		String FProgram=ReadingExcel.columnDataByHeaderName("Program","TC_15459",configProps.getProperty("TestData"));
	
		
		ECommercePreorderALaCarteFaculty1_15459.InstitutionDetails(FCountry,FState,Fcity,FInstitution,Fstreet,FZip,FMobile,FProgram);
		
	    ECommercePreorderALaCarte_Student_SplitOrders1_15597.updateAccount(user,studentStreet, studentCity, studentState, studentZip);
		
	  //CREDIT CARD TESTDATA
		String creditCardType=ReadingExcel.columnDataByHeaderName("cardType", "TC-15597", configProps.getProperty("TestData"));
		String creditCardNum=ReadingExcel.columnDataByHeaderName("cardNumber", "TC-15597", configProps.getProperty("TestData"));
		String creditCardCvv=ReadingExcel.columnDataByHeaderName("cardCVV", "TC-15597", configProps.getProperty("TestData"));
		String creditCardName=ReadingExcel.columnDataByHeaderName("cardName", "TC-15597", configProps.getProperty("TestData"));
		String creditCardExpYr=ReadingExcel.columnDataByHeaderName("cardExpYear", "TC-15597", configProps.getProperty("TestData"));
		String creditCardExpMnth=ReadingExcel.columnDataByHeaderName("cardExpMonth", "TC-15597", configProps.getProperty("TestData"));
	
		writeReport(ECommercePreorderALaCarte_Student_SplitOrders1_15597.CreditCardData(creditCardType,creditCardNum,creditCardCvv,creditCardName,creditCardExpMnth,creditCardExpYr),"Entering Credit Card details.",
			"Successfully Entered Credit Card Type:"+creditCardType+", Name:"+creditCardName+", Number:"+creditCardNum+", CVV:"+creditCardCvv+", Expiry Month:"+creditCardExpMnth+",year:"+creditCardExpYr,
			"Failed to Enter Credit Card Details.");
	    
	    Thread.sleep(low);
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.verifyMessageInReviewPage(ecommerceISBN1,ecommerceISBN3,searchISBN4,ecommerceISBN2,searchISBN5,publicationDate);
	
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.acceptAndContinue("",user);
	
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.verifyMessageInReceiptPage(ecommerceISBN1,ecommerceISBN3,searchISBN4,ecommerceISBN2,searchISBN5,publicationDate);
	
		String subtotal=ReadingExcel.columnDataByHeaderName("subtotal", "TC_15459", testDataPath);
		String discountPrice=ReadingExcel.columnDataByHeaderName("discount", "TC_15459", testDataPath);	
		String tax=ReadingExcel.columnDataByHeaderName("tax", "TC_15459", testDataPath);
		String total=ReadingExcel.columnDataByHeaderName("total", "TC_15459", testDataPath);
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.verifyOrderPricesHeadings(subtotal,discountPrice,tax,total);
	
		String ISBN1=ecommerceISBN1+","+ecommerceISBN3+","+searchISBN4+","+ecommerceISBN2+","+searchISBN5;

		ECommercePreorderALaCarteFaculty1_15459.fetchOrderNumberInReceiptPage(ISBN1);
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.verifyOrderPagerDetails(ecommerceISBN1,ecommerceISBN3,searchISBN4,ecommerceISBN2,searchISBN5,publicationDate);
	
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.checkorderwithISBN(ordernumber2,ecommerceISBN1,"Yes");
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.checkorderwithISBN(ordernumber3,ecommerceISBN3,"Yes");
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.checkorderwithISBN(ordernumber1,ecommerceISBN2,"Yes");
		
		EvolveCommonBussinessFunctions.getAccountDetails();
		
		writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the Educator page.", 
				"Sucecssfully logged out the Educator page.", 
				"Failed to logout the Educator page.");
		//SwitchToBrowser("chrome");
		writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Login In Into Evolve Email Page.", 
																  "Successfully login into Evolve Email Page.", 
																  "Failed to login into Evolve Email Page.");
		String emailid=EvolveCommonBussinessFunctions.getAccountDetailsEmail;
		writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(emailid),"Search email in evolve webmail.",
													"Successfully entered the emailid "+emailid+" in search box.",
													"Failed to enter email id.");
		
		ordersVerificationInEmailBody(ordernumber1,ordernumber2,ordernumber3);
		
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials"+adminUser,
	            "Launching the URL for User is successfull </br > Login to Application Using User credentails :"+adminUser+" is Successful",
	            "Launching and Login to Application Using User credentails : "+ adminUser+" is Failed");
		
		String pastpublicationDate=ReadingExcel.columnDataByHeaderName("pastDtae", "TC-15597", configProps.getProperty("TestData"));
		String newpublicationStatus=ReadingExcel.columnDataByHeaderName("newPublicationStatus", "TC-15597", configProps.getProperty("TestData"));
		String pasttype="past";
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.editingResource(ecommerceISBN3);
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.modifyingPublicatonDate(pasttype,pastpublicationDate,newpublicationStatus);
	
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.evolveBreadCrumb();
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.editingResource(ecommerceISBN2);
	
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.modifyingPublicatonDate(pasttype,pastpublicationDate,newpublicationStatus);
	
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.evolveBreadCrumb();
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.editingResource(ecommerceISBN1);
		
		ECommercePreorderALaCarte_Student_SplitOrders1_15597.modifyingPublicatonDate(pasttype,pastpublicationDate,newpublicationStatus);
	
		launchUrl(configProps.getProperty("NoCacheURL"));
		Thread.sleep(medium);
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
	}


	}
public void tear() throws Throwable{
	//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
