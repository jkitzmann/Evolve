package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.AdminMaintainProductsUpdateHistory_15465;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class AdminMaintainProductsUpdateHistoryScript_15465 extends AdminMaintainProductsUpdateHistory_15465{
	@Test
	public void adminMaintainProductsUpdateHistory_15465() throws Throwable{
		try{
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			stepReport("Login to Evolve Admin.");
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login to Application Using Admin Credentials"+adminUser,
																			"Launching the URL for Admin is successful </br > Login to Application Using Admin credentials :"+adminUser+" is Successful", 
																			"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");
			stepReport("Search for a product in Maintain Products.");
			maintainProductLink();
			
			stepReport("Verify Product tab history.");
			verifyHistory();
			
			stepReport("Verify Student History.");
			studentUpadateHistory();
			
			stepReport("Verify Faculty History.");
			facultyUpadateHistory();
			writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout as "+adminUser,
					"Successfully logged out admin page.", 
				  	"Failed to logout admin page.");
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
	/*@AfterTest
	public void tear() throws Throwable{
		HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		Base.tearDown();
	}*/
}
