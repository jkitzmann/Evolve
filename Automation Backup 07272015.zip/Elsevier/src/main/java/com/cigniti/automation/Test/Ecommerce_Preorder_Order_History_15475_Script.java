package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.Ecommerce_Preorder_Order_History_15475_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class Ecommerce_Preorder_Order_History_15475_Script extends Ecommerce_Preorder_Order_History_15475_Bussiness_Functions{

	
	@Test
	public void EcommercePreorderOrderHistory15475() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		String pubDatePreOrder=ReadingExcel.columnDataByHeaderName("pubDatePreOrder", "TC-15471", testDataPath);
		String pubDatePreOrderStatus=ReadingExcel.columnDataByHeaderName("pubDateStatusPreOrder", "TC-15471", testDataPath);
		String isbn=ReadingExcel.columnDataByHeaderName("product", "TC-15471", testDataPath);
		//String pubDatePostOrderStatus=ReadingExcel.columnDataByHeaderName("pubDatePostStatus", "TC-15471", testDataPath);
		
		stepReport("Login to Evolve Admin");
		adminLogin();
		
		stepReport("Set publication date/status of product to future date");
		editResource(isbn);
		modifyPublicatonDate(pubDatePreOrder,pubDatePreOrderStatus);
		adminLogout();
		Thread.sleep(medium);
		if(launchUrl("https://evolvetest.elsevier.com/cs/noCache")){
			Reporters.SuccessReport("Run the URL https://evolvetest.elsevier.com/cs/noCache", "URL ran successfully : https://evolvetest.elsevier.com/cs/noCache");
		}else{
			Reporters.failureReport("Run the URL https://evolvetest.elsevier.com/cs/noCache", "URL failed to run : https://evolvetest.elsevier.com/cs/noCache");
		}
		Thread.sleep(medium);
		driver.navigate().back();
				
		
		/*writeReport(User_BusinessFunction.Studentlogin("nuser1272", "abc@123"),"Login to Application Using User Credentials :"+sStudentUser,
                "Launching the URL for User is successful </br > Login to Application Using User credentails :"+sStudentUser+" is Successful",
                   "Launching and Login to Application Using User credentails : "+ sStudentUser+" is Failed");
*/
		stepReport("Create new student user");
		writeReport(CreateNewUser(ElsevierObjects.STUDENT),"Create a New Student",
                "Launching the URL for User is successful </br > Successfully created a new user <br> Login to Application Using User credentails :"+credentials[0]+" is Successful",
                   "Launching and Login to Application Using User credentails : "+ credentials[0]+" is Failed");
		
		Thread.sleep(high);
		checkOrderDetails();
	
		
		
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
