package com.cigniti.automation.BusinessFunctions;


import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;


public class User_BusinessFunction extends EvolveCommonBussinessFunctions
{



	public static boolean Studentlogin(String Username,String Password) throws Throwable
	{
		boolean flag = true;
		try
		{

			driver.manage().deleteAllCookies();
			//driver.navigate().refresh();
			if(!launchUrl(configProps.getProperty("URL4"))){
				flag = false;
			}
			Thread.sleep(medium);
			/*clickOnMainPageLink();
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			if(!click(ElsevierObjects.home_student_lnkstudent,"Clicked On student Link")){
				flag = false;
			}*/
			Thread.sleep(medium);
			if(!click(ElsevierObjects.student_login,"Clicked On student LogIn")){
				flag = false;
			}
			if(!type(ElsevierObjects.email,Username,"Email")){
				flag = false;
			}
			if(!type(ElsevierObjects.password,Password,"Email")){
				flag = false;
			}
			if(!click(ElsevierObjects.submit,"Clicked on Login Button")){
				flag = false;
			}
			Thread.sleep(high);
			Thread.sleep(high);
			System.out.println("************************* Student login is Completed*************************");

		}catch(Exception e){return false;

		}
		return flag;
	}

	public static boolean Educatorlogin(String Username,String Password) throws Throwable
	{
		try
		{
			boolean flag = true;
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			driver.manage().deleteAllCookies();
			//driver.navigate().refresh();
			if(!launchUrl(configProps.getProperty("URL3"))){
				flag = false;
			}
			Thread.sleep(medium);
			/*clickOnMainPageLink();
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			if(!click(ElsevierObjects.Educator_login,"Clicked On Educator Link")){
				flag = false;
			}*/
			Thread.sleep(medium);
			if(!click(ElsevierObjects.student_login,"Clicked On student LogIn")){
				flag = false;
			}
			if(!type(ElsevierObjects.email,Username,"Email")){
				flag = false;
			}
			if(!type(ElsevierObjects.password,Password,"Email")){
				flag = false;
			}
			if(!click(ElsevierObjects.submit,"Clicked on Login Button")){
				flag = false;
			}
			return flag;
		}catch(Exception e){return false;}
	}

	public static boolean LaunchStudent() throws Throwable
	{
		try
		{
			boolean flag = true;
			driver.manage().deleteAllCookies();
			//driver.navigate().refresh();
			if(!launchUrl(configProps.getProperty("URL"))){
				flag = false;
			}
			Thread.sleep(medium);
			//clickOnMainPageLink();
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			if(!click(ElsevierObjects.home_student_lnkstudent,"Clicked On Student Link")){
				flag = false;
			}
			Thread.sleep(medium);
			System.out.println("************************* Launch Student Completed*************************");
			return flag;
		}catch(Exception e){
			sgErrMsg="Launch Student Failed ..."+e;
			return false;
		}
	}

	public static boolean LaunchEducator() throws Throwable
	{
		try
		{
			boolean flag = true;
			driver.manage().deleteAllCookies();
			//driver.navigate().refresh();
			if(!launchUrl(configProps.getProperty("URL"))){
				flag = false;
			}
			Thread.sleep(medium);
			//clickOnMainPageLink();
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			if(!click(ElsevierObjects.Educator_login,"Clicked On Educator Link")){
				flag = false;
			}
			Thread.sleep(medium);
			System.out.println("************************* Launch Educator Completed*************************");
			return flag;
		}catch(Exception e){
			sgErrMsg="Launch Educator Failed ..."+e;
			return false;
		}
	}

	public static boolean NavigateResultsfromsplcategory(String Input) throws Throwable{
		try
		{

			boolean flag=true;

			if(!click(ElsevierObjects.SaveonElsevierProducts,"Clicking Save on Elsevier Prodicts"))
			{flag=false;}
			Thread.sleep(low);
			if(!isVisible(ElsevierObjects.BrowserourProductsbydisciple, "Browse our product by discipline"))
			{
				return false;
			}
			if(!click(ElsevierObjects.BrowserourProductsbydisciple, "Browse our products by discipline"))
			{flag=false;}
			System.out.println("***************Navigate to Browser Result is Successful*******");
			Thread.sleep(low);
			if(!isVisible(By.xpath(".//*[@id='pageLayout-body-inner-most']//span[contains(text(),'"+Input+"')]"), "Browser our product By Disciple"))
			{
				return false;
			}
			driver.findElement(By.xpath(".//*[@id='pageLayout-body-inner-most']//span[contains(text(),'"+Input+"')]")).click();
			return flag;
		}catch(Exception e){sgErrMsg="Navigating to Discipline and Speciality is not successful"+e;return false;}
	}

	public static boolean Verifysplcategory() throws Throwable{
		try
		{

			boolean flag=true;

			if(!isVisible(ElsevierObjects.SearcResults, "Search Results"))
			{
				sgErrMsg="Page navigationg to Results is failed";
				return false;
			}

			sActualValues=driver.findElement(ElsevierObjects.totalresults).getText();
			if(verifyvaluegreaterthanzero(sActualValues))
			{
				return true;
			}
			return false;

		}catch(Exception e){sgErrMsg="Page navigationg to Results is failed"+e;return false;}
	}

	public static boolean VerifyNoResults() throws Throwable{
		try
		{

			boolean flag=true;
			int flag1=0;
			sActualValues=driver.findElement(ElsevierObjects.totalresults).getText();
			if(!verifyvaluegreaterthanzero(sActualValues))
			{
				flag1=0;   
			}
			if(!isVisible(By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[5]/div[2]/p[1]"),"The Total result not displayed"))
			{
				flag1=1;
			}
			if(flag1==1)
			{return false;}
			{
				return true;
			}
		}catch(Exception e){sgErrMsg="Page Displayed Results and Expected Result is not Results should be Displayed"+e;return false;}
	}

	public static boolean verifyvaluegreaterthanzero(String Input)throws Throwable
	{
		try
		{
			String Temp[]=Input.split(" ");
			int value=Integer.parseInt(Temp[0]);
			if(value>0)
			{	
				sActualValues="The Current Total Results are :"+value;	
				return true;
			}else {sActualValues="The Current Total Results are :"+value;return false;}
		}catch(Exception e){sgErrMsg="UnHandled Exception "+e;return false;}
	}
	public static boolean SignInAsDifferentUser(String Username,String Password) throws Throwable
	{
		try
		{
			boolean flag = true;
			//clickOnMainPageLink();
			if(!click(ElsevierObjects.student_login,"Clicked On student LogIn")){
				flag = false;
			}
			if(!type(ElsevierObjects.email,Username,"Email")){
				flag = false;
			}
			if(!type(ElsevierObjects.password,Password,"Email")){
				flag = false;
			}
			if(!click(ElsevierObjects.submit,"Clicked on Login Button")){
				flag = false;
			}
			Thread.sleep(veryhigh);
			return flag;
		}catch(Exception e){return false;}
	}

	public static boolean NavigateToCatalog() throws Throwable
	{
		try

		{
			boolean flag = true;
			waitForVisibilityOfElement(ElsevierObjects.lnkevolvecart, "Waiting for Evolve Catalog");
			if(isElementPresent(ElsevierObjects.lnkevolvecart))
			{

				if(!click(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
					flag = false;
				}
				/*else
				{
					if(!click(ElsevierObjects.NavigatetoCatalog,"Clicked on Evolve Catalog")){
						flag = false;
					}

				}*/
			}
			Thread.sleep(medium);

			System.out.println("************************* Navigating to Catalog Page is Completed*************************");
			return flag;
		}catch(Exception e){sgErrMsg=e.getMessage();return false;}

	}

	public static boolean NavigateToCatalogHome() throws Throwable
	{
		try

		{
			boolean flag = true;
			if(!click(ElsevierObjects.NavigatetoCatalog,"Clicked on Evolve Catalog")){
				flag = false;
			}
			System.out.println("************************* Navigating to Catalog Page is Completed*************************");
			return flag;
		}catch(Exception e){return false;}

	}

	public static boolean HESI_Search(String SearchValue) throws Throwable
	{
		try

		{
			boolean flag = true;
			if(!type(ElsevierObjects.Hesi_Search,SearchValue,"Entering the value to be searched"))
			{flag=false;}
			if(!click(ElsevierObjects.Hesi_Go, "Clicking on Go button"))
			{flag=false;}
			waitForVisibilityOfElement(ElsevierObjects.SortyByRelevance, "");
			String str = driver.findElement(ElsevierObjects.SortyByRelevance).getAttribute("checked");
			if (str.equalsIgnoreCase("true"))
			{
				System.out.println("Relevance Checkbox selected as Default Option");
			}
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}

	public static boolean SearchCatalog(String SearchValue) throws Throwable
	{
		try

		{
			boolean flag = true;
			if(!type(ElsevierObjects.Hesi_Search,SearchValue,"Entering the value to be searched"))
			{flag=false;}
			if(!click(ElsevierObjects.Hesi_Go, "Clicking on Go button"))
			{flag=false;}

			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}


	public static boolean HESI_Search(String SearchValue1,String SearchValue2) throws Throwable
	{
		try

		{
			boolean flag = true;
			driver.findElement(ElsevierObjects.Hesi_Search).clear();
			Thread.sleep(low);
			if(!type(ElsevierObjects.Hesi_Search,SearchValue1,"Entering the value to be searched"))
			{ flag=false;}

			driver.findElement(ElsevierObjects.Hesi_Search).sendKeys(" ");
			driver.findElement(ElsevierObjects.Hesi_Search).sendKeys(SearchValue2);
			if(!click(ElsevierObjects.Hesi_Go, "Clicking on Go button"))
			{ flag=false;}

			waitForVisibilityOfElement(ElsevierObjects.SortyByRelevance, "SortByRelevance");
			String str = driver.findElement(ElsevierObjects.SortyByRelevance).getAttribute("checked");
			if (str.equalsIgnoreCase("true"))
			{
				System.out.println("Relevance Checkbox selected as Default Option");
			}
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}

	public static boolean SearchinHoneyPots_Faculty(String Honeypot,String SearchValue1) throws Throwable
	{
		try

		{
			boolean flag = true;
			//driver.findElement(By.xpath(".//img[contains(@alt,'"+Honeypot+"')]")).click();

			Entertextinhoneypots_faculty(Honeypot,SearchValue1 );
			Thread.sleep(low);
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}

	public static boolean SearchinHoneyPots_Student(String Honeypot,String SearchValue1) throws Throwable
	{
		try

		{
			boolean flag = true;
			//driver.findElement(By.xpath(".//img[contains(@alt,'"+Honeypot+"')]")).click();

			Entertextinhoneypots_student(Honeypot,SearchValue1 );
			Thread.sleep(low);
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}

	public static boolean Entertextinhoneypots_faculty(String input,String value)throws Throwable
	{
		try
		{
			boolean falg= true;
			if(input.equalsIgnoreCase("Online Courses"))
			{
				type(ElsevierObjects.txtproductsearch,value,"Entering the value to be searched");
				driver.findElement(ElsevierObjects.txtproductsearch).sendKeys(Keys.ENTER);
			}
			if(input.equalsIgnoreCase("Textbook resources"))
			{
				type(ElsevierObjects.txtproductsearch,value,"Entering the value to be searched");
				driver.findElement(ElsevierObjects.txtproductsearch).sendKeys(Keys.ENTER);
			}
			if(input.equalsIgnoreCase("Simulations"))
			{
				type(ElsevierObjects.txtproductsearch,value,"Entering the value to be searched");
				driver.findElement(ElsevierObjects.txtproductsearch).sendKeys(Keys.ENTER);
			}     
			if(input.equalsIgnoreCase("Adaptive Solutions"))
			{
				type(ElsevierObjects.txtproductsearch,value,"Entering the value to be searched");
				driver.findElement(ElsevierObjects.txtproductsearch).sendKeys(Keys.ENTER);

			}        

			return true;
		}catch(Exception e){sgErrMsg="Unable to Enter"+input+" in text"+e;return false;}
	}

	public static boolean Entertextinhoneypots_student(String input,String value)throws Throwable
	{
		try
		{
			boolean falg= true;
			if(input.equalsIgnoreCase("Online Courses"))
			{
				type(ElsevierObjects.txtproductsearch,value,"Entering the value to be searched");
				driver.findElement(ElsevierObjects.txtproductsearch).sendKeys(Keys.ENTER);
			}

			if(input.equalsIgnoreCase("Textbook resources"))
			{
				type(ElsevierObjects.txtproductsearch,value,"Entering the value to be searched");
				driver.findElement(ElsevierObjects.txtproductsearch).sendKeys(Keys.ENTER);
			}
			if(input.equalsIgnoreCase("Simulations"))
			{
				type(ElsevierObjects.txtproductsearch,value,"Entering the value to be searched");
				driver.findElement(ElsevierObjects.txtproductsearch).sendKeys(Keys.ENTER);
			}     
			if(input.equalsIgnoreCase("Adaptive Solutions"))
			{
				type(ElsevierObjects.txtproductsearch,value,"Entering the value to be searched");
				driver.findElement(ElsevierObjects.txtproductsearch).sendKeys(Keys.ENTER);

			}     
			if(input.equalsIgnoreCase("Pageburst"))
			{
				type(ElsevierObjects.txtproductsearch,value,"Entering the value to be searched");
				driver.findElement(ElsevierObjects.txtproductsearch).sendKeys(Keys.ENTER);

			}     

			return true;
		}catch(Exception e){sgErrMsg="Unable to Enter"+input+" in text"+e;return false;}
	}

	public  static boolean clickonMorelink() throws Throwable {
		try{
			By MoreProducttypeLink=By.xpath(".//*[@id='moreFormatsLink']");
			if(isVisible(MoreProducttypeLink, "More Format link"))
			{
				click(MoreProducttypeLink,  "More Format link");
				return true;
			}
			Thread.sleep(low);

			return true;
		}catch(Exception e){sgErrMsg="Show More link is not avilable"+e; return false;
		}
	}


	public static boolean ClickonFilterByProudctType(String SearchValue) throws Throwable
	{
		try

		{
			boolean flag = true;

			By MoreProducttypeLink=By.xpath(".//*[@id='moreProductsLink']");
			if(isVisible(MoreProducttypeLink, "More Product link"))
			{
				click(MoreProducttypeLink,  "More Product link");
			}
			Thread.sleep(low);

			List<WebElement> AllTitlesfromapplication = driver.findElements(By.xpath(".//*[@id='div-productTypes']//label"));
			int totalResults=AllTitlesfromapplication.size();
			System.out.println(totalResults);
			for(int i=0;i<totalResults;i++)
			{
				WebElement Appdatavalues=AllTitlesfromapplication.get(i);
				String values=Appdatavalues.getText();
				if(values.equals(SearchValue))
				{
					Thread.sleep(low);
					try{
						boolean result = false;
						int attempts = 0;
						while(attempts < 4) {
							try {
								//Appdatavalues.click();
								JavascriptExecutor executor = (JavascriptExecutor) driver;
								executor.executeScript("arguments[0].click();", Appdatavalues);
								result = true;
								break;
							} catch(StaleElementReferenceException  e) {
							}
							attempts++;
						}
						return result; 

					}catch(StaleElementReferenceException e){Appdatavalues.click();}

				}		System.out.println("The Text values are :"+values);
			}sgErrMsg=SearchValue+"Product Type is not Avilable in the list";return false;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}
	}

	public static boolean ClickonFilterByFormatType(String SearchValue,String Check) throws Throwable
	{
		try

		{
			boolean flag = true;
			//if(Check.equalsIgnoreCase("Check"))

			/***By MoreformatLink=By.xpath(".//*[@id='moreFormatsLink']]");
            if(isVisible(MoreformatLink, "More Format link"))
            {
			click(MoreformatLink,  "More Format link");
            }
			 ******/
			Thread.sleep(low);
			List<WebElement> AllTitlesfromapplication = driver.findElements(By.xpath(".//*[@id='div-formatTypes']//label"));
			int totalResults=AllTitlesfromapplication.size();
			System.out.println(totalResults);
			for(int i=0;i<totalResults;i++)
			{
				WebElement Appdatavalues=AllTitlesfromapplication.get(i);
				String values=Appdatavalues.getText();
				System.out.println("The Actual Values form Application:"+values);
				if(values.equalsIgnoreCase(SearchValue))
				{
					Thread.sleep(low);
					try{
						boolean result = false;
						int attempts = 0;
						while(attempts < 4) {
							try {
								//Appdatavalues.click();
								JavascriptExecutor executor = (JavascriptExecutor) driver;
								executor.executeScript("arguments[0].click();", Appdatavalues);
								result = true;
								break;
							} catch(StaleElementReferenceException  e) {
							}
							attempts++;
						}
						return result; 

					}catch(StaleElementReferenceException e){Appdatavalues.click();}

				}		System.out.println("The Text values are :"+values);
			}sgErrMsg=SearchValue+"Product Type is not Avilable in the list";return false;
		}catch(Exception e){
			click(ElsevierObjects.catalog, "Navigating to Catalog page");
			User_BusinessFunction.HESI_Search(exlu_formatby);
			sgErrMsg=e+" is Failed due to this exception";return false;}
	}

	public static boolean SelectSortingType(By by) throws Throwable
	{
		try

		{
			boolean flag = true;

			if(!click(by, "Clicking on  Radio button"))
			{ flag=false;}
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}

	public static boolean VerifySortorderfor_Page_Price(By locator) throws Throwable
	{
		try

		{
			boolean flag = true;

			List<WebElement> AllTitlesfromapplication = driver.findElements(locator);
			int totalResults=AllTitlesfromapplication.size();

			String[] AllTitlesfromApplications=new String[totalResults];

			//String[] Temp=new String[totalResults];

			for(int i=0;i<totalResults;i++)
			{
				Thread.sleep(300);
				WebElement Appdatavalues=AllTitlesfromapplication.get(i);
				String values=Appdatavalues.getText();
				//System.out.println(values);
				AllTitlesfromApplications[i]=values;

			}

			String[] ActualStringfromApplication=new String[totalResults];
			ActualStringfromApplication=Arrays.copyOf(AllTitlesfromApplications, AllTitlesfromApplications.length);

			String ActualStringfromApplication1=Arrays.toString(AllTitlesfromApplications);
			System.out.println(Arrays.toString(AllTitlesfromApplications));

			Thread.sleep(300);
			String[] ExpectedSortingString=AllTitlesfromApplications;
			Arrays.sort(ExpectedSortingString);
			String ExpectedSortingString2=Arrays.toString(ExpectedSortingString);

			System.out.println(Arrays.toString(ExpectedSortingString));
			int flagvalue=0;

			//for (int i = 0; i < ActualStringfromApplication.length; i++) 
			{

				for (int a = 0; a < ExpectedSortingString.length; a++) 
				{

					if (ActualStringfromApplication[a] == ExpectedSortingString[a])      
						//if(ActualStringfromApplication1.equals(ExpectedSortingString2))
					{
						System.out.println("Actual Sorting is:"+ActualStringfromApplication[a]);
						sActualValues=Arrays.toString(ActualStringfromApplication);
						System.out.println("Expected Sorting is:"+ActualStringfromApplication[a]);
						sExpectedValues=Arrays.toString(ExpectedSortingString);
						System.out.println("The Values are Matching");
						//return true;
						flagvalue=0;
					}
					else

					{	

						flagvalue=1;
						//break;
						//return false;

					}

				}

			}



			if(flagvalue==0)
			{
				return true;  
			}
			else if(flagvalue==1)
			{
				System.out.println("Actual Sorting is:"+Arrays.toString(ActualStringfromApplication));
				sActualValues=ActualStringfromApplication1;
				System.out.println("Expected Sorting is:"+Arrays.toString(ExpectedSortingString));
				sExpectedValues=ExpectedSortingString2;
				System.out.println("The Values are not Matching");

				return false;
			}


		}catch(Exception e){return false;}
		return false;

	}
	@SuppressWarnings("unchecked")
	public static boolean VerifySortorderfor_Page(By locator) throws Throwable
	{
		try

		{
			boolean flag = true;

			List<WebElement> AllTitlesfromapplication = driver.findElements(locator);
			int totalResults=AllTitlesfromapplication.size();

			String[] AllTitlesfromApplications=new String[totalResults];
			String[] AllTitlesfromApplications1=new String[totalResults];

			//String[] Temp=new String[totalResults];

			for(int i=0;i<totalResults;i++)
			{
				Thread.sleep(300);
				WebElement Appdatavalues=AllTitlesfromapplication.get(i);
				String values=Appdatavalues.getText();
				AllTitlesfromApplications1[i]=values;
				//System.out.println(values);
				String[] Temp=values.split(",");
				int lengthofTemp=Temp.length;
				String testdata=Temp[0];
				AllTitlesfromApplications[i]=testdata;
				//AllTitlesfromApplications[i]=values;

			}

			String[] ActualStringfromApplication=new String[totalResults];
			ActualStringfromApplication=Arrays.copyOf(AllTitlesfromApplications, AllTitlesfromApplications.length);

			//For References
			String ActualStringfromApplication1=Arrays.toString(ActualStringfromApplication);    



			List list = Arrays.asList(AllTitlesfromApplications);
			list = new LinkedList(Arrays.asList(AllTitlesfromApplications));
			Set set = new HashSet(Arrays.asList(AllTitlesfromApplications));
			Collections.sort(list, String.CASE_INSENSITIVE_ORDER);
			String[] ExpectedSortingString=(String[]) list.toArray(new String[0]);
			System.out.println("TheSorted list is:"+list);
			String ExpectedSortingString2=Arrays.toString(ExpectedSortingString);

			System.out.println("AfterConverting to Stringfor Comparsion:"+ExpectedSortingString2);
			//System.out.println(Arrays.toString(AllTitlesfromApplications));
			Thread.sleep(300);

			/*String[] ExpectedSortingString=AllTitlesfromApplications;
			Arrays.sort(ExpectedSortingString);
			String ExpectedSortingString2=Arrays.toString(ExpectedSortingString);
			 */
			//System.out.println(Arrays.toString(ExpectedSortingString));
			int flagvalue=0;


			//for (int i = 0; i < ActualStringfromApplication.length; i++) 
			{

				//for (int a = 0; a < ExpectedSortingString.length; a++) 
				{

					//if (ActualStringfromApplication[a] == ExpectedSortingString[a])      
					if(ActualStringfromApplication1.equals(ExpectedSortingString2))
					{
						System.out.println("Actual Sorting is:"+ActualStringfromApplication1);
						sActualValues=ActualStringfromApplication1;
						System.out.println("Expected Sorting is:"+ExpectedSortingString2);
						sExpectedValues=ExpectedSortingString2;
						System.out.println("The Values are Matching");
						//return true;
						flagvalue=0;
					}
					else

					{	

						flagvalue=1;
						//break;
						//return false;

					}

				}

			}



			if(flagvalue==0)
			{
				return true;  
			}
			else if(flagvalue==1)
			{
				System.out.println("Actual Sorting is:"+ActualStringfromApplication1);
				sActualValues=ActualStringfromApplication1;
				System.out.println("Expected Sorting is:"+(ExpectedSortingString2));
				sExpectedValues=ExpectedSortingString2;
				System.out.println("The Values are not Matching");

				return false;
			}


		}catch(Exception e){return false;}
		return false;

	}

	public static boolean VerifySortorderfor_ExculisveforCopyrightYear(By locator) throws Throwable
	{
		try

		{
			boolean flag = true;

			List<WebElement> AllTitlesfromapplication = driver.findElements(locator);
			int totalResults=AllTitlesfromapplication.size();

			String[] AllTitlesfromApplications=new String[totalResults];

			//String[] Temp=new String[totalResults];

			for(int i=0;i<totalResults;i++)
			{
				WebElement Appdatavalues=AllTitlesfromapplication.get(i);
				String values=Appdatavalues.getText(); 

				String[] Temp=values.split(" ");
				int lengthofTemp=Temp.length;

				String testdata=Temp[0];
				AllTitlesfromApplications[i]=testdata;				
			}

			String[] ActualStringfromApplication=new String[totalResults];
			ActualStringfromApplication=Arrays.copyOf(AllTitlesfromApplications,AllTitlesfromApplications.length);


			String ActualStringfromApplication1=Arrays.toString(AllTitlesfromApplications);
			System.out.println(Arrays.toString(AllTitlesfromApplications));
			int length=AllTitlesfromApplications.length;
			Arrays.sort(AllTitlesfromApplications, Collections.reverseOrder());
			String ActualStringfromApplication2=Arrays.toString(AllTitlesfromApplications);
			String[] ExpectedSortingString=AllTitlesfromApplications;
			System.out.println(Arrays.toString(ExpectedSortingString));

			if(ActualStringfromApplication1.equals(ActualStringfromApplication2))
			{
				System.out.println("Actual Sorting is:"+ActualStringfromApplication1);
				sActualValues=Arrays.toString(ActualStringfromApplication);
				System.out.println("Expected Sorting is:"+ActualStringfromApplication2);
				sExpectedValues=Arrays.toString(ExpectedSortingString);
				System.out.println("The Values are Matching");
				return flag;
			}
			else
			{

				System.out.println("Actual Sorting is:"+ActualStringfromApplication1);
				sActualValues=Arrays.toString(ActualStringfromApplication);
				System.out.println("Expected Sorting is:"+ActualStringfromApplication2);
				sExpectedValues=Arrays.toString(ExpectedSortingString);
				System.out.println("The Values are not Matching");

				return false;}
		}catch(Exception e){return false;}

	}

	public static boolean VerifySortorderfor_PageExlcusiveforlastname(By locator) throws Throwable
	{
		try

		{
			boolean flag = true;

			List<WebElement> AllTitlesfromapplication = driver.findElements(locator);
			int totalResults=AllTitlesfromapplication.size();

			String[] AllTitlesfromApplications=new String[totalResults];

			//String[] Temp=new String[totalResults];

			for(int i=0;i<totalResults;i++)
			{
				WebElement Appdatavalues=AllTitlesfromapplication.get(i);
				String values=Appdatavalues.getText();

				String[] Temp=values.split(",");
				int lengthofTemp=Temp.length;

				String testdata=Temp[0];
				if(testdata.contains("and"))
				{

					String[] Temp1=Temp[0].split("and");
					Temp1=Temp1[0].split(" ");
					int SizeofTemp=Temp1.length;
					String FinalValue=(Temp1[SizeofTemp-1]);
					// To capitalize the first word only
					//WordUtils.capitalize(FinalValue); 
					System.out.println(FinalValue);
					AllTitlesfromApplications[i]=FinalValue;

				}
				else
				{
					String[] Temp1=Temp[0].split(" ");
					int SizeofTemp=Temp1.length;
					String FinalValue=(Temp1[SizeofTemp-1]);
					// To capitalize the first word only
					//WordUtils.capitalize(FinalValue); 
					System.out.println(FinalValue);
					AllTitlesfromApplications[i]=FinalValue;
				}
			}

			String[] ActualStringfromApplication=new String[totalResults];
			ActualStringfromApplication=Arrays.copyOf(AllTitlesfromApplications, AllTitlesfromApplications.length);
			System.out.println("The Actual Sorted list from AUT is:"+Arrays.toString(ActualStringfromApplication));
			//For References
			String ActualStringfromApplication1=Arrays.toString(ActualStringfromApplication);    



			List list = Arrays.asList(AllTitlesfromApplications);
			list = new LinkedList(Arrays.asList(AllTitlesfromApplications));
			Set set = new HashSet(Arrays.asList(AllTitlesfromApplications));
			Collections.sort(list, String.CASE_INSENSITIVE_ORDER);
			String[] ExpectedSortingString=(String[]) list.toArray(new String[0]);
			System.out.println("The Expected Sorted list is:"+list);
			String ExpectedSortingString2=Arrays.toString(ExpectedSortingString);

			//System.out.println("AfterConverting to Stringfor Comparsion:"+ExpectedSortingString2);
			//System.out.println(Arrays.toString(AllTitlesfromApplications));
			Thread.sleep(300);

			/*String[] ExpectedSortingString=AllTitlesfromApplications;
			Arrays.sort(ExpectedSortingString);
			String ExpectedSortingString2=Arrays.toString(ExpectedSortingString);
			 */
			//System.out.println(Arrays.toString(ExpectedSortingString));
			int flagvalue=0;


			//for (int i = 0; i < ActualStringfromApplication.length; i++) 
			{

				//for (int a = 0; a < ExpectedSortingString.length; a++) 
				{

					//if (ActualStringfromApplication[a] == ExpectedSortingString[a])      
					if(ActualStringfromApplication1.equals(ExpectedSortingString2))
					{
						System.out.println("Actual Sorting is:"+ActualStringfromApplication1);
						sActualValues=ActualStringfromApplication1;
						System.out.println("Expected Sorting is:"+ExpectedSortingString2);
						sExpectedValues=ExpectedSortingString2;
						System.out.println("The Values are Matching");
						//return true;
						flagvalue=0;
					}
					else

					{	

						flagvalue=1;
						//break;
						//return false;

					}

				}

			}



			if(flagvalue==0)
			{
				return true;  
			}
			else if(flagvalue==1)
			{
				System.out.println("Actual Sorting is:"+ActualStringfromApplication1);
				sActualValues=ActualStringfromApplication1;
				System.out.println("Expected Sorting is:"+(ExpectedSortingString2));
				sExpectedValues=ExpectedSortingString2;
				System.out.println("The Values are not Matching");

				return false;
			}


		}

		catch(Exception e){return false;}
		return false;

	}

	public static boolean ClickingOnNext_Button() throws Throwable
	{
		try

		{
			boolean flag = true;

			if(!click(ElsevierObjects.ClickonNextbutton, "Clicking on Next button in the Results page"))
			{flag=false;}
			System.out.println("************************* Clicking On Next button *************************");
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}
	public static boolean ClickingOnThridPage_Button() throws Throwable
	{
		try

		{
			boolean flag = true;

			if(!click(ElsevierObjects.ClickonthirdPage, "Clicking on Third Page button"))
			{flag=false;}
			System.out.println("************************* Clicking On Third Page button *************************");
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}
	public static boolean  Logout() throws Throwable

	{
		try

		{
			boolean flag = true;
			
			if(!click(ElsevierObjects.myAccount,"click on my account")){
				flag = false;
			}

			if(!click(ElsevierObjects.lnkLogout, "Clicking on logout button")){
				flag = false;
			}
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}


	public static boolean  Admin() throws Throwable

	{
		try

		{
			boolean flag = true;

			List<WebElement> AllTitlesfromapplication = driver.findElements(By.xpath(".//*[@id='faculty-production']//span[@class='middle']//input"));
			int totalResults=AllTitlesfromapplication.size();
			System.out.println(totalResults);
			for(int i=0;i<totalResults;i++)
			{
				WebElement Appdatavalues=AllTitlesfromapplication.get(i);
				String values=Appdatavalues.getAttribute("value");
				System.out.println("The Text values are :"+values);
			}

			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}


	public static boolean VerifyValueinResults(By locator,By locator1,By locator2,String Testinput) throws Throwable
	{
		try

		{
			boolean flag = true;
			Thread.sleep(medium);	
			List<WebElement> AllTitlesfromapplication = driver.findElements(locator);
			List<WebElement> Listlocator1 = driver.findElements(locator);


			List<WebElement> Listlocator2 = driver.findElements(locator1);

			List<WebElement> Listlocator3 = driver.findElements(locator2);
			int totalResults=Listlocator2.size();
			String[] AllTitlesfromApplications=new String[totalResults];
			String values="";
			String values1="";
			String values2;
			String values3;
			String Pattern1;
			//String[] Temp=new String[totalResults];
			int flag1=0;
			int flag2=0;
			int count=0;
			Reporters.SuccessReport("The Total Results are:"+totalResults, "The Total Results for: "+Testinput+" Search Criteria are : "+totalResults);
			for(int i=0;i<totalResults;i++)
			{
				WebElement Appdatavalues=AllTitlesfromapplication.get(i);
				WebElement webelements1=Listlocator1.get(i);
				WebElement webelements2=Listlocator2.get(i);
				WebElement webelements3=Listlocator3.get(i);
				values=Appdatavalues.getText();
				values1=webelements1.getText();
				values2=webelements2.getText();
				values3=webelements3.getText();
				Pattern1=values1+values2+values3;
				if(Pattern1.contains(Testinput))
				{
					count=count+1;	
					System.out.println("Actual String Expected is:"+Testinput);
					sActualValues=Testinput ;
					System.out.println("Expected String in API is:"+values1+values2+values3);
					//sExpectedValues=values1+values2+values3;
					System.out.println("The Values are Matching");
					flag1=0;
					Reporters.SuccessReport("The Current Results is: "+count, "The Expected Input: "+Testinput+" is Present in the Current Actual Results of </br>Author:"+values1+"  OR </br>Title:"+values2+"  OR  </br> Product Type:"+values3);
					//return true;

				}
				else

				{	
					count=count+1;
					System.out.println("Actual String Expected is:"+Testinput);
					sActualValues=Testinput ;
					System.out.println("Expected String in API is:"+values1+values2+values3);
					//sExpectedValues=values1+values2+values3;
					Reporters.failureReport("The Current Results is: "+count, "The Expected Input: "+Testinput+" is not Present in the Current Actual Results of </br>Author:"+values1+"  OR </br>Title:"+values2+"  OR  </br> Product Type:"+values3);
					System.out.println("The Values are not Matching");
					flag2=1;

				}

			}
			if(flag2==1)
			{return false;}
			else if(flag1==0)
			{
				System.out.println("The Values are Matching");
				return true;

			}

		}

		catch(Exception e){sgErrMsg="Unable to Capture the values"+e;return false;}
		return false;


	}

	public static boolean VerifyValueinResults(By locator,By locator1,By locator2,String Testinput,String Testinput1) throws Throwable
	{
		try

		{
			boolean flag = true;

			List<WebElement> AllTitlesfromapplication = driver.findElements(locator);
			List<WebElement> Listlocator1 = driver.findElements(locator);
			int totalResults=Listlocator1.size();

			List<WebElement> Listlocator2 = driver.findElements(locator1);
			List<WebElement> Listlocator3 = driver.findElements(locator2);

			String[] AllTitlesfromApplications=new String[totalResults];
			String values="";
			String values1="";
			String values2;
			String values3;
			String Pattern1;
			//String[] Temp=new String[totalResults];
			int flag1=0;
			int flag2=0;
			int count=0;
			Reporters.SuccessReport("The Total Results are:"+totalResults, "The Total Results for: "+Testinput+" Search Criteria are : "+totalResults);
			for(int i=0;i<totalResults;i++)
			{
				WebElement Appdatavalues=AllTitlesfromapplication.get(i);
				WebElement webelements1=Listlocator1.get(i);
				WebElement webelements2=Listlocator2.get(i);
				WebElement webelements3=Listlocator3.get(i);
				values=Appdatavalues.getText();
				values1=webelements1.getText();
				values2=webelements2.getText();
				values3=webelements3.getText();
				Pattern1=values1+values2+values3;
				if((Pattern1.contains(Testinput))||(Pattern1.contains(Testinput1)))
				{
					count=i+1;	
					System.out.println("Actual String Expected is:"+Testinput+" and "+Testinput1 );
					sActualValues=Testinput ;
					System.out.println("Expected String in API is:"+values1+values2+values3);
					//sExpectedValues=values1+values2+values3;
					System.out.println("The Values are Matching");
					flag1=0;
					Reporters.SuccessReport("The Current Results is: "+count, "The Expected Input: "+Testinput+" OR "+Testinput1 +" is Present in the Current Actual Results of </br>Author:"+values1+"  OR </br>Title:"+values2+"  OR  </br> Product Type:"+values3);
					//return true;

				}
				else

				{	

					System.out.println("Actual String Expected is:"+Testinput+" and "+Testinput1 );
					sActualValues=Testinput ;
					System.out.println("Expected String in API is:"+values1+values2+values3);
					//sExpectedValues=values1+values2+values3;
					Reporters.SuccessReport("The Current Results is: "+count, "The Expected Input: "+Testinput+" OR "+Testinput1+" is not Present in the Current Actual Results of </br>Author:"+values1+"  OR </br>Title:"+values2+"  OR  </br> Product Type:"+values3);
					System.out.println("The Values are not Matching");
					flag2=1;

				}

			}
			if(flag2==1)
			{return false;}
			else if(flag1==0)
			{
				System.out.println("The Values are Matching");
				return true;

			}

		}

		catch(Exception e){return false;}
		return false;


	}


	public static boolean VerifyValueinResults(By locator,String Testinput) throws Throwable
	{
		try

		{
			boolean flag = true;

			List<WebElement> AllTitlesfromapplication = driver.findElements(locator);
			List<WebElement> Listlocator1 = driver.findElements(locator);
			int totalResults=Listlocator1.size();


			String[] AllTitlesfromApplications=new String[totalResults];
			String values="";
			String values1="";

			String Pattern1;
			//String[] Temp=new String[totalResults];
			int flag1=0;
			for(int i=0;i<totalResults;i++)
			{
				WebElement Appdatavalues=AllTitlesfromapplication.get(i);
				WebElement webelements1=Listlocator1.get(i);
				values=Appdatavalues.getText();
				values1=webelements1.getText();
				Pattern1=values1;
				
				// changed from Pattern1.contains(Testinput) to Testinput.contains(Pattern1) ...
				// previous way caused false positives
				if(Testinput.contains(Pattern1))
				{

					System.out.println("Actual String Expected is:"+Testinput);
					sActualValues=Testinput ;
					System.out.println("Expected String in API is:"+values1);
					sExpectedValues=values1;
					System.out.println("The Values are Matching");
					flag1=0;
					return true;

				}
				else

				{	
					flag1=1;

				}

			}
			if(flag1==1)
			{System.out.println("Actual String Expected is:"+Testinput);
			sActualValues=Testinput ;
			System.out.println("The Expected String is not avilable in the Results");

			System.out.println("The Values are not Matching");
			return false;}
		}catch(Exception e){sgErrMsg="The current values are mismatching due to:"+e;return false;}
		return false;


	}

	public static boolean VerifyValueinResultsandClickingonItem(By locator,String Testinput) throws Throwable
	{
		try

		{

			boolean flag = true;

			List<WebElement> AllTitlesfromapplication = driver.findElements(locator);
			List<WebElement> Listlocator1 = driver.findElements(locator);
			int totalResults=Listlocator1.size();


			String[] AllTitlesfromApplications=new String[totalResults];
			String values="";
			String values1="";

			String Pattern1;
			//String[] Temp=new String[totalResults];
			int flag1=0;
			for(int i=0;i<totalResults;i++)
			{
				//WebElement Appdatavalues=AllTitlesfromapplication.get(i);
				WebElement webelements1=Listlocator1.get(i);
				//	 values=Appdatavalues.getText();
				values1=webelements1.getText();
				Pattern1=values1;
				if(Pattern1.trim().equalsIgnoreCase(Testinput.trim()))
				{
					Thread.sleep(low);
					//webelements1.click();
					driver.findElement(By.linkText(values1)).click();
					//webelements1.sendKeys(Keys.ENTER);
					//List<WebElement> Temp = driver.findElements(locator);
					//WebElement Temp1=Listlocator1.get(i);

					//	driver.findElement(By.xpath(".//a[text="+Testinput+")]")).click();	
					/*	Action moveto=New Action();
					moveTo.moveToElement(element).click().build().perform();
					 */

					/*JavascriptExecutor executor = (JavascriptExecutor)driver;
					executor.executeScript("arguments[0].click();", Temp1);
					System.out.println("Actual String Expected is:"+Testinput);*/
					sActualValues=Testinput ;
					System.out.println("Expected String in API is:"+values1);
					sExpectedValues=values1;
					System.out.println("The Values are Matching");
					flag1=0;

					//JavaExecutor(webelements1);
					return true;

				}
				else

				{	
					flag1=1;

				}

			}
			if(flag1==1)
			{System.out.println("Actual String Expected is:"+Testinput);
			sActualValues="The Element is not present in the Results"+Testinput ;
			System.out.println("The Excepted String is not avilable in the Results");
			sgErrMsg="The current Element is not Available in the Results";
			System.out.println("The Values are not Matching");
			return false;}
		}catch(Exception e){sgErrMsg="The current values are mismatching due to:"+e;return false;}
		return false;


	}

	public static boolean VerifyISBNandTitle(String ISBN,String BookTitle) throws Throwable
	{
		try

		{
			int flag=0;
			if(!isVisible(By.xpath("//*[@id='pageLayout-body-inner-most']//span[contains(text(),'"+ISBN+"')]"),"ISBN is not Present"))
			{
				sgErrMsg="The Expected ISBN is not Matching with Current ISBN";
				return false;
			}
			else
			{flag=1;}

			// if(!isVisible(By.xpath(".//*[@id='tab-relayout']//h1[contains(text(),'"+BookTitle+"')]"),"Book Title is not Present"))
			String BookTitleAPI=driver.findElement(ElsevierObjects.Booktitle).getText(); 
			if(BookTitleAPI.equals(BookTitle))
			{
				sActualValues="The ISBN is:"+ISBN+" and Book Title is:"+BookTitleAPI;
				sgErrMsg="The Expected ISBN is not Matching with Current ISBN";
				flag=1;
			} 
			else
			{ sgErrMsg="The Expected Title is not Matching with Current Title";
			return false;}

			if(flag==1)
			{
				sActualValues ="The ISBN is:"+ISBN+" and Book Title is:"+BookTitle;
				return true;
			}
		}catch(Exception e){sgErrMsg="The verification is failed:"+e;return false;}
		sgErrMsg="The verification is failed";
		return false;

	}

	public static boolean VerifyISBN(String ISBN) throws Throwable
	{
		try

		{
			int flag=0;
			if(!isVisible(By.xpath("//*[@id='pageLayout-body-inner-most']//span[contains(text(),'"+ISBN+"')]"),"ISBN is not Present"))
			{
				sgErrMsg="The Expected ISBN is not Matching with Current ISBN";
				return false;
			}
			else
			{flag=1;}

			// if(!isVisible(By.xpath(".//*[@id='tab-relayout']//h1[contains(text(),'"+BookTitle+"')]"),"Book Title is not Present"))

			if(flag==1)
			{
				sActualValues ="The ISBN is:"+ISBN ;
				return true;
			}
		}catch(Exception e){sgErrMsg="The verification is failed:"+e;return false;}
		sgErrMsg="The verification is failed";
		return false;

	}

	public static boolean VerifyValueinResultsinallpages(By locator,String Testinput) throws Throwable
	{
		try

		{
			boolean flag = true;

			int flag1=0;
			int flag2=0;
			//List<WebElement> allpages=driver.findElements(By.xpath(".//*[@id='pageLayout-body-inner-most']//span[contains(@class,'p-nums')]//a[contains(@class,'productPageButton')]"));
			List<WebElement> allpages=driver.findElements(By.xpath("(.//div[@class='span17 align_center'])[2]/span[@class='p-nums']/a"));
			
			int allpagecount=allpages.size();
			WebElement finalelementvalue=allpages.get(allpagecount-1);

			String finalpagevalue=finalelementvalue.getText().toString();
			System.out.println("The final value"+finalpagevalue);
			int finalpage=Integer.parseInt(finalpagevalue);
			String values="";
			String values1="";	
			if(allpagecount==0)
			{

			}else if (allpagecount>1)
			{
				for(int a=1;a<finalpage;a++)

				{

					List<WebElement> AllTitlesfromapplication = driver.findElements(locator);
					List<WebElement> Listlocator1 = driver.findElements(locator);
					int totalResults=Listlocator1.size();


					System.out.println("Currentpages"+finalpage);
					String[] AllTitlesfromApplications=new String[totalResults];


					String Pattern1;
					//String[] Temp=new String[totalResults];

					for(int i=0;i<totalResults;i++)
					{
						WebElement Appdatavalues=AllTitlesfromapplication.get(i);
						WebElement webelements1=Listlocator1.get(i);
						values=Appdatavalues.getText();
						values1=webelements1.getText();

						Pattern1=values1;
						if(Pattern1.contains(Testinput))
						{

							flag1=0;

						}
						else
						{	
							flag2=1;
							break;
						}

					}
					if(a==0)
					{

					}
					else
					{			                    
						click(ElsevierObjects.ClickonNextbutton, "Clicking on Next button in the Results page");
						System.out.println("************************* Clicking On Next button *************************");
						System.out.println("clickingon"+a);
					}                

				}
			}
			if(flag2==1)
			{System.out.println("Actual String Expected is:"+values1);
			sActualValues=values1 ;

			System.out.println("Expected String is:"+Testinput);
			sExpectedValues =Testinput;
			System.out.println("The Excepted String is not avilable in the Results");

			System.out.println("The Values are not Matching");
			return false;
			}
			else
			{
				System.out.println("Actual String Expected is:"+values1);
				sActualValues=values1 ;
				System.out.println("Expected String in API is:"+Testinput);
				sExpectedValues=Testinput;
				System.out.println("The Values are Matching");

				return true;}
		}catch(Exception e){sgErrMsg="The current values are mismatching due to:"+e;return false;}



	}
	public static boolean VerifyValueinTwoResultsinallpages(By locator,String Testinput,String Testinput1) throws Throwable
	{
		try

		{
			boolean flag = true;

			int flag1=0;
			int flag2=0;
			//List<WebElement> allpages=driver.findElements(By.xpath(".//*[@id='pageLayout-body-inner-most']//span[contains(@class,'p-nums')]//a[contains(@class,'productPageButton')]"));
			List<WebElement> allpages=driver.findElements(By.xpath("(.//div[@class='span17 align_center'])[2]/span[@class='p-nums']/a"));

			int allpagecount=allpages.size();
			WebElement finalelementvalue=allpages.get(allpagecount-1);

			String finalpagevalue=finalelementvalue.getText().toString();
			System.out.println("The final value"+finalpagevalue);
			int finalpage=Integer.parseInt(finalpagevalue);
			String values="";
			String values1="";	
			if(allpagecount==0)
			{

			}else if (allpagecount>1)
			{
				for(int a=1;a<finalpage;a++)

				{

					List<WebElement> AllTitlesfromapplication = driver.findElements(locator);
					List<WebElement> Listlocator1 = driver.findElements(locator);
					int totalResults=Listlocator1.size();


					System.out.println("Currentpages"+finalpage);
					String[] AllTitlesfromApplications=new String[totalResults];


					String Pattern1;
					//String[] Temp=new String[totalResults];

					for(int i=0;i<totalResults;i++)
					{
						WebElement Appdatavalues=AllTitlesfromapplication.get(i);
						WebElement webelements1=Listlocator1.get(i);
						values=Appdatavalues.getText();
						values1=webelements1.getText();

						Pattern1=values1;

						if((Pattern1.contains(Testinput))||(Pattern1.contains(Testinput1)))
						{

							flag1=0;

						}
						else
						{	
							flag2=1;
							break;
						}

					}
					if(a==0)
					{

					}
					else
					{			                    
						click(ElsevierObjects.ClickonNextbutton, "Clicking on Next button in the Results page");
						System.out.println("************************* Clicking On Next button *************************");
						System.out.println("clickingon"+a);
					}                

				}
			}
			if(flag2==1)
			{System.out.println("Actual String Expected is:"+values1);
			sActualValues=values1 ;

			System.out.println("Expected String is:"+Testinput);
			sExpectedValues =Testinput;
			System.out.println("The Excepted String is not avilable in the Results");

			System.out.println("The Values are not Matching");
			return false;
			}
			else if(flag1==0)
			{
				//System.out.println("Actual String Expected is:"+values1);
				//sActualValues=values1 ;
				System.out.println("Expected String in API is:"+Testinput);
				sExpectedValues=Testinput+"and"+Testinput1;
				System.out.println("The Values are Matching");

				return true;}
			else
			{return false;}
		}catch(Exception e){sgErrMsg="The current values are mismatching due to:"+e;return false;}




	}


	public static boolean verifyentiresortorder(String[] Temp) throws Throwable{
		try{
			{
				//String[] Temp=values.split(",");
				List list = Arrays.asList(Temp);

				String ActualStringfromApplication1=Arrays.toString(Temp);
				list = new LinkedList(Arrays.asList(Temp));
				Set set = new HashSet(Arrays.asList(Temp));
				Collections.sort(list, String.CASE_INSENSITIVE_ORDER);
				String[] ExpectedSortingString=(String[]) list.toArray(new String[0]);
				System.out.println("The Expected Sorted list is:"+list);
				String ExpectedSortingString2=Arrays.toString(ExpectedSortingString);

				if(ActualStringfromApplication1.equals(ExpectedSortingString2))
				{

					System.out.println("Actual Sorting is:"+ActualStringfromApplication1);
					sActualValues=ActualStringfromApplication1;
					System.out.println("Expected Sorting is:"+ExpectedSortingString2);
					sExpectedValues=ExpectedSortingString2;
					System.out.println("The Values are Matching");

					return true;
				}

				else
				{  System.out.println("Actual Sorting is:"+ActualStringfromApplication1);
				sActualValues=ActualStringfromApplication1;
				System.out.println("Expected Sorting is:"+ExpectedSortingString2);
				sExpectedValues=ExpectedSortingString2;
				System.out.println("The Values are not Matching");


				return false;}

			}}catch(Exception e){return false;}

	}

	public static boolean verifyentiresortorder(String[] Temp,String ExlusiveYear) throws Throwable{
		try{
			{
				//String[] Temp=values.split(",");
				List list = Arrays.asList(Temp);

				String ActualStringfromApplication1=Arrays.toString(Temp);
				list = new LinkedList(Arrays.asList(Temp));
				Set set = new HashSet(Arrays.asList(Temp));
				Collections.sort(list, Collections.reverseOrder());
				String[] ExpectedSortingString=(String[]) list.toArray(new String[0]);
				System.out.println("The Expected Sorted list is:"+list);
				String ExpectedSortingString2=Arrays.toString(ExpectedSortingString);

				if(ActualStringfromApplication1.equals(ExpectedSortingString2))
				{

					System.out.println("Actual Sorting is:"+ActualStringfromApplication1);
					sActualValues=ActualStringfromApplication1;
					System.out.println("Expected Sorting is:"+ExpectedSortingString2);
					sExpectedValues=ExpectedSortingString2;
					System.out.println("The Values are Matching");

					return true;
				}

				else
				{  System.out.println("Actual Sorting is:"+ActualStringfromApplication1);
				sActualValues=ActualStringfromApplication1;
				System.out.println("Expected Sorting is:"+ExpectedSortingString2);
				sExpectedValues=ExpectedSortingString2;
				System.out.println("The Values are not Matching");


				return false;}

			}}catch(Exception e){return false;}

	}


	public static boolean VerifyContentByUsingHeadertitleforTable(By locator,String[] Headers,String[] Values) throws Exception 
	{

		WebElement tr = driver.findElement(locator);
		int totalAssertions=Headers.length;
		int comparevalue=Values.length;
		if(totalAssertions==comparevalue)
		{
			System.out.println("The length of Title and Values are matching");
		}
		else
		{
			System.out.println("The length of title and Values are not matching");
			return false;
		}
		List<WebElement> headers = tr.findElements(By.xpath("//thead//th"));
		int headercount = headers.size();
		System.out.println(headers.size());
		//for (WebElement column : columns) 
		int[] title  = new int[totalAssertions];
		for(int totalcheck=0;totalcheck<totalAssertions;totalcheck++)
		{
			for (int i = 0; i < headercount; i++) 

			{
				WebElement column=headers.get(i);
				System.out.println("The actualtext:"+column.getText());
				String ActualHeaderText=column.getText();
				String ExpectedValue=Headers[totalcheck];
				System.out.println("Expected Text:"+ExpectedValue);
				if(ActualHeaderText.equals(ExpectedValue))

				{
					String sAssertionActualValue="";

					sAssertionActualValue  = ActualHeaderText;
					title[totalcheck] =i;
					System.out.println(title[totalcheck]);
					break;
				}
			}
		}
		//int[] title  = new int[totalAssertions];
		/*title[0]=1;
	title[1]=2;
	title[2]=3;
	title[3]=4;*/
		List<WebElement> rows = tr.findElements(By.tagName("tr"));		
		int rowscount = rows.size();
		//System.out.println(rowscount);

		for(int j=1;j<rowscount;j++)
		{
			WebElement row=rows.get(j);
			List<WebElement> cols = row.findElements(By.tagName("td"));
			//System.out.println(cols.size());
			String[] arr = new String[totalAssertions];

			for(int totalcheck=0;totalcheck<totalAssertions;totalcheck++)
			{

				int temp=title[totalcheck];
				WebElement row1=cols.get(temp);
				String ActualValue=row1.getText();

				arr[totalcheck]=ActualValue;
			}
			System.out.println("Actual value from Application : "+Arrays.toString(arr));
			System.out.println("Expected value from Application : "+Arrays.toString(Values));

			if(Arrays.equals(arr,Values))		
			{

				System.out.println("To list elements are present in the Todo list table");return true;

			}

		}
		return false;

	}
}

