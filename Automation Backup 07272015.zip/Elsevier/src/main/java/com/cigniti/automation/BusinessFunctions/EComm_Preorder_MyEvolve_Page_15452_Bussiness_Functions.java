package com.cigniti.automation.BusinessFunctions;

import org.openqa.selenium.By;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class EComm_Preorder_MyEvolve_Page_15452_Bussiness_Functions extends Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions{

	public static boolean compareProtectionScheme(String protectionSche)throws Throwable{
		boolean flag= true;
		try{
			if(protectionID1.equalsIgnoreCase(protectionSche)){
				Reporters.SuccessReport("Verify that the Scheme Id value displayed on the Create Access Code tab matches <br/>the protection scheme saved for the corse ID in the above template.", "The Scheme Id value displayed on the Create Access Code tab matches the protection scheme saved for the corse ID in the above template.<br/> Protection Scheme ID saved for the above course : "+protectionSchemeID+"<br/> The Scheme Id value displayed on the Create Access Code tab : "+protectionID1);
			}else{
				Reporters.failureReport("Verify that the Scheme Id value displayed on the Create Access Code tab matches <br/>the protection scheme saved for the corse ID in the above template.", "The Scheme Id value displayed on the Create Access Code tab does not matches the protection scheme saved for the corse ID in the above template.<br/> Protection Scheme ID saved for the above course : "+protectionSchemeID+"<br/> The Scheme Id value displayed on the Create Access Code tab : "+protectionID1);
			}
		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(sgErrMsg="error occurred"+e);return false;
		}
		return flag;
	}
	
	
	
}
