package com.cigniti.automation.BusinessFunctions;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class AdminPasswordReminderEmail_withresetpwlink_15471 extends EvolveCommonBussinessFunctions {
	
	public static String Firstname;
	public static String Lastname;
	public static String EmailId;
	public static String first;
	public static String last;
	public static String email;
	public static String FIRSTNAME;
	public static String LASTNAME;
	public static String EMAILID;
	public static String Password;
	public static String Password1;
	public static String Password2;
	public static String Password3;
	public static String Password4;
	public static String Password5;
	public static String Password6;
	public static String confirmpassword;
	public static String parentHandle;
	
	public static boolean ResetPassword() throws Throwable{
	try
	  {
		boolean flag = true;
		b= true;
		launchUrl(configProps.getProperty("URL2"));
		Thread.sleep(low);
	    click(ElsevierObjects.Admin_Password_reminder,"Password Reminder");
	    Thread.sleep(low);
		isElementPresent(ElsevierObjects.Admin_Password_firstname,"Firstname textbox");	
		Thread.sleep(low);
		isElementPresent(ElsevierObjects.Admin_Password_lastname,"Lastname textbox");
		Thread.sleep(low);
		isElementPresent(ElsevierObjects.Admin_Password_EmailId,"EmailAddress textbox");
		Thread.sleep(low);
		isElementPresent(ElsevierObjects.Admin_Password_submit,"Submit button");
		Thread.sleep(low);
		click(ElsevierObjects.Admin_Password_submit,"Submit button");
		Alert();
		type(ElsevierObjects.Admin_Password_firstname,Firstname,"Enter Firstname in the textbox");
		Thread.sleep(low);
		type(ElsevierObjects.Admin_Password_lastname,Lastname,"Enter Lastname in the textbox");
		Thread.sleep(low);
		type(ElsevierObjects.Admin_Password_EmailId,email,"Enter EmailAddress in the text box");
		Thread.sleep(low);
		click(ElsevierObjects.Admin_Password_submit,"Submit button");
		Thread.sleep(low);
		b = false;
		String Err = getText(ElsevierObjects.Admin_Password_Errmsg,"Get the error message");
		Reporters.SuccessReport("Get error message","Successfully Error message is verified and it is : "+Err);
		Thread.sleep(low);
		b = true;
		type(ElsevierObjects.Admin_Password_firstname,Firstname,"Enter Firstname in the textbox");
		Thread.sleep(low);
		type(ElsevierObjects.Admin_Password_lastname,last,"Enter Lastname in the textbox");
		Thread.sleep(low);
		type(ElsevierObjects.Admin_Password_EmailId,EmailId,"Enter EmailAddress in the text box");
		Thread.sleep(low);
		click(ElsevierObjects.Admin_Password_submit,"Submit button");
		Thread.sleep(low);
		b = false;
		String Err1 = getText(ElsevierObjects.Admin_Password_Errmsg,"Get the error message");
		Reporters.SuccessReport("Get error message","Successfully Error message is verified and it is : "+Err1);
		Thread.sleep(low);
		b = true;
		type(ElsevierObjects.Admin_Password_firstname,first,"Enter Firstname in the textbox");
		Thread.sleep(low);
		type(ElsevierObjects.Admin_Password_lastname,Lastname,"Enter Lastname in the textbox");
		Thread.sleep(low);
		type(ElsevierObjects.Admin_Password_EmailId,EmailId,"Enter EmailAddress in the text box");
		Thread.sleep(low);
		click(ElsevierObjects.Admin_Password_submit,"Submit button");
		Thread.sleep(low);
		b = false;
		String Err2 = getText(ElsevierObjects.Admin_Password_Errmsg,"Get the error message");
		Reporters.SuccessReport("Get error message","Successfully Error message is verified and it is : "+Err2);
		Thread.sleep(low);
		b = true;
		type(ElsevierObjects.Admin_Password_firstname,FIRSTNAME,"Enter Firstname in the textbox");
		Thread.sleep(low);
		type(ElsevierObjects.Admin_Password_lastname,LASTNAME,"Enter Lastname in the textbox");
		Thread.sleep(low);
		type(ElsevierObjects.Admin_Password_EmailId,EMAILID,"Enter EmailAddress in the text box");
		Thread.sleep(low);
		click(ElsevierObjects.Admin_Password_submit,"Submit button");
		Thread.sleep(low);
		b = false;
		String Err3 = getText(ElsevierObjects.Admin_Password_Errmsg1,"Get the error message");
		Reporters.SuccessReport("Get error message","Successfully Error message is verified and it is : "+Err3);
		Thread.sleep(low);
		return flag;}
        catch(Exception e){sgErrMsg=e.getMessage();return false;}
	}
	
		//email forward step 8
	 public static boolean Emailforwarding() throws Throwable {
	 try
		{
		 boolean flag = true;
		 launchUrl(configProps.getProperty("EmailURL"));
		 Thread.sleep(medium);
		 type(ElsevierObjects.emailaddress,configProps.getProperty("verifyemail_username"),"Enter email id");
		 Thread.sleep(medium);
		 type(ElsevierObjects.emailpassword,configProps.getProperty("verifyemail_password"),"Enter password");
		 Thread.sleep(low);
		 click(ElsevierObjects.emaillogin, "Login Button.");
		 Thread.sleep(high);
	     click(ElsevierObjects.email_Icon," Email icon.");
		 Thread.sleep(low);
	     click(ElsevierObjects.email_dropdown,"Click on Dropdown.");
		 Thread.sleep(low);
		 click(ElsevierObjects.email_dropdown_Fromchk,"From check box.");
	     Thread.sleep(low);
	     click(ElsevierObjects.email_dropdown_Tochk,"To checkbox.");
		 Thread.sleep(low);
		 type(ElsevierObjects.email_SearchBox,EMAILID,"EmailAddress.");
		 Thread.sleep(low);
		 click(ElsevierObjects.email_SearchIcon,"search icon.");
		 Thread.sleep(medium);
		 String EmailTitle = getText(ElsevierObjects.titleInEmail,"Verify the Subject of the Email");
		 Reporters.SuccessReport("Verify Subject of Email","Successfully Email subject is verified </br> "+EmailTitle);
		 switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
		 String emailBody=getText(ElsevierObjects.email_body_text,"email body text");
		 Reporters.SuccessReport("Verify Email body content","Successfully Email body content is verified </br> "+emailBody);
		 driver.switchTo().defaultContent();
		 b= true;
	     
		 click(ElsevierObjects.Email_forward,"Forward button");
	     b= false;
	     Thread.sleep(medium);
	     String parentHandle = driver.getWindowHandle();
		 for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle);
			Thread.sleep(medium);
		}	
		Thread.sleep(low);
		b= true;
		type(ElsevierObjects.Email_Forwarding_To,configProps.getProperty("gmailUsername"),"Enter Gmail username in the textbox");
		Thread.sleep(low);
	    click(ElsevierObjects.Email_Send,"Send button");
		driver.switchTo().window(parentHandle);
		Thread.sleep(medium);
		click(ElsevierObjects.email_logout,"Logout button");
		b = false;
	    return flag;}
	    catch(Exception e){sgErrMsg=e.getMessage();return false;}		
	}
	 
		public static boolean WebmailVerification() throws Throwable {
			
			try {
				boolean flag = true;
				
				launchUrl(configProps.getProperty("EmailURL"));
				Thread.sleep(medium);
				type(ElsevierObjects.emailaddress,configProps.getProperty("verifyemail_username"),"Enter email id");
				Thread.sleep(medium);
				type(ElsevierObjects.emailpassword,configProps.getProperty("verifyemail_password"),"Enter password");
				Thread.sleep(low);
				click(ElsevierObjects.emaillogin, "Login Button.");
				Thread.sleep(high);
			    click(ElsevierObjects.email_Icon," Email icon.");
				Thread.sleep(low);
			    click(ElsevierObjects.email_dropdown,"Click on Dropdown.");
				Thread.sleep(low);
				click(ElsevierObjects.email_dropdown_Fromchk,"From check box.");
			    Thread.sleep(low);
			    click(ElsevierObjects.email_dropdown_Tochk,"To checkbox.");
				Thread.sleep(low);
				type(ElsevierObjects.email_SearchBox,EMAILID,"EmailAddress.");
				Thread.sleep(low);
				click(ElsevierObjects.email_SearchIcon,"search icon.");
				Thread.sleep(medium);
				
				String EmailTitle = getText(ElsevierObjects.titleInEmail,"Verify the Subject of the Email");
				Reporters.SuccessReport("Verify email subject","Successfully verified email subject</br> "+EmailTitle);
				/*
				String subject = "Evolve Admin Account Information";
				String EmailTitle = getText(ElsevierObjects.titleInEmail,"Verify the Subject of the Email");
				if(EmailTitle.contains(subject)){
					Reporters.SuccessReport("Verify subject of email", "Successfully verified email subject </br>Email subject is: "+ EmailTitle +"</br>Expected subject is:"+ subject);
				}
				else{
					Reporters.failureReport("Verify subject of email", "Failed to verify email subject </br>Email subject is: " + EmailTitle + "</br>Expected subject is: " + subject);
				}
				*/
				
				switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
				String emailBody=getText(ElsevierObjects.email_body_text,"email body text");
				Reporters.SuccessReport("Verify Email body content","Successfully Email body content is verified </br> "+emailBody);
				/*
				String emailContent="To reset your password for Evolve Admin Please Click Here";
				String emailBody=getText(ElsevierObjects.email_body_text,"email body text");
				if(emailBody.contains(emailContent)){
				    Reporters.SuccessReport("Verify text in email","Successfully verified text in email</br>Email Body Content is : "+ emailBody + "</br>Expected Text is: "+emailContent);
				}else{
					Reporters.failureReport("Verify text in email","Failed to verify text in email</br>Email Body Content is : "+ emailBody + "</br>Expected Text is: "+emailContent);
				}
				*/
				
				click(ElsevierObjects.Email_Inbox_clickhere,"Click Here link present on the mail");
				Thread.sleep(medium);
				String parentHandle = driver.getWindowHandle(); 
				   for (String winHandle : driver.getWindowHandles()) {
				    driver.switchTo().window(winHandle); 
				}
				b = true;
			    isElementPresent(ElsevierObjects.Admin_Password_breadcrumb,"Evolve Breadcrumb for Reset password");
			    isElementPresent(ElsevierObjects.Admin_Password_reset,"password reset header in the page");
			    isElementPresent(ElsevierObjects.Admin_Password_username,"Username in the page");
			    isElementPresent(ElsevierObjects.Admin_Password_newpassword,"textbox of password");
			    isElementPresent(ElsevierObjects.Admin_Password_conformpassword,"textbox of Confirm password");
			    isElementPresent(ElsevierObjects.Admin_Password_newsubmit,"submit button");
			    //password
			    type(ElsevierObjects.Admin_Password_newpassword,Password," Password ");
			    Thread.sleep(low);
			    type(ElsevierObjects.Admin_Password_conformpassword,Password," Confirmpassword ");
			    Thread.sleep(low);
			    click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
				Thread.sleep(low);
				b= false;
			    String err = getText(ElsevierObjects.Admin_Password_Errmsg2,"Get error message");
			    Reporters.SuccessReport("Get error message","Successfully Error message is verified and it is : "+err);
				Thread.sleep(low);
				//password1
				b = true;
				type(ElsevierObjects.Admin_Password_newpassword,Password1," Password ");
			    Thread.sleep(low);
			    type(ElsevierObjects.Admin_Password_conformpassword,Password1," Confirmpassword ");
			    Thread.sleep(low);
			    click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
				Thread.sleep(low);
				b = false;
			    String err1 = getText(ElsevierObjects.Admin_Password_Errmsg3,"Get the error message");
			    Reporters.SuccessReport("Get error message","Successfully Error message is verified and it is : "+err1);
				Thread.sleep(low);
				//password2
				b = true;
				type(ElsevierObjects.Admin_Password_newpassword,Password2,"Enter Password in the textbox");
			    Thread.sleep(low);
			    type(ElsevierObjects.Admin_Password_conformpassword,Password2," Confirmpassword ");
			    Thread.sleep(low);
			    click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
				Thread.sleep(low);
				b = false;
			    String err2 = getText(ElsevierObjects.Admin_Password_Errmsg3,"error message");
			    Reporters.SuccessReport("Get error message","Successfully Error message is verified and it is : "+err2);
				Thread.sleep(low);
				//password3
				b = true;
				type(ElsevierObjects.Admin_Password_newpassword,Password3," Password ");
			    Thread.sleep(low);
			    type(ElsevierObjects.Admin_Password_conformpassword,Password3,"Confirmpassword");
			    Thread.sleep(low);
			    click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
				Thread.sleep(low);
				b = false;
			    String err3 = getText(ElsevierObjects.Admin_Password_Errmsg4,"error message");
			    Reporters.SuccessReport("Get error message","Successfully Error message is verified and it is : "+err3);
				Thread.sleep(low);
				//password4
				b = true;
				type(ElsevierObjects.Admin_Password_newpassword,Password4," Password");
			    Thread.sleep(low);
			    type(ElsevierObjects.Admin_Password_conformpassword,Password4," confirmpassword ");
			    Thread.sleep(low);
			    click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
				Thread.sleep(low);
				b = false;
			    String err4 = getText(ElsevierObjects.Admin_Password_Errmsg5,"error message");
			    Reporters.SuccessReport("Get error message","Successfully Error message is verified and it is : "+err4);
				Thread.sleep(low);
			   //password5
				b = true;
				type(ElsevierObjects.Admin_Password_newpassword,Password5," Password");
			    Thread.sleep(low);
			    type(ElsevierObjects.Admin_Password_conformpassword,Password5,"Enter Confirmpassword in the textbox");
			    Thread.sleep(low);
			    click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
				Thread.sleep(low);
				b = false;
			    String err5 = getText(ElsevierObjects.Admin_Password_Errmsg4,"error message");
			    Reporters.SuccessReport("Get error message","Successfully Error message is verified and it is : "+err5);
				Thread.sleep(low);
				//password6
				b = true;
				type(ElsevierObjects.Admin_Password_newpassword,Password6,"Enter Password in the textbox");
			    Thread.sleep(low);
			    type(ElsevierObjects.Admin_Password_conformpassword,confirmpassword,"Confirmpassword ");
			    Thread.sleep(low);
			    click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
				Thread.sleep(low);
				Alert();
				//password
				type(ElsevierObjects.Admin_Password_newpassword,Password6," Password ");
			    Thread.sleep(low);
			    type(ElsevierObjects.Admin_Password_conformpassword,Password6," Confirmpassword");
			    Thread.sleep(low);
			    click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
				Thread.sleep(low);
				b = false;
				String SuccMsg = getText(ElsevierObjects.Admin_Password_Succmsg,"success message");
				Reporters.SuccessReport("Get success message","Successfully message is verified and it is : "+SuccMsg);
				Thread.sleep(low);
				//re login
				b = true;
				type(ElsevierObjects.Admin_Login_password,Password6,"password");
				Thread.sleep(low);
				click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
				b= false;
				driver.switchTo().window(parentHandle);
				
				return flag;
			} catch (Exception e){
				sgErrMsg=e.getMessage();
				return false;
			}
		}
 
	  //step 9
	 public static boolean Gmailverification() throws Throwable{
	 try
	   {
	    boolean flag = true;
		
	    driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");
		Thread.sleep(low);
	    launchUrl(configProps.getProperty("GmailURL"));
		Thread.sleep(low);
		type(ElsevierObjects.Gmail_username,configProps.getProperty("gmailUsername"),"Enter username");
		Thread.sleep(low);
		click(ElsevierObjects.Gmail_next, "Click on Next");
		Thread.sleep(low);
		type(ElsevierObjects.Gmail_password,configProps.getProperty("gmailPassword"),"Enter password");
		Thread.sleep(low);
		click(ElsevierObjects.Gmail_login,"Click on login");
		Thread.sleep(medium);
		click(ElsevierObjects.Gmail_searchbox,"Click on gmail searchbox");
		Thread.sleep(low);
		type(ElsevierObjects.Gmail_searchbox,EMAILID,"Enter EmailAddress in the searchbox");
		Thread.sleep(low);
		click(ElsevierObjects.Gmail_search_button,"Click on search button");
		Thread.sleep(low);
		click(ElsevierObjects.Gmail_verify_mail,"Click on forward mail present there");
		Thread.sleep(low);
		String s1 ="Dear TEST AUTO,\n"+
		"To reset your password for Evolve Admin Please Click Here";
				System.out.println(s1.split("/n")[0]);
				
		String emailContent="To reset your password for Evolve Admin Please Click Here";
		String content = getText(ElsevierObjects.Gmail_content,"Get Text of body content");
		if(content.contains(emailContent)){
		    Reporters.SuccessReport("Verify text in Email","Successfully text in Email is verified </br> Email Body Content is : "+content+" </br> Expected Text is : "+emailContent);
		}else{
			Reporters.failureReport("Verify text in Email","Failed to verify text in Email </br> Email Body Content is : "+content+" </br> Expected Text is : "+emailContent);
		}
		b = true;
		click(ElsevierObjects.Gmail_Inbox_clickhere,"Click Here link present on the mail");
		b = false;
	    
	    /*
		// verify email text
		String emailContent = "To reset your password for Evolve Admin Please";
		String emailBody = getText(ElsevierObjects.email_body_text,"email body text");
		if(emailBody.contains(emailContent)){
			  Reporters.SuccessReport("Verify text in Email","Successfully verified text in email </br> Email Body Content is : " + emailBody + " </br> Expected Text is : " + emailContent);
		}else{
			  Reporters.failureReport("Verify text in Email","Failed to verify text in Email </br> Email Body Content is : "+ emailBody + " </br> Expected Text is : " + emailContent);
		}
		  
		// click the link in the email
		b = true;
		if(!click(ElsevierObjects.Email_Inbox_clickhere, "Click password reset link in email.")){
			Reporters.failureReport("Click password reset link in email", "Failed to click password reset link in email");
		}
		else{
			Reporters.SuccessReport("Click password reset link in email", "Successfully clicked password reset link in email");
		}
		b = false;
		*/
	    
		String parentHandle = driver.getWindowHandle(); 
		   for (String winHandle : driver.getWindowHandles()) {
		    driver.switchTo().window(winHandle); 
		}
		b = true;
	    isElementPresent(ElsevierObjects.Admin_Password_breadcrumb,"Evolve Breadcrumb for Reset password");
	    isElementPresent(ElsevierObjects.Admin_Password_reset,"password reset header in the page");
	    isElementPresent(ElsevierObjects.Admin_Password_username,"Username in the page");
	    isElementPresent(ElsevierObjects.Admin_Password_newpassword,"textbox of password");
	    isElementPresent(ElsevierObjects.Admin_Password_conformpassword,"textbox of Confirm password");
	    isElementPresent(ElsevierObjects.Admin_Password_newsubmit,"submit button");
	    //password
	    type(ElsevierObjects.Admin_Password_newpassword,Password," Password ");
	    Thread.sleep(low);
	    type(ElsevierObjects.Admin_Password_conformpassword,Password," Confirmpassword ");
	    Thread.sleep(low);
	    click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
		Thread.sleep(low);
		b= false;
	    String err = getText(ElsevierObjects.Admin_Password_Errmsg2,"Get error message");
	    Reporters.SuccessReport("Get error message","Successfully Error message is verified and it is : "+err);
		Thread.sleep(low);
		//password1
		b = true;
		type(ElsevierObjects.Admin_Password_newpassword,Password1," Password ");
	    Thread.sleep(low);
	    type(ElsevierObjects.Admin_Password_conformpassword,Password1," Confirmpassword ");
	    Thread.sleep(low);
	    click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
		Thread.sleep(low);
		b = false;
	    String err1 = getText(ElsevierObjects.Admin_Password_Errmsg3,"Get the error message");
	    Reporters.SuccessReport("Get error message","Successfully Error message is verified and it is : "+err1);
		Thread.sleep(low);
		//password2
		b = true;
		type(ElsevierObjects.Admin_Password_newpassword,Password2,"Enter Password in the textbox");
	    Thread.sleep(low);
	    type(ElsevierObjects.Admin_Password_conformpassword,Password2," Confirmpassword ");
	    Thread.sleep(low);
	    click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
		Thread.sleep(low);
		b = false;
	    String err2 = getText(ElsevierObjects.Admin_Password_Errmsg3,"error message");
	    Reporters.SuccessReport("Get error message","Successfully Error message is verified and it is : "+err2);
		Thread.sleep(low);
		//password3
		b = true;
		type(ElsevierObjects.Admin_Password_newpassword,Password3," Password ");
	    Thread.sleep(low);
	    type(ElsevierObjects.Admin_Password_conformpassword,Password3,"Confirmpassword");
	    Thread.sleep(low);
	    click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
		Thread.sleep(low);
		b = false;
	    String err3 = getText(ElsevierObjects.Admin_Password_Errmsg4,"error message");
	    Reporters.SuccessReport("Get error message","Successfully Error message is verified and it is : "+err3);
		Thread.sleep(low);
		//password4
		b = true;
		type(ElsevierObjects.Admin_Password_newpassword,Password4," Password");
	    Thread.sleep(low);
	    type(ElsevierObjects.Admin_Password_conformpassword,Password4," confirmpassword ");
	    Thread.sleep(low);
	    click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
		Thread.sleep(low);
		b = false;
	    String err4 = getText(ElsevierObjects.Admin_Password_Errmsg5,"error message");
	    Reporters.SuccessReport("Get error message","Successfully Error message is verified and it is : "+err4);
		Thread.sleep(low);
	   //password5
		b = true;
		type(ElsevierObjects.Admin_Password_newpassword,Password5," Password");
	    Thread.sleep(low);
	    type(ElsevierObjects.Admin_Password_conformpassword,Password5,"Enter Confirmpassword in the textbox");
	    Thread.sleep(low);
	    click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
		Thread.sleep(low);
		b = false;
	    String err5 = getText(ElsevierObjects.Admin_Password_Errmsg4,"error message");
	    Reporters.SuccessReport("Get error message","Successfully Error message is verified and it is : "+err5);
		Thread.sleep(low);
		//password6
		b = true;
		type(ElsevierObjects.Admin_Password_newpassword,Password6,"Enter Password in the textbox");
	    Thread.sleep(low);
	    type(ElsevierObjects.Admin_Password_conformpassword,confirmpassword,"Confirmpassword ");
	    Thread.sleep(low);
	    click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
		Thread.sleep(low);
		Alert();
		//password
		type(ElsevierObjects.Admin_Password_newpassword,Password6," Password ");
	    Thread.sleep(low);
	    type(ElsevierObjects.Admin_Password_conformpassword,Password6," Confirmpassword");
	    Thread.sleep(low);
	    click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
		Thread.sleep(low);
		b = false;
		String SuccMsg = getText(ElsevierObjects.Admin_Password_Succmsg,"success message");
		Reporters.SuccessReport("Get success message","Successfully message is verified and it is : "+SuccMsg);
		Thread.sleep(low);
		//re login
		b = true;
		type(ElsevierObjects.Admin_Login_password,Password6,"password");
		Thread.sleep(low);
		click(ElsevierObjects.Admin_Password_newsubmit,"Submit button");
		b= false;
		driver.switchTo().window(parentHandle);
		
		return flag;}
	    catch(Exception e){sgErrMsg=e.getMessage();return false;}
	 }

}
