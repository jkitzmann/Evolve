package com.cigniti.automation.Utilities;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateGenerator {

	public static String getFutureDate(int extendDays){
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Calendar c = Calendar.getInstance();
		c.setTime(new Date());
		c.add(Calendar.DATE, extendDays);
		return sdf.format(c.getTime());
	}
	
	public static String getPastDate(){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Calendar c = Calendar.getInstance();
		c.setTime(new Date());
		c.add(Calendar.DATE, -10);
		return sdf.format(c.getTime());
	}
	
	public static String convertDate(String dateString){
		String end = new String();
		try {
		       DateFormat oldFormat = new SimpleDateFormat("MM/dd/yy");
		       Date date = (Date)oldFormat.parse(dateString);
		       SimpleDateFormat newFormat = new SimpleDateFormat("dd-MMM-yyyy");
		       end = newFormat.format(date);
		       System.out.println(end);
		} catch (Exception e) {
		       System.out.println("exception");
		}
		return end;
	}
		
}
