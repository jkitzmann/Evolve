package com.cigniti.automation.BusinessFunctions;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class Add_Administrators_UI_15476 extends EvolveCommonBussinessFunctions {

	public static String Firstname;
	public static String Lastname;
	public static String EmailId;
	public static String Username;
	public static String Password;
	public static String data3;
	public static String data2;
	public static String firstname;
	public static String lastname;
	public static String Email;

	public static boolean AddAdministrators() throws Throwable {
		boolean flag = true;
		try
		{
			if(click(ElsevierObjects.Admin_Evolve_Admin_AddAdministrator,"Click on Add Administrators")){
				Reporters.SuccessReport("Click on Add Administartors","Clicked on Add Administrators.");
			}else{
				Reporters.failureReport("Click on Add Administartors","Failed to click on Add Administartors.");
			}
			if(isElementPresent(ElsevierObjects.Admin_Evolve_Admin_AdminPage,"Verify Admin page")){
				Reporters.SuccessReport("Verify the Add Administrator header", "Add Administrator header is verified");
			}else{
				Reporters.failureReport("Verify the Add Administrator header", "Failed to verify the Add Administrator header");
			}
			Thread.sleep(medium);
			if(isChecked(ElsevierObjects.Admin_Evolve_Admin_Enable,"Verify Enable Checkbox")){
				Reporters.SuccessReport("Verify checkbox","Checkbox is verified and it is enabled");
			}else{
				Reporters.failureReport("Verify checkbox","Failed to verify Enable Checkbox");
			}
			if(isElementPresent(ElsevierObjects.Admin_Evolve_Admin_Create,"Verify Create button")){
				Reporters.SuccessReport("Verify the Create button", "Create button is present");
			}else{
				Reporters.failureReport("Verify the Create button", "Create button is not present");
			}
			if(isElementPresent(ElsevierObjects.Admin_Evolve_Admin_Firstname,"Verify Firstname textbox")){
				Reporters.SuccessReport("Verify the textbox of firstname","Firstname textbox is verified");
			}else{
				Reporters.failureReport("Verify the textbox of firstname","Failed to verify the firstname textbox");
			}
			Thread.sleep(low);	
			if(isElementPresent(ElsevierObjects.Admin_Evolve_Admin_Lastname,"Verify Lastname textbox")){
				Reporters.SuccessReport("Verify the textbox of Lastname","Lastname textbox is verified");
			}else{
				Reporters.failureReport("Verify the textbox of Lastname","Failed to verify the Lastname textbox");
			}
			Thread.sleep(low);
			if(isElementPresent(ElsevierObjects.Admin_Evolve_Admin_Email,"Verify Email textbox")){
				Reporters.SuccessReport("Verify the textbox of EmailAddress","EmailAddress textbox is verified");
			}else{
				Reporters.failureReport("Verify the textbox of  EmailAddress","Failed to verify the EmailAddress textbox");
			}
			Thread.sleep(low);
			if(isElementPresent(ElsevierObjects.Admin_Evolve_Admin_Dept,"Verify Department textbox")){
				Reporters.SuccessReport("Verify the textbox of Department","Department textbox is verified");
			}else{
				Reporters.failureReport("Verify the textbox of Department","Failed to verify the Department textbox");
			}
			if(isElementPresent(ElsevierObjects.Admin_Evolve_Admin_User,"Verify Username textbox")){
				Reporters.SuccessReport("Verify the textbox of Username","Username textbox is verified");
			}else{
				Reporters.failureReport("Verify the textbox of Username","Failed to verify the Username textbox");
			}
			if(isElementPresent(ElsevierObjects.Admin_Evolve_Admin_Password,"Verify DefaultPassword textbox")){
				Reporters.SuccessReport("Verify the textbox of DefaultPassword","DefaultPassword textbox is verified");
			}else{
				Reporters.failureReport("Verify the textbox of DefaultPassword","Failed to verify the DefaultPassword textbox");
			}
			if(isElementPresent(ElsevierObjects.Admin_Evolve_Admin_ForcePW,"Verify Forcepassword Checkbox")){
				Reporters.SuccessReport("Verify Checkbox","Successfully ForcePassword Checkbox is verified");
			}else{
				Reporters.failureReport("Verify Checkbox","Failed to Verify ForecePassword Checkbox");
			}
			Thread.sleep(low);
			List<WebElement> allOptions = driver.findElements(ElsevierObjects.Admin_Evolve_Admin_Roles);
			for(WebElement data: allOptions){
				data1=data.getText();
				System.out.println(data1);
			}

			List<String> s = new ArrayList<String>();
			s.add("Maintain Administrators");
			s.add("Maintain Products");
			s.add("Maintain Adoptions");
			s.add("Maintain Evolve Users");
			s.add("Maintain Variables");
			s.add("Manage Institution");
			s.add("Site Builder");
			s.add("Bookstore Taxonomy");
			s.add("Platform Service Health Management");
			s.add("External Role Management");
			s.add("ACM Admin");
			s.add("ACM Editor");
			s.add("ACM View Only");
			s.add("Promotion Management");
			s.add("Promotion Management Read Only");
			s.add("Ecommerce Package Maintenance");
			s.add("Ecommerce Package Read Only");
			s.add("Access Code Package Maintenance");
			s.add("Access Code Package Read Only");
			s.add("Create Unassigned Codes");
			s.add("Upload Unassigned Codes");
			s.add("Maintain PPM Data Settings");
			s.add("Pre-Order Maintenance");
			s.add("Platform Reporting");
			System.out.println(s);
			for(String s1: s){
				if(data1.trim().contains(s1.trim())){
					Reporters.SuccessReport("Verify products","EachProduct is verified Successfully and Product is : "+s1);
				}else{
					Reporters.failureReport("Verify products","Product verification is failed");
				}	
			}
			Thread.sleep(low);
			type(ElsevierObjects.Admin_Evolve_Admin_Firstname,Firstname,"Enter First Name into the textbox");
			Thread.sleep(low);
			type(ElsevierObjects.Admin_Evolve_Admin_Lastname,Lastname,"Enter Last Name into the textbox");
			Thread.sleep(low);
			type(ElsevierObjects.Admin_Evolve_Admin_Email,EmailId,"Enter Emailaddress into the textbox");
			Thread.sleep(low);
			type(ElsevierObjects.Admin_Evolve_Admin_User,Username,"Enter Username into the textbox");
			Thread.sleep(low);
			type(ElsevierObjects.Admin_Evolve_Admin_Password,Password,"Enter Password into the textbox");
			Thread.sleep(medium);
			click(ElsevierObjects.Admin_Evolve_Admin_Maintainproducts,"Click on Maintain Products Checkbox");
			Thread.sleep(low);
			Reporters.SuccessReport("Enter Details","Details are Entered successfully and clicked on Maintain Products checkbox and details are : </br> Firstname :"+Firstname+"</br>"+"Lastname :"+Lastname+
					"</br>"+"EmailAddress :"+EmailId+"</br>"+"Username :"+Username+"</br>"+"Password :"+Password);
			if(click(ElsevierObjects.Admin_Evolve_Admin_Create,"Click on Create button")){
				Reporters.SuccessReport("Click on Create button","Successfully Clicked on Create button");
			}else{
				Reporters.failureReport("Click on Create button","Failed to click on Create button");
			}

			Thread.sleep(medium);
			String SMsg =getText(ElsevierObjects.Admin_Evolve_Admin_succmsg,"Get Success Message present there");
			Reporters.SuccessReport("Verify the Account Creation message", "Successfully Account is Created and message is present : " +SMsg);
			Thread.sleep(low);
			if(click(ElsevierObjects.Admin_Evolve_Admin_Evolvecrumb,"Click on EvolveAdmin breadCrumb")){
				Reporters.SuccessReport("Click on EvolveAdmin breadCrumb","Successfully clicked on EvolveAdmin breadCrumb");
			}else{
				Reporters.failureReport("Click on EvolveAdmin breadCrumb","Failed to click on EvolveAdmin breadCrumb");
			}
			return flag;}
			catch(Exception e){
			sgErrMsg=e.getMessage();return false;}
	}

	public static boolean ManageAdministrators()throws Throwable{
		try
		{
			boolean flag = true;
			if(isElementPresent(ElsevierObjects.Admin_Evolve_Admin_ManageAdmin,"Verify ManageAdminstrators")){
				Reporters.SuccessReport("Verify Manage Administrators","Successfully page is navigated to EvolveAdmin and Manage Administrators is verified");
			}else{
				Reporters.failureReport("Verify Manage Administrators","Failed to Verify Manage Administrators");
			}
			if(click(ElsevierObjects.Admin_Evolve_Admin_ManageAdmin,"Click on Manage Administrators")){
				Reporters.SuccessReport("Click on Manage Administrators","Successfully clicked on Manage Administrators");
			}else{
				Reporters.failureReport("Click on Manage Administrators","Failed to click on Manage Administrators");
			}
			isElementPresent(ElsevierObjects.Admin_Evolve_Admin_userlink,"Verify Username list in the table");

			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			Date date = new Date();
			System.out.println(dateFormat.format(date));

			int iRowsCnt=driver.findElements(ElsevierObjects.Admin_Evolve_Manageadmin_table).size();
			for ( int iRow=2;iRow<=iRowsCnt;iRow++)
			{
				String str = Username;
				String s1 = EmailId;
				String sActualStringXpath=ElsevierObjects.user1+iRow+ElsevierObjects.user2;
				String sActualString=driver.findElement(By.xpath(sActualStringXpath)).getText().trim();
				System.out.println("Äctual String :" + sActualString);
				if (sActualString.equals(str)){
					System.out.println("Matching");
					String applicationdatexpath =ElsevierObjects.verify1+s1+ElsevierObjects.verify2;
					String applicationdate=driver.findElement(By.xpath(applicationdatexpath)).getText().trim();
					System.out.println("Application date:"+applicationdate);
					String date1=""+dateFormat.format(date);
					if(date1.contains(applicationdate)){
						Reporters.SuccessReport("Compare the Application date with Currentdate", "Current Date : "+date1+" </br> Application Date : "+applicationdate);
					}else{
						Reporters.failureReport("Compare the Application date with Currentdate", "Current Date : "+date1+" </br> Application Date : "+applicationdate);
					}
					String Statusxpath = ElsevierObjects.verify1+s1+ElsevierObjects.verify3;
					String Status=driver.findElement(By.xpath(Statusxpath)).getText().trim();
					Reporters.SuccessReport("Verify Status","Status is Verified and it is : "+Status);
					System.out.println("Status :"+Status);
					driver.findElement(By.xpath(sActualStringXpath)).click();
					Reporters.SuccessReport("Search and click","Searched with the username successfully clicked on that username and Page is navigated to Edit Administrators");
					break;
				}
				else 
					System.out.println("There is no Matching for the provided string");
			}    
			return flag;}
		catch(Exception e){sgErrMsg=e.getMessage();
			return false;}
	}

	public static boolean EditAdministrator()throws Throwable{
		try
		{
			boolean flag = true;
			String s = Username;
			String username = getText(ElsevierObjects.Admin_Evolve_Admin_Edituser,"Get the Username present there");
			if(username.contains(s)){
				Reporters.SuccessReport("Verify the Username","Successfully Username is verified : <br> Expected Username is :" +username+" </br> Actual Username is :"+s);
			}else{
				Reporters.failureReport("Verify the Username","Username verification is Failed : <br> Expected Username is :" +username+" </br> Actual Username is :"+s);
			}
			Thread.sleep(medium);
			String f = Firstname;
			firstname = getAttribute(ElsevierObjects.Admin_Evolve_Admin_Editfirst,"value","Get the Firstname present there");
			if(firstname.contains(f)){
				Reporters.SuccessReport("Verify the Firstname","Successfully Firstname is verified : <br> Expected Firstname is :"+firstname+" </br> Actual Firstname is :"+f);
			}else{
				Reporters.failureReport("Verify the Firstname","Firstname verification is Failed: <br> Expected Firstname is :"+firstname+" </br> Actual Firstname is :"+f);
			}
			Thread.sleep(medium);
			String l = Lastname;
			lastname = getAttribute(ElsevierObjects.Admin_Evolve_Admin_Editlast,"value","Get the Lastname present there");
			if(lastname.contains(l)){
				Reporters.SuccessReport("Verify the Lastname","Successfully Lastname is verified : <br> Expected Lastname is :"+lastname+" </br> Actual Lastname is :"+l);
			}else{
				Reporters.failureReport("Verify the Lastname","Lastname verification is Failed : <br> Expected Lastname is :"+lastname+" </br> Actual Lastname is :"+l);
			}
			Thread.sleep(medium);
			String E = EmailId;
			Email = getAttribute(ElsevierObjects.Admin_Evolve_Admin_Editemail,"value","Get the EmailAddress present there");
			if(Email.contains(E)){
				Reporters.SuccessReport("Verify the EmailAddress","Successfully EmailAddress is verified : <br> Expected EmailAddress is :"+Email+" </br> Actual EmailAddress is :"+E);
			}else{
				Reporters.failureReport("Verify the EmailAddress","EmailAddress verification is Failed : <br> Expected EmailAddress is :"+Email+" </br> Actual EmailAddress is :"+E);
			}
			Thread.sleep(medium);
			String P = "*******";
			String password = getText(ElsevierObjects.Admin_Evolve_Admin_Editpwd,"Get the password present there");
			if(password.contains(P)){
				Reporters.SuccessReport("Verify the Password","Successfully Password is verified : <br> Expected Password is :"+password+" </br> Actual Password is :"+P);
			}else{
				Reporters.failureReport("Verify the Password","Password verification is Failed : <br> Expected Password is :"+password+" </br> Actual Password is :"+P);
			}
			Thread.sleep(medium);
			if(isElementPresent(ElsevierObjects.Admin_Evolve_Admin_Editchk,"Verify Checkmark is present on Maintain Products")){
				Reporters.SuccessReport("Verify Checkbox","Successfully Checkbox is verified present on Maintain Products and All roles are not-editable");
			}else{
				Reporters.failureReport("Verify Checkbox","Failed to verify Checkbox present on Maintain Products");
			}
			return flag;}
		catch(Exception e){sgErrMsg=e.getMessage();return false;}
	}
	public static boolean login()throws Throwable{
		try
		{
			boolean flag = true;   
			type(ElsevierObjects.adminLogin,Username,"Enter username" );
			Thread.sleep(low);
			type(ElsevierObjects.adminPassword,Password,"Enter password" );
			Thread.sleep(low);
			click(ElsevierObjects.adminSubmit,"Click on submit button");
			Thread.sleep(medium);
			ArrayList<String> list = new ArrayList<String>();
			List<WebElement> allHeadingsList=driver.findElements(ElsevierObjects.allProductHeadingsList);
			for(WebElement data: allHeadingsList){
				data3=data.getText();
				list.add(data3);
				System.out.println(data3);
			}   
			List<String> e = new ArrayList<String>();
			e.add("Product Maintenance");
			e.add("Change Evolve Admin Password");
			e.add("Email Template Maintenance");
			e.add("ONIX PPM Load Data Manager");
			System.out.println(e);
			int ind=0;
			for(String s1: e){
				if(list.get(ind).trim().contains(s1.trim())){
					ind++;
					Reporters.SuccessReport("Verify headers of the page","Successfully Each header is verified and header is : " +s1);
				}else{
					Reporters.failureReport("Verify headers of the page","Failed to verify header in the page");
				}	
			}

			Thread.sleep(medium);
			ArrayList<String> list1 = new ArrayList<String>();
			List<WebElement> allProductsList=driver.findElements(ElsevierObjects.allProductList);
			for(WebElement data: allProductsList){
				data2=data.getText();
				list1.add(data2);
				System.out.println(data2);
			}

			List<String> P = new ArrayList<String>();
			P.add("Maintain Products");
			P.add("Maintain Smart Taxonomy");
			P.add("Maintain Bookstore Taxonomy");
			P.add("Change My Password");
			P.add("Browse Published Email Templates");
			P.add("Create New Email Templates");
			P.add("View Report of the Base Products By the Date");
			P.add("View Report of the Related Products By the Date");
			System.out.println(P);
			int i = 0;
			for(String p1: P){
				if(list1.get(i).trim().contains(p1.trim())){
					i++;
					Reporters.SuccessReport("Verify list of prodcuts","Successfully Each product in the list is verified and product is : "+p1);
				}else{
					Reporters.failureReport("Verify list of prodcuts","Failed to verify each product in the list");
				}	
			}
			return flag;}
		catch(Exception e){sgErrMsg=e.getMessage();return false;}
	}
}
