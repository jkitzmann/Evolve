package com.cigniti.automation.BusinessFunctions;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import jxl.Sheet;
import jxl.Workbook;

public class ExcelGetCell 
{
	/*public static Sheet wrkSheetObj,inputSheetObj =null;
    public static Workbook wrkBookObj =null;
    
    public static  Sheet getSheetObject(String inputDataFilePath, String SheetName) throws Exception
	{
		FileInputStream file = new FileInputStream(new File(inputDataFilePath));
		Workbook wrkBookObj =  Workbook.getWorkbook(file); 
		Sheet wrkSheetObj= wrkBookObj.getSheet(SheetName);		
		return wrkSheetObj;
	}
    
    public static String getSheetCellData(Sheet inputSheetObj, String ColumnName,int row) throws Exception
	{		
    	String cellData=null;
    	String cellDataFlag="False";
		int SheetColCount=inputSheetObj.getColumns();
		for(int Colcnt=0;Colcnt<SheetColCount;Colcnt++)
		{
			if((inputSheetObj.getCell(Colcnt,0).getContents()).equals(ColumnName))
			{
				cellData=inputSheetObj.getCell(Colcnt, row).getContents();
				cellDataFlag="True";
				//System.out.println("Column Match and data is  ="+inputSheetObj.getCell(Colcnt, row).getContents());
			}			
		}
		if(cellDataFlag.equals("False"))				
			System.out.println("Column Name: "+ColumnName+" doesn't exist in the sheet");
		return cellData;
		
	}*/
	
	/*public static XSSFSheet wrkSheetObj, inputSheetObj =null;
    public static XSSFWorkbook wrkBookObj =null;
    public static  XSSFSheet getSheetObject(String inputDataFilePath, String SheetName) throws Exception
   	{
    	File f = new File(inputDataFilePath);
    	FileInputStream ios = new FileInputStream(f);
        XSSFWorkbook workbook = new XSSFWorkbook(ios);
        return wrkSheetObj;
   	}
    public static  XSSFSheet getSheetObject(XSSFSheet inputSheetObj, String columnNumber, int rowNumber) throws Exception
	{
    	
    	String cellData=null;
    	String cellDataFlag="False";
		int SheetColCount=inputSheetObj.
        XSSFSheet sheet = workbook.getSheetAt(sheetIndex);
        Cell cell = sheet.getRow(rowNumber).getCell(columnNumber);
        
        switch(cell.getCellType()) {
		case Cell.CELL_TYPE_STRING: 
			cellData = cell.getStringCellValue();
			break;
		case Cell.CELL_TYPE_NUMERIC:  
			cellData = ""+cell.getNumericCellValue();
			break;
		}
		
		return wrkSheetObj;
	}
    
    public static String getSheetCellData(Sheet inputSheetObj, String ColumnName,int row) throws Exception
	{		
    	String cellData=null;
    	String cellDataFlag="False";
		int SheetColCount=inputSheetObj.getColumns();
		for(int Colcnt=0;Colcnt<SheetColCount;Colcnt++)
		{
			if((inputSheetObj.getCell(Colcnt,0).getContents()).equals(ColumnName))
			{
				cellData=inputSheetObj.getCell(Colcnt, row).getContents();
				cellDataFlag="True";
				//System.out.println("Column Match and data is  ="+inputSheetObj.getCell(Colcnt, row).getContents());
			}			
		}
		if(cellDataFlag.equals("False"))				
			System.out.println("Column Name: "+ColumnName+" doesn't exist in the sheet");
		return cellData;
		
	}*/

}
