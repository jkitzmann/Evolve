package com.cigniti.automation.BusinessFunctions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class Manual_Unique_Course_Fulfillment_10436_BussinessFuncitons extends Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions {

	String productTitle  ="";

	public void searchISBNNumber(String isBNumber) throws Throwable{
		
		System.out.println("In Search iSBN");
		
		
		
		String errorMessage ="";
		try{
			
			Thread.sleep(medium);
			
			if(!click(ElsevierObjects.catalog, "")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.txtproductsearch, isBNumber, "")){
				flag = false;
			}
			Thread.sleep(low);
			if(click(ElsevierObjects.gobutton, "")){
				Reporters.SuccessReport("Search for "+isBNumber, "Successfully entered "+isBNumber+" product and clicked on go");
			}else{
				Reporters.failureReport("Search for "+isBNumber, "Failed to enter "+isBNumber+" product");
			}
			waitForElementPresent(ElsevierObjects.gobutton, "");
			
			Thread.sleep(medium);
			productTitle = getText(By.xpath("//*[@id='tab-relayout']/div/div[2]/h1"),"");
			
			if(click(ElsevierObjects.btnaddtocart, "")){
				Reporters.SuccessReport("Press the 'Request this Product Now'" , "Successfully Clicked on the 'Request this Product Now'");
			}else{
				Reporters.failureReport("Press the 'Request this Product Now'", "Failed to Click on the 'Request this Product Now'");
			}
			
			waitForElementPresent(ElsevierObjects.Student_BillingAdd_ModalDialog, "");
			
			if(!switchToFrameByLocator(ElsevierObjects.Student_BillingAdd_ModalDialog, "Switch to IFrame")){

				flag=false;
			}

			if(isElementPresent(ElsevierObjects.Faculty_ContentPlus_ApplyButton,"")){
				Reporters.SuccessReport(" Verify course configuration pop up", "Success fully displays the course configuration pop up");
			}else{
				Reporters.failureReport(" Verify course configuration pop up", "Unable to display the course configuration pop up");
			}
			
			click(ElsevierObjects.Faculty_ContentPlus_ApplyButton, "");
		}
			catch(Exception e){sgErrMsg=e.getMessage();
			System.out.println(e);
		}



	}
	public void  evolveContentPlus() throws Throwable{


		//click(ElsevierObjects.btnapply, "");
try{
		if(isElementPresent(By.xpath("//div[@class='carttitle']//a"),"")){
			Reporters.SuccessReport("Verify the product is now displayed for the user on the My Cart page.", "The product "+getText(By.xpath("//div[@class='carttitle']//a"), "")+" is now displayed for the user on the My Cart page");
		}else{
			Reporters.failureReport("Verify the product is now displayed for the user on the My Cart page.", "Unable to dispaly the product on Cart Page");
		}

		if(click(ElsevierObjects.Student_MyCart_Checkout_btn, "")){
			Reporters.SuccessReport("Press the 'Redeem/Checkout' button.", "Successfully clicked on the 'Redeem/Checkout' button.");
		}else{
			Reporters.failureReport("Press the 'Redeem/Checkout' button.", "Failed to click on the 'Redeem/Checkout' button.");
		}
		
		Thread.sleep(high);
		
	 	System.out.println("Review ===>>>"+getText(By.xpath("//div[@class='current']"),""));
		
		if(getText(By.xpath("//div[@class='current']"),"").contains("REVIEW & SUBMIT")){
			Reporters.SuccessReport("Verify User is taken to the Review/Submit page. ", "User is Successfully taken to the Review/Submit page.");   
		}else{ 
			Reporters.failureReport("Verify User is taken to the Review/Submit page. ", "User is Failed to taken to the Review/Submit page."); 
		}

		click(ElsevierObjects.Student_accept_chk, "");

		click(ElsevierObjects.evolveInstructorChk, "");

		click(ElsevierObjects.submitbutton, "");
		
		Thread.sleep(veryhigh);
		
		System.out.println("Confirmations ===>>>"+getText(By.xpath("//div[@class='current']"),""));
		
		if(getText(By.xpath("//div[@class='current']"),"").contains("CONFIRMATION")){
			Reporters.SuccessReport("Verify User is taken to a receipt page and an order number is given.", "User is Successfully taken to a receipt page and an order number is given.");  
		}else{ 
			Reporters.failureReport("Verify User is taken to a receipt page and an order number is given.", "User is failed to taken to a receipt page and an order number is given.");      
		}
	}catch(Exception e){sgErrMsg=e.getMessage();
		System.out.println(e);
	}

	}
	
	public void searchAdoptionRequest(boolean pedingStatus) throws Throwable{
		try{
		click(ElsevierObjects.Admin_Evolve_Link, "");
		Thread.sleep(medium);
		LO_GlobalStudent_8571.EMAIL_ID ="dpriya@evolveqa.info";
		Z_Create_LO_Unique_Course_15583.searchAdoptionRequest();
		
		ManualUniqueCourseFulfillment_10436.verifyAdoptionRequestDetails();
		
		
		if(pedingStatus){
			String status=getText(ElsevierObjects.lststaus, "Status");
			System.out.println(status);
			selectByValue(ElsevierObjects.lststaus, "5", "");
			
			Thread.sleep(medium);
			click(ElsevierObjects.btnbottomsave, "");
			Thread.sleep(medium);
			click(ElsevierObjects.emailPopup, "");
		}else{
			if(click(ElsevierObjects.GENERATE_COURSE_ID, "")){
				Reporters.SuccessReport("Click the 'Generate Course IDs' button", "Successfully clicked on the Generate Course ID button");
			}else{
				Reporters.failureReport("Click the 'Generate Course IDs' button", "Failed to click on the Generate Course ID button");
			}
			
			EvolveCommonBussinessFunctions.courseID1 = getText(ElsevierObjects.COURSE_ID_TEXT, "");
			
			if(!EvolveCommonBussinessFunctions.courseID1.equalsIgnoreCase("")){
				Reporters.SuccessReport("Verify Course Id", "Successfully displays the unique course id in Small Pop up. : "+EvolveCommonBussinessFunctions.courseID1);
			}else{
				Reporters.failureReport("Verify Course Id", "Unable to dispaly the Course id in Small Pop up.");
			}
		}
		
		User_BusinessFunction.adminLogout();
		}catch(Exception e){sgErrMsg=e.getMessage();
		System.out.println(e);
	}
	}
	
	public void manageCoursePage(String courseId) throws Throwable{
		try{
		Thread.sleep(medium);
		click(ElsevierObjects.Ecert_Admin_MyAcc, "");
		Thread.sleep(medium);
		click(ElsevierObjects.Ecert_Admin_PortalLink,"");
		Thread.sleep(medium);
		
		click(ElsevierObjects.COURSE_ADMIN_COURSE_LINK, "");
		
		click(ElsevierObjects.ADD_COURSE_BUTTON, "");
		
		if(isElementPresent(By.xpath("//*[@id='stdHeader']/h1"),"")){
			Reporters.SuccessReport("Verify User is brought to a screen where a new course can be created.  Screen labeled: Add Group ", "User is Successfully brought to a screen where a new course can be created.  Screen labeled: Add Group ");
		}else{
			Reporters.failureReport("Verify User is brought to a screen where a new course can be created.  Screen labeled: Add Group ", "User is Failed to brought to a screen where a new course can be created.  Screen labeled: Add Group ");
		}
		
		
		if(type(ElsevierObjects.GROUP_Id, courseId, "")){
			Reporters.SuccessReport("Enter Course ID", "Successfully entered course ID : "+courseId);
		}else{
			Reporters.failureReport("Enter Course ID", "Failed to enter course ID : "+courseId);
		}
		
		if(type(ElsevierObjects.GROUP_NAME, "Automation "+courseId, "")){
			Reporters.SuccessReport("Enter Name as Automation(+unique generated ID)", "Successfully entered Name as : Automation "+courseId);
		}else{
			Reporters.failureReport("Enter Name as Automation(+unique generated ID)", "Failed to enter Name as : Automation "+courseId);
		}
		
		click(ElsevierObjects.GROUP_ADD_LIB, "");
		
		if(type(ElsevierObjects.GROUP_LIB,"Shiland3e_OC_v1" ,"")){
			Reporters.SuccessReport("Enter Shiland3e_OC_v1 into Add Libraries field.", "Successfully entered Shiland3e_OC_v1 into Add Libraries field.");
		}else{
			Reporters.failureReport("Enter Shiland3e_OC_v1 into Add Libraries field.", "Failed to enter Shiland3e_OC_v1 into Add Libraries field.");
		}
		
		if(selectByValue(ElsevierObjects.GROUP_SYSTEM,"10008364", "")){
			Reporters.SuccessReport("Select System as Evolve for the Integration and hit Submit", "Successfully selected System as Evolve for the Integration and hit Submit");
		}else{
			Reporters.failureReport("Select System as Evolve for the Integration and hit Submit", "Failed to select System as Evolve for the Integration and hit Submit");
		}
		
		click(ElsevierObjects.SUBMIT_BUTTON, "");
		
		// changed sleep time from medium (3000) to 20000
		Thread.sleep(20000);
		
		if(isElementPresent(By.xpath("//*[@id='stdHeader']/h1"),"")){
			Reporters.SuccessReport("Verify User is taken to Manage Course screen.", "User is Successfully taken to Manage Course screen.");
		}else{
			Reporters.failureReport("Verify User is taken to Manage Course screen.", "User is failed to taken to Manage Course screen.");
		}
		
		type(ElsevierObjects.SEARCH_BOX, courseId, "");
		Thread.sleep(medium);
		if(isElementPresent(By.xpath("//*[@id='groupTable']//td[text()='"+courseId+"']"), "")){
			Reporters.SuccessReport("Verify course id displays in search results if entered into search field.", "course id displays in search results <br> The course id is : "+courseId);
		}
		else{
			Reporters.failureReport("Verify course id displays in search results if entered into search field.", "course id is not displays in search results");
		}
		}catch(Exception e){sgErrMsg=e.getMessage();
		System.out.println(e);
	}
	}
	
	public void verifyProductTitle(String courseId)throws Throwable{
		try{
		Thread.sleep(high);
		if(isElementPresent(By.xpath("//span[text()='COURSE ID: "+courseId+"']"), "")){
			Reporters.SuccessReport("Verify New Created Course Id", "User was able to see the new the newly fulfilled "+courseId+" link for the unique course in the content list");
			Reporters.SuccessReport("Verify the Course id and title of course", "The title of course matches with mentioned while course added course in Portal admin");
		}else{
			Reporters.failureReport("Verify New Created Course Id", "User was unable to see the new the newly fulfilled "+courseId+" link for the unique course in the content list");
		}
		
		if(click(By.xpath("//a[@href='/cs/course/"+courseId+"']"), "")){
			Reporters.SuccessReport("Click on the content list link for this course ID.", "Successfully clicked on the content list link for this course ID.");
		}else{
			Reporters.failureReport("Click on the content list link for this course ID.", "Failed to click on the content list link for this course ID.");
		}
		
		Thread.sleep(100000);
		
		if(isElementPresent(By.xpath("//span[text()='Course']"),"")){
			Reporters.SuccessReport("Verify Title", "left hand content menu has a library folder titled Course.  ");
		}else{
			Reporters.failureReport("Verify Title", "left hand content menu does not have a library folder titled Course.  ");
		}
		
		if(isElementPresent(By.xpath("//*[@id='course-sidebar']/ul[2]/li[1]/a/span[1]/i"), "")){
			Reporters.SuccessReport("Verify Lock Icon", "The Course link has a lock icon next to it");
		}else{
			Reporters.failureReport("Verify Lock Icon", "The Course link does not have a lock icon next to it");
		}
		
		
		
		if(click(By.xpath("//span[text()='Course']"), "")){
			Reporters.SuccessReport("Click on the Course library folder.", "Successfully clicked on the Course Library folder");
		}else{
			Reporters.failureReport("Click on the Course library folder.", "Failed to click on the Course Library folder");
		}
		
		Thread.sleep(medium);
		
		if(isElementPresent(By.xpath("//*[@id='course-sidebar']//span[text()='Course Orientation']"), "")){
			Reporters.SuccessReport("Verify Sub folders", "The folders Successfully dispalys the Sub folders");
		}else{
			Reporters.failureReport("Verify Sub folders", "The folders was unable to dispaly the Sub folders");
		}

		if(click(ElsevierObjects.Ecert_Admin_ContentHome, "Click on the Content Home Link")){
			Reporters.SuccessReport("Click on the link titled 'Content Home'", "Successfully clicked on the link titled 'Content Home'");
		}else{
			Reporters.failureReport("Click on the link titled 'Content Home'", "Failed to click on the link titled 'Content Home'");
		}
		
		ImplicitWait();
		
		List<WebElement> editList  = driver.findElements(By.xpath("//a[text()='Edit  ']"));
		editList.get(0).click();
		if(editList.get(0)!=null){
			Reporters.SuccessReport("In the main window of the page click on the 'Edit' button on the 'Courses' folder.", "In the main window of the page successfully clicked on the 'Edit' button on the 'Courses' folder.");
		}else{
			Reporters.failureReport("In the main window of the page click on the 'Edit' button on the 'Courses' folder.", "In the main window of the page failed to click on the 'Edit' button on the 'Courses' folder.");
		}
		Thread.sleep(medium);
		
		if(click(By.xpath("//span[text()='About']"),"")){
			Reporters.SuccessReport("Choose 'About' from the options. ", "Successfully Choosen 'About' from the options. ");
		}else{
			Reporters.failureReport("Choose 'About' from the options. ", "Failed to Choose 'About' from the options. ");
		}
	
		/*List<WebElement> aboutList  = driver.findElements(By.xpath("//span[text()='About']"));
		aboutList.get(0).click();
		Thread.sleep(medium);
		*/
		Thread.sleep(medium);
		String protectionSchemeText=getText(ElsevierObjects.Ecert_Admin_ProtectionSchemeID, "Protection scheme text.");
		Thread.sleep(medium);
		System.out.println("Text===>>>>>"+protectionSchemeText);
		/*String pageLink=getText(ElsevierObjects.aboutLinkPage, "");
		if(pageLink!=null){
			Reporters.SuccessReport("User will be displayed a pop up titled About Link with info on the content. ", "User is Successfully taken to the pop up titled : "+pageLink+" with info on the content." );	
		}else{
			Reporters.failureReport("User will be displayed a pop up titled About Link with info on the content. ", "User is Failed to taken to the pop up titled : About Link with info on the content." );
		}*/
		
		//Reporters.SuccessReport("Protection Scheme Displayed on the About Link", "The Protection Scheme Displayed on the About Link is : " +protectionSchemeText);
		protectionSchemeID=protectionSchemeText.split("\\(")[1].replaceAll("\\)", "");
		Thread.sleep(medium);
		System.out.println(protectionSchemeID);
		Reporters.SuccessReport("Protection Scheme saved for future test case", "The Protection Scheme is Successfully saved for future Test cases is : " +protectionSchemeText);
		
		if(click(By.xpath(".//div[@class='modal-footer']/a"),"")){
			Reporters.SuccessReport("Close 'About' popup. ", "Successfully closed the 'About' popup window. ");
		}
		else{
			Reporters.failureReport("Close 'About' popup. ", "Failed to close the 'About' popup window. ");
		}
		
		instructorLogout();
		//String protectionSchemeText=getText(By.xpath("//dd[@data-ng-show='aboutingContent.protectionScheme']"), "Protection scheme text.");
		
		//Reporters.SuccessReport("The Protection Scheme Text", "The Protection Scheme Text is : " +protectionSchemeText);
		//String protectionSchemeID=protectionSchemeText.split("\\(")[1].replaceAll("\\)", "");
		}catch(Exception e){sgErrMsg=e.getMessage();
		System.out.println(e);
	}
		}
}
