package com.cigniti.automation.BusinessFunctions;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class ECommercePreorderALaCarteFaculty1_15459 extends EComm_Preorder_MyEvolve_Page_15452_Bussiness_Functions{
	public static  int count;
	public static int count1;


	public static void InstitutionDetails(String country,String state,String city,String institute,String street,String Zip,String mobile,String program) throws Throwable{
		try{
			selectByVisibleText(ElsevierObjects.Hesi_Student_country,country,"Enter Institute country");
			Thread.sleep(4000);
			selectByVisibleText(ElsevierObjects.Hesi_Student_state,state,"Enter Institution state");
			Thread.sleep(4000);
			driver.findElement(ElsevierObjects.Hesi_Student_City).sendKeys(city);
			driver.findElement(ElsevierObjects.Hesi_Student_City).sendKeys(Keys.ENTER);
			Thread.sleep(4000);
			type(ElsevierObjects.Hesi_Student_institute,institute,"Enter institute name");
			Thread.sleep(4000);
			type(ElsevierObjects.User_form_txtAddress1,street, "Get Street Adress1");
			Thread.sleep(4000);
			type(ElsevierObjects.User_form_txtAddPostalCode,Zip, "Enter Postal Code");
			Thread.sleep(4000);
			type(ElsevierObjects.User_form_txtAddPhone,mobile,"Get phone number");
			Thread.sleep(4000);
			selectBySendkeys(ElsevierObjects.User_form_txtddprogramType,program, "Get country of institution.");
			Thread.sleep(2000);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}

	}


	public static boolean searchProduct(String iSBNumber,String button,String date,int row) throws Throwable{
		boolean flag = true;
		//String errorMessage ="";
		try{

			Thread.sleep(4000);
			if(click(ElsevierObjects.catalog, "Click On Catalog Tab")){
				Reporters.SuccessReport("Clicking On Catalog Tab", "Successfully Clicked On Catalog Tab.");
			}
			else{
				Reporters.failureReport("Clicking On Catalog Tab", "Failed To Click On Catalog Tab.");
			}
			Thread.sleep(4000);
			if(type(ElsevierObjects.txtproductsearch, iSBNumber, "Enter ISBN In Search Text Box")){
				Reporters.SuccessReport("Entering ISBN In Search Text Box.", "Successfully Entered ISBN :"+iSBNumber+"");
			}
			else{
				Reporters.failureReport("Entering ISBN In Search Text Box.", "Failed To Enter ISBN :"+iSBNumber);
			}
			Thread.sleep(4000);
			if(click(ElsevierObjects.gobutton, "Click On Go Button")){
				Reporters.SuccessReport("Clicking On Go Button.", "Successfully Clicked On Go Button.");
			}
			else{
				Reporters.failureReport("Clicking On Go Button.", "Failed To Click On Go Button.");
			}
			Thread.sleep(4000);
			if(click(ElsevierObjects.btnaddtocart, "Click On 'add to cart' Button")){
				Reporters.SuccessReport("Clicking On "+button+" Button.", "Successfully Clicked On "+button+" Button.");
			}
			else{
				Reporters.failureReport("Clicking On "+button+" Button.", "FailedTO Click On  "+button+" Button.");
			}
			Thread.sleep(4000);
			try{

				driver.findElement(By.xpath(".//*[@id='pageLayout-body-inner-most']/div//h1[contains(text(),'My Cart')]"));
			}
			catch(Exception e){
				switchToFrameByLocator(ElsevierObjects.Student_register_frame, "Switch to iframe.");
				Thread.sleep(3000);
				click(ElsevierObjects.popUp_Apply, "Click on Apply button.");
				Thread.sleep(3000);
				if(isElementPresent(By.xpath(".//*[@id='pageLayout-body-inner-most']/div//h1[contains(text(),'My Cart')]"), "Get Text My Cart")){
					Reporters.SuccessReport("", "Navigated To My Cart Page.");
				}
			}
			Thread.sleep(4000);
			//if(mssg.equalsIgnoreCase("true")){
			String price=getText(By.xpath(".//*[@id='"+iSBNumber+"']//following-sibling::div[@class='price span2']"),"");

			ReadingExcel.updateCellInSheet(row, 1, testDataPath, "TC-15597_PriceValues", price);;
			//Changing Publication Date Format To Compare date in Evolve.

			String s=date;
			SimpleDateFormat ft = new SimpleDateFormat("MM-dd-yyyy");
			Date d1=new SimpleDateFormat("yyyyMMdd").parse(s);
			String verifydate=ft.format(d1);
			System.out.println(ft.format(d1));

			try{
				String message = getText(By.xpath("//*[@id='"+iSBNumber+"']/div[8]"), "");
				if((message !=null )&& message.contains("To review your order at any time")){
					if(message.contains(verifydate)){
						Reporters.SuccessReport("Verifying Notification Message In MyCart Page.", "Verified Notification Message For ISBN: "+iSBNumber+" And Notification Message is :"+message+".</br>Verified publication date : "+verifydate+" in Notification Message.");
					}
					else
					{
						Reporters.failureReport("Verifying Notification Message In MyCart Page", "Failed To Verify Notification Message.");
					}
				}
			}
			catch(Exception e){
				sgErrMsg=e.getMessage();return false;
			}
		}
		catch(Exception e){
			sgErrMsg =e.getMessage();return false;
		}
		//	finally{
		//		if(flag){
		//			Reporters.SuccessReport("Verify Notification Message", getText(By.xpath("//*[@id='"+iSBNumber+"']/div[8]"),""));
		//		}else{
		//			Reporters.failureReport("Verify Notification Message", "Unable to display Message Reason"+errorMessage);
		//		}
		//	}
		return flag;
	}

	public static boolean Checkout() throws Throwable{
		boolean flag=true;
		try{
			if(click(ElsevierObjects.btnRedeem,"Click on My Cart checkout Button")){
				Reporters.SuccessReport("Clicking On Checkout Button in My cart Page.", "Successfully Clicked On Checkout Button In My cart Page.</br>User Is Navigated To Update Account Page.");
			}
			else{
				Reporters.failureReport("Clicking On Checkout Button in My cart Page.", "Failed To Click On Checkout Button In My cart Page.</br>Failed To Navigate To Update Account Page.");
			}
			Thread.sleep(2000);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	/*public static boolean fetchOrderNumberInReceiptPage(String ISBNInOrderPage) throws Throwable{
	boolean flag=true;
	try{
			Thread.sleep(300);
			String TotalISBNs=driver.findElement(By.xpath(".//div[@class='cartproductdetails']")).getText();
			String ordernumber1=driver.findElement(By.xpath(".//div[@class='sidebar-list rounded']//h4/following-sibling::div")).getText();
			Thread.sleep(200);
			if(TotalISBNs.contains(ISBNInOrderPage))
			{
				Reporters.SuccessReport("Verifying Orders in Receipt Page.", "ISBN is present in the Current order Number:" +ordernumber1+" And ISBN details are"+ISBNInOrderPage);
			}
			else{
				Reporters.failureReport("Verifying Orders in Receipt Page.", "Failed To Fetch The Order Details From Order History Page.");
			}
		}
		catch(Exception e12){
			sgErrMsg=e12.getMessage();
		}
	return flag;
}*/
	public static boolean checkApprovedstatus(String title1,String title2) throws Throwable {
		boolean flag=true;

		try{



			String firstProductTitle=getText(By.xpath(".//div[contains(text(),'"+title1+"')]"),"");

			if(title1.contains(firstProductTitle)){
				Reporters.SuccessReport("Verifying Title in  Adoption Search Results Page.", "Successfully Verified Title :"+title1+" in Adoption Search Results Page.");
			}
			else{
				Reporters.failureReport("Verifying Title in  Adoption Search Results Page.", "Failed To Verify Title in  Adoption Search Results Page.");
			}
			Thread.sleep(2000);

			Thread.sleep(8000);
			String secondProductTitle=getText(By.xpath(".//div[contains(text(),'"+title2+"')]"),"");

			if(title2.contains(secondProductTitle)){
				Reporters.SuccessReport("Verifying Title in  Adoption Search Results Page.", "Successfully Verified Title :"+title2+" in Adoption Search Results Page.");
			}
			else{
				Reporters.failureReport("Verifying Title in  Adoption Search Results Page.", "Failed To Verify Title in  Adoption Search Results Page.");
			}

			Thread.sleep(2000);

			click(By.xpath(".//*[@id='pageBody']/table/tbody//table[@id='resultTable']/tbody/tr[1]//span/input[@name='chkbxFulfil']"),"");


			if(click(ElsevierObjects.Admin_Submit_btn,"submit button click")){
				Reporters.SuccessReport("Clicking On Submit Button After Checking Approve And FulFill Check boxes.", "SucessFully Clicked On Submit Button After Clicking Checking Approve And FulFill Check boxes.");
			}
			else{
				Reporters.failureReport("Clicking On Submit Button After Checking Approve And FulFill Check boxes.","Failed To Click On Submit Button." );
			}

			click(By.xpath(".//*[@id='pageBody']/table/tbody//table[@id='resultTable']/tbody/tr[2]//span/input[@name='chkbxFulfil']"),"");

			if(click(ElsevierObjects.Admin_Submit_btn,"submit button click")){
				Reporters.SuccessReport("Clicking On Submit Button After Checking Approve And FulFill Check boxes.", "SucessFully Clicked On Submit Button After Clicking Checking Approve And FulFill Check boxes.");
			}
			else{
				Reporters.failureReport("Clicking On Submit Button After Checking Approve And FulFill Check boxes.","Failed To Click On Submit Button." );
			}
			if(!(driver.getPageSource()).contains("Approved"))
			{
				Reporters.SuccessReport("Verifying Both The Adoptions are fulfilled Or Not.","Both The Adoptions Are Fulfilled Successfully.");

			}
			else 
			{
				Reporters.failureReport("Verifying Both The Adoptions are fulfilled Or Not.","Only One Of the Adoptions is in Fulfilled state.");
			}


			Thread.sleep(8000);
		}
		catch(Exception e12){
			sgErrMsg=e12.getMessage();
		}
		return flag;
	}
	public static boolean Adoptionsearch(String username) throws Throwable{

		boolean flag=true;
		try{
			if(click(ElsevierObjects.searchAR,"Adoption Requests")){
				Reporters.SuccessReport("Clicking On Search Adoption Requests.", "Successfully Clicked On Search Adoption Request Link.");
			}
			else{
				Reporters.failureReport("Clicking On Search Adoption Requests.", "Failed To Click On Search Adoption Request Link.");
			}
			if(!waitForElementPresent(ElsevierObjects.btndatesearch, "search button")){
				flag = false;
			}
			/*if(click(ElsevierObjects.rbtndate, "date Radio button")){
				Reporters.SuccessReport("Clicking On Todays Radio Button.", "Successfully Clicked On Todays Radio Button.");
			}
			else{
				Reporters.failureReport("Clicking On Todays Radio Button.", "Failed Clicked On Todays Radio Button.");
			}
			*/
			Thread.sleep(3000);
			selectByVisibleText(ElsevierObjects.btndatesearch_AR, "Today", "TodayDate");
			Thread.sleep(3000);
			if(type(ElsevierObjects.Adoption_userId,username , "Adoption search User Id")){
				Reporters.SuccessReport("Entering UserID In Search Results Page..", "Successfully Entered UserID:"+getAccountDetailsUserName);
			}
			else{
				Reporters.failureReport("Entering UserID In Search Results Page..", "Failed Enter UserID:"+getAccountDetailsUserName);
			}


			if(click(ElsevierObjects.Searchon, "search button")){
				Reporters.SuccessReport("Clicking On Search Button In  Search Adoption Requests Page.", "Successfully Clicked On Search Button In Clicking On Search Button In  Search Adoption Requests Page.</br>Navigated To Adoption Search Results Page.");
			}
			else{
				Reporters.failureReport("Clicking On Search Button In  Search Adoption Requests Page.", "Failed To Click On Search Button In Clicking On Search Button In  Search Adoption Requests Page.");
			}
			Thread.sleep(3000);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	public static void verifyTitles(String OnlineTitle,String ResourceTitle) throws Throwable{

		if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
			flag=false;
		}
		Thread.sleep(4000);
		if(!click(ElsevierObjects.Kno_refresh_lnk,"Click on refresh link in evolve page")){
			flag=false;
		}
		Thread.sleep(4000);

		ArrayList<String> titles=new ArrayList<String>();
		titles.add(OnlineTitle);
		titles.add(ResourceTitle);


		for(String title : titles){

			String onlinecoursetitle=getText(By.xpath("//*[@id='set']/li[@class='set setclosed  ']/div/div/a[contains(text(),'"+title+"')]"),"");

			if(onlinecoursetitle.contains(title)){
				Reporters.SuccessReport("Verifying there is Course link.", "Successfully Verified Course Link Title in My Evolve Page: "+onlinecoursetitle);
			}else{
				Reporters.failureReport("Verifying there is Course link.", "Failed to Verify Course Link Title in My Evolve Page: "+onlinecoursetitle);
			}
			Thread.sleep(4000);
			if(click(By.xpath("//*[@id='set']/li[@class='set setclosed  ']/div/div/a[contains(text(),'"+title+"')]"), "Click On Course Link.")){
				Reporters.SuccessReport("Clicking On is Course link.", "Successfully Clicked On Course Link Title in My Evolve Page: "+onlinecoursetitle+" </br> Navigated To Course details Page.");
			}else{
				Reporters.failureReport("Clicking On is Course link.", "Failed to Click On Course Link Title in My Evolve Page: "+onlinecoursetitle);
			}
			//Thread.sleep(4000);
			//driver.manage().timeouts().implicitlyWait(600, TimeUnit.SECONDS);
			Thread.sleep(60000);

			if(click(ElsevierObjects.educator_Course_Resource, "Click on Resource link present in course details page.")){
				Reporters.SuccessReport("Clicking On Resource Link.", "Clicked On Resource Link In content menu.");
			}
			else{
				Reporters.failureReport("Clicking On Resource Link.", "Failed To Click On Resource Link In content menu.");
			}

			List<WebElement> s=driver.findElements(ElsevierObjects.educator_CoursePage_SubFolders);
			for(WebElement subFolder:s){
				if(waitForElementPresent(ElsevierObjects.educator_CoursePage_SubFolders, "Course folder contains sub folders.")){
					Reporters.SuccessReport("Verifying subFolders.", "Verified SubFolders of Resource Folder.</br>SubFolder is:"+subFolder.getText());
				}
				else{
					Reporters.failureReport("Verifying subFolders.", "Failed To Verify SubFolders of Resource Folder.");
				}
			}
			Thread.sleep(3000);
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}

		}
	}
	public static boolean ordersVerificationInEmailBody(String Order1,String Order2,String Order3) throws Throwable{
		boolean flag=true;


		try{

			switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
			Thread.sleep(3000);
			String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");

			if(emailBody.trim().contains(Order1.trim()) && emailBody.trim().contains(Order2.trim())&& emailBody.trim().contains(Order3.trim())){
				System.out.println("Check user details in email.");
				driver.switchTo().defaultContent();
				if(click(ElsevierObjects.email_logout,"Click on logout.")){

					Reporters.SuccessReport("Verifying Order details In Email Body.</br>Clicking On Logout Button.","Successfully Verified Order1: "+Order1+"</br>Order2: "+Order2+"</br>Order3: "+Order3+"</br></br>Email Body Is: "+emailBody+"</br></br>Successfully Clicked On Logout Button.");
				}
				else{
					Reporters.failureReport("Verifying Order details In Email Body.</br>Clicking On Logout Button.", "Failed To Verify Order Details </br>Order1: "+Order1+"</br>Order2: "+Order2+"</br>Order3: "+Order3+"</br>Failed To Click On Logout Button.  Email Body Is: "+emailBody+"</br>");
				}
				Thread.sleep(3000);
			}
			else{
				Reporters.failureReport("Verifying Order details In Email Body.", "Failed To Verify Order Details in Email Body.");
			}
		}

		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	public static boolean fetchOrderNumberInReceiptPage(String ISBN1) throws Throwable{
		boolean flag=true;
		try{
			driver.navigate().refresh();
			//String ISBN1_total=ISBN1;
			List<WebElement> totalrows=driver.findElements(By.xpath(".//div[@class='row']"));
			int index=0;
			//int flag_ver=0;
			Thread.sleep(100);
			List<WebElement> totalordetrs=driver.findElements(By.xpath(".//div[@class='sidebar-list rounded']//h4/following-sibling::div"));
			int orderlist=totalordetrs.size();

			if(orderlist>=3){
				ordernumber1=totalrows.get(1).findElement(By.xpath(".//div[@class='sidebar-list rounded']//h4/following-sibling::div")).getText();		
				//ReadingExcel.updateCellInSheet(rowNumber, columnNumber, path, sheetName, cellValueToUpdate);
				List<WebElement> TotalISBNs=totalrows.get(1).findElements(By.xpath(".//div[@class='cartproductdetails']"));
				String [] stringParts = ISBN1.split(",");

				count=0;
				for(int b=0;b<stringParts.length;b++)
				{
					for(int a=0;a<TotalISBNs.size();a++)
					{

						String Temp=TotalISBNs.get(a).getText();

						String expectedvalue=stringParts[b];
						if(Temp.contains(expectedvalue))
						{
							ReadingExcel.updateCellInSheet(a+1, 1, testDataPath, "TC_15459_Orders", ordernumber1);
							ReadingExcel.updateCellInSheet(a+1, 0, testDataPath, "TC_15459_Orders", expectedvalue);
							count++;
							Reporters.SuccessReport("Verifying ISBN's in the Current order in Sequence:"+a, "ISBN's are present in the Current order Number:" +ordernumber1+" And ISBN details are"+Temp);
							//	flag_ver=1;
							break;
						}
						else
						{
							ISBN1=expectedvalue+",";
							//  flag_ver=0;
						}
					}
				}
				//if(flag_ver==1)
				try{

					Thread.sleep(200);
					//stringParts = ISBN1.split(",");
					ordernumber2=totalrows.get(2).findElement(By.xpath(".//div[@class='sidebar-list rounded']//h4/following-sibling::div")).getText();		
					count1=count;
					List<WebElement> TotalISBNs1=totalrows.get(2).findElements(By.xpath(".//div[@class='cartproductdetails']"));
					for(int b=0;b<stringParts.length;b++)
					{

						for(int a=0;a<TotalISBNs1.size();a++)
						{

							String Temp=TotalISBNs1.get(a).getText();
							String expectedvalue=stringParts[b];
							if(Temp.contains(expectedvalue))
							{
								index=a+1;
								ReadingExcel.updateCellInSheet(count+1, 1, testDataPath, "TC_15459_Orders", ordernumber2);
								ReadingExcel.updateCellInSheet(count+1, 0, testDataPath, "TC_15459_Orders", expectedvalue);
								count1++;
								Reporters.SuccessReport("Verifying ISBN's in the Current order in Sequence:"+a, "ISBN's are present in the Current order Number:" +ordernumber2+" And ISBN details are"+Temp);
								//flag_ver=1;
							}
							else
							{
								ISBN1=expectedvalue+",";
								//	flag_ver=0;
							}
						}
					}


				}
				catch(Exception e){
					sgErrMsg=e.getMessage();
				}

				//	if(flag_ver==1)
				try
				{
					Thread.sleep(200);
					//stringParts = ISBN1.split(",");
					ordernumber3=totalrows.get(3).findElement(By.xpath(".//div[@class='sidebar-list rounded']//h4/following-sibling::div")).getText();		
					List<WebElement> TotalISBNs2=totalrows.get(3).findElements(By.xpath(".//div[@class='cartproductdetails']"));
					for(int b=0;b<stringParts.length;b++)
					{

						for(int a=0;a<TotalISBNs2.size();a++)
						{	
							String Temp=TotalISBNs2.get(a).getText();
							String expectedvalue=stringParts[b];
							if(Temp.contains(expectedvalue))
							{
								index=a+1;
								ReadingExcel.updateCellInSheet(count1+1, 1, testDataPath, "TC_15459_Orders", ordernumber3);
								ReadingExcel.updateCellInSheet(count1+1, 0, testDataPath, "TC_15459_Orders", expectedvalue);
								Reporters.SuccessReport("Verifying ISBN's in the Current order in Sequence in Receipt Page:"+a, "ISBN's are present in the Current order Number:" +ordernumber3+" And ISBN details are"+Temp);
								//	flag_ver=1;
								break;
							}
							else
							{
								ISBN1=expectedvalue+",";
								//	flag_ver=0;
							}
						}
					}
				}
				catch(Exception e11){
					sgErrMsg=e11.getMessage();
				}
				Thread.sleep(200);
				/*if(ISBN1_total.contains(ISBN1))
			{

			//if(flag_ver==1)
			{
				Reporters.failureReport("ISBN or not present or Oder not splited in to three orders", "One of the ISBN is not present or"+ISBN1);

			}
			}*/		

			}
			else{
				Reporters.failureReport("Verifying Orders in Receipt Page.", "Number Of Orders Are Less Than three. ISze Of Orders List Is :"+orderlist);
			}


		}
		catch(Exception e12){
			sgErrMsg=e12.getMessage();
		}

		return flag;
	}

}


