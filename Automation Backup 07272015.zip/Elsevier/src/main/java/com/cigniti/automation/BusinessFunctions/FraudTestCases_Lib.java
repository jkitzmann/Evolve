package com.cigniti.automation.BusinessFunctions;

import java.awt.List;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Actiondriver;

public class FraudTestCases_Lib extends Actiondriver{

	public final static String[] credentials={"",""};
	public static Map<String, String> tcVST_KNO=readcolumns.twoColumnsBasedOnSheetName(0, 1, "createNewaccount", configProps.getProperty("TestData"));
	public static String StdEmail;

	/**
	 * 
	 * @param user
	 * @param fName
	 * @param lName
	 * @param email
	 * @param password
	 * @return
	 * @throws Throwable
	 */
	public static boolean createNewUser(String user, String fName, String lName, String email, String password) throws Throwable{
		boolean flag = true;
		try{
			driver.manage().deleteAllCookies();
			//Thread.sleep(medium);
			if(launchUrl(configProps.getProperty("URL"))){
				Reporters.SuccessReport("Launch the URL "+configProps.getProperty("URL"), "Successfully Launched URL "+configProps.getProperty("URL"));
			}else{
				Reporters.failureReport("Launch the URL "+configProps.getProperty("URL"), "Failed to Launch URL "+configProps.getProperty("URL"));
			}
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();

			/*if(!clickOnMainPageLink()){
					flag=false;
				}
			 */
			if(user.equalsIgnoreCase("educator")){ 

				if(click(ElsevierObjects.evolve_createNewUser,"Create new account")){
					Reporters.SuccessReport("Click on Create new account link", "Successfully Clicked on Create new account link");
				}else{
					Reporters.failureReport("Click on Create new account link", "Failed to Click on Create new account link");
				}
				if(!switchToFrameByLocator(ElsevierObjects.evolve_newAcount_frame,"Switch to frame")){
					flag=false;
				}

				if(!click(ElsevierObjects.faculty_radio_btn,"Faculty radio button")){
					flag=false;
				}
				verifyRegistrationElements();
				registrationForm(fName, lName, email, password);
			}else{
				if(!javaClick(ElsevierObjects.evolve_createNewUser,"Create new account")){
					Reporters.failureReport("Click on Create an account link", "Failed to click on Create an account link");}
				else{
					Reporters.SuccessReport("Click on Create an account link", "Succcessfully clicked on Create an account link");
				}

				if(isElementPresent1(ElsevierObjects.evolve_newAcount_frame, "Create Account popup"))
					if(!switchToFrameByLocator(ElsevierObjects.evolve_newAcount_frame,"Switch to frame")){
						flag=false;
					}

				if(isChecked(ElsevierObjects.createNewAccnt_studentRadioBtn, "Student Radio button")){
					Reporters.SuccessReport(" Verify status of Student radio button", "Student Radio button is selected by default");
				}
				verifyRegistrationElements();
				registrationForm(fName, lName, email, password);
			}
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}




	/**
	 * 
	 * @throws Throwable
	 */
	public static void verifyRegistrationElements() throws Throwable{
		boolean flag = true;
		try{


			if(!isElementPresent(ElsevierObjects.evolve_newAccount_firstname)){
				flag = false;
			}

			if(!isElementPresent(ElsevierObjects.evolve_newAcount_Lastname)){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.evolve_newAcount_Email)){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.evolve_newAcount_Pwd)){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.evolve_newAcount_ConfirmPwd)){
				flag = false;
			}

			if(flag){
				Reporters.SuccessReport("Verify there are text fields for First Name, Last Name, Email Address, Password & Confirm Password", "All text fields for First Name, Last Name, Email Address, Password & Confirm Password are present");
			}else{
				Reporters.failureReport("Verify there are text fields for First Name, Last Name, Email Address, Password & Confirm Password", "Text fields for First Name, Last Name, Email Address, Password & Confirm Password are not present");
			}

			if(isChecked(ElsevierObjects.evolve_newAcount_Chkbx, "Promotional offers Checkbox")){

				Reporters.SuccessReport("Verify if Promotion checkbox is checked by default", "YES, I wish to receive special offers and promotions from Elsevier Inc. about relevant products or services checkbox is already checked");
			}


			if(isEnabled(ElsevierObjects.evolve_newAcount_Submit_btn,"")){
				Reporters.SuccessReport("Verify the submit button is enabled or not", "Submit button is enabled");
			}else{
				Reporters.failureReport("Verify the submit button is enabled or not", "Submit button is not enabled");
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}
	//New Registration form for Both FACULTY And STUDENT
	/**
	 * 
	 * @param fName
	 * @param lName
	 * @param email
	 * @param password
	 * @return
	 * @throws Throwable
	 */
	public static boolean registrationForm(String fName, String lName, String email, String password) throws Throwable{
		stepReport("Fill the registration form");
		boolean flag = true;
		try{
			if(!type(ElsevierObjects.evolve_newAccount_firstname,fName/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_firstname")*/,"First Name")){
				flag=false;
			}
			if(!type(ElsevierObjects.evolve_newAcount_Lastname,lName/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_lastname")*/,"Last Name")){
				flag=false;
			}
			Random ra = new Random( System.currentTimeMillis() );
			Date today = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat ("MMddyyyy");
			StdEmail = email/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_email")*/+Integer.toString((1 + ra.nextInt(2)) * 10000 + ra.nextInt(10000)) + sdf.format(today) + "@evolveqa.info";


			//ReadingExcel.updateCellValue(3, 1, configProps.getProperty("TestData"), 15);
			if(!type(ElsevierObjects.evolve_newAcount_Email, StdEmail ,"Email")){
				flag=false;
			}
			if(!type(ElsevierObjects.evolve_newAcount_Pwd, password/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_pwd")*/,"Password")){
				flag=false;
			}
			if(!type(ElsevierObjects.evolve_newAcount_ConfirmPwd, password/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_pwd")*/,"Confirm Password")){
				flag=false;
			}
			String sEnteredFirstName=driver.findElement(ElsevierObjects.evolve_newAccount_firstname).getAttribute("value");
			String sEnteredLastName=driver.findElement(ElsevierObjects.evolve_newAcount_Lastname).getAttribute("value");
			String sEnteredemail=driver.findElement(ElsevierObjects.evolve_newAcount_Email).getAttribute("value");
			String sEnteredpwd=driver.findElement(ElsevierObjects.evolve_newAcount_Pwd).getAttribute("value");

			if(flag){
				Reporters.SuccessReport("Enter the required values", "Successfully entered all the values. The values entered are <br> First Name: "+sEnteredFirstName+"<br> Last Name: "+sEnteredLastName+"<br> Email address: "+sEnteredemail+"<br> Password: "+sEnteredpwd);
			}else{
				Reporters.failureReport("Enter the required values", "Failed to enter all the values. The values entered are <br> First Name: "+sEnteredFirstName+"<br> Last Name: "+sEnteredLastName+"<br> Email address: "+sEnteredemail+"<br> Password: "+sEnteredpwd);
			}

			if(isChecked(ElsevierObjects.evolve_newAcount_Chkbx, "Check box")){
				if(click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
					Reporters.SuccessReport("Click on Submit button", "Successfully clicked on Submit button");
				}
				else{
					Reporters.failureReport("Click on Submit button", "Failed to click on Submit button");
				}
				Thread.sleep(high);
			}
			else{
				if(!click(ElsevierObjects.evolve_newAcount_Chkbx,"Click chk box")){
					flag=false;
				}
				if(click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
					Reporters.SuccessReport("Click on Submit button", "Successfully clicked on Submit button");
				}
				else{
					Reporters.failureReport("Click on Submit button", "Failed to click on Submit button");
				}
				Thread.sleep(veryhigh);
			}

			Thread.sleep(medium);
			capturCredentials();

			Thread.sleep(medium);
			if(isElementPresent(ElsevierObjects.newAccount_contiue_btn, "Continue button")){
				Reporters.SuccessReport("Presence of Continue button", "Continue button is present");
			}
			if(click(ElsevierObjects.newAccount_contiue_btn,"Continue button")){
				Reporters.SuccessReport("Click on Continue button", "Successfully clicked on the continue button");
			}
			Thread.sleep(high);

			if(waitForVisibilityOfElement(ElsevierObjects.evolveCatalog, "Home page")){
				Reporters.SuccessReport("Verify Evolve Home page", "Successfully landed on the content list page after clicking on Continue button");
			}
			else{
				Reporters.failureReport("Verify Evolve Home page", "Clicking on continue button didn't take to the content list page");
			}

		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;

	}

	/**
	 * 
	 * @return
	 * @throws Throwable
	 */
	public static String []  capturCredentials() throws Throwable{
		Thread.sleep(high);
		waitForVisibilityOfElement(ElsevierObjects.NonAdmin_UserCredentials, "");
		Thread.sleep(medium);
		String credentialss = driver.findElement(ElsevierObjects.NonAdmin_UserCredentials).getText();

		String[] credentialsArr = credentialss.split("\n");

		String userName = null;
		String password = null;
		for(String credentials : credentialsArr){
			if(credentials.contains("Username:")){
				userName = credentials.replaceAll("Username:", "").trim();
			}
			if(credentials.contains("Password:")){
				password = credentials.replaceAll("Password:", "").trim();
			}    
		}

		credentials[0] =userName;
		credentials[1] =password;
		ReadingExcel.updateCellInSheet(1,5,configProps.getProperty("TestData"), "FraudTestCases", userName);

		ReadingExcel.updateCellInSheet(1,6,configProps.getProperty("TestData"), "FraudTestCases", password);


		if(credentials[0] != null && credentials[1] != null){
			Reporters.SuccessReport("Capture the created credentials", "Successfully created the user with credentials. <br>Username: "+credentials[0]+"<br>Password: "+credentials[1]);
		}
		else{
			Reporters.failureReport("Capture the created credentials", "Failed to create the credentials. <br>Username: "+credentials[0]+"<br>Password: "+credentials[1]);
		}

		return credentialsArr;
	}

	//Logout from the instructor
	/**
	 * 
	 * @return
	 * @throws Throwable
	 */
	public static boolean evolveLogout() throws Throwable{
		boolean flag = true;
		try{
			//Thread.sleep(medium);
			driver.switchTo().defaultContent();
			if(!click(ElsevierObjects.myAccount, "Clicked on My Account")){
				flag = false;
			}
			if(!click(ElsevierObjects.Educator_Logout, "Clicked on logout from Evolve")){
				flag = false;
			}
			Thread.sleep(high);
			return flag;
		}catch(Exception e){
			System.out.println(e.getMessage());
			sgErrMsg=e+" is Failed due to this exception";
			return false;
		}

		finally{
			if(flag)
				Reporters.SuccessReport("Log off from the application", "Successfully logged off from the application");
			else
				Reporters.failureReport("Log off from the application", "Failed to log off from the application");
		}
	}

	/**
	 * @param sUserName
	 * @param sPassword
	 * @throws Throwable
	 */
	public void evolveLogin(String sUserName, String sPassword)
			throws Throwable {
		try {

			waitForVisibilityOfElement(ElsevierObjects.LOGIN, "Login button");
			click(ElsevierObjects.LOGIN, "Click on login");

			if (type(ElsevierObjects.USERNAME_Fraud, sUserName, "Enter username"))
				Reporters.SuccessReport("Enter Username","Successfully entered Username");
			else
				Reporters.failureReport("Enter Username","Failed to enter Username");

			if (type(ElsevierObjects.PASSWORD, sPassword, "Enter password"))
				Reporters.SuccessReport("Enter password","Successfully entered password");
			else
				Reporters.failureReport("Enter password","Failed to enter password");

			if (click(ElsevierObjects.LOGIN_SUBMIT_BUTTON,"click on login button"))
				Reporters.SuccessReport("Click on login button","successfully Click on login button");
			else
				Reporters.failureReport("Click on login button","failure to Click on login button");

			if (isElementPresent(ElsevierObjects.EVOLVE_CATALOG))
				Reporters.SuccessReport("Verify user is able to login or not","successfully logged in as student  <br/> Username:"+ sUserName + " Password:" + sPassword);
			else
				Reporters.failureReport("Verify user is able to login or not","failure to login");

		} catch (Exception e) {

		}
	}

	/**
	 * 
	 * @throws Throwable
	 */
	public static void evolveCatalogClick() throws Throwable{
		try{
			if(javaClick(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
				Reporters.SuccessReport("Click on 'Evolve Catalog' link", "Successfully clicked on the Evolve Catalog link");
			}else{
				Reporters.failureReport("Click on 'Evolve Catalog' link", "Failed to click on Evolve catalog link");
			}

			//String text = getAttribute(By.name("query"), "placeholder", "Search Bar");
			if(isElementPresent(ElsevierObjects.SEARCH_CATALOG)){
				Reporters.SuccessReport("Verify the Evolve catalog screen", "Evolve catalog screen is displayed");
			}else{
				Reporters.failureReport("Verify the Evolve catalog screen", "Evolve catalog screen is not displayed");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	/**
	 * 
	 * @param sISBN
	 * @throws Throwable
	 */
	/*public static void searchAndAddProductFromCatalog(String sISBN) throws Throwable{
		try{
			if(type(ElsevierObjects.SEARCH_CATALOG, sISBN, "search item")){
				Reporters.SuccessReport("Enter the ISBN in search box", "Successfully entered the ISBN : "+sISBN+" into the search box" );
			}else{
				Reporters.failureReport("Enter the ISBN in search box", "Failed to enter the ISBN : "+sISBN+" into the search box" );
			}
			Thread.sleep(low);
			if(click(ElsevierObjects.CATALOG_GO, "Search Item")){
				Reporters.SuccessReport("Click on Go Button", "Successsfully Clicked on the Go Button");
			}else{
				Reporters.failureReport("Click on Go Button", "Faild to Click on the Go Button");
			}
			Thread.sleep(low);
			if(waitForVisibilityOfElement(ElsevierObjects.btnRequest, "Add to cart button"))
				Reporters.SuccessReport("Verify the product page", "Product page of the ISBN "+sISBN+" is displayed");
			else
				Reporters.failureReport("Verify the product page", "Product page of the ISBN is not displayed");

			if(javaClick(ElsevierObjects.btnRequest, "Add to cart button")){
				Reporters.SuccessReport("Click on Add to Cart button", "Successfully clicked on Add to cart button");
			}else{
				Reporters.failureReport("Click on Add to Cart button", "Failed to click on Add to cart button");
			}
			Thread.sleep(2000);
			if(waitForVisibilityOfElement(ElsevierObjects.MyCART, "My Cart page")){
				Reporters.SuccessReport("Verify the My cart page is displayed", "My cart page is displayed");
			}else{
				Reporters.failureReport("Verify the My cart page is displayed", "My cart page is not displayed");
			}
			Thread.sleep(low);
		}catch(Exception e){
			e.printStackTrace();
		}
	}*/

	/**
	 * 
	 * @param sISBN
	 * @throws Throwable
	 */
	public static void validateProductinCart(String sISBN) throws Throwable{
		try{
			if(isElementPresent(By.id(sISBN)))
				Reporters.SuccessReport("Verify ISBN in Cart", "ISBN "+sISBN+" is available in the cart");
			else
				Reporters.failureReport("Verify ISBN in Cart", "ISBN "+sISBN+" is not available in the cart");
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @param sISBN
	 * @throws Throwable
	 */
	public static void comparePriceinCart(String condition, String sISBN, String comparePrice) throws Throwable{
		try{
			String sISBNprice=getText(By.xpath(".//*[@id='"+sISBN+"']//div[@class='price span2']"), "ISBN Price");

			//String sComparePrice=ReadingExcel.columnDataByHeaderName("ISBN1Price", "FraudTestCases", testDataPath);

			float price = convertStringToPrice(sISBNprice);
			int cprice =Integer.parseInt(comparePrice);
			float comprice=cprice;
			//int iISBNPrice=Integer.parseInt(sISBNprice);
			//int iComparePrice=Integer.parseInt(sComparePrice);

			if(condition.equalsIgnoreCase("equals")){
				if(price==comprice)
					Reporters.SuccessReport("Verify price of ISBN is equal to "+comparePrice, "Price of ISBN is equal to "+comparePrice+". <br/> The price is : "+price);
				else
					Reporters.failureReport("Verify price of ISBN is greater than "+comparePrice, "Price of ISBN is not equal to "+comparePrice+". <br/> The price is : "+price);
			}
			else{
				if(price>comprice){
					Reporters.SuccessReport("Verify price of ISBN is greater than "+comparePrice, "Price of ISBN is greater than "+comparePrice+". <br/> The price is : "+price);
				}else{
					Reporters.failureReport("Verify price of ISBN is greater than "+comparePrice, "Price of ISBN is not greater than "+comparePrice+". <br/> The price is : "+price);
				}
			}
			if(condition.equalsIgnoreCase("preorder")){
				String preorderMessage = getText(By.xpath(".//*[@id='"+sISBN+"']//div[@class='notification_box rounded']//span"), "preorder message");
				if(preorderMessage!=null){
					Reporters.SuccessReport("Verify the PreOrder Message", "The Message is Displayed as : <br/> " + preorderMessage);
				}else{
					Reporters.failureReport("Verify the PreOrder Message", "The Message is not Displayed ");
				}
			}
		}
		catch(Exception e){
			System.out.println();
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @param sISBN
	 * @throws Throwable
	 */
	public static void searchAndAddProductFromCartSearch(String sISBN, String sButton) throws Throwable{
		try{
			Thread.sleep(low);
			if(type(ElsevierObjects.SEARCH_CATALOG, sISBN, "Search Box in cart page"))
				Reporters.SuccessReport("Enter the ISBN in search box", "Successfully entered the ISBN in the search box");
			else
				Reporters.failureReport("Enter the ISBN in search box", "Failed to enter the ISBN in the search box");
			Thread.sleep(low);
			if(click(ElsevierObjects.CATALOG_GO, "Search Item")){
				Reporters.SuccessReport("Click on Go Button", "Successsfully Clicked on the Go Button");
			}else{
				Reporters.failureReport("Click on Go Button", "Faild to Click on the Go Button");
			}
			Thread.sleep(low);
			
			if(waitForVisibilityOfElement(ElsevierObjects.btnRequest, "Add to cart button"))
				Reporters.SuccessReport("Verify the product page", "Product page of the ISBN "+sISBN+" is displayed");
			else
				Reporters.failureReport("Verify the product page", "Product page of the ISBN is not displayed");

			Thread.sleep(low);
			
			if(sButton.equalsIgnoreCase("Add to cart")){
				if(javaClick(ElsevierObjects.btnRequest, "Add to cart button"))
					Reporters.SuccessReport("Click on Add to Cart button", "Successfully clicked on Add to cart button");
				else
					Reporters.failureReport("Click on Add to Cart button", "Failed to click on Add to cart button");
			}
			else if(sButton.equalsIgnoreCase("pre-order")){
				if(javaClick(ElsevierObjects.btnPreOrder, "Pre-Order button"))
					Reporters.SuccessReport("Click on Pre-Order button", "Successfully clicked on Pre-Order button");
				else
					Reporters.failureReport("Click on Pre-Order button", "Failed to click on Pre-Order button");
			}
			else if(sButton.equalsIgnoreCase("Register")){
				if(javaClick(ElsevierObjects.btnRegister, "Register button"))
					Reporters.SuccessReport("Click on Register button", "Successfully clicked on Register button");
				else
					Reporters.failureReport("Click on Register button", "Failed to click on Register button");
			}
			
			Thread.sleep(2000);
			if(waitForVisibilityOfElement(ElsevierObjects.MyCART, "My Cart page")){
				Reporters.SuccessReport("Verify the My cart page is displayed", "My cart page is displayed");
			}else{
				Reporters.failureReport("Verify the My cart page is displayed", "My cart page is not displayed");
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

	/** Convert the Price value to float. 
	 * @param By Locator
	 * @return
	 * @throws Throwable
	 */
	public static float convertPrice(By Locator) throws Throwable{
		String price=getText(Locator, "Get Price from the package ");
		String priceReplace=price.replace("$", "");
		float totalPrice=Float.parseFloat(priceReplace);
		return totalPrice;
	}


	/** Convert the Price value to float. 
	 * @param By Locator
	 * @return
	 * @throws Throwable
	 */
	public static float convertStringToPrice(String price) throws Throwable{
		String priceReplace=price.replace("$", "");
		float totalPrice=Float.parseFloat(priceReplace);
		return totalPrice;
	}

	public static void checkout() throws Throwable{
		try{
			Thread.sleep(medium);
			if(javaClick(ElsevierObjects.Educator_Reedemchkout_btn,"Click on Reedeem Checkout button")){
				Reporters.SuccessReport("Click on the Redeem Checkout Button", "Successfully Clicked On Redeem checkout Button.");
			}else{
				Reporters.failureReport("Click on the Redeem Checkout Button", "Successfully Clicked On Redeem checkout Button.");
			}
			Thread.sleep(medium);
			
			//TODO Make this another method and call in 2 and not in 4
			/*String updateAccount = getText(By.xpath(".//*[@id='pageLayout-body-inner-most']//h1"), "Update Account");
			if(updateAccount!=null){
				Reporters.SuccessReport("Verify the Update my account page", "Successfully Navigated to the update my account page");
			}else{
				Reporters.failureReport("Verify the Update my account page", "Failed to Navigate to the update my account page");
			}*/
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void updateAccountPage() throws Throwable{
		try{
			String updateAccount = getText(ElsevierObjects.UPDATEACCOUNT_HEADING, "Update Account");
			if(updateAccount!=null){
				Reporters.SuccessReport("Verify Update my account page", "Successfully Navigated to the update my account page");
			}else{
				Reporters.failureReport("Verify Update my account page", "Failed to Navigate to the update my account page");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static boolean instituteAddress(String Country,String State, String City,String Instution,String Program,String Year) throws Throwable{
		boolean flag=true;
		try{

			if(!selectByVisibleText(ElsevierObjects.User_form_ddInstutionCountry, Country, "Country")){
				flag = false;
			}
			Thread.sleep(low);

			if(!selectByVisibleText(ElsevierObjects.User_form_State,State, "Select State institution.")){
				flag = false;
			}
			Thread.sleep(low);

			if(!type(ElsevierObjects.User_form_City,City, "Street Adress")){
				flag = false;
			}
			Thread.sleep(low);
			driver.findElement(ElsevierObjects.User_form_City).sendKeys(Keys.TAB);
			Thread.sleep(medium);

			if(!type(ElsevierObjects.User_form_txtInstution, Instution,"Institution name")){
				flag = false;
			}
			Thread.sleep(medium);
			driver.findElement(ElsevierObjects.User_form_txtInstution).sendKeys(Keys.TAB);
			Thread.sleep(medium);

			if(!selectBySendkeys(ElsevierObjects.User_form_txtddprogramType,Program, " country of institution.")){
				flag = false;
			}
			if(!selectBySendkeys(ElsevierObjects.Hesi_Student_year,Year,"Select the year from the list")){
				flag = false;
			}

			if(flag){
				Reporters.SuccessReport("Enter the details in Institute section ", "Successfully entered the details in Institution section <br/> The Details are : "
						+ "<br/> Institution Country : "+Country+"<br/>"
						+ "<br/> Institution State : "+State+"<br/>"
						+ "<br/> Institution City : "+City+"<br/>"
						+ "<br/> Institution Institution : "+Instution+"<br/>"
						+ "<br/> Institution Program : "+Program+"<br/>"
						+ "<br/> Institution Year : "+Year);
			}else{
				Reporters.failureReport("Enter the details in Institute section ", "Failed to enter the details in Institution section");
			}
			Thread.sleep(medium);
		}
		catch(Exception e){sgErrMsg="The Values are Not Submitted"+e;
		System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	public static void shippingAddress(String street, String city, String state, String zip) throws Throwable{
		boolean flag = true;
		try{
			if(!type(ElsevierObjects.Student_Shipping_Addr1, street,"Enter student Street")){
				flag=false;
			}
			if(!type(ElsevierObjects.Student_Shipping_City,city,"Enter student City")){
				flag=false;
			}

			if(!selectByValue(ElsevierObjects.Student_Shipping_State,state, "State name")){
				flag=false;
			}

			if(!type(ElsevierObjects.Student_Shipping_Zip,zip,"Enter student Zipcode")){
				flag=false;
			}
			if(flag){
				Reporters.SuccessReport("Enter the details in Shipping section ", "Successfully entered the details in Shipping section <br/> The Details are : "
						+ "<br/> Shipping state : "+state+"<br/>"
						+ "<br/> Shipping city : "+city+"<br/>"
						+ "<br/> Shipping street : "+street+"<br/>"
						+ "<br/> Shipping zip : "+zip);
			}else{
				Reporters.failureReport("Enter the details in Shipping section ", "Failed to enter the details in Shipping section");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void billingAddress(String streetAddress, String cityAddress,String stateAddress,String zip) throws Throwable{
		boolean flag = true;
		try{
			type(ElsevierObjects.student_billingAddress,streetAddress,"Enter the Street Address in the box");
			Thread.sleep(1000);
			type(ElsevierObjects.student_billingAddress_city,cityAddress,"Enter City in the textbox");
			Thread.sleep(1000);
			selectByValue(ElsevierObjects.student_billingAddress_state,stateAddress,"Enter State in the textbox");
			Thread.sleep(1000);
			type(ElsevierObjects.student_billingAddress_zip,zip,"Enter Zipcode in the textbox");
			Thread.sleep(1000);
			if(flag){
				Reporters.SuccessReport("Enter the details in Billing section ", "Successfully entered the details in Billing section <br/> The Details are : "
						+ "<br/> Billing Street Address : "+streetAddress+"<br/>"
						+ "<br/> Billing city Address : "+cityAddress+"<br/>"
						+ "<br/> Billing state Address : "+stateAddress+"<br/>"
						+ "<br/> Billing zip : "+zip);
			}else{
				Reporters.failureReport("Enter the details in Billing section ", "Failed to enter the details in Billing section");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}	

	public static void profileSubmit() throws Throwable{
		try{
			Thread.sleep(medium);
			if(click(ElsevierObjects.User_form_btnContinue,"Profile Submit")){
				Reporters.SuccessReport("Click on profile Submit button", "Successfully clicked on the profile submit button");
			}else{
				Reporters.failureReport("Click on profile Submit button", "Failed to click on the profile submit button");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}	


	public static void submitOrder() throws Throwable{
		try{
			Thread.sleep(veryhigh);
			Thread.sleep(veryhigh);
			switchToFrameByLocator(ElsevierObjects.Admin_Evolve_Ecom_framename,"Switch to iframe");
			Thread.sleep(low);
			String Popupheader = ReadingExcel.columnDataByHeaderName("PopUp", "TC-15588",configProps.getProperty("TestData"));
			String Popheader = getText(ElsevierObjects.Popup_header,"Get header of the frame");
			if(Popheader.contains(Popupheader)){
				Reporters.SuccessReport("Verify the header of Frame","PopupHeader is Successfully verified : </br> Expected Header is :"+Popheader+" </br> Actual Header is :"+Popupheader);
			}else{
				Reporters.failureReport("Verify the header of Frame","Failed to verify headers : </br> Expected Header is :"+Popheader+" </br> Actual Header is :"+Popupheader);
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.Use_this_address,"Click on use this address")){
				Reporters.SuccessReport("Click on Use this Address","Successfully clicked on Use this Address");
			}else{
				Reporters.failureReport("Click on Use this Address","Failed to click on Use this Address");
			}
			Thread.sleep(veryhigh);

			if(isElementPresent(ElsevierObjects.useThisAddressFrame)){
				switchToFrameByLocator(ElsevierObjects.useThisAddressFrame, "Switch to iFrame");
				click(ElsevierObjects.Use_this_address,"Click on use this address");
			}
			Thread.sleep(medium);
			String Creditheader = ReadingExcel.columnDataByHeaderName("Creditheader", "TC-15588",configProps.getProperty("TestData"));
			String cardheader = getText(ElsevierObjects.Creditcard_header,"Get header of the Page");
			if(cardheader.contains(Creditheader)){
				Reporters.SuccessReport("Verify the header of page","Creditcard Header is Successfully verified : </br> Expected Header is :"+cardheader+" </br> Actual Header is :"+Creditheader);
			}else{
				Reporters.failureReport("Verify the header of page","Failed to verify headers : </br> Expected Header is :"+cardheader+" </br> Actual Header is :"+Creditheader);
			}
			Thread.sleep(medium);


		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static boolean creditCardData(String cardType,String cardNumber,String cvvNumber,String nameOnCard,String expMonth,String expYear) throws Throwable{
		boolean flag = true;
		//String errorMessage ="";
		try {
			if(!selectByVisibleText(ElsevierObjects.lstcardtype, cardType,"")){
				flag = false;
			}
			if(!type(ElsevierObjects.Student_CardNumber_txt, cardNumber, "")){
				flag = false;
			}
			if(!type(ElsevierObjects.Student_Cardcvv_txt, cvvNumber, "")){
				flag = false;
			}
			if(!type(ElsevierObjects.Student_Cardname_txt, nameOnCard, "")){
				flag = false;
			}
			if(!selectByVisibleText(ElsevierObjects.Student_CardExpMnth_txt, expMonth, "")){
				flag = false;
			}

			if(!selectByVisibleText(ElsevierObjects.Student_CardExpYr_txt, expYear, "")){
				flag = false;
			}

			if(click(ElsevierObjects.Student_Card_continue_btn, "")){
				Reporters.SuccessReport("Entering Credit Card Details And Clicking On Submit Button.", "Successfully Entered Credit Card Details Card Type:"+cardType+"<br/>Card Number:"+cardNumber+"<br/>CVV Number:"+cvvNumber+"<br/>Expiry Month:"+expMonth+"<br/>Expiry Year:"+expYear+"</br>Clicked On Submit Button.</br>Successfully Navigated To Review And Submit Page.");
			}	
			else{
				Reporters.failureReport("Entering Credit Card Details And Clicking On Submit Button.", "Failed To Enter Credit Card Details.");
			}
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println();
		}
		return flag;
	}

	public static void submit() throws Throwable{
		try{
			Thread.sleep(low);
			if(click(ElsevierObjects.Student_accept_chk, "Accept Checkbox")){
				Reporters.SuccessReport("Check the I Accept checkbox", "Successfully checked the I Accept Checkbox");
			}else{
				Reporters.failureReport("Check the I Accept checkbox", "Failed to check the I Accept Checkbox");
			}
			Thread.sleep(low);
			if(click(ElsevierObjects.Student_Review_Submit, "Review Submit Button")){
				Reporters.SuccessReport("Click on the Review Submit Button", "Successfully Clicked on the Review Submit Button");
			}else{
				Reporters.failureReport("Click on the Review Submit Button", "Failed to Click on the Review Submit Button");
			}
			Thread.sleep(medium);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static void adminLogin(String username, String password) throws Throwable{
		boolean flag = true;
		try{

			if(!waitForElementPresent(ElsevierObjects.adminemail, "UserName text box")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.adminemail, username,"Enter Login Name")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.adminpassword, password,"Enter Login Password")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.adminlogin, "Submit")){
				flag = false;
			}
			Thread.sleep(medium);
			
			if(flag){
				Reporters.SuccessReport("Login as Admin User", "Successfully logged in as Admin user");
			}else{
				Reporters.failureReport("Login as Admin User", "Failed to log in as Admin user");
			}
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

	public static void maintainSuspicious() throws Throwable{
		try{
			if(isElementPresent(ElsevierObjects.MAINTAIN_SUSPICIOUS)){
				Reporters.SuccessReport("Verify that 'Maintain Suspicious Orders' section is present", "'Maintain Suspicious Orders' section is present");
			}else{
				Reporters.failureReport("Verify that 'Maintain Suspicious Orders' section is present", "'Maintain Suspicious Orders' section is not present");
			}
			click(ElsevierObjects.REVIEW_SUSPICIOUS, "");
			Thread.sleep(low);
			String breadCrumb=getText(ElsevierObjects.verifybreadcrumb, "");		
			if(isElementPresent(ElsevierObjects.verifybreadcrumb)){
				Reporters.SuccessReport("User should be navigated to Evolve Admin >> Maintain Suspicious Orders screen ", "Actual Bread Crumb is : "+breadCrumb +"<br> Expected Bread Crumb is : Evolve Admin > Maintain Suspicious Orders");
			}else{
				Reporters.failureReport("User should be navigated to Evolve Admin >> Maintain Suspicious Orders screen  ", "Actual Bread Crumb is : "+breadCrumb +"<br> Expected Bread Crumb is : Evolve Admin > Maintain Suspicious Orders");

			}	
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static void orderNumber(int col) throws Throwable{
		try{
			Thread.sleep(high);
			String orderNumber = getText(ElsevierObjects.ORDER_NUMBER_FORUSE, "Order Number");
			if(orderNumber!=null){
				Reporters.SuccessReport("Capture the Order Number", "Order Number is "+orderNumber);
			}else{
				Reporters.failureReport("Capture the Order Number", "Order Number is not generated");
			}
			ReadingExcel.updateCellInSheet(1,col,configProps.getProperty("TestData"), "FraudTestCases", orderNumber);
		}catch(Exception e){
			e.printStackTrace();
		}
	}


	public static void searchOrder(String orderNumber, String condition, String expectedConfidentialNote) throws Throwable{
		try{
			boolean flag = false;

			if(type(ElsevierObjects.ORDER_NUMBER, orderNumber, "orderNumber")){
				Reporters.SuccessReport("Enter the order number in the Search By Order Number text box", "Successfully entered Order Number in Search By Order Number text box as : "+orderNumber);
			}else{
				Reporters.failureReport("Enter the order number in the Search By Order Number text box", "Failed to enter Order Number in Search By Order Number text box");
			}
			if(click(ElsevierObjects.ORDER_SEARCH, "")){
				Reporters.SuccessReport("Click on the Search button", "Successfully Clicked on the Search Button");
			}else{
				Reporters.failureReport("Click on the Search button", "Failed to Click on the Search Button");
			}
			Thread.sleep(low);
			java.util.List<WebElement> order=driver.findElements(ElsevierObjects.ORDER_TABLE);
			for(WebElement e: order){
				System.out.println(e.getText());
				if(e.getText().equalsIgnoreCase(orderNumber)){
					flag = true;
					break;
				}else{
					flag=false;
				}
			}

			if(flag){
				Reporters.SuccessReport("Verify Order Details", "Order Details are successfully displayed ");
			}else{
				Reporters.failureReport("Verify Order Details", "Order Details are successfully displayed");
			}

			String orderNum = getText(By.xpath(".//*[@id='table-container']//strong[text()='Searched Suspicious Order(s)']//following::tbody[@template-tag='body']//td//a[text()='"+orderNumber+"']"), "");
			if(orderNum.contains(orderNumber)){
				Reporters.SuccessReport("Verify the order details displayed in the table under 'Searched suspicious orders(s)'", "The order details are displayed in the table under 'Searched suspicious orders(s)' <br> The order number from table is "+orderNum);
			}else{
				Reporters.failureReport("Verify the order details displayed in the table under 'Searched suspicious orders(s)'", "The order details are not displayed in the table under 'Searched suspicious orders(s)' <br> The order number from table is "+orderNum);
			}

			String status = getText(ElsevierObjects.ORDER_STATUS, "status");
			if(status.equalsIgnoreCase("Review")){
				Reporters.SuccessReport("Verify the status", "The status of the order is as expected and is : "+status);
			}else{
				Reporters.failureReport("Verify the status", "The status of the order is not as expected");
			}
			if(click(ElsevierObjects.ORDER_BUBBLE_ICON, "")){
				Reporters.SuccessReport("Click on the bubble icon ", "Successfully clicked on the bubble icon");
			}else{
				Reporters.SuccessReport("Click on the bubble icon ", "Failed to click on the bubble icon");
			}
			Thread.sleep(low);
			String confidentialNote = getText(ElsevierObjects.CONFIDENTIAL_NOTE, "confidential note");
			
			System.out.println(confidentialNote);
			if(confidentialNote.trim().equalsIgnoreCase(expectedConfidentialNote.trim())){
				Reporters.SuccessReport("Verify the Confidential Notes", "Confidential note is : <br/> Actual : "+confidentialNote+" <br/> Expected : "+confidentialNote);
			}else{
				Reporters.failureReport("Verify the Confidential Notes", "Confidential note is : <br/> Actual : "+confidentialNote+" <br/> Expected : "+confidentialNote);
			}
			if(click(ElsevierObjects.ORDER_BUBBLE_ICON_CLOSE, "close box")){
				Reporters.SuccessReport("Close the NOTES box", "Successfully Closed the NOTES box");
			}else{
				Reporters.failureReport("Close the NOTES box", "Failed to Close the NOTES box");
			}
			Thread.sleep(low);
			if(condition.contains("Rejected")){
				if(click(ElsevierObjects.ORDER_REJECT_CHKBOX, "reject checkbox")){
					Reporters.SuccessReport("Check the box under 'REJECT' column for this order", "Successfully Checked the box under 'REJECT' column for this order");
				}else{
					Reporters.failureReport("Check the box under 'REJECT' column for this order", "Failed to Check the box under 'REJECT' column for this order");
				}
				if(click(ElsevierObjects.ORDER_SUBMIT, "Submit")){
					Reporters.SuccessReport("Hit SUBMIT button located in the footer area of the screen", "Successfully Clicked on the SUBMIT button located in the footer area of the screen");
				}else{
					Reporters.failureReport("Hit SUBMIT button located in the footer area of the screen", "Failed to Click on the SUBMIT button located in the footer area of the screen");
				}
				if(isElementPresent(ElsevierObjects.ORDER_SUBMIT)){
					Reporters.SuccessReport("User is presented with pop up window to enter the note for rejecting this order", "Pop up window is now available to enter the note for rejecting the order");
				}else{
					Reporters.failureReport("User is presented with pop up window to enter the note for rejecting this order", "Pop up window is not available to enter the note for rejecting the order");
				}
				if(type(ElsevierObjects.ORDER_REJECTION_MESSAGE, "Rejecting", "reject message")){
					Reporters.SuccessReport("Enter some text in this screen", "Successfully entered the text as 'Rejecting'");
				}else{
					Reporters.failureReport("Enter some text in this screen", "Failed to enter the text as 'Rejecting'");
				}
				if(click(ElsevierObjects.ORDER_REJECTION_MESSAGE_SAVE, "save button")){
					Reporters.SuccessReport("Click on the save button", "Successfully Clicked on the save button");
				}else{
					Reporters.failureReport("Click on the save button", "Failed to Click on the save button");
				}
				Thread.sleep(medium);
			}else if(condition.contains("Approved")){
				if(click(ElsevierObjects.ORDER_APPROVAL_CHKBOX, "approve checkbox")){
					Reporters.SuccessReport("Check the box under 'APPROVE' column for this order", "Successfully Checked the box under 'APPROVE' column for this order");
				}else{
					Reporters.failureReport("Check the box under 'APPROVE' column for this order", "Failed to Check the box under 'APPROVE' column for this order");
				}
				if(click(ElsevierObjects.ORDER_SUBMIT, "Submit")){
					Reporters.SuccessReport("Hit SUBMIT button located in the footer area of the screen", "Successfully Clicked on the SUBMIT button located in the footer area of the screen");
				}else{
					Reporters.failureReport("Hit SUBMIT button located in the footer area of the screen", "Failed to Click on the SUBMIT button located in the footer area of the screen");
				}
				if(isElementPresent(ElsevierObjects.ORDER_SUBMIT)){
					Reporters.SuccessReport("User is presented with pop up window to enter the note for rejecting this order", "Pop up window is now available to enter the note for rejecting the order");
				}else{
					Reporters.failureReport("User is presented with pop up window to enter the note for rejecting this order", "Pop up window is not available to enter the note for rejecting the order");
				}
				if(type(ElsevierObjects.ORDER_APPROVAL_MESSAGE, "Approving", "Approve message")){
					Reporters.SuccessReport("Enter some text in this screen", "Successfully entered the text as 'Approving'");
				}else{
					Reporters.failureReport("Enter some text in this screen", "Failed to enter the text as 'Approving'");
				}
				if(click(ElsevierObjects.ORDER_REJECTION_MESSAGE_SAVE, "save button")){
					Reporters.SuccessReport("Click on the save button", "Successfully Clicked on the save button");
				}else{
					Reporters.failureReport("Click on the save button", "Failed to Click on the save button");
				}
				Thread.sleep(veryhigh);
				Thread.sleep(medium);
			}
			String orderUpdateMessage = getText(ElsevierObjects.ORDER_CHANGE_MESSAGE, "Update Message");
			if(orderUpdateMessage.contains("rejected")){
				Reporters.SuccessReport("Verify that Maintain suspicious order will reload and a message 'The order successfully approved/rejected' is displayed.", "Maintain suspicious order is reloaded and a message "+orderUpdateMessage+" is displayed.");
			}else{
				Reporters.failureReport("Verify that Maintain suspicious order will reload and a message 'The order successfully approved/rejected' is displayed.", "Maintain suspicious order is reloaded and a message is not displayed.");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static void searchOrderRejected(String orderNumber, String condition) throws Throwable{
		try{
			driver.findElement(ElsevierObjects.ORDER_NUMBER).clear();
			driver.findElement(ElsevierObjects.ORDER_SEARCH_USERNAME).click();
			if(type(ElsevierObjects.ORDER_NUMBER, orderNumber, "orderNumber")){
				Reporters.SuccessReport("Enter the order number in the Search By Order Number text box", "Successfully entered Order Number in Search By Order Number text box as : "+orderNumber);
			}else{
				Reporters.failureReport("Enter the order number in the Search By Order Number text box", "Failed to enter Order Number in Search By Order Number text box");
			}
			if(click(ElsevierObjects.ORDER_SEARCH, "")){
				Reporters.SuccessReport("Click on the Search button", "Successfully Clicked on the Search Button");
			}else{
				Reporters.failureReport("Click on the Search button", "Failed to Click on the Search Button");
			}
			Thread.sleep(low);


			String status = getText(ElsevierObjects.ORDER_STATUS, "status");
			if(condition.equalsIgnoreCase("Rejected")){
				if(status.equalsIgnoreCase("REJECTED")){
					Reporters.SuccessReport("Verify the status", "The status of the order is as expected and is : "+status);
				}else{
					Reporters.failureReport("Verify the status", "The status of the order is not as expected");
				}
			}else if(condition.equalsIgnoreCase("Approved")){
				if(status.equalsIgnoreCase("APPROVED")){
					Reporters.SuccessReport("Verify the status", "The status of the order is as expected and is : "+status);
				}else{
					Reporters.failureReport("Verify the status", "The status of the order is not as expected");
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	//Logout from Admin
	public static boolean adminLogout() throws Throwable{
		boolean flag = true;
		try{
			if(click(ElsevierObjects.logout,"Clicked on Logout Button")){
				Reporters.SuccessReport("Logout from Admin User", "Successfully Logged out from Admin user");
			}else{
				Reporters.failureReport("Logout from Admin User", "Failed to Log out from Admin user");
			}
			Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	public static void getEmailBody() throws Throwable{
		try{
			switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
			String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
			System.out.println(emailBody);
			Reporters.SuccessReport("Verify Email body content","Successfully Emailbody content is verified </br> "+emailBody);

		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
