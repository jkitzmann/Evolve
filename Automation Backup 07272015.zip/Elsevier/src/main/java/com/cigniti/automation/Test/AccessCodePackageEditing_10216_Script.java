package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.AccessCodePackageEditing_10216;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class AccessCodePackageEditing_10216_Script extends AccessCodePackageEditing_10216 {

	@Test
	public void accessCodePackageEditing_10216() throws Throwable{

		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			SwitchToBrowser(ElsevierObjects.adminBrowserType);

			stepReport("Login to Evolve Admin.");
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials "+ configProps.getProperty("AdminUser"),
					"Launching the URL for User is successful </br > Login to Application Using User credentails : "+configProps.getProperty("AdminUser")+" is Successful",
					"Launching and Login to Application Using User credentails : "+ configProps.getProperty("AdminUser")+" is Failed");

			stepReport("Update an existing access code package.");
			clickMaintainAccessCode();
			Thread.sleep(medium);
			writeReport(EvolveCommonBussinessFunctions.adminLogout(),"Clicking on Logout",
					"Clicking on Logout is Successful",
					"Clicking on Logout is not Successful");


		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}

}
