package com.cigniti.automation.BusinessFunctions;

import org.openqa.selenium.Keys;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;


public class HESIStudent_loginexistinguserafteraddtocart_9791 extends EvolveCommonBussinessFunctions {
	public static String Country;
	public static String State;
	public static String City;
	public static String Institute;
	public static String Programtype;
	public static String Year;
	public static String StudentId;
	public static String price;
	public static String Title;
	public static String isbn;
	
	public static boolean Hesi_Existing_Student() throws Throwable {
	try
      {
		boolean flag = true;
		 /*if(click(ElsevierObjects.Hesi_Student_HesiExam,"Click on HESI Exams Button")){
	    	 Reporters.SuccessReport("Click on HESI Exams Icon","Successfully clicked on HESI Exams Honey pot");
	     }else{
	    	 Reporters.failureReport("Click on HESI Exams Icon","Failed to click on HESI Exams Honey pot");
	     }
	     Thread.sleep(1000);*/
         if(click(ElsevierObjects.Hesi_Student_HesiRegister,"Click on HESI Register Button")){
        	 Reporters.SuccessReport("Click on HESI Registration link","Successfully clicked on Register for HESI link");
         }else{
        	 Reporters.failureReport("Click on HESI Registration link","Failed to click on HESI Registration link");
         }
	    Thread.sleep(2000);
	    String header = ReadingExcel.columnDataByHeaderName("HesiHeader","TC-8567",configProps.getProperty("TestData"));
	    String h = getText(ElsevierObjects.Hesi_Registration_header,"Get the header of the page");
	    if(h.contains(header)){
	    	Reporters.SuccessReport("Verify the header of the page","Header is verified where HESI Registration and Register Now button is present");
	    }else{
	    	Reporters.failureReport("Verify the header of the page","Failed to verify the page header where HESI Registration and Register Now button");
	    }
	    Thread.sleep(2000);
	    if(click(ElsevierObjects.Hesi_Student_Registernow,"Click on Register Now button")){
	    	Reporters.SuccessReport("Click on Register Now","Successfully clicked on Register Now button and Item is added to cart");
	    }else{
	    	Reporters.failureReport("Click on Register Now","Failed to click on Register Now button and Item is added to cart");
	    }
	    Thread.sleep(high);
	    Title = getText(ElsevierObjects.Hesi_title,"Get the title of the product");
	    Reporters.SuccessReport("Verify the title of product", "Title of the product is " +Title);
	    Thread.sleep(1000);
	     
	    isbn = getText(ElsevierObjects.Hesi_Student_isbn,"Get the isbn present there");
	    Reporters.SuccessReport("Verify the isbn of the product", "ISBN of the product is "+isbn);
	    Thread.sleep(1000);
	     
	    String s = ReadingExcel.columnDataByHeaderName("S","TC-8567",configProps.getProperty("TestData"));  
	    price=getText(ElsevierObjects.Hesi_Student_price,"Get price present there");
		if(price.contains(s)){
			 Reporters.SuccessReport("Verify Prices of the product", "Prices are compared successfully: <br> Expected Price is : "+price+"<br>Actual Price is : "+s);
		}else{
		   	 Reporters.failureReport("Verify Prices of the product", "Prices comparision failed: <br> Expected Price is : "+price+"<br>Actual Price is : "+s);
		}
		Thread.sleep(1000);
		Reporters.SuccessReport("Verify Item add to Cart","Item is Successfully add to cart and Price is verified");
		Thread.sleep(1000);
		if(click(ElsevierObjects.Hesi_Student_Reedembutton,"Click on Reedem/Checkout button")){
			Reporters.SuccessReport("Click on Reedem/Checkout","Successfully clicked on Reedem/Checkout button </br> Logged in as an Existing user  <br> Username :"+credentials[0]+ "</br> Password : "+credentials[1] +"</br> Update Your Account page is displayed");
		}else{
			Reporters.failureReport("Click on Reedem/Checkout","Failed to click on Reedem/Checkout button,  login and Update your account");
		}
	    Thread.sleep(1000);
	    type(ElsevierObjects.Hesi_Student_username,credentials[0],"Enter username in the textbox");
	    Thread.sleep(1000);
	    type(ElsevierObjects.Hesi_Student_password,credentials[1],"Enter Password in the textbox");
	    Thread.sleep(1000);
	    click(ElsevierObjects.Hesi_Student_login,"Click on login button");
		Thread.sleep(3000);
		selectByVisibleText(ElsevierObjects.Hesi_Student_country,Country,"Enter Institute country");
	    Thread.sleep(2000);
		selectByVisibleText(ElsevierObjects.Hesi_Student_state,State,"Enter Institution state");	  
	    Thread.sleep(2000);
	    selectBySendkeys(ElsevierObjects.Hesi_Student_City,City,"Enter Cityname");
		Thread.sleep(4000);
		driver.findElement(ElsevierObjects.Hesi_Student_City).sendKeys(Keys.ENTER);
		Thread.sleep(2000);
        type(ElsevierObjects.Hesi_Student_institute,Institute,"Enter institute name");
	    Thread.sleep(2000);
	    selectByVisibleText(ElsevierObjects.Hesi_Student_prgtype,Programtype,"Enter Program type");
	    Thread.sleep(2000);
        selectByValue(ElsevierObjects.Hesi_Student_year,Year,"Enter year of graduation");
	    Thread.sleep(2000);
        type(ElsevierObjects.Hesi_Student_Optional,StudentId,"Enter student Id");
        Thread.sleep(1000);
        click(ElsevierObjects.Hesi_Student_continue,"Click on continue button");
        Thread.sleep(2000);			
        click(ElsevierObjects.instructor_chk ,"Click on check box");
        Thread.sleep(1000);
        click(ElsevierObjects.instructor_submit ,"Click on submit button");
        Thread.sleep(2000);
        return flag;}
        catch(Exception e){return false;}
	}    
    
	public static boolean Confirmationpage()throws Throwable{
     try
       {
        boolean flag = true;        
    	String st=getText(ElsevierObjects.Hesi_Student_msg,"Get the Success message present there");
	    Reporters.SuccessReport("Verify the Success Message","Successfully Message is verified :"+st);
	    Thread.sleep(1000);
	   
	     String HesiProductTitle=getText(ElsevierObjects.Hesi_Student_title,"Get the title Present there");
	     if(HesiProductTitle.contains(Title)){
	    	 Reporters.SuccessReport("Verify the title of product", "Titles are compared successfully: <br> Expected Title is :"+HesiProductTitle+"<br>Actual Title is :"+Title);
	     }else{
	    	 Reporters.failureReport("Verify the title of product", "Titles are compared is failed: <br> Expected Title is :"+HesiProductTitle+"<br>Actual Title is :"+Title);
	     }
	     Thread.sleep(1000);
	   
	     String ISBN = getText(ElsevierObjects.Hesi_Student_ISBN,"Get the isbn present there");
	     if(ISBN.contains(isbn)){
	    	 Reporters.SuccessReport("verify the isbn of the product", "ISBN's are compared successfully: <br>Expected ISBN is :"+ISBN+"<br>Actual ISBN is :"+isbn);
	     }else{
	    	 Reporters.failureReport("verify the isbn of the product", "Failed to compare ISBN's :<br>Expected ISBN is :"+ISBN+"<br>Actual ISBN is :"+isbn);
	     }
	     Thread.sleep(1000);
	     
	     String Price = getText(ElsevierObjects.Price,"Get the price of the product");
	     if(Price.contains(price)){
			  Reporters.SuccessReport("Verify Item Price of product", "Prices are compared successfully: <br> Expected Price is : "+Price+"<br>Actual Price is : "+price);
		 }else{
		   	  Reporters.failureReport("Verify Item Price of product", "Prices comparision failed: <br> Expected Price is : "+Price+"<br>Actual Price is : "+price);
		 }
	     Thread.sleep(1000);
	     String TotalPrice=getText(ElsevierObjects.Hesi_Verify_Total,"Get the Totalprice Present there");
	     if(TotalPrice.contains(price)){
			    Reporters.SuccessReport("Verify Total Price of product", "TotalPrices are compared successfully: <br> Expected Price is : "+price+"<br>Actual Price is : "+price);
		 }else{
		   	    Reporters.failureReport("Verify Total Price of product", "TotalPrices comparision failed: <br> Expected Price is : "+price+"<br>Actual Price is : "+price);
	     }
		return flag;}
	    catch(Exception e){return false;}
	}

}
