package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EComm_Preorde_MyEvolve_Page15594_BussinessFunctions;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class EComm_Preorde_MyEvolve_Page15594_Script_2 extends EComm_Preorde_MyEvolve_Page15594_BussinessFunctions{

	@Test
	public static void eCommPreordeMyEvolvePage15594_2() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		launchUrl(configProps.getProperty("URL4"));
		String username=readcolumns.twoColumns(0,1, "ECommercePreOrder", configProps.getProperty("TestData")).get("eCommPreorderMyEvolvePage15594");
		String password=readcolumns.twoColumns(0,2, "ECommercePreOrder", configProps.getProperty("TestData")).get("eCommPreorderMyEvolvePage15594");
		if(User_BusinessFunction.SignInAsDifferentUser(username, password)){
			Reporters.SuccessReport("Login into Application as same student user", "Successfully logged in as Student user with the credentials : <br> Username : "+username+"<br> Password : "+password);
		}else{
			Reporters.failureReport("Login into Application as same student user", "Failed to log in as Student user with the credentials : <br> Username : "+username+"<br> Password : "+password);
		}
		String user="student";
		courseDetailsPage(ElsevierObjects.courseContentLink,"contentHome");
	}
	@AfterTest
	public void closeBrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		//Base.tearDown();
	}
}
