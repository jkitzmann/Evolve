package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.VitalSourceAccountAC_HomePage_StudentExists_VST;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class VitalSourceAccount_AC_MyCart_Student_Script_15562 extends EvolveCommonBussinessFunctions{
	
	@Test 
	public void vitalSourceAccount_AC_MyCart_Student_15562() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String username=ReadingExcel.columnDataByHeaderName( "VST_InstructorUser", "VST",configProps.getProperty("TestData"));
			String password=ReadingExcel.columnDataByHeaderName( "VST_InstructorPassword", "VST",configProps.getProperty("TestData"));
			
			String user = "student";
			String knoUser="";
			
			stepReport("Create new student user.");
			if(CreateNewUser(user))
			{
	     		Reporters.SuccessReport("Login into Application ", "Successfully logged in as Student user");
			}
			else
			{
				Reporters.failureReport("Login into Application ", "Failed to login as Student user");
			}
			String name = "VST";
			String accessCode = "true";
			
			stepReport("Add VST product to cart, apply access code, and enter checkout.");
			VSTandKnoSearch(name,accessCode);
			
			stepReport("Enter VST password in checkout.");
			updateVSTandKNOAccount(user,name,accessCode,knoUser);
			
			stepReport("Complete checkout and verify receipt page.");
			if(userReviewSubmit(user,accessCode,KNOIsbn))
			{
	     		Reporters.SuccessReport("Review and submit page:" ,"Successfully entered to review and submit page");
			}
			else
			{
				Reporters.failureReport("Review and submit page:", "Failed to enter review and submit page");
			}
			String accessCodeUser="student";
			String beforeTitle=titleInReceiptPage;
			String condition="myCartTitle";
			stepReport("Verify VST link in My Evolve.");
			writeReport(VitalSourceAccountAC_HomePage_StudentExists_VST.pageburstVstLink(accessCodeUser, beforeTitle, condition), "Verify the VST link.", 
					"Succesfully verified the VST link.</br>Successfully Clicked on VST link.</br>Successfully Navigated to VST page.", 
					"Failed to verify the VST link.");
			if(instructorLogout())
			{
				Reporters.SuccessReport("Student Log out:", "Student Loged Out Successfully");
			}
	       else{
				Reporters.failureReport("Student Log out:", "Student Log out Failed."); 
			}
			String user1="educator";
			
			stepReport("Verify that the access code used is no longer valid.");
			if(reCheckingAccessCode(user1,username, password))
			{
				Reporters.SuccessReport("ReChecking Access Code", "User is given an error when attempted to enter the used vst access code.  <br>The code is now redeemed so no other user should be able to use this code.  The VST item is not added to the card and the access code is not applied.");
			}
	       else{
				Reporters.failureReport("ReChecking Access Code", "User is failed to give an error message when attempted to enter the used vst access code.  <br>The code is now redeemed so no other user should be able to use this code.  The VST item is not added to the card and the access code is not applied."); 
			}
			ReadingExcel.removeUsedVSTCode(VSTDataPath, "VSTCodes");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ReadingExcel.removeUsedVSTCode(VSTDataPath, "VSTCodes");
		}
	}
	@AfterTest
	public void closeBrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
