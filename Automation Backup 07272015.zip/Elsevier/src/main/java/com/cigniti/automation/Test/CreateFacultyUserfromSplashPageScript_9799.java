package com.cigniti.automation.Test;




import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.CreateFacultyUserfromSplashPage_9799;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class CreateFacultyUserfromSplashPageScript_9799 extends CreateFacultyUserfromSplashPage_9799{
	@Test
	public void CreateFacultyUserfromSplashPageScript9799() throws Throwable{
		try{
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			stepReport("Open Evolve Main Page");
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			EvolveCommonBussinessFunctions.mainPageLink();
			String user="educator";
			String page="splash";
			
			stepReport("Error handling: empty fields");
			createAnAccountWithEmptyFields(user,page);
			
			stepReport("Error handling: no password");
			createAnAccountWithPwdEmpty(user,page);
			
			stepReport("Error handling: password mismatch");
			createAnAccountPwdMismatch(user,page);
			
			stepReport("Create new instructor account");
			createAnAccountWithCorrectDetails(user,page);
			getAccountDetails();
			
			stepReport("Log out and back in");
			if(instructorLogout()){
				Reporters.SuccessReport("Faculty logout:", "Successfully logged out the faculty aplication.");
			}
			else{
				Reporters.failureReport("Faculty logout:", "Failed to logout the faculty application.");
			}
			userReLogin(user);
			
			//SwitchToBrowser("Chrome");
			stepReport("Verify email");
			if(emailLogin()){
				Reporters.SuccessReport("Email login:", "Successfully logged into User Email.");
			}
			else{
				Reporters.failureReport("Email Login:", "Failed to login into User Email.");
			}
			String Title=tc_9798.get("Title");
			CreateFacultyUserfromSplashPageScript_9799.emailBodyVerification(Title,user);
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}