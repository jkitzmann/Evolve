package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarte_Student_SplitOrders2_15597;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;

public class ECommercePreorderALaCarte_Student_SplitOrders2_Script_15597 extends ECommercePreorderALaCarte_Student_SplitOrders2_15597 {

@Test

public void eCommercePreorderALaCarte_Student_SplitOrders2_15597() throws Throwable{
	SwitchToBrowser(ElsevierObjects.studentBrowserType);
	String studentuser=ReadingExcel.columnDataByHeaderName("Username", "TC-15597", testDataPath);
	writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials"+adminUser,
            "Launching the URL for User is successful </br> Login to Application Using User credentails :"+adminUser+" is Successful",
            "Launching and Login to Application Using User credentails : "+ adminUser+" is Failed");
	
	searchPreOrder();
	
	String isbn=ReadingExcel.columnDataByHeaderName("ecommerceISBN1","TC-15597",testDataPath);
	String status=ReadingExcel.columnDataByHeaderName("preOrderStatus", "TC-15597", testDataPath);
	String order=ReadingExcel.columnDataByHeaderName("OrderID", "TC-15597", testDataPath);
	String username=ReadingExcel.columnDataByHeaderName("Username", "TC-15597", testDataPath);
	String year=ReadingExcel.columnDataByHeaderName("year", "TC-15597", testDataPath);
	
	
	verifyOrderSubmitDateCalender(status);
	
	verifyPreOrderFulfillmentCalender(status);
	
	String status1=ReadingExcel.columnDataByHeaderName("status1", "TC-15597", testDataPath);
	String status2=ReadingExcel.columnDataByHeaderName("status2", "TC-15597", testDataPath);
	String status3=ReadingExcel.columnDataByHeaderName("status3", "TC-15597", testDataPath);
	String status4=ReadingExcel.columnDataByHeaderName("status4", "TC-15597", testDataPath);
	
	
	verifyStatus(status1,status2,status3,status4,isbn);
	
	verifyISBN(status,order,username,year);
	
	verifyOrderID(status,isbn,username,year);
	
	verifyUsername(status,isbn,order,year);
	
	verifyPreOrderDetails();
	
	searchOrderswithUsername(username);
	
	Thread.sleep(300);
	String ecommerceISBN1=ReadingExcel.columnDataByHeaderName("ecommerceISBN1", "TC-15597", configProps.getProperty("TestData"));
	String orderid1=readcolumns.twoColumnsBasedOnSheetName(0,1, "TC-15597_Orders", configProps.getProperty("TestData")).get(ecommerceISBN1);
	String publicationDate=ReadingExcel.columnDataByHeaderName("publicationDate", "TC-15597", configProps.getProperty("TestData"));
	String completeStatus=ReadingExcel.columnDataByHeaderName("completeStatus", "TC-15597", testDataPath);
	String packeged=ReadingExcel.columnDataByHeaderName("packaged", "TC-15597", testDataPath);
	String originalPrice1=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-15597_PriceValues", configProps.getProperty("TestData")).get("ecommerceISBN1");
	
	String accesscode=ReadingExcel.columnDataByHeaderName("accesscode", "TC-15597", testDataPath);
	String accesscodeDiscount=ReadingExcel.columnDataByHeaderName("accesscodeDiscount", "TC-15597", testDataPath);
	String pastpublicationDate=ReadingExcel.columnDataByHeaderName("pastDtae", "TC-15597", configProps.getProperty("TestData"));
	verifyISBNDetails(orderid1,ecommerceISBN1,"",pastpublicationDate,completeStatus,studentuser,packeged,originalPrice1,originalPrice1,"",accesscode,accesscodeDiscount);
	
	String ecommerceISBN3=ReadingExcel.columnDataByHeaderName("ecommerceISBN3", "TC-15597", configProps.getProperty("TestData"));
	String orderid2=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-15597_Orders", configProps.getProperty("TestData")).get(ecommerceISBN3);
	
	String cancelStatus=ReadingExcel.columnDataByHeaderName("cancelStatus", "TC-15597", testDataPath);
	String originalPrice2=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-15597_PriceValues", configProps.getProperty("TestData")).get("ecommerceISBN3");
	
	verifyISBNDetails(orderid2,ecommerceISBN3,"",publicationDate,cancelStatus,studentuser,packeged,originalPrice2,originalPrice2,"",accesscode,accesscodeDiscount);

	String futureyear=ReadingExcel.columnDataByHeaderName("futureYear", "TC-15597", testDataPath);
	verifyDateError(futureyear);
	
	String password=ReadingExcel.columnDataByHeaderName("password", "TC-15597", testDataPath);
	
	writeReport(User_BusinessFunction.Studentlogin(studentuser, password),"Launching The URL And Login As Student User.",
			"Successfully Logged In Into Student Application As :"+studentuser,
			"Failed To Login Into Application As Student :"+studentuser);
	
	String title=ReadingExcel.columnDataByHeaderName("resourcetitle", "TC-15597", testDataPath);
	String notitle=ReadingExcel.columnDataByHeaderName("Onlinetitle", "TC-15597", testDataPath);
	
	verifyTitleInEvolve(title,notitle);
	
}


}
