package com.cigniti.automation.BusinessFunctions;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Test.CreateRosterforLOcourse_Byrosteredinstructor_Script_15565;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class ChangeRosterTitle_10440 extends EvolveCommonBussinessFunctions
{
	//===Variable for new Student creation======//
	public static String sFirstName;
	public static String sLastName;
	public static String sEmail;
	public static String newSName;
	public static String newSPwd;
	public static String newSdetails;

	//===variable for getting courseID from roster information=====//
	public static String CID;
	public static String COURSETITLE;
	public static String newtitle;

	//=====Variable for store roster faculty User-name and password=====//
	public static String rostered_facultyUserName;
	public static String rostered_facultyPassword;

	//=====variables for enrolled student from 15565============//

	public static String selfSUserName;
	public static String selfSPassword;


	//======variables for step#6 in Step#11==================//

	public static String firstname;
	public static String educatorName;
	public static String FirstName;
	public static String lastname;
	public static String LastName;
	public static String institutionName;
	public static String Institution;

	//=====variables used for 'Self enrol into LO course through e-commerce - Home page' 
	public static String newStUserinSelf;
	public static String newStpwdinSelf;



	public static boolean studentDetails()throws Throwable
	{		
		boolean flag=true;
		try{

			if(!click(ElsevierObjects.myAccount,"click on my account")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.myAccount_AccountSettings,"click on account settings.")){
				flag=false;
			}
	
			sFirstName=getAttribute(ElsevierObjects.educator_form_txtFirstName, "value", "Get first name");
			sLastName=getAttribute(ElsevierObjects.educator_form_txtLastName,"value","Get Last Name");
			sEmail=getAttribute(ElsevierObjects.educator_form_txtEmail,"value","Get email id.");
			newSdetails=sLastName+","+sFirstName+","+sEmail;
	
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(medium);
			}
			catch(Exception e){
				sgErrMsg=e.getMessage();return false;
			}
	
		return flag;
	}
	
	
	//====================================end of the Method============================================//
	
	

	public static boolean verifyTitle(String titleToVerify)throws Throwable
	{
		boolean flag=true;
		try{
		
		String ID21="true";

		CID=ReadingExcel.columnDataByHeaderName("CourseId","TC-15565",configProps.getProperty("TestData"));

		if(ID21.equalsIgnoreCase("true"))
		{
			if(waitForVisibilityOfElement(By.xpath(".//*[@id='set']/li/div/div/span[text()='COURSE ID: "+CID+"']"),"Verify course id1 present."))
			{
				Reporters.SuccessReport("verify that the rostered CourseID present in the content list", " successfully verifies the roster courseID presence in the content list and</br>The roster CourseID is   :   "+CID);
			}
			else
			{
				Reporters.failureReport("verify that the rostered CourseID present in the content list", "Failed to verify the roster courseID");
			}
		}

		if(click(By.xpath("//*[@id='set']/li/div/div/span[text()='COURSE ID: "+CID+"']/following-sibling::a"),"Click on Course Title."))
		{

			//driver.manage().timeouts().implicitlyWait(600, TimeUnit.SECONDS);
			Thread.sleep(60000);
			Reporters.SuccessReport("Get in to the content List page", "Successfully get into the ContentList page");
		}
		else
		{

			Reporters.failureReport("Get in to the content List", "Failed to get in to the content list page ");
		}
		COURSETITLE=getText(ElsevierObjects.course_title, "course Title");
		System.out.println("course Title is::>>"+COURSETITLE);
		
		if(COURSETITLE.contains(titleToVerify))
		//if(COURSETITLE.contains(COURSETITLE))
		{
			Reporters.SuccessReport("verify the Course Title", "Successfully verifies the course Title and</br>The Actual Course Title is   :   "   +COURSETITLE);
		}
		else
		{
			Reporters.failureReport("verify the Course Title", "Failed to verify the course title");
		}
		Thread.sleep(medium);
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();return false;
	}
		return flag;
	}
	
	
	//====================================end of the Method============================================//
	
	

	public static boolean editTitle()throws Throwable
	{
	boolean flag=true;
		try{
		mouseover(ElsevierObjects.course_title, "MouseOver the course title");

		if(click(ElsevierObjects.course_title, "click on the course for edit it"))
		{
			
			Reporters.SuccessReport("click the course title and Highlight the title", "Successfully Clicked on the course Title for edit it");
		}

		else
		{
			Reporters.failureReport("Click the course title and Highlight the title", "failed to click on the course Title for edit it");
		}
		Thread.sleep(high);
		String editedtitle=ReadingExcel.columnDataByHeaderName("EditwithTitle","TC-15565",testDataPath);
		//Random ra = new Random( System.currentTimeMillis() );
		//String edintingTitle ="CourseABC"+Integer.toString((1 + ra.nextInt(2)) * 1000+ ra.nextInt(1000));
		
		if(type(ElsevierObjects.editableCourseID,editedtitle, "editing course title"))
		{

			driver.findElement(ElsevierObjects.editableCourseID).sendKeys(Keys.ENTER);
			Thread.sleep(high);
			newtitle=getText(ElsevierObjects.course_title, "Title after edit it");
			System.out.println("Edited title is::>>"+newtitle.toString());
			Reporters.SuccessReport("Edit the course Title and Press the 'Enter' key for saving New Title of the course", "Sucessfully edit the course Title and  pressed 'ENTER' key for save the new Title</br> The Actual Title is   :   "+COURSETITLE+"</br>The Edited Title is   :   "+newtitle.toString());
		}
		else
		{
			Reporters.failureReport("Edit the course Title and Press the 'Enter' key for saving New Title of the course", "Failed to edit the course title");
		}		
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();return false;
	}
		return flag;
	}
	
	//====================================end of the Method============================================//
	
	
	
	public static boolean checkChangedCourseTitleInStudentPage()throws Throwable
	{
		boolean flag=true;
		try{
			User_BusinessFunction.Studentlogin(selfSUserName, selfSPassword);
	
			click(ElsevierObjects.lnkevolve, "click on the 'MyEvolve' link");
			if(isElementPresent(By.xpath(".//*[@id='set']/li/div/div/span[text()='COURSE ID: "+CID+"']"),"Verify course id1 present."))
			{
				Thread.sleep(medium);
				Reporters.SuccessReport("Log into the 'evolvecer.com' as a  rostered student from Step#1", "Sucessfully logged into the 'evolvecert.com' with rostered student and verifies changed course Title</br>Changed Title is   :   "+newtitle.toString());
			}
			else
			{
				Reporters.failureReport("Log into the 'evolvecer.com' as a  rostered student from Step#1", "Failed to verify the changed course Title");
			}
			User_BusinessFunction.Logout();
		}
	catch(Exception e){
		sgErrMsg=e.getMessage();return false;
	}
		return flag;
	}
	
	//====================================end of the Method============================================//
	
	
	
	public static boolean checkChangedCourseTitleInFacultyPage()throws Throwable
	{
		boolean flag=true;
		try{
			User_BusinessFunction.Educatorlogin(rostered_facultyUserName, rostered_facultyPassword);
	
			click(ElsevierObjects.lnkevolve, "click on the 'MyEvolve' link");
	
			if(isElementPresent(By.xpath("//*[@id='set']/li/div/div/span[text()='COURSE ID: "+CID+"']/following-sibling::a"),"Verify course id1 present."))
			{
				Thread.sleep(medium);
				Reporters.SuccessReport("Log into the 'evolvecer.com' as a faculty from step#1 verifies the  course show's changed course title", "Sucessfully logged into the 'evolvecert.com' with Roster instructor and verifies changed course Title</br>Changed Title is   :   "+newtitle.toString());
			}
			else
			{
				Reporters.failureReport("Log into the 'evolvecer.com' as a faculty from step#1 verifies the  course show's changed course title", "Failed to verify the changed course Title");
			}
			User_BusinessFunction.Logout();
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();return false;
	}
		return flag;
	}
	
	//====================================end of the Method============================================//


	public static void rostersubmission()throws Throwable
	{
		try{
			ImplicitWait();
			b=true;
			type(ElsevierObjects.txtcourseID,CID,"Enter unique courseId in the 'CourseID' TextField and ");
			Thread.sleep(low);
			b=false;
			driver.findElement(ElsevierObjects.txtArea).clear();
			driver.findElement(ElsevierObjects.txtArea).sendKeys(newSdetails);		
			Thread.sleep(high);
			if(click(ElsevierObjects.btnpreiviewroster,"click on preview and Roster")){
				Reporters.SuccessReport("Enter student info in rosterfield and submit", "Successfully Enter the student info from Step #2 into the roster text box in the format of:<br/> 'Last Name, First Name, Email Address' and </br> clicked on 'Preview Roster & Assign Roles' button then </br> User is brought to a second screen that shows<br/> the user listed with a dropdown next to the username to assign a role to the enrolled.");
			}else{
				Reporters.failureReport("Enter student info in rosterfield and submit", "unable to click on 'Preview Roster & Assign Roles' button");	
			}
			b=true;
			selectByValue(ElsevierObjects.Role_selection, "student", "Select the Student("+newSName+") role as a 'STUDENT'");
			b=false;
			Thread.sleep(low);
	
			if(click(ElsevierObjects.Email_only_me,"selecting the 'Email the roster to only me and I will distribute the usernames & passwords to my students.' radio button")){
				Reporters.SuccessReport("select Radio button", " successfully selecting the 'Email the roster to only me and I will distribute the usernames & passwords to my students.' radio button");
			}
			else{
				Reporters.failureReport("select Radio button", "successfully selecting the 'Email the roster to only me and I will distribute the usernames & passwords to my students.' radio button");
			}
	
			if(click(ElsevierObjects.btnsubmitroster,"click on the 'Submit this Roster' Button"))
			{
				Reporters.SuccessReport("click on Submit roster button", "Successfully clicked on the 'Submit This Roster'Button");
			}
			else
			{
				Reporters.failureReport("click on Submit roster button", "failed to click on 'Submit This Roster'Button");
			}
			String CourseCode=ReadingExcel.columnDataByHeaderName("CourseId","TC-15565",configProps.getProperty("TestData"));
			String successMsg="Success!";
			String s=getText(ElsevierObjects.sucess_Message,"Verify the success message");
			if(s.contains(CourseCode)&&s.contains(successMsg))
			{
				Thread.sleep(medium);
				Reporters.SuccessReport("Verify Success Message","User will see a success message   :   "+s);
			} else{
				Reporters.failureReport("Verify Success Message","User will unable to see a success message   :   "+s);	
			}
			click(ElsevierObjects.Roster_done,"Click on Done button");
			User_BusinessFunction.Logout();
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
		}
	}
	
	
	
	//====================================end of the Method============================================//
	
	
	
	public static void stuRelogin()throws Throwable
	{
		try{
			if(User_BusinessFunction.Studentlogin(newSName, newSPwd))
			{
				Reporters.SuccessReport("Login with the created student in Step #2. ", "Successfully log into the evolve cert as a student created in step#2<br> the Username is   :   "+newSName);
			}
			else
			{
				Reporters.failureReport("Login with the created student in Step #2. ", "failed to log into evolve cert as a student");
			}
			b=true;
			click(ElsevierObjects.lnkevolve, "'My Evolve'tab");
			b=false;
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
	}
	}
	
	/*public static boolean verifyMyCart(String isbnInReceiptPage, String titleInReceiptPage) throws Throwable{
		boolean flag=true;
		try{
			Isbn=getText(ElsevierObjects.Student_Product_ISBN,"get isbn number.");
			title=getText(ElsevierObjects.evolve_Rview_chktitle,"Get title of book.");
			newTitle=title.split(",")[0];
			System.out.println("newTitle:"+newTitle);
			myCartPrice=getText(ElsevierObjects.evolve_Product_priceAfterRequest, "Get the product price");
			totalPriceInMyCart=getText(ElsevierObjects.evolve_AccessCode_totalprice,"Fetch total Price");
			if(Isbn.trim().contains(isbnInReceiptPage.trim()) && title.trim().contains(titleInReceiptPage.trim()) && myCartPrice.trim().contains(totalPriceInMyCart.trim()))
			{
				Reporters.SuccessReport("Verifying Product Details In My Cart Page.", "Verified ISBN:"+Isbn+",Title:"+title+",Total Price:"+totalPriceInMyCart+" is Same As Price:"+myCartPrice+" In Mycart Page.");
			}
			else{
				Reporters.failureReport("Verifying Product Details In My Cart Page.", "Failed To Verify Product details In My Cart Page: ISBN:"+Isbn+",Title:"+title+",Total Price:"+totalPriceInMyCart+" is Same As Price:"+myCartPrice+" In Mycart Page.");
			}
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return flag;*/
	//}

}




