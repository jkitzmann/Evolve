package com.cigniti.automation.BusinessFunctions;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class CreateLOUniqueCourseFaculty_15583 extends EvolveCommonBussinessFunctions{
	
	public static boolean getCourseId() throws Throwable{
		boolean flag=true;
		try{
			courseID1=getAttribute(ElsevierObjects.adoptionRequestCourseId1,"value", "Get courseId1");
			if(courseID1!=null){
				Reporters.SuccessReport("Fetching The Course ID.", "Fetched Course ID:"+courseID1);
			}
			else{
				Reporters.failureReport("Fetching The Course ID.", "Failed To Fetch Course ID");
		 
			}
			String ID=courseID1.split("_")[2];
			int IDlength=ID.length();
			System.out.println("ID:"+ID);
			System.out.println("courseID1:"+courseID1);
			ReadingExcel.updateCellInSheet(1,12,configProps.getProperty("TestData"), "TC-10410", courseID1);
	
		
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
		return flag;
	}
	
	
	public static boolean verifyLOStatusAfterEmailSentInARPage(String statusAfterEmailSent,String productId,String username) throws Throwable{
		boolean flag=true;
		try{
			 courseID1=getAttribute(ElsevierObjects.adoptionRequestCourseId1,"value", "Get courseId1");
			 String ID=courseID1.split("_")[2];
			 int IDlength=ID.length();
			 System.out.println("ID:"+ID);
			 System.out.println("courseID1:"+courseID1);
			
			 ReadingExcel.updateCellInSheet(1,12,configProps.getProperty("TestData"), "TC-10410", courseID1);
			
			 String adoptionrequeststatus=getText(ElsevierObjects.adoptionRequestFulfillStatus,"");
			// if(adoptionrequeststatus.contains(statusAfterEmailSent) && courseID1.contains("("+productId+")"+"_"+"("+username+")"+"_"+"([0-9])")){
			 if(adoptionrequeststatus.equals(statusAfterEmailSent) && courseID1.contains(productId) && IDlength==4){
				 Reporters.SuccessReport("Verifying Status After Sending Email.</br>Fetching CourseId's And Verifying Course ID Format.", "Successfully Verified Status:"+statusAfterEmailSent+" after sending email.</br>Fetched CourseId's:"+courseID1+"</br>Succesfully Verified Course ID Format (productID)_(instructorname on the AR)_(4 digit number):"+courseID1);
				}
			 else{
					Reporters.failureReport("Verifying Status After Sending Email.</br>Fetching CourseId's And Verifying Course ID Format.", "Failed To Verify Status:"+statusAfterEmailSent+" after sending email.</br>Failed To Verify Course ID Format (productID)_(instructorname on the AR)_(4 digit number):"+courseID1); 
			 }
			}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
			return flag;
		}
	
	public static boolean verifyLOStatusAfterEmailSentInARPage(String sheetName,String statusAfterEmailSent,String productId,String username, int col) throws Throwable{
		boolean flag=true;
		try{
			 courseID1=getAttribute(ElsevierObjects.adoptionRequestCourseId1,"value", "Get courseId1");
			 String ID=courseID1.split("_")[2];
			 int IDlength=ID.length();
			 System.out.println("ID:"+ID);
			 System.out.println("courseID1:"+courseID1);
			
			 ReadingExcel.updateCellInSheet(1,col,configProps.getProperty("TestData"), sheetName, courseID1);
			
			 String adoptionrequeststatus=getText(ElsevierObjects.adoptionRequestFulfillStatus,"");
			// if(adoptionrequeststatus.contains(statusAfterEmailSent) && courseID1.contains("("+productId+")"+"_"+"("+username+")"+"_"+"([0-9])")){
			 if(adoptionrequeststatus.equals(statusAfterEmailSent) || courseID1.contains(productId)){
				 Reporters.SuccessReport("Verifying Status After Sending Email.</br>Fetching CourseId's And Verifying Course ID Format.", "Successfully Verified Status:"+statusAfterEmailSent+" after sending email.</br>Fetched CourseId's:"+courseID1+"</br>Succesfully Verified Course ID Format (productID)_(instructorname on the AR)_(4 digit number):"+courseID1);
				}
			 else{
					Reporters.failureReport("Verifying Status After Sending Email.</br>Fetching CourseId's And Verifying Course ID Format.", "Failed To Verify Status:"+statusAfterEmailSent+" after sending email.</br>Failed To Verify Course ID Format (productID)_(instructorname on the AR)_(4 digit number):"+courseID1); 
			 }
			}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
			return flag;
		}
	
	public static boolean verifyLOStatusInARPage(String format_LO) throws Throwable{
		boolean flag=true;
		try{
			String status=ReadingExcel.columnDataByHeaderName("Status", "TC_9804", testDataPath);
			if(getAccountDetailsFirstName.contains(adoptionRequest_FirstName) && getAccountDetailsLastName.contains(adoptionRequest_LastName) && getAccountDetailsEmail.contains(adoptionRequest_Email) && /*getAccountDetailsInstitution.contains(adoptionRequest_Institution) &&*/ getAccountDetailsPhone.contains(adoptionRequest_Phone) && getAccountDetailsUserName.contains(adoptionRequest_Username) && password.contains(adoptionRequest_Password) && getAccountDetailsCountry.contains(adoptionRequest_Country)){
				Reporters.SuccessReport("Verifying The User Information In Matches That Of Instructor.", "Verified Firstname:"+adoptionRequest_FirstName+",Lastname:"+adoptionRequest_LastName+",Email:"+adoptionRequest_Email+",Institution:"+adoptionRequest_Institution+",Username:"+adoptionRequest_Username+",Password:"+adoptionRequest_Password+",Phone:"+adoptionRequest_Phone+",Country:"+adoptionRequest_Country+",Adress:"+adoptionRequest_Adress);
			}
			else{
				Reporters.failureReport("Verifying The User Information In Matches That Of Instructor.", "Failed To Verify User Details In Adoption Request Details Page.");
			}
			if(title.contains(adoptionRequest_producttitle) || Isbn.contains(adoptionRequest_Isbn) || author.contains(adoptionRequest_Author) /*&& productType.contains(adoptionRequest_ProductType)*/ || adoptionRequest_Format.contains(format_LO)){
				
				Reporters.SuccessReport("Verifying the product information is correct per the online course ordered ", "Verified ISBN:"+adoptionRequest_Isbn+",Title:"+adoptionRequest_producttitle+",ProductType:"+adoptionRequest_ProductType+",Author:"+adoptionRequest_Author+",Format:"+adoptionRequest_Format);
			}
			else{
				Reporters.failureReport("Verifying the product information is correct per the online course ordered ", "Failed To Verify the product information is correct per the online course ordered.");
			}				
			if(verifyText(ElsevierObjects.adoptionRequestStatus, status, "Verify request status.")){
				Reporters.SuccessReport("Verifying Adoption Request Status.", "Verified Adoption Request "+status+" Status.");
			}
			else{
				Reporters.failureReport("Verifying Adoption Request Status.", "Failed To verify Adoption Request Status.");
			}
			System.out.println("adoptionRequest_Comment:"+adoptionRequest_Comment);
			System.out.println("comment:"+comment);
			System.out.println("adoptionRequest_CourseContent:"+adoptionRequest_CourseContent);
			System.out.println("evolveContent:"+evolveContent);
			System.out.println("adoptionRequest_Enrollment:"+adoptionRequest_Enrollment);
			System.out.println("enrollment:"+enrollment);
			String changeStatus=ReadingExcel.columnDataByHeaderName("changeStatus", "TC_9804", testDataPath);
			if(adoptionRequest_Comment.trim().contains(comment.trim()) && adoptionRequest_CourseContent.trim().contains(evolveContent.trim()) && adoptionRequest_Enrollment.trim().contains(enrollment.trim())){
				Reporters.SuccessReport("Verifying CourseContent,Enrollment,Customer Comment in Adoption Request Details Page.","Successfully Verified Content:"+adoptionRequest_CourseContent+",Enrollment:"+adoptionRequest_Enrollment+",Customer comment:"+adoptionRequest_Comment);
			}
			else{
				Reporters.failureReport("Verifying CourseContent,Enrollment,Customer Comment in Adoption Request Details Page.", "Failed To Verify CourseContent,Enrollment,Customer Comment in Adoption Request Details Page.");
			}
			selectByVisibleText(ElsevierObjects.adoptionRequestStatus, changeStatus, "Change status to fulfilled.");
			Thread.sleep(medium);				
			if(click(ElsevierObjects.adoptionRequest_Save,"Click on Save button.")){
				Reporters.SuccessReport("Selecting "+changeStatus+" Status from dropdown.</br>Clicking On Save Button", "Successfully Selected Status:"+changeStatus+" from Dropdown.</br>Clicked On Save Button.</br>User is shown a pop up regarding if an email should be sent.");
			}
			else{
				Reporters.failureReport("Selecting "+changeStatus+" Status from dropdown.</br>Clicking On Save Button", "Failed To Change Status from dropdown.</br>Failed To Click On Save Button.");
			}
			Thread.sleep(high);
			//ImplicitWait();
			if(javaClick(ElsevierObjects.emailPopup,"Click on Send mail button on popup.")){
				Reporters.SuccessReport("Clicking On Send Mail Button In Email Popup.", "Successfully Clicked On Send Mail Button in Email Popup.</br>The Page is Refreshed After Send Email Button Is Clicked.");
			}else{
				Reporters.failureReport("Clicking On Send Mail Button In Email Popup.", "Failed To Click On Send Email Button In Email Popup.");
			}
			Thread.sleep(high);
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
		return flag;
	}
}

