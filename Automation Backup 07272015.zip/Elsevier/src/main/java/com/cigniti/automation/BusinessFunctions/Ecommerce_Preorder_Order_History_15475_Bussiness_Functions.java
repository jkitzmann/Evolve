package com.cigniti.automation.BusinessFunctions;

import org.openqa.selenium.By;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class Ecommerce_Preorder_Order_History_15475_Bussiness_Functions  extends Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions{

	public void checkOrderDetails() throws Throwable{
		try{
		String StreetAddress=ReadingExcel.columnDataByHeaderName("StreetAddress","TC-15588",configProps.getProperty("TestData"));
		String isbn=ReadingExcel.columnDataByHeaderName("product", "TC-15471", testDataPath);
		String Zipcode=ReadingExcel.columnDataByHeaderName("ZipCode","TC-15588",configProps.getProperty("TestData"));
		 
		 String CityAddress=ReadingExcel.columnDataByHeaderName("CityAddress", "TC-15588",configProps.getProperty("TestData"));
		 String StateAddress=ReadingExcel.columnDataByHeaderName("StateAddress","TC-15588",configProps.getProperty("TestData"));
		
		if(!javaClick(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
			flag = false;
		}
		Thread.sleep(medium);
		
		stepReport("Search for modified product and click Pre-Order button");
		searchAndGo(isbn);
		String message=getText(By.xpath(".//*[@id='tab-relayout']/div/div[5]/div[1]"), "product availability date");
		Thread.sleep(low);
		if(message!=null){
			Reporters.SuccessReport("Product availability date details", "The product availability date is successfully displayed <br> "+message);
		}
		
		System.out.println(message);
		Thread.sleep(medium);
		click(ElsevierObjects.ReserveBtn, "Click on the Pre Order Button");
		Thread.sleep(medium);
		
		stepReport("Verify the preorder message and enter checkout");
		String message1=getText(By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class,'notification_box rounded')]"), "");
		Thread.sleep(low);
		System.out.println(message1);
		if(message1!=null){
			Reporters.SuccessReport("Verify below message is displayed in the notification box on My Cart page", "The message is displayed in the notification box on My Cart page<br>"+message1);
		}else{
			Reporters.failureReport("Verify below message is displayed in the notification box on My Cart page", "The message is not displayed in the notification box on My Cart page<br>"+message1);
		}
		click(ElsevierObjects.checkoutBtn, "Click on the Checkout Button");
		Thread.sleep(medium);
		/*String message2=getText(By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class,'notification_box rounded')]"), "");
		System.out.println(message1);
		if(message1!=null){
			Reporters.SuccessReport("Publication message", "themessage is printed in the Confirmation page<br>"+message2);
		}else{
			Reporters.failureReport("publication message", "the message is not presnt");
		}
		*/
		
		stepReport("Complete checkout");
		click(ElsevierObjects.Student_Register_Chk, "Click on no institution checkbox");
		Thread.sleep(medium);
		
		 type(ElsevierObjects.student_billingAddress,StreetAddress,"Enter the Street Address in the box");
		 Thread.sleep(medium);
	     type(ElsevierObjects.student_billingAddress_city,CityAddress,"Enter City in the textbox");
	     Thread.sleep(medium);
	     selectByVisibleText(ElsevierObjects.student_billingAddress_state,StateAddress,"Enter State in the textbox");
	     Thread.sleep(medium);
	     type(ElsevierObjects.student_billingAddress_zip,Zipcode,"Enter Zipcode in the textbox");
	     Thread.sleep(medium);
	     Reporters.SuccessReport("Enter and click","billing address is entered successfully and Details entered in billing address:</br>"+"Street Address :"+StreetAddress+"</br>"+"CityAddress :"+CityAddress+"</br>"+"StateAddress :"+StateAddress+ "</br>"+"Zipcode :"+Zipcode);
	     click(ElsevierObjects.educator_form_btnContinue,"Click on continue button");
		 Thread.sleep(medium);
		 switchToFrameByLocator(ElsevierObjects.Admin_Evolve_Ecom_framename,"Switch to iframe");
		 Thread.sleep(medium);
		 String Popupheader = ReadingExcel.columnDataByHeaderName("PopUp", "TC-15588",configProps.getProperty("TestData"));
		 String Popheader = getText(ElsevierObjects.Popup_header,"Get header of the frame");
		 if(Popheader.contains(Popupheader)){
			 Reporters.SuccessReport("Verify the header of Frame","PopupHeader is Successfully verified : </br> Expected Header is :"+Popheader+" </br> Actual Header is :"+Popupheader);
		 }else{
			 Reporters.failureReport("Verify the header of Frame","Failed to verify headers : </br> Expected Header is :"+Popheader+" </br> Actual Header is :"+Popupheader);
		 }
		 Thread.sleep(medium);
		 if(click(ElsevierObjects.Use_this_address,"Click on use this address")){
			 Reporters.SuccessReport("Click on Use this Address","Successfully clicked on Use this Address");
		 }else{
			 Reporters.failureReport("Click on Use this Address","Failed to click on Use this Address");
		 }
		 Thread.sleep(medium);
		 String Creditheader = ReadingExcel.columnDataByHeaderName("Creditheader", "TC-15588",configProps.getProperty("TestData"));
		 String cardheader = getText(ElsevierObjects.Creditcard_header,"Get header of the Page");
		 if(cardheader.contains(Creditheader)){
			 Reporters.SuccessReport("Verify the header of page","Creditcard Header is Successfully verified : </br> Expected Header is :"+cardheader+" </br> Actual Header is :"+Creditheader);
		 }else{
			 Reporters.failureReport("Verify the header of page","Failed to verify headers : </br> Expected Header is :"+cardheader+" </br> Actual Header is :"+Creditheader);
		 }
		 Thread.sleep(medium);
		 if(creditCardDetails()){
			Reporters.SuccessReport("Enter Details and verify","Creditcard details are entered and User is Successfully taken to Review and Submit Page"); 
		 }else{
			 Reporters.failureReport("Enter Details and verify","User is Failed to enter creditcard details and to take Review and Submit page");
		 }
		 Thread.sleep(high);
		 String message4=getText(By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class,'notification_box rounded')]"), "");
		 Thread.sleep(low);
		 if(message4!=null){
				Reporters.SuccessReport("Verify below message is displayed in the notification box on Review/Submit page", "The message is displayed in the notification box on Review/Submit page<br>"+message4);
			}else{
				Reporters.failureReport("Verify below message is displayed in the notification box on Review/Submit page", "The message is not displayed in the notification box on Review/Submit page<br>"+message4);
			}
		
		 Thread.sleep(medium);
		 
		 stepReport("Submit order and verify receipt page");
		 click(ElsevierObjects.Student_accept_chk, "Accept Checkbox");
		 Thread.sleep(medium);
		 click(ElsevierObjects.Student_Review_Submit, "Review Submit");
		 Thread.sleep(medium);
		 String message3=getText(By.xpath(".//*[@id='pageLayout-body-inner-most']//div[contains(@class,'notification_box rounded')]"), "");
		 if(message3!=null){
				Reporters.SuccessReport("Verify below message is displayed in the notification box on Confirmation page", "The message is displayed in the notification box on Confirmation page<br>"+message3);
			}else{
				Reporters.failureReport("Verify below message is displayed in the notification box on Confirmation page", "The message is not displayed in the notification box on Confirmation page<br>"+message3);
			}
			
		 Thread.sleep(medium);
		
		 stepReport("Verify preorder in order history");
		 if(!click(ElsevierObjects.Catalog_Header_Link, "Click on Catalog")){
				flag=false;
			}
		 
		 if(click(ElsevierObjects.Ecert_Admin_MyAcc, "My Account")){
			Reporters.SuccessReport("Click on My Account link", "Successfully clicked on the My Account link");
		}else{
			Reporters.failureReport("Click on My Account link", "Failed to click on the My Account link");
		}
		Thread.sleep(medium);

		if(click(ElsevierObjects.MYACCOUNT_ORDERHISTORY, "Order History")){
			Reporters.SuccessReport("Click on Order History link.", "Successfully clicked on Order History link.");
		}else{
			Reporters.failureReport("Click on Order History link.", "Failed to click on Order History link.");
		}
		Thread.sleep(medium);

		String orderMessage = getText(By.xpath("//*[@id='pageLayout-body-inner-most']/div/div/div[2]/div/div[2]/div/div[2]/div[3]/div"), "");
		Thread.sleep(low);
		if(orderMessage.contains("This item is not yet available")){
			Reporters.SuccessReport("Verify order Message", orderMessage);
		}else{
			Reporters.failureReport("Verify Order Message", orderMessage);
		}
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(sgErrMsg="error occurred"+e);
		}
	}
	
}
