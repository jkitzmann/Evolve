package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.Evolve_StudentLogin_9795;
import com.cigniti.automation.BusinessFunctions.LO_GlobalStudent_8571;
import com.cigniti.automation.BusinessFunctions.LO_SelfStudy;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class LO_SelfStudy_Script extends LO_SelfStudy {

	@Test 
	public void selfStudy() throws Throwable{
		try {
			stepReport("Create new student user");
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			if(CreateNewUser(ElsevierObjects.STUDENT))
			{
	     		Reporters.SuccessReport("Login into Application ", "Successfully logged in as Faculty user");
			}
			else
			{
				Reporters.failureReport("Login into Application ", "Failed to login as Faculty user");
			}
			
			stepReport("Search for product and add to cart");
			if(searchProduct())
			{
	     		Reporters.SuccessReport("Search Product ", "Successfully searched product.");
			}
			else
			{
				Reporters.failureReport("Search Product ", "Failed to search product.");
			}	

			if(addProductToCart())
			{
	     		Reporters.SuccessReport("Add product to cart ", "Successfully added product to cart.");
			}
			else
			{
				Reporters.failureReport("Search Product ", "Failed to added product to cart.");
			}
			
			stepReport("Complete checkout and submit order");
			if(LO_GlobalStudent_8571.checkOut())
			{
	     		Reporters.SuccessReport("CheckOut ", "Successfully CheckOut.");
			}
			else
			{
				Reporters.failureReport("CheckOut ", "Failed to CheckOut.");
			}

			if(formFill(ElsevierObjects.STUDENT))
			{
	     		Reporters.SuccessReport("Fill update user form ", "Successfully filled 'update user form'.");
			}
			else
			{
				Reporters.failureReport("Fill update user form ", "Failed to fill 'update user form'.");
			}
			
			if(verifyBillingAddress())
			{
	     		Reporters.SuccessReport("Click 'Use This Address' button", "Successfully clicked 'Use This Address' button.");
			}
			else
			{
				Reporters.failureReport("Fill update user form ", "Failed to click 'Use This Address' button.");
			}			
			
			if(Evolve_StudentLogin_9795.evolve_StudentCreditCardDetails())
			{
	     		Reporters.SuccessReport("Click 'Use This Address' button", "Successfully clicked 'Use This Address' button.");
			}
			else
			{
				Reporters.failureReport("Fill update user form ", "Failed to click 'Use This Address' button.");
			}
			
			if(LO_GlobalStudent_8571.submitOrder(ElsevierObjects.STUDENT))
			{
	     		Reporters.SuccessReport("Submit Order ", "Successfully submitted order.");
			}
			else
			{
				Reporters.failureReport("Submit Order ", "Failed to submitt order.");
			}
			
			stepReport("Verify course link and content");
			if(verifyCourseListContainsCourseID())
			{
	     		Reporters.SuccessReport("Should see  the resource in user's content list ", "Successfully added course to user's content list.");
			}
			else
			{
				Reporters.failureReport("Should see  the resource in user's content list ", "Failed to added course to user's content list.");
			}
							
			if(clickContentLink())
			{
	     		Reporters.SuccessReport("Click on content link ", "Successfully opened content link page.");
			}
			else
			{
				Reporters.failureReport("Click on content link ", "Failed to open content link page.");
			}
			
			if(verifyCourseTitle())
			{
	     		Reporters.SuccessReport("Verify the course title ", "Successfully displayed course title.");
			}
			else
			{
				Reporters.failureReport("Verify the course title ", "Failed to display course title.");
			}	
			
			if(verifyResourcesSubFoldersVisible())
			{
	     		Reporters.SuccessReport("Verify Subfolders ", "Successfully displayed Subfolders.");
			}
			else
			{
				Reporters.failureReport("Verify Subfolders ", "Failed to display Subfolders.");
			}	
			
			if(openResourcesSubFoldersVisible())
			{
	     		Reporters.SuccessReport("Open Subfolders ", "Successfully opened Subfolders.");
			}
			else
			{
				Reporters.failureReport("Open Subfolders ", "Failed to opened Subfolders.");
			}
			
			stepReport("Verify student appears in Course PAR Report");
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			if(evolveAdminlogin())
			{
	     		Reporters.SuccessReport("Login as admin user ", "Successfully logged in admin user.");
			}
			else
			{
				Reporters.failureReport("Login as admin user ", "Failed to logged in admin user.");
			}

			if(searchCourseParReport())
			{
	     		Reporters.SuccessReport("Search course par ", "Successfully search course par for user.");
			}
			else
			{
				Reporters.failureReport("Search course par ", "Failed to search course par for user.");
			}
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}

