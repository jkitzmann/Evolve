package com.cigniti.automation.Test;

import java.util.Random;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.Add_Administrators_UI_15476;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;

public class Add_Administartors_UI_Script_15476 extends Add_Administrators_UI_15476 {
  @Test
  public static void Add_Administrator_UI_15476() throws Throwable{
	  
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			Firstname=ReadingExcel.columnDataByHeaderName("Firstname","TC-15476",configProps.getProperty("TestData"));
			Lastname=ReadingExcel.columnDataByHeaderName("Lastname","TC-15476",configProps.getProperty("TestData"));
			Random ra = new Random(System.currentTimeMillis());
		    EmailId = ReadingExcel.columnDataByHeaderName("EmailId","TC-15476",configProps.getProperty("TestData"))+Integer.toString((1 + ra.nextInt(2)) * 1000 + ra.nextInt(1000))+"@evolveqa.info";
		    Random r = new Random(System.currentTimeMillis());
		    Username = ReadingExcel.columnDataByHeaderName("Username","TC-15476",configProps.getProperty("TestData"))+Integer.toString((1 + r.nextInt(2)) * 1000 + r.nextInt(1000));
			Password=ReadingExcel.columnDataByHeaderName("Password","TC-15476",configProps.getProperty("TestData"));
			
		   stepReport("Login to Evolve Admin.");
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to EvolveAdmin page with the User Credentials",
				                                                         "Successfully login to EvolveAdmin page with the User Credentials",
				                                                         "Failed to login the EvolveAdmin page with the User Credentials");
		   
			stepReport("Add Administrators.");
			Add_Administrators_UI_15476.AddAdministrators();
		   Thread.sleep(low);
		   
		   stepReport("Manage Administrators.");
		   writeReport(Add_Administrators_UI_15476.ManageAdministrators(),"Enter the Manage Administrator",
		    		                                                       "Successfully Entered Manage Administrators and Verified the details",
		    		                                                       "Failed to Enter Manage Administrators verify the details");
		   
		   stepReport("Edit existing administrator.");
		   writeReport(Add_Administrators_UI_15476.EditAdministrator(),"Enter the Edit page with username and verify details",
		    		                                                    "Successfully Entered the Edit Administrator page and verified the details",
		    		                                                    "Failed to enter Edit Administrator page and verify the details"); 
		   writeReport(EvolveCommonBussinessFunctions.adminLogout(),"Logout from EvolveAdmin page",
		    		                                                  "Successfully loggedout from EvolveAdmin page",
		    		                                                  "Failed to logout from EvolveAdmin page");
	       
		   stepReport("Login as new administrator.");
		   writeReport(Add_Administrators_UI_15476.login(),"Login with the created username and verify the elements",
		    		                                        "Successfully login with the Created Username and verified the details </br> Username : "+Username+ "</br>"+"Password : " +Password,
		    		                                        "Failed to login with the Created Username and verify the details");
	      writeReport(EvolveCommonBussinessFunctions.adminLogout(),"Logout from EvolveAdmin page",
                                                                   "Successfully loggedout from page and User is taken to Evolve Admin log in page.",
                                                                   "Failed to logout from EvolveAdmin page");
  }
} 
