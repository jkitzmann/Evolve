package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.ConvertLOTrialCoursetoPermanentPending_15566;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseFulfillmentfromSearchResultsPage_LO_15100;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentFaculty_15243;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101;
import com.cigniti.automation.BusinessFunctions.LO_Global_Instructor_AR_8572;
import com.cigniti.automation.BusinessFunctions.LO_Unique_CourseFulfillment_Faculty_10410;
import com.cigniti.automation.BusinessFunctions.LO_Unique_CourseFulfillment_Faculty_15586;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;

public class LOUniqueCourseTrialFulfillmentFaculty_15243_Script extends LOUniqueCourseTrialFulfillmentFaculty_15243{

@Test
public static void LOUniqueCourseTrialFulfillmentFaculty_15243() throws Throwable{
	
try{
	String adminUser=configProps.getProperty("AdminUser");
	emailID=getAccountDetailsEmail;
	iSBN=ReadingExcel.columnDataByHeaderName("iSBN","TC-15101", configProps.getProperty("TestData")) ;
	product=iSBN;
	KNOIsbn=iSBN;
	requestText=ReadingExcel.columnDataByHeaderName("requestText","TC-15101", configProps.getProperty("TestData"));
	String statusAfterEmailSent=ReadingExcel.columnDataByHeaderName("verifyStatusAfterEmailSent", "TC-15101", configProps.getProperty("TestData"));
	String productId=ReadingExcel.columnDataByHeaderName("productID", "TC-15101", configProps.getProperty("TestData"));
	String format_LO=ReadingExcel.columnDataByHeaderName("format_LO", "TC-15101", configProps.getProperty("TestData"));
	TrialStatus=ReadingExcel.columnDataByHeaderName("trialStatus","TC-15101", configProps.getProperty("TestData"));
	checkTrialStatus=ReadingExcel.columnDataByHeaderName("checkTrialStatus","TC-15101", configProps.getProperty("TestData"));
	String startDate=ReadingExcel.columnDataByHeaderName("StartDate","TC-15101", configProps.getProperty("TestData"));
	
	//TestData to Check MIlestone Data in Adoption Request Page
	compareStartDate=ReadingExcel.columnDataByHeaderName("comapreStartDate","TC-15101", configProps.getProperty("TestData"));
	compareEmailTemplateStartDate=ReadingExcel.columnDataByHeaderName("EmailTemlateocTrial","TC-15101", configProps.getProperty("TestData"));
	compareEmailTemplateWarning1=ReadingExcel.columnDataByHeaderName("EmailTemlatewarning1","TC-15101", configProps.getProperty("TestData"));
	compareEmailTemplateWarning2=ReadingExcel.columnDataByHeaderName("EmailTemlatewarning2","TC-15101", configProps.getProperty("TestData"));
	compareEmailTemplateEnd=ReadingExcel.columnDataByHeaderName("EmailTemlateendDate","TC-15101", configProps.getProperty("TestData"));
	unEnrollDays=ReadingExcel.columnDataByHeaderName("unEnrollDays","TC-15101", configProps.getProperty("TestData"));
	warning1Days=ReadingExcel.columnDataByHeaderName("daysWarning1","TC-15101", configProps.getProperty("TestData"));
	wraning2Days=ReadingExcel.columnDataByHeaderName("daysWarning2","TC-15101", configProps.getProperty("TestData"));
	endDays=ReadingExcel.columnDataByHeaderName("endDays","TC-15101", configProps.getProperty("TestData"));
	
	String DayTrial=ReadingExcel.columnDataByHeaderName("TRialLink","TC-15101", configProps.getProperty("TestData"));

	TrialEmailTitle=ReadingExcel.columnDataByHeaderName("emailTitle", "TC-15101", configProps.getProperty("TestData"));
	
	
	//*************************************************************************************************************************************************************//

	stepReport("Login to Evolve Admin");
	SwitchToBrowser(ElsevierObjects.adminBrowserType);
	writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login to Application Using Admin Credentials"+adminUser,
			"Launching the URL for Admin is successful </br > Login to Application Using Admin credentials :"+adminUser+" is Successful", 
			"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");
	
	stepReport("Edit product and verify trial dates");
	writeReport(LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.maintainProductLink(iSBN), "Clicking Maintain products link in Admin Page And Searching For ISBN:"+iSBN, 
																									"Successfully Clicked on Maintain Product Link in Admin Page. </br> Successfully entered ISBN:"+iSBN+" in Search box. </br> Successfully Clicked on Search Button.</br>Successfully Navigated To Product Search Result Page.", 
																									"Failed to Click on Maintain Product Link in Admin page.</br>Failed To Search For ISBN:"+iSBN);
	writeReport(LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.f_prodLinkInMaintainProductPage(), "Clicking F-Prod link in Product Search Result Page.",
																											 "Successfully Clicked on F-prod link in Product Search Result Page.",
																											 "Failed to Click on F-Prod Link in Product Serarch Result Page.");
	
	String value="Start Date";
	LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.compareStartDtaeTrialReg(value,startDate,compareEmailTemplateStartDate);
	String warning1="Warning 1";
	LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.f_productionTrialRegistrationTable(warning1,warning1Days,compareEmailTemplateWarning1);
	String warning2="Warning 2";
	LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.f_productionTrialRegistrationTable(warning2,wraning2Days,compareEmailTemplateWarning2);
	String end="End Date";
	LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.f_productionTrialRegistrationTable(end,endDays,compareEmailTemplateEnd);
	String unenroll="Unenroll User*";
	LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.compareUnEnrollTrialReg(unenroll,unEnrollDays);
	
	writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout.", 
															  "Successfully logged out Admin page", 
															  "Failed to logout Admin page.");
	//SwitchToBrowser(ElsevierObjects.studentBrowserType);
	stepReport("Login to Evolve as existing instructor");
	String user="educator";
	facultyUser=ReadingExcel.columnDataByHeaderName("Faculty_User", "TC-15101", configProps.getProperty("TestData"));
	facultyPwd=ReadingExcel.columnDataByHeaderName("Faculty_passWord", "TC-15101", configProps.getProperty("TestData"));
	
	writeReport(EvolveCommonBussinessFunctions.existingUserLogin(user,facultyUser,facultyPwd),"Login to Application Using User Credentials",
																						   	  "Launching the URL for User is successfull </br > Login to Application Using User Credentials :"+facultyUser+" is Successfull",
																							  "Launching and Login to Application Using User Credentials : "+ facultyUser+" is Failed");
	writeReport(EvolveCommonBussinessFunctions.getAccountDetails(),"Fetching Account Details from My Account.",
																   "Successfully Fetched account details from My Account page.",
																   "Failed to Fetch the account details from My Account page.");
	
	stepReport("Search for product and request trial");
	writeReport(EvolveCommonBussinessFunctions.searchProduct(product,productCost),"Search for the product..",
																				  "Successfully Entered ISBN:"+product+" in Search Box.</br>Clicked On Go Button.</br>Navigated To Product Details Page.",
																				  "Failed to Enter ISBN:"+product+" in Search Box.");
	LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.request30DayTrial();
	searchTrial="true";
	
	stepReport("Verify My Cart page and submit order");
	LOUniqueCourseTrialFulfillmentfromSearchResultsPageScript_15101.Mycart(searchTrial,DayTrial);
	accessCode="false";
	LO_Unique_CourseFulfillment_Faculty_10410.userReviewSubmit(searchTrial,DayTrial);
	
	stepReport("Verify receipt page");
	LO_Unique_CourseFulfillment_Faculty_10410.receiptPage(searchTrial,DayTrial);

	writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the educator:"+facultyUser, 
																	"Successfully logged out the educator:"+facultyUser, 
																	"Failed to logout the educator page:"+facultyUser);
	//****************************Title Verification In Email After Requesting The Product*************************************//

	//SwitchToBrowser("chrome");
	stepReport("Verify email");
	writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Login In Into Evolve Email Page.", 
															  "Successfully login into Evolve Email Page.", 
															  "Failed to login into Evolve Email Page.");
	String emailid=EvolveCommonBussinessFunctions.getAccountDetailsEmail;
	writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(emailid),"Search email in evolve webmail.",
												"Successfully entered the emailid "+emailid+" in search box.",
												"Failed to enter email id.");
	trial="true";
	LOUniqueCourseTrialFulfillmentFaculty_15243.verifyEmailBodyAfterRequestProduct(trial);
	
	//****************************************Verifying User Details In ADMIN*************************************************//

	//SwitchToBrowser(ElsevierObjects.adminBrowserType);
	
	stepReport("Login to Evolve Admin");
	writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login to Application Using Admin Credentials :"+adminUser,
			"Launching the URL for Admin is successful </br > Login to Application Using Admin credentials :"+adminUser+" is Successful", 
			"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");
	
	stepReport("Search for AR and verify trial status");
	LO_Global_Instructor_AR_8572.admin_Adoptionsearch();
	
	/*writeReport(EvolveCommonBussinessFunctions.clickAdoptionRequest(),"Clicking on Search Adoption request link in Admin page.",
			  "Successfully clicked on Search Adoption Requests link.</br>Successfully Selected Today Radio Button In Adoption Request Page.</br>Successfully Clicked On Search Button</br>Navigated To Adoption Search Results Page.",
			  "Failed to click on Search Adoption Requests link.</br>Failed To Select Today Radio Button In Adoption Request Page.</br>Failed To Navigate To Adoption Search Results Page.");*/
	
	writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.verifyTrial(), "Verifying Trial status in Adoption Search Results Page.", 
																			"Successfully verified the Trial Status in Adoption Search Results Page.", 
																			"Failed to verify the Trial Status in Adoption Search Results Page");	
	
	writeReport(EvolveCommonBussinessFunctions.getAdoptionRequestDetails(),"Clicking On Adoption Number.</br>Fetching Adoption Details of User and Course in Adoption Request Details page",
			   "Adoption Number:"+adoptionRequest_getAdoptionNum+" is On Top Of The Row.</br>Successfully Clicked On "+adoptionRequest_getAdoptionNum+"</br>Successfully Fetched the details of User And Course from Adoption Request Details Page.",
			   "Failed To Click On Adoption Number:"+adoptionRequest_getAdoptionNum+"</br>Failed to Fetch the details of User And Course from Adoption Request Details Page.");
														
	LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.verifyTrialLOStatus(format_LO);
	
	writeReport(ConvertLOTrialCoursetoPermanentPending_15566.adoptionRequestVerifyMIlestonesData(),"Verifying the Trial MIlestones section within the Adoption Request Details page is as expected.",
			"Successfully Verified Milestone Data.</br> StartDate:"+compareStartDate+",Email Temaplate:"+compareEmailTemplateStartDate+"</br>Warning1:"+warning1Days+",Email Temaplate:"+compareEmailTemplateWarning1+"</br>,Warnimg2:"+wraning2Days+",Email Temaplate:"+compareEmailTemplateWarning2+"</br>,EndDate:"+endDays+",Email Temaplate:"+compareEmailTemplateEnd+"</br>Unenroll User:"+unEnrollDays,
			"Failed To Verify Milestone Data.");
	
	stepReport("Fulfill AR");
	writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.changeStatusAndEmailPopup(statusAfterEmailSent),"Verifying course details after email sent in Adoption Request Details page",
			  "Successfully verified course details after email sent in Adoption Request page.",
			  "Failed to verify course details after email sent in Adoption Request page.");
	
	LOUniqueCourseFulfillmentfromSearchResultsPage_LO_15100.getCourseId(statusAfterEmailSent,productId,facultyUser);
	
	LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.adoptionRequestVerifyMIlestoneDateformat(compareStartDate);
	
	writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout.", 
			  "Successfully logged out admin page.", 
			  "Failed to logout admin page.");
	
	//**************************Verifying Title After Fulfilling The Request**********************************************************//

	//SwitchToBrowser("chrome");
	stepReport("Verify email");
	writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Login In Into Evolve Email Page.", 
			  "Successfully login into Evolve Email Page.", 
			  "Failed to login into Evolve Email Page.");
	
	//emailid=EvolveCommonBussinessFunctions.getAccountDetailsEmail;
	writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(emailid),"Search email in evolve webmail.",
				"Successfully entered the emailid "+emailid+" in search box.",
				"Failed to enter email id.");
	String EmailTitleAfterFullfilled=ReadingExcel.columnDataByHeaderName("trialEmailTitleAfterFullfilled", "TC-15101", configProps.getProperty("TestData"));

	
	LOUniqueCourseTrialFulfillmentFaculty_15243.verifyEmailBodyAfterRequestFullfill(EmailTitleAfterFullfilled);
  
	//**********************************Searching For Course ID In Faculty Page Generated In ADMIN After Fulfilling The Request************************//

	//SwitchToBrowser(ElsevierObjects.studentBrowserType);
	stepReport("Login as instructor and verify course");
	facultyUserName=ReadingExcel.columnDataByHeaderName("Faculty_User", "TC-15101", configProps.getProperty("TestData"));
	facultyPassword=ReadingExcel.columnDataByHeaderName("Faculty_passWord", "TC-15101", configProps.getProperty("TestData"));
	writeReport(LO_Unique_CourseFulfillment_Faculty_10410.reLogin(facultyUserName, facultyPassword),  "Login to Application Using User Credentials",
																						    	"Launching the URL for User is successful </br > Login to Application Using User Credentials :"+facultyUserName+" is Successful",
																						    	"Launching and Login to Application Using User Credentials : "+ facultyUserName+" is Failed");
	
	String ID1="true";
	String ID2="false";
	writeReport(LO_Unique_CourseFulfillment_Faculty_10410.courseIDSearch(ID1,ID2),"Verifying course ID's generated in Admin page are in Educator page or not.",
																	  "Successfully verified CourseId "+courseID1+". </br> Clicked on "+courseID1+".", 
																	  	"Failed to verify CourseId "+courseID1);
	
	// Looks like course materials are sometimes not available right away. Adding in a logout/relogin if it's not there yet.
	if(!isVisible(ElsevierObjects.educator_CoursePage_Courselink, "Course link")){
		EvolveCommonBussinessFunctions.instructorLogout();
		LO_Unique_CourseFulfillment_Faculty_10410.reLogin(facultyUserName, facultyPassword);
		LO_Unique_CourseFulfillment_Faculty_10410.courseIDSearch(ID1, ID2);
	}
	
	/*writeReport(LO_Unique_CourseFulfillment_Faculty_15586.courseDetailsPage(),"Verify Course details in Course Details page.",
																		"Successfully verified all course details. </br> Succesfully get the protection scheme id.",
																		"Failed to verify all course details.");*/
	LO_Unique_CourseFulfillment_Faculty_10410.courseDetailsPage(searchTrial);

	writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the educator page.", 
			"Successfully logged out the educator:"+facultyUser, 
			"Failed to logout the educator page:"+facultyUser);

}
	catch(Exception e){
		System.out.println(e);
	}
}

}
