package com.cigniti.automation.Utilities;

import java.sql.*;
import java.util.HashSet;

import com.cigniti.automation.accelerators.Actiondriver;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class Database extends Actiondriver{
	
	public static Connection getDBConnection() {
		
		try {
			
			String DB_URL = configProps.getProperty("DB_URL");
			String DB_USER = configProps.getProperty("DB_USER");
			String DB_PASS = configProps.getProperty("DB_PASS");
			String TNS_NAMES_LOC = configProps.getProperty("TNS_NAMES_LOC");
			System.setProperty("oracle.net.tns_admin", TNS_NAMES_LOC);
			Class.forName("oracle.jdbc.OracleDriver").newInstance();
			Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
			
			return conn;
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return null;
	}
	
	public static void fraudDBCleanup() throws Throwable {
		
		try {
			
			boolean flag = true;
			int i = 0, rowCount = 0;
			String[] ccIDs = new String[2];
			String[] reviewIDs = new String[2];
			String shipStateID = "", billStateID = "";
			
			// get addresses and order #s from TestData spreadsheet
			String Order1 = ReadingExcel.columnDataByHeaderName("ORDER1", "FraudTestCases", testDataPath);
			String Order2 = ReadingExcel.columnDataByHeaderName("ORDER2", "FraudTestCases", testDataPath);
			String Order3 = ""; // will retrieve this order # from database
			String ShipStreet = ReadingExcel.columnDataByHeaderName("ShipStreet", "FraudTestCases", testDataPath).toUpperCase();
			String ShipCity = ReadingExcel.columnDataByHeaderName("ShipCity", "FraudTestCases", testDataPath).toUpperCase();
			String ShipState = ReadingExcel.columnDataByHeaderName("ShipState", "FraudTestCases", testDataPath);
			String ShipZip = ReadingExcel.columnDataByHeaderName("ShipZIP", "FraudTestCases", testDataPath);
			String BillStreet = ReadingExcel.columnDataByHeaderName("BillStreet", "FraudTestCases", testDataPath).toUpperCase();
			String BillCity = ReadingExcel.columnDataByHeaderName("BillCity", "FraudTestCases", testDataPath).toUpperCase();
			String BillState = ReadingExcel.columnDataByHeaderName("BillState", "FraudTestCases", testDataPath);
			String BillZip = ReadingExcel.columnDataByHeaderName("BillZIP", "FraudTestCases", testDataPath);
			
			// setup db connection
			ResultSet rs;
			String query;
			Connection conn = getDBConnection();
			Statement statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			
			// get the evl_order_id of the child of the approved order
			stepReport("Get the evl_order_id of the child of the approved order");
			query = "select evl_order_id from evladmin.preorder_queue where parent_evl_order_id = " + Order2;
			rs = statement.executeQuery(query);
			// make sure the # of records returned = 1
			rs.last();
			rowCount = rs.getRow();
			rs.beforeFirst();
			if (rowCount == 1){
				rs.next();
				Order3 = rs.getString(1);
				Reporters.SuccessReport("Retrieve the child order id of the approved order", "Successfully retrieved the child order id of the approved order. Parent: " + Order2 + " | Child: " + Order3);
			}
			else {
				flag = false;
				Reporters.failureReport("Retrieve the child order id of the approved order", "Failed to retrieve the child order id of the approved order: " + Order2);
			}
			rowCount = 0;
			
			// get credit_card_ids from db
			stepReport("Get credit_card_id from database for both orders");
			query = "select credit_card_id from evladmin.evl_order where evl_order_id in (" + Order1 + "," + Order2 + ")";
			rs = statement.executeQuery(query);
			// make sure the # of records returned = 2
			rs.last();
			rowCount = rs.getRow();
			rs.beforeFirst();
			if (rowCount == 2){
				i = 0;
				while(rs.next()){
					ccIDs[i] = rs.getString(1);
					i++;
				}
				Reporters.SuccessReport("Retrieve credit_card_ids from database for both orders", "Successfully retrieved credit_card_ids from database for orders: " + Order1 + ", " + Order2);
			}
			else {
				flag = false;
				Reporters.failureReport("Retrieve credit_card_ids from database for both orders", "Failed to retrieve credit_card_ids from database for orders: " + Order1 + ", " + Order2);
			}
			rowCount = 0;
			
			// get evl_order_review_ids from db
			stepReport("Get evl_order_review_id from database for both orders");
			query = "select evl_order_review_id from evladmin.evl_order_review where evl_order_id in (" + Order1 + "," + Order2 + ")";
			rs = statement.executeQuery(query);
			// make sure # of records returned = 2
			rs.last();
			rowCount = rs.getRow();
			rs.beforeFirst();
			if (rowCount == 2){
				i = 0;
				while(rs.next()){
					reviewIDs[i] = rs.getString(1);
					i++;
				}
				Reporters.SuccessReport("Retrieve evl_order_review_ids from database for both orders", "Successfully retrieved evl_order_review_ids from database for orders: " + Order1 + ", " + Order2);
			}
			else {
				flag = false;
				Reporters.failureReport("Retrieve evl_order_review_ids from database for both orders", "Failed to retrieve evl_order_review_ids from database for orders: " + Order1 + ", " + Order2);
			}
			rowCount = 0;
			
			// get state ids from db
			stepReport("Get IDs of billing/shipping states from database");
			query = "select mdcuid from evladmin.evolve_state where abbr in ('" + ShipState + "','" + BillState + "')";
			rs = statement.executeQuery(query);
			// make sure # of records returned = 2
			rs.last();
			rowCount = rs.getRow();
			rs.beforeFirst();
			if (rowCount == 2){
				if(rs.next())
					shipStateID = rs.getString(1);
				if(rs.next())
					billStateID = rs.getString(1);
				Reporters.SuccessReport("Retrieve IDs of billing/shipping states from database", "Successfully retrieved IDs of the billing/shipping states from the database.");
			}
			else {
				flag = false;
				Reporters.failureReport("Retrieve IDs of billing/shipping states from database", "Failed to retrieve IDs of the billing/shipping states from the database.");
			}
			
			// if everything was successful so far, move forward with the deletions
			// will need to change selects to deletes, executeQuery to executeUpdate
			stepReport("Delete records from the database");
			if (flag) {
				
				/* this is just for debugging */
				//ResultSetMetaData rsmd;
				
				Reporters.SuccessReport("Retrieve all required info from database", "Successfully retrieved all required info from database.");
				
				conn.setAutoCommit(true);
				int rowsDeleted;
				
				// evl_order_review_audit table
				System.out.println("Deleting from evl_order_review_audit");
				query = "delete from evladmin.evl_order_review_audit where evl_order_review_id in (" + reviewIDs[0] + "," + reviewIDs[1] + ")";
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records from evl_order_review_audit", "Successfully deleted " + rowsDeleted + " rows from evl_order_review_audit.");
				// debugging
				/*
				rsmd = rs.getMetaData();
				while (rs.next()) {
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						if (j > 1) System.out.print(", ");
						String value = rs.getString(j);
						System.out.print(value);
					}
					System.out.println("");
				}
				System.out.println("");
				*/
				
				// evl_order_review table
				System.out.println("Deleting from evl_order_review");
				query = "delete from evladmin.evl_order_review where evl_order_id in (" + Order1 + "," + Order2 + ")";
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records from evl_order_review", "Successfully deleted " + rowsDeleted + " rows from evl_order_review.");
				// debugging
				/*
				rsmd = rs.getMetaData();
				while (rs.next()) {
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						if (j > 1) System.out.print(", ");
						String value = rs.getString(j);
						System.out.print(value);
					}
					System.out.println("");
				}
				System.out.println("");
				*/
				
				// order_item table
				System.out.println("Deleting from order_item");
				query = "delete from evladmin.order_item where evl_order_id in (" + Order1 + "," + Order2 + "," + Order3 + ")";
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records from order_item", "Successfully deleted " + rowsDeleted + " rows from order_item.");
				// debugging
				/*
				rsmd = rs.getMetaData();
				while (rs.next()) {
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						if (j > 1) System.out.print(", ");
						String value = rs.getString(j);
						System.out.print(value);
					}
					System.out.println("");
				}
				System.out.println("");
				*/
				
				// preorder_queue table
				System.out.println("Deleting from preorder_queue");
				query = "delete from evladmin.preorder_queue where parent_evl_order_id in (" + Order1 + "," + Order2 + ")";
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records from preorder_queue", "Successfully deleted " + rowsDeleted + " rows from preorder_queue.");
				// debugging
				/*
				rsmd = rs.getMetaData();
				while (rs.next()) {
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						if (j > 1) System.out.print(", ");
						String value = rs.getString(j);
						System.out.print(value);
					}
					System.out.println("");
				}
				System.out.println("");
				*/
				
				// evl_order table
				System.out.println("Deleting from evl_order");
				query = "delete from evladmin.evl_order where evl_order_id in (" + Order1 + "," + Order2 + "," + Order3 + ")";
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records from evl_order", "Successfully deleted " + rowsDeleted + " rows from evl_order.");
				// debugging
				/*
				rsmd = rs.getMetaData();
				while (rs.next()) {
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						if (j > 1) System.out.print(", ");
						String value = rs.getString(j);
						System.out.print(value);
					}
					System.out.println("");
				}
				System.out.println("");
				*/
				
				// credit_card_detail table
				System.out.println("Deleting from credit_card_detail");
				query = "delete from evladmin.credit_card_detail where credit_card_id in (" + ccIDs[0] + "," + ccIDs[1] + ")";
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records from credit_card_detail", "Successfully deleted " + rowsDeleted + " rows from credit_card_detail.");
				// debugging
				/*
				rsmd = rs.getMetaData();
				while (rs.next()) {
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						if (j > 1) System.out.print(", ");
						String value = rs.getString(j);
						System.out.print(value);
					}
					System.out.println("");
				}
				System.out.println("");
				*/
				
				// suspected_address table (shipping address)
				System.out.println("Deleting from suspected_address (shipping)");
				query = "delete from evladmin.suspected_address where line1 = '" + ShipStreet + "' and city = '" + ShipCity + "' and zip = '" + ShipZip + "' and state_mdcuid = " + shipStateID;
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records for shipping address from suspected_address", "Successfully deleted " + rowsDeleted + " rows from suspected_address.");
				// debugging
				/*
				rsmd = rs.getMetaData();
				while (rs.next()) {
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						if (j > 1) System.out.print(", ");
						String value = rs.getString(j);
						System.out.print(value);
					}
					System.out.println("");
				}
				System.out.println("");
				*/
				
				// suspected_address_table (billing address)
				System.out.println("Deleting from suspected_address (billing)");
				query = "delete from evladmin.suspected_address where line1 = '" + BillStreet + "' and city = '" + BillCity + "' and zip = '" + BillZip + "' and state_mdcuid = " + billStateID;
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records for billing address from suspected_address", "Successfully deleted " + rowsDeleted + " rows from suspected_address.");
				// debugging
				/*
				rsmd = rs.getMetaData();
				while (rs.next()) {
					for (int j = 1; j <= rsmd.getColumnCount(); j++) {
						if (j > 1) System.out.print(", ");
						String value = rs.getString(j);
						System.out.print(value);
					}
					System.out.println("");
				}
				*/
			}
			
			else {
				Reporters.failureReport("Retrieve all required info from database", "Failed to retrieve all required info from database. Nothing has been deleted!");
			}
			
			rs.close();
			statement.close();
			conn.close();
			
		} catch(Exception e){
			System.out.println(e.getMessage());
		}
			
	}
	
	public static void preorderDBCleanup() throws Throwable {
		
		try {

			final String LAST_FOUR = "<ENCR1AES0006>6EE28D509A8BA0EADEC26C65017CC258";
			
			// setup db connection
			ResultSet rs;
			String query;
			Connection conn = getDBConnection();
			Statement statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			
			// get the parent order ids that use the credit card
			stepReport("Get the order ids that use the credit card");
			HashSet<String> orderIDs = new HashSet<String>();
			query = "select eo.evl_order_id from evladmin.evl_order eo " +
					"join evladmin.credit_card_detail ccd " +
					"on eo.credit_card_id = ccd.credit_card_id " +
					"where ccd.last_four_digits = '" + LAST_FOUR + "'";
			rs = statement.executeQuery(query);
			while(rs.next()){
				orderIDs.add(rs.getString(1));
			}
			
			// get any child orders of the above parents
			query = "select pq.evl_order_id from evladmin.preorder_queue pq where pq.parent_evl_order_id in (";
			int i = 1;
			for (String ordernum : orderIDs){
				query += ordernum;
				if (i < orderIDs.size()){
					query += ",";
				}
				i++;
			}
			query += ")";
			rs = statement.executeQuery(query);
			while (rs.next()){
				orderIDs.add(rs.getString(1));
			}
			if (orderIDs.size() > 0){
				Reporters.SuccessReport("Retrieve order IDs that use the credit card and their children", "Successfully retrieved the order IDs.");
				System.out.println(orderIDs);
			}
			else {
				Reporters.failureReport("Retrieve order IDs that use the credit card and their children", "Failed to retrieve the order IDs.");
			}
			
			// create a complete list of the orders for use in deletions
			i = 1;
			String orderList = "";
			for (String ordernum : orderIDs){
				orderList += ordernum;
				if (i < orderIDs.size()){
					orderList += ",";
				}
				i++;
			}
			System.out.println(orderList + "\n");
			
			// get the order review ids from the database
			stepReport("Get evl_order_review_id from database for the orders");
			HashSet<String> reviewIDs = new HashSet<String>();
			query = "select evl_order_review_id from evladmin.evl_order_review where evl_order_id in (" + orderList + ")";
			rs = statement.executeQuery(query);
			while(rs.next()){
				reviewIDs.add(rs.getString(1));
			}
			
			// create a complete list of the review ids for use in deletions
			i = 1;
			String reviewList = "";
			for (String reviewnum : reviewIDs){
				reviewList += reviewnum;
				if (i < reviewIDs.size()){
					reviewList += ",";
				}
				i++;
			}
			System.out.println(reviewList + "\n");
			
			stepReport("Delete the necessary records from the database");
			int rowsDeleted;
			conn.setAutoCommit(true);
			
			if (reviewIDs.size() > 0) {
				// delete from evl_order_review_audit table
				System.out.println("Deleting from evl_order_review_audit table");
				query = "delete from evladmin.evl_order_review_audit where evl_order_review_id in (" + reviewList + ")";
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records from evl_order_review_audit", "Successfully deleted " + rowsDeleted + " rows from evl_order_review_audit.");
			
				// delete from evl_order_review table
				System.out.println("Deleting from evl_order_review table");
				query = "delete from evladmin.evl_order_review where evl_order_id in (" + orderList + ")";
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records from evl_order_review", "Successfully deleted " + rowsDeleted + " rows from evl_order_review.");
			}
			
			// delete from order_item table
			System.out.println("Deleting from order_item table");
			query = "delete from evladmin.order_item where evl_order_id in (" + orderList + ")";
			System.out.println(query);
			rowsDeleted = statement.executeUpdate(query);
			System.out.println(rowsDeleted + " rows deleted.\n");
			if (rowsDeleted > 0) {
				Reporters.SuccessReport("Deleting records from order_item", "Successfully deleted " + rowsDeleted + " rows from order_item.");
			}
			else
				Reporters.failureReport("Deleting records from order_item", "Failed to delete any rows from order_item.");
			
			// delete from preorder_queue table
			System.out.println("Deleting from preorder_queue table");
			query = "delete from evladmin.preorder_queue where evl_order_id in (" + orderList + ")";
			System.out.println(query);
			rowsDeleted = statement.executeUpdate(query);
			System.out.println(rowsDeleted + " rows deleted.\n");
			Reporters.SuccessReport("Deleting records from preorder_queue", "Successfully deleted " + rowsDeleted + " rows from preorder_queue.");
			
			// delete from evl_order table
			System.out.println("Deleting from evl_order table");
			query = "delete from evladmin.evl_order where evl_order_id in (" + orderList + ")";
			System.out.println(query);
			rowsDeleted = statement.executeUpdate(query);
			System.out.println(rowsDeleted + " rows deleted.\n");
			if (rowsDeleted > 0) {
				Reporters.SuccessReport("Deleting records from evl_order", "Successfully deleted " + rowsDeleted + " rows from evl_order.");
			}
			else
				Reporters.failureReport("Deleting records from evl_order", "Failed to delete any rows from evl_order.");
			
			// delete from credit_card_detail table
			System.out.println("Deleting from credit_card_detail table");
			query = "delete from evladmin.credit_card_detail where last_four_digits = '" + LAST_FOUR + "'";
			System.out.println(query);
			rowsDeleted = statement.executeUpdate(query);
			System.out.println(rowsDeleted + " rows deleted.\n");
			if (rowsDeleted > 0) {
				Reporters.SuccessReport("Deleting records from credit_card_detail", "Successfully deleted " + rowsDeleted + " rows from credit_card_detail.");
			}
			else
				Reporters.failureReport("Deleting records from credit_card_detail", "Failed to delete any rows from credit_card_detail.");
			
			rs.close();
			statement.close();
			conn.close();
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
