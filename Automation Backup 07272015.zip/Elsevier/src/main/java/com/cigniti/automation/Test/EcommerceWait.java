package com.cigniti.automation.Test;

import org.testng.annotations.Test;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Actiondriver;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;

public class EcommerceWait extends Actiondriver{
	@Test
	public static void ecommerceWait() throws Throwable 
	{
		EvolveCommonBussinessFunctions.SwitchToBrowser(ElsevierObjects.studentBrowserType);
		launchUrl(configProps.getProperty("PreOrderJobURL"));
		Thread.sleep(medium);
		String results = getText(ElsevierObjects.PREORDER_JOB_RESULTS, "Preorder job results");
		System.out.println("Preorder job results:");
		System.out.println(results);
		
		Reporters.SuccessReport("Launch preorder queue job URL.", "Preorder queue job URL launched successfully.");
		
		/*
		System.out.println("Wait for 10 mins for preorder queue job to run");
		for(int i=1;i<=EcommerceMinutes;i++){
			Thread.sleep(60000);
			System.out.println("Completed Minutes:" +i );
		}
		
		Reporters.SuccessReport("Completed Wait time for Ecommerce PreOrder Test Cases","Completed wait time for "+EcommerceMinutes+" mins for preorder queue job to run");
		System.out.println("Completed wait time for "+EcommerceMinutes+" mins for preorder queue job to run");
		*/
	}
}
