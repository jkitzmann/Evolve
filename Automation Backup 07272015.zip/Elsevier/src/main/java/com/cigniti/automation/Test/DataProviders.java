package com.cigniti.automation.Test;

import java.util.ArrayList;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Actiondriver;

public class DataProviders extends Actiondriver{
 
	public static String filepath=configProps.getProperty("TestData");
	
  @Test(dataProvider = "dp9", enabled=true)
  public void f9(String n, String s,String p) {
	  System.out.println("n>>> "+n);
	  System.out.println("s>>> "+s);
	  System.out.println("p>>> "+p);
	  System.out.println("-------------<<>>>");
  }
  
  
  @DataProvider
  public Object[][] dp9() {
	  Object objj[][]= new Object[3][];
	  
	  ReadingExcel r = new ReadingExcel();
	  
	  objj[0] = new Object[3];
	  ArrayList<String> rowList1 = r.rowData(1, 2, 14,  filepath);	
      for(int i=0;i<rowList1.size();i++){
    	  objj[0][i]= rowList1.get(i);
      }

      objj[1] = new Object[3];
	  ArrayList<String> rowList2 = r.rowData(2, 2, 14,  filepath);	
      for(int i=0;i<rowList2.size();i++){
    	  objj[1][i]= rowList2.get(i);
      }

      objj[2] = new Object[3];
	  ArrayList<String> rowList3 = r.rowData(3, 2, 14,  filepath);	
      for(int i=0;i<rowList3.size();i++){
    	  objj[2][i]= rowList3.get(i);
      }

	  return objj;
  }
  
  

}
