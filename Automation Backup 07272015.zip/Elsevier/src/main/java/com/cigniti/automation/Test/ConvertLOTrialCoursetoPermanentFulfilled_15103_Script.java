package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.ConvertLOTrialCoursetoPermanentFulfilled_15103;
import com.cigniti.automation.BusinessFunctions.ConvertLOTrialCoursetoPermanentPending_15566;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentFaculty_15243;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101;
import com.cigniti.automation.BusinessFunctions.LO_Unique_CourseFulfillment_Faculty_10410;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class ConvertLOTrialCoursetoPermanentFulfilled_15103_Script extends ConvertLOTrialCoursetoPermanentFulfilled_15103{

@Test
public static void convertLOTrialCoursetoPermanentFulfilled_15103() throws Throwable{
	
	try{
	//HtmlReporters.currentTimeList.add(System.currentTimeMillis());

	String format_LO=ReadingExcel.columnDataByHeaderName("format_LO", "TC-15101", configProps.getProperty("TestData"));
	String statusAfterEmailSent=ReadingExcel.columnDataByHeaderName("verifyStatusAfterEmailSent", "TC-10410", configProps.getProperty("TestData"));
	String productId=ReadingExcel.columnDataByHeaderName("productID", "TC-10410", configProps.getProperty("TestData"));
	emailtitlPermanent=ReadingExcel.columnDataByHeaderName("emailTitleAfterConvertingToPermanent", "TC-15101", configProps.getProperty("TestData"));
	trialEmailTitleAfterFullfilled=ReadingExcel.columnDataByHeaderName("trialEmailTitleAfterFullfilled", "TC-15101", configProps.getProperty("TestData"));
	rosterDetails=ReadingExcel.columnDataByHeaderName("rosterDetails", "TC-15566", configProps.getProperty("TestData"));

	//******************************Complete all steps for test case: "LO Unique Course Trial Fulfillment-Faculty"**************************************//
	          
	LOUniqueCourseTrialFulfillmentFaculty_15243_Script.LOUniqueCourseTrialFulfillmentFaculty_15243();

	//********************************Searching For The Adoption Request ID Referenced From 15243 Testcase***********************************************//
	
	stepReport("Login to Evolve Admin");
	SwitchToBrowser(ElsevierObjects.adminBrowserType);
	writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login to Application Using Admin Credentials"+adminUser,
			"Launching the URL for Admin is successful </br > Login to Application Using Admin credentials :"+adminUser+" is Successful", 
			"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");
	
	stepReport("Search for AR");
	writeReport(ConvertLOTrialCoursetoPermanentFulfilled_15103.clickOnSearchAdoptionLink(),"Click on Search Adoption request link in Admin page.",
			  "Successfully clicked on Seach Adoption request link.",
			  "Failed to click on Search Adoption request link.");
	
	String ARNumber=adoptionRequest_getAdoptionNum;
	writeReport(ConvertLOTrialCoursetoPermanentFulfilled_15103.searchAdoptionByAdoptionNumber(ARNumber),"Search for Adoption Number.",
			  "Successfully searched for Adoption Number"+adoptionRequest_getAdoptionNum,
			  "Failed to search for Adoption Number"+adoptionRequest_getAdoptionNum);
	
	stepReport("Conver the course from trial to permanent");
	verifymessage=ReadingExcel.columnDataByHeaderName("verifyTrialMessage", "TC-15566", configProps.getProperty("TestData"));
	writeReport(ConvertLOTrialCoursetoPermanentPending_15566.adoptionRequestConvertTrialToPermanant(),"Convert Trial status to Permanent."
		     ,"Successfully Converted Status to permanent.</br> Successfully verified Trial Message.",
			  "Failed to convert Trial status.");
	
	writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout.", 
			  "Successfully logged out admin page.", 
			  "Failed to logout admin page.");
	
	//*******************************************Verifying Email Title*******************************************************************************//
	//SwitchToBrowser("chrome");
	stepReport("Verify email");
	writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Login In Into Evolve Email Page.", 
			  "Succesfully login into Evole Email Page.", 
			  "Failed to login into Evolve Email Page.");
	
	String emailid=EvolveCommonBussinessFunctions.getAccountDetailsEmail;
	writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(emailid),"Search email in evolve webmail.",
			"Successfully entered the emailid "+emailid+" in search box.",
			"Failed to enter email id.");
	String emailTitlefulfilled=emailtitlPermanent;
	LOUniqueCourseTrialFulfillmentFaculty_15243.verifyEmailBodyAfterRequestFullfill(emailTitlefulfilled);
	
	//******************************************Creating LO Trial Course And Verifying Details In Adoption Request Page.******************************//
	
	//SwitchToBrowser(ElsevierObjects.studentBrowserType);
	stepReport("Login as instructor");
	facultyUserName=ReadingExcel.columnDataByHeaderName("Faculty_User", "TC-15101", configProps.getProperty("TestData"));
	facultyPassword=ReadingExcel.columnDataByHeaderName("Faculty_passWord", "TC-15101", configProps.getProperty("TestData"));
	writeReport(LO_Unique_CourseFulfillment_Faculty_10410.reLogin(facultyUserName, facultyPassword),  "Login to Application Using User Credentials",
																						    	"Launching the URL for User is successful </br > Login to Application Using User credentails :"+facultyUserName+" is Successful",
																						    	"Launching and Login to Application Using User credentails : "+ facultyUserName+" is Failed");
	writeReport(EvolveCommonBussinessFunctions.getAccountDetails(),"Fetching Account Details from My Account.",
			   "Successfully Fetched account details from My Account page.",
			   "Failed to Fetch the account details from My Account page.");
	
	String ID1="true";
	String ID2="false";
	
	stepReport("Verify course appears in My Evolve and open it");
	writeReport(LO_Unique_CourseFulfillment_Faculty_10410.courseIDSearch(ID1,ID2),"Verifying course ID's generated in Admin page are in Educator page or not.",
																	  "Successfully Verified CourseId "+courseID1+". </br> Clicked on "+courseID1+".", 
																	  	"Failed to Verify CourseId "+courseID1);
	searchTrial="true";
	LO_Unique_CourseFulfillment_Faculty_10410.courseDetailsPage(searchTrial);
	
	stepReport("Search for product and request trial");
	ConvertLOTrialCoursetoPermanentPending_15566.catalogButton();
	ConvertLOTrialCoursetoPermanentPending_15566.myEvolve();
	writeReport(EvolveCommonBussinessFunctions.searchProduct(product,productCost),"Serach for the product..",
			  "Successfully Entered ISBN:"+product+" in Search Box.</br>Clicked On Go Button.</br>Navigated To Product Details Page.",
			  "Failed to Enter ISBN:"+product+" in Search Box.");
	//
	LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.request30DayTrial();

	searchTrial="true";
	String DayTrial=ReadingExcel.columnDataByHeaderName("TRialLink","TC-15101", configProps.getProperty("TestData"));

	stepReport("Verify My Cart and submit order");
	LOUniqueCourseTrialFulfillmentfromSearchResultsPageScript_15101.Mycart(searchTrial,DayTrial);
	
	accessCode="false";

	LO_Unique_CourseFulfillment_Faculty_10410.userReviewSubmit(searchTrial,DayTrial);                                          

	stepReport("Verify receipt page");
	LO_Unique_CourseFulfillment_Faculty_10410.receiptPage(searchTrial,DayTrial);
	
	writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the educator page.", 
			"Sucecssfully logged out the educator page.", 
			"Failed to logout the educator page.");
	//***********************************************************************************************************//
	//SwitchToBrowser(ElsevierObjects.adminBrowserType);
	stepReport("Login to Evolve Admin");
	writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login to Application Using Admin Credentials"+adminUser,
			"Launching the URL for Admin is successful </br > Login to Application Using Admin credentials :"+adminUser+" is Successful", 
			"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");

	stepReport("Search for AR and verify trial status");
	writeReport(EvolveCommonBussinessFunctions.clickAdoptionRequest(getAccountDetailsUserName),"Clicking on Search Adoption request link in Admin page.",
			  "Successfully clicked on Seach Adoption Requests link.</br>Successfully Selected Today Radio Button In Adoption Request Page.</br>Successfully Clicked On Search Button</br>Navigated To Adoption Search Results Page.",
			  "Failed to click on Search Adoption Requests link.</br>Failed To Select Today Radio Button In Adoption Request Page.</br>Failed To Navigate To Adoption Search Results Page.");

	writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.verifyTrial(), "Verifying Trial status in Adoption Search Results Page.", 
			"Successfully verified the Trial Status in Adoption Search Results Page.", 
			"Failed to verified the Trial Status in Adoption Search Results Page");	
	
	writeReport(EvolveCommonBussinessFunctions.getAdoptionRequestDetails(),"Clicking On Adoption Number:"+adoptionRequest_getAdoptionNum+".</br>Fetching Adoption Details of User and Course in Adoption Request Details page",
			   "Adoption Number:"+adoptionRequest_getAdoptionNum+" is On Top Of The Row.</br>Successfully Clicked On "+adoptionRequest_getAdoptionNum+"</br>Successfully Fetched the details of User And Course from Adoption Request Details Page.",
			   "Failed To Click On Adoption Number:"+adoptionRequest_getAdoptionNum+"</br>Failed to Fetch the details of User And Course from Adoption Request Details Page.");

	LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.verifyTrialLOStatus(format_LO);
	
	ConvertLOTrialCoursetoPermanentPending_15566.adoptionRequestVerifyMIlestonesData();
	
	//ConvertLOTrialCoursetoPermanentPending_15566.adoptionRequestConvertTrialToPermanant();
	
	stepReport("Fulfill the AR");
	String changeStatus=ReadingExcel.columnDataByHeaderName("changeStatus", "TC-15101", testDataPath);
	ConvertLOTrialCoursetoPermanentPending_15566.changeStatusToFullfilled(changeStatus);
	
	//LOUniqueCourseFulfillmentfromSearchResultsPage_LO.getCourseId(statusAfterEmailSent,productId,facultyUser);
	
	/*writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout.", 
															  "Successfully logged out admin page.", 
															  "Failed to logout admin page.");
	*///********************************************************************************************************************************************//
	//SwitchToBrowser("chrome");
	stepReport("Verify email");
	writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Login In Into Evolve Email Page.", 
			  "Succesfully login into Evolve Email Page.", 
			  "Failed to login into Evolve Email Page.");
	
	emailid=EvolveCommonBussinessFunctions.getAccountDetailsEmail;
	writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(emailid),"Search email in evolve webmail.",
				"Successfully entered the emailid "+emailid+" in search box.",
				"Failed to enter email id.");
	
	LOUniqueCourseTrialFulfillmentFaculty_15243.verifyEmailBodyAfterRequestFullfill(trialEmailTitleAfterFullfilled);
	
	//**********************************Searching For Course ID In Faculty Page Generated In ADMIN After Fulfilling The Request************************//

	//SwitchToBrowser(ElsevierObjects.studentBrowserType);
	
	facultyUserName=ReadingExcel.columnDataByHeaderName("Faculty_User", "TC-15101", configProps.getProperty("TestData"));
	facultyPassword=ReadingExcel.columnDataByHeaderName("Faculty_passWord", "TC-15101", configProps.getProperty("TestData"));
	
	stepReport("Login as instructor and verify courses in My Evolve");
	writeReport(LO_Unique_CourseFulfillment_Faculty_10410.reLogin(facultyUserName, facultyPassword),  "Login to Application Using User Credentials",
																								    	"Launching the URL for User is successful </br > Login to Application Using User credentails :"+facultyUserName+" is Successful",
																								    	"Launching and Login to Application Using User credentails : "+ facultyUserName+" is Failed");
			
	writeReport(LO_Unique_CourseFulfillment_Faculty_10410.courseIDSearch(ID1,ID2),"Verifying course ID's generated in Admin page are in Educator page or not.",
																			  "Successfully Verified CourseId "+courseID1+". </br> Clicked on "+courseID1+".", 
																			  	"Failed to Verify CourseId "+courseID1);
			
	LO_Unique_CourseFulfillment_Faculty_10410.courseDetailsPage(searchTrial);
			
	stepReport("Submit roster for course");
	writeReport(ConvertLOTrialCoursetoPermanentPending_15566.catalogButton(), "Clicking on Catalog Button.",
													"Successfully Clicked on Catalog Button.", 
													"Failed to Click on Catalog Button.");
			
	/*writeReport(ConvertLOTrialCoursetoPermanentPending_15566.onlineCourseHoneyPot(), "Clicking on Online Courses Honeypot in evolve page.",
					"Successfully clicked on Online course honey pot.", 
					"Failed to click on Online course honey pot.");*/
			
	ConvertLOTrialCoursetoPermanentPending_15566.onlineSubmitStudent(rosterDetails);

	verifytextInRosterRoles();
	
	writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the educator:"+facultyUserName, 
			"Successfully logged out the educator:"+facultyUserName, 
			"Failed to logout the educator page:"+facultyUserName);
	}
	catch(Exception e){
		System.out.println(e);
	}

}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}

}
