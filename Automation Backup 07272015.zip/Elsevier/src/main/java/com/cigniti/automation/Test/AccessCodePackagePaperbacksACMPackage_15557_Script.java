package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.AccessCodePackagePaperbacksACMPackage_15557;
import com.cigniti.automation.BusinessFunctions.AccessCodePackageUnassignedAccessCodesUpload_10213;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.FileDelete;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class AccessCodePackagePaperbacksACMPackage_15557_Script extends AccessCodePackagePaperbacksACMPackage_15557{

	@Test
	public void accessCodePackagePaperbacksACMPackage_15557() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			//ElsevierObjects.adminBrowserType="firefox";
			String filePath = ReadingExcel.getAbsoulteFilePath(readcolumns.twoColumns(0, 1,"TC-10212", configProps.getProperty("TestData")).get("UploadDataFile_15557"));
			//String validAccessCodes=ReadingExcel.getCell(1, 2, filePath, "UploadFile");
			
			String shippingAdress=ReadingExcel.columnDataByHeaderName("student_StreetAdress", "TC-15557",configProps.getProperty("TestData"));
			String shippingCity=ReadingExcel.columnDataByHeaderName("student_City", "TC-15557",configProps.getProperty("TestData"));
			String shippingState=ReadingExcel.columnDataByHeaderName("student_State", "TC-15557",configProps.getProperty("TestData"));
			String shippingZip=ReadingExcel.columnDataByHeaderName("student_ZipCode", "TC-15557",configProps.getProperty("TestData"));
			String VSTPassword=ReadingExcel.columnDataByHeaderName("VKno_Password", "TC-15557",configProps.getProperty("TestData"));
			String studentSecurityQuestion=ReadingExcel.columnDataByHeaderName("Student_Secu_Que", "TC-15557",configProps.getProperty("TestData"));
			String studentSecurityAns=ReadingExcel.columnDataByHeaderName("Student_Sec_Ans", "TC-15557",configProps.getProperty("TestData"));
			String KNOPassword=ReadingExcel.columnDataByHeaderName("KNO_Pwd", "TC-15557",configProps.getProperty("TestData"));

			stepReport("Login to Evolve Admin.");
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials : "+ configProps.getProperty("AdminUser"),
					"Launching the URL for User is successful </br > Login to Application Using User credentails : "+configProps.getProperty("AdminUser")+" is Successful",
					"Launching and Login to Application Using User credentails : "+ configProps.getProperty("AdminUser")+" is Failed");

			stepReport("Create unassigned access codes.");
			if(unassignedAccesscodeLink())
			{
				Reporters.SuccessReport("Unassigned Access code link ", "Successfully clicked on Unassigned access code link");
			}
			else
			{	
				Reporters.failureReport("Unassigned Access code link ", "Failed to clicked on Unassigned access code link");
			}

			verifyCodeCreation();
			if(AccessCodePackageUnassignedAccessCodesUpload_10213.clickDownloadAndCompareNotePadDataWithStringliterals()){
				Reporters.SuccessReport("Verify Access Codes generated", "Access Codes text file is downloaded and String literals verified successfully in the above steps");
			}
			else{
				Reporters.failureReport("Verify Access Codes generated", "Access Codes text file failed to download and String literals verified failed. ");
			}	
			Thread.sleep(medium);
			
			stepReport("Upload unassigned access codes.");
			click(ElsevierObjects.Admin_Evolve_lnk, "Click on Bread Crumb Evolve Admin");
			Thread.sleep(medium);
			if(AccessCodePackageUnassignedAccessCodesUpload_10213.accesscodeUploadLink())
			{
				Reporters.SuccessReport("Access Code Upload Link", "Successfully Clicked on Access Code Upload Link ");
			}
			else
			{
				Reporters.failureReport("Access Code Upload Link", "Successfully Clicked on Access Code Upload Link ");
			}
			//String filePath1 = ReadingExcel.getAbsoulteFilePath(readcolumns.twoColumns(0, 1, "TC-10212", configProps.getProperty("TestData")).get("UploadDataFile_15557"));
			if(AccessCodePackageUnassignedAccessCodesUpload_10213.verifyCopyToExcel(filePath))
			{
				Reporters.SuccessReport("Copy the access codes data from text file to excel file", "Successfully Copied the access codes available <br> in the text file to the excel file to upload");
			}
			else
			{
				Reporters.failureReport("Copy the access codes data from text file to excel file", "failed to Copy the access codes available <br> in the text file to the excel file to upload");
			}
			//String filepath=readcolumns.twoColumns(0, 1, "TC-10212", configProps.getProperty("TestData")).get("UploadDataFile_15557");
			if(AccessCodePackageUnassignedAccessCodesUpload_10213.uploadExcel(filePath))
			{
				Reporters.SuccessReport("Upload Excel File", "Excel File Uploaded Successfully ");
			}
			else
			{
				Reporters.failureReport("Upload Excel File", "Excel File Fialed to Upload");
			}
			
			stepReport("Create new student user.");
			if(CreateNewUser(ElsevierObjects.STUDENT))
			{
				Reporters.SuccessReport("Create New Student user and log into the application", "Successfully Created new student user with the credentials : <br> Username : "+credentials[0]+"<br> Password : "+credentials[1]+" <br>Successfully logged in as New Student user");
			}
			else
			{
				Reporters.failureReport("Create New Student user and log into the application", "Failed to login as New Student user");
			}
			String user1="true";
			
			stepReport("Submit access code through Catalog page and enter checkout.");
			if(EvolveCatalog(user1))
			{
				Reporters.SuccessReport("Redeemption of valid Code", "valid Redeem Code Message was Printed Successfully ");
			}
			else
			{
				Reporters.failureReport("Redeemption of valid Code", "Case Failed No valid Redeem Code Message was Printed ");
			}
			Thread.sleep(medium);
			
			stepReport("Complete checkout.");
			studentShippingOrder(shippingAdress, shippingCity, shippingState, shippingZip, VSTPassword, studentSecurityQuestion, studentSecurityAns, KNOPassword);

			Thread.sleep(medium);
			User_BusinessFunction.Logout();
			Thread.sleep(medium);
			
			stepReport("Verify the email sent for the order.");
			if(emailLogin()){
				Reporters.SuccessReport("Log into the Evolve outlook Mail", "Successfully logged into the evolve outlook mail");
			}else{
				Reporters.failureReport("Log into the Evolve outlook Mail", "Failed to log into the evolve outlook mail");
			}
			Thread.sleep(medium);

			emailVerification(StdEmail);

			Thread.sleep(medium);
			
			stepReport("Login to Evolve Admin.");
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials : "+ configProps.getProperty("AdminUser"),
					"Launching the URL for User is successful </br > Login to Application Using User credentails :"+configProps.getProperty("AdminUser")+" is Successful",
					"Launching and Login to Application Using User credentails : "+ configProps.getProperty("AdminUser")+" is Failed");

			String user="";


			String validAccessCodes=ReadingExcel.getCell(1, 2, filePath, "UploadFile");

			stepReport("Verify that the access code redemption is reflected in Evolve Admin.");
			AccessCodePackageUnassignedAccessCodesUpload_10213.accessCodeVerify(validAccessCodes, user);

			//String username=readcolumns.twoColumns(0,1, "DynamicCredentials", configProps.getProperty("TestData")).get("UserName");
			String username=credentials[0];
			//String password=readcolumns.twoColumns(0,1, "DynamicCredentials", configProps.getProperty("TestData")).get("Password");
			String password=credentials[1];
			
			stepReport("Verify that the access code used is no longer valid for the existing student.");
			if(SignInAsDifferentUser(username, password)){
				Reporters.SuccessReport("Login into Application as same student user", "Successfully logged in as Student user with the credentials : <br> Username : "+username+"<br> Password : "+password);
			}else{
				Reporters.failureReport("Login into Application as same student user", "Failed to log in as Student user with the credentials : <br> Username : "+username+"<br> Password : "+password);
			}

			String user2="";
			EvolveCatalog(user2);
			if(User_BusinessFunction.Logout()){
				Reporters.SuccessReport("Log out from the application", "Successfully logged out as Student user");
			}else{
				Reporters.failureReport("Log out from the application", "Failed to log out as Student user");
			}

			stepReport("Verify that the access code is no longer valid for a new student user.");
			if(CreateNewUser(ElsevierObjects.STUDENT))
			{
				Reporters.SuccessReport("Create New Student user and log into the application", "Successfully Created new student user with the credentials : <br> Username : "+credentials[0]+"<br> Password : "+credentials[1]+" <br>Successfully logged in as New Student user");
			}
			else
			{
				Reporters.failureReport("Create New Student user and log into the application", "Failed to login as New Student user");
			}

			String user3="";
			EvolveCatalog(user3);

			if(User_BusinessFunction.Logout()){
				Reporters.SuccessReport("Log out from the application", "Successfully logged out as Student user");
			}else{
				Reporters.failureReport("Log out from the application", "Failed to log out as Student user");
			}
			
			FileDelete.deleteFile(downloadFilePath);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			FileDelete.deleteFile(downloadFilePath);
		}
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}


}