package com.cigniti.automation.Test;

public class Snippet {
	public static void main(String[] args) {
		//LO_GlobalCourse_Script_9826.java
	}
}

