package com.cigniti.automation.Test;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class HESI_Transcripts1_17185 extends EvolveCommonBussinessFunctions{

	@Test
	public void HESI_Transcript1_17185() throws Throwable{
		
		try {
		    SwitchToBrowser(ElsevierObjects.studentBrowserType);
		    if(launchUrl(configProps.getProperty("URL4"))){
				Reporters.SuccessReport("Launch the URL "+configProps.getProperty("URL4"), "Successfully Launched URL "+configProps.getProperty("URL4"));
			}else{
				Reporters.failureReport("Launch the URL "+configProps.getProperty("URL4"), "Failed to Launch URL "+configProps.getProperty("URL4"));
			}
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			
			if(click(ElsevierObjects.HESI_TRANSCRIPTS,"Click HESI Transcripts link")){
				Reporters.SuccessReport("Click HESI Transcripts link", "Successfully Clicked on HESI Transcripts link");
			}else{
				Reporters.failureReport("Click HESI Transcripts link", "Failed to Click on HESI Transcripts link");
			}
			
			if(launchUrl(configProps.getProperty("URL3"))){
				Reporters.SuccessReport("Launch the URL "+configProps.getProperty("URL3"), "Successfully Launched URL "+configProps.getProperty("URL3"));
			}else{
				Reporters.failureReport("Launch the URL "+configProps.getProperty("URL3"), "Failed to Launch URL "+configProps.getProperty("URL3"));
			}
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			
			if(!click(ElsevierObjects.HESI_TRANSCRIPTS,"Click HESI Transcripts link")){
				Reporters.SuccessReport("Verify HESI Transcripts link as Educator", "Verified HESI Transcripts link not present for Educator");
			}else{
				Reporters.failureReport("Verify HESI Transcripts link as Educator", "HESI Transcripts link incorrectly found for Educator");
			}
			
		}
		
		catch (Exception e) {
			System.out.println(e.getMessage());	
		}
	}
}
