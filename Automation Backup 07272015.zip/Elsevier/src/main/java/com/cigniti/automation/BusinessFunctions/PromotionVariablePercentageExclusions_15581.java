package com.cigniti.automation.BusinessFunctions;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Test.PromotionVariablePercentageInclusions_10227_Script;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;


public class PromotionVariablePercentageExclusions_15581 extends EvolveCommonBussinessFunctions{

	String dmCodeForUse=PromotionVariablePercentageInclusions_10227_Script.DMCodeForUse;
	//Pre Requisite for the This script is run PromotionVariablePercentageInclusions_Script and save the dmcode
	public static boolean maintainPromotion(String dmCode) throws Throwable
	{
		try
		{
			boolean flag = true;
			click(ElsevierObjects.Promotion_ExclusionVariable_MaintainPromotionLink, "Click on the Maintain Promotions link in the Promotion Management section");
			isElementPresent(ElsevierObjects.Promotion_ExclusionVariable_BreadCrumb, "Evolve Admin > Maintain Promotions", driver.getCurrentUrl());
			type(ElsevierObjects.Promotion_ExclusionVariable_Searchbox,  dmCode, "Enter the DM Code saved for the future use ");
			if(click(ElsevierObjects.Promotion_ExclusionVariable_SearchButton, "Click on the Search Button")){
				Reporters.SuccessReport("Edit Promotion page", "User now taken to the Edit Promotion page for this DM Code : "+dmCode);	
			}else{
				Reporters.failureReport("Edit Promotion page", "User is unbale to go to the Edit Promotion page for this DM Code : "+dmCode);
			}
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}

	//Verify the elements in the Exclude Section
	public static boolean verifyTextExcludeProducts() throws Throwable
	{
		try
		{
			boolean flag = true;
			verifyTextForExcludeProducts(ElsevierObjects.Promotion_ExclusionVariable_PrmTxt, ElsevierObjects.Promotion_ExclusionVariable_ChkBoxReference, ElsevierObjects.Promotion_ExclusionVariable_ChkBoxText, 
					ElsevierObjects.Promotion_ExclusionVariable_ChkBoxTrade, ElsevierObjects.Promotion_ExclusionVariable_ChkBoxAnnual, ElsevierObjects.Promotion_ExclusionVariable_ChkBoxSucMsg);
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}



	//Validating Profit Center Section 

	public static boolean validateDifferentSection(String type,By xpath,String user,By comboBox, By addBtn, By percentField,String percentage1, String percentage2,By percFailMsg, 
			By sucMsg, By backgroundColor, By selectOption1,By selectOption2, By rmvLink, By anyTextField, 
			By percRowValue, By selectOptionFinal, By viewAllLink) throws Throwable{
		try{
			boolean flag=true;

			String comboSize=getAttribute(comboBox, "size", "");
			System.out.println(comboSize);
			if(comboSize.contains("5")){
				Reporters.SuccessReport("Profit Centers shows 5", "Profit Centers shows 5");
			}else{
				Reporters.failureReport("Profit Centers shows 5", "Profit Centers shows 5");
			}			
			/*List<WebElement> selectOptionData=getElements(comboBox);
			for(WebElement option: selectOptionData){
				System.out.println(option.getText());
			}
			 */
			String [] Values1=new String[5];
			List<WebElement> selectOption=driver.findElements(xpath);
			for(int i =0;i<5;i++)
			{
				Values1[i]=selectOption.get(i).getText();  	
				//	System.out.println(option.getText());
			}				
			verifysort(Values1);
			//System.out.println("");
			isElementPresent(addBtn, "Add Button", driver.getCurrentUrl());			
			//Validating the products...

			click(addBtn, "Click on add button");
			Thread.sleep(medium);
			verifyText(percFailMsg, "Please select product group to add to the promotion.", "Select one or more inclusions from  the Profit Center");
			click(selectOption1, "Select any Option ");
			click(addBtn, "Click on add button");
			click(rmvLink, "Click on remove button");
			Alert();
			Thread.sleep(medium);		
			//addProduct(ElsevierObjects.Evolve_Admin_Prmlnk_SelcOption,percentField, percentage , addBtn, 1);
			click(selectOption1, "Select any Option ");
			click(selectOption1, "Select any Option ");			
			click(addBtn, "Click on add button");			
			verifyText(sucMsg, "The Promotion Inclusion is successfully saved. ", "Promotion Inclusions are successfully saved");						
			verifyBackGroundColor(backgroundColor);			
			isElementPresent(rmvLink, "Remove link", driver.getCurrentUrl());			



			//step 7			
			click(selectOption1, "Select any Option ");
			click(selectOption2, "Select any Option ");



			click(addBtn, "Click on add button");
			String succMsg=getText(sucMsg, "");
			if(verifyText(sucMsg, "The Promotion Inclusion is successfully saved. ", "Promotion Inclusions are successfully saved")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+succMsg+" is displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+succMsg+" is failed to display");
			}
			verifyBackGroundColor(backgroundColor);

			List<WebElement> element=driver.findElements(rmvLink);
			int getSize=element.size();
			for (int i = 1; i < getSize+1; i++) {
				String row1=getText(By.xpath(ElsevierObjects.remove3+i+ElsevierObjects.remove4), "");
				//driver.findElement(By.xpath(ElsevierObjects.remove1+i+ElsevierObjects.remove2)).getText();
				System.out.println(row1);
				if(row1.contains("remove")){
					System.out.println(row1);
					Reporters.SuccessReport("Remove link", "Remove Link is present");
				}else{

					Reporters.failureReport("Remove link", "Remove Link is not present");
				}
			}
			//Step 8			
			click(rmvLink, "");
			Alert();			
			//Step 9

			flag=iterate(type,user,selectOptionFinal, percentField, percentage1, addBtn, sucMsg, percRowValue, rmvLink, 5, anyTextField);

			flag= validateViewAll(viewAllLink, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_ViewNewPageMsg, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, VerifyText3,"");

			/*By by = ElsevierObjects.Evolve_Admin_Prmlnk_IncAddedTable;
				List<WebElement> prodDetails = getTableTD(by, 1, 1).findElements(By.tagName("table"));

				//List<String> tableData=(List<String>) getTableTD(ElsevierObjects.Evolve_Admin_Prmlnk_IncAddedTable, 1, 1);
				for(WebElement table:prodDetails){
					System.out.println(table.getText());
				}*/
			return flag;			
		}catch(Exception e){return false;}
	}	

	public static boolean validateISBNSection() throws Throwable{
		try{
			boolean flag=true;
			String condition="exclusion";
			flag=validateISBNSection(condition, ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExcludeTxtBox, 
					ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExludeBtn, 
					ElsevierObjects.Promotion_ExclusionVariable_ProISBNErrorMsg, ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExludeSucMsg,
					ElsevierObjects.Promotion_ExclusionVariable_ISBNAddList, ElsevierObjects.Promotion_ExclusionVariable_ISBNRem, 
					readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("InvalidISBN"));	

			/*flag= validateViewAll(ElsevierObjects.Promotion_ExclusionVariable_ISBNViewAll, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_ViewNewPageMsg, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, VerifyText3,"isbnIncExclusion");
			 */
			return flag;			
		}catch(Exception e){return false;}
	}

	//Validating the ISBN Upload Section
	public static boolean uploadCSVFile() throws Throwable{
		boolean flag=true;
		String condition="exclusion";
		flag=uploadCSVFile(condition, ElsevierObjects.Promotion_ExclusionVariable_ISBNBrowse, 
				ElsevierObjects.Promotion_ExclusionVariable_ISBNUpload, ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExludeSucMsg);
		flag=removeVerify(ElsevierObjects.Promotion_ExclusionVariable_ISBNUplRem, ElsevierObjects.remove11, ElsevierObjects.remove12);
		Thread.sleep(medium);
		return flag;
	}

	//Validating ISBN Section
	public static boolean validateISBNSection(String condition,By ISBNText, By ISBNAdd, By ISBNErrMsg, By ISBNSucMsg, By ISBNAddList, By ISBNRem, String invalidISBN) throws Throwable {
		boolean flag = true;				
		try{
			if(!isElementPresent(ISBNText, "ISBN Text Box is Present")){
				flag = false;
			}				

			if(!isElementPresent(ISBNAdd, "ISBN Text Box is Present")){
				flag = false;
			}				
			driver.findElement(ISBNText).clear();
			Thread.sleep(medium);

			if(!type(ISBNText, invalidISBN /*readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("InvalidISBN") */,"Enter Invalid ISBN into the Text Box")){
				flag = false;
			}	

			if(!click(ISBNAdd, "Click on Add Button")){
				flag = false;
			}	
			Thread.sleep(medium);
			if(!verifyText(ISBNErrMsg, "The ISBN does not exist. Please enter new ISBN.", "Error Message")){
				flag = false;
			}	
			driver.findElement(ISBNText).clear();
			Thread.sleep(medium);
			driver.findElement(ElsevierObjects.Evolve_Admin_Prmlnk_CampaignCode).click();
			ReadingExcel re=new ReadingExcel();
			List<String> ISBNdata=re.columnData(5, "Ecom_TCID_10217", configProps.getProperty("TestData"));

			for(String ISBN:ISBNdata){	
				System.out.println(ISBN);

				driver.findElement(ISBNText).clear();
				Thread.sleep(medium);
				driver.findElement(By.xpath(".//*[@id='enddate']")).click();
				if(!type(ISBNText, ISBN ,"Enter valid ISBN into the Text Box")){
					flag = false;
				}

				if(!click(ISBNAdd, "Click on Add Button")){
					flag = false;
				}
				Thread.sleep(medium);	
				String sucMsg=getText(ISBNSucMsg, "");
				if(verifyText(ISBNSucMsg, "The Promotion Inclusion is successfully saved.", "Success Message")){
					Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is displayed");	
				}else{
					Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
				}
				if(!isElementPresent(ISBNAddList, "ISBN is Added successfully")){
					flag = false;
				}							
			}				
			if(!click(ISBNRem, "Click on Remove Button for the ISBN")){
				flag = false;
			}	
			if(!Alert()){
				flag = false;
			}
			if(condition.equalsIgnoreCase("exclusion")){
				List<WebElement> isbnDataAdded=driver.findElements(ElsevierObjects.Promotion_isbnListValueExclude);
				for(WebElement e: isbnDataAdded){
					System.out.println(e.getText());
					Reporters.SuccessReport("List of ISBNs added One by One into the Text box", "ISBN is added to the ISBN Text box Successfully : " + e.getText());
				}
			}else{
				List<WebElement> isbnDataAdded1=driver.findElements(ElsevierObjects.Promotion_isbnListValueInclude);
				for(WebElement e1: isbnDataAdded1){
					System.out.println(e1.getText());
					Reporters.SuccessReport("List of ISBNs added One by One into the Text box", "ISBN is added to the ISBN Text box Successfully : " + e1.getText());
				}
			}
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		Thread.sleep(medium);				
		return flag;			
	}

	//Validating CSV file upload section
	public static boolean uploadCSVFile(String condition, By ISBNBrowseBtn,By uploadBtn, By sucMsg) throws Throwable{				
		boolean flag = true;				
		try{
			String filePath = ReadingExcel.getAbsoulteFilePath(readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("UploadCSVFile"));

			uploadFile(ISBNBrowseBtn, filePath, "");
			Thread.sleep(high);			   
			if(!click(uploadBtn, "Click on Upload Button")){
				flag = false;
			}

			Thread.sleep(high);		
			String sucMsg1=getText(sucMsg, "");
			if(verifyText(sucMsg, "The file is uploaded successfully.", "Success Message")){
				Reporters.SuccessReport("Validate CSV ISBN File Upload Section", "The success message : "+sucMsg1+" is displayed <br> CSV file is uploaded from solution and the path is : \\TestData\\ISBNFile.csv");	
			}else{
				Reporters.failureReport("Validate CSV ISBN File Upload Section", "The failure message : "+sucMsg1+" is displayed <br> CSV file is failed to upload from solution and the path is : \\TestData\\ISBNFile.csv");	
			}

			if(condition.equalsIgnoreCase("exclusion")){
				List<WebElement> isbnDataAdded=driver.findElements(ElsevierObjects.Promotion_isbnListValueExclude);
				int size=isbnDataAdded.size();
				int count=0;
				for(WebElement e: isbnDataAdded)
				{
					if(count<3){
						Reporters.SuccessReport("List of ISBNs added by uploading the CSV file", "ISBN is added by uploading the CSV file is : " + e.getText());
						count++;
					}else{
						System.out.println("Come out from loop");
					}
				}
			}else{
				List<WebElement> isbnDataAdded=driver.findElements(ElsevierObjects.Promotion_isbnListValueInclude);
				int size=isbnDataAdded.size();
				int count=0;
				for(WebElement e: isbnDataAdded)
				{
					if(count<3){
						Reporters.SuccessReport("List of ISBNs added by uploading the CSV file", "ISBN is added by uploading the CSV file is : " + e.getText());
						count++;
					}else{
						System.out.println("Come out from loop");
					}
				}
			}
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		//Reporters.SuccessReport("", "");
		return flag;
	}


	public static boolean removeVerify(By remLnk, String rem1, String rem2) throws Throwable{
		boolean flag=true;
		try{

			List<WebElement> element=driver.findElements(remLnk);
			int getSize=element.size();
			for (int i = 1; i < getSize+1; i++) {
				String row1=getText(By.xpath(rem1+i+rem2), "");
				//driver.findElement(By.xpath(ElsevierObjects.remove1+i+ElsevierObjects.remove2)).getText();
				System.out.println(row1);
				if(row1.contains("remove")){
					System.out.println(row1);
					Reporters.SuccessReport("Remove link", "Remove Link is present for inclusion/Exclusion : "+row1);
				}else{

					Reporters.failureReport("Remove link", "Remove Link is not present for inclusion : "+row1);
				}
			}	
		}catch(Exception e){System.out.println(e.getMessage());return false;}
		return flag;
	}


}
