package com.cigniti.automation.BusinessFunctions;

import java.util.Random;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;

public class Instructor_loginAfterAddition_9794 extends EvolveCommonBussinessFunctions {
	
	
	public static boolean formFill() throws Throwable{
		boolean flag = true;
		try
		{
		String HESI_USER=ReadingExcel.columnDataByHeaderName("HESI_USERNAME", "HESI", configProps.getProperty("TestData"));

		if(!type(ElsevierObjects.educator_form_txtFirstName, ReadingExcel.columnDataByHeaderName("FirstName", "Tc-9794", configProps.getProperty("TestData")), "First Name")){
			flag = false;
		}
		
		if(!type(ElsevierObjects.educator_form_txtLastName, ReadingExcel.columnDataByHeaderName("LastName", "Tc-9794", configProps.getProperty("TestData")), "Last Name")){
			flag = false;
		}
		
		Random ra = new Random( System.currentTimeMillis() );
		String stdMail = ReadingExcel.columnDataByHeaderName("Emailid", "Tc-9794", configProps.getProperty("TestData")) + Integer.toString((1 + ra.nextInt(2)) * 100 + ra.nextInt(100))+"@evolveqa.info";
		
		//ReadingExcel.updateCellValue(3, 1, configProps.getProperty("TestData"), 10);
		if(!type(ElsevierObjects.educator_form_txtEmail, stdMail , "Email")){
			flag = false;
		}
		
		//ReadingExcel.updateCellValue(4, 1, configProps.getProperty("TestData"), 10);
		if(!type(ElsevierObjects.educator_form_txtConformEmail, stdMail, "ConformEmail")){
			flag = false;
		}
		
		if(!type(ElsevierObjects.educator_form_txtPassword, ReadingExcel.columnDataByHeaderName("Password", "Tc-9794", configProps.getProperty("TestData")), "Password")){
			flag = false;
		}
		
		if(!type(ElsevierObjects.educator_form_txtConformPassword, ReadingExcel.columnDataByHeaderName("Password", "Tc-9794", configProps.getProperty("TestData")), "Confirm Password")){
			flag = false;
		}
		if(!selectByVisibleText(ElsevierObjects.Institution_Country, ReadingExcel.columnDataByHeaderName("Country", "Tc-9794", configProps.getProperty("TestData")), "Institution Country")){
			flag = false;
		}
		
		if(!selectByVisibleText(ElsevierObjects.educator_form_State, ReadingExcel.columnDataByHeaderName("State", "Tc-9794", configProps.getProperty("TestData")), "Institution State")){
			flag = false;
		}
		
		if(!type(ElsevierObjects.educator_form_Town, ReadingExcel.columnDataByHeaderName("City", "Tc-9794", configProps.getProperty("TestData")), "Institution City")){
			flag = false;
		}
		
		if(!type(ElsevierObjects.educator_form_txtAddress, ReadingExcel.columnDataByHeaderName("Address1", "Tc-9794", configProps.getProperty("TestData")), "Instution Address")){
			flag = false;
		}
		
		if(!type(ElsevierObjects.educator_form_txtInstution, ReadingExcel.columnDataByHeaderName("Institution", "Tc-9794", configProps.getProperty("TestData")), "Instution Name")){
			flag = false;
		}
		
		if(!type(ElsevierObjects.educator_form_txtAddZipCode, ReadingExcel.columnDataByHeaderName("ZipCode", "Tc-9794", configProps.getProperty("TestData")), "ZipCode")){
			flag = false;
		}
		
		if(!type(ElsevierObjects.educator_form_txtAddPhone, ReadingExcel.columnDataByHeaderName("Phone", "Tc-9794", configProps.getProperty("TestData")), "PhoneNumber")){
			flag = false;
		}
		
		if(!selectByVisibleText(ElsevierObjects.educator_form_txtddprogramType, ReadingExcel.columnDataByHeaderName("Program", "Tc-9794", configProps.getProperty("TestData")), "Program Type")){
			flag = false;
		}
		
		if(!click(ElsevierObjects.educator_form_btnContinue,"Clicked on Continue Button")){
    		 flag = false;
    	}
		}
		catch(Exception e)
		{
		sgErrMsg=e.getMessage();
		return false;
		}
		 
		return flag;
	}
}
