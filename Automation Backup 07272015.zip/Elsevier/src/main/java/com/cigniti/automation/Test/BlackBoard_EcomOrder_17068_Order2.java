package com.cigniti.automation.Test;

import com.cigniti.automation.BusinessFunctions.BlackBoard_BusinessFunctions;
import com.cigniti.automation.BusinessFunctions.Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Database;
import com.cigniti.automation.Utilities.Reporters;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class BlackBoard_EcomOrder_17068_Order2 extends BlackBoard_BusinessFunctions {
	
	@Test
	public static void BlackBoard_EcomOrder_17068_Order2_Script() throws Throwable {
		
		Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions preorderFunctions = new Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions();
		
		// login to evolve admin
		stepReport("Login to Evolve Admin");
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		writeReport(preorderFunctions.adminLogin(), "Login to Evolve Admin", "Successfully logged into Evolve Admin", "Failed to log in to Evolve Admin");
		
		// edit the resource record of the product, run nocache url, and logout
		stepReport("Modify publication date/status");
		String isbn = ReadingExcel.columnDataByHeaderName("Order2_ProdISBN", "TC-17068", configProps.getProperty("TestData"));
		String preorderStatus = ReadingExcel.columnDataByHeaderName("PreorderStatus", "TC-17068", configProps.getProperty("TestData"));
		String preorderDate = ReadingExcel.columnDataByHeaderName("PreorderDate", "TC-17068", configProps.getProperty("TestData"));
		Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions.editResource(isbn);
		preorderFunctions.modifyPublicatonDate(preorderDate, preorderStatus);
		writeReport(launchUrl(configProps.getProperty("NoCacheURL")), "Run the URL https://evolvecert.elsevier.com/cs/noCache", "Successfully ran the URL https://evolvecert.elsevier.com/cs/noCache", "Failed to run the URL https://evolvecert.elsevier.com/cs/noCache");
		Thread.sleep(medium);
		driver.navigate().back();
		Thread.sleep(low);
		adminLogout();
		
		// login to blackboard as student
		stepReport("Login to BlackBoard as a student");
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		String username = ReadingExcel.columnDataByHeaderName("BB_Username", "TC-17068", configProps.getProperty("TestData"));
		String password = ReadingExcel.columnDataByHeaderName("BB_Password", "TC-17068", configProps.getProperty("TestData"));
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		writeReport(blackboardLogin(username, password), "Login to BlackBoard as a student",
				"Successfully logged into BlackBoard as user: " + username,
				"Failed to log into BlackBoard as user: " + username);
		
		// navigate to Academic Materials page
		stepReport("Navigate to Academic Materials");
		writeReport(gotoAcademicMaterials(), "Navigate to Academic Materials page",
				"Successfully navigated to Academic Materials page",
				"Failed to navigate to Academic Materials page");
		
		// verify course filter
		stepReport("Verify the Course filter");
		String courseName = ReadingExcel.columnDataByHeaderName("BB_CourseName", "TC-17068", configProps.getProperty("TestData"));
		writeReport(verifyFilter(ElsevierObjects.BB_CourseFilter, courseName, ""), "Verify the Course filter",
				"Course filter is displayed and has the correct default option: " + courseName,
				"Failed to verify the Course filter");
		
		// verify publisher filter
		stepReport("Verify the Publisher filter");
		String pubName = ReadingExcel.columnDataByHeaderName("BB_PubName", "TC-17068", configProps.getProperty("TestData"));
		writeReport(verifyFilter(ElsevierObjects.BB_PublisherFilter, "All", pubName), "Verify the Publisher filter",
				"Publisher filter has the correct default option: All</br>" +
				"Publisher filter has the following option available: " + pubName,
				"Failed to verify the Publisher filter");
		
		// verify the type filter
		stepReport("Verify the Type filter");
		writeReport(verifyFilter(ElsevierObjects.BB_TypeFilter, "All", ""), "Verify the Type filter",
				"Type filter is displayed and has the correct default option: All",
				"Failed to verify the Type filter");
		
		// place an order for the product
		stepReport("Place an order for the product");
		String title = ReadingExcel.columnDataByHeaderName("Order2_ProdTitle", "TC-17068", configProps.getProperty("TestData"));		
		writeReport(placeOrder(title, isbn, true), "Place order",
				"Successfully placed order for product:</br>" + title + "</br>" + isbn,
				"Failed to place order for product:</br>" + title + "</br>" + isbn);
		
		// verify the receipt page and save the order #
		stepReport("Verify the order receipt page");
		writeReport(receiptPage(title, isbn, true), "Verify order receipt page",
				"Successfully verified the order receipt page",
				"Failed to verify the order receipt page");
		
		// login to evolve admin
		stepReport("Login to Evolve Admin");
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		writeReport(preorderFunctions.adminLogin(), "Login to Evolve Admin", "Successfully logged into Evolve Admin", "Failed to log in to Evolve Admin");
		
		// revert changes to resource record, run nocache url, and logout
		stepReport("Revert changes to publication date/status");
		String originalStatus = ReadingExcel.columnDataByHeaderName("OriginalStatus", "TC-17068", configProps.getProperty("TestData"));
		String originalDate = ReadingExcel.columnDataByHeaderName("OriginalDate", "TC-17068", configProps.getProperty("TestData"));
		Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions.editResource(isbn);
		preorderFunctions.modifyPublicatonDate(originalDate, originalStatus);
		writeReport(launchUrl(configProps.getProperty("NoCacheURL")), "Run the URL https://evolvecert.elsevier.com/cs/noCache", "Successfully ran the URL https://evolvecert.elsevier.com/cs/noCache", "Failed to run the URL https://evolvecert.elsevier.com/cs/noCache");
		Thread.sleep(medium);
		driver.navigate().back();
		Thread.sleep(low);
		adminLogout();
		
		// run the preorder queue job
		stepReport("Run the preorder queue job");
		EcommerceWait.ecommerceWait();
		Reporters.SuccessReport("Run the preorder queue job", "Successfully ran the preorder queue job");
		
		// verify referral data in database
		stepReport("Verify the referral data");
		String orderNumber = ReadingExcel.columnDataByHeaderName("Order2", "TC-17068", configProps.getProperty("TestData"));
		writeReport(databaseVerification(orderNumber), "Verify the referral data",
				"Successfully verified the referral data for order: " + orderNumber,
				"Failed to verify referral data for order: " + orderNumber);
		
		// database cleanup
		stepReport("Database cleanup");
		Database.preorderDBCleanup();
		
	}
	
	@AfterTest
	public void tear() throws Throwable {
		
	}

}
