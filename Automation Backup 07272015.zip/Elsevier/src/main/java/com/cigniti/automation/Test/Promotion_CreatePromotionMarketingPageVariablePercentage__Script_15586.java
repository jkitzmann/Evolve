package com.cigniti.automation.Test;

import java.util.Random;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.Promotion_CreatePromotionMarketingPageSinglePercentage_15582;
import com.cigniti.automation.BusinessFunctions.Promotion_CreatePromotionMarketingPageVariablePercentage_15586;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class Promotion_CreatePromotionMarketingPageVariablePercentage__Script_15586 extends Promotion_CreatePromotionMarketingPageVariablePercentage_15586{
	public static String DMCode;
	Random ra = new Random( System.currentTimeMillis() );
	@Test
	public void createPromotionMarketingPageVariablePercentage_15586() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			DMCode=ReadingExcel.columnDataByHeaderName("DMcode", "PromotionTestData",testDataPath)+Integer.toString((1 + ra.nextInt(2)) * 100000 + ra.nextInt(100000));
			String PromotionCode=ReadingExcel.columnDataByHeaderName("PromotionCode", "PromotionTestData",testDataPath);
			String DiscountType2=ReadingExcel.columnDataByHeaderName("DiscountType2", "PromotionTestData",testDataPath);
			String CampaignCode=ReadingExcel.columnDataByHeaderName("CampaignCode", "PromotionTestData",testDataPath);
			String PromotionName=ReadingExcel.columnDataByHeaderName("PromotionName", "PromotionTestData",testDataPath);
			String TerritoryCode=ReadingExcel.columnDataByHeaderName("TerritoryCode", "PromotionTestData",testDataPath);
			String percentageOff=ReadingExcel.columnDataByHeaderName("PercentageOff", "PromotionTestData",testDataPath);
			String percentageOff1=ReadingExcel.columnDataByHeaderName("PercentageOff1", "PromotionTestData",testDataPath);
			String invalidPercentage=ReadingExcel.columnDataByHeaderName("invalidPercentage", "PromotionTestData",testDataPath);
			String percentage=ReadingExcel.columnDataByHeaderName("percentage", "PromotionTestData",testDataPath);		
			String healthNursing=ReadingExcel.columnDataByHeaderName("SearchProduct", "PromotionTestData", testDataPath);
			//String percentageCDROM=ReadingExcel.columnDataByHeaderName("percentageCDROM", "TC-15582", testDataPath);
			String variablePercentage=ReadingExcel.columnDataByHeaderName("variablePercentage", "PromotionTestData", testDataPath);
						
			writeReport(User_BusinessFunction.Studentlogin(sStudentUser, sStudentPassword),"Login to Application Using Student User Credentials : "+sStudentUser,
                    "Launching the URL for Student User is successful </br > Login to Application Using Student User credentails :"+sStudentUser+" is Successful",
                       "Launching and Login to Application Using Student User credentails : "+ sStudentUser+" is Failed");
			Thread.sleep(medium);
			writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as:"+sStudentUser,
                    "Navigating to CATALOG page is Successful",
                    "Navigating to CATALOG Page is failed");
			Thread.sleep(medium);
			writeReport(productSearch(healthNursing),"Searching for Value:"+healthNursing,
                      "Search for "+healthNursing+" is successfully verified ",
                      "Unable to Search for : "+ healthNursing+ " search results failed");
			Thread.sleep(medium);
			writeReport(clickDVDHardcover(),"Filter by DVD and Hardcover Product Types",
		            "Successfully Filtered the DVD Product type and HardCover product type on the page ",
		            "Failed to Filter the DVD Product type and HardCover product type on the page  ");
		
			productClick();
			
			/*writeReport(productClick(),"Click on the DVD Product's and <br>Navigate to the Next Page and Verify the presence of ADD TO CART button",
                    "Successfully Clicked on the DVD Product and  <br>Navigate to the Next Page and Verify the presence of ADD TO CART button </br > Click on the First DVD Product",
                    "Unable to Click on the Product DVD element ");*/
			
			Thread.sleep(medium);
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			writeReport(evolveAdminlogin(),"Login to Application Using Admin Credentials :"+adminUser,
                    "Launching the URL for Admin Credentials is successful </br > Login to Application Using Admin Credentials :"+adminUser+" is Successful",
                       "Launching and Login to Application Using Admin Credentials : "+ adminUser+" is Failed");
			
			Thread.sleep(medium);
			writeReport(checkPromotionLink(),"Click on the 'Global Promotion Exclusions' under the 'Promotion Management' Section",
                    "Global Promotion Exclusions Link is successfully clicked ",
                       "Clicking on the Global Promotion Exclusions Link is failed");
			Thread.sleep(medium);
			String isbn=isbnForFutureUse1;
			String isbn4=isbnForFutureUse4;
			ISBNExcludeGlobalPromotion(isbn);
			Thread.sleep(medium);
			click(ElsevierObjects.marketingPageSinglePercentage_PrmPge_EvlAdmnLnk, "Click on the Evolve Admin Bread Crumb");
			Thread.sleep(medium);
			addPromotionLink();
			Thread.sleep(medium);
					
			String user="variablePercentage";
			
			writeReport(inputValuesInPromotionCode(user, DMCode, "", "", DiscountType2, "", PromotionName, TerritoryCode, ""),  
					"Fill all the mandatory fields in Promotion Type under Add Promotion", 
					"Details are filled successfully: DM Code : "+DMCode+"<br> Discount Type : "+user+ "<br> Promotion Name : "+PromotionName+"<br> Territory Code : "+TerritoryCode+"<br> Promotion Name : "+percentageOff,
					"Failed to fill Details : DM Code : "+DMCode+"<br> Discount Type : "+user+ "<br> Promotion Name : "+PromotionName+"<br> Territory Code : "+TerritoryCode+"<br> Promotion Name : "+percentageOff+"<br> Promotion successfully saved. ");
			
			Thread.sleep(medium);
			//String user1="variablePercentage";
			//String percentageDVD="";
			writeReport(globalPromotionDVD(user, percentage),  
					"Select the DVD product type", 
					"DVD Product type is selected successful </br>and Validated by checking for the product added to the right side in a table", 
					"DVD Product type is not selected");
			Thread.sleep(medium);
			writeReport(ISBNExclude(variablePercentage),  
					"ISBN is added to exclude under ISBN Section", 
					"ISBN is successful added to the table", 
					"ISBN is not added to the table");
			Thread.sleep(medium);
			writeReport(viewMarketingPage(),  
					"View Marketing Page link is successfully clicked and navigated to the next page", 
					"View Marketing Page link is successfully clicked and navigated to the next page </br> Bread Crumb is present", 
					"View Marketing Page link is failed to click on the link </br> Bread Crumb is not present");
			Thread.sleep(medium);
			writeReport(detailsForFutureUse(),  
					"Details are stored for future use", 
					"Details DM Code, ISBN, Title and Price for 4 items are successfully saved for future use </br> DM Code is : "+DMCode+"</br>"+"ISBNs are : "+Promotion_CreatePromotionMarketingPageSinglePercentage_15582.isbnForFutureUse1+ "," +Promotion_CreatePromotionMarketingPageSinglePercentage_15582.isbnForFutureUse2+"," +Promotion_CreatePromotionMarketingPageSinglePercentage_15582.isbnForFutureUse3+","+Promotion_CreatePromotionMarketingPageSinglePercentage_15582.isbnForFutureUse4
					+"</br> The Titles are : "+Promotion_CreatePromotionMarketingPageSinglePercentage_15582.titleforfutureuse1+ "</br>"+Promotion_CreatePromotionMarketingPageSinglePercentage_15582.titleforfutureuse2 + "</br>"+Promotion_CreatePromotionMarketingPageSinglePercentage_15582.titleforfutureuse3 + "</br>"+Promotion_CreatePromotionMarketingPageSinglePercentage_15582.titleforfutureuse4 
					+ "</br>"+Promotion_CreatePromotionMarketingPageSinglePercentage_15582.priceforfutureuse1+"," +Promotion_CreatePromotionMarketingPageSinglePercentage_15582.priceforfutureuse2 +"," +Promotion_CreatePromotionMarketingPageSinglePercentage_15582.priceforfutureuse3 +"," +Promotion_CreatePromotionMarketingPageSinglePercentage_15582.priceforfutureuse4, 
					"Details ISBN, Title and Price for 4 items are failed to save for future use");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		//Base.tearDown();
	}
}



