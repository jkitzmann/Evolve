package com.cigniti.automation.BusinessFunctions;

import org.openqa.selenium.By;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class EComm_Preorder_MyEvolve_Page_15598_Bussiness_Functions extends Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions{

	@Override
	public boolean createAccessCode() throws Throwable {
		try{
		boolean flag =true;
		if(!click(ElsevierObjects.EVOLVE_BUTTON, "Evolve Button")){
			flag = false;
		}
		if(!click(ElsevierObjects.maintainProd, "Maintain Products.")){
			flag =false;
		}
		if(!type(ElsevierObjects.searchTitle,CINICAL_MEDICAL_ASSISTING_ONLIN_E,"ISBN")){
			flag = false;
		}
		if(!click(ElsevierObjects.btnserchTitle,"Search")){
			flag =false;
		}
		
		if(!click(By.xpath("//a[text()='"+CINICAL_MEDICAL_ASSISTING_ONLIN_E+"']"), "ISBN number")){
			flag =false;
		}
		Thread.sleep(3000);
		super.createAccessCode();
		
		if(!click(ElsevierObjects.DOWNLOAD_ACCESS_CODE, "Download Access Code")){
			flag =false;
		}
		if(!click(ElsevierObjects.DOWNLOAD_ACCESS_CODE_TXT, "Download Access Code Text.")){
			flag =false;
		}
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}
		return flag;
	}
	
	public void enterAsIndepentSelfStudy() throws Throwable{
		try{
		if(!click(ElsevierObjects.ENTER_AS_IND_BUTTON, "Enter As Independent Button")){
			flag = false;
		}
		
		String modalText = getText(ElsevierObjects.MODAL_HEADER, "Modal Dialogue");
		if(modalText.contains("Confirm Independent Self-Study")){
			Reporters.SuccessReport("Verify Modal Header", "Modal Header is Successfully dispalys with message" +modalText);
		}else{
			Reporters.failureReport("Verify Modal Header", "Unable to view the modal header message");
		}
		
		String conformMessage = getText(ElsevierObjects.MODAL_CONFORMATION, "Modal Dialogue Confirmation Message.");
		if(conformMessage.contains("")){
			Reporters.SuccessReport("Verify Confrom Message", "Conform Message is Successfully dispalys with message" +modalText);
		}else{
			Reporters.SuccessReport("Verify Confrom Message", "Conform Message is Successfully dispalys with message" +modalText);
		}
		
		String checkBoxMessage = getText(By.xpath("//*[@id='modalSelfStudy']/form/p[1]/label"), "Check Box Message");
		if(checkBoxMessage.contains(" I want to use this product")){
			Reporters.SuccessReport("Verify Message", " Message is Successfully dispalys with message" +modalText);
		}else{
			Reporters.SuccessReport("Verify  Message", " Message is Successfully dispalys with message" +modalText);
		}
		
		if(!click(ElsevierObjects.MODAL_CANCEL_BUTTON, "MODAL_CANCEL_BUTTON")){
			flag = false;
		}
		
		if(!click(ElsevierObjects.ENTER_AS_IND_BUTTON, "ENTER_AS_IND_BUTTON")){
			flag = false;
		}
		
		if(!click(ElsevierObjects.MODAL_CONFORM_BUTTON, "MODAL_CONFORM_BUTTON")){
			flag =false;
		}
		String courseId = getText(ElsevierObjects.ONLIE_COURSE_ID, "ONLIE_COURSE_ID");
		if(!courseId.equalsIgnoreCase("")){
			Reporters.SuccessReport("Verify Course Id", " CourseId is Successfully dispalys with message" +courseId);
		}else{
			Reporters.SuccessReport("Verify  Course Id", " CourseId is not dispalys");
		}
		
		if(click(ElsevierObjects.ONLINE_COURSE_LINK, "ONLINE_COURSE_LINK")){
			if(isElementPresent(ElsevierObjects.COURSE_TITLE, "")){
				Reporters.SuccessReport("Verify User navigation", "User Successfully naviagates to Catlog Page");
			}else{
				Reporters.SuccessReport("Verify User navigation", "User unable to naviagates to Catlog Page");
			}
		}
	
	}
	catch(Exception e)
	{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		
	}
	
}
}
