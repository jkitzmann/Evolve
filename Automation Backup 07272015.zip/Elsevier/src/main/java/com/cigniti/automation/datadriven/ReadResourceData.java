package com.cigniti.automation.datadriven;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cigniti.automation.Utilities.Property;
import com.google.common.collect.Maps;

public class ReadResourceData {

	public static Property configProps=new Property("config.properties");
	public static Map<String, String> dataMap = Maps.newHashMap();
	
	public static Map<String, String> readResourceData() throws IOException{
		
		FileInputStream file = new FileInputStream(new File(configProps.getProperty("ResourceFilePath")));
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheetAt(0);
		int rowCount =sheet.getLastRowNum()-sheet.getFirstRowNum();
		for(int i=0;i<rowCount;i++){
			Row r= sheet.getRow(i);
			dataMap.put(r.getCell(0).getStringCellValue(),r.getCell(1).getStringCellValue());
		}
		
		return dataMap;

	}
	
	public static String getResourceData(String key,String dynamicValue){
		String resourceName="";
		if(key!=null && !key.equalsIgnoreCase("")){
			resourceName = dataMap.get(key);
			resourceName =resourceName.replaceAll(",",dynamicValue);
		}
		return resourceName;
	}

}
