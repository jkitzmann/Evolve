package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.AccessCodePackageUnassignedAccessCodesUpload_10213;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.FileDelete;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class AccessCodePackageUnassignedAccessCodesUpload_Script_10213 extends AccessCodePackageUnassignedAccessCodesUpload_10213{
	
	@Test
	public void accessCodePackageUnassignedAccessCodesUpload_10213() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			String filePath = ReadingExcel.getAbsoulteFilePath(readcolumns.twoColumns(0, 1, "TC-10212", configProps.getProperty("TestData")).get("UploadDataFile"));
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			
			stepReport("Login to Evolve Admin.");
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials : "+ configProps.getProperty("AdminUser"),
	                "Launching the URL for User is successful </br > Login to Application Using User credentails : "+configProps.getProperty("AdminUser")+" is Successful",
	                   "Launching and Login to Application Using User credentails : "+ configProps.getProperty("AdminUser")+" is Failed");
			
			if(unassignedAccesscodeLink())
			{
	     		Reporters.SuccessReport("Unassigned Access code link ", "Successfully clicked on Unassigned access code link");
			}
			else
			{	
				Reporters.failureReport("Unassigned Access code link ", "Failed to clicked on Unassigned access code link");
			}
					
			//Step 2 is done manually
			stepReport("Create and download unassigned access codes.");
			verifyCodeCreation();
			if(clickDownloadAndCompareNotePadDataWithStringliterals()){
				Reporters.SuccessReport("Verify Access Codes generated", "Access Codes text file is downloaded and String literals verified successfully in the above steps");
			}
			else{
				Reporters.failureReport("Verify Access Codes generated", "Access Codes text file failed to download and String literals verified failed. ");
			}	
			if(!click(ElsevierObjects.Admin_Evolve_AdminLink, " Click on Evolve Admin Link")){
				flag = false;
			}
			
			stepReport("Upload unassigned access codes.");
			if(accesscodeUploadLink())
			{
	     		Reporters.SuccessReport("Access Code Upload Link", "Successfully Clicked on Access Code Upload Link ");
			}
			else
			{
				Reporters.failureReport("Access Code Upload Link", "Successfully Clicked on Access Code Upload Link ");
			}
			//String filePath1 = ReadingExcel.getAbsoulteFilePath(readcolumns.twoColumns(0, 1, "TC-10212", configProps.getProperty("TestData")).get("UploadDataFile"));
			if(verifyCopyToExcel(filePath))
			{
	     		Reporters.SuccessReport("Copy the access codes data from text file to excel file", "Successfully Copied the access codes available <br> in the text file to the excel file to upload");
			}
			else
			{
				Reporters.failureReport("Copy the access codes data from text file to excel file", "failed to Copy the access codes available <br> in the text file to the excel file to upload");
			}
			String filePathNew = ReadingExcel.getAbsoulteFilePath(readcolumns.twoColumns(0, 1,"TC-10212", configProps.getProperty("TestData")).get("UploadDataFile"));
			if(uploadExcel(filePath))
			{
	     		Reporters.SuccessReport("Upload Excel File", "Excel File Uploaded Successfully ");
			}
			else
			{
				Reporters.failureReport("Upload Excel File", "Excel File Fialed to Upload");
			}
			Thread.sleep(high);
			click(ElsevierObjects.Admin_Evolve_Link, "Click on Bread Crumb Evolve Admin");
			Thread.sleep(medium);
			String validAccessCodes=ReadingExcel.getCell(1, 2, filePath, "UploadFile");
			ReadingExcel.updateCellInSheet(2,1,configProps.getProperty("TestData"), "TC-10220", validAccessCodes);
			String user="upload";
			
			stepReport("Verify uploaded access codes.");
			if(accessCodeVerify(validAccessCodes, user))
			{
	     		Reporters.SuccessReport("Search Access Code", "Access Code Search Verification Successful ");
			}
			else
			{
				
				Reporters.failureReport("Search Access Code", "Access Code Search Verification Successful ");
			}
			
			if(adminLogout()){
				Thread.sleep(medium);
				/*if(!verifyTitle("Welcome To Evolve Admin"))
					flag = false;*/
				
				Reporters.SuccessReport("Logout Successful", "Successfully logout from admin");
			}
			else
			{
				
				Reporters.SuccessReport("Logout Successful", "logout failed from admin");
			}	
			FileDelete.deleteFile(downloadFilePath);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			FileDelete.deleteFile(downloadFilePath);
		}
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
	
}
