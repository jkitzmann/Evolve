package com.cigniti.automation.Utilities;


	import java.io.File;
	import java.io.IOException;
	import java.util.ArrayList;

	import org.testng.annotations.Test;

	import jxl.Cell;
	import jxl.Sheet;
	import jxl.Workbook;

	public class ReadData {


		public static Property configProps=new Property("config.properties");
		private static String inputFile;
		public static String result=null;
		public static int count=0;
		
		public static String browser=null;
		String strBrowserType[];
		static int len=0;
		static int i=0;

		/*public void setInputFile(String inputFile)
		{
			this.inputFile = inputFile;
		}*/
		

		public static  String readUserName()  
		{
			inputFile=configProps.getProperty("UserData");
			
			File inputWorkbook = new File(inputFile);
			Workbook w;
			String Uname=null;
		
			try {
				w = Workbook.getWorkbook(inputWorkbook);
				// Get the first sheet
				Sheet sheet = w.getSheet(0);

				Cell usernamecell;
			
				usernamecell =sheet.getCell(0, 0);
				Uname=usernamecell.getContents().toString();
						
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return Uname;
		}
		
		public static  String readPassword()  
		{
			inputFile=configProps.getProperty("UserData");
			File inputWorkbook = new File(inputFile);
			Workbook w;
			String Password=null;
		
			try {
				w = Workbook.getWorkbook(inputWorkbook);
				// Get the first sheet
				Sheet sheet = w.getSheet(0);
				Cell passwordCell;
				passwordCell =sheet.getCell(1, 0);
				Password=passwordCell.getContents().toString();
				
				
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return Password;
		}
		public static  String testdata()  
		{
			inputFile=configProps.getProperty("UserData");
			File inputWorkbook = new File(inputFile);
			Workbook w;
			String data=null;
		
			try {
				w = Workbook.getWorkbook(inputWorkbook);
				// Get the first sheet
				Sheet sheet = w.getSheet(0);
				Cell testdata;
				for (int i = 0; i < sheet.getRows(); i++) {
					testdata=sheet.getCell(0, i);
					data=testdata.getContents().toString();
				}
							
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return data;
		}

		public static  String validISBN()  
		{
			inputFile=configProps.getProperty("TestData");
			File inputWorkbook = new File(inputFile);
			Workbook w;
			String data=null;
		
			try {
				w = Workbook.getWorkbook(inputWorkbook);
				// Get the first sheet
				Sheet sheet = w.getSheet(0);
				Cell testdata;
				for (int i = 0; i < sheet.getRows(); i++) {
					testdata=sheet.getCell(0, i);
					data=testdata.getContents().toString();
				}
							
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return data;
		}

		/*@Test
		public static void main() throws IOException {
			ReadData test = new ReadData();
			test.setInputFile(configProps.getProperty("UserData"));
			test.read();
			
		}*/

	}


