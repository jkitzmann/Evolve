package com.cigniti.automation.Test;

import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EComm_Preorde_MyEvolve_Page15594_BussinessFunctions;
import com.cigniti.automation.BusinessFunctions.EComm_Preorder_MyEvolve_Page_15452_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.ECommercePackagependingcourseid_15461;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class Ecomm_Preorder_MyEvolve_Page_15452_2 extends EComm_Preorder_MyEvolve_Page_15452_Bussiness_Functions{
	
	@Test
	public void ecommPreorderMyEvolvePage15452_2() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		launchUrl(configProps.getProperty("URL4"));
		String username=readcolumns.twoColumns(0,1, "ECommercePreOrder", configProps.getProperty("TestData")).get("eCommPreorderMyEvolvePage15452");
		String password=readcolumns.twoColumns(0,2, "ECommercePreOrder", configProps.getProperty("TestData")).get("eCommPreorderMyEvolvePage15452");
		if(User_BusinessFunction.SignInAsDifferentUser(username, password)){
			Reporters.SuccessReport("Login into Application as same student user", "Successfully logged in as Student user with the credentials : <br> Username : "+username+"<br> Password : "+password);
		}else{
			Reporters.failureReport("Login into Application as same student user", "Failed to log in as Student user with the credentials : <br> Username : "+username+"<br> Password : "+password);
		}
				
		click(ElsevierObjects.Myevolve,"Click on my evolve");
		Thread.sleep(medium);
		String course=ReadingExcel.columnDataByHeaderName("course", "TC-15452", testDataPath);
		String button1=ReadingExcel.columnDataByHeaderName("button1", "TC-15452", testDataPath);
		String button2=ReadingExcel.columnDataByHeaderName("button2", "TC-15452", testDataPath);
		String courseType=ReadingExcel.columnDataByHeaderName("courseType", "TC-15452", testDataPath);
		ECommercePackagependingcourseid_15461.VerifyContentpagewithinputs(courseType,course,button1,button2,"Yes");
		//verifyOnlineCourseButtons();
		enterAsIndependentSelfStudy();
		EComm_Preorde_MyEvolve_Page15594_BussinessFunctions.courseDetailsPage(By.xpath("//*[@id='set']/li/div/div/a"),"contentHome");
		
		/*verifyTwoButtons();
		ECommercePackagependingcourseid_15461.VerifyContentpagewithinputs("Online Course","Clinical Medical Assisting Online for Clinical Procedures for Medical Assistants, 9th Edition","Enter Instructor's Course ID","Enter as Independent Self-Study","Yes");
		enterAsIndepentSelfStudy();
		verifySubFloders();*/
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}

