package com.cigniti.automation.Test;

import java.util.Random;
import java.util.Date;
import java.text.SimpleDateFormat;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.CreateFacultyUserafteraddingitemstoCart_9803;
import com.cigniti.automation.BusinessFunctions.CreateFacultyUserfromSplashPage_9799;
import com.cigniti.automation.BusinessFunctions.CreateStudentUserafteraddingitemstoCart_9802;
import com.cigniti.automation.BusinessFunctions.CreateStudentUserafteraddingitemstoCart_Hardgood_15588;
import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarte_Student_SplitOrders1_15597;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class CreateStudentUserafteraddingitemstoCart_Hardgood_Script_15588 extends CreateStudentUserafteraddingitemstoCart_Hardgood_15588 {
	
  @Test
  public void CreateStudentUserafteraddingitemstoCart_15588() throws Throwable{
	  
		 SwitchToBrowser(ElsevierObjects.studentBrowserType);
		 ISBN = ReadingExcel.columnDataByHeaderName("ISBN","TC-15588",configProps.getProperty("TestData"));
		 Firstname=ReadingExcel.columnDataByHeaderName("Firstname","TC-15588",configProps.getProperty("TestData"));
		 Lastname=ReadingExcel.columnDataByHeaderName("Lastname","TC-15588",configProps.getProperty("TestData"));
		 Date today = new Date();
		 SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
		 Random ra = new Random( System.currentTimeMillis() );
	     EmailId =ReadingExcel.columnDataByHeaderName("EmailId","TC-15588",configProps.getProperty("TestData"))+Integer.toString((1 + ra.nextInt(2)) * 1000 + ra.nextInt(1000))+"-"+sdf.format(today)+"@evolveqa.info";	
	     Password=ReadingExcel.columnDataByHeaderName("Password","TC-15588",configProps.getProperty("TestData"));
		 ConformPassword=ReadingExcel.columnDataByHeaderName("ConformPassword","TC-15588",configProps.getProperty("TestData"));
		 Country=ReadingExcel.columnDataByHeaderName("Country","TC-15588",configProps.getProperty("TestData"));
		 State=ReadingExcel.columnDataByHeaderName("State","TC-15588",configProps.getProperty("TestData"));
		 City=ReadingExcel.columnDataByHeaderName("City","TC-15588",configProps.getProperty("TestData"));
		 Institution=ReadingExcel.columnDataByHeaderName("Institution","TC-15588",configProps.getProperty("TestData"));
		 StreetAddress=ReadingExcel.columnDataByHeaderName("StreetAddress","TC-15588",configProps.getProperty("TestData"));
	     Zipcode=ReadingExcel.columnDataByHeaderName("ZipCode","TC-15588",configProps.getProperty("TestData"));
		 ProgramType=ReadingExcel.columnDataByHeaderName("ProgramType","TC-15588",configProps.getProperty("TestData"));
	     Year=ReadingExcel.columnDataByHeaderName("Year","TC-15588", configProps.getProperty("TestData"));
		 isbn = ReadingExcel.columnDataByHeaderName("isbnnew","TC-15588",configProps.getProperty("TestData"));
		 CityAddress=ReadingExcel.columnDataByHeaderName("CityAddress", "TC-15588",configProps.getProperty("TestData"));
		 StateAddress=ReadingExcel.columnDataByHeaderName("StateAddress","TC-15588",configProps.getProperty("TestData"));
		
		 stepReport("Add item to cart and enter checkout");
		 writeReport(CreateStudentUserafteraddingitemstoCart_Hardgood_15588.Studentafteraddingtocart(),"Login and Register for product",
                                                                                                       "Successfully Launched EVOLVECERT URL </br> User is taken to Student Honeypot page </br> Searched for the product from searchbox and ISBN is :" +ISBN+ 
                                                                                                       "</br> Registered for the product </br> Click on Reedem/Checkout button",
                                                                                                       "Failed to Launch the URL and Register for product");
	     Thread.sleep(medium);
	     stepReport("Complete checkout");
	     writeReport(CreateStudentUserafteraddingitemstoCart_Hardgood_15588.AccountRegistration(),"Enter details into Registration form and submit the order",
                                                                                                  "Entered details Successfully into Registration form,submitted the order and page is navigated to confirmation page",
                                                                                                  "Failed to enter the Registration form and to enter details");
	     Thread.sleep(veryhigh);
	     stepReport("Verify receipt page");
	     writeReport(CreateStudentUserafteraddingitemstoCart_Hardgood_15588.confirmationpage(),"Verify details in confirmation page,Relogin using details and verify the product",
                                                                                               "Successfully verified the confirmation page,Relogin and verified the details of the product",
                                                                                               "Failed to verify the confirmation page,Relogin and verify the details of the product");
	     Thread.sleep(medium);
	    
	     /*writeReport(CreateStudentUserafteraddingitemstoCart_Hardgood_15588.emailVerification(),"Launch Email URL,login and search the Email registered",
                                                                                                "Successfully Email URL Launched,login and Registered Email is reached,",
                                                                                                "Failed to Launch,login and get Registered Email");*/
	     //SwitchToBrowser("Chrome");
	     stepReport("Verify email");
		 if(emailLogin()){
			 Reporters.SuccessReport("Email login:", "Successfully logged into User Email.");
		 }
		 else{
			 Reporters.failureReport("Email Login:", "Failed to login into User Email.");
		 }
	     CreateFacultyUserafteraddingitemstoCart_9803.emailVerification();
  
  }
}
