package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.AcesscodeBusinessfunctions15558;
import com.cigniti.automation.BusinessFunctions.Admin_BusinessFunction;
import com.cigniti.automation.BusinessFunctions.EComm_Preorde_MyEvolve_Page15594_BussinessFunctions;
import com.cigniti.automation.BusinessFunctions.EComm_Preorder_MyEvolve_Page_15452_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.EComm_Preorder_MyEvolve_Page_15598_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.ECommercePackagependingcourseid_15461;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class Ecomm_Preorder_MyEvolve_Page_15598_Script2  extends  ECommercePackagependingcourseid_15461{

	String product1;
	String product2;
	String originalProduct;
	@Test
	public void Ecomm_Preorder_MyEvolve_Page_TC15598() throws Throwable{
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		//Step 1:Complete test cases:  LO Unique Course Fulfillment-Faculty and capture the product id
		//product1 = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15598", configProps.getProperty("TestData")).get("ISBN1");
		//product2 = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15598", configProps.getProperty("TestData")).get("ISBN2");
		 /*String ISBN1=ReadingExcel.columnDataByHeaderName( "ISBN1", "TC-15598",configProps.getProperty("TestData"));	
		 String ISBN2=ReadingExcel.columnDataByHeaderName( "ISBN2", "TC-15598",configProps.getProperty("TestData"));
		 String Date=ReadingExcel.columnDataByHeaderName( "Date_New", "TC-15598",configProps.getProperty("TestData"));
		 String discount1=ReadingExcel.columnDataByHeaderName("Discount1", "TC-15461", testDataPath);
			String discount2=ReadingExcel.columnDataByHeaderName("Discount2", "TC-15461", testDataPath);
			String streetAddress=ReadingExcel.columnDataByHeaderName("StreetAddress","TC-15588",configProps.getProperty("TestData"));
			String zip=ReadingExcel.columnDataByHeaderName("ZipCode","TC-15588",configProps.getProperty("TestData"));
			String cityAddress=ReadingExcel.columnDataByHeaderName("CityAddress", "TC-15588",configProps.getProperty("TestData"));
			String stateAddress=ReadingExcel.columnDataByHeaderName("StateAddress","TC-15588",configProps.getProperty("TestData"));*/
			
			String course1=ReadingExcel.columnDataByHeaderName("course1", "TC-15598", testDataPath);
			String course2=ReadingExcel.columnDataByHeaderName("course2", "TC-15598", testDataPath);
			String username=readcolumns.twoColumns(0,1, "ECommercePreOrder", configProps.getProperty("TestData")).get("eCommPreorderMyEvolvePage15598");
			String password=readcolumns.twoColumns(0,2, "ECommercePreOrder", configProps.getProperty("TestData")).get("eCommPreorderMyEvolvePage15598");
			String user="student";
			writeReport(EvolveCommonBussinessFunctions.existingUserLogin(user,username,password),"Launching The URL And Login to Application.",
					"Launching the URL for User is successful </br > Login to Application Using User credentails :"+username+" is Successful",
					"Launching and Login to Application Using User credentials : "+ username+" is Failed");
			//clickEvolveAndVerifyUserContent();
			
			String course1ProductType=ReadingExcel.columnDataByHeaderName("course1ProductType", "TC-15598", testDataPath);
			String course2ProductType=ReadingExcel.columnDataByHeaderName("Course2ProductType", "TC-15598", testDataPath);
			VerifyContentpagewithinputs(course1ProductType,course1,"Enter Instructor's Course ID","Enter as Independent Self-Study","Yes");
			VerifyContentpagewithinputs(course2ProductType,course2,"Enter Instructor's Course ID","","Yes");
			//Thread.sleep(high);
			//EComm_Preorde_MyEvolve_Page15594_BussinessFunctions.courseDetailsPage(ElsevierObjects.contentLink1,"contentHome");
			Thread.sleep(5000);
			/*String courseID1=ReadingExcel.columnDataByHeaderName("Courseid1", "TC-15588", testDataPath);
			String courseID2=ReadingExcel.columnDataByHeaderName("Courseid2", "TC-15588", testDataPath);*/
			
			writeReport(AcesscodeBusinessfunctions15558.clickonbutton_coursedetails(course1,"Enter as Independent Self-Study"),"Click on Button under Course Details"+course1,"Clicking on Button Enter as Independent Self Study is Successful on course"+course1,"Clicking on Button Enter as Independent Self Study is not Successful on online course"+course1);
			AcesscodeBusinessfunctions15558.confirmbutton();
			Thread.sleep(3000);
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve"))
			{
				flag=false;
			}
			
			writeReport(AcesscodeBusinessfunctions15558.clickon_coursedetails(course1),"Click on Course Details"+course1,"Clicking on Course is Successful "+course1,"Clicking on Course is not Successful "+course1);
			//writeReport(AcesscodeBusinessfunctions15558.clickon_coursedetails("Clinical Medical Assisting Online for Clinical Procedures for Medical Assistants, 9th Edition"),"Click on Course Details","Clicking on Course is Successful","Clicking on Course is not Successful");
			Thread.sleep(high);
			AcesscodeBusinessfunctions15558.verifyingcoursedetailsafternavigationforcourse();
			
			//writeReport(AcesscodeBusinessfunctions15558.clickon_coursedetails(course2),"Click on Course Details"+course2,"Clicking on Course is Successful "+course2,"Clicking on Course is not Successful "+course2);
			//writeReport(AcesscodeBusinessfunctions15558.clickon_coursedetails("Clinical Medical Assisting Online for Clinical Procedures for Medical Assistants, 9th Edition"),"Click on Course Details","Clicking on Course is Successful","Clicking on Course is not Successful");
			Thread.sleep(5000);
			AcesscodeBusinessfunctions15558.verifyingcoursedetailsafternavigationforcourse();
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve"))
			{
				flag=false;
			}
			Thread.sleep(5000);
			//writeReport(AcesscodeBusinessfunctions15558.clickon_coursedetails("PBC Test - UAT0237 - SimChart eComm (SME), 1st Edition"),"Click on Course Details","Clicking on Course is Successful","Clicking on Course is not Successful");
			//FileDelete.deleteFile();
			writeReport(AcesscodeBusinessfunctions15558.clickonbutton_coursedetails(course2,"Enter Instructor's Course ID"),"Click on Button under Course Details" +course2,"Clicking on Button Enter Instructor's Course ID is Successful on Course Details"+course2,"Clicking on Button Enter Instructor's Course ID is not Successful on course details"+course2);
			String Courseid=ReadingExcel.columnDataByHeaderName("Courseid2", "TC-15598",configProps.getProperty("TestData"));
			Thread.sleep(6000);
			
			AcesscodeBusinessfunctions15558.Entercourseid(Courseid);
			writeReport(AcesscodeBusinessfunctions15558.clickon_coursedetails(course2),"Click on Course Details"+course2,"Clicking on Course is Successful:" +course2,"Clicking on Button is not Successful :"+course2);
			Thread.sleep(6000);
			AcesscodeBusinessfunctions15558.verifyingcoursedetailsafternavigationforcontenthome();
			
			
		   /*
		    Processvalue=ReadingExcel.columnDataByHeaderName("Processvalue2", "TC-15598", configProps.getProperty("TestData"));
			 StatuCode=ReadingExcel.columnDataByHeaderName("StatuCodeUpdate2", "TC-15598", configProps.getProperty("TestData"));
			 Date=ReadingExcel.columnDataByHeaderName("Date_Old", "TC-15598",configProps.getProperty("TestData"));
		   
			 
		   
			 writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials"+ configProps.getProperty("AdminUser"),
	                "Launching the URL for User is successful </br > Login to Application Using User credentails :"+configProps.getProperty("AdminUser")+" is Successful",
	                   "Launching and Login to Application Using User credentails : "+ configProps.getProperty("AdminUser")+" is Failed");
		   			
		   writeReport(Admin_BusinessFunction.NavigatetoBusinessProducts(), "Navigating to Basic Product Reports under ONIX PPM Load Data Manager ",  
					                                                          "Navigating to Basic Product Reports under ONIX PPM Load Data Manager is Successful ",
					                                                          "Navigating to Basic Product Reports under ONIX PPM Load Data Manager is failed ");
		
		   writeReport(Admin_BusinessFunction.EditISBNStatusCode(ISBN1, Processvalue,Date,StatuCode), "Editing ISBN : " +ISBN1,  
				   "Entering ISBN "+ISBN1+" is successful </br> Selecting "+Processvalue+" is Successful</br> Clicking on Go is Successful </br> Selecting "+StatuCode+" is Successful</br>Entering Date is "+Date+"is Successful </br>Clicking on Edit is Successful</br> 'Product Resource is successfully updated' Message appeared",
                                                                         "Editing ISBN is failed");

		   writeReport(Admin_BusinessFunction.EditISBNStatusCode(ISBN2, Processvalue,Date,StatuCode), "Editing ISBN2 : " +ISBN2,  
				   "Entering ISBN "+ISBN2+" is successful </br> Selecting "+Processvalue+" is Successful</br> Clicking on Go is Successful </br> Selecting "+StatuCode+" is Successful</br>Entering Date is "+Date+"is Successful </br>Clicking on Edit is Successful</br> 'Product Resource is successfully updated' Message appeared",
                                                                         "Editing ISBN is failed");

		   Thread.sleep(5000);
*/
	}
}
