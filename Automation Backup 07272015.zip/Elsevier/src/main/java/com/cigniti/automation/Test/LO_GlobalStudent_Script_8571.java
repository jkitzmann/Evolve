package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.ConvertLOTrialCoursetoPermanentPending_15566;
import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarte_Student_SplitOrders1_15597;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentFaculty_15243;
import com.cigniti.automation.BusinessFunctions.LO_GlobalStudent_8571;
import com.cigniti.automation.BusinessFunctions.LO_Global_Instructor_AR_8572;
import com.cigniti.automation.BusinessFunctions.SelfEnrollLOCourseHomePage_10303;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class LO_GlobalStudent_Script_8571 extends LO_GlobalStudent_8571 {

	@Test 
	public void lo_GlobalStudent_8571() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			String courseID=readcolumns.twoColumns(0, 1, "TC-9826 & 8572", configProps.getProperty("TestData")).get("CourseID");
			String courseTitle=readcolumns.twoColumns(0, 1, "TC-9826 & 8572", configProps.getProperty("TestData")).get("Educator_course_Title");
		
			stepReport("Create new student user");
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			writeReport(EvolveCommonBussinessFunctions.CreateNewUser("student"),"Creating Student User From Student Page.", 
					"Successfuully Created New Student User Username:"+credentials[0]+", Password:"+credentials[1]+"</br>User Now logged Into Evolve Cert As A Student.",
					"Failed To Create New Student User.");
			
			String product = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("Product"); 
			String productCost = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("ProductCost");
		
			stepReport("Search for product and add to cart");
			writeReport(EvolveCommonBussinessFunctions.searchProduct(product,productCost),"Serach for the product..",
					  "Successfully Entered ISBN:"+product+" in Search Box.</br>Clicked On Go Button.</br>Navigated To Product Details Page.",
					  "Failed to Enter ISBN:"+product+" in Search Box.");
		
			writeReport(EvolveCommonBussinessFunctions.requestProduct(),"Clicking on the Register For This Product Button In Product Details Page.",
					"Successfully clicked on Register For This Product Button.",
					"Failed to click on Register For This Product Button.");
			
			stepReport("Verify cart contents and enter checkout");
			LO_Global_Instructor_AR_8572.myCart();
			
			//String user="Student";
			String country=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("country"); 
			String state=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("state"); 
			String city=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("city"); 
			String institution=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("institute"); 
			String programtype=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("programType"); 
			String year=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("year"); 
			
			stepReport("Complete checkout and submit order");
			writeReport(LO_GlobalStudent_8571.studentInstitution(country,state,city,institution,programtype,year),"Entering Student Institution Details.",
			"Successfully Entered Student Institution Details.",
			"Failed To Enter Student Institution Details.");
			
			SelfEnrollLOCourseHomePage_10303.StudentReviewandSubmit();
			
			stepReport("Verify receipt page");
			receiptPage();
		
			stepReport("Verify course link and course contents");
			ConvertLOTrialCoursetoPermanentPending_15566.myEvolve();
			
			LO_GlobalStudent_8571.student_courseId_search(courseID,courseTitle);
			
			ECommercePreorderALaCarte_Student_SplitOrders1_15597.getStudentAccountDetails();
		
			writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the Student page.", 
					"Sucecssfully logged out the Student:"+credentials[0], 
					"Failed to logout the Student page:"+credentials[0]);
			
			stepReport("Verify email");
			writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Login In Into Evolve Email Page.", 
					  "Succesfully login into Evole Email Page.", 
					  "Failed to login into Evolve Email Page.");
			
			String emailid=EvolveCommonBussinessFunctions.getAccountDetailsEmail;
			writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(emailid),"Search email in evolve webmail.",
													"Successfully entered the emailid "+emailid+" in search box.",
													"Failed to enter email id.");
			
			String emailTitle=readcolumns.twoColumns(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("studentTitle");
			
			verifyTitleInEmailBody(emailTitle);
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}

