package com.cigniti.automation.Utilities;

import com.cigniti.automation.Test.*;
import com.cigniti.automation.accelerators.*;
import com.cigniti.automation.BusinessFunctions.*;
import com.cigniti.automation.datadriven.*;
import com.cigniti.automation.ObjectRepository.*;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class RegressionBatch {

	@Test
	public static void main(String[] args) {
		
		
		try {
			
			//LO_Unique_CourseFulfillment_Faculty_Script_10410 S=new LO_Unique_CourseFulfillment_Faculty_Script_10410();
			//S.loUniqueCoursefulfillmentFaculty_10410();
			
			// 10438:  Roster submission from within course.
			RosterSubmissionfromwithincourse_Script_10438.rosterSubmissionfromwithincourse_10438();
			
			/*
			// 9796:  Self-enroll LO course.
			SelfEnrollLOCourse_9796_Script enrollmentScript = new SelfEnrollLOCourse_9796_Script();
			enrollmentScript.SelfEnrollLOCourse9796();
			
			// 15562:  VST access code from My Cart (student).
			VitalSourceAccount_AC_MyCart_Student_Script_15562 VSTscript = new VitalSourceAccount_AC_MyCart_Student_Script_15562();
			VSTscript.vitalSourceAccount_AC_MyCart_Student_15562();
			
			// 15225:  KNO access code from home page (existing student).
			KNOACfromHomePage_ExistingStudentScript_15225 KNOscript = new KNOACfromHomePage_ExistingStudentScript_15225();
			KNOscript.KNOHomeExistingStudent_15225();
			*/
			
			// 9833:  Product search (student)
			//ProductSearchPortal_Student_9833 searchScript = new ProductSearchPortal_Student_9833();
			//searchScript.ProductSearchPortal_Student_9833();
			//HtmlReporters.createHtmlSummaryReport();
			
		} catch(Throwable e) {
			e.printStackTrace();
		}

	}
	
	@AfterTest
	public void tear() throws Throwable{
		
	}
	
}
