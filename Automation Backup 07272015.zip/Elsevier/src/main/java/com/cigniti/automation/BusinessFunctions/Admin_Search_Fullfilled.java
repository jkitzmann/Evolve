package com.cigniti.automation.BusinessFunctions;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class Admin_Search_Fullfilled extends EvolveCommonBussinessFunctions{
	 
	public static boolean EducatorLogin() throws Throwable{
		boolean flag = true;
	try{
		webDriver.manage().deleteAllCookies();
		//driver.manage().deleteAllCookies();
		if(!launchUrl(configProps.getProperty("URL"))){
			flag = false;
			
		}
		
		if(!clickOnMainPageLink()){
			flag=false;
		}
		if(!click(ElsevierObjects.iameducator, "Clicked on Educator")){
				flag = false;
		}
		Thread.sleep(medium);
			if(!click(ElsevierObjects.login, "login link")){
				flag = false;
		} 
			if(!type(ElsevierObjects.email,configProps.getProperty("Educator_UserName"),"Email")){
				flag = false;
		}
			if(!type(ElsevierObjects.password,configProps.getProperty("Educator_passWord"), "password")){
				flag = false;
		}
			if(!click(ElsevierObjects.submit, "login submit")){
				flag = false;
		}
			Thread.sleep(medium);
	}
			catch(Exception e){
				sgErrMsg=e.getMessage();return false;
			}
			return flag;
	}
	
	public static boolean EducatorLogin2() throws Throwable{
		boolean flag = true;
		try{
		webDriver.manage().deleteAllCookies();
		if(!launchUrl(configProps.getProperty("URL"))){
			flag = false;
			
		}
		
		if(!click(ElsevierObjects.login, "login link")){
				flag = false;
		} 
			if(!type(ElsevierObjects.email,configProps.getProperty("Educator_UserName"),"Email")){
				flag = false;
		}
			if(!type(ElsevierObjects.password,configProps.getProperty("Educator_passWord"), "password")){
				flag = false;
		}
			if(!click(ElsevierObjects.submit, "login submit")){
				flag = false;
		}
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
			return flag;
	}
	public static boolean Admin_searchCourse() throws Throwable{
		boolean flag = true;
	try{
		Thread.sleep(medium);
		if(!click(ElsevierObjects.lnkevolvecart, "Clicked on Evolve")){
			flag = false;
		}
		Thread.sleep(medium);
		if(!type(ElsevierObjects.txtproductsearch,readcolumns.twoColumns(0, 1,"TC-9826 & 8572", configProps.getProperty("TestData")).get("Educatorsearch_Num"), "text to search")){
			flag = false;
		}
		if(!click(ElsevierObjects.gobutton, "search button")){
			flag = false;
		}
		Thread.sleep(medium);
		if(!waitForElementPresent(ElsevierObjects.btnaddtocart,"Request this product now")){
			flag = false;
		}
	}
		catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
		return flag;	
	}
	public boolean click_Request() throws Throwable{
		
		boolean flag=true;
	try{	
		Thread.sleep(high);
		if(!click(ElsevierObjects.Educator_RequestProduct_btn,"Click Request button")){
			flag=false;
		}
		price=getText(ElsevierObjects.Educator_RequestPage_btn, "price");
 		 expectedPrice="$0.00";
 		  Thread.sleep(high);
 		 if(price.equals(expectedPrice)){
 			if(!click(ElsevierObjects.checkout, "Redeem Checkout")){
 				flag = false;
 			}
 		 }
	}
 		catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
 		return flag;

	}
	
	
	 public static boolean check_Approvedstatus() throws Throwable {
		 boolean flag=true;
		try{
		 String s1=getText(ElsevierObjects.Admin_Apprstatus_BeforeChk,"Status"); 
		 if(!click(ElsevierObjects.Admin_AdoptionSerach_Approve_chk,"Adoption checkbox click")){
				flag=false;
		 }
		 Thread.sleep(medium);
		 if(!click(ElsevierObjects.Admin_Submit_btn,"submit button click")){
				flag=false;
		 }
		 String s2=getText(ElsevierObjects.Admin_Apprstatus_AfterChk,"Status");
		 System.out.println(s2);
		 if(s1!=s2)
		 	{
			 if(!click(ElsevierObjects.Admin_Fulfil_chk,"Fullfilled checkbox click")){
					flag=false;
				}
			/* if(!click(ElsevierObjects.Admin_Email_chk,"Email checkbox click")){
					flag=false;
				}*/
			 if(!click(ElsevierObjects.Admin_Submit_btn,"submit button click")){
					flag=false;
			 	}
		 	}
		}
		 catch(Exception e){
				sgErrMsg=e.getMessage();return false;
			}
		 return flag;
		 }
	 public static boolean admin_Adoptionsearch() throws Throwable{
		   boolean flag=true;
	  try{
		   if(!click(ElsevierObjects.searchAR,"Adoption Requests")){
		    flag = false;
		   }
		   if(!waitForElementPresent(ElsevierObjects.btndatesearch, "search button")){
		    flag = false;
		   }
		   if(!click(ElsevierObjects.rbtndate, "date Radio button")){
		    flag = false;
		   }
		   Thread.sleep(medium);
		   if(!type(ElsevierObjects.Adoption_userId, readcolumns.twoColumns(0, 1,"TC-9826 & 8572", configProps.getProperty("TestData")).get("UserID"), "Adoption search User Id")){
		    flag = false;
		   }
		   if(!click(ElsevierObjects.btndatesearch, "search button")){
		    flag = false;
		   }
		   Thread.sleep(medium);
	 }
	 catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
		   return flag;
		 }
	 public static boolean educator_courseId_search() throws Throwable {
			 boolean flag=true;
			 /*if(!waitForElementPresent(ElsevierObjects.Educator_CourseId_search, "Online couse id")){
				 flag=false;
				}*/
		try{
			 Thread.sleep(medium);
			 String sucMsg=getText(ElsevierObjects.Educator_CourseId_search, "");
			 if(verifyText(ElsevierObjects.Educator_CourseId_search,readcolumns.twoColumns(0, 1, "TC-9826 & 8572", configProps.getProperty("TestData")).get("Educator_CourseID"), "Online couse id")){
				 Reporters.SuccessReport("Online CourseID search", "The success message : "+sucMsg+" is successfully displayed");	
				}else{
					Reporters.failureReport("Online CourseID search", "The success message : "+sucMsg+" is failed to display");
				}
			 Thread.sleep(medium);
			 if(!click(ElsevierObjects.Educator_CourseId_Click,"click on online course")){
					
				 flag=false;
			 } 
			 Thread.sleep(medium);
		}
		 catch(Exception e){
				sgErrMsg=e.getMessage();return false;
			}
	return flag;

}
}