package com.cigniti.automation.Test;

import java.util.Random;

import jxl.Sheet;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.HESI_BusinessFunction;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;


public class HESI_Instructor_Update_9859 extends User_BusinessFunction {
	
	//**************************** Declarations *****************************************************
 	public static Sheet inputSheetObj =null;
	//Random ra = new Random( System.currentTimeMillis() );
	@Test
	public void HESI_InstructorUpdate_9859() throws Throwable
	
	{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());

		stepReport("Login to Evolve as existing Instructor");
		writeReport(SwitchToBrowser(ElsevierObjects.studentBrowserType),"Launching Browser to Educator","Launching Browser to Educator is succesful","Lanching Browser to Educator is failed");

		String HESI_USER=ReadingExcel.columnDataByHeaderName("HESI_USERNAME", "HESI", configProps.getProperty("TestData"));        
	    String HESI_Password=ReadingExcel.columnDataByHeaderName("HESI_PASSWORD", "HESI", configProps.getProperty("TestData"));
	        
//			
        String HESIEducator=ReadingExcel.columnDataByHeaderName("HESI_FACULTYUSER", "HESI", configProps.getProperty("TestData"));
        String HESIEducatorPassword=ReadingExcel.columnDataByHeaderName("HESI_FACULTYPASSWORD", "HESI", configProps.getProperty("TestData"));
        
        String Firstname=ReadingExcel.columnDataByHeaderName("FirstName", "TC-9859", configProps.getProperty("TestData"));
        String Lastname=ReadingExcel.columnDataByHeaderName("LastName", "TC-9859", configProps.getProperty("TestData"));
        String Emailid=ReadingExcel.columnDataByHeaderName("Emailid", "TC-9859", configProps.getProperty("TestData"));
        String Instution=ReadingExcel.columnDataByHeaderName("Institution", "TC-9859", configProps.getProperty("TestData"));
        String Mobile=ReadingExcel.columnDataByHeaderName("Phone", "TC-9859", configProps.getProperty("TestData"));
        String Address1=ReadingExcel.columnDataByHeaderName("Address1", "TC-9859", configProps.getProperty("TestData"));
        String Address2=ReadingExcel.columnDataByHeaderName("Address2", "TC-9859", configProps.getProperty("TestData"));
        String Country=ReadingExcel.columnDataByHeaderName("Country", "TC-9859", configProps.getProperty("TestData"));
        String State=ReadingExcel.columnDataByHeaderName("State", "TC-9859", configProps.getProperty("TestData"));
        String City=ReadingExcel.columnDataByHeaderName("City", "TC-9859", configProps.getProperty("TestData"));
        String Program=ReadingExcel.columnDataByHeaderName("Program", "TC-9859", configProps.getProperty("TestData"));
        String ZipCode=ReadingExcel.columnDataByHeaderName("ZipCode", "TC-9859", configProps.getProperty("TestData"));
       // String Catalogs=ReadingExcel.columnDataByHeaderName("Catalogs", "TC-8563AndTC-8565", configProps.getProperty("TestData"));
        
        String Hesi_firstname=ReadingExcel.columnDataByHeaderName("Hesi_Firstname", "TC-9859", configProps.getProperty("TestData"));
        String Hesi_lastname=ReadingExcel.columnDataByHeaderName("Hesi_lastname", "TC-9859", configProps.getProperty("TestData"));
        String Hesi_Email=ReadingExcel.columnDataByHeaderName("Hesi_Email", "TC-9859", configProps.getProperty("TestData"));
        String Hesi_Areacode=ReadingExcel.columnDataByHeaderName("Hesi_AreaCode", "TC-9859", configProps.getProperty("TestData"));
        String Hesi_Phonenumber=ReadingExcel.columnDataByHeaderName("Hesi_Phonenumber", "TC-9859", configProps.getProperty("TestData"));
        String Hesi_Comments=ReadingExcel.columnDataByHeaderName("Hesi_Comments", "TC-9859", configProps.getProperty("TestData"));
        
        //facultyUser=configProps.getProperty("Faculty_User");
		//facultyPwd=configProps.getProperty("Educator_passWord");
		String user="educator";
		writeReport(EvolveCommonBussinessFunctions.existingUserLogin(user,HESIEducator,HESIEducatorPassword), "Launch Evolve Cert URL And Login As Existing Educator: "+HESIEducator, 
				"Successfully Launched Evolve Cert URL.</br>Successfully Logged In as Educator. "+HESIEducator,
				"Failed to Launch Evolve Cert URL.</br>Failed to Login As Educator. "+HESIEducator);
		
	    stepReport("Update account details in Evolve");
		writeReport(HESI_BusinessFunction.UpdateAccountDetails(Firstname,Lastname,Emailid,Instution,Mobile,Address1,Address2,Country,State,City,ZipCode,Program),"Values Submitted Successfully","Entered Values are Successfully Submitted","Entered Values are not Submitted");
	    Thread.sleep(veryhigh);
		writeReport(HESI_BusinessFunction.getAccountDetails(), "Fetching Account Details From MyAccount Page.", 
				"Successfully Fetched Username: "+getAccountDetailsUserName+"</br>Successfully Fetched FirstName: "+getAccountDetailsFirstName+"</br>Successfully Fetched Lastname: "+getAccountDetailsLastName+"</br>Successfully Fetched Email: "+getAccountDetailsEmail+"</br>Successfully Fetched Institution: "+getAccountDetailsInstitution+"</br>Successfully Fetched PhoneNumber: "+getAccountDetailsPhone+"</br>Successfully Fetched StreetAdreess: "+ getAccountDetailsStreetAddress, 
				"Failed to Fetch Account Details From MyAccount Page. ");
		
		stepReport("Login to HESI and go to account management");
		writeReport(HESI_BusinessFunction.HESI_Login(HESI_USER,HESI_Password),"Launching HESI URL and UserName"+HESI_USER,
                                                                                            "Launching the URL for HESI USER is successful </br > Login to Application Using HESI USER credentails :"+HESI_USER+" is Successful",
                                                                                              "Launching and Login to Application Using HESI USER credentails : "+ HESI_USER+" is Failed");

		writeReport( HESI_BusinessFunction.NavigatingtoAccountManagmentPage(),"Navigating to Account Managment Page",
                "Clicking on Account Managment is Successful </br> Clicking on Faculty and Programs link is Successful",
                "Navigating to Account Managment is Failed");

		stepReport("Search for existing instructor");
		writeReport( HESI_BusinessFunction.SearchUser(getAccountDetailsUserName),"Searching for User to Navigate to Account Managment Tab",
                                                                                 "Successfully Entered the Userdetails And Submitted",
                                                                                 "Failed to Enter User Details or Submission failed");

	    writeReport(HESI_BusinessFunction.CompareValuesintheResultsandClickonResults(getAccountDetailsUserName,getAccountDetailsFirstName,getAccountDetailsLastName,getAccountDetailsEmail),"Verifying the Results and Clicking Evolve ID",
			                                                                       "The Values Are verified and Successfully Clicked on EvolveId",
			                                                                       "</br>Results are not Appeared");
	  
	    stepReport("Verify account updates from Evolve are reflected in HESI");
	    writeReport(HESI_BusinessFunction.CompareHESIFacDetails(getAccountDetailsUserName, getAccountDetailsFirstName, getAccountDetailsLastName, getAccountDetailsEmail, getAccountDetailsInstitution, getAccountDetailsPhone, getAccountDetailsStreetAddress, getAccountDetailsStreetAddress2, getAccountDetailsCountry, getAccountDetailsState, getAccountDetailsTown, getAccountDetailsZipcode),"Comparing values from CERT to HESI","All the Above Comparions are Successful","All the Comparisons are Failed");
	    
	    stepReport("Update account details in HESI");
	    writeReport(HESI_BusinessFunction.UpdateHESIFac(Hesi_firstname,Hesi_lastname,Hesi_Email,Hesi_Areacode,Hesi_Phonenumber,Hesi_Comments),"Comparing values from CERT to HESI","All the Above Comparions are Successful","All the Comparisons are Failed");
	
	    Thread.sleep(14000);
	    stepReport("Log back into Evolve as the instructor");
		writeReport(EvolveCommonBussinessFunctions.existingUserLogin(user,HESIEducator,HESIEducatorPassword), "Launch Evolve Cert URL And Login As Existing Educator: "+HESIEducator, 
				"Successfully Launched Evolve Cert URL.</br>Successfully Logged In as Educator. "+HESIEducator,
				"Failed to Launch Evolve Cert URL.</br>Failed to Login As Educator. "+HESIEducator);
		
		stepReport("Verify account updates from HESI are reflected in Evolve");
		writeReport(HESI_BusinessFunction.getAccountDetails(), "Fetching Account Details From MyAccount Page.", 
				"Successfully Fetched Username: "+getAccountDetailsUserName+"</br>Successfully Fetched FirstName: "+getAccountDetailsFirstName+"</br>Successfully Fetched Lastname: "+getAccountDetailsLastName+"</br>Successfully Fetched Email: "+getAccountDetailsEmail+"</br>Successfully Fetched Institution: "+getAccountDetailsInstitution+"</br>Successfully Fetched PhoneNumber: "+getAccountDetailsPhone+"</br>Successfully Fetched StreetAdreess: "+ getAccountDetailsStreetAddress, 
				"Failed to Fetch Account Details From MyAccount Page. ");
		String Phone_number=Hesi_Areacode+Hesi_Phonenumber;
	  writeReport(HESI_BusinessFunction.CompareaferhesiupdateinCERT(Hesi_firstname,Hesi_lastname,Hesi_Email,Phone_number), "Comparing values from HESI to CERT", "Comparisions values from  HESI  updated Values to CERT Environment is Successful", "Comparisions values from  HESI  updated Values to CERT Environment is not matching");
	  Thread.sleep(3000);
		}
    
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
	}
	

