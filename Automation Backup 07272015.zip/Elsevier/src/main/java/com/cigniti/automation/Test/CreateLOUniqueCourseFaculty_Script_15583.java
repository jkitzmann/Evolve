package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.CreateLOUniqueCourseFaculty_15583;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentFaculty_15243;
import com.cigniti.automation.BusinessFunctions.LO_Global_Instructor_AR_8572;
import com.cigniti.automation.BusinessFunctions.LO_Unique_CourseFulfillment_Faculty_10410;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class CreateLOUniqueCourseFaculty_Script_15583 extends CreateLOUniqueCourseFaculty_15583{

	@Test
	public void uniqueCourseLOFaculty(String sheetName, String product, int col) throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		try{
			String evolve="true";
			String lmsvalue=null;

			comment=ReadingExcel.columnDataByHeaderName("evolveComment", "TC-10410", configProps.getProperty("TestData"));
			evolveContent=ReadingExcel.columnDataByHeaderName("evolveContent", "TC-10410", configProps.getProperty("TestData"));
			//product=ReadingExcel.columnDataByHeaderName("searchNumber", "TC-10410", configProps.getProperty("TestData"));
			enrollment=ReadingExcel.columnDataByHeaderName("enrollment", "TC-10410", configProps.getProperty("TestData"));
			String format_LO=ReadingExcel.columnDataByHeaderName("format_LO", "TC-10410", configProps.getProperty("TestData"));
			String statusAfterEmailSent=ReadingExcel.columnDataByHeaderName("verifyStatusAfterEmailSent", "TC-10410", configProps.getProperty("TestData"));
			String productId=ReadingExcel.columnDataByHeaderName("productID", "TC-10410", configProps.getProperty("TestData"));
			LO_Unique_CourseFulfillment_Faculty_10410.courseLink=ReadingExcel.columnDataByHeaderName("courseLnik","TC-10410" ,configProps.getProperty("TestData"));

			
			String user="educator";
			if(Hesi_lofalg==true)
			{
				facultyUser=credentials[0];
				facultyPwd=credentials[1];
			}
			else
			{
			facultyUser=ReadingExcel.columnDataByHeaderName("facultyUserName", "TC-15461", configProps.getProperty("TestData"));
			facultyPwd=ReadingExcel.columnDataByHeaderName("facultyPassword", "TC-15461", configProps.getProperty("TestData"));
			}
			
			stepReport("Login to Evolve as Educator");
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			writeReport(EvolveCommonBussinessFunctions.existingUserLogin(user,facultyUser,facultyPwd),"Launching The URL And Login to Application.",
					"Launching the URL for User is successful </br > Login to Application Using User credentails :"+facultyUser+" is Successful",
					"Launching and Login to Application Using User credentials : "+ facultyUser+" is Failed");
			writeReport(EvolveCommonBussinessFunctions.getAccountDetails(),"Fetching Account Details from My Account.",
					"Successfully Fetched account details from My Account page.",
					"Failed to Fetch the account details from My Account page.");
			
			stepReport("Search for Online Course and add to cart");
			writeReport(EvolveCommonBussinessFunctions.searchProduct(product,productCost),"Serach for the product..",
					"Successfully Entered ISBN:"+product+" in Search Box.</br>Clicked On Go Button.</br>Navigated To Product Details Page.",
					"Failed to Enter ISBN:"+product+" in Search Box.");
			writeReport(EvolveCommonBussinessFunctions.requestProduct(),"Clicking on the Request Product Button In Product Details Page.",
					"Successfully clicked on Request Product Button.",
					"Failed to click on Request Product Button.");
			writeReport(EvolveCommonBussinessFunctions.hostedAfterRequestPopUp(),"Switching to Course Configuration Popup in Request Product page.",
					"Successfully switched to Course Configuration Popup in Request Product page.",
					"Failed to switch to Course Configuration Popup in Request Product page.");
			evolveContent=ReadingExcel.columnDataByHeaderName("content", "TC-10410", configProps.getProperty("TestData"));

			writeReport(EvolveCommonBussinessFunctions.evolveContentInPopUp(evolveContent,comment,enrollment),"Entering Evolve Content In Course Configuration Popup.",
					"Successfully entered evolve content in Course Configuration Popup.</br>Clicked On Apply Button In Popup.</br>Navigated To Mycart Page.",
					"Failed to enter evolve content in Course Configuration Popup.</br>Failed To click On Apply Button In Popup.</br>Failed To Navigate To Mycart Page.");
			
			stepReport("Verify My Cart contents and submit order");
			EvolveCommonBussinessFunctions.hostedMycart(lmsvalue,evolve);
			searchTrial="false";
			String TrialLink=null;
			LO_Unique_CourseFulfillment_Faculty_10410.userReviewSubmit(searchTrial,TrialLink);
			Thread.sleep(veryhigh);
			String lmsTextLO=EvolveCommonBussinessFunctions.lmsText;
			
			stepReport("Verify receipt page");
			LO_Unique_CourseFulfillment_Faculty_10410.receiptPage(searchTrial,TrialLink);

			writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the educator page.", 
					"Successfully logged out the educator:"+facultyUser, 
					"Failed to logout the educator page:"+facultyUser);

			stepReport("Login to Evolve Admin");
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login to Application Using Admin Credentials :"+adminUser,
					"Launching the URL for Admin is successful </br > Login to Application Using Admin credentials :"+adminUser+" is Successful", 
					"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");
			
			stepReport("Search for AR and view details");
			LO_Global_Instructor_AR_8572.admin_Adoptionsearch();

		writeReport(EvolveCommonBussinessFunctions.getAdoptionRequestDetails(),"Clicking On Adoption Number.</br>Fetching Adoption Details of User and Course in Adoption Request Details page",
					"Adoption Number:"+adoptionRequest_getAdoptionNum+" is On Top Of The Row.</br>Successfully Clicked On "+adoptionRequest_getAdoptionNum+"</br>Successfully Fetched the details of User And Course from Adoption Request Details Page.",
					"Failed To Click On Adoption Number:"+adoptionRequest_getAdoptionNum+"</br>Failed to Fetch the details of User And Course from Adoption Request Details Page.");
			
		stepReport("Fulfill AR");	
		verifyLOStatusInARPage(format_LO);
			
			verifyLOStatusAfterEmailSentInARPage(sheetName,statusAfterEmailSent, productId, facultyUser, col);
			Thread.sleep(high);
			writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout as "+adminUser,
					"Successfully logged out admin page.", 
					"Failed to logout admin page.");
					
					
		}catch(Exception e){
			System.out.println(sgErrMsg="Exception occurred");
		}
	}
	@AfterTest
	public void closeBrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
