package com.cigniti.automation.Utilities;

public class ElsevierConstants {

	public final static String EXCEL_INPUT_SHEET_PATH="TestData\\TestData.xls";
}
