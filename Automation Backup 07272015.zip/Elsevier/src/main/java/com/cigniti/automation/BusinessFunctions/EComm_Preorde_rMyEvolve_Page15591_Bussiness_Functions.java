package com.cigniti.automation.BusinessFunctions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class EComm_Preorde_rMyEvolve_Page15591_Bussiness_Functions extends Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions {

	public static final String CINICAL_MEDICAL_ASSISTING_ONLIN_E ="9780323287029";
	public static final String CINICAL_MEDICAL_ASSISTING_ONLIN_E_1 ="9780323287029";

}
