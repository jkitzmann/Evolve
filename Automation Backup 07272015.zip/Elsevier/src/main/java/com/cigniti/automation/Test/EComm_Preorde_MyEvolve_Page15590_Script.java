package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EComm_Preorde_MyEvolve_Page15590;
import com.cigniti.automation.BusinessFunctions.Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;


public class EComm_Preorde_MyEvolve_Page15590_Script extends EComm_Preorde_MyEvolve_Page15590 {

	public static final String CINICAL_MEDICAL_ASSISTANT_ONLINE =ReadingExcel.columnDataByHeaderName("product", "TC-15590", testDataPath);
	 
	@Test
	public void ecommPreorderMyEvolve15590()throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		ElsevierObjects.browserType ="Firefox";
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		String pubDatePreOrder=ReadingExcel.columnDataByHeaderName("pubDatePreOrder", "TC-15590", testDataPath);
		String pubDatePreOrderStatus=ReadingExcel.columnDataByHeaderName("pubDateStatusPreOrder", "TC-15590", testDataPath);
		String pubDatePostOrder=ReadingExcel.columnDataByHeaderName("pubDatePostOrder", "TC-15590", testDataPath);
		String pubDatePostOrderStatus=ReadingExcel.columnDataByHeaderName("pubDatePostStatus", "TC-15590", testDataPath);
		
		
		CreateLOUniqueCourseFaculty_Script_15583 louniqueCourse=new CreateLOUniqueCourseFaculty_Script_15583();
		String product=ReadingExcel.columnDataByHeaderName("product", "TC-15590", testDataPath);
		louniqueCourse.uniqueCourseLOFaculty("TC-15590",product, 1);
	
		String courseID=ReadingExcel.columnDataByHeaderName("CourseID", "TC-15590", testDataPath);
		Thread.sleep(veryhigh);
		
		stepReport("Get the protection scheme of the course");
		ZFindProtectionSchemeSelfStudyCourse_Script_15571 zFind = new ZFindProtectionSchemeSelfStudyCourse_Script_15571();
		zFind.findProtectionSchemeSelfStudyCourse_15571(courseID,"ecommercePreOrder");
		
		System.out.println("Protection Shcemem==>"+protectionSchemeID);
		
		System.out.println("CourseId===>>>"+EvolveCommonBussinessFunctions.courseID1);
		
		stepReport("Login to Evolve Admin");
		adminLogin();
		
		stepReport("Set publication date to future date and set status to NYP");
		editResource(CINICAL_MEDICAL_ASSISTANT_ONLINE);
		modifyPublicatonDate(pubDatePreOrder,pubDatePreOrderStatus);
		writeReport(launchUrl(configProps.getProperty("NoCacheURL")), "Run the URL https://evolvecert.elsevier.com/cs/noCache", "Successfully ran the URL https://evolvecert.elsevier.com/cs/noCache", "Failed to run the URL https://evolvecert.elsevier.com/cs/noCache");
		driver.navigate().back();
		
		stepReport("Create access codes for the product");
		createAccessCode(product,"2","10");
		//adminLogout();
		String protection1=ReadingExcel.columnDataByHeaderName("ProtectionSchemeFromCourseID", "TC-15590", testDataPath);
		String protection2=ReadingExcel.columnDataByHeaderName("ProtectionSchemeFromAdminModule", "TC-15590", testDataPath);
		//compareProtectionScheme(protection1,protection2);
		
		stepReport("Create new student user");
		launchUrl(configProps.getProperty("URL4"));
		Thread.sleep(medium);
		writeReport(Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions.CreateNewUser("student", "ECommPreordeMyEvolvePage15590", "ECommercePreOrder", 1, 1,2,0), "Create New Student user", "Successfully created new student user with credentials: <br> Username: "+credentials[0]+"<br> Password : "+credentials[1], "Failed to create a new student account");
		
		String studentUserName = EvolveCommonBussinessFunctions.credentials[0];
		String studentPasswrod = EvolveCommonBussinessFunctions.credentials[1];
		System.out.println(studentUserName +","+ studentPasswrod);
		
		stepReport("Add preorder product to cart and place order using access code");
		searchISBNNumber(CINICAL_MEDICAL_ASSISTANT_ONLINE);
		studnetCheckOut(true,CINICAL_MEDICAL_ASSISTANT_ONLINE);
			
		stepReport("Login to Evolve Admin and revert publication date/status changes");
		adminLogin();
		editResource(CINICAL_MEDICAL_ASSISTANT_ONLINE);
		modifyPublicatonDate(pubDatePostOrder,pubDatePostOrderStatus);
		writeReport(launchUrl(configProps.getProperty("NoCacheURL")), "Run the URL https://evolvecert.elsevier.com/cs/noCache", "Successfully ran the URL https://evolvecert.elsevier.com/cs/noCache", "Failed to run the URL https://evolvecert.elsevier.com/cs/noCache");
		Thread.sleep(low);
		driver.navigate().back();
		Thread.sleep(medium);
		}
	
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
