package com.cigniti.automation.BusinessFunctions;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;

public class StudentLogIn_Neg_8566 extends EvolveCommonBussinessFunctions{
	public static float product_price=0;
	public static float expectedproduct_price=0;
	
	public static boolean studentcheckout() throws Throwable{
		boolean flag = true;
		if(!click(ElsevierObjects.btnaddtocart, "Click on request this product")){
			flag = false;
		}
		
		Thread.sleep(medium);
		  /*if(isElementPresent(ElsevierObjects.Admin_Evolve_StdtPopUp, "clicked on popup")){
		            click(ElsevierObjects.Admin_Evolve_StdtPopUp, "clicked on popup");
		            flag=true;
		  }*/
		   Thread.sleep(medium);
		
		product_price=  Float.parseFloat(getText(ElsevierObjects.student_product_price, "Product Price").substring(1));
		if(product_price > expectedproduct_price){
			if(!click(ElsevierObjects.checkout, "Redeem Checkout")){
 				flag = false;
 			}
		}
		/*if(!click(ElsevierObjects.student_chkInstution, "CheckBox Click")){
				flag = false;
		}*/
		return flag;
	}
	
	public static boolean studentBillingAddress() throws Throwable{
		boolean flag = true;
		
		if(!type(ElsevierObjects.student_billingAddress,readcolumns.twoColumns(0, 1, "Tc-8566", configProps.getProperty("TestData")).get("StreetAddress"), "Enter Address")){
			flag = false;
		}
		if(!type(ElsevierObjects.student_billingAddress_city,readcolumns.twoColumns(0, 1, "Tc-8566", configProps.getProperty("TestData")).get("City"), "Enter City")){
			flag = false;
		}
		if(!selectByValue(ElsevierObjects.student_billingAddress_state,readcolumns.twoColumns(0, 1, "Tc-8566", configProps.getProperty("TestData")).get("State") ," Select State")){
			flag = false;
		}
		if(!type(ElsevierObjects.student_billingAddress_zip,readcolumns.twoColumns(0, 1, "Tc-8566", configProps.getProperty("TestData")).get("ZipCode"), "Enter Zip  code")){
			flag = false;
		}
			if(!click(ElsevierObjects.btnprofilecontinue, "Clicked on continue")){
				flag = false;
			}
		
		
		  if(!switchToFrameByLocator(ElsevierObjects.Student_register_frame,"Switch to frame")){
			  	flag=false;
		   }
		   if(!click(ElsevierObjects.Student_register_UseAdress_btn,"Click UsethisAdress Button")){
			   	flag=false;
		   }
		
		
		return flag;
	}
}
