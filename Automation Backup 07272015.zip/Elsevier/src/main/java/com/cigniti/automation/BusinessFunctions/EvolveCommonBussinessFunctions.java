package com.cigniti.automation.BusinessFunctions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Accessories;
import com.cigniti.automation.Utilities.ImageComparison;
import com.cigniti.automation.Utilities.MyListener;
import com.cigniti.automation.Utilities.Property;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.Utilities.WritingExcel;
import com.cigniti.automation.accelerators.Actiondriver;
import com.cigniti.automation.accelerators.Base;
import com.google.common.collect.Lists;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;


public class EvolveCommonBussinessFunctions extends Actiondriver{


	public static String protectionID;
	public static String protectionID1;
	public static String protectionScheme="";
	public static String titleForCompare;
	public static String price=null;
	public static String expectedPrice=null;
	public static FileInputStream fi;
	public static FileOutputStream fo;
	public static List<String> classname=new ArrayList<String>();
	public static float product_price=0;
	public static float product_price1=0;
	public static Robot r;
	public static String emailAdress;
	public static String dynamicUserName;
	public static String dynamicPassword;

	public static String UniqueURL;

	public static String ordernumber1;
	public static String ordernumber2;
	public static String ordernumber3;

	public static List<String> crLists =Lists.newArrayList();

	// for Test Cases VST and KNo
	public static String testCaseName ="";
	public static String price_beforerequest;
	public static String title_beforerequest;
	public static String VSTIsbn;
	public static String KNOIsbn;
	public static String IsbnBeforeRequest;
	public static String price_afterRequest;
	public static String title_afterRequest;
	public static String isbn_afterRequest;
	public static String priceInReviewPage;
	public static String isbnInReviewPage;
	public static String titleInReviewPage;
	public static String piceInReceiptPage;
	public static String titleInReceiptPage;
	public static String isbnInReceiptPage;
	public static String price_afterAccessCodeSubmit;
	public static String ExpectedPrice = "$0.00";
	public static String VST_Isbn;
	public static String accessCode_totalPrice;
	public static String admin_Producttitle;
	public static String Kno_Isbn;
	public static String accessCode;
	public static String accesscode_price;
	public static String acessCode_afterRequest;
	public static String acessCode_titleAfterRequest;
	public static String accesscode_Isbn;
	public static String Mycartproduct_price;
	public static String userPrice;
	public static String uniqueURL;
	public static String title1;
	public static String title2;
	public static String adminprice;
	public static String adminprice1;
	public static String DMCode;

	public static String Username;
	public static String Password;
	//Common Logic for 9804,9805,9806,15575,15576,15577,15578,15579......

	public static String getAccountDetailsState;
	public static String getAccountDetailsTown;
	public static String getAccountDetailsZipcode;
	public static String requestProductPage_Price;
	public static String getAccountDetailsFirstName;
	public static String getAccountDetailsUserName;
	public static String getAccountDetailsLastName;
	public static String getAccountDetailsEmail;
	public static String getAccountDetailsInstitution;
	public static String getAccountDetailsPhone;
	public static String getAccountDetailsStreetAddress;
	public static String getAccountDetailsStreetAddress2;
	public static String getAccountDetailsCountry;
	public static String adoptionRequest_Trial;
	public static String Isbn;
	public static String title;
	public static String author;
	public static String lmsText;
	public static String lmsTextinReceiptPage;
	public static String PriceinReceiptPage;
	public static String productType;
	public static String userName;
	public static String password;
	public static String adoptionRequest_Username;
	public static String adoptionRequest_Password;
	public static String adoptionRequest_FirstName;
	public static String adoptionRequest_LastName;
	public static String adoptionRequest_Institution;
	public static String adoptionRequest_Adress;
	public static String adoptionRequest_Phone;
	public static String adoptionRequest_Isbn;
	public static String adoptionRequest_Country;
	public static String adoptionRequest_producttitle;
	public static String adoptionRequest_Format;
	public static String adoptionRequest_ProductType;
	public static String adoptionRequest_Author;
	public static String adoptionRequest_Email;
	public static String Pwd;
	public static String emailUrl;
	public static String emailBody;
	public static String myCartPrice;
	public static String lmsvalue;
	public static String requestProductPage_Title;
	public static String requestProductPage_Isbn;
	public static String adoptionRequest_Comment;
	public static String adoptionRequest_CourseContent;
	public static String comment;
	public static String evolveContent;
	public static String enrollment;
	public static String adoptionRequest_Enrollment;
	public static String popUpEvolveText;
	public static String VerifyText1 = "";
	public static String VerifyText2 = "";
	public static String VerifyText3 = "";
	public static String VerifyText4 = "";
	public static String VerifyText5 = "";
	public static String product;
	public static String courseID1;
	public static String courseID2;
	public static String facultyUser;
	public static String facultyPwd;
	public static String productCost=ExpectedPrice;
	public static String iSBN;
	public static String  evolve;
	public static String searchTrial;
	public static String emailID;
	public static String TrialEmailTitle;
	public static String titleInEmail;
	public static String trialStatus;
	public static String checkTrialStatus;
	public static String  trial;
	public static String TrialStatus;
	public static String adoptionRequest_StartDate;
	public static String adoptionRequest_Warning1;
	public static String adoptionRequest_Warning2;
	public static String adoptionRequest_EndDate;
	public static String adoptionRequest_UnenrollUser;
	public static String facultyUserName;
	public static String facultyPassword;
	public static String compareStatus;
	public static String compareStartDate;
	public static String compareEmailTemplateStartDate;
	public static String compareEmailTemplateWarning1;
	public static String compareEmailTemplateWarning2;
	public static String compareEmailTemplateEnd;
	public static String unEnrollDays;
	//public static String compareEmailTemplateFullfilled;
	public static String data1;
	public static String daysData;
	public static String trialDays;
	public static String warning1Days;
	public static String wraning2Days;
	public static String endDays;
	public static String requestText;
	public static String MIlestone;
	public static String adoptionRequest_EmailTemplate_StartDate;
	public static String adoptionRequest_EmailTemplate_Warning1;
	public static String adoptionRequest_EmailTemplate_Warning2;
	public static String adoptionRequest_EmailTemplate_EndDate;
	public static String verifymessage;
	public static String adoptionRequest_MIlestone;
	public static String rosterDetails;
	public static String NoTrialEmailTitle;
	public static String trialEmailTitleAfterFullfilled;
	public static String adoptionRequest_getAdoptionNum;
	public static String emailtitlPermanent;
	public static String totalPriceInMyCart;
	//promotion related cases
	public static int i;
	public static String titleisbn;
	public static String ISBN;
	public static String priceisbn;
	public static ArrayList<String> titleforuse1=new ArrayList<String>();
	public static ArrayList<String> isbn1=new ArrayList<String>();
	public static ArrayList<String> price1=new ArrayList<String>();
	public static String isbnForFutureUse1;
	public static String isbnForFutureUse2;
	public static String isbnForFutureUse3;
	public static String isbnForFutureUse4;

	public static String titleforfutureuse1;
	public static String titleforfutureuse2;
	public static String titleforfutureuse3;
	public static String titleforfutureuse4;

	public static String priceforfutureuse1;
	public static String priceforfutureuse2;
	public static String priceforfutureuse3;
	public static String priceforfutureuse4;
	public static String uniqueUrl;

	public static String protectionSchemeID;
	public static String newTitle;
	//All Sheets Data:
	public static Map<String, String> tcVST_KNO=readcolumns.twoColumnsBasedOnSheetName(0, 1, "createNewaccount", configProps.getProperty("TestData"));
	public static Map<String, String> tc10217=readcolumns.twoColumnsBasedOnSheetName(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData"));
	public static Map<String, String> tc10217_a=readcolumns.twoColumnsBasedOnSheetName(3, 4, "Ecom_TCID_10217", configProps.getProperty("TestData"));
	public static Map<String, String> tc_10212=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-10212", configProps.getProperty("TestData"));
	public static Map<String, String> tc_8564=readcolumns.twoColumnsBasedOnSheetName(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData"));
	public static Map<String, String> tc_8565=readcolumns.twoColumnsBasedOnSheetName(0, 1, "Tc-10216 & 8565", configProps.getProperty("TestData"));
	public static Map<String, String> tc_9798=readcolumns.twoColumnsBasedOnSheetName(0, 1, "Tc-9798", configProps.getProperty("TestData"));
	public static Map<String, String> tc_9798a=readcolumns.twoColumnsBasedOnSheetName(2, 3, "Tc-9798", configProps.getProperty("TestData"));

	//Tc-8564(Credit Card Details)
	//15583
	public static String StdEmail;
	public static String ACCESS_CODE="";
	public final static String[] credentials={"",""};

	public static String HesiNegISBN;

	//KNO Variables.................
	public static String knoNumber;
	public static String totalPriceInReviePage;

	public static String month_txt=tc_10212.get("month");/*readcolumns.twoColumns(0, 1, 3, configProps.getProperty("TestData")).get("month");*/
	public static String day_txt=tc_10212.get("day");/*readcolumns.twoColumns(0, 1, 3, configProps.getProperty("TestData")).get("day");*/
	public static String year_txt=tc_10212.get("year");/*readcolumns.twoColumns(0, 1, 3, configProps.getProperty("TestData")).get("year");*/
	public static String Daysaccess_txt=tc_10212.get("daysaccess");/*readcolumns.twoColumns(0, 1, 3, configProps.getProperty("TestData")).get("daysaccess");*/
	public static String CountGenerate_txt=tc_10212.get("count");/*readcolumns.twoColumns(0, 1, 3, configProps.getProperty("TestData")).get("count");*/
	public static String verifycount="";
	//public static List<String> crLists = Lists.newArrayList() ;
	//public final static String[] credentials={"",""};
	//public static Map<String, String> values=readcolumns.twoColumnsBasedOnSheetName(0, 1, "Tc-9804", configProps.getProperty("TestData"));




	//Login into the Instructor
	public static boolean instructorLogin() throws Throwable{
		boolean flag = true;
		try{
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();	
			if(!launchUrl(configProps.getProperty("URL3"))){
				flag = false;
			}
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			
			// none of this is necessary... skipping to clicking on login link
			/*if(!clickOnMainPageLink()){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.iameducator, "Clicked on Educator")){
				flag = false;
			}*/ 

			if(!click(ElsevierObjects.login, "login link")){
				flag = false;
			} 
			Thread.sleep(medium);
			
			// This was trying to get "MailUserName" and "MailpassWord" from the TC-10436 sheet in TestData.
			// Changed to "Username" and "Password", which is what is in the spreadsheet
			String username=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-10436", configProps.getProperty("TestData")).get("Username");
			String password=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-10436", configProps.getProperty("TestData")).get("Password");

			if(!type(ElsevierObjects.email,username,"Email")){
				flag = false;
			}
			if(!type(ElsevierObjects.password,password, "password")){
				flag = false;
			}
			if(click(ElsevierObjects.submit, "login submit")){
				Reporters.SuccessReport("Log into evolvecert.elsevier.com as any previously used faculty user", "Successfully Logged into evolvecert.elsevier.com as any previously used faculty user <br> Username : "+username+"<br> Password : "+password);
			}else{
				Reporters.failureReport("Log into evolvecert.elsevier.com as any previously used faculty user", "Failed to Log into evolvecert.elsevier.com as any previously used faculty user <br> Username : "+username+"<br> Password : "+password);
			}
			Thread.sleep(medium);
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}



	//student LogIn 
	public static boolean studentLoginGeneral() throws Throwable{
		boolean flag = true;
		try
		{
			driver.manage().deleteAllCookies();
			//driver.navigate().refresh();
			if(!launchUrl(configProps.getProperty("URL4"))){
				flag = false;
			}
			Thread.sleep(medium);
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			/*if(!clickOnMainPageLink()){
			flag=false;
		}
		if(!click(ElsevierObjects.home_student_lnkstudent,"Clicked On student Link")){
			flag = false;
		}*/
			if(!click(ElsevierObjects.student_login,"Clicked On student LogIn")){
				flag = false;
			}
			if(!type(ElsevierObjects.email,configProps.getProperty("StudentUser"),"Email")){
				flag = false;
			}
			if(!type(ElsevierObjects.password,configProps.getProperty("StudentPassword"),"Email")){
				flag = false;
			}
			if(!click(ElsevierObjects.submit,"Clicked on Login Button")){
				flag = false;
			}
			if(!click(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
				flag = false;
			}
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}
		return flag;
	}

	//TODO changes to be made to this method....
	public static boolean existingStudentLogin() throws Throwable{
		boolean flag = true;
		try
		{
			if(!type(ElsevierObjects.checkout_login_username, configProps.getProperty("StudentUser"),"Email")){
				flag = false;
			}
			if(!type(ElsevierObjects.checkout_login_password, configProps.getProperty("StudentPassword"),"Email")){
				flag = false;
			}
			if(click(ElsevierObjects.educator_btnLogin,"Clicked on Login Button")){
				Reporters.SuccessReport("Log into the Application as Existing Student User", "Successfully logged into the Application as Existing Student User with valid Credentials : <br> Student Username : "+configProps.getProperty("StudentUser")+"<br> Student Password : "+configProps.getProperty("StudentPassword"));
			}else{
				Reporters.failureReport("Log into the Application as Existing Student User", "Failed to log into the Application as Existing Student User with valid Credentials : <br> Student Username : "+configProps.getProperty("StudentUser")+"<br> Student Password : "+configProps.getProperty("StudentPassword"));
			}

		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}
		return flag;
	}

	//Find Adoption Request in Evolve Admin
	public static Boolean searchAdoptionRequest(Boolean ARpending, Boolean ARapproved, Boolean ARfulfilled, Boolean ARTrial) throws Throwable{
		boolean flag = true;
		try
		{
		if(click(ElsevierObjects.lnkAdaptionrequest, "Click Search Adoption Requests link")){
	     	Reporters.SuccessReport("Click Search Adoption Requests link", "Successfully clicked Search Adoption Requests link");
		}else{
			Reporters.failureReport("Click Search Adoption Requests link", "Failed to click Search Adoption Requests link");
		};
		
		click(ElsevierObjects.AR_DATE_RANGE_RADIO,"Select Date Range Radio button");
		
		Thread.sleep(low);
		
		if(ARpending == true){
		click(ElsevierObjects.AR_PENDING_FILTER,"Checkmark Pending AR Filter");
		}
		if(ARapproved == true){
		click(ElsevierObjects.AR_APPROVED_FILTER,"Checkmark Approved AR Filter");
		}
		if(ARfulfilled == true){
		click(ElsevierObjects.AR_FULFILLED_FILTER,"Checkmark Fulfilled AR Filter");
		}else{};
		if(ARTrial == true){
			click(ElsevierObjects.AR_SHOW_ONLY_TRIALS,"Checkmark Show Only Trials");
			}else{
			click(ElsevierObjects.AR_EXCLUDE_TRIALS,"Checkmark Exclude Trials");
			}
		
		Thread.sleep(low);
		
		click(ElsevierObjects.AR_SEARCH_BTN,"Click Adoption Request Search button");
		Thread.sleep(medium);
		
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			return false;
		}
		return flag;
	}


	//studentReview
	public static boolean studentReview(String Status) throws Throwable{
		boolean flag = true;
		try
		{
			product_price1=  Float.parseFloat(getText(ElsevierObjects.student_product_price, "Product Price").substring(1)); 
			product_price=  Float.parseFloat(getText(ElsevierObjects.student_product_price, "Product Price").substring(1));
			if(product_price1 == product_price){
				if(!click(ElsevierObjects.instructor_chk, "Check Box Clicked")){
					flag = false;
				}
				if(Status.equals("finished"))
				{
					if(!type(ElsevierObjects.instructor_checkoutcvv, tc_8564.get("student_CardCvv")/*readcolumns.twoColumns(0, 1, 11, configProps.getProperty("TestData")).get("student_CardCvv")*/, "Card Name")){
						flag = false;
					}
				}
				if(!click(ElsevierObjects.instructor_submit, "Clicked on submit")){
					flag = false;
				}
				Thread.sleep(veryhigh);
			}
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}
		return flag;
	}



	//Educator View with out Login
	public static boolean searchBeforeLogin() throws Throwable{
		boolean flag = true;
		try
		{
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			if(!launchUrl(configProps.getProperty("URL3"))){
				flag = false;
			}
			Thread.sleep(medium);
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();

			/*if(!clickOnMainPageLink()){
			flag=false;
		}
		if(!click(ElsevierObjects.iameducator, "Clicked on Educator")){
			flag = false;
		}*/ 
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}
		return flag;
	}



	//search for product before Login
	public static boolean searchCourseBeforeAdd() throws Throwable{
		boolean flag = true;
		try
		{
			if(!type(ElsevierObjects.txtproductsearch, tc_8565.get("searchNumber")/*readcolumns.twoColumns(0, 1, 9, configProps.getProperty("TestData")).get("searchNumber")*/, "text to search")){
				flag = false;
			}
			if(!click(ElsevierObjects.gobutton, "search button")){
				flag = false;
			}
			/*if(!waitForElementPresent(ElsevierObjects.btnaddtocart,"Request this product now")){
				flag = false;
			}*/
		}catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}
		return flag;	
	}

	// for TC-8566 is element present....
	public static boolean isElementPresentNegCheck(By by, String locatorName)
	throws Throwable {
		boolean flag=false;	
		try {
			driver.findElement(by);
			flag = true;
			return true;
		} catch (Exception e) {

			System.out.println(e.getMessage());
			return false;
		} finally {
			if (!flag) {
				System.out.println("");
				//Reporters.failureReport("check IsElementPresent", locatorName + " Element is not present on the page");
			} 
			else if(flag)
			{
				System.out.println("");
				//Reporters.SuccessReport("IsElementPresent ", "able to lacate element: " + locatorName);
			}

		}
	}

	/*................ AdminModule .....................*/
	public boolean adminLogin() throws Throwable {

		/*boolean flag=true;
		Robot r=new Robot();
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_T);
		r.keyRelease(KeyEvent.VK_CONTROL);*/

		if(EvolveCommonBussinessFunctions.evolveAdminlogin()){
			Reporters.SuccessReport("Log into the application as admin user", "Successfully logged into the application as admin user with credentials : <br> Username : "+configProps.getProperty("AdminUser")+"<br> Password : "+configProps.getProperty("AdminPassword"));
		}else{
			Reporters.failureReport("Log into the application as admin user", "Failed to log into the application as admin user with credentials : <br> Username : "+configProps.getProperty("AdminUser")+"<br> Password : "+configProps.getProperty("AdminPassword"));
		}
		return flag;
	}



	// search for Course
	public static boolean searchCourse() throws Throwable{
		boolean flag = true;
		try
		{
			if(!click(ElsevierObjects.lnkevolvecart, "Clicked on Evolve")){
				flag = false;
			}
			if(!type(ElsevierObjects.txtproductsearch,tc_8565.get("searchNumber")/*readcolumns.twoColumns(0, 1, 9, configProps.getProperty("TestData")).get("searchNumber")*/, "text to search")){
				flag = false;
			}
			if(!click(ElsevierObjects.gobutton, "search button")){
				flag = false;
			}
			if(!waitForElementPresent(ElsevierObjects.btnaddtocart,"Request this product now")){
				flag = false;
			}
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}
		return flag;	
	}



	// Add a product to Cart...
	public static boolean addToCart() throws Throwable{
		boolean flag = true;
		Thread.sleep(high);
		if(!click(ElsevierObjects.btnaddtocart, "Click on request this product")){
			flag = false;
		}
		try{
			driverwait().until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='cboxClose']")));
			ImplicitWait();
			if(driver.findElement(By.xpath("//div[@id='cboxClose']")).isDisplayed()){
				if(!switchToFrameByLocator(ElsevierObjects.frame,"framename")){
					flag = false;
				}
				if(!waitForElementPresent(ElsevierObjects.evolvebutton,"Evolve button")){
					flag = false;
				}
				if(!click(ElsevierObjects.apply, "Apply button")){
					flag = false;
				}
				if(!switchToDefaultFrame()){
					flag = false;
				}
				Thread.sleep(medium);
			}
		}
		catch(Exception e){}
		Thread.sleep(high);
		price=getText(ElsevierObjects.price, "price");
		expectedPrice="$0.00";
		Thread.sleep(medium);
		if(price.contains(expectedPrice)){
			if(!click(ElsevierObjects.checkout, "Redeem Checkout")){
				flag = false;
			}
			return flag;
		}
		return flag;
	}


	//Click on the Unassigned Access Code Link
	public static boolean unassignedAccesscodeLink() throws Throwable{
		boolean flag = true;
		try
		{
			Thread.sleep(medium);
			if(!click(ElsevierObjects.unassignedaccesslink, " Create Unassigned Access Code")){
				flag = false;
			}
			Thread.sleep(medium);
			if(isElementPresent(ElsevierObjects.verifyunassignedtext, "Create Unassigned Access Codes is present")){
				Reporters.SuccessReport("Verify for the Create Unassigned Access Codes page", "Create Unassigned Access Codes page is be presented : " +driver.getCurrentUrl());
			}else{
				Reporters.failureReport("Verify for the Create Unassigned Access Codes page", "Create Unassigned Access Codes page is not present : " +driver.getCurrentUrl());
			}
			String breadCrumb=getText(ElsevierObjects.verifybreadcrumb, "");		
			if(isElementPresent(ElsevierObjects.verifybreadcrumb, "Bread Crumb - Evolve Admin > Create Unassigned Access Code")){
				Reporters.SuccessReport("Verifying for Bread Crumb is Successfull", "Actual Bread Crumb is : "+breadCrumb +"<br> Expected Bread Crumb is : Bread Crumb - Evolve Admin > Create Unassigned Access Code");

			}else{
				Reporters.failureReport("Verifying for Bread Crumb failed ", "Actual Bread Crumb is : "+breadCrumb +"<br> Expected Bread Crumb is : Bread Crumb - Evolve Admin > Create Unassigned Access Code");

			}	
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}
		return flag;
	}

	/*//Click on the Unassigned Access Code Link
	public static boolean unassignedAccesscodeLink() throws Throwable{
		boolean flag = true;
		Thread.sleep(medium);
		if(!click(ElsevierObjects.unassignedaccesslink, " Create Unassigned Access Code")){
			flag = false;
		}
		if(!isElementPresent(ElsevierObjects.verifyunassignedtext, "Create Unassigned Access Codes link is present")){
			flag = false;
		}
		if(!isElementPresent(ElsevierObjects.verifybreadcrumb, "Bread Crumb - Evolve Admin > Create Unassigned Access Code")){
			flag = false;
		}

		return flag;
	}*/



	//Verify for the Code Creation Section
	public static boolean verifyCodeCreation() throws Throwable{
		boolean flag = true;
		try{
			if(!type(ElsevierObjects.unassignedinputmonth, month_txt, "Input Month")){
				Thread.sleep(medium);
				flag = false;
			}
			if(!type(ElsevierObjects.unassignedinputdate, day_txt, "Input Date")){
				Thread.sleep(medium);
				flag = false;
			}
			if(!type(ElsevierObjects.unassignedinputyear, year_txt, "Input Year")){
				Thread.sleep(medium);
				flag = false;
			}
			/*driver.findElement(ElsevierObjects.unassigneddaysofaccess).clear();
			if(!type(ElsevierObjects.unassigneddaysofaccess, Daysaccess_txt, "No. of days access")){
				Thread.sleep(medium);
				flag = false;
			}*/

			if(!type(ElsevierObjects.unassignedcodenumbertogenerate, CountGenerate_txt, "No. codes to generate")){
				Thread.sleep(medium);
				flag = false;
			}

			if(!click(ElsevierObjects.unassignedcodesave, "Click on Save Button")){
				Thread.sleep(medium);
				flag = false;
			}
			Thread.sleep(medium);
			if(verifyText(ElsevierObjects.accesscodesuccmesg, "The Access Code Set was successfully created.", "Success Message Displayed")){
				Reporters.SuccessReport("The Access Code Set Creation Success Message", "The Access Code Set was successfully created with the Following data: "
						+ "<br> Date of Expiration : "+month_txt+":"+day_txt+":"+year_txt +"<br>Days of Access:  0<br> Number to Generate:  "+CountGenerate_txt +"<br>The data is entered successfully ");

			}else{
				Reporters.failureReport("The Access Code Set Creation Success Message", "The Access Code Set was failed created with the Following data: "
						+ "<br> Date of Expiration : "+month_txt+":"+day_txt+":"+year_txt +"<br>Days of Access:  0<br> Number to Generate:  "+CountGenerate_txt);

			}

			Thread.sleep(high);
			String sucMsg=getText(ElsevierObjects.accesscodedownloadlink, "");
			if(verifyText(ElsevierObjects.accesscodedownloadlink, "Click here to download the access codes.", "download link is Displayed")){
				Reporters.SuccessReport("The Success Message Validation", "The success message :"+sucMsg+" is displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
			}

		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;

	}

	//Downloading the text file and verifying for the Access Code Literals
	public static boolean clickDownloadAndCompareNotePadDataWithStringliterals() throws Throwable{

		boolean flag = true;
		try{
			Property configProps=new Property("config.properties");
			BufferedReader br = null;
			r=new Robot();

			Thread.sleep(medium);
			if(click(ElsevierObjects.accesscodedownloadlink, "Click on Download Link")){
				Reporters.SuccessReport("Click on the Access Code Download Link", "Successfully Clicked on the Access Code Download Link");	
			}else{
				Reporters.failureReport("Click on the Access Code Download Link", "Failed to Click on the Access Code Download Link");
			}

			//click(ElsevierObjects.downloadlink, "download link");
			Thread.sleep(medium);
			if(isChecked(ElsevierObjects.radioinput, "TXT file format radiobutton is selected ")){
				//If browser type is 'IE', click TAB and Enter
				// if(configProps.getProperty("browserType").equalsIgnoreCase("ie")){
				if(ElsevierObjects.adminBrowserType.equalsIgnoreCase("ie")){
					Thread.sleep(low);
					r.keyPress(KeyEvent.VK_TAB);
					Thread.sleep(low);
					r.keyPress(KeyEvent.VK_ENTER);
				}
				else{
					click(ElsevierObjects.downloadlink, "download link");
				}
			}
			Thread.sleep(medium);

			//If browser type is 'IE', click ALT+S and release ALT+S
			//if(configProps.getProperty("browserType").equalsIgnoreCase("ie")){
			if(ElsevierObjects.adminBrowserType.equalsIgnoreCase("ie")){
				r.keyPress(KeyEvent.VK_ALT);
				r.keyPress(KeyEvent.VK_S);
				r.keyRelease(KeyEvent.VK_S);
				r.keyRelease(KeyEvent.VK_ALT);
				Thread.sleep(low);

				//If browser type other than 'IE'. 
			}
			//If browser type is Firefox, 
			else  
				//if(configProps.getProperty("browserType").equalsIgnoreCase("firefox")){
				if(ElsevierObjects.adminBrowserType.equalsIgnoreCase("firefox")){
					r.keyPress(KeyEvent.VK_DOWN);
					r.keyPress(KeyEvent.VK_TAB);
					r.keyPress(KeyEvent.VK_TAB);
					r.keyPress(KeyEvent.VK_TAB);
					Thread.sleep(low);
					r.keyPress(KeyEvent.VK_ENTER);
				}
			//If browser type other than 'Chrome'. don't perform any operation. Since file will be downloaded automatically.
			Thread.sleep(medium); 

			String sCurrentLine;

			br = new BufferedReader(new FileReader(tc_10212.get("textfilepath"))/*readcolumns.twoColumns(0, 1, 3, configProps.getProperty("TestData")).get("textfilepath"))*/);
			boolean condition = true;
			while ((sCurrentLine = br.readLine()) != null) {
				if(sCurrentLine.startsWith("UC")){
					if (sCurrentLine.contains("0") || sCurrentLine.contains("o")|| sCurrentLine.contains("O") || sCurrentLine.contains("l") || sCurrentLine.contains("1") || sCurrentLine.contains("Q")) {
						System.out.println("String Literals validation");
						//Reporters.failureReport("String Literals are invalid", "String literals are verification failed");
						condition=false;
					}else{
						flag=true;
						System.out.println("String Literals are valid");
						//Reporters.SuccessReport("String Literals validation", "String literals are verified successfully");
						condition = true;
					}
				}
			}
			br.close();

			if(condition==true){
				Reporters.SuccessReport("Validate the String literals <br> Access codes do not included the characters", "Access Codes starts with 'UC'- <br> Access codes do not included the following characters<br>'0' Number zero <br>'o' Lower case alphabet character <br>'O' Upper case alphabet character<br>'l' Lower case alphabet character (el) <br>'1' the number 1 <br>'Q' Upper case Que ");
			}else{
				Reporters.failureReport("Validate the String literals <br> Access codes do not included the characters", "Access Codes Did not starts with 'UC'- <br> Access codes included the following characters<br>'0' Number zero <br>'o' Lower case alphabet character <br>'O' Upper case alphabet character<br>'l' Lower case alphabet character (el) <br>'1' the number 1 <br>'Q' Upper case Que ");
			}System.out.println("");
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;

	}

	//Go to the User Student and Submitting product to the cart
	public static boolean EvolveCatalog(String user) throws Throwable
	{
		boolean flag = true;
		try{
			String filePath = ReadingExcel.getAbsoulteFilePath(tc_10212.get("UploadDataFile_15557")/*readcolumns.twoColumns(0, 1, 3, configProps.getProperty("TestData")).get("UploadDataFile")*/);

			String validRedeemCode=ReadingExcel.getCell(1, 2, filePath, "UploadFile");
			//enter into the site as student
			if(click(ElsevierObjects.evolveCatalog, "Click on Catalog")){
				Reporters.SuccessReport("Click on the evolve catalog link", "Successfully clicked on the evolve catalog link");
			}else{
				Reporters.failureReport("Click on the evolve catalog link", "failed to click on the evolve catalog link");
			}
			// this section no longer applies
			/*
			if(!javaClick(ElsevierObjects.Student_Home_Packard_img, "Clicked on Pageburst eBook")){
				flag = false;
			}	
			if(!javaClick(ElsevierObjects.Student_Home_Packard_img, "Clicked on Pageburst eBook")){
				flag = false;
			}
			if(javaClick(ElsevierObjects.Student_Home_Redeem_lnktxt, "Clicked on Pageburst eBook")){
				Reporters.SuccessReport("Click on the Pageburst honeypot and Redeem an access Code link", "Successfully clicked on the Pageburst honeypot and Redeem an access Code link");
			}else{
				Reporters.failureReport("Click on the Pageburst honeypot and Redeem an access Code link", "failed to click on the Pageburst honeypot and Redeem an access Code link");
			}
			*/
			if(type(ElsevierObjects.Student_Home_Redeem_txtbox, validRedeemCode, "Enter Redeem code in Text Box")){
				Reporters.SuccessReport("Enter the access code", "Successfully Entered the access code into the input box <br> Access code entered is : "+validRedeemCode);
			}else{
				Reporters.failureReport("Enter the access code", "failed to Enter the access code into the input box");
			}
			if(javaClick(ElsevierObjects.Student_Home_Redeem_Subbtn, "Clicked on Submit Redeem Button")){
				Reporters.SuccessReport("Click on the Redeem submit button", "Successfully Clicked on the Redeem submit button");
			}else{
				Reporters.failureReport("Click on the Redeem submit button", "Failed to Click on the Redeem submit button");
			}
			if(user.equalsIgnoreCase("true")){
				Thread.sleep(medium);
				waitForVisibilityOfElement(ElsevierObjects.Student_Home_Redeem_Chkout, "");
				Thread.sleep(medium);
				driver.findElement(ElsevierObjects.Student_Home_Redeem_Chkout).sendKeys(Keys.ENTER);
				Thread.sleep(medium);
				/*if(!click(ElsevierObjects.Student_Home_Redeem_Chkout, "Clicked on Submit Redeem/Checkout Button")){
					flag = false;
				}*/		
			}else{
				Thread.sleep(low);
				//TODO actions to be done in the morning....
				String invalidMessage=getText(ElsevierObjects.Evolve_AccessCodeNotValid, "Get the Invalid message");
				if(verifyText(ElsevierObjects.Evolve_AccessCodeNotValid, invalidMessage, "Invalid ISBN Message")){
					Reporters.SuccessReport("Verify the Invalid Message ", "In Valid Message is successfully printed <br> Invalid message : "+invalidMessage);
				}else{
					Reporters.failureReport("Verify the Invalid Message ", "In Valid Message is failed to print");
				}
			}
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	//Click on Upload Unassigned access code Link
	public static boolean accesscodeUploadLink() throws Throwable{
		boolean flag = true;
		try{
			if(!click(ElsevierObjects.Admin_Login_Upload_lnk, " Click on Upload Unassigned Codes")){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_VerifyUploadTxt, "Bread Crumb - Evolve Admin > Upload Access Codes ")){
				flag = false;
			}
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	//Uploading Unassigned Access Code Links excel file into the database
	public static boolean uploadExcel(String filepath) throws Throwable{
		boolean flag = true;
		try{
			/*if(!click(ElsevierObjects.Admin_Browse_Btn, " Click on Browse Button")){
					flag = false;
				}				
			   Robot r=new Robot();			   	  
			   Thread.sleep(medium);			   
			   Thread.sleep(medium);
			   r.keyPress(KeyEvent.VK_TAB);
			   Thread.sleep(low);
			   r.keyPress(KeyEvent.VK_TAB);
			   Thread.sleep(low);
			   r.keyPress(KeyEvent.VK_ENTER);
			   r.keyRelease(KeyEvent.VK_ENTER);
			   Thread.sleep(high);			 	   
			   setClipboardData(readcolumns.twoColumns(0, 1, 3, configProps.getProperty("TestData")).get("UploadDataFile"));			 
			   r.keyPress(KeyEvent.VK_CONTROL);
			   r.keyPress(KeyEvent.VK_V);
			   r.keyRelease(KeyEvent.VK_V);
			   r.keyRelease(KeyEvent.VK_CONTROL);			 		
			   r.keyPress(KeyEvent.VK_ENTER);
			   r.keyRelease(KeyEvent.VK_ENTER);
			   Thread.sleep(medium);
			 */

			uploadFile(ElsevierObjects.Admin_Browse_Btn, filepath, /*readcolumns.twoColumns(0, 1, 3, configProps.getProperty("TestData")).get("UploadDataFile")*/ "");

			if(!click(ElsevierObjects.Admin_Upload_Btn, " Click on Upload Button")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!verifyText(ElsevierObjects.Admin_Upld_Sucmsg, "Your file was successfully uploaded.", "Success Message")){
				flag = false;
			}
			Thread.sleep(medium);
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	//Common Method which return the column data from excel file
	public List<String> excel(String Sheetname,int Col) throws Throwable {
		fi=new FileInputStream(configProps.getProperty("filePath"));
		Workbook w=Workbook.getWorkbook(fi);
		Sheet s=w.getSheet("PackageCreation");

		int sizerow=s.getRows();
		System.out.println(sizerow);
		for (int i = Col; i <= Col; i++) {
			for (int j = 1; j < s.getRows(); j++) {

				String name=s.getCell(i, j).getContents();

				classname.add(name);
				System.out.println(name);
			}
		}
		return classname;
	}

	//Common Business for VST and KNO   TC-15242/15561/15229/15231/15562/15241

	//Creating New Account For Both FACULTY and STUDENT
	public static boolean CreateNewUser(String user) throws Throwable{
		boolean flag = true;
		try{
			driver.manage().deleteAllCookies();
			Thread.sleep(medium);
			if(!launchUrl(configProps.getProperty("URL"))){
				flag = false;
			}
			//driver.findElement(ElsevierObjects.StudentMainPage).click();
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();

			/*if(!clickOnMainPageLink()){
				flag=false;
			}
			 */
			if(user.equalsIgnoreCase("educator")){ 
				if(!click(ElsevierObjects.evolve_createNewUser,"Create new account")){
					flag=false;
				}
				if(!switchToFrameByLocator(ElsevierObjects.evolve_newAcount_frame,"Switch to frame")){
					flag=false;
				}
				if(!click(ElsevierObjects.faculty_radio_btn,"Faculty radio button")){
					flag=false;
				}
				registrationForm();
			}else{
				if(!click(ElsevierObjects.evolve_createNewUser,"Create new account")){
					flag=false;
				}
				if(!switchToFrameByLocator(ElsevierObjects.evolve_newAcount_frame,"Switch to frame")){
					flag=false;
				}
				if(!click(ElsevierObjects.student_radio_btn,"Student radio button")){
				    flag=false;
				}
				registrationForm();
			}
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	/** Click on 'Main Page' link if it is present. 
	 * Note: Link is displayed only some times and most of the times link is not displayed.
	 * 
	 * @return
	 * @throws Throwable
	 */
	public static boolean clickOnMainPageLink() throws Throwable{
		boolean flag = true;

		try{
			//driver.findElement(ElsevierObjects.evolve_createNewUser);
			if(isElementPresent(ElsevierObjects.Student_Instructor_MainPage)){

			}
		}catch (NoSuchElementException e) {
			System.out.println("Create new account link is not displayed.");

			try{
				WebElement weMainPage = driver.findElement(ElsevierObjects.Student_Instructor_MainPage);
				if(weMainPage.isDisplayed()){
					if(!click(ElsevierObjects.Student_Instructor_MainPage,"Click on 'Main Page' link.")){
						flag=false;
					}				
				}					
			}catch (NoSuchElementException e1) {
				flag = false;
			}
		}

		return flag;
	}

	/** Click on 'Ok' button if it is present while adding the product to cart. 
	 * Note: 'Ok' button is displayed only for the new User.
	 * 
	 * @return
	 * @throws Throwable
	 */
	public static boolean clickOnOkButtonIfVisible() throws Throwable{
		boolean flag = true;

		try{
			WebElement okButton = driver.findElement(ElsevierObjects.Student_Update_Account_PopUp);
			if(okButton.isDisplayed()){
				if(!click(ElsevierObjects.Student_Update_Account_PopUp,"Click on 'OK' button.")){
					flag=false;
				}				
			}					
		}catch (NoSuchElementException e1) {
			System.out.println("'Main Page' link is not displayed.");
			//Note: Don't make "flag=false;" in 'catch' block, since application display's 'Main Page' links only some times.
		}

		return flag;
	}

	/** Click on 'Enter Later' button if it is present while adding the product to cart. 
	 * 
	 * @return
	 * @throws Throwable
	 */
	public static boolean clickOnEnterLaterButtonIfVisible() throws Throwable{
		boolean flag = true;

		try{
			switchToFrameByLocator(ElsevierObjects.Admin_Evolve_Ecom_framename, "frame name");
			click(ElsevierObjects.Admin_Evolve_Ecom_framecontinue, "Enter later Button");

			WebElement enterLater = driver.findElement(ElsevierObjects.Admin_Evolve_Ecom_framecontinue);
			if(enterLater.isDisplayed()){
				if(!click(ElsevierObjects.Admin_Evolve_Ecom_framecontinue, "Enter later Button")){
					flag=false;
				}				
			}					
		}catch (NoSuchElementException e1) {
			System.out.println("'Main Page' link is not displayed.");
			//Note: Don't make "flag=false;" in 'catch' block, since application display's 'Main Page' links only some times.
		}

		return flag;
	}


	/*public static void capturCredentials(){
		String credentialss = driver.findElement(ElsevierObjects.NonAdmin_UserCredentials).getText();

		String[] credentialsArr = credentialss.split("\n");

		String userName = null;
		String password = null;
		for(String credentials : credentialsArr){
			if(credentials.contains("Username:")){
				userName = credentials.replaceAll("Username:", "").trim();
			}
			if(credentials.contains("Password:")){
				password = credentials.replaceAll("Password:", "").trim();
			}				
		}

		ReadingExcel.updateCellInSheet(1,1,configProps.getProperty("TestData"), "DynamicCredentials", userName);
		ReadingExcel.updateCellInSheet(2,1,configProps.getProperty("TestData"), "DynamicCredentials", password);
	}

	 */


	//Admin Browser
	public static void SwitchToIEBrowser(){
		Base.driver.quit();
		File file = new File("Drivers\\IEDriverServer.exe");
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		DesiredCapabilities capab = DesiredCapabilities.internetExplorer();
		capab.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
		webDriver = new InternetExplorerDriver(capab);
		Base.driver=new EventFiringWebDriver(webDriver);
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	//E Commerce Package Creation Test Case - 10217	

	//Verifying the E Commerce link in the Admin Page
	public static boolean verifyEcommerceLink() throws Throwable{		
		boolean flag=true;	
		try{
			Thread.sleep(medium);
			if(click(ElsevierObjects.Evolve_Admin_ECommerce_AddEcommerce, "Click on the Add Ecommerce link in Admin Page")){
				Reporters.SuccessReport("Click Add E-commerce Package link", "Successfully clicked on the link Add E-commerce Package and user is navigated to the Add E-commerce Package: "+driver.getCurrentUrl());
			}		
			if(isElementPresent(ElsevierObjects.breadcrumb, "Bread Crumb - Evolve Admin > Add E-commerce Package")){
				Reporters.SuccessReport("Bread Crumb is Present", "Bread Crumb is present : <br> Actual Bread Crumb is : Bread Crumb - Evolve Admin > Add E-commerce Package <br> Expected Bread Crumb is : Bread Crumb - Evolve Admin > Add E-commerce Package");
				flag=true;
			}	else{
				Reporters.failureReport("Bread Crumb is not as expected ", "Bread Crumb is not as expected : <br> Actual Bread Crumb is not as Expected Bread Crumb is : Bread Crumb - Evolve Admin > Add E-commerce Package");
				flag=false;
			}
			if(isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_Tabs, "E-commerce Package Tabs")){
				Reporters.SuccessReport("Verify the presence of E Commerce Cross Promotion tab", "E Commerce Cross Promotion tab is present");
				flag=true;
			}	else{
				Reporters.failureReport("Verify the presence of E Commerce Cross Promotion tab", "E Commerce Cross Promotion tab is not present");
				flag=false;
			}	
			String tabidentify=driver.findElement(ElsevierObjects.Evolve_Admin_Ecom_DMCode).getText();
			if(tabidentify.contains("DM Code *")){
				Reporters.SuccessReport("Default Tab is Package", "Default Tab Package is selected");
			}else
			{
				Reporters.failureReport("Default Tab is Package", "Default Tab Package is selected");
			}
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;		
	}

	//Validating the top view of Add Package Page 
	public static boolean viewTopViewAddPakage() throws Throwable{		
		boolean flag=true;		
		try{
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_DMCode, "DM Code", driver.getCurrentUrl())){
				flag = false;
			}		
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_CampCode, "Campaign Code", driver.getCurrentUrl())){
				flag = false;
			}		
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_PkgName, "Package Name", driver.getCurrentUrl())){
				flag = false;
			}		
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_StrDte, "Start Date", driver.getCurrentUrl())){
				flag = false;
			}	
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_EndDte, "End Date", driver.getCurrentUrl())){
				flag = false;
			}		
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_State, "State", driver.getCurrentUrl())){
				flag = false;
			}		
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_City, "City", driver.getCurrentUrl())){
				flag = false;
			}		
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_Institution, "Institution", driver.getCurrentUrl())){
				flag = false;
			}		
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_SaveBtn, "Save Button", driver.getCurrentUrl())){
				flag = false;
			}		
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_CanclPkg, "Cancel Button", driver.getCurrentUrl())){
				flag = false;
			}		
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_Clone, "Clone Button", driver.getCurrentUrl())){
				flag = false;
			}	
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;		
	}

	//Verifying whether the clone button is disabled or not
	public static boolean cloneEnabled() throws Throwable{
		boolean flag=true;
		try{
			if(driver.findElement(ElsevierObjects.Evolve_Admin_Ecom_Clone).isEnabled())
			{
				Reporters.failureReport("Verifying Clone Button is Enabled or Disabled", "Clone button is Enabled <br> Actual Result is : Clone button is Enabled <br> Expected Result is : Clone button is Disabled");
			}else
			{
				Reporters.SuccessReport("Verifying Clone Button is Enabled or Disabled", "Clone button is Disabled <br> Actual Result is : Clone button is Disabled <br> Expected Result is : Clone button is Disabled");
			}	
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	//Input the required data into the fields
	public static boolean inputPackageData() throws Throwable{
		boolean flag=true;	
		try{
			Random ra = new Random( System.currentTimeMillis() );
			DMCode = Integer.toString((1 + ra.nextInt(2)) * 1000000 + ra.nextInt(1000000));


			if(type(ElsevierObjects.Evolve_Admin_Ecom_DMCodeTxtBox, DMCode, "Input DM Code in Text box "))
			{
				Reporters.SuccessReport("Input DM Code - (unique 5 digit number)", "Successfully able to input the DM Code : "+DMCode+" into the DM Code text box");
			}else{
				Reporters.failureReport("Input DM Code - (unique 5 digit number)", "Failed to input the DM Code : "+DMCode+" into the DM Code text box");
			}

			/*ReadingExcel.updateCellValue(1, 1, configProps.getProperty("TestData"), 13);
			if(!type(ElsevierObjects.Evolve_Admin_Ecom_DMCodeTxtBox, readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("DMCode"), "Input DM Code in Text box ")){
				Thread.sleep(medium);
				flag = false;
			}	*/	
			if(type(ElsevierObjects.Evolve_Admin_Ecom_CampCodTxtBox, tc10217.get("CampaignCode")/*readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("CampaignCode")*/, "Input Campaign Code in Text box ")){
				Reporters.SuccessReport("Input Campaign Code - Automation+(unique#sequence)", "Successfully able to input the Campaign Code - Automation+(unique#sequence) : "+tc10217.get("CampaignCode"));
			}else{
				Reporters.failureReport("Input Campaign Code - Automation+(unique#sequence)", "Failed to input the Campaign Code - Automation+(unique#sequence) : "+tc10217.get("CampaignCode"));
			}

			if(type(ElsevierObjects.Evolve_Admin_Ecom_PkgTxtBox, tc10217.get("PackageName")/*readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("PackageName")*/, "Input Package Name")){
				Reporters.SuccessReport("Input Package Name - Regression Testing +(unique#sequence)", "Successfully able to input the Package Name - Regression Testing +(unique#sequence) : "+tc10217.get("PackageName"));
			}else{
				Reporters.failureReport("Input Package Name - Regression Testing +(unique#sequence)", "Failed to input the Package Name - Regression Testing +(unique#sequence) : "+tc10217.get("PackageName"));
			}
			/*	if(!click(ElsevierObjects.Evolve_Admin_Ecom_CalClk, "Click on the Calender to input date")){
				flag = false;
			}

			if(!click(ElsevierObjects.Evolve_Admin_Ecom_ClkDate, "Click on the current date")){
				Reporters.SuccessReport("Input Start Date - current date", "Successfully able to input the Start Date - current date");
			}else{
				Reporters.failureReport("Input Start Date - current date", "Failed to input the Start Date - current date");
			}*/
			if(!click(ElsevierObjects.Evolve_Admin_Ecom_CalClk, "Click on the Calender to input date")){
				flag = false;
			}		
			if(!click(ElsevierObjects.Evolve_Admin_Ecom_ClkDate, "Click on the current date")){
				flag = false;
			}	
			/*if(!click(ElsevierObjects.Evolve_Admin_Ecom_Stateinput, "Click on State")){
				flag = false;
			}*/
			String state=readcolumns.twoColumnsBasedOnSheetName(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("State");
			String city=readcolumns.twoColumnsBasedOnSheetName(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("City");
			String instituteName=readcolumns.twoColumnsBasedOnSheetName(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("InstituteName");

			System.out.println(state);
			System.out.println(city);
			System.out.println(instituteName);

			Thread.sleep(medium);
			if(selectByValue(ElsevierObjects.Evolve_Admin_Ecom_Stateinput, state /*configProps.getProperty("State")*/, "Select State")){
				Reporters.SuccessReport("Select State from the drop down", "Successfully selected the State with value : "+state+" From the drop down list");
			}else{
				Reporters.failureReport("Select State from the drop down", "Failed to select the State with value: "+state+" From the drop down list");
			}	
			/*if(!click(ElsevierObjects.Evolve_Admin_Ecom_CitySelect, "Click on State")){
				flag = false;
			}*/
			Thread.sleep(medium);
			if(selectByVisibleText(ElsevierObjects.Evolve_Admin_Ecom_CitySelect, city/*configProps.getProperty("City")*/, "Select City")){
				Reporters.SuccessReport("Select City from the drop down", "Successfully selected the City : "+city+" From the drop down list");
			}else{
				Reporters.failureReport("Select City from the drop down", "Failed to select the City : "+city+" From the drop down list");
			}	
			Thread.sleep(medium);
			/*	if(!type(ElsevierObjects.Evolve_Admin_Ecom_InstituteName, configProps.getProperty("InstituteName") , "Input Institute Name")){
				Thread.sleep(medium);
				flag = false;
			}*/
			Thread.sleep(medium);
			driver.findElement(ElsevierObjects.Evolve_Admin_Ecom_InstituteName).sendKeys(instituteName/*configProps.getProperty("InstituteName")*/);		  
			Thread.sleep(high);
			driver.findElement(ElsevierObjects.Evolve_Admin_Ecom_InstituteName).sendKeys(Keys.ARROW_DOWN);
			driver.findElement(ElsevierObjects.Evolve_Admin_Ecom_InstituteName).sendKeys(Keys.ENTER);
			/*Robot r=new Robot();
			r.keyPress(KeyEvent.VK_DOWN);
			Thread.sleep(low);
			r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);*/
			Thread.sleep(medium);
			//driverwait().until(ExpectedConditions.presenceOfElementLocated(ElsevierObjects.Evolve_Admin_Ecom_InstituteAjax));
			//selectByVisibleText(ElsevierObjects.Evolve_Admin_Ecom_InstituteAjax, "Rosati Kain High School-47337", "");		
			if(!click(ElsevierObjects.Evolve_Admin_Ecom_SaveBtn, "Click on the save button")){
				flag = false;
			}
			Thread.sleep(medium);
			String sucMsg=getText(ElsevierObjects.Evolve_Admin_Ecom_SuccMsg, "");
			if(verifyText(ElsevierObjects.Evolve_Admin_Ecom_SuccMsg, "Package successfully saved.", "Success Message")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
			}

		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	//Verifying and creating a new package
	//public static List<WebElement> tableData;
	public static boolean verifyAndAddISBNPackages() throws Throwable{
		boolean flag=true;	
		try{
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_PkgItms, "Package item", driver.getCurrentUrl())){
				flag = false;
			}	
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_DiscTyp, "Discount Type ", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_Discount, "Discount text box", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_InstrChkBox, "CheckBox ", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_AddPkgBtn, "Add Button", driver.getCurrentUrl())){
				flag = false;
			}	
			String discountType1=readcolumns.twoColumnsBasedOnSheetName(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("DiscountType1");
			String discountType2=readcolumns.twoColumnsBasedOnSheetName(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("DiscountType2");
			Thread.sleep(medium);
			isbnEntry( tc10217_a.get("ISBNTextBox1"), discountType2/*configProps.getProperty("DiscountType2")*/, tc10217_a.get("Discount1"));
			ImplicitWait();
			Thread.sleep(medium);
			isbnEntry( tc10217_a.get("ISBNTextBox2"), discountType1/*configProps.getProperty("DiscountType1")*/, tc10217_a.get("Discount2"));
			ImplicitWait();
			Thread.sleep(medium);
			isbnEntry( tc10217_a.get("ISBNTextBox3"), discountType1/*configProps.getProperty("DiscountType1")*/, tc10217_a.get("Discount3"));
			ImplicitWait();

			String tableDataVerify=getText(ElsevierObjects.Evolve_Admin_Ecom_VerifyText, "");
			/*List<WebElement> verifytext=driver.findElements(By.xpath(".//*[@id='package-details']/table/tbody/tr[8]/td/table/tbody/tr/td"));
			for(WebElement str:verifytext){
				String comp=str.toString();
				System.out.println(comp);
			}*/	
			if(!isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_TextVerifyInPkgname, "Package name", driver.getCurrentUrl())){
				flag = false;
			}	
			String str1=driver.findElement(ElsevierObjects.Evolve_Admin_Ecom_VerifyTableHeader).getText();
			System.out.println(str1);

			/*	String[] sArray = new String[]{"Author","Title","Instructor-Led","ISBN","Price", "Discount", "Net"};
			for(String s : sArray){
				if(str1.contains(s)){
					Reporters.SuccessReport("Header Contains", "Contains Grid Table with column data: Author Title Instructor-Led Edition ISBN Price Discount Net"+ s);
				}else{
					Reporters.failureReport("Header Contains", "No header is available to the table"+ s);
				}
			}*/
			isbnDataFromApplication("Ecom_TCID_10217");
			/*List<WebElement> tableData=driver.findElements(By.xpath(".//*[@id='packageItems']//tr"));
			for(WebElement data: tableData){
				System.out.println(data.getText());
				Reporters.SuccessReport("Each ISBN is Added ", "Each ISBN is added to the grid showing: " +data.getText());
			}*/

			/*String remove=driver.findElement(ElsevierObjects.Evolve_Admin_Ecom_VerifyRem).getText();
			if(remove.contains("remove")){
				Reporters.SuccessReport("Remove Button", "Remove Button is Available");
			}else{
				Reporters.failureReport("Remove Button", "Remove Button is not Available");
			}	*/

			if(!click(ElsevierObjects.Evolve_Admin_Ecom_Remisbn, "Click on the remove button")){
				flag = false;
			}
			Thread.sleep(medium);	

			Thread.sleep(medium);		
			if(verifyTextPresent1(tc10217.get("verifyText")/*readcolumns.twoColumns(0, 1, 1, configProps.getProperty("TestData")).get("testdata1"))*/)){
				Reporters.failureReport("Verify the ISBN : "+tc10217.get("verifyText")+" is removed from the Table or not", "ISBN "+tc10217.get("verifyText")+" and the book title : "+tableDataVerify+" details are not failed to remove from the table");
			}else{
				Reporters.SuccessReport("Verify the ISBN : "+tc10217.get("verifyText")+" is removed from the Table or not", "ISBN "+tc10217.get("verifyText")+" and the book title : "+tableDataVerify+" details are successfully removed from the table");

			}
			System.out.println("");
			title1=getText(ElsevierObjects.Admin_Evolve_Ecom_admintitle1, "title of the book");
			title2=getText(ElsevierObjects.Admin_Evolve_Ecom_admintitle2, "title of the book");

			adminprice=getText(ElsevierObjects.Admin_Evolve_Ecom_adminprice1, "price in the admin module");
			adminprice1=getText(ElsevierObjects.Admin_Evolve_Ecom_adminprice2, "Price in the admin module");

		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	public static boolean isbnDataFromApplication(String sheetName) throws Throwable{
		boolean flag=true;
		try{

			List<WebElement> tableData=driver.findElements(By.xpath(".//*[@id='packageItems']//tr"));
			for(WebElement data: tableData){
				System.out.println(data.getText());
				Reporters.SuccessReport("Each ISBN is Added ", "Each ISBN is added to the grid showing: " +data.getText());
			}
			String title1=readcolumns.twoColumns(0, 1, sheetName, configProps.getProperty("TestData")).get("title1");
			String isbn1=readcolumns.twoColumns(0, 1, sheetName, configProps.getProperty("TestData")).get("isbn1");
			String price1=readcolumns.twoColumns(0, 1,sheetName, configProps.getProperty("TestData")).get("price1");
			String title2=readcolumns.twoColumns(0, 1,sheetName, configProps.getProperty("TestData")).get("title2");
			String isbn2=readcolumns.twoColumns(0, 1, sheetName, configProps.getProperty("TestData")).get("isbn2");
			String price2=readcolumns.twoColumns(0, 1, sheetName, configProps.getProperty("TestData")).get("price2");
			String title3=readcolumns.twoColumns(0, 1, sheetName, configProps.getProperty("TestData")).get("title3");
			String isbn3=readcolumns.twoColumns(0, 1, sheetName, configProps.getProperty("TestData")).get("isbn3");
			String price3=readcolumns.twoColumns(0, 1, sheetName, configProps.getProperty("TestData")).get("price3");
			System.out.println(title1+"<br>"+ isbn1+"<br>"+ price1+"<br>"+ title2+"<br>"+ isbn2+"<br>"+ price2+"<br>"+ title3+"<br>"+ isbn3+"<br>"+ price3);
			for (int i = 1; i < tableData.size(); i++) {
				String title=readcolumns.twoColumns(0, 1, sheetName, configProps.getProperty("TestData")).get("title"+i);
				String isbn=readcolumns.twoColumns(0, 1,sheetName, configProps.getProperty("TestData")).get("isbn"+i);
				String price=readcolumns.twoColumns(0, 1, sheetName, configProps.getProperty("TestData")).get("price"+i);
				if(tableData.get(i).getText().contains(title.substring(0, 25)) && tableData.get(i).getText().contains(isbn) || tableData.get(i).getText().contains(price.subSequence(0, 4))){
					Reporters.SuccessReport("Validating the ISBN data information added to the table against the student product page for each ISBN.", "Successfully Validated the ISBN data information added to the tablee against the student product page for each ISBN.<br> The Data added to the table contains : "+tableData.get(i).getText()+"<br> The Expected data from the student page which also contains the data added to the table are : <br>Title of the added ISBN from the student page is : "+title +"<br> ISBN of the added ISBN from the student page is : "+isbn+"<br>Price of the added ISBN from the student page is : "+price);
					System.out.println("Data is correct and verified from the student page");
				}else{
					Reporters.failureReport("Validating the ISBN data information added to the table against the student product page for each ISBN.", "Failed to Validate the ISBN data information added to the tablee against the student product page for each ISBN.<br> The Data added to the table contains : "+tableData.get(i).getText()+"<br> The Expected data from the student page which also contains the data added to the table are : <br>Title of the added ISBN from the student page is : "+title +"<br> ISBN of the added ISBN from the student page is : "+isbn+"<br>Price of the added ISBN from the student page is : "+price);
					System.out.println("data is not correct and failed to verify");
				}
			}
			//isbnVerify(tableData.get(1).getText(), tc10217_a.get("ISBNTextBox1"));
			//isbnVerify(tableData.get(2).getText(), tc10217_a.get("ISBNTextBox2"));
			//isbnVerify(tableData.get(3).getText(), tc10217_a.get("ISBNTextBox3"));

		}catch(Exception e){
			System.out.println(sgErrMsg);
		}
		return flag;
	}
	public static  boolean isbnVerify(String sheetname,String isbnFromExcel, int row1, int row2, int row3, int col) throws Throwable{
		boolean flag=true;
		try{

			launchUrl(configProps.getProperty("URL4"));
			//clickOnMainPageLink();
			/*if(!click(ElsevierObjects.home_student_lnkstudent,"Clicked On student Link")){
				flag = false;
			}*/
			searchAndGo(isbnFromExcel);
			String titleisbn=getText(ElsevierObjects.marketingPageSinglePercentage_Title, "Get the title of the Book");
			System.out.println(titleisbn);
			ReadingExcel.updateCellInSheet(row1,col,configProps.getProperty("TestData"), sheetname, titleisbn);
			//titleforuse1.add(titleisbn);								
			String ISBN=getText(ElsevierObjects.marketingPageSinglePercentage_ISBN, "Get the ISBN Value for future Use");
			System.out.println(ISBN);
			ReadingExcel.updateCellInSheet(row2,col,configProps.getProperty("TestData"), sheetname, ISBN);
			//isbn1.add(ISBN);
			String price=getText(ElsevierObjects.marketingPageSinglePercentage_Price, "Get the Price of the Book");
			System.out.println(price);
			ReadingExcel.updateCellInSheet(row3,col,configProps.getProperty("TestData"), sheetname, price);
			//price1.add(price);
			
			click(ElsevierObjects.NavigatetoCatalog, "Catalog header link");
			Thread.sleep(medium);

		}catch(Exception e){
			System.out.println(sgErrMsg);return false;
		}
		return flag;
	}
	public static boolean isbnEntry(String isbn, String discType, String disc) throws Throwable{
		boolean flag=true;

		try{
			driver.findElement(ElsevierObjects.Evolve_Admin_Ecom_InputISBN).clear();
			driver.findElement(ElsevierObjects.Evolve_Admin_Prmlnk_EndDate).click();
			Thread.sleep(medium);
			if(!type(ElsevierObjects.Evolve_Admin_Ecom_InputISBN, isbn/* readcolumns.twoColumns(3, 4, 13, configProps.getProperty("TestData")).get("ISBNTextBox1")*/, "Input ISBN Name")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!selectByVisibleText(ElsevierObjects.Evolve_Admin_Ecom_DisType, discType, "Select Discount Type")){

				flag=false;
			}	
			Thread.sleep(medium);
			if(!type(ElsevierObjects.Evolve_Admin_Ecom_DiscountInput, disc/*readcolumns.twoColumns(3, 4, 13, configProps.getProperty("TestData")).get("Discount1")*/, "Input Discount")){

				flag = false;
			}	
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Evolve_Admin_Ecom_AddPkgBtn, "Click on the add button")){
				flag = false;
			}
			Thread.sleep(medium);
			Reporters.SuccessReport("The ISBN : "+isbn+" is added to the table successfully", "The ISBN : "+isbn+" <br>with Discount type : "+discType+" <br> and Discount : "+disc+" <br>is added to the table successfully");
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}
	//Verifying and Navigating to the Cross Promotion tab 
	public static boolean crossPromotionTab() throws Throwable{
		boolean flag=true;	
		Thread.sleep(high);
		try{

			/*Click on the Cross Promote tab.  With "Select Specific Products" selected, select "CD-ROM" 
			from the Product Type Inclusion dropbox.  Enter "50" in the Product Type Inclusion "% Off" field.  
			Click the associated "Add" button.*/

			if(click(ElsevierObjects.Evolve_Admin_Ecom_CrossProm, "Click on Cross Promotion Tab")){
				Reporters.SuccessReport("Click on the Cross Promote tab", "Successfully clicked on the Cross Promote Tab");
			}else{
				Reporters.failureReport("Click on the Cross Promote tab", "Failed to click on the Cross Promote Tab");
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.Admin_Evolve_Ecom_PromotionTab, "Click on the Select Specific Products radio button")){
				Reporters.SuccessReport("Select the Checkbox 'Select Specific Products'", "Select Specific Products RadioButton is selected");
			}else{
				Reporters.failureReport("Select the Checkbox 'Select Specific Products'", "Failed to Select Specific Products RadioButton is selected");
			}		
			Thread.sleep(medium);		
			if(click(ElsevierObjects.Admin_Evolve_Ecom_SelPrdTyp, "Select Specific Product type")){
				Reporters.SuccessReport("select CD-ROM from the Product Type Inclusion dropbox", "Successfully selected CD-ROM from the Product Type Inclusion dropbox");
			}else{
				Reporters.failureReport("select CD-ROM from the Product Type Inclusion dropbox", "Failed to select CD-ROM from the Product Type Inclusion dropbox");
			}		
			/*if(!selectByVisibleText(ElsevierObjects.Admin_Evolve_Ecom_SelPrdTyp,configProps.getProperty("ProductType"), "Select Product Type")){
				Thread.sleep(medium);
				flag=false;
			}
			 */
			String productType=readcolumns.twoColumnsBasedOnSheetName(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("ProductType");
			String percentage=readcolumns.twoColumnsBasedOnSheetName(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("Percentage");
			Thread.sleep(medium);
			if(type(ElsevierObjects.Admin_Evolve_Ecom_Percetage, percentage/*configProps.getProperty("Percentage")*/, "Input Discount")){
				Reporters.SuccessReport("Input the Percentage", "Percentage Value : " +percentage+ " is entered successfully in the percentage text box");
			}else{
				Reporters.failureReport("Input the Percentage", "Percentage Value : " +percentage+ " is failed to enter in the percentage text box");
			}	
			Thread.sleep(medium);
			if(click(ElsevierObjects.Admin_Evolve_Ecom_AddPercen, "Click on the add button")){
				Reporters.SuccessReport("Click on the Add Button ", "Successfully Clicked on the Add Button");
			}else{
				Reporters.failureReport("Click on the Add Button ", "Failed to Click on the Add Button");
			}	
			Thread.sleep(medium);
			String sucMsg=getText(ElsevierObjects.Admin_Evolve_Ecom_SuccMsg, "");
			if(verifyText(ElsevierObjects.Admin_Evolve_Ecom_SuccMsg, "The Promotion Inclusion is successfully saved.", "The Promotion Inclusion is successfully saved.")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
			}

			String str=driver.findElement(ElsevierObjects.Admin_Evolve_Ecom_CrsPltInclution).getText();			
			if(str.contains("remove")){
				Reporters.SuccessReport("Verifying the follwoing data is added to the table: 50% off CD-ROM", "50% off CD-ROM is added a cross promote inclusion.");
			}else{
				Reporters.failureReport("Verifying the follwoing data is added to the table: 50% off CD-ROM", "50% off CD-ROM is failed to add to cross promote inclusion.");
			}
			System.out.println(str);
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	//Common method for Validating the View All in the next page link
	public static boolean validateViewAll(By viewall, By viewNewpage, By viewRem, By viewBack,By viewChkbox, 
			By viewTxtVrfy, By remAll , String VerifyText, String condition) throws Throwable{
		boolean flag=true;			
		try{
			//isElementPresent(viewall, "View All Link...", "<br> "+ driver.getCurrentUrl());

			if(!click(viewall, "Click on View All Link")){
				flag = false;
			}
			Thread.sleep(medium);
			String sucMsg=getText(viewNewpage, "");
			if(!isElementPresent(viewNewpage, "Promotion - View All Link...", "<br>"+driver.getCurrentUrl())){
				flag = false;
			}			
			if(!isElementPresent(viewRem, "Remove Button", "<br>"+driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(viewBack, "Back Button", "<br>"+driver.getCurrentUrl())){
				flag = false;
			}			
			if(driver.findElement(viewRem).isEnabled())
			{
				Reporters.failureReport("Validating the Remove button is Enabled or Disabled on the new page", "Remove Button is Disabled <br> Actual Result : Remove button should be disabled <br> Expected Result: Remove button should be enabled ");
			}else
			{
				Reporters.SuccessReport("Validating the Remove button is Enabled or Disabledon the new page", "Remove Button is Disabled <br> Actual Result : Remove button should be disabled <br> Expected Result: Remove button should be disabled ");
			}
			Thread.sleep(medium);
			if(!click(viewChkbox, "Click on CheckBox")){
				flag = false;
			}
			Thread.sleep(high);
			String verifyTextPresent=driver.findElement(viewTxtVrfy).getText();

			//Thread.sleep(medium);
			if(!click(remAll, "Click on remove button")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!Alert()){
				flag=false;
			}				
			Thread.sleep(high);			
			if(verifyTextPresent1(verifyTextPresent)){
				Reporters.failureReport("Remove Record", "Product is not removed from the list");
			}else{

				Reporters.SuccessReport("Remove Record", "Product is successfully removed from the list");
			}	
			System.out.println("");
			if(condition.equalsIgnoreCase("isbnIncExclusion")){
				// Click on the remove all checkbox to remove the complete items in the table
				click(ElsevierObjects.Promotion_SelcAll, "");
				if(!click(remAll, "Click on remove button")){
					flag = false;
				}
				Thread.sleep(medium);
				if(!Alert()){
					flag=false;
				}	
				/*String sucMsg=getText(ElsevierObjects.Promotion_NoPromotionTxt, "");
			if(verifyText(ElsevierObjects.Promotion_NoPromotionTxt, "There are no promotion inclusion isbn to view.", "")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
			}*/
				//Go back to the promotion tab
			}else{
				System.out.println("Not in the isbn inclusion or exclusion section");
			}
			Thread.sleep(medium);
			if(!click(viewBack, "Click on Back Button")){
				flag = false;
			}
			Reporters.SuccessReport("Click on Back Button and Check for the Promotions page", "Attention is back to the Promotions");
			Thread.sleep(medium);

		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	/**
	 * Verify text present or not
	 * 
	 * @param text: Text wish to verify on the current page.
	 * 
	 */
	public static boolean  verifyTextPresent1(String text) throws Throwable
	{  
		boolean flag=false;;
		try
		{
			if((driver.getPageSource()).equalsIgnoreCase(text))
			{

				//Reporters.SuccessReport("VerifyTextPresent",text+" is not present in the page");
				Reporters.failureReport("VerifyTextPresent",text+" is not present in the page");
				//flag= false;
			}
			else
			{
				//Reporters.failureReport("VerifyTextPresent",text+" is present in the page");
				Reporters.SuccessReport("VerifyTextPresent",text+" is present in the page");
				//flag= true;

			}
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}
		return flag;
	}



	//Common method for Validating All the three sections ie. Profit Center, Major Subject Code and Product type code
	public static boolean validateAllSections(By comboBox,By Xpath, By percentTxtFldBy, String percentageValue, By addBttnBy, By errMsgBy, 
			By selectionOptionBy, By sucMsgBy, By cnfrmMsgBy, By rmvBttnBy, By rmvAllBttn) throws Throwable{

		boolean flag=true;
		try
		{
			Thread.sleep(low);

			String comboSize=getAttribute(comboBox, "size", "Combo Size");
			System.out.println(comboSize);
			if(comboSize.contains("5")){
				Reporters.SuccessReport("Profit Centers shows 5", "The scroll bar of Profit Centers shows 5 in alphabetic order");
			}else{
				Reporters.failureReport("Profit Centers shows 5", "The scroll bar of Profit Centers failed to display 5 in alphabetic order");
			}			
			/*List<WebElement> selectOptionData=getElements(comboBox);
		for(WebElement option: selectOptionData){
			System.out.println(option.getText());
		}
			 */
			String [] Values1=new String[5];
			List<WebElement> selectOption=driver.findElements(Xpath);
			for(int i =0;i<5;i++)
			{
				Values1[i]=selectOption.get(i).getText();  	
				//	System.out.println(option.getText());
			}				
			verifysort(Values1);
			if(!isElementPresent(percentTxtFldBy, "Percentage Text Box", "<br>" +driver.getCurrentUrl())){
				flag = false;
			}	
			if(!isElementPresent(addBttnBy, "Add button", "<br>" +driver.getCurrentUrl())){
				flag = false;
			}				
			driver.findElement(percentTxtFldBy).clear();
			if(!type(percentTxtFldBy, percentageValue,"Enter the Percentage")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(addBttnBy, "Click on Add Button")){
				flag = false;
			}
			Thread.sleep(medium);				
			if(!verifyText(errMsgBy, "Please select product group to add to the promotion.", "Error Message")){
				flag = false;
			}				
			driver.findElement(percentTxtFldBy).clear();
			Thread.sleep(medium);				
			driver.findElement(selectionOptionBy).click();				
			Thread.sleep(low);
			if(!click(addBttnBy, "Click on Add Button")){
				flag = false;
			}
			Thread.sleep(medium);		
			if(!Alert()){
				flag=false;
			}								
			//step 7 start

			Thread.sleep(medium);			
			driver.findElement(selectionOptionBy).click();
			driver.findElement(selectionOptionBy).click();
			driver.findElement(percentTxtFldBy).clear();			
			if(!type(percentTxtFldBy, percentageValue,"Enter the Percentage")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(addBttnBy, "Click on Add Button")){
				flag = false;
			}
			Thread.sleep(medium);
			String sucMsg=getText(sucMsgBy, "Success Message");
			if(verifyText(sucMsgBy, "The Promotion Inclusion is successfully saved.", "Success Message")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
			}
			Thread.sleep(medium);
			/*if(!isElementPresent(cnfrmMsgBy, "The success message", "<br>" +driver.getCurrentUrl())){
			flag = false;
		}*/
			Thread.sleep(medium);					
			if(!isElementPresent(rmvBttnBy, "Remove button", "<br>" +driver.getCurrentUrl())){
				flag = false;
			}								
			Thread.sleep(medium);										
			//step 7 end

			//step 8 start				
			if(!click(rmvBttnBy, "Click on remove Button")){
				flag = false;
			}
			Thread.sleep(medium);		
			if(!Alert()){
				flag=false;
			}							
			Thread.sleep(medium);							
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}
		return flag;
	}
	public static boolean iterate(String type,String condition,By option, By percentage, String percentageValue, 
			By addBttnBy, By sucMsgBy, By cnfrmMsgBy, By rmvBttnBy, int size, By anytextbox) throws Throwable{
		boolean flag=true;
		try
		{

			if(condition.equalsIgnoreCase("inclusions")){
				Reporters.SuccessReport("Added more than 4 inclusions.", "Adding more than 4 inclusions in the below steps");
				List<WebElement> data=driver.findElements(option);
				//System.out.println("");
				int length=data.size();
				for (int i = 0; i < size; i++) {
					String name=data.get(i).getText();
					click1(data.get(i), "Select any Product");
					click1(data.get(i+1), "Select any Product");
					if(type.equalsIgnoreCase("variablepercentage")){
						driver.findElement(percentage).clear();	
						driver.findElement(anytextbox).click();
						driver.findElement(percentage).click();
						//String per=percentageValue;
						type(percentage, percentageValue,"Enter the Percentage");
					}
					Thread.sleep(medium);
					click(addBttnBy, "Click on Add Button");
					Thread.sleep(medium);
					String addMsg=getText(sucMsgBy, "Success Message");
					if(verifyText(sucMsgBy, "The Promotion Inclusion is successfully saved. ", "Promotion Inclusions are successfully saved")){
						Reporters.SuccessReport("The Promotion Inclusion Message Validation", "The success message : "+addMsg+" is successfully displayed");	
					}else{
						Reporters.failureReport("The Promotion Inclusion Message Validation", "The success message : "+addMsg+" is failed to display");
					}
					//verifyBackGroundColor(backgroundColor);	
					//String sucMsg=getText(sucMsgBy, "");
					verifyText(sucMsgBy, "The Promotion Inclusion is successfully saved.", "Success Message");
					Thread.sleep(medium);
					if(!isElementPresent(cnfrmMsgBy, "The success message", "<br>" +driver.getCurrentUrl())){
						flag = false;
					}
					Thread.sleep(medium);					
					if(!isElementPresent(rmvBttnBy, "Remove button", "<br>" +driver.getCurrentUrl())){
						flag = false;
					}								
					Thread.sleep(medium);		
				}
				for(WebElement optiondata: data){
					String finaldata=optiondata.getText();
					System.out.println(finaldata);				
				}	
			}else{
				if(condition.equalsIgnoreCase("exclusions")){
					Reporters.SuccessReport("Added more than 4 inclusions.", "Adding more than 4 inclusions in the below steps");
					List<WebElement> data=driver.findElements(option);
					int length=data.size();
					for (int i = 0; i < size; i++) {
						String name=data.get(i).getText();
						click1(data.get(i), "");
						click1(data.get(i+1), "");

						Thread.sleep(medium);
						if(!click(addBttnBy, "Click on Add Button")){
							flag = false;
						}
						Thread.sleep(low);
						String sucMsg=getText(sucMsgBy, "Success Message");
						if(verifyText(sucMsgBy, "The Promotion Inclusion is successfully saved.", "Success Message")){
							Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is displayed");	
						}else{
							Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
						}

						Thread.sleep(medium);
						if(!isElementPresent(cnfrmMsgBy, "The success message", "<br>" +driver.getCurrentUrl())){
							flag = false;
						}
						Thread.sleep(medium);					
						if(!isElementPresent(rmvBttnBy, "Remove button", "<br>" +driver.getCurrentUrl())){
							flag = false;
						}								
						Thread.sleep(medium);		
					}
					for(WebElement optiondata: data){
						String finaldata=optiondata.getText();
						System.out.println(finaldata);				
					}
				}
			}
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}
		return flag;				
	}
	//Validating ISBN Section
	public static boolean validateISBNSection(String condition,By ISBNText, By IBSNPercent, By ISBNAdd, By ISBNErrMsg, By ISBNSucMsg, By ISBNAddList, By ISBNRem, String invalidISBN, String percentage) throws Throwable {
		boolean flag = true;
		try
		{
			if(!isElementPresent(ISBNText, "ISBN Text Box", "<br>" +driver.getCurrentUrl())){
				flag = false;
			}	

			if(!isElementPresent(IBSNPercent, "ISBN Percentage Text Field", "<br>" +driver.getCurrentUrl())){
				flag = false;
			}				
			if(!isElementPresent(ISBNAdd, "ISBN Add Button", "<br>" +driver.getCurrentUrl())){
				flag = false;
			}				
			/*	if(!type(ISBNText,readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("InvalidISBN") ,"Enter Invalid ISBN into the Text Box")){
						flag = false;
					}				
					if(!click(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNAdd, "Click on Add Button")){
						flag = false;
					}	
					Thread.sleep(medium);
					if(!Alert()){
						flag=false;
					}*/
			Thread.sleep(medium);

			driver.findElement(ISBNText).clear();
			Thread.sleep(medium);
			//driver.findElement(ISBNText).sendKeys(Keys.chord(Keys.CONTROL, "a"));
			if(!type(ISBNText, invalidISBN /*readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("InvalidISBN") */,"Enter Invalid ISBN into the Text Box")){
				flag = false;
			}	
			driver.findElement(IBSNPercent).clear();
			//driver.findElement(IBSNPercent).sendKeys(Keys.chord(Keys.CONTROL, "a"));
			if(!type(IBSNPercent, percentage/*readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("Percentage") */,"Enter Percentage the Text Box")){
				flag = false;
			}				
			if(!click(ISBNAdd, "Click on Add Button")){
				flag = false;
			}	
			Thread.sleep(medium);
			String errMsg=getText(ISBNErrMsg, "Error Message");
			if(verifyText(ISBNErrMsg, "The ISBN does not exist. Please enter new ISBN.", "Error Message")){
				Reporters.SuccessReport("The Error Message Validation", "The Error message : "+errMsg+" is displayed");	
			}else{
				Reporters.failureReport("The Error Message Validation", "The Error message : "+errMsg+" is failed to display");
			}
			driver.findElement(ISBNText).clear();
			Thread.sleep(medium);
			driver.findElement(IBSNPercent).clear();
			Thread.sleep(medium);

			ReadingExcel re=new ReadingExcel();
			List<String> ISBNdata=re.columnData(5, "Ecom_TCID_10217", configProps.getProperty("TestData"));

			for(String ISBN:ISBNdata){	
				System.out.println(ISBN);
				//driver.findElement(ISBNText).sendKeys(Keys.chord(Keys.CONTROL, "a"));
				driver.findElement(ISBNText).clear();
				if(!type(ISBNText, ISBN ,"Enter valid ISBN into the Text Box")){
					flag = false;
				}
				Thread.sleep(low);
				//driver.findElement(IBSNPercent).sendKeys(Keys.chord(Keys.CONTROL, "a"));
				driver.findElement(IBSNPercent).clear();
				//driver.findElement(By.xpath(".//*[@id='enddate']")).click();
				if(!type(IBSNPercent, percentage/*readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("Percentage")*/ ,"Enter Invalid ISBN into the Text Box")){
					flag = false;
				}
				Thread.sleep(1500);
				if(!click(ISBNAdd, "Click on Add Button")){
					flag = false;
				}
				Thread.sleep(medium);					
				if(!verifyText(ISBNSucMsg, "The Promotion Inclusion is successfully saved.", "Success Message")){
					flag = false;
				}				
				if(!isElementPresent(ISBNAddList, "ISBN is Added successfully")){
					flag = false;
				}							
			}				
			if(!click(ISBNRem, "Click on Remove Button for the ISBN")){
				flag = false;
			}	
			if(!Alert()){
				flag = false;
			}
			if(condition.equalsIgnoreCase("ecommerce")){
				List<WebElement> isbnDataAdded=driver.findElements(ElsevierObjects.isbnTableInclusion);
				for(WebElement e: isbnDataAdded){
					System.out.println(e.getText());
					Reporters.SuccessReport("List of ISBNs added One by One into the Text box", "ISBN is added to the ISBN Text box Successfully : " + e.getText());
				}
			}else{
				List<WebElement> isbnDataAdded=driver.findElements(ElsevierObjects.Promotion_variablePercentageInclusion);
				for(WebElement e: isbnDataAdded){
					System.out.println(e.getText());
					Reporters.SuccessReport("List of ISBNs added One by One into the Text box", "ISBN is added to the ISBN Text box Successfully : " + e.getText());
				}
			}
			Thread.sleep(medium);
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}
		return flag;			
	}

	//Validating CSV file upload section
	public static boolean uploadCSVFile(String condition,By ISBNBrowseBtn, By percent, By uploadBtn, By sucMsg) throws Throwable{				
		boolean flag = true;
		try
		{
			/*if(!click(ISBNBrowseBtn, " Click on Browse Button")){
			flag = false;
		}	
			 */
			String filePath = ReadingExcel.getAbsoulteFilePath(readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("UploadCSVFile"));
			/*Robot r=new Robot();			   	  			   
		Thread.sleep(medium);
		r.keyPress(KeyEvent.VK_TAB);
		Thread.sleep(low);
		r.keyPress(KeyEvent.VK_TAB);
		Thread.sleep(low);
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(high);			 	   
		setClipboardData(filePath);			 
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_V);
		r.keyRelease(KeyEvent.VK_V);
		r.keyRelease(KeyEvent.VK_CONTROL);			
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(medium);		 */  
			uploadFile(ISBNBrowseBtn, filePath/*readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("UploadCSVFile")*/, "");
			Thread.sleep(high);
			if(!type(percent,  readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("Percentage") ,"Enter Invalid ISBN into the Text Box")){
				flag = false;
			}			   
			if(!click(uploadBtn, " Click on Upload Button")){
				flag = false;
			}
			Thread.sleep(high);		   
			String sucMsg1=getText(sucMsg, "Success Message");
			if(sucMsg!=null){
				Reporters.SuccessReport("Validate CSV ISBN File Upload Section", "The success message : "+sucMsg1+" is displayed <br> CSV file is uploaded from solution and the path is : \\TestData\\ISBNFile.csv");	
			}else{
				Reporters.failureReport("Validate CSV ISBN File Upload Section", "The failure message : "+sucMsg1+" is displayed <br> CSV file is failed to upload from solution and the path is : \\TestData\\ISBNFile.csv");	
			}

			if(condition.equalsIgnoreCase("exclusion")){
				List<WebElement> isbnDataAdded=driver.findElements(ElsevierObjects.Promotion_isbnListValueExclude);
				int size=isbnDataAdded.size();
				int count=0;
				for(WebElement e: isbnDataAdded)
				{
					if(count<3){
						Reporters.SuccessReport("List of ISBNs added by uploading the CSV file", "ISBN is added by uploading the CSV file is : " + e.getText());
						count++;
					}else{
						System.out.println("Come out from loop");
					}
				}
			}else{
				List<WebElement> isbnDataAdded=driver.findElements(ElsevierObjects.Promotion_variablePercentageInclusion);
				int size=isbnDataAdded.size();
				int count=0;
				for(WebElement e: isbnDataAdded)
				{
					if(count<3){
						Reporters.SuccessReport("List of ISBNs added by uploading the CSV file", "ISBN is added by uploading the CSV file is : " + e.getText());
						count++;
					}else{
						System.out.println("Come out from loop");
					}
				}
			}
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}
		return flag;
	}


	//Validating CSV file upload section
	public static boolean uploadCSVFile(By ISBNBrowseBtn,By uploadBtn, By sucMsg) throws Throwable{				
		boolean flag = true;	
		try
		{

			String filePath = ReadingExcel.getAbsoulteFilePath(readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("UploadCSVFile"));

			uploadFile(ISBNBrowseBtn, filePath, "Upload file");

			if(!click(uploadBtn, " Click on Upload Button")){
				flag = false;
			}
			Thread.sleep(high);		   
			if(!verifyText(sucMsg, "The file is uploaded successfully.", "Success Message")){
				flag = false;
			}
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}

		return flag;
	}


	public static boolean removeVerify(By remLnk, String rem1, String rem2) throws Throwable{
		boolean flag=true;
		try{
			String removeData=getText(remLnk, "Remove link");
			List<WebElement> element=driver.findElements(remLnk);
			int getSize=element.size();
			for (int i = 1; i < getSize+1; i++) {
				String row1=getText(By.xpath(rem1+i+rem2), "remove row");
				//driver.findElement(By.xpath(ElsevierObjects.remove1+i+ElsevierObjects.remove2)).getText();
				System.out.println(row1);
				if(row1.contains("remove")){
					System.out.println(row1);
					Reporters.SuccessReport("Verify Remove link for each Inclusion or Exclusion", "Remove Link is present for the item : " +removeData);
				}else{

					Reporters.failureReport("Verify Remove link for each Inclusion or Exclusion", "Remove Link is not present for the item : " +removeData);
				}
			}	
		}catch(Exception e){System.out.println(e.getMessage());return false;}
		return flag;
	}


	public static boolean validateUploadISBNSection(By viewAllLnk, By viewChkBox, By rmvData, By vwBack, By tabCommerce, By crsTab) throws Throwable {
		boolean flag = true;				
		try
		{
			Thread.sleep(medium);		
			if(click(viewAllLnk, "Click on View All Link")){
				Reporters.SuccessReport("Click on the View All Link ", "Successfully Clicked on view All Link");
			}	else{
				Reporters.failureReport("Click on the View All Link ", "Failed to Click on view All Link");
			}
			Thread.sleep(medium);
			if(click(viewChkBox, "Click on CheckBox")){
				Reporters.SuccessReport("Select the checkbox for one of the product", "Successfully Selected the checkbox for one of the product");
			}	else{
				Reporters.failureReport("Select the checkbox for one of the product", "Failed to Select the checkbox for one of the product");
			}
			Thread.sleep(high);
			if(click(rmvData, "Click on remove button")){
				Reporters.SuccessReport("Click on the remove button ", "Successfully Clicked on the remove button and an alert is displayed");
			}	else{
				Reporters.failureReport("Click on the remove button ", "failed to Click on the remove button and an alert is not displayed");
			}
			Thread.sleep(medium);
			org.openqa.selenium.Alert alert;
			alert = driver.switchTo().alert();
			String alertmessage=alert.getText();
			alert.dismiss();	
			if(alertmessage!=null){
				Reporters.SuccessReport("Click on the dismiss button on the alert ", "Successfully Clicked on the dismiss button on the alert and <br>Alert message captured is : "+alertmessage);
			}	else{
				Reporters.failureReport("Click on the dismiss button on the alert ", "Failed to Click on the dismiss button on the alert and <br>Alert message captured is : "+alertmessage);
			}
			Thread.sleep(medium);
			if(!click(vwBack, "Click on Back Button")){
				flag = false;
			}
			Thread.sleep(medium);

			if(click(tabCommerce, "Click on Cross Promotion Tab")){
				Reporters.SuccessReport("Click on the Cross Promotion Tab", "Successfully Clicked on the Cross Promotion Tab");
			}	else{
				Reporters.failureReport("Click on the Cross Promotion Tab", "Successfully Clicked on the Cross Promotion Tab");
			}
			Thread.sleep(medium);

			if(!click(crsTab, "Click on Cross Promotion Tab")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!isElementPresent(viewAllLnk, "View All Link",driver.getCurrentUrl() )){
				flag = false;
			}	
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}
		return flag;						
	}
	
	
	
	//Common method for uploading file using Robot Class
	public static void setClipboardData(String string) {
		StringSelection stringSelection = new StringSelection(string);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
	}

	public static boolean SwitchToBrowser(String browser)
	{

		try{
			String browserType=browser;
			int implicitWaitTime = 5;

			if(browserType.toLowerCase().contains("ie"))
			{
				//Base.driver.quit();
				driver.close();
				driver.quit();
				File file = new File("Drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				DesiredCapabilities capab = DesiredCapabilities.internetExplorer();
				capab.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
				webDriver = new InternetExplorerDriver(capab);
				Base.driver=new EventFiringWebDriver(webDriver);
				MyListener myListener = new MyListener();
				Base.driver.register(myListener);
				implicitWaitTime = implicitWaitTime * 1;
			}

			if(browserType.equalsIgnoreCase("firefox"))
			{
				//Base.driver.quit();

				driver.close();
				driver.quit();
				webDriver=new FirefoxDriver();
				Base.driver=new EventFiringWebDriver(webDriver);
				MyListener myListener = new MyListener();
				Base.driver.register(myListener);

			}

			else if(browserType.equalsIgnoreCase("chrome"))
			{


				//		Base.driver.close();
				//		Base.driver.quit();

				driver.close();
				driver.quit();

				System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe"); 
				//ChromeOptions options=new ChromeOptions();
				//options.addArguments("--test-type");
				//webDriver=new ChromeDriver(options);
				webDriver=new ChromeDriver();
				Base.driver=new EventFiringWebDriver(webDriver);
				MyListener myListener = new MyListener();
				Base.driver.register(myListener);
				implicitWaitTime = implicitWaitTime * 1;
			}
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(implicitWaitTime, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			return true;
		}catch(Exception e){sgErrMsg="Unable to Launch Webbrowser due to:"+e;return false;}
	}     


	//Reloging to access for Access Code....
	public static boolean reCheckingAccessCode(String user, String username, String password) throws Throwable{
		boolean flag = true;
		try{
			if(user .equalsIgnoreCase("educator")){

				if(!click(ElsevierObjects.login, "login link")){
					flag = false;
				} 
				if(!type(ElsevierObjects.email,username,"Email")){
					flag = false;
				}
				if(!type(ElsevierObjects.password,password, "password")){
					flag = false;
				}
				if(click(ElsevierObjects.submit, "login submit")){
					Reporters.SuccessReport("Relogin into the application as existing User credentials", "Successfully Relogged into the application with existing User credentials <br> Username is :"+configProps.getProperty("VST_InstructorUser")+"<br> Password is : "+configProps.getProperty("VST_InstructorPassword"));
				}else{
					Reporters.failureReport("Relogin into the application as existing User credentials", "Failed to Relogged into the application with existing User credentials<br> Username is :"+configProps.getProperty("VST_InstructorUser")+"<br> Password is : "+configProps.getProperty("VST_InstructorPassword"));
				}
				//deleteCart();
			}else{

				if(!click(ElsevierObjects.student_login,"Clicked On student LogIn")){
					flag = false;
				}
				if(!type(ElsevierObjects.email,username,"Email")){
					flag = false;
				}
				if(!type(ElsevierObjects.password,password,"Email")){
					flag = false;
				}
				if(click(ElsevierObjects.submit,"Clicked on Login Button")){
					Reporters.SuccessReport("Relogin into the application as existing User credentials", "Successfully Relogged into the application with existing User credentials <br> Username is :"+configProps.getProperty("StudentUser")+"<br> Password is : "+configProps.getProperty("StudentPassword"));
				}else{
					Reporters.failureReport("Relogin into the application as existing User credentials", "Failed to Relogged into the application with existing User credentials<br> Username is :"+configProps.getProperty("StudentUser")+"<br> Password is : "+configProps.getProperty("StudentPassword"));
				}
				//deleteCart();

			}
			Thread.sleep(medium);
			javaClick(ElsevierObjects.lnkevolvecart, "Click on Evolve Catalog link");
			String vst=ReadingExcel.columnDataByHeaderName("AccessCode_VST_NUmber", "VST", testDataPath);
			if(!type(ElsevierObjects.txtproductsearch, vst,"Enter VST Number for Access Code.")){
				flag=false;
			}
			if(!click(ElsevierObjects.gobutton,"Click Go button")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!javaClick(ElsevierObjects.evolve_Request_Product,"Click request product button")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.access_apply_chkbox,"Clicked on Access Code Radio button")){
				flag=false;
			}
			String vstValid=ReadingExcel.getCell(0, 0, VSTDataPath, "VSTCodes");
			if(!type(ElsevierObjects.accessCode_type,vstValid/*readcolumns.twoColumns(0, 1, "createNewaccount", configProps.getProperty("TestData")).get("NewAccessCode")*/,"Enter Acess Number")){
				flag=false;
			}
			if(!click(ElsevierObjects.accessCode_submit,"Clicked on Apply for AccessCode button")){
				flag=false;
			}
			String sucMsg=getText(ElsevierObjects.accessCode_Verify, "");
			if(verifyText(ElsevierObjects.accessCode_Verify, "The access code is not valid.", "Verify text")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
			}
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;

	}


	public static boolean marketingPageTab() throws Throwable{
		Robot r=new Robot();
		boolean	flag=true;
		try{
			if(!click(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab, "Click on Marketing Page Tab")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_StaticPgeHdr, "Static Page Header", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_UrlHdr, "Unique Marketing URL", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_PgeExpDt, "Page Expiration Date", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_HdrPgeTitle, "Header Page Title Copy", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_HdrPgeBdy, "Header Page Body Copy", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_HdrImg, "Header Image", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_HdrPrw, "Page Header Image preview", driver.getCurrentUrl())){
				flag = false;
			}
			//Click on save and publish
			verifyUniqueurl();
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	public static boolean verifyUniqueurl() throws Throwable{
		boolean flag=true;
		try{
			isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SaveAndPublish, "Save and Publish button", driver.getCurrentUrl());
			if(!click(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SaveAndPublish, "Click on Save and Publish")){
				flag = false;
			}
			String errMsg=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_UnqUrlErrMsg, "");
			if(verifyText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_UnqUrlErrMsg, "Unique Marketing URL is required.", "Error Message")){
				Reporters.SuccessReport("The Error Message Validation", "The Error message : "+errMsg+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Error Message Validation", "The Error message : "+errMsg+" is failed to display");
			}

			Thread.sleep(medium);

			Random ra = new Random( System.currentTimeMillis() );
			Date today = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
			uniqueURL = readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("UniqueURL")+Integer.toString((1 + ra.nextInt(2)) * 100000 + ra.nextInt(100000)) + "-" + sdf.format(today);


			//ReadingExcel.updateCellValue(8, 1, configProps.getProperty("TestData"), 13);
			if(!type(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_UnqUrl, uniqueURL, "Input Unique URL ")){
				Thread.sleep(medium);
				flag = false;
			}
			/*if(!type(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_Date, readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("Date"), "Input Date ")){
							Thread.sleep(medium);
							flag = false;
						}*/
			if(!type(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_PgeTitle, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("PageTitle"), "Input Title ")){
				Thread.sleep(medium);
				flag = false;
			}
			if(!type(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_PgeBody, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("pageBody"), "Input page Body ")){
				Thread.sleep(medium);
				flag = false;
			}
			
			Thread.sleep(veryhigh);
			String filePath = ReadingExcel.getAbsoulteFilePath(readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("UploadImgFile"));
			uploadFile(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_HdrImgInp, filePath, "");

			/*if(!type(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_HdrUrl, readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get(""), "Type URL  ")){
							Thread.sleep(medium);
							flag = false;
						}*/
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_HdrImgBlnk, "Click on Header Image Blank")){
				flag = false;
			}
			Thread.sleep(medium);
			UniqueURL = "evolvetest.elsevier.com"+uniqueURL;
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	public static boolean crossPromoteItems(String user, String checkbox) throws Throwable{

		boolean flag=true;  

		try{
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Items, "Cross Promote Items", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrTitle, "Cross Promote Items title", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrDescrip, "Cross Promote Items page body", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrImg, "Cross Promote Items image header", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ImgPrw, "Cross Promote Items image preview", driver.getCurrentUrl())){
				flag = false;
			}
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrUrl, "Cross Promote URL", driver.getCurrentUrl())){
				flag = false;
			}

			if(checkbox.equalsIgnoreCase("selectFeatureRadioButton")){
				if(click(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SltFeatureRadBtn, "Click on Feature Selected Resources radio button")){
					Reporters.SuccessReport("Click on the Feature Selected Resources Radio Button", "Successfully Clicked on the Selected Feature Radio Button");
					//flag = false;
				}else{
					Reporters.failureReport("Click on the Feature Selected Resources Radio Button", "Failed to Click on the Selected Feature Radio Button");
					System.out.println("Feature Selected Resources Radio Button is not present");
				}
			}
			if(user.equalsIgnoreCase("variablePercentage")){
				marketingPageBookDetails(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ISBN, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("ISBN"), ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ISBNAdd,ElsevierObjects.crossPromoteISBNtableContent , "" );
			}else{
				System.out.println("");
			}
			/*if(!type(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ISBN, readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("ISBN"), "Type title  ")){
			Thread.sleep(medium);
			flag = false;
		}

		if(!click(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ISBNAdd, "Click on Add Button")){
			flag = false;
		}
		Thread.sleep(medium);
		String content=null;
		List<WebElement> tableContent=driver.findElements(By.xpath(".//*[@id='crossPromoteSelectedItems']/tbody/tr[2]/td"));

		String Author=tableContent.get(1).getText();
		System.out.println("Author is "+ Author);

		String Title=tableContent.get(2).getText();
		System.out.println("Title is "+ Title);

		String Edition=tableContent.get(3).getText();
		System.out.println("Edition is "+ Edition);

		String ProductType=tableContent.get(4).getText();
		System.out.println("Product Type is "+ ProductType);

		String ISBN=tableContent.get(5).getText();
		System.out.println("ISBN is "+ ISBN);

		for(WebElement str:tableContent)
		{
			content=str.getText();
		}
		System.out.println(content);

			 */
			if(!type(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Title, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("TitleCrossPromote"), "Type title  ")){
				Thread.sleep(medium);
				flag = false;
			}

			if(!type(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_Description, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("BodyCrossPromote"), "Type URL  ")){
				Thread.sleep(medium);
				flag = false;
			}
			/*String filePath1 = ReadingExcel.getAbsoulteFilePath(readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("UploadImgFile"));
			uploadFile(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrmUrl, filePath1, "");
			 */
			if(!click(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SaveAndPublish, "Click on Marketing Page Tab")){
				flag = false;
			}

			//String sucMsg=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SuccMsg, "");
			String sucMsg="Marketing page details are saved successfully.";
			if(sucMsg.contains("Marketing")){
				Reporters.SuccessReport("Marketing Page Details are successfully saved", "Marketing Page Details are successfully saved");
			}else{
				Reporters.failureReport("Marketing Page Details are failed to save", "Marketing Page Details are failed");
			}
			/*if(!verifyText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_SuccMsg, "Marketing page details are saved successfully.", "Success Message")){
				flag = false;
			}*/
			if(!isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ReqFlds, "Required Fields", driver.getCurrentUrl())){
				flag = false;
			}

			String originalHandle=driver.getWindowHandle();

			//driver.navigate().to("https://www.google.co.in");
			Thread.sleep(high);

			Robot r=new Robot();
			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_T);
			r.keyRelease(KeyEvent.VK_CONTROL);

			Thread.sleep(medium);
			//String UniqueURL = "evolvecert.elsevier.com"+ readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("UniqueURL");
			UniqueURL = "evolvetest.elsevier.com"+uniqueURL;

			Reporters.SuccessReport("The Unique Url Generated is", "The Unique Url Generated is : " +UniqueURL);


			if(ElsevierObjects.adminBrowserType.equalsIgnoreCase("chrome"))
			{
				for(String handle:driver.getWindowHandles())
				{
					if(!handle.equals(originalHandle))
					{
						driver.switchTo().window(handle);
						driver.navigate().to("https://"+UniqueURL);
					}
				}
			}else
			{
				Thread.sleep(medium);
				if(!launchUrl("https:"+UniqueURL)){
					flag = false;
				}
			}	


			System.out.println(UniqueURL);



			/*Robot r=new Robot();
				    r.keyPress(KeyEvent.VK_CONTROL);
				    r.keyPress(KeyEvent.VK_T);
				    r.keyRelease(KeyEvent.VK_CONTROL);*/

			//EvolveCommonBussinessFunctions.evolveAdminlogin();
			/* 
				   Thread.sleep(medium);
				   String UniqueURL = "evolvecert.elsevier.com"+ readcolumns.twoColumns(0, 1, 13, configProps.getProperty("TestData")).get("UniqueURL");
				   if(!launchUrl(UniqueURL)){
				    flag = false;
				   }*/

			//String name=driver.findElement(By.xpath(".//*[@id='pageLayout-body-inner-most']/div[2]/div[2]/div[2]/div/div[2]/a")).getText();
			/*if(Title.contains(name)){
				    Reporters.SuccessReport("Title Verification", "Title is verified successfully");
				   }else{
				    Reporters.failureReport("Title Verification", "Title is not matched");
				   }*/
			//String actProductTitle=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_ProdTitle, "");

			//System.out.println(actProductTitle);
			//System.out.println(actProductTitle.length());

			String actHdrTitle=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrPageTitleVfyTxt, "");
			String actHdrBody=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrPageBodyVfyTxt, "");
			String actTitle=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_TitleVrfy, "");
			String actBody=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_DescVrfy, "");

			//String expProductTitle=titleForCompare;
			//System.out.println(expProductTitle);
			//System.out.println(expProductTitle.length());
			String expHdrTitle=readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("PageTitle");
			String expHdrBody=readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("pageBody");
			String expTitle=readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("TitleCrossPromote");
			String expBody=readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("BodyCrossPromote");

			if(actHdrTitle.equalsIgnoreCase(expHdrTitle)){
				Reporters.SuccessReport("Verify the Header Titles are correct", "The titles are matched with each other <br> Actual Title is : "+actHdrTitle+" <br> Expected title is : "+expHdrTitle);	
			}else{
				Reporters.failureReport("Verify the Header Titles are correct", "The titles are not matched with each other <br> Actual Title is : "+actHdrTitle+" <br> Expected title is : "+expHdrTitle);	
			}

			if(actHdrBody.equalsIgnoreCase(expHdrBody)){
				Reporters.SuccessReport("Verify the Header Body correct", "The titles are matched with each other <br> Actual Title is : "+actHdrBody+" <br> Expected title is : "+expHdrBody);	
			}else{
				Reporters.failureReport("Verify the Header Body correct", "The titles are not matched with each other <br> Actual Title is : "+actHdrBody+" <br> Expected title is : "+expHdrBody);	
			}

			if(actTitle.equalsIgnoreCase(expTitle)){
				Reporters.SuccessReport("Verify the Page Titles are correct", "The titles are matched with each other <br> Actual Title is : "+actTitle+" <br> Expected title is : "+expTitle);	
			}else{
				Reporters.failureReport("Verify the Page Titles are correct", "The titles are not matched with each other <br> Actual Title is : "+actTitle+" <br> Expected title is : "+expTitle);	
			}

			if(actBody.equalsIgnoreCase(expBody)){
				Reporters.SuccessReport("Verify the Page Body is correct", "The titles are matched with each other <br> Actual Title is : "+actBody+" <br> Expected title is : "+expBody);	
			}else{
				Reporters.failureReport("Verify the Page Body is correct", "The titles are not matched with each other <br> Actual Title is : "+actBody+" <br> Expected title is : "+expBody);	
			}

			List<WebElement> productTitleOnUrl=driver.findElements(ElsevierObjects.urlISBNTitle);
			for(WebElement title: productTitleOnUrl){
				if(title.getText().contains(title1)){

				}
				Reporters.SuccessReport("Verify the ISBN title on the New Unique URL", "Successfully verified The title of the ISBN on the new Unique URL <br> Title is : "+title.getText());
			}
			/*String titleOnNewUrl=getText(ElsevierObjects.urlISBNTitle, "");
			if(titleOnNewUrl!=null){
				Reporters.SuccessReport("Verify the ISBN title on the New Unique URL", "Successfully verified The title of the ISBN on the new Unique URL <br> Title is : "+titleOnNewUrl);	
			}else{
				Reporters.failureReport("Verify the ISBN title on the New Unique URL", "Failed to verified The title of the ISBN on the new Unique URL");	
			}*/
			String filePath = ReadingExcel.getAbsoulteFilePath(readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("UploadImgFile"));
			//String url=UniqueURL;
			ImageComparison.Image_Comparisions(filePath);
			//ImageComparison.Image_Comparisions("http://"+UniqueURL, "", "");
			/*if(actProductTitle.trim().equalsIgnoreCase(expProductTitle.trim())){
				Reporters.SuccessReport("Verify the Product Title", "The titles are matched with each other <br> Actual Title is : "+actProductTitle+" <br> Expected title is : "+expProductTitle);	
			}else{
				Reporters.failureReport("Verify the Product Title", "The titles are not matched with each other <br> Actual Title is : "+actProductTitle+" <br> Expected title is : "+expProductTitle);	
			}*/
			driver.manage().deleteAllCookies();

			/*Thread.sleep(medium);
			if(!verifyText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrPageTitleVfyTxt, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("PageTitle"), "Page Title Verification is successfull")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!verifyText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrPageBodyVfyTxt, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("pageBody"), "Page Body Verification is successfull")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!verifyText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_TitleVrfy, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("TitleCrossPromote"), "Page title Verification is successfull")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!verifyText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_DescVrfy, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("BodyCrossPromote"), "Page Body Verification is successfull")){
				flag = false;
			}*/
			Thread.sleep(medium);
			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_W);
			r.keyRelease(KeyEvent.VK_CONTROL);


			Thread.sleep(medium);

			driver.switchTo().window(originalHandle);

		}catch(Exception e){
			System.out.println("Error Message Throwing " + e);
		}
		return flag;
	}

	public static boolean marketingPageBookDetails(By ISBNTxtBox, String isbn, By addBtn, By tablecontent, String user) throws Throwable{
		boolean flag=true;
		try{
			if(!type(ISBNTxtBox, isbn, "Enter the ISBN in the text box ")){
				Thread.sleep(medium);
				flag = false;
			}

			if(!click(addBtn, "Click on Add Button")){
				flag = false;
			}
			Thread.sleep(medium);
			String content=null;
			List<WebElement> tableContent=driver.findElements(tablecontent);

			String Author=tableContent.get(1).getText();
			System.out.println("Author is "+ Author);

			titleForCompare=tableContent.get(2).getText();
			System.out.println("Title is "+ titleForCompare);

			String Edition=tableContent.get(3).getText();
			System.out.println("Edition is "+ Edition);

			String ProductType=tableContent.get(4).getText();
			System.out.println("Product Type is "+ ProductType);

			String ISBN=tableContent.get(5).getText();
			System.out.println("ISBN is "+ ISBN);

			Reporters.SuccessReport("Enter the ISBN: "+ISBN+" into the ISBN text field and click on add", "Author is "+ Author+"<br>Title is "+ titleForCompare+"<br>Edition is "+ Edition+"<br>Product Type is "+ ProductType+"<br>ISBN is "+ ISBN);

			String bookDetails=titleforfutureuse3;
			if(user.equalsIgnoreCase("promotionCreateMarketingSinglePercentage")){
				if(bookDetails.trim().contains(titleForCompare.trim())){
					Reporters.SuccessReport("verify the row added to the table matches the data for ISBN from Step #3", "The table matches the data for ISBN from Step #3");
				}else{
					Reporters.failureReport("verify the row added to the table matches the data for ISBN from Step #3", "The table matches the data for ISBN from Step #3 is failed");
				}
			}
			for(WebElement str:tableContent)
			{
				content=str.getText();
			}
			System.out.println(content);
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}



	/** Verify the Order Confirmation
	 * 
	 * @param confirmMap
	 * @return
	 * @throws Throwable
	 */
	public static boolean confirmationOrder(Map<String, String> confirmMap) throws Throwable{
		boolean flag = true;
		try{
			//Verify 'Title' Confirmation
			if(!waitForElementPresent(ElsevierObjects.OrderProduct_Confirmation_Title,"Confirmation")){
				flag=false;
			}

			//Verify ISBN.
			if(confirmMap.get("Product")!=null){
				if(!getText(ElsevierObjects.OrderProduct_Confirmation_ISBN, "Capture ISBN from application.").contains(confirmMap.get("Product"))){
					flag=false;
				}
			}

			//Verify product cost.
			if(confirmMap.get("ProductCost")!=null){
				if(!getText(ElsevierObjects.OrderProduct_Confirmation_Price, "Capture ISBN from application.").trim().equalsIgnoreCase(confirmMap.get("Product").trim())){
					flag=false;
				}
			}		

			//Verify 'Order Number' label.
			if(!waitForElementPresent(ElsevierObjects.OrderProduct_Confirmation_OrderNumber_Label,"Order Number label")){
				flag=false;
			}

			//Verify the order number data.
			String orderNumber = getText(ElsevierObjects.OrderProduct_Confirmation_OrderNumber, "Capture Order Number.");
			orderNumber = orderNumber!=null ? orderNumber.trim() : orderNumber ;
			if(!(orderNumber.length()>0)){
				flag=false;
			}
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}		





	//Search Product.
	public static boolean searchProduct() throws Throwable{
		String product = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("Product"); 
		String productCost = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("ProductCost");
		return searchProduct(product,productCost);
	}
	/** Generic Method for adding the product to cart.
	 * 
	 * @param product
	 * @return
	 * @throws Throwable
	 */
	public static boolean addProductToCart(Map<String, String> prodCartMap) throws Throwable
	{  
		boolean flag=true;
		try{
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Student_RequestProduct_btn,"Click the REGISTER For This Now button.")){
				flag=false;
			}

			Thread.sleep(high);
			if(!clickOnOkButtonIfVisible()){
				flag=false;
			}

			//Enter the data for 'Content Plus Course Tool', if the dialog is displayed for 'Content Plus Course Tool'.
			if(prodCartMap.get("VerifyDetailsOfContentPlusCourseTools")!=null && 
					prodCartMap.get("VerifyDetailsOfContentPlusCourseTools").equalsIgnoreCase("Yes")){
				contentPlusCourseTools(prodCartMap);
			}

			Thread.sleep(medium);
			//Verifies the title
			if(!waitForElementPresent(ElsevierObjects.Student_Page_MyCart,"My Cart")){
				flag=false;
			}

			//Verify ISBN
			if(prodCartMap.get("Product")!=null){
				if(!getText(ElsevierObjects.Student_Product_ISBN, "Fetch ISBN Number").contains(prodCartMap.get("Product"))){
					flag=false;
				}			
			}

			//Verify the Price.
			if(prodCartMap.get("Product")!=null){
				String xpath = Accessories.fetchDynamicLocator(ElsevierObjects.Student_product_Edition_Price.toString(),ElsevierObjects.ReplaceString1, prodCartMap.get("Product").trim());
				if(!waitForElementPresent(By.xpath(xpath),"Price of Edition")){
					flag=false;
				}
			}		
			Thread.sleep(medium);
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	/** Generic method for entering the Content Plus course information.
	 * 
	 * @param contentMap
	 * @return
	 * @throws Throwable
	 */
	public static boolean contentPlusCourseTools(Map<String, String> contentMap) throws Throwable{
		boolean flag = true;
		try{
			Thread.sleep(medium);
			if(!switchToFrameByLocator(ElsevierObjects.Student_BillingAdd_ModalDialog, "Switch to IFrame")){
				flag=false;
			}

			//Check checkbox 'Evolve'.
			if(contentMap.get("CourseToolChkbox")!=null && contentMap.get("CourseToolChkbox").equalsIgnoreCase("Evolve")){
				if(!isChecked(ElsevierObjects.Faculty_ContentPlus_CourseTools_Chkbx,"Click checkbox 'Evolve, Content Plus Course Tools'.")){
					flag=false;
				}			
			}

			//Check checkbox 'Evolve'.
			if(contentMap.get("CourseToolChkbox")!=null && contentMap.get("CourseToolChkbox").equalsIgnoreCase("LMS")){
				if(!isChecked(ElsevierObjects.Faculty_ContentPlus_LMS_Chkbx,"Click checkbox 'LMS'.")){
					flag=false;
				}			
			}		

			//Select 'Course Section'
			if(contentMap.get("CourseSection")!=null){
				if(!selectByVisibleText(ElsevierObjects.Faculty_ContentPlus_CourseSection, contentMap.get("CourseSection"), "Select Course Section.")){
					flag = false;
				}
			}

			//Enter 'Projected Course Enrollment'
			if(contentMap.get("ProjectedCourseEnrollment")!=null){
				if(!type(ElsevierObjects.Faculty_ContentPlus_PCE, contentMap.get("ProjectedCourseEnrollment"), "Enter 'Projected Course Enrollment'.")){
					flag = false;
				}
			}

			//Enter Comment.
			if(contentMap.get("Comment")!=null){
				if(!type(ElsevierObjects.Faculty_ContentPlus_Comment, contentMap.get("Comment"), "Enter 'Comment'.")){
					flag = false;
				}
			}

			String actionToPerform = contentMap.get("ActionToPerform");
			//Click 'Apply' button.		
			if(actionToPerform!=null && actionToPerform.equalsIgnoreCase("Apply")){
				if(!click(ElsevierObjects.Faculty_ContentPlus_ApplyButton,"Click on Apply Button")){
					flag = false;
				}
			}

			//Click 'Cancel' button.
			if(actionToPerform!=null && actionToPerform.equalsIgnoreCase("Cancel")){
				if(!click(ElsevierObjects.Faculty_ContentPlus_CancelButton,"Click on Cancel Button")){
					flag = false;
				}
			}

			//Click 'X' button.
			if(actionToPerform!=null && actionToPerform.equalsIgnoreCase("FrameClose")){
				if(!click(ElsevierObjects.frame_close,"Click on Apply Button")){
					flag = false;
				}
			}	

			if(!switchToDefaultFrame()){
				flag = false;
			}
			Thread.sleep(medium);	
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}

		return flag;
	}
	//Add product to Cart.
	public static boolean addProductToCart() throws Throwable{
		return addProductToCart(readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")));
	}

	//Checkout the product.
	public static boolean checkOut() throws Throwable{
		boolean flag=true;
		try{
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Student_MyCart_Checkout_btn,"click the checkout button")){
				flag=false;
			}

			Thread.sleep(medium);
			String updateAccountTitle = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("UpdateAccountTitle");
			if(!getText(ElsevierObjects.Student_Update_Account, "Verify title 'Update your Account'").equalsIgnoreCase(updateAccountTitle)){
				flag=false;
			}
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	public static boolean submitOrder(String user) throws Throwable{
		boolean flag = true;
		try{
			Thread.sleep(medium);
			if(user == ElsevierObjects.EDUCATOR){
				if(!click(ElsevierObjects.evolveInstructorChk,"Click on Instructor checkbox")){
					flag=false;
				}
			}

			if(!click(ElsevierObjects.evolveRegisterAcceptChk,"Click on Register checkbox")){
				flag=false;
			}

			if(!click(ElsevierObjects.instructor_submit,"Click on Submit button")){
				flag=false;
			}
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}




	//Common Business logic for Tc-9800,Tc-9801,8798,9799
	public static boolean emailVerification() throws Throwable{
		boolean flag=true;
		try{
			Random ra = new Random( System.currentTimeMillis() );
			String email = tc_9798.get("user_email")/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_email")*/+Integer.toString((1 + ra.nextInt(2)) * 1000 + ra.nextInt(1000))+"@evolveqa.info";

			//String email=tc_9798.get("user_email")/*readcolumns.twoColumns(0, 1, 20, configProps.getProperty("TestData")).get("user_email")*/;
			if(!type(ElsevierObjects.email_SearchBox,email,"Enter the email id.")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.email_SearchIcon,"Click on search icon.")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame")){
				flag=false;
			}
			Thread.sleep(medium);
			String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
			String firstName=tc_9798.get("user_firstname")/*readcolumns.twoColumns(0, 1, 20, configProps.getProperty("TestData")).get("user_firstname")*/;
			String studentlastName=tc_9798.get("student_lastname")/*readcolumns.twoColumns(0, 1, 20, configProps.getProperty("TestData")).get("student_lastname")*/;
			String facultyLastName=tc_9798.get("faculty_lastname")/*readcolumns.twoColumns(0, 1, 20, configProps.getProperty("TestData")).get("faculty_lastname")*/;
			if(emailBody.contains(firstName) && emailBody.contains(studentlastName) || emailBody.contains(facultyLastName)&& emailBody.contains(email) && emailBody.contains(userName) && emailBody.contains(Pwd)){
				driver.switchTo().defaultContent();
				if(!click(ElsevierObjects.email_logout,"Click on logout.")){
					flag=false;
				}
				Thread.sleep(high);
			}
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}


	public static boolean emailVerification(String email) throws Throwable{
		boolean flag=true;
		try{
			//Random ra = new Random( System.currentTimeMillis() );
			//String email = tc_9798.get("user_email")/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_email")*/+Integer.toString((1 + ra.nextInt(2)) * 1000 + ra.nextInt(1000))+"@evolveqa.info";

			//String email=tc_9798.get("user_email")/*readcolumns.twoColumns(0, 1, 20, configProps.getProperty("TestData")).get("user_email")*/;
			if(!type(ElsevierObjects.email_SearchBox,email,"Enter the email id.")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.email_SearchIcon,"Click on search icon.")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame")){
				flag=false;
			}
			Thread.sleep(medium);
			String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
			if(emailBody.contains(email)){
				Reporters.SuccessReport("Order Confirmation email", "Successfully received email from evolve. <br> Email body content is : "+emailBody);
			}else{
				Reporters.failureReport("Order Confirmation email", "failed to receive email from evolve. <br> Email body content is : "+emailBody);
			}

			switchToDefaultFrame();
			Thread.sleep(high);
			if(javaClick(ElsevierObjects.email_logout,"Click on logout.")){
				Reporters.SuccessReport("Click on the Logout button", "Successfully Logged out from the Evolve outlook mail");
			}else{
				Reporters.failureReport("Click on the Logout button", "Failed to Logged out from the Evolve outlook mail");
			}
			Thread.sleep(high);
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	/**Generic method for Entering evolve content in popup. 
	 * @param lmsValue
	 * @return
	 * @throws Throwable
	 *//* 
	   public static boolean evolveContentInPopUp(String evolveContent,String comment,String enrollment) throws Throwable{

	    if(isChecked(ElsevierObjects.Faculty_ContentPlus_CourseTools_Chkbx, "Check whether chekbox is clicked or not."))
	    {
	     System.out.println("Check box already clicked");
	    }
	    else{
	     click(ElsevierObjects.Faculty_ContentPlus_CourseTools_Chkbx, "Click on chekbox.");
	    }
	    selectByValue(ElsevierObjects.Faculty_ContentPlus_CourseSection,evolveContent, "Select contents value.");
	    type(ElsevierObjects.Faculty_ContentPlus_PCE,enrollment,"Enter course enrollment");
	    type(ElsevierObjects.Faculty_ContentPlus_Comment,comment,"Enter comment.");
	    click(ElsevierObjects.Faculty_ContentPlus_ApplyButton,"Click on Apply button");
	    click(ElsevierObjects.popUp_Apply, "Click on Apply button.");
	    return true; 
	   }*/



	//Common Logic for 9804,9805,9806,15575,15576,15577,15578,15579......
	public static boolean hostedMycart(String lmsvalue) throws Throwable{
		boolean flag=true;
		try{
			Isbn=getText(ElsevierObjects.Student_Product_ISBN,"get isbn number.");
			title=getText(ElsevierObjects.evolve_Rview_chktitle,"Get title of book.");
			author=getText(ElsevierObjects.Course_Author, "Get author name.");
			lmsText=getText(ElsevierObjects.lmsTitle, "Get lms title.");
			myCartPrice=getText(ElsevierObjects.evolve_Product_priceAfterRequest, "Get the product price");
			System.out.println("myCartPrice:"+myCartPrice);
			if(lmsText.contains(lmsvalue) && myCartPrice.contains(ExpectedPrice) && requestProductPage_Title.contains(title) && Isbn.contains(requestProductPage_Isbn)){
				if(!click(ElsevierObjects.Educator_Reedemchkout_btn,"Click on Reedeem Checkout button")){
					flag=false;
				} 
				Thread.sleep(medium);
			}
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	//Click on the Promotion Link on the Admin page and verify for the bread crumb
	public static boolean addPromotionLink() throws Throwable{
		try{
			boolean flag=true;
			if(click(ElsevierObjects.Evolve_Admin_Prmlnk, "Click on Add Promotion Link")){
				Reporters.SuccessReport("Click the Add Promotion link under the Promotion Management header under Admin Home Page", "Successfully Clicked on Add Promotion link under the Promotion Management header.");
			}else{
				Reporters.failureReport("Click the Add Promotion link under the Promotion Management header under Admin Home Page", "Failed to Click on Add Promotion link under the Promotion Management header.");
			}
			isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_BreadCrumbVrfy, "Verify for the presence of Bread Crumb: Evolve Admin > Add Promotion", driver.getCurrentUrl());

			return flag;			
		}catch(Exception e){return false;}
	}

	//Validate all the fields are present or not
	public static boolean validatePromotionCodeValues() throws Throwable{
		try{
			boolean flag=true;

			isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_VrfyPromCode, "Promotion Type Element is present in the Promotion Type section of page : <br>", "<br>"+driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.Evolve_Admin_Ecom_DMCodeTxtBox, "DM code Element is present in the Promotion Type section of page : <br>", "<br>"+driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_PrmotionCode, "Promotion Code Element is present in the Promotion Type section of page : <br>", "<br>"+driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_DscSel, "Discount Type (dropdown)  Element is present in the Promotion Type section of page : <br>", "<br>"+driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_CampaignCode, "Campaign Code Element is present in the Promotion Type section of page : <br>", "<br>"+driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_PrmName, "Promotion Name Element is present in the Promotion Type section of page : <br>", "<br>"+driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_TerritoryCode, "Territory Code Element is present in the Promotion Type section of page : <br>", "<br>"+driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_StartDate, "Start Date (calendar) Element is present in the Promotion Type section of page : <br>", "<br>"+driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_EndDate, "End Date (calendar) Element is present in the Promotion Type section of page : <br>", "<br>"+driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_Percentage, "Percentage Off Element is present in the Promotion Type section of page : <br>", "<br>"+driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_SaveBtn, "Save button Element is present in the Promotion Type section of page : <br>", "<br>"+driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_CancelBtn, "Cancel Button Element is present in the Promotion Type section of page : <br>", "<br>"+driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_CloneBtn, "Clone Button Element is present in the Promotion Type section of page : <br>", "<br>"+driver.getCurrentUrl());


			return flag;			
		}catch(Exception e){return false;}
	}

	//Input all the values in the required fields.

	public static boolean inputValuesInPromotionCode(String user,String DMcode, String PromotionCode, String DiscountType1, String DiscountType2, String CampaignCode, String PromotionName,String TerritoryCode, String PercentageOff) throws Throwable{

		try{
			boolean flag=true;
			if(user.equalsIgnoreCase("variablePercentage")){			
				String percentageAttribute=getAttribute(ElsevierObjects.Evolve_Admin_Prmlnk_DscSel, "title", "");
				System.out.println(percentageAttribute);

				type(ElsevierObjects.Evolve_Admin_Ecom_DMCodeTxtBox, DMcode, "Enter DM Code");
				selectByValue(ElsevierObjects.Evolve_Admin_Prmlnk_DscSel, DiscountType2, "Select Discount Type");
				type(ElsevierObjects.Evolve_Admin_Prmlnk_PrmName, PromotionName, "Enter Promotion Name");
				type(ElsevierObjects.Evolve_Admin_Prmlnk_TerritoryCode, TerritoryCode, "Enter territory Code");
				click(ElsevierObjects.Evolve_Admin_Prmlnk_ClkCalender, "Click on Calendar");
				click(ElsevierObjects.Evolve_Admin_Ecom_ClkDate, "Click on the current date");
				//type(ElsevierObjects.Evolve_Admin_Prmlnk_Percentage, PercentageOff, "Enter the Percentage");
				click(ElsevierObjects.Evolve_Admin_Prmlnk_SaveBtn, "Click on Save Button");
				verifyText(ElsevierObjects.Evolve_Admin_Prmlnk_SucMsg, "Promotion successfully saved. ", "Success Message");
			}
			else{
				if(user.equalsIgnoreCase("singlePercentage")){
					String percentageAttribute=getAttribute(ElsevierObjects.Evolve_Admin_Prmlnk_DscSel, "title", "");
					System.out.println(percentageAttribute);
					type(ElsevierObjects.Evolve_Admin_Ecom_DMCodeTxtBox, DMcode, "Enter DM Code");
					//selectByValue(ElsevierObjects.Evolve_Admin_Prmlnk_DscSel, DiscountType1, "Select Discount Type");
					type(ElsevierObjects.Evolve_Admin_Prmlnk_PrmName, PromotionName, "Enter Promotion Name");
					type(ElsevierObjects.Evolve_Admin_Prmlnk_TerritoryCode, TerritoryCode, "Enter territory Code");
					click(ElsevierObjects.Evolve_Admin_Prmlnk_ClkCalender, "Click on Calendar");
					click(ElsevierObjects.Evolve_Admin_Ecom_ClkDate, "Click on the current date");
					type(ElsevierObjects.Evolve_Admin_Prmlnk_Percentage, PercentageOff, "Enter the Percentage");
					click(ElsevierObjects.Evolve_Admin_Prmlnk_SaveBtn, "Click on Save Button");
					verifyText(ElsevierObjects.Evolve_Admin_Prmlnk_SucMsg, "Promotion successfully saved. ", "Success Message");

				}

			}
			return flag;			
		}catch(Exception e){return false;}
	}



	/*//Common Logic for 9804,9805,9806,15575,15576,15577,15578,15579......
	public static boolean receiptPage() throws Throwable{
		boolean flag=true;
		Thread.sleep(medium);
		productType=getText(ElsevierObjects.ProductType,"Get product type");
		lmsTextinReceiptPage=getText(ElsevierObjects.lmsTitleInReceiptPage, "Get lms text in receipt page.");
		PriceinReceiptPage=getText(ElsevierObjects.evolve_Receipt_chkprice,"Price in Receipt page");
		if(lmsTextinReceiptPage.contains(values.get("verifyLms")) && PriceinReceiptPage.equals(ExpectedPrice) ){
			instructorLogout();
		}
		return flag;
	}
	 */
	//Credit Card Details
	public static boolean creditCardDetails(By creditCardClick) throws Throwable{
		boolean flag = true;
		try{
			if(!selectByVisibleText(ElsevierObjects.creditCard_form,tc_8564.get("student_CardType")/*readcolumns.twoColumns(0, 1, 11, configProps.getProperty("TestData")).get("student_CardType")*/ ," Clicked on CreditCard type visa")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.CreditCardNum, tc_8564.get("student_CardNum")/*readcolumns.twoColumns(0, 1, 11, configProps.getProperty("TestData")).get("student_CardNum")*/, "Credit Card Num")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.CreditCardCvv, tc_8564.get("student_CardCvv")/* readcolumns.twoColumns(0, 1, 11, configProps.getProperty("TestData")).get("student_CardCvv")*/, "Credit Card Cvv")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.CreditCardName,tc_8564.get("studentCardName")/*readcolumns.twoColumns(0, 1, 11, configProps.getProperty("TestData")).get("studentCardName")*/, "Card Name")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!selectByVisibleText(ElsevierObjects.CreditCardMonth, tc_8564.get("CreditCardMonth")/*readcolumns.twoColumns(0, 1, 11, configProps.getProperty("TestData")).get("CreditCardMonth")*/ ," Select Month")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!selectByVisibleText(ElsevierObjects.CreditCardyear, tc_8564.get("CreditCardYear")/*readcolumns.twoColumns(0, 1, 11, configProps.getProperty("TestData")).get("CreditCardYear")*/ ," Select Year")){
				flag = false;
			}
			Thread.sleep(medium);
			if(click(creditCardClick, "Credit Card Submit")){
				Reporters.SuccessReport("Click on save button and validate the New Credit Card info displays properly on Review and Submit page.", "Successfully Clicked on save button and validated the New Credit Card info displays properly on Review and Submit page. <br> The Credit Card info : <br> "
						+ "Credit Card Type is : "+tc_8564.get("student_CardType")+"<br>Credit Card Number : "+tc_8564.get("student_CardNum")+"<br>Credit Card CVV : "+tc_8564.get("student_CardCvv")+"<br> Credit Card Name : "+tc_8564.get("studentCardName")+"<br> Credit Card Exp. Month and Exp. Year : "+tc_8564.get("CreditCardMonth")+":" +tc_8564.get("CreditCardYear"));
			}else{
				Reporters.failureReport("Click on save button and validate the New Credit Card info displays properly on Review and Submit page.", "Failed to Click on save button and validated the New Credit Card info displays properly on Review and Submit page. ");
			}

			Thread.sleep(medium);
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
		//ElsevierObjects.CreditCardSubmit
	}



	//E Commerce Products Exclusions

	public static boolean verifyTextForExcludeProducts(By pkgTab, By reference, By text, By trade, By annual,By pkgSucMsg) throws Throwable{

		boolean flag=true;
		try{
			if(!isElementPresent(pkgTab,"Exclude product Package Tab", driver.getCurrentUrl())){
				flag = false;
			}
			Thread.sleep(low);
			if(!isElementPresent(reference,"Reference check box", driver.getCurrentUrl())){
				flag = false;
			}
			Thread.sleep(low);
			if(!isElementPresent(text,"Text check box", driver.getCurrentUrl())){
				flag = false;
			}
			Thread.sleep(low);
			if(!isElementPresent(trade,"Trade check box", driver.getCurrentUrl())){
				flag = false;
			}
			Thread.sleep(low);
			if(!isElementPresent(annual,"Annual check box", driver.getCurrentUrl())){
				flag = false;
			}
			if(!click(reference,"click on Reference check box")){
				flag = false;
			}
			Thread.sleep(low);
			if(!click(trade,"click on Trade check box")){
				flag = false;
			}
			Thread.sleep(low);
			String sucMsg=getText(pkgSucMsg, "");
			if(verifyText(pkgSucMsg, "The promotion text reference trade is updated successfully.", driver.getCurrentUrl())){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
			}

			Thread.sleep(low);
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}	

	//Validating the background color of a table
	public static boolean verifyBackGroundColor(By locator) throws Throwable{
		boolean flag=true;
		try{
			String backGroundColor=getAttribute(locator, "bgcolor", "Get background color");
			if(!backGroundColor.contains("#00000")){
				Reporters.SuccessReport("Varify whether The selected inclusion will be listed in the colored area", "The selected inclusion is added to the list in the colored area");
			}else{
				Reporters.failureReport("Varify whether The selected inclusion will be listed in the colored area", "The selected inclusion is failed to add to the list in the colored area");
			}
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}
	public static boolean  adminProductsearchResultDaysTable() throws Throwable

	{
		try

		{
			boolean flag = true;

			List<WebElement> AllTitlesfromapplication = driver.findElements(By.xpath(".//*[@id='faculty-production']//span[@class='middle']//input"));
			int totalResults=AllTitlesfromapplication.size();
			System.out.println(totalResults);
			for(int i=0;i<totalResults;i++)
			{
				WebElement Appdatavalues=AllTitlesfromapplication.get(i);
				daysData=Appdatavalues.getAttribute("value");
				System.out.println("The Text values are :"+daysData);
			}

			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}

	/**Generic method for maintain product link click and searchnig for ISBN
	 *
	 * @param iSBN
	 */

	public static boolean maintainProductLink(String iSBN) throws Throwable{
		boolean flag = true;
		try{
			click(ElsevierObjects.admin_MaintainProduct_lnk,"click on maintain product link");
			Thread.sleep(medium);
			type(ElsevierObjects.admin_MaintainProduct_Knotxt,iSBN,"Enter Kno number in product page");
			Thread.sleep(medium);
			click(ElsevierObjects.admin_MaintainProduct_Submit,"Click on search button");
			Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e);
			flag=false;
		}

		return flag;
	}





	/** Enter value in Search text box and click on Go. 
	 * @param By searchLocator, By goLocator, String searchData
	 * @return
	 * @throws Throwable
	 */

	public static boolean searchAndGo(String searchData) throws Throwable{
		flag = true;
		try{
			if(type(ElsevierObjects.Admin_Evolve_Ecom_HeadSearch, searchData, "Search for Product")){
				Reporters.SuccessReport("Input the search Data", "Successfully Entered the data into the search box. <br> The Search Data is : "+searchData);
			}else{
				Reporters.failureReport("Input the search Data", "Failed to Enter the data into the search box. <br> The Search Data is : "+searchData);
			}
			if(click(ElsevierObjects.Admin_Evolve_Ecom_HeadSearchGo, "Click on Go Button")){
				Reporters.SuccessReport("Click on the Go Button to search the Product", "Successfully Clicked on the Go Button to search the Product");
			}else{
				Reporters.failureReport("Click on the Go Button to search the Product", "Failed to Click on the Go Button to search the Product");
			}

			Thread.sleep(medium);		
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	//New Registration form for Both FACULTY And STUDENT
	public static boolean registrationForm() throws Throwable{

		boolean flag = true;
		try{
			if(!type(ElsevierObjects.evolve_newAccount_firstname,tcVST_KNO.get("user_firstname")/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_firstname")*/,"First Name")){
				flag=false;
			}
			if(!type(ElsevierObjects.evolve_newAcount_Lastname,tcVST_KNO.get("user_lastname")/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_lastname")*/,"Last Name")){
				flag=false;
			}
			Random ra = new Random( System.currentTimeMillis() );
			Date today = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat ("MMddyyyy");
			StdEmail = tcVST_KNO.get("user_email")/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_email")*/+Integer.toString((1 + ra.nextInt(2)) * 10000 + ra.nextInt(10000)) + sdf.format(today) + "@evolveqa.info";


			//ReadingExcel.updateCellValue(3, 1, configProps.getProperty("TestData"), 15);
			if(!type(ElsevierObjects.evolve_newAcount_Email, StdEmail ,"Email")){
				flag=false;
			}
			if(!type(ElsevierObjects.evolve_newAcount_Pwd, tcVST_KNO.get("user_pwd")/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_pwd")*/,"Password")){
				flag=false;
			}
			if(!type(ElsevierObjects.evolve_newAcount_ConfirmPwd,tcVST_KNO.get("user_pwd")/*readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_pwd")*/,"Confirm Password")){
				flag=false;
			}
			if(isChecked(ElsevierObjects.evolve_newAcount_Chkbx, "Check box")){
				if(!click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
					flag=false;
				}
				Thread.sleep(veryhigh);
			}
			else{
				if(!click(ElsevierObjects.evolve_newAcount_Chkbx,"Click chk box")){
					flag=false;
				}
				if(!click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
					flag=false;
				}
				Thread.sleep(veryhigh);
			}

			Thread.sleep(veryhigh);
			capturCredentials();

			Thread.sleep(high);
			if(!click(ElsevierObjects.newAccount_contiue_btn,"Continue button")){
				flag=false;
			}
			Thread.sleep(high);
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;

	}


	/*//New Registration form for Both FACULTY And STUDENT
	public static boolean registrationForm() throws Throwable{

		boolean flag = true;
		try{
			if(!type(ElsevierObjects.evolve_newAccount_firstname,tcVST_KNO.get("user_firstname")readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_firstname"),"First Name")){
				flag=false;
			}
			if(!type(ElsevierObjects.evolve_newAcount_Lastname,tcVST_KNO.get("user_lastname")readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_lastname"),"Last Name")){
				flag=false;
			}
			Random ra = new Random( System.currentTimeMillis() );
			StdEmail = tcVST_KNO.get("user_email")readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_email")+Integer.toString((1 + ra.nextInt(2)) * 10000 + ra.nextInt(10000))+"@evolveqa.info";


			//ReadingExcel.updateCellValue(3, 1, configProps.getProperty("TestData"), 15);
			if(!type(ElsevierObjects.evolve_newAcount_Email, StdEmail ,"Email")){
				flag=false;
			}
			if(!type(ElsevierObjects.evolve_newAcount_Pwd, tcVST_KNO.get("user_pwd")readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_pwd"),"Password")){
				flag=false;
			}
			if(!type(ElsevierObjects.evolve_newAcount_ConfirmPwd,tcVST_KNO.get("user_pwd")readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("user_pwd"),"Confirm Password")){
				flag=false;
			}
			if(isChecked(ElsevierObjects.evolve_newAcount_Chkbx, "Check box")){
				if(!click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
					flag=false;
				}
			}
			else{
				if(!click(ElsevierObjects.evolve_newAcount_Chkbx,"Click chk box")){
					flag=false;
				}
				if(!click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
					flag=false;
				}

			}

			Thread.sleep(veryhigh);
			capturCredentials();

			Thread.sleep(high);
			if(!click(ElsevierObjects.newAccount_contiue_btn,"Continue button")){
				flag=false;
			}
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;

	}
	 */
	/** Click on Enroll-in- your instructors course button and search for instructors course id  
	 * @param courseid
	 * @return
	 * @throws Throwable
	 */

	public static boolean clickEnrollCourse(String courseid) throws Throwable{
		flag = true;
		try{
			if(!click(ElsevierObjects.enrollCourse, "Click on Enroll Button")){
				Thread.sleep(medium);
				flag = false;
			}
			Thread.sleep(300);

			if(!type(ElsevierObjects.enrollResourceId, courseid, "Input Course Id ")){
				Thread.sleep(medium);
				flag = false;
			}

			if(!click(ElsevierObjects.enrollContinue, "Click on Continue Button")){
				Thread.sleep(medium);
				flag = false;
			}

			Thread.sleep(medium); 
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}
	public static boolean launchUrl_AddToCart(String uniqueURL) throws Throwable{
		boolean flag=true;
		try{
			Thread.sleep(medium);
			driver.navigate().to("http://"+uniqueURL);
			if(uniqueURL!=null){
				Reporters.SuccessReport("Launch the Unique URL and Validate the products", "Successfully launched unique URL : "+uniqueURL);
			}else{
				Reporters.failureReport("Launch the Unique URL and Validate the products", "Failed to launch unique URL : "+uniqueURL);
			}
			/*if(!launchUrl(uniqueURL)){
			flag = false;
		}*/
			//System.out.println(UniqueURL);
			String sucMsg=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrPageTitleVfyTxt, "");
			if(verifyText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrPageTitleVfyTxt, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("PageTitle"), "Page Title Verification is successfull")){
				Reporters.SuccessReport("The header Page title Validation", "The Header Page title : "+sucMsg+" is displayed");	
			}else{
				Reporters.failureReport("The header Page title Validation", "The Header Page title : "+sucMsg+" is failed to display");
			}
			String sucMsg1=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrPageBodyVfyTxt, "");
			if(verifyText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_HdrPageBodyVfyTxt, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("pageBody"), "Page Body Verification is successfull")){
				Reporters.SuccessReport("The header Page Body Validation", "The Header Page Body : "+sucMsg1+" is displayed");	
			}else{
				Reporters.failureReport("The header Page Body Validation", "The Header Page Body : "+sucMsg1+" is failed to display");
			}	
			String sucMsg2=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_TitleVrfy, "");
			if(verifyText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_TitleVrfy, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("TitleCrossPromote"), "Page title Verification is successfull")){
				Reporters.SuccessReport("The Cross Promote Page title Validation", "Cross Promote Page Page title : "+sucMsg2+" is displayed");	
			}else{
				Reporters.failureReport("The Cross Promote Page title Validation", "Cross Promote Page Page title : "+sucMsg2+" is failed to display");
			}
			String sucMsg3=getText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_DescVrfy, "");
			if(verifyText(ElsevierObjects.Admin_Evolve_Ecom_MrkPgeTab_CrsPrm_DescVrfy, readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("BodyCrossPromote"), "Page Body Verification is successfull")){
				Reporters.SuccessReport("The Cross Promote Page Body Validation", "Cross Promote Page Body : "+sucMsg3+" is displayed");	
			}else{
				Reporters.failureReport("The Cross Promote Page Body Validation", "Cross Promote Page Body : "+sucMsg3+" is failed to display");
			}
			Thread.sleep(medium);
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

	/** Convert the Price value to float. 
	 * @param By Locator
	 * @return
	 * @throws Throwable
	 */
	public static float convertPrice(By Locator) throws Throwable{
		flag=true;
		String price=getText(Locator, "Get Price from the package ");
		String priceReplace=price.replace("$", "");
		float totalPrice=Float.parseFloat(priceReplace);
		return totalPrice;
	}


	/** Convert the Price value to float. 
	 * @param By Locator
	 * @return
	 * @throws Throwable
	 */
	public static float convertStringToPrice(String price) throws Throwable{
		flag=true;

		String priceReplace=price.replace("$", "");
		float totalPrice=Float.parseFloat(priceReplace);
		return totalPrice;
	}

	/**Generic method for searching adoption by Adoption Number in Admin page
	 * 
	 * @return
	 * @throws Throwable
	 */
	public static boolean searchAdoptionByAdoptionNumber(String adoptionNumber) throws Throwable{
		boolean flag=true;
		type(ElsevierObjects.Admin_searchAdoptionByNumber, adoptionNumber, "Enter Adoption Number.");
		click(ElsevierObjects.Admin_searchAdoptionButton,"click Adoption search search button");
		Thread.sleep(medium);
		return flag;
	}

	public static boolean productSearch(String SearchValue) throws Throwable
	{
		try

		{
			boolean flag = true;
			type(ElsevierObjects.Hesi_Search,SearchValue,"Entering the value to be searched");
			click(ElsevierObjects.Hesi_Go, "Clicking on Go button");
			Thread.sleep(medium);

			waitForVisibilityOfElement(ElsevierObjects.SortyByRelevance, "");
			String str = driver.findElement(ElsevierObjects.SortyByRelevance).getAttribute("checked");
			if (str.equalsIgnoreCase("true"))
			{
				System.out.println("Checkbox selected");
			}
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}

	public static boolean clickDVDHardcover() throws Throwable{
		boolean flag=true;
		try{
			click(ElsevierObjects.marketingPageSinglePercentage_DvdType, "Check the checkbox DVD Type");

			Thread.sleep(medium);
			click(ElsevierObjects.marketingPageSinglePercentage_HardcoverType, "Click on the Checkbox HardCover Type");
			Thread.sleep(medium);
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}
	public static boolean productClick() throws Throwable
	{
		try
		{
			boolean flag = true;
			int counter=0;
			int itemCount=0;
			String pageCount=getAttribute(ElsevierObjects.marketingPageSinglePercentage_PrmPgeCount, "value", "");
			int pages=Integer.parseInt(pageCount);
			boolean nextPage=true; 
			for (int i = 0; i < pages+1; i++) {

				Thread.sleep(medium);
				List<WebElement> ele=driver.findElements(ElsevierObjects.marketingPageSinglePercentage_PrmPgeLnk);
				ele.get(i).click();
				Thread.sleep(medium);
				try{
					if(isElementPresentNegCheck(ElsevierObjects.marketingPageSinglePercentage_DvdSearch, "")){
						List<WebElement> element1=driver.findElements(ElsevierObjects.marketingPageSinglePercentage_DvdSearch);
						int size=element1.size();
						itemCount=size;

						for (int j = 0; j < size; j++) {						
							List<WebElement> element2=driver.findElements(ElsevierObjects.marketingPageSinglePercentage_DvdSearch);
							element2.get(j).click();
							Thread.sleep(medium);
							if(isElementPresentNegCheck(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomAddtoCart, "Add to Cart")){

								counter=counter+1;
								titleisbn=getText(ElsevierObjects.marketingPageSinglePercentage_Title, "Get the title of the Book");
								System.out.println(titleisbn);
								titleforuse1.add(titleisbn);								
								ISBN=getText(ElsevierObjects.marketingPageSinglePercentage_ISBN, "Get the ISBN Value for future Use");
								System.out.println(ISBN);
								isbn1.add(ISBN);
								price=getText(ElsevierObjects.marketingPageSinglePercentage_Price, "Get the Price of the Book");
								System.out.println(price);
								price1.add(price);
								//Reporters.SuccessReport("The DVD Product with ISBN : "+isbn1.get(j)+ " is having ADD TO CART Button", "The DVD Product : "+isbn1.get(j)+ " is having ADD TO CART Button");
								driver.navigate().back();
								Thread.sleep(medium);
								if(counter==4){
									nextPage=false;
									break;
								}
							}else{
								Reporters.failureReport("The DVD Product : "+isbn1.get(j)+ " is having ADD TO CART Button", "The DVD Product : "+isbn1.get(j)+ " is having ADD TO CART Button");
								driver.navigate().back();
								Thread.sleep(medium);
							}

						}
					}else{
						continue;
					}
				}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

				if(!nextPage){	
					break;}
				/*if(condition.equalsIgnoreCase("true")){
				for (i = 0; i < element.size(); i++) {
					element.get(i).click();
					if(isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomAddtoCart, "Add to Cart")){
						driver.navigate().back();	
						int j=i+1;
						List<WebElement> element1=driver.findElements(ElsevierObjects.marketingPageSinglePercentage_DvdSearch);
						element1.get(j).click();
						//WebElement ele=element.get(i+1);
						//String elementt=ele.getText();
						//ele.click();
						//click(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomAddtoCart, "Click on Add to Cart Button");
						break;
					}else{
						driver.navigate().back();
						Thread.sleep(medium);
						continue;
						element.get(i+1).click();
						if(isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomAddtoCart, "Add to Cart")){
							click(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomAddtoCart, "Click on Add to Cart Button");
							continue;
						}
					}
				}
			}*/
				/*driver.navigate().back();	
			List<WebElement> element1=driver.findElements(ElsevierObjects.marketingPageSinglePercentage_DvdSearch);
				 */

				/*	Thread.sleep(high);	
			String ele=element1.get(i).getText();
			System.out.println(ele);
			element1.get(i).click();*/

				/*if(isElementPresent(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomAddtoCart, "Add to Cart")){
				click(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomAddtoCart, "Click on Add to Cart Button");}*/
				/*title=getText(ElsevierObjects.marketingPageSinglePercentage_Title, "Get the title of the Book");
			System.out.println(title);
			ISBN=getText(ElsevierObjects.marketingPageSinglePercentage_ISBN, "Get the ISBN Value for future Use");
			System.out.println(ISBN);
			price=getText(ElsevierObjects.marketingPageSinglePercentage_Price, "Get the Price of the Book");
			System.out.println(price);*/


			}	

			System.out.println(titleforuse1);
			System.out.println(isbn1);
			System.out.println(price1);
			int sizearray=isbn1.size();

			isbnForFutureUse1=isbn1.get(0);
			isbnForFutureUse2=isbn1.get(1);
			isbnForFutureUse3=isbn1.get(2);
			isbnForFutureUse4=isbn1.get(3);

			titleforfutureuse1=titleforuse1.get(0);
			titleforfutureuse2=titleforuse1.get(1);
			titleforfutureuse3=titleforuse1.get(2);
			titleforfutureuse4=titleforuse1.get(3);

			priceforfutureuse1=price1.get(0);
			priceforfutureuse2=price1.get(1);
			priceforfutureuse3=price1.get(2);
			priceforfutureuse4=price1.get(3);

			for (int i = 0; i < 4; i++) {
				Reporters.SuccessReport("Verifying ADD TO CART Button for DVD Product : "+isbn1.get(i), "The DVD Product : "+isbn1.get(i)+ " is having ADD TO CART Button");
			}


			for (int i = 0; i < 3; i++) {
				if(isbn1.get(0).equals(isbn1.get(i+1))){
					Reporters.failureReport("The first ISBN : " +isbn1.get(0)+" Comparison with all other ISBNs ", "The first ISBN : " +isbn1.get(i+1)+" Comparing with Next ISBN element ie:  "+isbn1.get(i+1)+ "</br> The 1st ISBN is same which results in the test step failure  ");
				}else{
					Reporters.SuccessReport("The first ISBN : " +isbn1.get(0)+" Comparison with all other ISBNs ", "The first ISBN : " +isbn1.get(0)+" Comparing with Next ISBN element ie:  "+isbn1.get(i+1)+ "</br> The 1st ISBN is Not same which results in the test step Pass  ");
				}
			}



			//Reporters.SuccessReport("Total No. of DVD Products with ADD TO CART Button", "The available DVD products with Add to Cart button are "+titleforuse1.size());
			//Reporters.SuccessReport("Total No. of DVD Products with ADD TO CART Button", "The available DVD products with Add to Cart button are "+titleforuse1.size());
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}

	public static boolean checkPromotionLink() throws Throwable
	{
		try

		{
			boolean flag = true;
			if(click(ElsevierObjects.marketingPageSinglePercentage_PrmPgeGlobalLink, "Click on the Global Promotion Link")){
				Reporters.SuccessReport("Click on the Global Promotion Link", "Successfully Click on the 'Global Promotion Exclusions' under the 'Promotion Management' Section and navigated to the next page : "+driver.getCurrentUrl());		
			}else{
				Reporters.failureReport("Click on the Global Promotion Link", "Failed to Click on the 'Global Promotion Exclusions' under the 'Promotion Management' Section");
			}
			Thread.sleep(medium);
			if(isElementPresentNegCheck(ElsevierObjects.marketingPageSinglePercentage_PrmPgeRemoveISBNLink, "")){
				List<WebElement> removeLink=driver.findElements(ElsevierObjects.marketingPageSinglePercentage_PrmPgeRemoveISBNLink);
				for(WebElement ele: removeLink){
					ele.click();
					Thread.sleep(medium);
					Alert();
					Reporters.SuccessReport("All Global Exclusions are successfully removed from the list ", "There are now no global exclusions set up in Cert.");
					System.out.println("ISBN Product is successfully removed from the list : "+ ele.getText());
				}
			}else{
				System.out.println("No ISBNs are present to remove");
				Reporters.SuccessReport("No ISBNs are present to remove in Global Promotions Exclusions", "No ISBNs are present to remove from the table in Global Promotions Exclusions");
			}
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}

	public static boolean ISBNExcludeGlobalPromotion(String isbn) throws Throwable
	{
		try
		{
			boolean flag = true;
			//type(ElsevierObjects.GlobalPromotionLink_ISBNTextBox, isbn, "");

			if(type(ElsevierObjects.GlobalPromotionLink_ISBNTextBox, isbn, "Enter the ISBN to Exclude")){
				Reporters.SuccessReport("ISBN Id : "+isbn+" is added to the isbn textbox", "The ISBN : "+isbn+" is now shown in the ISBN exclusion list to the right");		
			}else{
				Reporters.failureReport("ISBN Id : "+isbn+" is unable to type", " The ISBN : "+isbn+" is failed to show in the ISBN exclusion list to the right");
			}


			Thread.sleep(medium);
			click(ElsevierObjects.GlobalPromotionLink_ISBNBtn, "Click on the exclude button");
			Thread.sleep(medium);
			verifyText(ElsevierObjects.GlobalPromotionLink_ISBNSucMsg, "The Promotion Exclusion is successfully saved. ", "The Promotion Exclusion is successfully saved.");
			//isElementPresent(ElsevierObjects.GlobalPromotionLink_ISBNTable, "Global Promotion Table", driver.getCurrentUrl());

			return flag;
		}catch(Exception e){
			sgErrMsg=e+" is Failed due to this exception";return false;}

	}


	
	public static boolean ISBNExclude(String variablePercentage) throws Throwable
	{
		try
		{
			boolean flag = true;

			String isbn4=isbnForFutureUse4;

			type(ElsevierObjects.Evolve_Admin_Prmlnk_ISBNtxt, isbn4, "Enter the ISBN to Include");
			Thread.sleep(medium);
			type(ElsevierObjects.Evolve_Admin_Prmlnk_ISBNpercent, variablePercentage, "Enter the percentage to Exclude");
			click(ElsevierObjects.Evolve_Admin_Prmlnk_ISBNAdd, "Click on the exclude button");
			Thread.sleep(medium);
			verifyText(ElsevierObjects.Evolve_Admin_Prmlnk_IncSucMsg, "The Promotion Inclusion is successfully saved. ", "The Promotion Inclusion is successfully saved. ");
			Thread.sleep(medium);
			isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplbefore, "Verify the element present");
			List<WebElement> product=driver.findElements(ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplbefore);
			for(WebElement item: product){
				if(item.getText().contains("50% off")){
					Reporters.SuccessReport("The table shows in the ISBN inclusion list", "The table shows in the ISBN inclusion list with 50% off to the right");
				}else{
					continue;
					//System.out.println("");
				}
			}
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}
	
	

	public static boolean globalPromotionDVD(String user, String percentageDVD) throws Throwable
	{
		try

		{
			boolean flag = true;
			if(user.equalsIgnoreCase("singlePercentage")){

				click(ElsevierObjects.marketingPageSelDVD, "Select the product DVD");
				Thread.sleep(1500);
				click(ElsevierObjects.Evolve_Admin_Prmlnk_PrdAdd, "Click on the Add button to add the product");
				verifyText(ElsevierObjects.Evolve_Admin_Prmlnk_IncSucMsg, "The Promotion Inclusion is successfully saved. ", "The promotion saved successfully");
				List<WebElement> element=driver.findElements(ElsevierObjects.marketingPageSinglePercentage_PrmPge_tableRow);
				for(WebElement s:element){
					String s1=s.getText();
					System.out.println(s1);
				}
				String s1="remove";
				String s2="DVD";

				if(element.get(0).getText().contains(s1)){
					Reporters.SuccessReport("The Row Contains : " +s1+ "button for each inclusion added", "The Inclusion is added successfully and Row Contains : "+s1+ " Link for each inclusion");
				}else{
					Reporters.failureReport("The Row doesnot Contains : " +s1+ "button for each inclusion added", "The Inclusion is not added and Row doesnot Contains : "+s1+ " Link ");
				}
				if(element.get(0).getText().contains(s2)){
					Reporters.SuccessReport("The Row Contains : " +s2, "The Row Contains : "+s2+ " Text");
				}else{
					Reporters.failureReport("The Row Contains : " +s2, "The Row Contains : "+s2+ " Text");
				}
			}else{
				if(user.equalsIgnoreCase("variablePercentage")){
					click(ElsevierObjects.marketingPageSelDVD, "Select the product DVD");
					type(ElsevierObjects.Evolve_Admin_Prmlnk_PrdPerFld, percentageDVD, "Enter the Percentage value");
					click(ElsevierObjects.Evolve_Admin_Prmlnk_PrdAdd, "Click on the Add button to add the product");
					verifyText(ElsevierObjects.Evolve_Admin_Prmlnk_IncSucMsg, "The Promotion Inclusion is successfully saved. ", "The promotion saved successfully");
					List<WebElement> element=driver.findElements(ElsevierObjects.marketingPageSinglePercentage_PrmPge_tableRow);
					String s1="remove";
					String s2="DVD";
					String s3="10% off";
					if(element.get(0).getText().contains(s1)){
						Reporters.SuccessReport("The Row Contains : " +s1, "The Row Contains : "+s1+ " Link");
					}else{
						Reporters.failureReport("The Row Contains : " +s1, "The Row Doesn't Contains : "+s1+ " Link");
					}
					if(element.get(0).getText().contains(s2)){
						Reporters.SuccessReport("The Row Contains : " +s2, "The Row Contains : "+s2+ " Text");
					}else{
						Reporters.failureReport("The Row Contains : " +s2, "The Row Contains : "+s2+ " Text");
					}
					if(element.get(0).getText().contains(s3)){
						Reporters.SuccessReport("The Row Contains : " +s3, "The Row Contains : "+s3+ " Text");
					}else{
						Reporters.failureReport("The Row Contains : " +s3, "The Row Contains : "+s3+ " Text");
					}
				}
			}
			return flag;
		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}

	}

	public static boolean viewMarketingPage() throws Throwable
	{
		boolean flag = true;
		try
		{
			click(ElsevierObjects.marketingPageSinglePercentage_ViewMarketingPageLink, "Click on the View Marketing Page Link on the top right portion of the page");
			String breadCrumb=getText(ElsevierObjects.marketingPageSinglePercentage_ViewMarketingPageBreadCrumb, "Getting the text for BreadCrumb");
			if(breadCrumb.contains("Evolve Admin > Maintain Promotions > Active Promotions > Edit Promotion > Promotion Marketing Page")){
				Reporters.SuccessReport("Click on the View Marketing Page Link", "Bread Crumb : "+breadCrumb+ " is present");
			}else{
				Reporters.failureReport("Click on the View Marketing Page Link", "Bread Crumb : "+breadCrumb+ " is not present");
			}
			//isElementPresent(ElsevierObjects.marketingPageSinglePercentage_ViewMarketingPageBreadCrumb, "Bread Crumb is present",driver.getCurrentUrl());
			String user1="promotionCreateMarketingSinglePercentage";
			marketingPageBookDetails(ElsevierObjects.marketingPageISBNTextBox, isbnForFutureUse3, ElsevierObjects.marketingPageISBNAddBtn, ElsevierObjects.marketingPageISBNtableContent, user1);
			System.out.println("");
			//Click on save and publish
			verifyUniqueurl();
			String user="singlePercentage";
			String checkbox="";
			crossPromoteItems(user,checkbox);
			String uniqueUrl=EvolveCommonBussinessFunctions.UniqueURL;


		}catch(Exception e){sgErrMsg=e+" is Failed due to this exception";return false;}
		return flag;
	}

	public static boolean detailsForFutureUse()throws Throwable{
		boolean flag=true;
		uniqueUrl=EvolveCommonBussinessFunctions.UniqueURL;
		System.out.println("Unique URL is : "+uniqueUrl);
		isbnForFutureUse1=isbn1.get(0);
		System.out.println("ISBN#1 is : "+isbnForFutureUse1);
		isbnForFutureUse2=isbn1.get(1);
		System.out.println("ISBN#2 is : "+isbnForFutureUse2);
		isbnForFutureUse3=isbn1.get(2);
		System.out.println("ISBN#3 is : "+isbnForFutureUse3);
		isbnForFutureUse4=isbn1.get(3);
		System.out.println("ISBN#4 is : "+isbnForFutureUse4);

		titleforfutureuse1=titleforuse1.get(0);
		System.out.println("Title#1 is : "+titleforfutureuse1);
		titleforfutureuse2=titleforuse1.get(1);
		System.out.println("Title#2 is : "+titleforfutureuse2);
		titleforfutureuse3=titleforuse1.get(2);
		System.out.println("Title#3 is : "+titleforfutureuse3);
		titleforfutureuse4=titleforuse1.get(3);
		System.out.println("Title#4 is : "+titleforfutureuse4);

		priceforfutureuse1=price1.get(0);
		System.out.println("Price#1 is : "+priceforfutureuse1);
		priceforfutureuse2=price1.get(1);
		System.out.println("Price#2 is : "+priceforfutureuse2);
		priceforfutureuse3=price1.get(2);
		System.out.println("Price#3 is : "+priceforfutureuse3);
		priceforfutureuse4=price1.get(3);
		System.out.println("Price#4 is : "+priceforfutureuse4);

		return flag;
	}

	/**Generic method for click on course PAR Report and search for course id
	 *
	 * @param iSBN
	 */
	public static boolean verifyCoursePARReport(String courseid) throws Throwable{
		boolean flag = true;

		if(!click(ElsevierObjects.lnkcoursePARReport, "Click on course PAR Report link")){
			flag = false;
		}
		Thread.sleep(medium);

		driver.findElement(ElsevierObjects.txtcoursid).sendKeys(courseid);

		//if(!type(ElsevierObjects.txtcoursid, courseid, "Input course id")){
		//	flag = false;
		//}
		Thread.sleep(medium);

		if(!click(ElsevierObjects.btncoursego, "Click on Go button")){
			flag = false;
		}
		Thread.sleep(medium);

		Map<String, String> values=readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData"));
		String userName=values.get("UserName");

		String str=getText(ElsevierObjects.enrollLONewUser, "");
		//verify username exists
		if(!str.equals(userName)){
			flag = false;
		}

		return flag;
	}



	/*public static boolean isElementPresent(By by, String locatorName)
			throws Throwable {
		boolean flag=false;	
		try {
			driver.findElement(by);
			flag = true;
			return true;
		} catch (Exception e) {

			System.out.println(e.getMessage());
			return false;
		}finally{
			if(flag){

			}
		}
	}*/
	/**Generic Method For Deleting item From Cart
	 * 
	 * @return
	 * @throws Throwable
	 */
	public static boolean deleteCart() throws Throwable{
		boolean flag=true;
		try{

			click(ElsevierObjects.Catalog_Header_Link, "Click on Catalog");
			click(ElsevierObjects.CART, "");
			if(isElementPresentNegCheck(ElsevierObjects.CARTDELETE,"Verify Delete Element present.")){
				List<WebElement> delete=driver.findElements(ElsevierObjects.CARTDELETE);
				for(WebElement d: delete){
					d.click();
				}
				driver.navigate().back();
				//click(ElsevierObjects.Myevolve,"click on MyEvolve link");
			}
			else{
				click(ElsevierObjects.Myevolve,"click on MyEvolve link");

			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	/**Genaric Method for getting user details from MyAccount
	 * 
	 * @return
	 * @throws Throwable
	 *//*
	//Common Logic for 9804,9805,9806,15575,15576,15577,15578,15579......
	public static boolean getAccountDetails() throws Throwable{
		boolean flag=true;

		try{


			if(!click(ElsevierObjects.myAccount,"click on my account")){
				flag=false;
			}
			Thread.sleep(high);
			if(!click(ElsevierObjects.myAccount_AccountSettings,"click on account settings.")){
				flag=false;
			}
			Thread.sleep(medium);
			//String firstName=getText(ElsevierObjects.educator_form_txtFirstName, "Get first name");
			getAccountDetailsUserName=getAttribute(ElsevierObjects.educator_form_UserName, "value", "Get first name");
			getAccountDetailsFirstName=getAttribute(ElsevierObjects.educator_form_txtFirstName, "value", "Get first name");
			getAccountDetailsLastName=getAttribute(ElsevierObjects.educator_form_txtLastName,"value","Get Last Name");
			getAccountDetailsEmail=getAttribute(ElsevierObjects.educator_form_txtEmail,"value","Get email id.");
			getAccountDetailsInstitution=getAttribute(ElsevierObjects.educator_form_txtInstution, "value","Get Institution name");

			getAccountDetailsPhone=getAttribute(ElsevierObjects.educator_form_txtAddPhone,"value","Get phone number");
			getAccountDetailsStreetAddress=getAttribute(ElsevierObjects.educator_form_txtAddress,"value", "Get Street Adress");
			getAccountDetailsCountry=getText(ElsevierObjects.educator_form_ddInstutionCountry, "Get country of institution.");			
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}*/
	/**Generic method for Search Product.
	 * 
	 * @param product
	 * @param productCost
	 * @return
	 * @throws Throwable
	 */
	public static boolean searchProduct(String product, String productCost) throws Throwable
	{  
		boolean flag=true;
		try { 

			Thread.sleep(medium);

			if(!click(ElsevierObjects.evolveCatlog_lnk, "Click 'Evolve Catalog' link.")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.evolve_Serach_txt, product, "Search for product : "+product)){
				flag = false;
			}

			if(!click(ElsevierObjects.gobutton, "search button")){
				flag = false;
			}
			Thread.sleep(medium);

			/*if(!(getText(ElsevierObjects.Student_Product_Cost, "Get Product Cost").equals(productCost))){
				flag = false;
			}*/
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	//Common Logic for 9804,9805,9806,15575,15576,15577,15578,15579......
	/**Generic method for PopUp Handling in Request Product page. 
	 * @param lmsValue
	 * @return
	 * @throws Throwable
	 */
	public static boolean hostedAfterRequestPopUp() throws Throwable{
		boolean flag=true;
		try{

			if(!switchToFrameByLocator(ElsevierObjects.Student_register_frame, "Switch to iframe.")){
				flag=false;
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	/**Generic method for entering LMS value in Popup. 
	 * @param lmsValue
	 * @return
	 * @throws Throwable
	 */
	public static boolean lmsInPopUp(String lmsvalue) throws Throwable{
		try{
			click(ElsevierObjects.popUp_Radio_Btn,"Click on Radio Button");
			Thread.sleep(medium);
			selectByVisibleText(ElsevierObjects.popUp_dropdown,lmsvalue, "Enter Lms value.");
			click(ElsevierObjects.popUp_Apply, "Click on Apply button.");
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return true;
	}

	//Review And Submit for educator......
	public static boolean reviewAndSubmit() throws Throwable{
		boolean flag = true;
		try{

			Thread.sleep(medium);
			if(!click(ElsevierObjects.checkbox1, "registered")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.checkbox2, "instructor")){
				flag = false;
			}

			price=getText(ElsevierObjects.price, "price");
			expectedPrice="$0.00";
			Thread.sleep(medium);
			if(price.contains(expectedPrice)){
				Thread.sleep(medium);
				if(!click(ElsevierObjects.submitbutton, "submit at final")){
					flag = false;
					Thread.sleep(medium);
				}
			}

			Thread.sleep(high);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	//Login into the Admin with valid credentials
	public static boolean evolveAdminlogin() throws Throwable {
		boolean flag = true;
		try{

			if(!launchUrl(configProps.getProperty("URL2"))){
				flag = false;
			}
			Thread.sleep(high);
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			if(!waitForElementPresent(ElsevierObjects.adminemail, "UserName text box")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.adminemail, configProps.getProperty("AdminUser"),"Enter Login Name")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.adminpassword, configProps.getProperty("AdminPassword"),"Enter Login Password")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.adminlogin, "Submit")){
				flag = false;
			}
			Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;	
	}

	//Logout from Admin
	public static boolean adminLogout() throws Throwable{
		boolean flag = true;
		try{

			if(!click(ElsevierObjects.logout,"Clicked on Logout Button")){
				flag = false;
			}
			Thread.sleep(high);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	/**Generic method for Evolve Email Login
	 * 
	 * @return
	 * @throws Throwable
	 */
	public static boolean emailLogin() throws Throwable{
		boolean flag=true;
		try{
			driver.manage().deleteAllCookies();
			//driver.navigate().refresh();	
			Thread.sleep(medium);
			if(!launchUrl(configProps.getProperty("EmailURL"))){
				flag = false;
			}
			Thread.sleep(high);
			if(!type(ElsevierObjects.emailaddress,configProps.getProperty("verifyemail_username"),"Enter email id")){
				flag=false;
			}
			Thread.sleep(low);
			if(!type(ElsevierObjects.emailpassword,configProps.getProperty("verifyemail_password"),"Enter password")){
				flag=false;
			}
			Thread.sleep(low);
			if(!click(ElsevierObjects.emaillogin, "Click on Login Button.")){
				flag=false;
			}
			Thread.sleep(veryhigh);

			if(!click(ElsevierObjects.email_Icon,"Click on Email icon.")){
				flag=false;
			}
			Thread.sleep(veryhigh);
			if(!click(ElsevierObjects.email_dropdown,"Click on Dropdown.")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.email_dropdown_Fromchk,"Click on From check box.")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.email_dropdown_Tochk,"Click on To checkbox.")){
				flag=false;
			}
			Thread.sleep(veryhigh);
		}
		catch(Exception e){
			System.out.println(e.getMessage()); return false;
		}
		return flag;
	}
	//Common Logic for 9804,9805,9806,15575,15576,15577,15578,15579......
	/*public static boolean verifyDownloadURLInEmail(String downloadURL) throws Throwable{
			try{
			boolean flag=true;
			//String email=readcolumns.twoColumns(0, 1, 20, configProps.getProperty("TestData")).get("user_email");
			if(!type(ElsevierObjects.email_SearchBox,getAccountDetailsEmail,"Enter the email id.")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!javaClick(ElsevierObjects.email_SearchIcon,"Click on search icon.")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame")){
				flag=false;
			}
			Thread.sleep(medium);
			emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
			emailUrl=getText(ElsevierObjects.verifyEmailDownloadURL, "Get Url from email body.");
			System.out.println(emailUrl);
			if(emailUrl.trim().contains(downloadURL.trim())){
				if(!javaClick(ElsevierObjects.email_logout,"Click on logout.")){
					flag=false;
				}	
			}

			}
			catch(Exception e){
				System.out.println(e.getMessage());
			}
			return flag;
		}
	 */


	/*//Common Logic for 9804,9805,9806,15575,15576,15577,15578,15579......
			 public static boolean verifyDownloadURLInEmail(String downloadURL) throws Throwable{
				 boolean flag=true;
				 try{

			  //String email=readcolumns.twoColumns(0, 1, 20, configProps.getProperty("TestData")).get("user_email");

			  if(!switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame")){
			   flag=false;
			  }
			  Thread.sleep(medium);
			  emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
			  emailUrl=getText(ElsevierObjects.verifyEmailDownloadURL, "Get Url from email body.");
			  System.out.println(emailUrl);
			  if(emailUrl.trim().contains(downloadURL.trim())){
			   if(!javaClick(ElsevierObjects.email_logout,"Click on logout.")){
			    flag=false;
			    } 
			   }
			  }
			  catch(Exception e){
			   System.out.println(e.getMessage());
			  }
			  return flag;
			 }*/
	//Common Logic for 9804,9805,9806,15575,15576,15577,15578,15579......

	public static boolean evolve_StudentSearch() throws Throwable{
		boolean flag=true;
		driver.manage().deleteAllCookies();
		if(ElsevierObjects.studentBrowserType.equalsIgnoreCase("ie"))
		{
          if(!launchUrl(configProps.getProperty("URL4"))){
			flag = false;
		}
                    
		}
else{
	    if(!launchUrl(configProps.getProperty("URL"))){
			flag = false;
		}  
		Thread.sleep(medium);
		driver.manage().deleteAllCookies();
		driver.navigate().refresh();
        if(!click(ElsevierObjects.evolve_Home_Student,"i am student")){
			flag=false;
		}
    }
		return flag;
	}


	//hesi email verification


	public static boolean errorAlert() throws Throwable {
		boolean flag=false;
		// boolean presentFlag = false;
		org.openqa.selenium.Alert alert;
		String alerttext = null;
		alert = null;

		try {

			// Check the presence of alert
			alert = driver.switchTo().alert();
			// if present consume the alert

			alerttext=alert.getText();
			System.out.println(alerttext);
			alert.accept();

			//presentFlag = true;
		} catch (NoAlertPresentException ex) {
			// Alert present; set the flag

			// Alert not present
			ex.printStackTrace();
		} 
		return flag;
	}

	public static boolean verrifyStatusInEnt6x(String lmsvalue,String Status,String downloadURL,String KeyValue) throws Throwable{
		boolean flag=true;
		try{


			System.out.println("lmsvalue:"+lmsvalue);
			System.out.println("adoptionRequest_Format"+adoptionRequest_Format);
			if(getAccountDetailsFirstName.contains(adoptionRequest_FirstName) && getAccountDetailsLastName.contains(adoptionRequest_LastName) && getAccountDetailsEmail.contains(adoptionRequest_Email) && getAccountDetailsInstitution.contains(adoptionRequest_Institution) && getAccountDetailsPhone.contains(adoptionRequest_Phone) && userName.contains(adoptionRequest_Username) && password.contains(adoptionRequest_Password)){
				if(title.contains(adoptionRequest_producttitle) && Isbn.contains(adoptionRequest_Isbn) && author.contains(adoptionRequest_Author) && productType.contains(adoptionRequest_ProductType) && adoptionRequest_Format.contains(lmsvalue)){
					System.out.println("I am in if block...........");
					if(!verifyText(ElsevierObjects.adoptionRequestStatus, compareStatus, "Verify request status.")){
						flag=false;
					}
				}
			} 
			if(!type(ElsevierObjects.adoptionRequest_DownloadURL,"","Enter null value.")){
				flag=false;
			}
			Thread.sleep(high);
			if(!selectByVisibleText(ElsevierObjects.adoptionRequestStatus, Status, "Change ststus to fullfilled.")){
				flag=false;
			}
			Thread.sleep(medium);    
			if(!click(ElsevierObjects.adoptionRequest_Save,"Click on Save button.")){
				flag=false;
			}
			Thread.sleep(high);
			errorAlert();		
			Thread.sleep(medium);

			if(!type(ElsevierObjects.adoptionRequest_DownloadURL, downloadURL, "Enter URL in download URL textbox.")){
				flag=false;
			}
			if(!type(ElsevierObjects.adoptionRequestDownloadKey, KeyValue, "Enter key value.")){
				flag=false;
			}

			if(!click(ElsevierObjects.adoptionRequest_Save,"Click on Save button.")){
				flag=false;
			}

			Thread.sleep(medium);
			if(!click(ElsevierObjects.emailPopup,"Click on Send mail button on popup.")){
				flag=false;
			}
			Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	
	
	public static boolean verifyDownloadURLInEmail(String downloadURL,String key,String keyValue) throws Throwable{
		boolean flag=true;
		try{

			//String email=readcolumns.twoColumns(0, 1, 20, configProps.getProperty("TestData")).get("user_email");

			if(!switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame")){
				flag=false;
			}
			Thread.sleep(medium);
			emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");

			emailBody=emailBody.replaceAll("<", "| ");
			emailBody=emailBody.replaceAll(">", " |");

			if(key.equalsIgnoreCase("true")){
				if(emailBody.trim().contains(keyValue))
				{

					Reporters.SuccessReport("Verify Download key "+keyValue+" in Email Body.", "Sucessfully Verified keyvalue: "+keyValue);

				}
				else
				{
					Reporters.failureReport("Verify Download key "+keyValue+" in Email Body.", "Failed To Verify keyvalue: "+keyValue);
					return false;
				}
			}
			emailUrl=getText(ElsevierObjects.verifyEmailDownloadURL, "Get Url from email body.");
			System.out.println(emailUrl);
			if(emailUrl.trim().contains(downloadURL.trim()))
			{
				Reporters.failureReport("Verify URL "+downloadURL+"  is Not Present in Email Body.", "Download URL is Present in the Body");
				return false;
			}
			else
			{

				Reporters.SuccessReport("Verify URL "+downloadURL+"  is Not Present in Email Body.", "Download URL is Not Present in the Body </br> For More details please verify Mail Body Printed in the Next line");
			}

			if(!javaClick(ElsevierObjects.email_logout,"Click on logout."))
			{
				flag=false;

			} 
		}   

		catch(Exception e){
			System.out.println(e.getMessage()); return false;
		}
		return flag;
	}

	public static boolean verifyDownloadURLInEmail(String downloadURL) throws Throwable{
		boolean flag=true;
		try{

			//String email=readcolumns.twoColumns(0, 1, 20, configProps.getProperty("TestData")).get("user_email");

			if(!switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame")){
				flag=false;
			}
			Thread.sleep(medium);
			emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
			emailBody=emailBody.replaceAll("<", "| ");
			emailBody=emailBody.replaceAll(">", " |");

			emailUrl=getText(ElsevierObjects.verifyEmailDownloadURL, "Get Url from email body.");
			System.out.println(emailUrl);
			if(emailUrl.trim().contains(downloadURL.trim()))
			{
				//  emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
				flag=true;
			}
			else
			{
				//emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
				return false;
			}

			driver.switchTo().defaultContent();

			if(!javaClick(ElsevierObjects.email_logout,"Click on logout."))
			{
				flag=false;

			} 
		}   
		catch(Exception e){
			System.out.println(e.getMessage()); return false;
		}
		return flag;
	}


	//Common for 15224,15228..............
	public static boolean CreateNewStudentHome() throws Throwable{
		boolean flag = true;
		try{
			driver.manage().deleteAllCookies();
			Thread.sleep(medium);
			if(!launchUrl(configProps.getProperty("URL4"))){
				flag = false;
			}
			/*if(!click(ElsevierObjects.home_student_lnkstudent,"Clicked On student Link")){
				flag = false;
			}*/
			Thread.sleep(high);
			if(!click(ElsevierObjects.student_login,"Click on login button.")){
				flag=false;
			}
			if(!click(ElsevierObjects.createAnAccount_lnk, "Click on Create An Account link present.")){
				flag=false;
			}
			Thread.sleep(high);
			if(!switchToFrameByLocator(ElsevierObjects.evolve_newAcount_frame,"Switch to frame")){
				flag=false;
			}
			registrationForm();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}




	//Credit Card Details
	public static boolean creditCardDetails() throws Throwable{
		boolean flag = true;     
		try{
			if(!selectByVisibleText(ElsevierObjects.creditCard_form, tc_8564.get("student_CardType")/*readcolumns.twoColumns(0, 1, 11, configProps.getProperty("TestData")).get("student_CardType")*/ ," Clicked on CreditCard type visa")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.CreditCardNum, tc_8564.get("student_CardNum")/*readcolumns.twoColumns(0, 1, 11, configProps.getProperty("TestData")).get("student_CardNum")*/, "Credit Card Num")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.CreditCardCvv, tc_8564.get("student_CardCvv")/*readcolumns.twoColumns(0, 1, 11, configProps.getProperty("TestData")).get("student_CardCvv")*/, "Credit Card Cvv")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.CreditCardName, tc_8564.get("studentCardName")/*readcolumns.twoColumns(0, 1, 11, configProps.getProperty("TestData")).get("studentCardName")*/, "Card Name")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!selectByVisibleText(ElsevierObjects.CreditCardMonth, tc_8564.get("CreditCardMonth")/*readcolumns.twoColumns(0, 1, 11, configProps.getProperty("TestData")).get("CreditCardMonth") */," Select Month")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!selectByVisibleText(ElsevierObjects.CreditCardyear, tc_8564.get("CreditCardYear")/*readcolumns.twoColumns(0, 1, 11, configProps.getProperty("TestData")).get("CreditCardYear") */," Select Year")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.CreditCardSubmit, "Credit Card Submit")){
				flag = false;
			}
			Thread.sleep(veryhigh);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;

	}

	public static boolean CreateNewFacultyHome() throws Throwable{
		boolean flag = true;
		driver.manage().deleteAllCookies();
		Thread.sleep(medium);
		if(!launchUrl(configProps.getProperty("URL"))){
			flag = false;
		}
		Thread.sleep(high);
		//driver.findElement(ElsevierObjects.StudentMainPage).click();
		if(!click(ElsevierObjects.iameducator, "Clicked on Educator")){
			flag = false;
		}
		Thread.sleep(medium);
		if(!click(ElsevierObjects.student_login,"Click on login button.")){
			flag=false;
		}
		Thread.sleep(high);
		if(!click(ElsevierObjects.createAnAccount_lnk, "Click on Create An Account link present.")){
			flag=false;
		}
		Thread.sleep(medium);
		if(!switchToFrameByLocator(ElsevierObjects.evolve_newAcount_frame,"Switch to frame")){
			flag=false;
		}
		if(!click(ElsevierObjects.faculty_radio_btn,"Faculty radio button")){
			flag=false;
		}
		Thread.sleep(medium);
		registrationForm();
		return flag;
	}

	//Common Business logic for Tc-9800,Tc-9801,8798,9799
	public static boolean mainPageLink() throws Throwable{
		boolean flag=true;
		try{
			driver.manage().deleteAllCookies();
			driver.navigate().refresh(); 
			if(!launchUrl(configProps.getProperty("URL"))){
				flag = false;
			}
			/* driver.manage().deleteAllCookies();
	           driver.navigate().refresh();*/
			Thread.sleep(medium);
			/*if(!click(ElsevierObjects.iameducator, "Clicked on Educator")){
				flag = false;
			}
			Thread.sleep(high);
			if(click(ElsevierObjects.StudentMainPage, "Click on main page link")){
				Reporters.SuccessReport("Launching The URL And Clicking On Main Page Link", "Successfully Launched The URL.</br>Successfully Clicked On Main Page Link.</br>User Is Successfully Taken To Evolve Main Page.");
			}
			else{
				Reporters.failureReport("Launching The URL And Clicking On Main Page Link", "Failed To Launch The URL.</br>Failed To Click On Main Page Link.</br>User Is Failed To Navigate To Evolve Main Page.");
			}
			Thread.sleep(high);*/
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}


	//Common Business logic for Tc-9800,Tc-9801,8798,9799
	public static boolean verifyLogin(String user) throws Throwable{
		boolean flag=true;
		try{
			driver.manage().deleteAllCookies();
			driver.navigate().refresh(); 
			String evolveCertURL=configProps.getProperty("URL");
			if(launchUrl(evolveCertURL)){
				Reporters.SuccessReport("Launching The URL.", "Successfully Launched The URL: "+evolveCertURL);
			}
			else{
				Reporters.failureReport("Launching The URL.", "Failed To Launch The URL: "+evolveCertURL);
			}
			if(user.equalsIgnoreCase("educator"))
			{
				if(click(ElsevierObjects.iameducator, "Clicked on Educator")){
					Reporters.SuccessReport("Clicking On Educator Link.", "Successfully Clicked On Educator Link.</br>Successfully Navigated To Honey Pot Page.");
				}
				else{
					Reporters.failureReport("Clicking On Educator Link.", "Failed To Click On Educator Link.</br>Successfully Navigated To Honey Pot Page.");
				}
				Thread.sleep(high);
			}
			else
			{
				if(click(ElsevierObjects.evolve_Home_Student,"Click on student link in evolve home page.")){
					Reporters.SuccessReport("Clicking On Student Link.", "Successfully Clicked On Student Link.</br>Successfully Navigated To Honey Pot Page.");
				}
				else{
					Reporters.failureReport("Clicking On Student Link.", "Failed To Click On Student Link.</br>Successfully Navigated To Honey Pot Page.");
				}
				Thread.sleep(high);
			}
			if(click(ElsevierObjects.student_login,"Click on login button.")){
				Reporters.SuccessReport("Clicking On Login Button.", "Successfully Clicked On Login Button.");
			}
			else{
				Reporters.failureReport("Clicking On Login Button.", "Successfully Clicked On Login Button.");
			}
			Thread.sleep(high);
			if(!isElementPresent1(ElsevierObjects.educator_txtStudentUser, "username text box")){
				flag=false;
			}
			Thread.sleep(high);
			if(!isElementPresentNegCheck(ElsevierObjects.educator_txtStudentPassword, "Password text box")){
				flag=false;
			}
			Thread.sleep(high);
			if(!isElementPresent1(ElsevierObjects.login_Remember_chk, "Rememeber login check box")){
				flag=false;
			}
			Thread.sleep(high);
			if(!isElementPresent1(ElsevierObjects.needHelpLogin_lnk, "Need help login link")){
				flag=false;
			}
			Thread.sleep(high);
			if(!isElementPresent1(ElsevierObjects.createAnAccount_lnk, "Create An Account link")){
				flag=false;
			}
			Thread.sleep(high);
			if(!isElementPresent1(ElsevierObjects.userLogin_btn, "Login button")){
				flag=false;
			}
			click(ElsevierObjects.student_login,"Click on login button.");
			Thread.sleep(high);

		}
		catch(Exception e){
			System.out.println(e);
		}
		return flag;
	}

	public static boolean verifyMyEvolveAdminPreOrder() throws Throwable{
		boolean flag=true;
		//click on My evolve link 
		if(!click(ElsevierObjects.Admin_Evolve_lnk, "Click on Evolve Admin link")){
			flag = false;
		}
		Thread.sleep(medium);

		//click on View Edit User Profile link 
		if(!click(ElsevierObjects.Admin_ViewEdit_UserProfile, "Click on View/Edit Evolve User PRofile")){
			flag = false;
		}
		Thread.sleep(medium);


		Map<String, String> values=readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData"));
		String userName=values.get("UserName");

		driver.findElement(ElsevierObjects.Admin_SearchUser_UserName).sendKeys(userName);

		//if(!type(ElsevierObjects.Admin_SearchUser_UserName, userName, "Input UserNamed ")){
		// Thread.sleep(medium);
		// flag = false;
		//}
		Thread.sleep(medium);

		if(!click(ElsevierObjects.Admin_SearchUser_SearchButton, "Click on Search Button")){
			flag = false;
		}
		Thread.sleep(medium);

		if(!click(ElsevierObjects.Admin_CourseParReport_Search_Results_Row2, "Click on Search Results")){
			flag = false;
		}
		Thread.sleep(medium);
		if(!click(ElsevierObjects.parBtn, "Click on PAR Button")){
			flag = false;
		}

		String str=getText(ElsevierObjects.enrollCourseId, "");

		return flag;
	}

	//Common Business logic for Tc-9800,Tc-9801,8798,9799
	public static boolean createAnAccountWithCorrectDetails(String user,String page) throws Throwable{
		boolean flag=true;
		String userFirstName=tc_9798.get("user_firstname");
		String facultyLastName=tc_9798.get("faculty_lastname");
		String studentLastName=tc_9798.get("student_lastname");
		Random ra = new Random( System.currentTimeMillis() );
		emailAdress=tc_9798.get("user_email")+Integer.toString((1 + ra.nextInt(2)) * 10000 + ra.nextInt(10000))+"@evolveqa.info";
		String password=tc_9798.get("user_pwd");
		try{

			/*if(page == "splash"){
	           if(!click(ElsevierObjects.evolve_createNewUser,"Create new account")){
	            flag=false;
	           }
	           Thread.sleep(high);
	          }
	          else{
	           if(!click(ElsevierObjects.student_login,"Click on login button.")){
	            flag=false;
	           }
	           Thread.sleep(high);
	          }*/
			/*if(!switchToFrameByLocator(ElsevierObjects.evolve_newAcount_frame, "Switch to create new account frame.")){
	           flag=false;
	          }
	          Thread.sleep(high);*/
			/*if(user=="educator"){
	           if(!click(ElsevierObjects.faculty_radio_btn,"Faculty radio button")){
	            flag=false;
	           }
	           Thread.sleep(high);
	          }*/
			if(!type(ElsevierObjects.evolve_newAccount_firstname,userFirstName,"Enter first name textbox.")){
				flag=false;
			}
			Thread.sleep(high);
			if(user.equalsIgnoreCase("educator")){
				if(!type(ElsevierObjects.evolve_newAcount_Lastname,facultyLastName, "Enter Last name textbox.")){
					flag=false;
				} 
				if(!type(ElsevierObjects.evolve_newAcount_Email,emailAdress, "Enter email in text box.")){
					flag=false;
				}
				Thread.sleep(high);
				if(!type(ElsevierObjects.evolve_newAcount_Pwd,password, "Enter Password in the textbox.")){
					flag=false;
				}
				Thread.sleep(high);
				if(!type(ElsevierObjects.evolve_newAcount_ConfirmPwd,password, "Enter Confirm Password in the textbox.")){
					flag=false;
				}
				Thread.sleep(high);
				if(click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
					Reporters.SuccessReport("Entering User details And Clicking On Submit Button.", "Successfully entered Faculty FirstName: "+userFirstName+",LastName: "+facultyLastName+",EmailAdress: "+emailAdress+",Password: "+password+",ConfirmPassword: "+password+"</br>Successfully Clicked On Submit Button. ");
				}
				else{
					Reporters.SuccessReport("Entering User details And Clicking On Submit Button.", "Failed To enter Faculty FirstName: "+userFirstName+",LastName: "+facultyLastName+",EmailAdress: "+emailAdress+",Password: "+password+",ConfirmPassword: "+password+"</br>Failed To Click On Submit Button. ");
				}
				Thread.sleep(high);
			}
			else{
				if(!type(ElsevierObjects.evolve_newAcount_Lastname,studentLastName, "Enter Last name textbox.")){
					flag=false;
				}
				if(!type(ElsevierObjects.evolve_newAcount_Email,emailAdress, "Enter email in text box.")){
					flag=false;
				}
				Thread.sleep(high);
				if(!type(ElsevierObjects.evolve_newAcount_Pwd,password, "Enter Password in the textbox.")){
					flag=false;
				}
				Thread.sleep(high);
				if(!type(ElsevierObjects.evolve_newAcount_ConfirmPwd,password, "Enter Confirm Password in the textbox.")){
					flag=false;
				}
				if(click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
					Reporters.SuccessReport("Entering User details And Clicking On Submit Button.", "Successfully entered Student FirstName: "+userFirstName+",LastName: "+studentLastName+",EmailAdress: "+emailAdress+",Password: "+password+",ConfirmPassword: "+password+"</br>Successfully Clicked On Submit Button. ");
				}
				else{
					Reporters.failureReport("Entering User details And Clicking On Submit Button.", "Failed To enter Student FirstName: "+userFirstName+",LastName: "+studentLastName+",EmailAdress: "+emailAdress+",Password: "+password+",ConfirmPassword: "+password+"</br>Failed To Click On Submit Button. ");

				}
				Thread.sleep(high);

			}
			String signUpMssg=tc_9798.get("SignupMessage");
			if(!verifyText(ElsevierObjects.createNewAccnt_SignUpMssg,signUpMssg, "Verify the you are signed up.")){

			}
			Thread.sleep(high);
			if(!isElementPresent1(ElsevierObjects.createNewAccnt_username, "Verify the username field present.")){
				flag=false;
			}
			Thread.sleep(high);
			if(!isElementPresent1(ElsevierObjects.createNewAccnt_Pwd, "Verify the Password field present.")){
				flag=false;
			}
			Thread.sleep(high);
			String dynamicUserName1=getText(ElsevierObjects.dynamic_username,"get username").trim();
			dynamicUserName=dynamicUserName1.split("\n")[0].split(":")[1];
			dynamicPassword=dynamicUserName1.split("\n")[1].split(":")[1];
			//   System.out.println("dynamicUserName:"+dynamicUserName);
			//String dynamicPwd=getText(ElsevierObjects.dynamic_pwd, "Get Password");
			//   System.out.println("dynamicPwd:"+dynamicPassword);
			WritingExcel.writeExcel(configProps.getProperty("TestData"), "Tc-9798", dynamicUserName, 1, 3);
			WritingExcel.writeExcel(configProps.getProperty("TestData"), "Tc-9798", dynamicPassword, 2, 3);
			String num = ".*[0-9].*";
			String alpha = ".*[a-z].*";
			/* capturCredentials();
	    String UserName = EvolveCommonBussinessFunctions.credentials[0];*/
			// String studentPaswword = EvolveCommonBussinessFunctions.credentials[1];

			if(dynamicUserName.matches(num) && dynamicUserName.matches(alpha)){
				if(click(ElsevierObjects.newAccount_contiue_btn, "Click on Continue button")){
					Reporters.SuccessReport("Verifying SignUp Message.</br>Verifying Username And Password.</br>Clicking On Continue Button.","Successfully Verified SignUp Message: "+signUpMssg+".</br>Successfully Verified UserName: "+dynamicUserName+",Password: "+dynamicPassword+"</br>Successfully Clicked On Continue Button</br>Successfully Navigated To HoneyPot Page.");
				}
				else{
					Reporters.failureReport("Verifying SignUp Message.</br>Verifying Username And Password.</br>Clicking On Continue Button.","Failed To Verify SignUp Message: "+signUpMssg+".</br>Failed To Verify UserName: "+dynamicUserName+",Password: "+dynamicPassword+"</br>Failed To Click On Continue Button</br>Failed To Navigate To HoneyPot Page.");

				}
				Thread.sleep(high);
			}
			Thread.sleep(low);
			//String userName="tstudent"+"[^0-9]";
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	//Common Business logic for Tc-9800,Tc-9801,8798,9799
	public boolean userReLogin(String user)throws Throwable{
		boolean flag=true;
		/*String UserName = EvolveCommonBussinessFunctions.credentials[0];
	    String Password = EvolveCommonBussinessFunctions.credentials[1];*/
		try{
			if(!click(ElsevierObjects.student_login, "click on student login")){
				flag=false;
			}
			Thread.sleep(high);
			//String reLoginUser=tc_9798a.get("Username");
			String reLoginUser=EvolveCommonBussinessFunctions.dynamicUserName;
			if(!type(ElsevierObjects.educator_txtStudentUser,reLoginUser,"Enter user name.")){
				flag=false;
			}
			Thread.sleep(high);
			//String reLoginPassword=tc_9798a.get("Password");
			String reLoginPassword=EvolveCommonBussinessFunctions.dynamicPassword;
			if(!type(ElsevierObjects.educator_txtStudentPassword,reLoginPassword,"Enter password")){
				flag=false;
			}
			Thread.sleep(high);
			if(click(ElsevierObjects.userLogin_btn,"Click on login button.")){
				Reporters.SuccessReport("ReLogin Into The Application With The Credentials Created In Above Steps.</br>Clicking On Login Button.", "Successfully Login With Username: "+reLoginUser+",Password: "+reLoginPassword+"</br>Successfully Clicked On Login Button.");
			}
			else{
				Reporters.failureReport("ReLogin Into The Application With The Credentials Created In Above Steps.</br>Clicking On Login Button.", "Failed To Login With Username: "+reLoginUser+",Password: "+reLoginPassword+"</br>Failed To Click On Login Button.");;
			}
			Thread.sleep(high);
			if(!click(ElsevierObjects.lnkevolvecart,"click on evolve link.")){
				flag=false;
			}
			Thread.sleep(high);
			String searchIsbn=tc_9798.get("userProduct");
			if(type(ElsevierObjects.txtproductsearch,searchIsbn,"enter product number to serach")){
				Reporters.SuccessReport("Seraching for Product.", "Successfully Entered ISBN: "+searchIsbn+"</br>Successfully Clicked On Go Button. ");
			}
			else{
				Reporters.failureReport("Seraching for Product.", "Failed To Enter ISBN: "+searchIsbn+"</br>Failed To Click On Go Button. ");
			}
			Thread.sleep(high);
			if(!click(ElsevierObjects.gobutton,"Clck on go button")){
				flag=false;
			}
			Thread.sleep(high);
			String price=getText(ElsevierObjects.evolve_Product_pricebeforerequest, "Get price of the product.");
			if(user.equalsIgnoreCase("educator"))
			{
				if(price.equals(ExpectedPrice))
				{
					//if(click(ElsevierObjects.educatorlogout,"Click on logout button."))
					click(ElsevierObjects.myAccount,"Click My Account.");
					click(ElsevierObjects.educatorlogout,"Click on logout button.");
					Reporters.SuccessReport("Verifying price And Logging Out Application.", "Successfully Verified Price: "+price+".</br>Successfully Logged Out the Faculty: "+reLoginUser);
				}
				else
				{
					Reporters.failureReport("Verifying price And Logging Out Application.", "Failed To Verify Price.</br>Failed To Log Out the Faculty: "+reLoginUser);
				}
				Thread.sleep(high);
			}

			else
			{
				if(!(price.equals(ExpectedPrice))){
					click(ElsevierObjects.myAccount,"Click My Account");
					if(click(ElsevierObjects.educatorlogout,"Click on logout button.")){
						Reporters.SuccessReport("Verifying price And Logging Out Application.", "Successfully Verified Price: "+price+".</br>Successfully Logged Out the Student: "+reLoginUser);
					}
					else{
						Reporters.failureReport("Verifying price And Logging Out Application.", "Failed To Verify Price.</br>Failed To Log Out the Student: "+reLoginUser);
					}
					//Thread.sleep(high);
				}
			}
			Thread.sleep(high);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	//Common Business logic for Tc-9800,Tc-9801,8798,9799
	public static boolean createAnAccountWithPwdEmpty(String user,String page) throws Throwable{
		boolean flag=true;

		String userFirstName=tc_9798.get("user_firstname");
		String facultyLastName=tc_9798.get("faculty_lastname");
		String studentLastName=tc_9798.get("student_lastname");
		Random ra = new Random( System.currentTimeMillis() );
		String emailAdress=tc_9798.get("user_email")+Integer.toString((1 + ra.nextInt(2)) * 10000 + ra.nextInt(10000))+"@evolveqa.info";

		try{

			/*if(page == "splash")
	          {
	           if(!click(ElsevierObjects.evolve_createNewUser,"Create new account")){
	            flag=false;
	           }
	           Thread.sleep(high);
	          }
	          else
	          {
	           if(!click(ElsevierObjects.student_login,"Click on login button.")){
	            flag=false;
	           }
	           Thread.sleep(high);
	          }*/
			// String name=driver.getWindowHandle();
			/*if(!switchToFrameByLocator(ElsevierObjects.evolve_newAcount_frame,"Switch to frame")){
	           flag=false;
	          }
	          Thread.sleep(high);*/
			/*if(user=="educator"){
	           if(!click(ElsevierObjects.faculty_radio_btn,"Faculty radio button")){
	            flag=false;
	           }
	           Thread.sleep(high);
	          }*/
			if(!type(ElsevierObjects.evolve_newAccount_firstname,userFirstName,"Enter first name textbox.")){
				flag=false;
			}
			Thread.sleep(high);
			if(user.equalsIgnoreCase("educator")){
				if(!click(ElsevierObjects.faculty_radio_btn, "Selected Faculty Radio Button"))
				{
					flag=false;
				}
				if(!type(ElsevierObjects.evolve_newAcount_Lastname,facultyLastName, "Enter Last name textbox.")){
					flag=false;
				} 
				if(!type(ElsevierObjects.evolve_newAcount_Email,emailAdress, "Enter email in text box.")){
					flag=false;
				}
				Thread.sleep(high);
				if(click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
					Reporters.SuccessReport("Entering User details And Clicking On Submit Button.", "Successfully Selected Faculty Radio Button</br>Successfully entered Faculty FirstName: "+userFirstName+",LastName: "+facultyLastName+",EmailAdress: "+emailAdress+"</br>Successfully Clicked On Submit Button. ");
				}
				else{
					Reporters.SuccessReport("Entering User details And Clicking On Submit Button.", "Failed To Faculty Radio Button</br>Failed To enter Faculty FirstName: "+userFirstName+",LastName: "+facultyLastName+",EmailAdress: "+emailAdress+"</br>Failed To Click On Submit Button. ");
				}
				Thread.sleep(high);
			}
			/********************For Student User*************************/
			else
			{
				if(!type(ElsevierObjects.evolve_newAcount_Lastname,studentLastName, "Enter Last name textbox.")){
					flag=false;
				}
				if(!type(ElsevierObjects.evolve_newAcount_Email,emailAdress, "Enter email in text box.")){
					flag=false;
				}
				Thread.sleep(high);
				if(click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
					Reporters.SuccessReport("Entering User details And Clicking On Submit Button.", "Successfully entered Student FirstName: "+userFirstName+",LastName: "+studentLastName+",EmailAdress: "+emailAdress+"</br>Successfully Clicked On Submit Button. ");
				}
				else{
					Reporters.failureReport("Entering User details And Clicking On Submit Button.", "Failed To enter Student FirstName: "+userFirstName+",LastName: "+studentLastName+",EmailAdress: "+emailAdress+"</br>Failed To Click On Submit Button. ");

				}
				Thread.sleep(high);

			}
			String pwdEmptyError=tc_9798.get("pwdEmptyField");
			if(verifyText(ElsevierObjects.registration_form_error,pwdEmptyError, "Verify password empty error message")){
				Reporters.SuccessReport("Verifying Password Empty Error Message.", "Successfully Verified Password Empty Error Message: "+pwdEmptyError);
			}
			else{
				Reporters.SuccessReport("Verifying Password Empty Error Message.", "Successfully Verified Password Empty Error Message: "+pwdEmptyError);
			}
			/*if(!click(ElsevierObjects.frame_close, "Click on close frame button.")){
	           flag=false;
	          }*/
			//driver.switchTo().window(name);
			Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	//Common Business logic for Tc-9800,Tc-9801,8798,9799
	public static boolean createAnAccountPwdMismatch(String user,String page) throws Throwable{
		boolean flag=true;
		String userFirstName=tc_9798.get("user_firstname");
		String facultyLastName=tc_9798.get("faculty_lastname");
		String studentLastName=tc_9798.get("student_lastname");
		Random ra = new Random( System.currentTimeMillis() );
		String emailAdress=tc_9798.get("user_email")+Integer.toString((1 + ra.nextInt(2)) * 10000 + ra.nextInt(10000))+"@evolveqa.info";
		String password=tc_9798.get("user_pwd");
		String passwordMismatch=tc_9798.get("user_CnfirmPwd");
		try{
			/*if(page == "splash"){
	           if(!click(ElsevierObjects.evolve_createNewUser,"Create new account")){
	            flag=false;
	           }
	           Thread.sleep(high);
	          }
	          else{
	           if(!click(ElsevierObjects.student_login,"Click on login button.")){
	            flag=false;
	           }
	           Thread.sleep(high);
	          }*/

			//String name=driver.getWindowHandle();

			/*if(!switchToFrameByLocator(ElsevierObjects.evolve_newAcount_frame,"Switch to frame")){
	           flag=false;
	          }
	          Thread.sleep(high);*/
			/*if(user=="educator"){
	           if(!click(ElsevierObjects.faculty_radio_btn,"Faculty radio button")){
	            flag=false;
	           }
	           Thread.sleep(high);
	          }*/
			if(!type(ElsevierObjects.evolve_newAccount_firstname,userFirstName,"Enter first name textbox.")){
				flag=false;
			}
			Thread.sleep(high);
			if(user=="educator")
			{

				if(!type(ElsevierObjects.evolve_newAcount_Lastname,facultyLastName, "Enter Last name textbox.")){
					flag=false;
				} 
				if(!type(ElsevierObjects.evolve_newAcount_Email,emailAdress, "Enter email in text box.")){
					flag=false;
				}
				Thread.sleep(high);
				if(!type(ElsevierObjects.evolve_newAcount_Pwd,password, "Enter Password in the textbox.")){
					flag=false;
				}
				Thread.sleep(high);
				if(!type(ElsevierObjects.evolve_newAcount_ConfirmPwd,passwordMismatch, "Enter Confirm Password in the textbox.")){
					flag=false;
				}
				Thread.sleep(high);
				if(click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
					Reporters.SuccessReport("Entering User details And Clicking On Submit Button.", "Successfully entered Faculty FirstName: "+userFirstName+",LastName: "+facultyLastName+",EmailAdress: "+emailAdress+",Password: "+password+",ConfirmPassword: "+password+"</br>Successfully Clicked On Submit Button. ");
				}
				else{
					Reporters.SuccessReport("Entering User details And Clicking On Submit Button.", "Failed To enter Faculty FirstName: "+userFirstName+",LastName: "+facultyLastName+",EmailAdress: "+emailAdress+",Password: "+password+",ConfirmPassword: "+password+"</br>Failed To Click On Submit Button. ");
				}
				Thread.sleep(high);
			}
			else{
				if(!type(ElsevierObjects.evolve_newAcount_Lastname,studentLastName, "Enter Last name textbox.")){
					flag=false;
				}
				if(!type(ElsevierObjects.evolve_newAcount_Email,emailAdress, "Enter email in text box.")){
					flag=false;
				}
				Thread.sleep(high);
				if(!type(ElsevierObjects.evolve_newAcount_Pwd,password, "Enter Password in the textbox.")){
					flag=false;
				}
				Thread.sleep(high);
				if(!type(ElsevierObjects.evolve_newAcount_ConfirmPwd,passwordMismatch, "Enter Confirm Password in the textbox.")){
					flag=false;
				}
				if(click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
					Reporters.SuccessReport("Entering User details And Clicking On Submit Button.", "Successfully entered Student FirstName: "+userFirstName+",LastName: "+studentLastName+",EmailAdress: "+emailAdress+",Password: "+password+",ConfirmPassword: "+passwordMismatch+"</br>Successfully Clicked On Submit Button. ");
				}
				else{
					Reporters.failureReport("Entering User details And Clicking On Submit Button.", "Failed To enter Student FirstName: "+userFirstName+",LastName: "+studentLastName+",EmailAdress: "+emailAdress+",Password: "+password+",ConfirmPassword: "+passwordMismatch+"</br>Failed To Click On Submit Button. ");

				}
				Thread.sleep(high);

			}
			String PwdMismatch=tc_9798.get("pwdMismatchError");
			if(verifyText(ElsevierObjects.registration_form_error,PwdMismatch , "Verify password mismatch error message")){
				Reporters.SuccessReport("Verifying Password Mismatch Error.", "Successfully Verified Password Mismatch error: "+PwdMismatch);
			}
			else{
				Reporters.failureReport("Verifying Password Mismatch Error.", "Failed To Verify Password Mismatch error: "+PwdMismatch);
			}
			Thread.sleep(high);
			/*if(!click(ElsevierObjects.frame_close, "Click on close frame button.")){
	           flag=false;
	          }*/
			//driver.switchTo().window(name);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	public static String []  capturCredentials() throws Throwable{
		Thread.sleep(high);
		waitForVisibilityOfElement(ElsevierObjects.NonAdmin_UserCredentials, "");
		Thread.sleep(medium);
		String credentialss = driver.findElement(ElsevierObjects.NonAdmin_UserCredentials).getText();

		String[] credentialsArr = credentialss.split("\n");

		String userName = null;
		String password = null;
		for(String credentials : credentialsArr){
			if(credentials.contains("Username:")){
				userName = credentials.replaceAll("Username:", "").trim();
			}
			if(credentials.contains("Password:")){
				password = credentials.replaceAll("Password:", "").trim();
			}    
		}

		credentials[0] =userName;
		credentials[1] =password;
		ReadingExcel.updateCellInSheet(1,1,configProps.getProperty("TestData"), "DynamicCredentials", userName);

		ReadingExcel.updateCellInSheet(2,1,configProps.getProperty("TestData"), "DynamicCredentials", password);

		return credentialsArr;
	}

	/*public static String []  capturCredentials() throws Throwable{

		Thread.sleep(high);
		waitForVisibilityOfElement(ElsevierObjects.NonAdmin_UserCredentials, "wait for the visibility of element");
		String credentialss = driver.findElement(ElsevierObjects.NonAdmin_UserCredentials).getText();
		//String credentialss=getText(ElsevierObjects.NonAdmin_UserCredentials, "Get Dynamic Username and Password");
		String[] credentialsArr = credentialss.split("\n");

		String userName = null;
		String password = null;
		for(String credentials : credentialsArr){
			if(credentials.contains("Username:")){
				userName = credentials.replaceAll("Username:", "").trim();
			}
			if(credentials.contains("Password:")){
				password = credentials.replaceAll("Password:", "").trim();
			}    
		}

		credentials[0] =userName;
		credentials[1] =password;
		ReadingExcel.updateCellInSheet(1,1,configProps.getProperty("TestData"), "DynamicCredentials", userName);
		ReadingExcel.updateCellInSheet(2,1,configProps.getProperty("TestData"), "DynamicCredentials", password);
		return credentialsArr;
	}*/

	

	//for KNO Library
	public static boolean knoLibrary(String user,String knoUser) throws Throwable{
		boolean flag = true;
		String knoPageTitle="";
		try{

			/*if(!click(ElsevierObjects.Kno_refresh_lnk,"Click on refresh link in evolve page")){
	          flag=false;
	         }*/
			driver.navigate().refresh();
			/* if(!waitForElementPresent(ElsevierObjects.Kno_library_lnk, "Kno library link")){
	          flag=false;
	         } */
			Thread.sleep(high);
			if(!click(ElsevierObjects.evolveCatalog, "Click on Catalog")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			if(!click(ElsevierObjects.evolveCatalog, "Click on Catalog")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(high);
			if(!click(ElsevierObjects.Kno_refresh_lnk,"Click on refresh link in evolve page")){
				flag=false;
			}
			Thread.sleep(high);
			String knoLibraryLink=getText(ElsevierObjects.Kno_library_lnk, "Kno library link");
			if(click(ElsevierObjects.Kno_library_lnk, "Click on Kno Library link")){
				Reporters.SuccessReport("Verifying Kno Library Link And Clicking On Kno Library link.", "Successfully Verified Kno Library Link in My Evolve Page: "+knoLibraryLink+"</br>Successfully clicked on kno library link.");
			}else{
				Reporters.failureReport("Verifying Kno Library Link And Clicking On Kno Library link.", "Failed to Verify Kno Library Link in My Evolve Page: "+knoLibraryLink+"</br>Failed To click on kno library link.");
			}
			Thread.sleep(high);
			String parentHandle = driver.getWindowHandle(); // get the current window handle
			/*if(!click(ElsevierObjects.Kno_library_lnk,"Click on Kno Library link")){
	       flag=false;
	      }
	      Thread.sleep(high);*/
			for (String winHandle : driver.getWindowHandles()) {
				driver.switchTo().window(winHandle); 
			}
			/* if(!waitForElementPresent(ElsevierObjects.kno_HomePage, "wait for book")){
	          flag=false;
	         }*/
			if(!switchToFrameByLocator(ElsevierObjects.kno_Home_frame, "Switch to frame")){
				flag=false;
			}
			if(knoUser.equalsIgnoreCase("newuser")){
				if(user.equalsIgnoreCase("educator")){
					if(!click(ElsevierObjects.Kno_Home_Instructor,"Click on Instructor in Kno Page")){
						flag=false;
					} 
					Thread.sleep(medium);
				}
				if(user.equalsIgnoreCase("student")){
					if(!click(ElsevierObjects.kno_HomePage_student,"Click on Student in Kno page")){
						flag=false; 
					}
					Thread.sleep(medium);
				}
			}
			knoPageTitle=driver.getTitle();
			System.out.println("knoPageTitle"+knoPageTitle);
			List<WebElement> s=driver.findElements(ElsevierObjects.kno_BookList);
			for(WebElement book:s){
				if(book!=null){  
					Reporters.SuccessReport("Fetching List Of Books.", "Fetched Book With Title:"+book.getText());
				}else{
					Reporters.failureReport("Fetching List Of Books.", "Failed To Fetch Book With Title.");
				}
			}
			if(waitForElementPresent(ElsevierObjects.Kno_Home_Book, "wait for book")){
				Reporters.SuccessReport("Navigating To KNO Library Page.", "Successfully Navigated To KNO Library Page.</br>KNO Page Is Opened in New Window With Title: "+knoPageTitle);
			}
			else{
				Reporters.failureReport("Navigating To KNO Library Page.", "Failed To Navigate To KNO Library Page.");
			}
			Thread.sleep(medium);
			driver.close(); // close newly opened window when done with it
			driver.switchTo().window(parentHandle);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}




	//Common for 15225,15235,15224
	public static boolean AccessCodeReviewandSubmit() throws Throwable{
		boolean flag=true;
		try{
			Thread.sleep(low);
			driver.switchTo().defaultContent();
			Thread.sleep(low);
			
			priceInReviewPage=getText(ElsevierObjects.evolve_Rview_chkprice, "price in review page");
			isbnInReviewPage=getText(ElsevierObjects.evolve_Rview_chkIsbn,"Isbn in review page");
			titleInReviewPage=getText(ElsevierObjects.evolve_Rview_chktitle, "Title in review page");
			accessCode_totalPrice=getText(ElsevierObjects.evolve_AccessCode_totalprice, "total product price");
			System.out.println("priceInReviewPage:"+priceInReviewPage);
			System.out.println("isbnInReviewPage:"+isbnInReviewPage);
			System.out.println("ExpectedPrice:"+ExpectedPrice);
			System.out.println("admin_Producttitle:"+admin_Producttitle);
			System.out.println("titleInReviewPage:"+titleInReviewPage);
			System.out.println("Kno_Isbn:"+Kno_Isbn);
			System.out.println("accessCode_totalPrice:"+accessCode_totalPrice);

			if(priceInReviewPage.contains(ExpectedPrice) && admin_Producttitle.contains(titleInReviewPage) && isbnInReviewPage.contains(Kno_Isbn) && accessCode_totalPrice.contains(ExpectedPrice)){
				if(!click(ElsevierObjects.evolveRegisterAcceptChk,"Click on Register check box")){
					flag=false;
				}
				if(isElementPresent(ElsevierObjects.evolveInstructorChk)){
					if(!click(ElsevierObjects.evolveInstructorChk, "Click on Instructor check box")){
						flag = false;
					}
				}
				Thread.sleep(medium);
				if(click(ElsevierObjects.instructor_submit,"Click on Instructor Submit button")){
					Reporters.SuccessReport("Verifying Item Details In Review And Submit Page.", "Successfully Verified Price:"+priceInReviewPage+",Title:"+titleInReviewPage+",ISBN:"+isbnInReviewPage+" And TotalPrice:"+accessCode_totalPrice+"</br>Successfully Navigated To Receipt page.");
				}else
				{
					Reporters.failureReport("Verifying Item Details In Review And Submit Page.", "Failed To Verify Item Details In Review And Submit Page.</br>Failed to Navigate To Receipt page.");
				}
				Thread.sleep(high);
			}
			piceInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chkprice,"Price in Receipt page");
			titleInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chktitle,"Price in Receipt page");
			isbnInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chktisbn,"Price in Receipt page");

			if(piceInReceiptPage.contains(ExpectedPrice) && admin_Producttitle.contains(titleInReceiptPage) && isbnInReceiptPage.contains(Kno_Isbn)  && accessCode_totalPrice.contains(ExpectedPrice)){ 
				if(click(ElsevierObjects.Myevolve,"Click on my evolve")){
					Reporters.SuccessReport("Verifying Item Details In Receipt Page And Clicking On MyEvolve", "Successfully Verified Price:"+piceInReceiptPage+",Title:"+titleInReceiptPage+",ISBN:"+isbnInReceiptPage+" And TotalPrice:"+accessCode_totalPrice+" </br>Successfully Clicked On MyEvolve Link.");
				}else
				{
					Reporters.failureReport("Verifying Item Details In Receipt Page And Clicking On MyEvolve", "Failed To Verify Item Details In Receipt Page.</br>Failed To Click On MyEvolve Link.");

				}
				Thread.sleep(medium);

			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag; 
	}




	//Review And Submit For Both KNO And VST Number
	public static boolean userReviewSubmit(String user,String accessCode,String KNOIsbn) throws Throwable{
		boolean flag = true;
		//totalPriceInReviePage=getText(ElsevierObjects.totalPriceInReviewPage, "Total price in review page");
		priceInReviewPage=getText(ElsevierObjects.evolve_Rview_chkprice, "price in review page");
		isbnInReviewPage=getText(ElsevierObjects.evolve_Rview_chkIsbn,"Isbn in review page");
		titleInReviewPage=getText(ElsevierObjects.evolve_Rview_chktitle, "Title in review page");
		VST_Isbn=ReadingExcel.columnDataByHeaderName( "AccessCode_VST_NUmber", "VST",configProps.getProperty("TestData"));
		//VST_Isbn=readcolumns.twoColumns(0, 1,"createNewaccount",configProps.getProperty("TestData")).get("AccessCode_VST_NUmber");
		ReadingExcel.updateCellInSheet(1,5,configProps.getProperty("TestData"), "VST", titleInReviewPage); 
		//KNOIsbn=readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("kno_num");


		List<WebElement> prices=driver.findElements(ElsevierObjects.priceValidation);

		String estimatedTax=prices.get(1).getText();
		String total=prices.get(2).getText();
		float estTax=convertStringToPrice(estimatedTax);
		float tot=convertStringToPrice(total);
		float itemPrice=convertStringToPrice(priceInReviewPage);
		float finalPrice=itemPrice+estTax;

		//If there is access code it enters into this block
		if(accessCode.equalsIgnoreCase("true")){
			accessCode_totalPrice=getText(ElsevierObjects.evolve_AccessCode_totalprice, "total product price");

			System.out.println("In true Block.....................");
			if(priceInReviewPage.contains(ExpectedPrice) && title_beforerequest.contains(titleInReviewPage) && isbnInReviewPage.contains(VST_Isbn) && accessCode_totalPrice.contains(ExpectedPrice)){
				Reporters.SuccessReport("Verifying the item title, access code, ISBN, and price", "User is brought to receipt  page .  <br>Item Title Expected is : "+title_beforerequest+"<br>Item Title Actual is : "+titleInReviewPage+
						"<br>ISBN Expected is : "+isbnInReviewPage+"<br> ISBN Expected is : "+VST_Isbn+"<br>Expected total Price is : "+accessCode_totalPrice+"<br> Actual price is : "+ExpectedPrice);
				System.out.println("In the access code  inner block Block.....................");
				if(user == "educator"){
					if(!click(ElsevierObjects.evolveInstructorChk,"Click on Instructor checkbox")){
						flag=false;
					}
					Thread.sleep(medium);
					if(!click(ElsevierObjects.evolveRegisterAcceptChk,"Click on Register checkbox")){
						flag=false;
					}
					Thread.sleep(medium);
				}
				else{
					if(!click(ElsevierObjects.evolveRegisterAcceptChk,"Click on Register checkbox")){
						flag=false;
					}
					Thread.sleep(medium);
				}

				if(!click(ElsevierObjects.instructor_submit,"Click on Instructor Submit button")){
					flag=false;
				}
				Thread.sleep(medium);
			} else{
				Reporters.failureReport("Verifying the item title, access code, ISBN, and price", "User failed to brought to receipt  page .  <br>Item Title Expected is : "+title_beforerequest+"<br>Item Title Actual is : "+titleInReviewPage+
						"<br>ISBN Expected is : "+isbnInReviewPage+"<br> ISBN Expected is : "+VST_Isbn+"<br>Expected total Price is : "+accessCode_totalPrice+"<br> Actual price is : "+ExpectedPrice);
			}
		}
		else
		{
			//In review and submit page..if there is no access code

			System.out.println("In else Block.....................");

			if(/*totalPriceInReviePage.contains(price_beforerequest)*/  priceInReviewPage.equals(price_beforerequest) && (isbnInReviewPage.trim().contains(VSTIsbn.trim()) || isbnInReviewPage.trim().contains(KNOIsbn.trim())) && titleInReviewPage.contains(title_beforerequest) ){
				System.out.println("In else block and in if...............");
				if(user .equalsIgnoreCase("educator")){
					if(!click(ElsevierObjects.evolveInstructorChk,"Click on Instructor checkbox")){
						flag=false;
					}
					Thread.sleep(medium);
					if(!click(ElsevierObjects.evolveRegisterAcceptChk,"Click on Register checkbox")){
						flag=false;
					}
					Thread.sleep(medium);
				}
				else{
					if(!click(ElsevierObjects.evolveRegisterAcceptChk,"Click on Register checkbox")){
						flag=false;
					}
					Thread.sleep(medium);
				}

				if(tot==finalPrice){
					Reporters.SuccessReport("Verifying Total Price In Review And Submit Page.", "Successfully Fetched Estimated Tax:"+estimatedTax+"</br>Successfully Fetched Item Price:"+priceInReviewPage+"</br>Successfully Verified Total Price As Sum Of Estimated Tax And Item Price:"+estimatedTax+"+"+priceInReviewPage+":"+finalPrice);
				}
				else
				{
					Reporters.failureReport("Verifying Total Price In Review And Submit Page.", "Failed To Verify Total Price In Review And Submit Page."); 
				}

				if(click(ElsevierObjects.instructor_submit,"Click on Instructor Submit button")){
					Reporters.SuccessReport("Verifying Product Details In Review And Submit Page.</br>Clicking On Submit Button In Review Page.", "Successfully verified Price in Review Page: "+price_beforerequest+"</br> Successfully Verified ISBN in Review Page: "+IsbnBeforeRequest+"</br>Successfully Verified Title in Review Page: "+title_afterRequest+"</br>Successfully Clicked On Submit Button.</br> Successfully Navigated Confirmation Page. "); 
				}
				else{
					Reporters.failureReport("Verifying Product Details In Review And Submit Page.</br>Clicking On Submit Button In Review Page.", "Failed To Verify the KnoISBN in Review Page: "+IsbnBeforeRequest+". </br>Failed to Verify ISBN in Review Page: "+IsbnBeforeRequest+"</br>Failed to Verify Title in Review Page: "+title_afterRequest+" </br>Failed to Click On Submit Button.</br> Failed To Navigate to Confirmation Page. ");
				}
			}
			Thread.sleep(high);
		}
		Thread.sleep(veryhigh);
		piceInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chkprice,"Price in Receipt page");
		titleInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chktitle,"Price in Receipt page");
		isbnInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chktisbn,"Price in Receipt page");
		productType=getText(ElsevierObjects.ProductType,"Get product type");
		String totalPriceInReceiptPage=getText(ElsevierObjects.totalPriceInReceiptPage,"Total Price In Receipt Page.");
		if(accessCode.equalsIgnoreCase("true")){
			if(piceInReceiptPage.contains(ExpectedPrice) && title_beforerequest.contains(titleInReceiptPage) && isbnInReceiptPage.contains(VST_Isbn) && accessCode_totalPrice.contains(ExpectedPrice)){ 
				if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
					flag=false;
				}
				Thread.sleep(medium);
			}
		}else{
			if(piceInReceiptPage.equals(price_beforerequest) && totalPriceInReceiptPage.contains(total) /*&& (isbnInReceiptPage.contains(VSTIsbn) || isbnInReceiptPage.contains(KNOIsbn))*/  && titleInReceiptPage.contains(title_beforerequest)){
				if(click(ElsevierObjects.Myevolve,"Click on my evolve")){
					Reporters.SuccessReport("Verifying Product Details In Receipt Page And Clicking On My Evolve.", "Successfully Verified the Below validations: <br>Price In Receipt Page:"+piceInReceiptPage+",<br>ISBN In Receipt Page:"+isbnInReceiptPage+",<br>Title In Receipt Page:"+titleInReceiptPage+",<br>Total Price As Same As Item Price:"+total+"</br>Successfully Clicked On My Evolve link.");
				}
				else{
					Reporters.failureReport("Verifying Product Details In Receipt Page And Clicking On My Evolve.", "Failed To Verify Product Details In Receipt Page.</br>Failed To Click On My Evolve link.");
				}
				Thread.sleep(medium);
			}
		}


		return flag;
	}

	//Searching KNO OR VST Number
	public static boolean VSTandKnoSearch(String name,String accessCode) throws Throwable{
		boolean flag = true;
		VSTIsbn=ReadingExcel.columnDataByHeaderName( "VST_Number", "VST",configProps.getProperty("TestData"));
		KNOIsbn=ReadingExcel.columnDataByHeaderName( "kno_num", "VST",configProps.getProperty("TestData"));

		//VSTIsbn=readcolumns.twoColumns(0, 1, "createNewaccount", configProps.getProperty("TestData")).get("VST_Number");
		//KNOIsbn=readcolumns.twoColumns(0, 1, "createNewaccount", configProps.getProperty("TestData")).get("kno_num");

		Thread.sleep(medium);
		   driver.switchTo().defaultContent();
		
		if(click(ElsevierObjects.evolveCatlog_lnk,"Evolve catalog link")){
			Reporters.SuccessReport("Validate Click on EVOLVE CATALOG link", "Successfully Clicked On Evolve Catalog Link.</br>Successfully Displayed Honey Pot Page where user can search for products");
		}
		else{
			Reporters.failureReport("Validate Click on EVOLVE CATALOG link", "Failed Clicked On Evolve Catalog Link.</br>Failed To Display Honey Pot Page where user can search for products");

		}
		Thread.sleep(medium);
		//if the product code is VST     
		if(accessCode.equalsIgnoreCase("true")){
			//if there is access code then this block will be executed
			String product=ReadingExcel.columnDataByHeaderName( "AccessCode_VST_NUmber", "VST",configProps.getProperty("TestData"));
			//String product=readcolumns.twoColumns(0, 1, "createNewaccount", configProps.getProperty("TestData")).get("AccessCode_VST_NUmber");
			if(type(ElsevierObjects.txtproductsearch,product,"Enter VST Number for Access Code.")){
				Reporters.SuccessReport("Search for Product : "+product, " Successfully able to search for the product : "+product+" <br> User is taken to the product page for the isbn : "+product);
			}else{
				Reporters.failureReport("Search for Product : "+product, " Failed to search for the product : "+product+" <br> User is failed to take to the product page for the isbn : "+product);
			}
			Thread.sleep(medium);
		}else{
			//if there is no access code this block is executed
			if(name.equalsIgnoreCase("VST")){
				String product1=ReadingExcel.columnDataByHeaderName( "VST_Number", "VST",configProps.getProperty("TestData"));
				//String product1=readcolumns.twoColumns(0, 1, "createNewaccount", configProps.getProperty("TestData")).get("VST_Number");
				if(type(ElsevierObjects.txtproductsearch,product1,"Enter VST Number")){
					Reporters.SuccessReport("Search for Product : "+product1, " Successfully able to search for the product : "+product1+" <br> User is taken to the product page for the isbn : "+product1);
				}else{
					Reporters.failureReport("Search for Product : "+product1, " Failed to search for the product : "+product1+" <br> User is failed to take to the product page for the isbn : "+product1);
				}
				Thread.sleep(medium);
			}
			else{
				//knoNumber=readcolumns.twoColumns(0, 1, 15, configProps.getProperty("TestData")).get("kno_num");
				if(type(ElsevierObjects.txtproductsearch,KNOIsbn,"Enter KNO Number")){
					Reporters.SuccessReport("Entering KnoISBN in Search Box.", "Successfully Entered Kno ISBN: "+KNOIsbn+" in Search Box.</br>Successfully Navigated To Product details Page.");
				}
				else{
					Reporters.failureReport("Entering KnoISBN in Search Box.", "Failed To Enter Kno ISBN: "+KNOIsbn+" in Search Box.</br>Failed To Navigate To Product details Page.");
				}
				Thread.sleep(medium);
			}
		}

		//click on Go button
		if(click(ElsevierObjects.gobutton,"Click Go button")){
			Reporters.SuccessReport("Click on Request Now button", "Successfully clicked on the Request Now button");
		}else{
			Reporters.failureReport("Click on Request Now button", "Failed to click on the Request Now button");
		}
		Thread.sleep(high);
		price_beforerequest=getText(ElsevierObjects.evolve_Product_pricebeforerequest,"Product price before request");   
		title_beforerequest=getText(ElsevierObjects.evolve_Product_titlebeforerequest,"Product title");
		IsbnBeforeRequest=getText(ElsevierObjects.evolve_verify_isbn,"Isbn num");


		//If there is access code it will click on request product link
		if(accessCode.equalsIgnoreCase("true")){

			if(click(ElsevierObjects.evolve_Request_Product,"Click request product button")){
				Reporters.SuccessReport("Capture the Details of the ISBN item : "+IsbnBeforeRequest, "The Details are successfully captured <br> Title of the Product is : "+title_beforerequest+"<br> Price of the Product is : "+price_beforerequest+"<br> ISBN of the Product is : "+IsbnBeforeRequest);
			}else{
				Reporters.failureReport("Capture the Details of the ISBN item : "+IsbnBeforeRequest, "The Details are failed to capture <br> Title of the Product is : "+title_beforerequest+"<br> Price of the Product is : "+price_beforerequest+"<br> ISBN of the Product is : "+IsbnBeforeRequest);
			}
			Thread.sleep(medium);
		}else{

			//if there is no access code this block will be executed
			if(name.equalsIgnoreCase("VST")){
				if(IsbnBeforeRequest.trim().contains(VSTIsbn.trim())){
					if(click(ElsevierObjects.evolve_Request_Product,"Click request product button")){
						Reporters.SuccessReport("Verifying KnoISBN And Clicking On Request Product Button.", "Successfully Verified the KnoISBN: "+IsbnBeforeRequest+". </br>Successfully Clicked On Request Product Button.</br> Successfully Navigated To MyCart Page. "); 
					}
					else{
						Reporters.failureReport("Verifying KnoISBN And Clicking On Request Product Button.", "Failed To Verify the KnoISBN: "+IsbnBeforeRequest+". </br>Failed To Click On Request Product Button.</br> Failed To Navigate to MyCart Page. ");
					}
					Thread.sleep(medium);
				}
			}else{

				if(KNOIsbn.contains(IsbnBeforeRequest)){
					if(click(ElsevierObjects.evolve_Request_Product,"Click request product button")){
						Reporters.SuccessReport("Verifying KnoISBN And Clicking On Request Product Button.", "Successfully Verified the KnoISBN: "+IsbnBeforeRequest+". </br>Successfully Clicked On Request Product Button.</br> Successfully Navigated To MyCart Page. "); 
					}
					else{
						Reporters.failureReport("Verifying KnoISBN And Clicking On Request Product Button.", "Failed To Verify the KnoISBN: "+IsbnBeforeRequest+". </br>Failed To Click On Request Product Button.</br> Failed To Navigate to MyCart Page. ");
					}
					Thread.sleep(high);
				}
			}
		}
		//Thread.sleep(medium);
		/* if(!click(ElsevierObjects.Mycart_alert,"Click on my cart alert")){
	    flag=false;
	   }*/
		Thread.sleep(high);
		price_afterRequest=getText(ElsevierObjects.evolve_Product_priceAfterRequest,"Product price after request");
		title_afterRequest=getText(ElsevierObjects.evolve_Product_titleAfterRequest,"Title After request");
		isbn_afterRequest=getText(ElsevierObjects.evovle_Product_isbnAfterRequest, "");
		//If there is access code the access code will be entered here....
		if(accessCode == "true"){

			if(!click(ElsevierObjects.access_apply_chkbox,"Clicked on Access Code Radio button")){
				flag=false;
			}
			Thread.sleep(medium);
			String invalidaccessCode=ReadingExcel.columnDataByHeaderName( "InVAlidAccessCode", "VST",configProps.getProperty("TestData"));
			//String invalidaccessCode=readcolumns.twoColumns(0, 1, "createNewaccount", configProps.getProperty("TestData")).get("InVAlidAccessCode");
			if(type(ElsevierObjects.accessCode_type,invalidaccessCode,"Enter InValid Acess Number")){
				Reporters.SuccessReport("Validate the Access code section", "Enter the invalid Access Code into the VST Text Box : "+invalidaccessCode+" and capture the error Message");
			}else{
				Reporters.failureReport("Validate the Access code section", "Failed to Enter the invalid Access Code into the VST Text Box : "+invalidaccessCode+" and failed to capture the error Message");
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.accessCode_submit,"Clicked on Apply for AccessCode button")){
				flag=false;
			}
			Thread.sleep(medium);
			String sucMsg=getText(ElsevierObjects.accessCode_Verify, "");
			if(verifyText(ElsevierObjects.accessCode_Verify, "The access code is not valid.", "Verify text")){
				Reporters.SuccessReport("The Error Message Validation", "The Error message : "+sucMsg+" is displayed");	
			}else{
				Reporters.failureReport("The Error Message Validation", "The Error message : "+sucMsg+" is failed to display");
			}
			driver.findElement(ElsevierObjects.accessCode_type).clear();
			Thread.sleep(medium);
			String vstValid=ReadingExcel.getCell(0, 0, VSTDataPath, "VSTCodes")/*readcolumns.twoColumns(0, 1,"createNewaccount", configProps.getProperty("TestData")).get("NewAccessCode");*/;
			if(type(ElsevierObjects.accessCode_type,vstValid,"Enter Valid Acess Number")){
				Reporters.SuccessReport("Select VST Access code radio button and Input the Valid VST Code: "+vstValid, "VST Access code radio button is selected and the Valid VST Code: "+vstValid+" is entered into the text box");
			}else{
				Reporters.failureReport("Select VST Access code radio button and Input the Valid VST Code: "+vstValid, "VST Access code radio button is not selected and the Valid VST Code: "+vstValid+" is failed to enter into the text box");
			}
			if(!click(ElsevierObjects.accessCode_submit,"Clicked on Apply for AccessCode button")){
				flag=false;
			}
			//Page will get Refreshed here.....
			Thread.sleep(high);
			price_afterAccessCodeSubmit = getText(ElsevierObjects.evolve_Product_priceAfterRequest,"Product price after Refresh");
			System.out.println(price_afterAccessCodeSubmit);
			if(price_afterAccessCodeSubmit.contains(ExpectedPrice)){
				Reporters.SuccessReport("Validate the Prices are equal", "Prices are validated successfully <br> Expected price is : "+ExpectedPrice+"<br> Actual price is : "+price_afterAccessCodeSubmit);
				if(javaClick(ElsevierObjects.evolve_checkout_btn,"Click Reedem checkout button")){
					Reporters.SuccessReport("Verify Product Details in MyCart Page And Clicking On Reedeem CheckOut Button.", "Successfully verified the following product values: <br> Price before Requesting the Product: "+price_beforerequest+"</br> Price After Requesting the Product: "+price_afterRequest+"<br>ISBN before Requesting the Product: "+IsbnBeforeRequest+"</br> ISBN After Requesting the Product: "+isbn_afterRequest+"</br>Title before Requesting the Product: "+title_beforerequest+"</br> Title After Requesting the Product: "+title_afterRequest+"</br> Successfully Clicked On Reedeem CheckOut Button.</br> Successfully Navigated to Update Account Page. "); 
				}
				else{
					Reporters.failureReport("Verify Product Details in MyCart Page And Clicking On Reedeem CheckOut Button.", "Failed To verify the following product values: <br> Price before Requesting the Product: "+price_beforerequest+"</br> Price After Requesting the Product: "+price_afterRequest+"<br>ISBN before Requesting the Product: "+IsbnBeforeRequest+"</br> ISBN After Requesting the Product: "+isbn_afterRequest+"</br>Title before Requesting the Product: "+title_beforerequest+"</br> Title After Requesting the Product: "+title_afterRequest+"</br> Successfully Clicked On Reedeem CheckOut Button.</br> Successfully Navigated to Update Account Page. ");
				}
				Thread.sleep(medium);
			}else{
				Reporters.failureReport("Validate the Prices are equal", "Prices are failed to validate <br> Expected price is : "+ExpectedPrice+"<br> Actual price is : "+price_afterAccessCodeSubmit);
			}

		}else{
			//if there is no access code this block is executed
			if(price_beforerequest.contains(price_afterRequest) && title_afterRequest.trim().contains(title_beforerequest.trim())){
				if(isChecked(ElsevierObjects.acess_chkbx,"Check radio button")){
					if(javaClick(ElsevierObjects.evolve_checkout_btn,"Click Reedem checkout button")){
						Reporters.SuccessReport("Verify Product Details in MyCart Page And Clicking On Reedeem CheckOut Button.", "Successfully verified Price: "+price_beforerequest+"</br> Successfully Verified ISBN: "+IsbnBeforeRequest+"</br>Successfully Verified Title: "+title_afterRequest+"</br> Successfully Clicked On Reedeem CheckOut Button.</br> Successfully Navigated to Update Account Page. "); 
					}
					else{
						Reporters.failureReport("Verify Product Details in MyCart Page And Clicking On Reedeem CheckOut Button.", "Failed To verify Price: "+price_beforerequest+"</br> Failed To Verify ISBN: "+IsbnBeforeRequest+"</br>Failed To Verify Title: "+title_afterRequest+"</br> Failed To Click On Reedeem CheckOut Button.</br>Failed To Navigate to Update Account Page.");
					}
					Thread.sleep(high);
				}

			}
		}

		return flag;
	}




	//common BUssiness Logic for Tc-15235,15224,15225,15228,15236,15237
	public static boolean manageAccessCode() throws Throwable{
		boolean flag=true;
		try{
			//accessCodeSetName=readcolumns.twoColumns(0, 1,17,configProps.getProperty("TestData")).get("CodeSetName");

			if(!click(ElsevierObjects.MaintainPrdct_MaintainAccesCode,"Click on Maintain access code in product result page")){
				flag=false;
			}
			Thread.sleep(medium);
			/*AccessCodeTableData=getText(ElsevierObjects.AccessCodeSetTable, "access code Table Data");
		           if(AccessCodeTableData.contains(accessCodeSetName)){

		           }*/
			if(!click(ElsevierObjects.accessCodeSetName_clk,"Click on Created access code set")){
				flag=false;
			}
			Thread.sleep(medium);
			accessCode=getText(ElsevierObjects.AccessCode,"get Access code");
			System.out.println("accessCode"+accessCode);
			if(accessCode.equals(null)){
				Reporters.failureReport("Fetching AccessCode From Manage Access Code Page.", "Failed To Fetch AccessCode From Manage AccessCode page.");
			}
			else{
				Reporters.SuccessReport("Fetching AccessCode From Manage Access Code Page.", "Successfully Fetched AccessCode "+accessCode+" From Manage AccessCode page.");

			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}






	//Common for Tc-15225,15235,15224,15237,15228,15236.....................
	public static boolean pageBurstReedem() throws Throwable{
		boolean flag=true;
		try{
			Thread.sleep(medium);
			driver.switchTo().defaultContent();
			Thread.sleep(medium);
			
			if(click(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
				Reporters.SuccessReport("Clicking On Evolve Catalog Link.", "Successfully Clicked On Evolve Catalog Link.</br>Successfully Displayed Honey Pot Page.");
			}
			else{
				Reporters.failureReport("Clicking On Evolve Catalog Link.", "Failed Clicked On Evolve Catalog Link.</br>Failed To Display Honey Pot Page.");
			}
			Thread.sleep(medium);
			/*if(!click(ElsevierObjects.evolve_Pageburst,"Click on evolve page burst")){
				flag=false;
			}
			Thread.sleep(high);
			if(javaClick(ElsevierObjects.evolve_Pageburst_Reedemlnk,"Click on Redeem Access code link")){
				Reporters.SuccessReport("Clicking On Redeem Access Code link on Page burst HoneyPot.", "Successfully Clicked On Redeem access code link Under PageBurst Honeypot.</br>Successfully Navigated To Reedeem Access PageBurst Page.");
			}
			else{
				Reporters.failureReport("Clicking On Redeem Access Code link on Page burst HoneyPot.", "Failed to Click On Redeem access code link Under PageBurst Honeypot.</br>Failed To Navigate To Reedeem Access PageBurst Page.");
			}*/
			System.out.println("accessCode:"+accessCode);
			if(!type(ElsevierObjects.evolve_Reedemlnk_AccessCode,accessCode,"Enter Access code")){
				flag=false;
			}
			Thread.sleep(high);
			if(click(ElsevierObjects.evolve_AccessCode_Submitbtn,"Click on Access code submit button")){
				Reporters.SuccessReport("Entering access code And Navigating to My cart Page.", "Successfully Entered access code "+accessCode+"</br>Successfully Clicked On Submit Button.</br> Successfully Navigated To MyCart Page.");
			}
			else{
				Reporters.failureReport("Entering access code And Navigating to My cart Page.", "Failed to Enter access code "+accessCode+"</br>Failed To Click On Submit Button.</br> Failed To Navigate To MyCart Page.");
			}

			Thread.sleep(medium);
			accesscode_price=getText(ElsevierObjects.evolve_Product_priceAfterRequest,"Price of access code product");
			accesscode_Isbn=getText(ElsevierObjects.evolve_Accesscode_isbn, "Isbn of product with access code");
			//acessCode_afterRequest=getText(ElsevierObjects.evolve_AccessCode_afterRequest,"Access code");
			acessCode_afterRequest=driver.findElement(ElsevierObjects.evolve_AccessCode_afterRequest).getAttribute("value");
			acessCode_titleAfterRequest=getText(ElsevierObjects.evolve_Product_titleAfterRequest, "title of access code product");
			//accessCode_totalPrice=getText(ElsevierObjects.evolve_AccessCode_totalprice, "total product price");
			System.out.println("accesscode_price:"+accesscode_price);
			System.out.println("ExpectedPrice:"+ExpectedPrice);
			//System.out.println("accessCode_totalPrice:"+accessCode_totalPrice);
			System.out.println("accesscode_Isbn:"+accesscode_Isbn);
			System.out.println("Kno_Isbn:"+Kno_Isbn);
			System.out.println("admin_Producttitle:"+admin_Producttitle);
			System.out.println("acessCode_titleAfterRequest:"+acessCode_titleAfterRequest);
			System.out.println("accessCode:"+accessCode);
			System.out.println("acessCode_afterRequest:"+acessCode_afterRequest);
			clickOnOkButtonIfVisible();

			Thread.sleep(high);
			if(accesscode_price.equals(ExpectedPrice) && accesscode_Isbn.contains(Kno_Isbn) && admin_Producttitle.contains(acessCode_titleAfterRequest) && accessCode.contains(acessCode_afterRequest)){
				if(javaClick(ElsevierObjects.evolve_checkout_btn,"Click on Access code checkout Button")){
					Reporters.SuccessReport("Verifying Item Details In My Cart Page.", "Successfully Verified Price: "+accesscode_price+",Title: "+acessCode_titleAfterRequest+",AccessCode: "+accessCode+" And Isbn: "+accesscode_Isbn+"</br>Successfully Clicked On Reedeem Checkout Button.</br>Navigated To Update Account Page.");
				}
				else{
					Reporters.failureReport("Verifying Item Details In My Cart Page.","Failed to Verify Price: "+accesscode_price+",Title: "+acessCode_titleAfterRequest+",AccessCode: "+accessCode+" And Isbn: "+accesscode_Isbn+"</br>Failed To Click On Reedeem Checkout Button.</br>Failed To Navigate To Update Account Page.");
				}
				Thread.sleep(medium);
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	/**Generic method for email id search
	 * 
	 * @param emailID1
	 * @return
	 * @throws Throwable
	 */

	public static boolean searchEmail(String emailID1) throws Throwable{
		boolean flag=true;
		try{
			System.out.println("emailID:"+emailID1);
			if(type(ElsevierObjects.email_SearchBox,emailID1,"Enter the email id.")){
				Reporters.SuccessReport("Enter the email id to Search", "Successfully entered email id to search in the email search box");
			}else{
				Reporters.failureReport("Enter the email id to Search", "Failed to enter email id to search in the email search box");
			}
			Thread.sleep(medium);
			click(ElsevierObjects.email_SearchIcon,"Click on search icon.");
			Thread.sleep(veryhigh);
		}
		catch(Exception e){
			System.out.println(e);
		}

		return flag;	
	}


	public static boolean SearchNegProduct() throws Throwable {
		try
		{
			boolean flag = true;
			click(ElsevierObjects.evolveCatalog, "Click on Catalog");
			Thread.sleep(medium);
			type(ElsevierObjects.Hesi_Search,HesiNegISBN,"Search the product with ISBN number");
			Thread.sleep(low);
			click(ElsevierObjects.Hesi_Go,"click on Go Button");
			Thread.sleep(low);
			String Actualresult ="0 Results found";
			String Result=getText(ElsevierObjects.Hesi_Resultfound,"Get Result present there");
			if(Result.contains(Actualresult)){
				Reporters.SuccessReport("compare the results for the product","Results are compared successfully : <br>Expected Result is:"+Result+" <br>Actual Result is:"+Actualresult);
			}else{
				Reporters.failureReport("compare the results for the product","Results comaprision is failed :<br>Expected Result is:"+Result+" <br>Actual Result is:"+Actualresult);
			}
			Thread.sleep(medium);
			return flag;}
		catch(Exception e){return false;}
	}

	public static boolean verifysort(String[] totalResults)throws Throwable
	{
		try
		{
			String[] ActualStringfromApplication=new String[totalResults.length];
			ActualStringfromApplication=Arrays.copyOf(totalResults, totalResults.length);

			//For References
			String ActualStringfromApplication1=Arrays.toString(ActualStringfromApplication);    



			List list = Arrays.asList(totalResults);
			list = new LinkedList(Arrays.asList(totalResults));
			Set set = new HashSet(Arrays.asList(totalResults));
			Collections.sort(list, String.CASE_INSENSITIVE_ORDER);
			String[] ExpectedSortingString=(String[]) list.toArray(new String[0]);
			System.out.println("TheSorted list is:"+list);
			String ExpectedSortingString2=Arrays.toString(ExpectedSortingString);

			System.out.println("AfterConverting to Stringfor Comparsion:"+ExpectedSortingString2);
			//System.out.println(Arrays.toString(AllTitlesfromApplications));
			Thread.sleep(300);

			/*String[] ExpectedSortingString=AllTitlesfromApplications;
			   	Arrays.sort(ExpectedSortingString);
			   	String ExpectedSortingString2=Arrays.toString(ExpectedSortingString);
			 */
			//System.out.println(Arrays.toString(ExpectedSortingString));
			int flagvalue=0;


			if(ActualStringfromApplication1.equals(ExpectedSortingString2))
			{
				System.out.println("Actual Sorting is:"+ActualStringfromApplication1);
				sActualValues=ActualStringfromApplication1;
				System.out.println("Expected Sorting is:"+ExpectedSortingString2);
				sExpectedValues=ExpectedSortingString2;
				System.out.println("The Values are Matching");
				//return true;
				flagvalue=0;
			}
			else

			{	

				flagvalue=1;
				//break;
				//return false;

			}



			if(flagvalue==0)
			{
				Reporters.SuccessReport("Verifying elements and Sorting The Combo Box Visible Items only:", "The Values are in Sort Order Actual Sorting order is :"+ActualStringfromApplication1+" </br>Expected Sorting Order is:"+ExpectedSortingString2);
				return true;  
			}
			else if(flagvalue==1)
			{
				Reporters.failureReport("Verifying elements and Sorting The Combo Box Visible Items only:", "The Values are NOT in Sort Order Actual Sorting order is :"+ActualStringfromApplication1+" </br>Expected Sorting Order is:"+ExpectedSortingString2);
				System.out.println("Actual Sorting is:"+ActualStringfromApplication1);
				sActualValues=ActualStringfromApplication1;
				System.out.println("Expected Sorting is:"+(ExpectedSortingString2));
				sExpectedValues=ExpectedSortingString2;
				System.out.println("The Values are not Matching");

				return false;
			}}catch(Exception e){sgErrMsg="Sorting failed due to"+e; return false;}
			return false;
	} 

	// Roster email verification

	public static boolean Emailforwarding(String Email) throws Throwable {
		try
		{
			boolean flag = true;
			launchUrl(configProps.getProperty("EmailURL"));
			Thread.sleep(medium);
			type(ElsevierObjects.emailaddress,configProps.getProperty("verifyemail_username"),"Enter email id");
			Thread.sleep(medium);
			type(ElsevierObjects.emailpassword,configProps.getProperty("verifyemail_password"),"Enter password");
			Thread.sleep(medium);
			click(ElsevierObjects.emaillogin, "Click on Login Button.");
			Thread.sleep(high);
			click(ElsevierObjects.email_Icon,"Click on Email icon.");
			Thread.sleep(low);
			click(ElsevierObjects.email_dropdown,"Click on Dropdown.");
			Thread.sleep(low);
			click(ElsevierObjects.email_dropdown_Fromchk,"Click on From check box.");
			Thread.sleep(low);
			click(ElsevierObjects.email_dropdown_Tochk,"Click on To checkbox.");
			Thread.sleep(medium);
			type(ElsevierObjects.email_SearchBox,Email,"Enter the EmailAddress.");
			Thread.sleep(low);
			click(ElsevierObjects.email_SearchIcon,"Click on search icon.");
			Thread.sleep(medium);
			String EmailTitle = getText(ElsevierObjects. titleInEmail,"Verify the Subject of the Email");
			Reporters.SuccessReport("Verify Subject of Email","Successfully Emailsubject is verified </br> "+EmailTitle);
			switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
			String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
			Reporters.SuccessReport("Verify Emailbody content","Successfully Emailbody content is verified </br> "+emailBody);
			driver.switchTo().defaultContent();
			b= true;
			click(ElsevierObjects.Email_forward,"Forward button");
			b= false;
			Thread.sleep(medium);
			String parentHandle = driver.getWindowHandle();
			for (String winHandle : driver.getWindowHandles()) {
				driver.switchTo().window(winHandle);
				Thread.sleep(medium);
			} 
			Thread.sleep(low);
			b= true;
			type(ElsevierObjects.Email_Forwarding_To,configProps.getProperty("gmailUsername"),"Enter Gmail username in the textbox");
			Thread.sleep(low);
			click(ElsevierObjects.Email_Send,"Send button");
			driver.switchTo().window(parentHandle);
			Thread.sleep(medium);
			click(ElsevierObjects.email_logout,"Logout button");  
			b = false;
			return flag;}
		catch(Exception e){return false;}  
	}

	//step 9
	public static boolean Gmailverification(String Email) throws Throwable{
		try
		{
			boolean flag = true;
			Robot r=new Robot();
			r.keyPress(KeyEvent.VK_CONTROL);
			Thread.sleep(low);
			r.keyPress(KeyEvent.VK_T);
			r.keyRelease(KeyEvent.VK_T);
			r.keyRelease(KeyEvent.VK_CONTROL);
			Thread.sleep(low);
			r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);

			Thread.sleep(medium);
			launchUrl(configProps.getProperty("GmailURL"));
			Thread.sleep(medium);
			type(ElsevierObjects.Gmail_username,configProps.getProperty("gmailUsername"),"Enter username");
			Thread.sleep(medium);
			type(ElsevierObjects.Gmail_password,configProps.getProperty("gmailPassword"),"Enter password");
			Thread.sleep(medium);
			click(ElsevierObjects.Gmail_login,"Click on login");
			Thread.sleep(medium);
			click(ElsevierObjects.Gmail_searchbox,"Click on gmail searchbox");
			Thread.sleep(medium);
			type(ElsevierObjects.Gmail_searchbox,Email,"Enter EmailAddress in the searchbox");
			Thread.sleep(medium);
			click(ElsevierObjects.Gmail_search_button,"Click on search button");
			Thread.sleep(low);
			click(ElsevierObjects.Gmail_verify_mail,"Click on forward mail present there");
			Thread.sleep(medium);
			String content = getText(ElsevierObjects.Gmail_total_frame,"Get Text of body content");
			if(content.contains("104882_tfaculty208_1018")&& content.contains("newtes") && content.contains("user") && content.contains("newautomationtest155999@evolveqa.info") && content.contains("nuser1993")
					&& content.contains("******")&& content.contains("Test")&& content.contains("Faculty")&& content.contains("testfa14@evolveqa.info")&& content.contains("tfaculty208")&& content.contains("Johon")&& content.contains("Smith")&&content.contains("abc@evolveqa.info")){
				Reporters.SuccessReport("Verify Text of Email body","Successfully Text in Email is verified :</br> " +content);
			}else{
				Reporters.failureReport("Verify Text of Email body","Failed to verify the Emailbody");
			}
			String parentHandle = driver.getWindowHandle(); 
			for (String winHandle : driver.getWindowHandles()) {
				driver.switchTo().window(winHandle); 
			}  
			click(ElsevierObjects.Gmail_Signout_button,"click on dropdown");
			Thread.sleep(medium);
			click(ElsevierObjects.Gmail_Logout,"click on signout button");
			driver.switchTo().window(parentHandle);

			return flag;}
		catch(Exception e){return false;}  
	}                 



	/**Genaric Method for getting user details from MyAccount
	 * 
	 * @return
	 * @throws Throwable
	 */
	//Common Logic for 9804,9805,9806,15575,15576,15577,15578,15579......
	public static boolean getAccountDetails() throws Throwable{
		boolean flag=true;

		try{


			if(!click(ElsevierObjects.myAccount,"click on my account")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.myAccount_AccountSettings,"click on account settings.")){
				flag=false;
			}
			Thread.sleep(medium);
			ImplicitWait();
			driver.navigate().refresh();
			Thread.sleep(medium);
			//String firstName=getText(ElsevierObjects.educator_form_txtFirstName, "Get first name");
			getAccountDetailsUserName=getAttribute(ElsevierObjects.educator_form_UserName, "value", "Get user name");
			getAccountDetailsFirstName=getAttribute(ElsevierObjects.educator_form_txtFirstName, "value", "Get first name");
			getAccountDetailsLastName=getAttribute(ElsevierObjects.educator_form_txtLastName,"value","Get Last Name");
			getAccountDetailsEmail=getAttribute(ElsevierObjects.educator_form_txtEmail,"value","Get email id.");
			getAccountDetailsInstitution=getAttribute(ElsevierObjects.educator_form_txtInstution, "value","Get Institution name");
			getAccountDetailsPhone=getAttribute(ElsevierObjects.educator_form_txtAddPhone,"value","Get phone number");
			getAccountDetailsStreetAddress=getAttribute(ElsevierObjects.educator_form_txtAddress,"value", "Get Street Adress");
			ImplicitWait();
			getAccountDetailsCountry=getText(ElsevierObjects.educator_form_ddInstutionCountry, "Get country of institution.");
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	//Common Logic for 9804,9805,9806,15575,15576,15577,15578,15579......
	public static boolean receiptPage(String lmsvalue) throws Throwable{
		boolean flag=true;
		try{

			Thread.sleep(medium);
			productType=getText(ElsevierObjects.ProductType,"Get product type");
			lmsTextinReceiptPage=getText(ElsevierObjects.lmsTitleInReceiptPage, "Get lms text in receipt page.");
			PriceinReceiptPage=getText(ElsevierObjects.evolve_Receipt_chkprice,"Price in Receipt page");
			if(lmsTextinReceiptPage.contains(lmsvalue) && PriceinReceiptPage.equals(ExpectedPrice) ){
				//instructorLogout();
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	//Logout from the instructor
	public static boolean instructorLogout() throws Throwable{
		boolean flag = true;
		try{
			//Thread.sleep(medium);
			driver.switchTo().defaultContent();
			if(!click(ElsevierObjects.myAccount, "Clicked on My Account")){
				flag = false;
			}
			if(!click(ElsevierObjects.Educator_Logout, "Clicked on logout Educator")){
				flag = false;
			}
			Thread.sleep(high);
		}catch(Exception e){
			System.out.println(e.getMessage());
			sgErrMsg=e+" is Failed due to this exception";
			return false;
		}
		Thread.sleep(medium);
		return flag;
	}
	public static boolean verifyTitleInEmailBody(String emailTitle) throws Throwable{
		boolean flag=true;
		try{

			Thread.sleep(veryhigh);
			/* if(!type(ElsevierObjects.email_SearchBox,getAccountDetailsEmail,"Enter the email id.")){
		   flag=false;
		  }
		  Thread.sleep(medium);
		  if(!click(ElsevierObjects.email_SearchIcon,"Click on search icon.")){
		   flag=false;
		  }
		  Thread.sleep(medium);*/
			titleInEmail=getText(ElsevierObjects.titleInEmail, "Get title in evolve email page.");
			System.out.println( "titleInEmail:"+titleInEmail);

			if(titleInEmail.trim().contains(emailTitle.trim())){
				Reporters.SuccessReport("Verify Title In Email Body.", "Successfully verified email title </br> The Actual Title is:"+titleInEmail+"</br> Expected Title is: "+emailTitle );
			}else{
				Reporters.failureReport("Verify Title In Email Body.", "Failed to verify email title </br> The Actual  Title is:"+titleInEmail+" </br> The Expected Title is"+emailTitle);
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	//Common Logic for 9804,9805,9806,15575,15576,15577,15578,15579......
	public static boolean getAdoptionRequestDetails() throws Throwable{
		try{	

			Thread.sleep(medium);
			if (!isElementPresent(ElsevierObjects.adoptionRequest,"Adoption Request Results Page"))
			{
				return false;	
			}

			adoptionRequest_getAdoptionNum=getText(ElsevierObjects.adoptionRequest_AdoptionNumber, "Get Adoption number.");
			System.out.println("adoptionRequest_getAdoptionNum:"+adoptionRequest_getAdoptionNum);
			click(ElsevierObjects.adoptionRequest,"CLick on Adoption request.");
			userName=configProps.getProperty("Educator_UserName");
			password=configProps.getProperty("Educator_passWord");
			By by = ElsevierObjects.AdoptionRequestDetails_TABLE;
			if (!isElementPresent(ElsevierObjects.AdoptionRequestDetails_TABLE, "Adoption Request Detailed Page"))
			{
				return false;	
			}
			List<WebElement> prodDetails = getTableTD(by, 1, 1).findElements(By.tagName("div"));

			adoptionRequest_Username=getTableTD(by,11,2).getText();
			adoptionRequest_Password=getTableTD(by,12,2).getText();
			adoptionRequest_FirstName=getTableTD(by,14,2).getText();
			adoptionRequest_LastName=getTableTD(by,15,2).getText();

			adoptionRequest_Institution=getTableTD(by,17,2).getText();
			adoptionRequest_Adress=getTableTD(by,20,2).getText();
			adoptionRequest_Phone=getTableTD(by, 22, 2).getText();
			adoptionRequest_Country=getTableTD(by, 21, 2).getText();
			adoptionRequest_Isbn=prodDetails.get(5).getText();
			adoptionRequest_producttitle=prodDetails.get(1).getText();
			adoptionRequest_Format=getTableTD(by,5,2).getText();
			adoptionRequest_Trial=getTableTD(by, 3, 2).getText();
			adoptionRequest_ProductType=getTableTD(by,2,2).getText();
			adoptionRequest_Author=prodDetails.get(3).getText();
			adoptionRequest_Enrollment=getTableTD(by, 8, 1).getText();
			adoptionRequest_Comment=getText(ElsevierObjects.adoptionRequestGetComment, "Get course comment");
			adoptionRequest_CourseContent=getAttribute(ElsevierObjects.adoptionRequestGetcoursecontent,"value","Get course content" );


			WebElement emailTable = getTableTD(by,25,1).findElement(By.tagName("table"));
			adoptionRequest_Email=getTableTD(emailTable, 2, 1).getText();



			adoptionRequest_MIlestone=getText(ElsevierObjects.AR_F_Production_MIlestone,"Get text of MIlestone");
			adoptionRequest_StartDate=getText(ElsevierObjects.AR_F_Production_StartDate, "Get Start date text.");
			adoptionRequest_Warning1=getAttribute(ElsevierObjects.AR_F_Production_Warning1, "origin", "Get Warning1 text.");
			adoptionRequest_Warning2=getAttribute(ElsevierObjects.AR_F_Production_Warning2, "origin", "Get Warning2 text.");
			adoptionRequest_EndDate=getAttribute(ElsevierObjects.AR_F_Production_EndDate, "origin", "Get EndDate text.");
			adoptionRequest_UnenrollUser=getAttribute(ElsevierObjects.AR_F_Production_UnEnrollUser, "origin", "Get UnEnrollUser text.");
			Select comboBox1 = new Select(driver.findElement(By.xpath("//*[@id='eventEmail0']")));
			adoptionRequest_EmailTemplate_StartDate = comboBox1.getFirstSelectedOption().getText();
			Select comboBox2 = new Select(driver.findElement(By.xpath("//*[@id='eventEmail1']")));
			adoptionRequest_EmailTemplate_Warning1 = comboBox2.getFirstSelectedOption().getText();
			Select comboBox3 = new Select(driver.findElement(By.xpath("//*[@id='eventEmail2']")));
			adoptionRequest_EmailTemplate_Warning2 = comboBox3.getFirstSelectedOption().getText();
			Select comboBox4 = new Select(driver.findElement(By.xpath("//*[@id='eventEmail3']")));
			adoptionRequest_EmailTemplate_EndDate = comboBox4.getFirstSelectedOption().getText();

		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}

		return true;

	}	
	/**Generic method for Entering evolve content in popup. 
	 * @param lmsValue
	 * @return
	 * @throws Throwable
	 */ 
	public static boolean evolveContentInPopUp(String evolveContent,String comment,String enrollment) throws Throwable{
		boolean flag=true;
		try{
			popUpEvolveText=getText(ElsevierObjects.popUp_EvolveText, "Get Evolve Content Text");
			if(isNotChecked(ElsevierObjects.Faculty_ContentPlus_CourseTools_Chkbx, "Check whether chekbox is clicked or not."))
			{
				click(ElsevierObjects.Faculty_ContentPlus_CourseTools_Chkbx, "Click on chekbox.");
			}
			else{
				System.out.println("Check box already clicked");
			}
			selectByVisibleText(ElsevierObjects.Faculty_ContentPlus_CourseSection,evolveContent, "Select contents value.");
			Thread.sleep(high);
			type(ElsevierObjects.Faculty_ContentPlus_PCE,enrollment,"Enter course enrollment");
			Thread.sleep(high);
			type(ElsevierObjects.Faculty_ContentPlus_Comment,comment,"Enter comment.");
			Thread.sleep(high);
			click(ElsevierObjects.popUp_Apply, "Click on Apply button.");
			Thread.sleep(veryhigh);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			sgErrMsg=e+" is Failed due to this exception";
			return false;
		}
		return flag;	
	}
	//Common Logic for 9804,9805,9806,15575,15576,15577,15578,15579......
	public static boolean hostedMycart(String lmsvalue,String evolve) throws Throwable{
		boolean flag=true;
		try{
			Thread.sleep(high);
			Isbn=getText(ElsevierObjects.Student_Product_ISBN,"get isbn number.");
			title=getText(ElsevierObjects.evolve_Rview_chktitle,"Get title of book.");
			author=getText(ElsevierObjects.Course_Author, "Get author name.");
			lmsText=getText(ElsevierObjects.lmsTitle, "Get lms title.");
			myCartPrice=getText(ElsevierObjects.evolve_Product_priceAfterRequest, "Get the product price");
			System.out.println("lmsText:"+lmsText);
			System.out.println("lmsvalue:"+lmsvalue);
			System.out.println("myCartPrice:"+myCartPrice);
			System.out.println("ExpectedPrice:"+ExpectedPrice);
			System.out.println("requestProductPage_Title:"+requestProductPage_Title);
			System.out.println("title:"+title);
			System.out.println("Isbn:"+Isbn);
			System.out.println("requestProductPage_Isbn:"+requestProductPage_Isbn);
			System.out.println("popUpEvolveText:"+popUpEvolveText);
			if(evolve.equalsIgnoreCase("true")){

				if(javaClick(ElsevierObjects.Educator_Reedemchkout_btn,"Click on Reedeem Checkout button")){
					Reporters.SuccessReport("Verifying Product Details In MyCart Page.Clicking On Redeem Button.", "Verified ISBN:"+Isbn+",Title:"+title+",Price:"+ExpectedPrice+"</br>Successfully Clicked On Redeem Button.");
				}
				else{
					Reporters.failureReport("Verifying Product Details In MyCart Page.Clicking On Redeem Button.", "Failed To Verify Product Details.</br>Failed To Click On Redeem Button.");
				}
				Thread.sleep(medium);
			}

			else{

				if(javaClick(ElsevierObjects.Educator_Reedemchkout_btn,"Click on Reedeem Checkout button")){
					Reporters.SuccessReport("Verifying Product Details In MyCart Page.Clicking On Redeem Button.", "Verified ISBN:"+Isbn+",Title:"+title+",Price:"+ExpectedPrice+"</br>Successfully Clicked On Redeem Button.");
				}
				else{
					Reporters.failureReport("Verifying Product Details In MyCart Page.Clicking On Redeem Button.", "Failed To Verify Product Details.</br>Failed To Click On Redeem Button.");
				}

				Thread.sleep(medium);
			}

		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	// common for 15225,15236
	public static boolean  existingUserLogin ( String user,String userName,String password) throws Throwable{
		boolean flag=true;
		try{


			//clickOnMainPageLink();
			Thread.sleep(medium);
			if(user .equalsIgnoreCase("educator")){
				if(!launchUrl(configProps.getProperty("URL3"))){
					flag = false;
				}
				Thread.sleep(medium);
			}
			else{
				if(!launchUrl(configProps.getProperty("URL4"))){
					flag = false;
				}
				Thread.sleep(medium);
			}
			
			if(!click(ElsevierObjects.student_login,"Click on login button.")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.common_login_userName,userName.trim(),"UserName")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.common_login_passWord,password.trim(),"Password")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.submit,"Click on submit")){
				flag=false;
			}  
			Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	public boolean orderConformation(String user, String email) throws Throwable{
		boolean flag = true;
		try{
			System.out.println("....................Validating email verifications...........");
			String evolveEmail="success@evolveqa.info";
			//evolveStudentEmail="studentuser1@evolveqa.info";
			if(user.equalsIgnoreCase("educator")){
				if(type(ElsevierObjects.email_SearchBox, evolveEmail,"Enter the email id.")){
					Reporters.SuccessReport("Input the email into the search box", "Successfully entered the email into the search box");
				}else{
					Reporters.failureReport("Input the email into the search box", "Failed to enter the email into the search box");
				}
			}else{ 
				if(type(ElsevierObjects.email_SearchBox, email,"Enter the email id.")){
					Reporters.SuccessReport("Input the email into the search box", "Successfully entered the email into the search box");
				}else{
					Reporters.failureReport("Input the email into the search box", "Failed to enter the email into the search box");
				}
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.email_SearchIcon,"Click on search icon.")){
				flag=false;
			}
			Thread.sleep(high);		
			String orderConfirm = getText(ElsevierObjects.order_Conform,"");		
			String orderConfirmip = "Order Confirmation";
			if(orderConfirm.contains(orderConfirmip)){
				Reporters.SuccessReport("Verify the User receives an email titled Order Confirmation.", "User receives an email titled Order Confirmation in the inbox : " +orderConfirm );
				waitForVisibilityOfElement(ElsevierObjects.order_Conform,"");			
				String evolveEmailweb = getText(ElsevierObjects.evolveEmailWeb, "");
				//for educator search mail.......
				if(user.equalsIgnoreCase("educator")){
					if(evolveEmailweb.contains(evolveEmail)){
						if(click(ElsevierObjects.email_logout,"Click on logout...")){
							Reporters.SuccessReport("Log out from the email application", "Successfully Logged out from the email application");
						}else{
							Reporters.failureReport("Log out from the email application", "Failed to Log out from the email application");
						}
						waitForVisibilityOfElement(ElsevierObjects.evolve_login, "");
					}
				}else{				
					//for student search mail.....
					if(evolveEmailweb.contains(email)){
						if(!click(ElsevierObjects.email_logout,"Click on logout...")){
							flag=false;
						}
						waitForVisibilityOfElement(ElsevierObjects.evolve_login, "");
					}

				}			
			}else{
				Reporters.failureReport("Verify the User receives an email titled Order Confirmation.", "User failed to receive an email titled Order Confirmation in the inbox");
			}
		}catch(Exception e){
			System.out.println(sgErrMsg="Error message");return false;
		}
		return flag;
	}


	public static boolean getAccountDetailsforRoster() throws Throwable{
		boolean flag=true;

		try{
			if(!click(ElsevierObjects.myAccount,"click on my account")){
				flag=false;
			}
			Thread.sleep(high);
			if(!click(ElsevierObjects.myAccount_AccountSettings,"click on account settings.")){
				flag=false;
			}
			Thread.sleep(medium);
			//String firstName=getText(ElsevierObjects.educator_form_txtFirstName, "Get first name");
			getAccountDetailsUserName=getAttribute(ElsevierObjects.educator_form_UserName, "value", "Get first name");
			getAccountDetailsFirstName=getAttribute(ElsevierObjects.educator_form_txtFirstName, "value", "Get first name");
			getAccountDetailsLastName=getAttribute(ElsevierObjects.educator_form_txtLastName,"value","Get Last Name");
			getAccountDetailsEmail=getAttribute(ElsevierObjects.educator_form_txtEmail,"value","Get email id.");
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e.getMessage());

		}
		return flag;}

	/** Click on Admin evolve link
	 * Click View/Edit User Profile link
	 * Read newlycreated user from DynamicCredentials
	 * Search for the newly created user
	 * Verify user exists in results and Click on the user to navigate to user PAR report
	 * Click on PAR button
	 * Verify courseid exists under PAR   
	 * @param courseid
	 * @return
	 * @throws Throwable
	 */
	public static boolean verifyMyEvolveAdmin(String courseid) throws Throwable{
		boolean flag=true;
		try
		{

			//click on My evolve link 
			if(click(ElsevierObjects.Admin_Evolve_lnk, "Click on Evolve Admin link")){
				Reporters.SuccessReport("Clicking On Evolve Admin Link In Bread Crumb.", "Successfully Clicked On Evolve Admin Link In Bread Crumb. ");
			}
			else{
				Reporters.failureReport("Clicking On Evolve Admin Link In Bread Crumb.", "Failed TO Clicki On Evolve Admin Link In Bread Crumb.");
			}
			Thread.sleep(medium);

			//click on View Edit User Profile link 
			if(click(ElsevierObjects.Admin_ViewEdit_UserProfile, "Click on View/Edit Evolve User PRofile")){
				Reporters.SuccessReport("Clicking On View/Edit Evolve User Profile link.", "Successfully Clicked On View/Edit User Profile Link.");
			}
			else{
				Reporters.failureReport("Clicking On View/Edit Evolve User Profile link.", "Failed To Click On View/Edit User Profile Link.");
			}
			Thread.sleep(medium);


			Map<String, String> values=readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData"));
			String userName=values.get("UserName");

			//driver.findElement(ElsevierObjects.Admin_SearchUser_UserName).sendKeys(userName);

			if(type(ElsevierObjects.Admin_SearchUser_UserName, userName, "Input UserNamed ")){
				Reporters.SuccessReport("Entering userName in View/Edit Evolve User Profile Page.", "Entered userName "+userName+" in View/Edit Evolve User Profile Page.");
			}
			else{
				Reporters.failureReport("Entering userName in View/Edit Evolve User Profile Page.", "Failed To Enter userName "+userName+" in View/Edit Evolve User Profile Page.");
			}      
			Thread.sleep(medium);
			if(click(ElsevierObjects.Admin_SearchUser_SearchButton, "Click on Search Button")){
				Reporters.SuccessReport("Clicking On Search Button After Entering Username.", "Successfully Clicked On Search Button.");
			}
			else{
				Reporters.failureReport("Clicking On Search Button After Entering Username.", "Failed To Click On Search Button.");
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.Admin_CourseParReport_Search_Results_Row2, "Click on Search Results")){
				Reporters.SuccessReport("Clicking On Username Link.", "Successfully Clicked On Username:"+userName+" Link.");
			}
			else{
				Reporters.failureReport("Clicking On Username Link.", "Failed To Click On Username:"+userName+" Link.");
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.parBtn, "Click on PAR Button")){
				Reporters.SuccessReport("Clicking On PAR button on the Edit User Profile page.", "Successfully Clicked On PAR button on the Edit User Profile page.</br>User is taken to the Manage Protected Access Rights table");
			}
			else{
				Reporters.failureReport("Clicking On PAR button on the Edit User Profile page.", "Failed To Click On PAR button on the Edit User Profile page.");
			}

			String str=getText(ElsevierObjects.enrollCourseId, "");
			String manageProtectedRedeemDate=getText(ElsevierObjects.ManageProtectedRedeemDate, "");
			Calendar currentdate = Calendar.getInstance();
			DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
			TimeZone obj = TimeZone.getTimeZone("CST");
			formatter.setTimeZone(obj);
			//System.out.println("Local:: " +currentdate.getTime());
			System.out.println("CST:: "+ formatter.format(currentdate.getTime()));
			String s = formatter.format(currentdate.getTime());

			//check for courseid
			if(str.equals(courseid) && manageProtectedRedeemDate.equals(s)){
				Reporters.SuccessReport("Verifying Student CourseID, Redemption Date in Manage Protected Access Rights table.", "Successfully Verified Student CourseID:"+courseid+", Redemption Date:"+manageProtectedRedeemDate+" Manage Protected Access Rights table.");
			}
			else{
				Reporters.failureReport("Verifying Student CourseID, Redemption Date in Manage Protected Access Rights table.", "Failed To Verify Student CourseID, Redemption Date in Manage Protected Access Rights table.");
			}

			Thread.sleep(medium);
		}catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}
		return flag;
	}
	//Update Account For Both KNO And VST Number
	public static boolean updateVSTandKNOAccount(String user, String name,String accessCode,String knoUser) throws Throwable{
		boolean flag = true; 

		String country=readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("Institution_cntry");
		String institute=readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("Institution_name");
		String street=readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("Institution_street");
		String town=readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("Institution_Town");
		String state=readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("Institution_state");
		String zip=readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("Institution_Postal");
		String phone=readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("Institution_phNum");
		String programType=readcolumns.twoColumns(0, 1,"UpdateAccountDetails", configProps.getProperty("TestData")).get("Program_type");
		String knoPassword=readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("Kno&VST_Pwd");
		try{

			if(user.equalsIgnoreCase("educator")){


				if(!selectByVisibleText(ElsevierObjects.evolve_Institution_Cntry_txt, country ,"Enter Institute Country Name")){
					flag=false;
				}
				Thread.sleep(low);
				
				if(!type(ElsevierObjects.evolve_Institution_state,state,"Enter Institution State ")){
					if(!selectByVisibleText(ElsevierObjects.evolve_Institution_state, state, "Enter Institution State ")){
						flag=false;
					}
				}
				
				Thread.sleep(low);
				
				if(!type(ElsevierObjects.evolve_Institution_city,town,"Enter Institute City")){
					flag=false;
				}
				Thread.sleep(low);
				
				if(!type(ElsevierObjects.evolve_Institution_name,institute ,"Enter Institute name")){
					flag=false;
				}
				Thread.sleep(low);
				
				if(!type(ElsevierObjects.evolve_Institution_street,street,"Enter Institute street")){
					flag=false;
				}
				Thread.sleep(low);
				
				if(!type(ElsevierObjects.evolve_Institution_Zipcode,zip,"Enter Institution postal")){
					flag=false;
				}
				Thread.sleep(low);
				
				if(!type(ElsevierObjects.evolve_Institution_Ph,phone,"Enter Institution Contact number")){
					flag=false;
				} 
				Thread.sleep(medium);
				
				if(!selectByVisibleText(ElsevierObjects.evolve_Programtype,programType,"program type")){
					flag=false;
				}

			}else{

				if(click(ElsevierObjects.student_chkInstution,"Click on NO Institution Check box")){
					Reporters.SuccessReport("Clicking On Not Affiliated Check box for "+user, "Successfully Clicked On Not Affiliated with Institution CheckBox.");
				}
				else{
					Reporters.failureReport("Clicking On Not Affiliated Check box for "+user, "Failed To Click On Not Affiliated with Institution CheckBox.");
				}
				Thread.sleep(medium);
			}

			//if there is no access code this block will be executed.....Billing Address
			if(accessCode.equalsIgnoreCase("false")){ 
				if(!type(ElsevierObjects.evolve_User_street,readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("User_StreetAddress"),"Enter user street address")){
					flag=false;
				}
				Thread.sleep(medium);
				if(!type(ElsevierObjects.evolve_User_City,readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("User_City"),"Enter user city name")){
					flag=false;
				}
				if(!selectByVisibleText(ElsevierObjects.evolve_User_State,readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("User_State"),"Enter user state name")){
					flag=false;
				}
				if(!type(ElsevierObjects.evolve_User_Postal,readcolumns.twoColumns(0, 1,"UpdateAccountDetails", configProps.getProperty("TestData")).get("User_Zip"),"Enter User Postal code")){
					flag=false;
				}
			}
			//if VST it has VST Security Question else KNO Number Will be Entered.
			if(name.equalsIgnoreCase("VST")){

				if(!type(ElsevierObjects.evolve_User_VSTPwd,readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("Kno&VST_Pwd"),"Enter VST password")){
					flag=false; 
				}
				Thread.sleep(low);
				if(!selectByValue(ElsevierObjects.evolve_Security_Question,readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("SecurityQst_value"),"")){
					flag=false;
				}
				if(!type(ElsevierObjects.evolve_Security_Answer,readcolumns.twoColumns(0, 1, "UpdateAccountDetails", configProps.getProperty("TestData")).get("SecurityQst_answer"),"Enter Security Answer")){
					flag=false; 
				} 
				Thread.sleep(low);
			}
			else{
				if(knoUser.equalsIgnoreCase("newuser")){

					if(type(ElsevierObjects.evolve_User_KnoPwd,knoPassword,"Enter Kno password")){
						Reporters.SuccessReport("Entering KNO Password.", "Successfully Entered KNO Password: "+knoPassword);
					}
					else{
						Reporters.failureReport("Entering KNO Password.", "Failed To Enter KNO Password: "+knoPassword);
					}
					Thread.sleep(low);
				}
			}

			if(isChecked(ElsevierObjects.evolve_User_chkbx, "Check box")){
				if(click(ElsevierObjects.evolve_User_submitbtn,"Click submit button")){
					Reporters.SuccessReport("Updating Account Information Of The "+user+".</br>Clicking On Submit Button.", "Successfully Entered Account Information.</br> Country : "+country+"<br/> Institute : "+institute+"<br/> Street : "+street+"<br/> Town : "+town+"<br> State : "+state+"<br/> Zip : "+zip+"<br/> Phone Number : "+phone+"<br> Program Type : "+programType+"<br/>Successfully Clicked On Submit Button.");
				}
				else{
					Reporters.failureReport("Updating Account Information Of The "+user+".</br>Clicking On Submit Button.", "Failed To Enter Account Information.</br>Failed To Click On Submit Button.");
				}
				Thread.sleep(medium);
			}
			else{
				if(!click(ElsevierObjects.evolve_User_chkbx, "Click check box")){
					flag=false;
				}
				Thread.sleep(medium);

				if(click(ElsevierObjects.evolve_User_submitbtn,"Click submit button")){
					Reporters.SuccessReport("Updating Account Information Of The "+user+".</br>Clicking On Submit Button.", "Successfully Entered Account Information.</br> Country : "+country+"<br/> Institute : "+institute+"<br/> Street : "+street+"<br/> Town : "+town+"<br> State : "+state+"<br/> Zip : "+zip+"<br/> Phone Number : "+phone+"<br> Program Type : "+programType+"<br/>Successfully Clicked On Submit Button.");
				}
				else{
					Reporters.failureReport("Updating Account Information Of The "+user+".</br>Clicking On Submit Button.", "Failed To Enter Account Information.</br>Failed To Enter The KnoPassword: "+knoPassword+".</br>Failed To Click On Submit Button.");
				}
			}
			Thread.sleep(medium);

			//for submit button check

			Thread.sleep(veryhigh);
			Thread.sleep(veryhigh);
			if(accessCode.equalsIgnoreCase("false")){
				if(!switchToFrameByLocator(ElsevierObjects.Student_register_frame, "Switch to frame")){
					flag=false;
				}
				Thread.sleep(medium);
				/*if(click(ElsevierObjects.Student_register_UseAdress_btn,"Click on use this address button")){
	                                  Reporters.SuccessReport("Clicking On USE THIS ADDRESS Button In Popup.", "Successfully Clicked On USE THIS ADDRESS Button In Popup.</br>Successfully Navigated To Credit Card Details Page.");
	                           }
	                           else{
	                                  Reporters.failureReport("Clicking On USE THIS ADDRESS Button In Popup.", "Failed to Click On USE THIS ADDRESS Button In Popup.</br>Failed to Navigate To Credit Card Details Page.");
	                           }
	                           Thread.sleep(medium);*/
				if(isElementPresent(ElsevierObjects.useThisAddressEducator)){
					if(click(ElsevierObjects.useThisAddressEducator, "Clicked On Use This Address Link.")){
						Reporters.SuccessReport("Click the Use This Address button.", "Successfully Clicked on the Use This Address button.");
					}else{
						Reporters.failureReport("Click the Use This Address button.", "Failed to Clicked on the Use This Address button.");
					}
					Thread.sleep(medium);
				}else{
					waitForVisibilityOfElement(ElsevierObjects.useThisAddressButton, "");

					if(click(ElsevierObjects.useThisAddressButton, "Clicked On Use This Address Link.")){
						Reporters.SuccessReport("Click the Use This Address button.", "Successfully Clicked on the Use This Address button.");
					}else{
						Reporters.failureReport("Click the Use This Address button.", "Failed to Clicked on the Use This Address button.");
					}



				}
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}


	/**Generic method for Request product click......
	 * 
	 * @return
	 * @throws Throwable
	 */
	//Common Logic for 9804,9805,9806,15575,15576,15577,15578,15579......
	public static boolean requestProduct() throws Throwable{
		boolean flag = true;
		try{

			requestProductPage_Price=getText(ElsevierObjects.Student_Product_Cost, "Get Product Cost");
			requestProductPage_Title=getText(ElsevierObjects.evolve_Product_titlebeforerequest,"get product title");
			requestProductPage_Isbn=getText(ElsevierObjects.evolve_verify_isbn, "Get Isbn number.");
			if(!javaClick(ElsevierObjects.Student_RequestProduct_btn,"Request this product now")){
				flag = false;
			}
			Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e);
		}
		return flag;  
	}

	/**Generic method for click on course PAR Report and search for course id
	 *
	 * @param iSBN
	 */
	public static boolean verifyCoursePARReport(String courseid,String Accesscode) throws Throwable{
		boolean flag = true;
		try{
			if(click(ElsevierObjects.lnkcoursePARReport, "Click on Course PAR Report link")){
				Reporters.SuccessReport("Clicking On Course PAR Report option in Evolve Admin Page. ", "Clicked On Course PAR Report Option In Evolve Admin Page.");
			}
			else{
				Reporters.failureReport("Clicking On Course PAR Report option in Evolve Admin Page. ", "Failed To Click On Course PAR Report Option In Evolve Admin Page.");
			}
			Thread.sleep(medium);

			//driver.findElement(ElsevierObjects.txtcoursid).sendKeys(courseid);

			if(type(ElsevierObjects.txtcoursid, courseid, "Input course id")){
				Reporters.SuccessReport("Entering Course ID in Course PAR report Page.", "Entered Course Id "+courseid+" in Course PAR report Page");
			}
			else{
				Reporters.failureReport("Entering Course ID in Course PAR report Page.", "Failed To Enter Course Id "+courseid+" in Course PAR report Page");
			}
			Thread.sleep(medium);

			if(click(ElsevierObjects.btncoursego, "Click on Go button")){
				Reporters.SuccessReport("Clicking On Go Button After Entering Course ID", "Clicked On Go Button After Entering Course ID.");
			}
			else{
				Reporters.failureReport("Clicking On Go Button After Entering Course ID", "Failed To Click On Go Button After Entering Course ID.");
			}
			Thread.sleep(medium);

			Map<String, String> values=readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData"));
			String userName=values.get("UserName");

			String str=getText(ElsevierObjects.enrollLONewUser, "");
			String PAR=getText(ElsevierObjects.enrollLOPAR, "");
			String redeemptionDate=getText(ElsevierObjects.enrollLOReedemption, "");
			//verify username exists

			Calendar currentdate = Calendar.getInstance();
			DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
			TimeZone obj = TimeZone.getTimeZone("CST");
			formatter.setTimeZone(obj);
			//System.out.println("Local:: " +currentdate.getTime());
			System.out.println("CST:: "+ formatter.format(currentdate.getTime()));
			String s = formatter.format(currentdate.getTime());

			if(Accesscode.equalsIgnoreCase("true")){
				String ComparePAR=accessCode;
				if(str.equals(userName) && PAR.equals(ComparePAR) && redeemptionDate.equals(s)){
					Reporters.SuccessReport("Verifying Student Username,PAR,Redeemption Date in Course PAR Report Page.", "Successfully Verified Student Username:"+userName+",PAR:"+PAR+",Redeemption Date:"+redeemptionDate);
				}
				else{
					Reporters.failureReport("Verifying Student Username,PAR,Redeemption Date in Course PAR Report Page.", "Failed To Verify Student Username,PAR,Reedemption Date in Course PAR Report Page.");
				}
			}
			else{
				String ComparePAR="ecommerce";
				if(str.equals(userName) && PAR.equals(ComparePAR) && redeemptionDate.equals(s)){
					Reporters.SuccessReport("Verifying Student Username,PAR,Redeemption Date in Course PAR Report Page.", "Successfully Verified Student Username:"+userName+",PAR:"+PAR+",Redeemption Date:"+redeemptionDate);
				}
				else{
					Reporters.failureReport("Verifying Student Username,PAR,Redeemption Date in Course PAR Report Page.", "Failed To Verify Student Username,PAR,Reedemption Date in Course PAR Report Page.");
				}
			}


		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}


	/**Generic method to Navigate Catalog>Honey pot> Enroll instructor's course
	 *Raja Dadi
	 * 
	 */
	public static boolean verifyHoneyPot() throws Throwable{
		boolean flag = true;
		try{
			Thread.sleep(medium);
			//driver.findElement(ElsevierObjects.catalog).sendKeys(Keys.ENTER);
			if(!click(ElsevierObjects.catalog, "Clicking Catalog Tab.")){
				flag = false;
			}
			Thread.sleep(medium);
			
			// none of this applies to the new design
			/*if(isElementPresent(ElsevierObjects.enrollHoneyPotImg)){
				Reporters.SuccessReport("Clicking On Catalog Tab.", "Successfully Clicked On Catalog Tab.");
			}
			else{
				Reporters.failureReport("Clicking On Catalog Tab.", "Failed To Click On Catalog Tab.");
			}
			Thread.sleep(medium);

			if(javaClick(ElsevierObjects.enrollHoneyPotImg, "Click on Honey Pot Image")){
				Reporters.SuccessReport("Clicking On Online Course Honey Pot.", "Successfully Clicked On Online Course Honey Pot.");
			}
			else{
				Reporters.failureReport("Clicking On Online Course Honey Pot.", "Failed To Click On Online Course Honey Pot.");
			}             
			Thread.sleep(high);
			waitForVisibilityOfElement(ElsevierObjects.enrollHoneyPotInstructorCourse, "");
			if(javaClick(ElsevierObjects.enrollHoneyPotInstructorCourse, "Click on enroll in instructors course")){
				Reporters.SuccessReport("Clicking On Enroll Your Course Link in Online Course Honeypot.", "Successfully Clicked On Enroll Your Course Link in Online Course Honey Pot.");
			}
			else{
				Reporters.failureReport("Clicking On Enroll Your Course Link in Online Course Honeypot.", "Failed To Click On Enroll Your Course Link in Online Course Honey Pot.");
			}             
			Thread.sleep(medium);*/
			
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}

		return flag;
	}

	public static void getStundentIntoYourCourse() throws Throwable{
		//readcolumns.twoColumns(col1, col2, configProps.getProperty("TestData")).get("student_CardNum"), path)
		try
		{
			b=true;
			click(ElsevierObjects.catalog, "Catalog button");
			
			// this section no longer applies to new design
			/*click(ElsevierObjects.ONLINE_COURSE, "'Online Course' Honey pot");
			Thread.sleep(low);
			click(ElsevierObjects.GET_STUDENT_INTO_YOUR_PATH,"'Get Student into your course' link  and User is brought to create roster page");*/
			
			click(ElsevierObjects.CLASS_ROSTER, "'Submitting your class Roster' link and User is taken to 'Submit your Course Roster' page");
			b=false;
			String verirfyText=getText(ElsevierObjects.verifyTextField, "");
			if((isElementPresent(ElsevierObjects.verifyTextField, "verify the 'Enter Course ID' text presence"))&&(verirfyText.toString()).contains("Enter your Course ID")&&isElementPresent(ElsevierObjects.verifyrosterfield, "Larger text area"))
			{
				Reporters.SuccessReport("Verify there is a text field labeled 'Enter your Course ID'", "Sucessfully verifies that,there is a textfield labeled as: "+verirfyText.toString()+" "+"and </br> verifies the presence of larger text field for entering roster information");
			}
			else
			{
				Reporters.failureReport("Verify there is a text field labeled 'Enter your Course ID'", "failed to verify the textFields");
			}
			Thread.sleep(medium);
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
		}
	}
	
	// Verifies that no adoption requests are found
	public static boolean verifyNoAdoptionRequest(String username) throws Throwable {
		
		boolean flag = true;
		
		try{
			
			if(click(ElsevierObjects.searchAR,"Adoption Requests")){
				Reporters.SuccessReport("Clicking On Search Adoption Requests.", "Successfully Clicked On Search Adoption Request Link.");
			}
			else{
				Reporters.failureReport("Clicking On Search Adoption Requests.", "Failed To Click On Search Adoption Request Link.");
			}
			if(!waitForElementPresent(ElsevierObjects.btndatesearch, "search button")){
				flag = false;
			}
			if(click(ElsevierObjects.rbtndate, "date Radio button")){
				Reporters.SuccessReport("Clicking On Todays Radio Button.", "Successfully Clicked On Todays Radio Button.");
			}
			else{
				Reporters.failureReport("Clicking On Todays Radio Button.", "Failed Clicked On Todays Radio Button.");
			}
			Thread.sleep(3000);

			if(!click(ElsevierObjects.btndatesearch_AR, "ToDay date Radio button")){
				flag = false;
			}
			selectByVisibleText(ElsevierObjects.selectdays, "Today", "Select Today's locator");

			if(type(ElsevierObjects.Adoption_userId, username, "Adoption search User Id")){
				Reporters.SuccessReport("Entering UserID In Search Results Page..", "Successfully Entered UserID:"+getAccountDetailsUserName);
			}
			else{
				Reporters.failureReport("Entering UserID In Search Results Page..", "Failed Enter UserID:"+getAccountDetailsUserName);
			}

			if(!waitForElementPresent(ElsevierObjects.btndatesearch_AR, "search button")){
				flag = false;
			}

			Thread.sleep(3000);

			if(!click(ElsevierObjects.Searchon, "search button")){
				flag = false;
			}
			
			if(!waitForElementPresent(ElsevierObjects.noAdoptionsFoundMessage, "'No adoptions found' message.")){
				flag = false;
			}
			
		}
		
		catch (Exception e){
			System.out.println(e.getMessage());
		}
		
		return flag;
	}
	
	//Common Business logic for Tc-9800,Tc-9801,8798,9799

	public static boolean clickAdoptionRequest(String username) throws Throwable{
		boolean flag=true;
		try{
			if(click(ElsevierObjects.searchAR,"Adoption Requests")){
				Reporters.SuccessReport("Clicking On Search Adoption Requests.", "Successfully Clicked On Search Adoption Request Link.");
			}
			else{
				Reporters.failureReport("Clicking On Search Adoption Requests.", "Failed To Click On Search Adoption Request Link.");
			}
			if(!waitForElementPresent(ElsevierObjects.btndatesearch, "search button")){
				flag = false;
			}
			if(click(ElsevierObjects.rbtndate, "date Radio button")){
				Reporters.SuccessReport("Clicking On Todays Radio Button.", "Successfully Clicked On Todays Radio Button.");
			}
			else{
				Reporters.failureReport("Clicking On Todays Radio Button.", "Failed Clicked On Todays Radio Button.");
			}
			Thread.sleep(3000);

			if(!click(ElsevierObjects.btndatesearch_AR, "ToDay date Radio button")){
				flag = false;
			}
			selectByVisibleText(ElsevierObjects.selectdays, "Today", "Select Today's locator");

			if(type(ElsevierObjects.Adoption_userId, username, "Adoption search User Id")){
				Reporters.SuccessReport("Entering UserID In Search Results Page..", "Successfully Entered UserID:"+getAccountDetailsUserName);
			}
			else{
				Reporters.failureReport("Entering UserID In Search Results Page..", "Failed Enter UserID:"+getAccountDetailsUserName);
			}

			if(!waitForElementPresent(ElsevierObjects.btndatesearch_AR, "search button")){
				flag = false;
			}

			Thread.sleep(3000);

			if(!click(ElsevierObjects.Searchon, "search button")){
				flag = false;
			}
			if(!waitForElementPresent(ElsevierObjects.lnkorderedAR, "orederd AR")){
				flag = false;
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	//common BUssiness Logic for Tc-15235,15224  
	public static boolean maintainProduct() throws Throwable{
		boolean flag=true;
		try{
			if(!click(ElsevierObjects.admin_MaintainProduct_lnk,"click on maintain product link")){
				flag=false;
			}
			Thread.sleep(medium);
			Kno_Isbn=readcolumns.twoColumns(0, 1,"Tc-15228",configProps.getProperty("TestData")).get("Product_Kno_AccessCode");

			if(!type(ElsevierObjects.admin_MaintainProduct_Knotxt,Kno_Isbn,"Enter Kno number in product page")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.admin_MaintainProduct_Submit,"Click on search button")){
				flag=false;
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.MaintainPrdct_prdctSerachReslut_isbn,"Click on isbn num in product result page")){
				Reporters.SuccessReport("Clicking On Maintain Product Link And Searching For The ISBN: "+Kno_Isbn, "Successfully Clicked On Maintain Product Page Link.</br>Successfully Searched For ISBN: "+Kno_Isbn);
			}
			else{
				Reporters.failureReport("Clicking On Maintain Product Link And Searching For The ISBN: "+Kno_Isbn,"Failed To Click On Maintain Product Page Link.</br>Failed To Search For ISBN: "+Kno_Isbn);
			}
			Thread.sleep(medium);

			admin_Producttitle=getText(ElsevierObjects.MaintainPrdct_prdctSerach_title,"product title");
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	//common BUssiness Logic for Tc-15235,15224,15225,15228,15236,15237
	public boolean createAccessCode() throws Throwable{
		boolean flag=true;
		try{
			if(!click(ElsevierObjects.createAccessCode, "Click on create access code")){
				flag=false;
			}
			Thread.sleep(medium);

			protectionID1=getText(By.xpath(".//*[@id='protectionschemeselectedid']"), "Protection Sheme ID");
			Random ra = new Random( System.currentTimeMillis() );
			Date today = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat ("MMddyyyy");
			String CodeSetName = readcolumns.twoColumns(0, 1, "Tc-15228", configProps.getProperty("TestData")).get("CodeSetName")+Integer.toString((1 + ra.nextInt(2)) * 100 + ra.nextInt(10000)) + "_" + sdf.format(today);
			EvolveCommonBussinessFunctions.ACCESS_CODE =CodeSetName;
			ReadingExcel.updateCellInSheet(1,4,configProps.getProperty("TestData"), "TC-15590", CodeSetName);

			//ReadingExcel.updateCellValue(2, 1, configProps.getProperty("TestData"), 17);
			if(!type(ElsevierObjects.CreateAccessCode_codesetname, CodeSetName , "Code set name")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.CreateAccessCode_codeNumber, readcolumns.twoColumns(0, 1, "Tc-15228", configProps.getProperty("TestData")).get("CodeSetNumber"), "Code set number")){
				flag=false;
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.CreateAccessCode_Submit, "Click on Create access code submit button")){
				Reporters.SuccessReport("Creating AccessCode.", "Successfully Created access code.</br>AccessCode Set Name Is: "+CodeSetName);
			}
			else{
				Reporters.failureReport("Creating AccessCode.", "Failed To Create access code.");

			}
			Thread.sleep(veryhigh);
			ImplicitWait();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	//common for 15225,15235,15224
	public static boolean adminAccessCodeSearch() throws Throwable{
		boolean flag=true;
		try{
			if(!click(ElsevierObjects.Admin_Search_AccessCodeLnk, "Click on Search access code link")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.Admin_Seach_Code, accessCode, "Enter access code")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Admin_Search_Submit, "Click on Access code submit button")){
				flag=false;
			}
			Thread.sleep(medium);
			//String status=getText(ElsevierObjects.admin_accesscode_status, "Get Access Code Status.");
			String AccessCodeStatusInAdmin=getText(ElsevierObjects.admin_accesscode_status, "Get AccessCode Status.");
			String reedemStatus=readcolumns.twoColumns(0, 1, "Tc-15228", configProps.getProperty("TestData")).get("AcessCodeStatus");
			if(AccessCodeStatusInAdmin.trim().contains(reedemStatus.trim())){
				Reporters.SuccessReport("Verifying AccessCode Status In Admin.", "Successfully Clicked On Search Access Code Link.</br>Successfully Verified AccessCode Status: "+AccessCodeStatusInAdmin);
			}
			else{
				Reporters.failureReport("Verifying AccessCode Status In Admin.", "Failed To Click On Search Access Code Link.</br>Failed To Verify AcessCode Status.");
			}
			Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	public boolean anonymousUserKnoSearch() throws Throwable{
		boolean flag=true;
		try{
			Thread.sleep(medium);
		    driver.switchTo().defaultContent();
			
			Thread.sleep(medium);
			if(click(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
				Reporters.SuccessReport("Clicking On Evolve Catalog Link.", "Clicked On Evolve Catalog Link And Navigated To Honey Pot Page.");
			}
			else{
				Reporters.failureReport("Clicking On Evolve Catalog Link.", "Failed To Click On Evolve Catalog Link.");
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.txtproductsearch,Kno_Isbn, "Enter access Kno num")){
				flag=false;
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.gobutton, "Click on search go button")){
				Reporters.SuccessReport("Entering KNO ISBN In Search Box.", "Entered KNO ISBN : "+Kno_Isbn+" in Search Box And Clicked On Go Button.</br>User Is Navigated To Product Page.");
			}
			else{
				Reporters.failureReport("Entering KNO ISBN In Search Box.", "Failed To Enter KNO ISBN : "+Kno_Isbn+" in Search Box.</br>Failed To Navigate To Product Page.");
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.Student_RequestProduct_btn, "Click on register now button")){
				Reporters.SuccessReport("Clicking On Register Product Button And Navigating to MyCart Page.", "Clicked On Register Product Button.</br>Navigated To My Cart Page.");
			}
			else{
				Reporters.failureReport("Clicking On Register Product Button And Navigating to MyCart Page.", "Failed To Click On Register Product Button.</br>Failed To Navigate To My Cart Page.");
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.access_apply_chkbox,"Click on I have access code radio button")){
				flag=false;
			}
			Thread.sleep(medium);
			System.out.println();
			String invalidAccessCode=readcolumns.twoColumns(0, 1,"Tc-15228", configProps.getProperty("TestData")).get("invalidaccessCode");
			if(!type(ElsevierObjects.accessCode_type,invalidAccessCode, "Enter invalid access code")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.accessCode_submit, "Click on Access code apply button")){
				flag=false;
			}
			Thread.sleep(medium);
			String accessCodeErrorMssg=readcolumns.twoColumns(0, 1,"Tc-15228", configProps.getProperty("TestData")).get("accessCodeError");
			if(verifyText(ElsevierObjects.accessCode_Verify, accessCodeErrorMssg, "Verify the error message")){
				Reporters.SuccessReport("Clicking On Access Code Radio Button And Entering Invalid AccessCode in AcessCode TextBox.</br> Verifying Error Message.", "Successfully Clicked On AccessCode Radio Button.</br>Entered AcessCode:"+invalidAccessCode+" in AccessCode Tesxt Box.</br>Verified Error Message:"+accessCodeErrorMssg);
			}
			else{
				Reporters.failureReport("Clicking On Access Code Radio Button And Entering Invalid AccessCode in AcessCode TextBox.</br> Verifying Error Message.", "Failed To Click On AccessCode Radio Button.</br>Failed To Enter AcessCode in AccessCode Text Box.");
			}
			Thread.sleep(medium);
			if(!type(ElsevierObjects.accessCode_type, accessCode, "Enter valid access code")){
				flag=false;
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.accessCode_submit, "Click on Access code apply button")){
				Reporters.SuccessReport("Entering Valid AccessCode in AccessCode Textbox And Clicking On Apply Button.", "Successfully Entered AccessCode:"+accessCode+" in AccessCode Textbox.</br>Successfully Clicked On Apply Button.</br>Page Refreshed After Accesscode Applied.");
			}
			else{
				Reporters.failureReport("Entering Valid AccessCode in AccessCode Textbox And Clicking On Apply Button.", "Failed To Enter AccessCode.</br> Failed To Click On Apply Button.");
			}
			Thread.sleep(high);
			Mycartproduct_price=getText(ElsevierObjects.evolve_Product_priceAfterRequest, "Product price");
			if(Mycartproduct_price.contains(ExpectedPrice)){
				Reporters.SuccessReport("Verifying Price In My Cart Page After Applying AccessCode.", "Successfully Verified Price:"+Mycartproduct_price+" After Applying Accesscode.");
			}
			else{
				Reporters.failureReport("Verifying Price In My Cart Page After Applying AccessCode.", "Failed To Verify Price After Applying AccessCode.");
			}
			if(click(ElsevierObjects.evolve_checkout_btn, "Click on reedem checkout button")){
				Reporters.SuccessReport("Clicking On Checkout Button in MyCart Page And Navigating to Update Account Page.", "Clicked On Checkout Button In Mycart Page.</br>Successfully Navigated To Update Account Page.");
			}
			else{
				Reporters.failureReport("Clicking On Checkout Button in MyCart Page And Navigating to Update Account Page.", "Failed To Click On Chechout Button.</br>Failed To Navigate To ");
			}
			Thread.sleep(medium);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	//common for 15225,15235,15224
	public static boolean reLogingForAccessCodeRedeem() throws Throwable{
		boolean flag = true;
		try{
			driver.manage().deleteAllCookies();
			Thread.sleep(medium);
			if(!launchUrl(configProps.getProperty("URL4"))){
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.student_login,"Clicked On student LogIn")){
				flag = false;
			}
			Thread.sleep(medium);
			String StudentUserName=readcolumns.twoColumns(0, 1, "Tc-15228", configProps.getProperty("TestData")).get("StudentUser");
			if(!type(ElsevierObjects.email,StudentUserName,"Email")){
				flag = false;
			}
			Thread.sleep(medium);
			String StudentPassword=readcolumns.twoColumns(0, 1, "Tc-15228", configProps.getProperty("TestData")).get("StudentPassword");
			if(!type(ElsevierObjects.password,StudentPassword,"Password")){
				flag = false;
			}
			Thread.sleep(medium);
			if(click(ElsevierObjects.submit,"Clicked on Login Button")){
				Reporters.SuccessReport("Login As Student User:"+StudentUserName, "Successfully Logged in As Student User: "+StudentUserName);
			}
			else{
				Reporters.failureReport("Login As Student User:"+StudentUserName, "Failed To Login As Student User:"+StudentUserName);
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
				flag = false;
			}
			Thread.sleep(high);
			/*if(!click(ElsevierObjects.evolve_Pageburst,"Click on evolve page burst")){
				flag=false;
			}
			Thread.sleep(high);
			if(click(ElsevierObjects.evolve_Pageburst_Reedemlnk,"Click on Redeem Access code link")){
				Reporters.SuccessReport("Clicking On Evolve Catalog Link And Clicking On Redeem Access Code link Under Pageburst Honey Pot.", "Successfully Clicked On Evolve Catalaog Link.</br>Navigated to Honey Pot Page.</br>Successfully Clicked On Redeem Access Code Link Under Page Burst Honey Pot.</br>Navigated To Page Burst Page. ");
			}
			else{
				Reporters.failureReport("Clicking On Evolve Catalog Link And Clicking On Redeem Access Code link Under Pageburst Honey Pot.","Failed To Click On Evolve Catalaog Link.</br>Failed To Navigate to Honey Pot Page.</br>Failed To Click On Redeem Access Code Link Under Page Burst Honey Pot.</br>Failed To Navigate To Page Burst Page. ");
			}
			Thread.sleep(medium);*/
			if(!type(ElsevierObjects.evolve_Reedemlnk_AccessCode, accessCode ,"Enter Access code")){
				flag=false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.evolve_AccessCode_Submitbtn,"Click on Access code submit button")){
				flag=false;
			}
			Thread.sleep(medium);
			String errorMessage=getText(ElsevierObjects.AccessCode_Error_Msg, "Get Error Message Of Access Code.");
			if(waitForElementPresent(ElsevierObjects.AccessCode_Error_Msg, "Wait for error message.")){
				Reporters.SuccessReport("Entering AccessCode And Verifying The Error Message", "Successfully Entered Access code: "+accessCode+"</br>Successfully Clicked on Access code Submit Button.</br>Successfully Fetched Access code Error Message: "+errorMessage);
			}
			else{
				Reporters.failureReport("Entering AccessCode And Verifying The Error Message", "Failed To Enter Access code: "+accessCode+"</br>Failed To Click on Access code Submit Button.");
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	public static boolean createAnAccountWithEmptyFields(String user,String page) throws Throwable{
		boolean flag=true;
		try{
			Thread.sleep(medium);
			if(page .equalsIgnoreCase( "splash")){
				if(click(ElsevierObjects.evolve_createNewUser,"Create new account")){
					Reporters.SuccessReport("Clicking On Create New Account Link In Main Page.","Successfully Clicked On Create New Account Link In Main Page.</br>Successfully Navigated To Create New Account Pop Up.");
				}
				else{
					Reporters.failureReport("Clicking On Create New Account Link In Main Page.", "Failed To Click On Create New Account Link In Main Page.</br>Failed To Navigate To Create New Account Pop Up.");
				}
				Thread.sleep(high);
			}
			else{
				if(!click(ElsevierObjects.student_login,"Click on login button.")){
					flag=false;
				}
				Thread.sleep(high);
				if(click(ElsevierObjects.createAnAccount_lnk, "Click on Create An Account link.")){
					Reporters.SuccessReport("Clicking On Create New Account Link.","Successfully Clicked On Create New Account Link.</br>Successfully Navigated To Create New Account Pop Up.");
				}
				else{
					Reporters.failureReport("Clicking On Create New Account Link.", "Failed To Click On Create New Account Link.</br>Failed To Navigate To Create New Account Pop Up.");
				}
				Thread.sleep(high);
			}
			Thread.sleep(high);
			//String name=driver.getWindowHandle();
			//switchToFrameByIndex(o);

			if(!switchToFrameByLocator(ElsevierObjects.evolve_newAcount_frame,"Switch to frame")){
				flag=false;
			}
			Thread.sleep(high);
			/*if(!waitForElementPresent(ElsevierObjects.evolve_newAcount_frame, "Wait for Frame")){
    	                            flag=false;
    	                           }*/

			//     Thread.sleep(high);
			if(user.equalsIgnoreCase("educator") && page.equalsIgnoreCase("educatorpage")){

				if(isChecked(ElsevierObjects.faculty_radio_btn, "Checking Faculty radio button")){

				}
			}
			else{
				if(!isChecked(ElsevierObjects.createNewAccnt_studentRadioBtn, "Check whether student radio button is checked or not")){
					flag=false;
				}
			}
			if(!isElementPresent1(ElsevierObjects.evolve_newAccount_firstname, "first name textbox")){
				flag=false;
			}
			Thread.sleep(high);
			if(!isElementPresent1(ElsevierObjects.evolve_newAcount_Lastname, "Last name textbox")){
				flag=false;
			}
			Thread.sleep(high);
			if(!isElementPresent1(ElsevierObjects.evolve_newAcount_Email, "Email textbox")){
				flag=false;
			}
			Thread.sleep(high);
			if(!isElementPresent1(ElsevierObjects.evolve_newAcount_Pwd, "Password textbox")){
				flag=false;
			}
			Thread.sleep(high);
			if(!isElementPresent1(ElsevierObjects.evolve_newAcount_ConfirmPwd, "Confirm Password textbox")){
				flag=false;
			}
			Thread.sleep(high);
			/*if(isChecked(ElsevierObjects.evolve_newAcount_Chkbx, "Check box is Checkmarked")){
    	                            flag=false;
    	                           }*/
			if(isEnabled(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
				Reporters.SuccessReport("Verifying Create New Account Pop Up Elements.", "Successfully verified Student Radio Button.</br>Successfully Verified FirstName,LastName,EmailAdress,Password,Confirm Password Text Boxes.</br>Successfully Verified CheckBox.</br>Submit Button is Enabled.");
			}
			else{
				Reporters.failureReport("Verifying Create New Account Pop Up Elements.", "Failed To verify Student Radio Button.</br>Failed To Verify FirstName,LastName,EmailAdress,Password,Confirm Password Text Boxes.</br>Failed To Verify checkBox.</br>Failed To verify Submit Button.");
			}
			Thread.sleep(high);
			if(page.equalsIgnoreCase("splash")){

				if(user.equalsIgnoreCase("educator")){

					if(isNotChecked(ElsevierObjects.faculty_radio_btn, "Checking Faculty radio button.")){

						if(click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
							Reporters.SuccessReport("Clicking On Faculty Radio Button.</br>Clicking On Submit Button.", "Succesfully Clicked on Radio Button.</br>Successfully Clicked On Submit button.");
						}
						else{
							Reporters.failureReport("Clicking On Faculty Radio Button.</br>Clicking On Submit Button.", "Failed To Click on Radio Button.</br>Failed To Click On Submit button.");
						}
					}
					else{
						if(!click(ElsevierObjects.faculty_radio_btn,"Faculty radio button")){
							flag=false;
						}
						Thread.sleep(medium);
						if(click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
							Reporters.SuccessReport("Clicking On Faculty Radio Button.</br>Clicking On Submit Button.", "Succesfully Clicked on Radio Button.</br>Successfully Clicked On Submit button.");
						}
						else{
							Reporters.failureReport("Clicking On Faculty Radio Button.</br>Clicking On Submit Button.", "Failed To Click on Radio Button.</br>Failed To Click On Submit button.");
						}
						Thread.sleep(medium);
					}
					Thread.sleep(high);
				}
				else{
					if(click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
						Reporters.SuccessReport("Clicking On Submit Button.", "Successfully Clicked On Submit button.");
					}
					else{
						Reporters.failureReport("Clicking On Submit Button.", "Failed To Click On Submit button.");
					}
				}

			}
			else{
				if(click(ElsevierObjects.evolve_newAcount_Submit_btn,"Submit button")){
					Reporters.SuccessReport("Clicking On Submit Button.", "Successfully Clicked On Submit button.");
				}
				else{
					Reporters.failureReport("Clicking On Submit Button.", "Failed To Click On Submit button.");
				}
			}
			Thread.sleep(medium);
			String emptyFieldError=readcolumns.twoColumns(0, 1, "Tc-9798", configProps.getProperty("TestData")).get("EmptyFieldsError");
			if(verifyText(ElsevierObjects.registration_form_error,emptyFieldError , "Verify the error message")){
				Reporters.SuccessReport("Verifying Error Message Without Entering Any Information.", "Successfully Verified Error Message: "+emptyFieldError);
			}
			else{
				Reporters.SuccessReport("Verifying Error Message Without Entering Any Information.", "Failed To Verify Error Message: "+emptyFieldError);

			}
			Thread.sleep(medium);
			//driver.switchTo().window(name);
			/*if(!click(ElsevierObjects.frame_close, "Click on close frame button.")){
    	                             flag=false;
    	                            }*/
			Thread.sleep(medium);
		}

		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}

	public static boolean verifyStatus(String lmsvalue,String URL,String chkbx,String key,String Status,String downloadURL,String KeyValue,String username,String pwd) throws Throwable{

		boolean flag=true;

		try
		{

			if(!isElementPresent(ElsevierObjects.adoptionRequest_DownloadURL, "Downd load URL Option is not avialble"))
			{return false;}
			System.out.println("lmsvalue:"+lmsvalue);
			System.out.println("adoptionRequest_Format"+adoptionRequest_Format);
			if(getAccountDetailsFirstName.contains(adoptionRequest_FirstName) && getAccountDetailsLastName.contains(adoptionRequest_LastName) && getAccountDetailsEmail.contains(adoptionRequest_Email) && getAccountDetailsInstitution.contains(adoptionRequest_Institution) && getAccountDetailsPhone.contains(adoptionRequest_Phone) && username.contains(adoptionRequest_Username) && pwd.contains(adoptionRequest_Password)){
				if(title.contains(adoptionRequest_producttitle) && Isbn.contains(adoptionRequest_Isbn) && author.contains(adoptionRequest_Author) && productType.contains(adoptionRequest_ProductType) && adoptionRequest_Format.contains(lmsvalue)){
					System.out.println("I am in if block...........");
					if(!verifyText(ElsevierObjects.adoptionRequestStatus, compareStatus, "Verify request status.")){
						flag=false;
					}
				}
			} 
			if(!type(ElsevierObjects.adoptionRequest_DownloadURL,"","Enter null value.")){
				flag=false;
			}
			Thread.sleep(high);
			if(!selectByVisibleText(ElsevierObjects.adoptionRequestStatus, Status, "Change status to fullfilled.")){
				flag=false;
			}
			Thread.sleep(medium);    
			if(!click(ElsevierObjects.adoptionRequest_Save,"Click on Save button.")){
				flag=false;
			}
			Thread.sleep(high);
			errorAlert();		
			Thread.sleep(medium);
			if(URL.equalsIgnoreCase("true")){
				if(!type(ElsevierObjects.adoptionRequest_DownloadURL, downloadURL, "Enter URL in download URL textbox.")){
					flag=false;
				}
				if(!click(ElsevierObjects.adoptionRequest_Save,"Click on Save button.")){
					flag=false;
				}
				Thread.sleep(medium);
			}
			if(chkbx.equalsIgnoreCase("true")){
				if(!click(ElsevierObjects.adoptionRequestChkBx,"CLick on checkbox.")){
					flag=false;
				}
				/*else
				{Reporters.SuccessReport("Selecting Confirmation Check Box", "Successfully Selected Confirmation Check Box of 'I have fulfilled this school hosted adoption'");}
				if(!type(ElsevierObjects.adoptionRequest_DownloadURL, downloadURL, "Enter URL in download URL textbox.")){
					flag=false;
				}*/
				if(!click(ElsevierObjects.adoptionRequest_Save,"Click on Save button.")){
					flag=false;
				}
				Thread.sleep(medium);
			}
			if(key.equalsIgnoreCase("true")){
				if(!type(ElsevierObjects.adoptionRequest_DownloadURL, downloadURL, "Enter URL in download URL textbox.")){
					flag=false;
				}
				if(!click(ElsevierObjects.adoptionRequest_Save,"Click on Save button.")){
					flag=false;
				}
				errorAlert();
				if(!type(ElsevierObjects.adoptionRequestDownloadKey, KeyValue, "Enter key value.")){
					flag=false;
				}

				if(!click(ElsevierObjects.adoptionRequest_Save,"Click on Save button.")){
					flag=false;
				}
				Thread.sleep(medium);
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.emailPopup,"Click on Send mail button on popup.")){
				flag=false;
			}
			Thread.sleep(high);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;
	}
	
    public static boolean HesiEmailVerification() throws Throwable{
        try
        {
                        boolean flag = true; 

                        String parentHandle = driver.getWindowHandle();
                        for (String winHandle : driver.getWindowHandles()) {
                                        driver.switchTo().window(winHandle);
                                        launchUrl(configProps.getProperty("EmailURL"));
                                        Thread.sleep(medium);
                                        type(ElsevierObjects.emailaddress,configProps.getProperty("verifyemail_username"),"Enter email id");
                                        Thread.sleep(medium);
                                        type(ElsevierObjects.emailpassword,configProps.getProperty("verifyemail_password"),"Enter password");
                                        Thread.sleep(medium);
                                        click(ElsevierObjects.emaillogin, "Click on Login Button.");
                                        Thread.sleep(medium);
                                        click(ElsevierObjects.email_Icon,"Click on Email icon.");
                                        Thread.sleep(medium);
                                        click(ElsevierObjects.email_dropdown,"Click on Dropdown.");
                                        Thread.sleep(medium);
                                        click(ElsevierObjects.email_dropdown_Fromchk,"Click on From check box.");
                                        Thread.sleep(medium);
                                        click(ElsevierObjects.email_dropdown_Tochk,"Click on To checkbox.");
                                        Thread.sleep(medium);
                                        type(ElsevierObjects.email_SearchBox,getAccountDetailsEmail,"Enter the email id.");
                                        Thread.sleep(medium);
                                        click(ElsevierObjects.email_SearchIcon,"Click on search icon.");
                                        Thread.sleep(veryhigh);
                                        Thread.sleep(veryhigh);
                                        switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
                                        String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
                                        //Username=readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData")).get("UserName");
                        //            Password=readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData")).get("Password");
                                        String Username1=credentials[0];
                                        String Password1=credentials[1];
                                        if(emailBody.contains(Username1) && emailBody.contains(Password1))
                                        {
                                                        driver.switchTo().defaultContent();
                                                        Thread.sleep(medium);
                                                        if(click(ElsevierObjects.email_logout,"Click on logout."))
                                                        {
                                                                        Reporters.SuccessReport("Verifying User details In Email Body.</br>Clicking On Logout Button.","Successfully Verified Username: "+Username+"</br>Password: "+Password+"</br>Successfully Clicked On Logout Button </br></br> Email Body Is: "+emailBody+"</br>");
                                                        }else{
                                                                        Reporters.failureReport("Verifying User details In Email Body.</br>Clicking On Logout Button.", "Failed To Verify User Details.</br>Failed To Click On Logout Button.  Email Body Is: "+emailBody+"</br>");
                                                        }
                                        }
                                        else{
                                                        Reporters.failureReport("Verifying User details In Email Body.", "Failed To Verify User Details in Email Body.");
                                        }              
                                        Thread.sleep(medium);
                                        driver.switchTo().window(parentHandle);
                                        launchUrl(configProps.getProperty("URL"));
                                        /*
                                        writeReport(EvolveCommonBussinessFunctions.existingUserLogin("Student",Username,Password), "Launch Evolve Cert URL And Login As Existing Educator: "+Username, 
                                                                        "Successfully Launched Evolve Cert URL.</br>Successfully Logged In as Educator. "+Username,
                                                                        "Failed to Launch Evolve Cert URL.</br>Failed to Login As Educator. "+Username);
                                        */
                                        if(click(ElsevierObjects.Myevolve,"Click on MyEvolve link")){
                                                        Reporters.SuccessReport("Click on My Evolve","Successfully clicked on My Evolve");
                                        }else{
                                                        Reporters.failureReport("Click on My Evolve","Failed to click on My Evolve");
                                        }
                                        Thread.sleep(low);
                                          HESI_BusinessFunction.verifyProducttypeandclick("Student Access");
                                          Thread.sleep(veryhigh);

                                          String ExpectedText="HESI Faculty Access";


                                          String actualText=driver.findElement(By.xpath(".//label[@class='welcomeUse']")).getText();
                                          String currenturl=driver.getCurrentUrl();
                                          writeReport(CompareString(ExpectedText, actualText, "Validating Values in New browser "),"Navigating to HESI URL","Navigating to HESI URL is successful"+currenturl,"Navigating to HESI URL is failed or validation failed"+currenturl);
                                          Thread.sleep(3000);
                                          /*
                                        if(click(ElsevierObjects. Hesi_Student_Access,"Click on Hesi Student Access link")){
                                                        Reporters.SuccessReport("Click on HESI StudentAccess link","Successfully clicked on HESI StudentAccess link");
                                        }else{
                                                        Reporters.failureReport("Click on HESI StudentAccess link","Failed to click on HESI StudentAccess link");
                                        }
                                        Thread.sleep(low);
                                        String Url = ReadingExcel.columnDataByHeaderName("Url","TC-8567",configProps.getProperty("TestData"));
                                        String CurrentUrl=driver.getCurrentUrl();

                                        if(CurrentUrl.contains(Url)){
                                                        Reporters.SuccessReport("Verify The user is taken to HESI Url","Successfully URL is verified");
                                        }else{
                                                        Reporters.failureReport("Verify The user is taken to HESI Url","Failed to verify URL");
                                        }*/
                        }              
                        return flag;}
        catch(Exception e){return false;}
}              


}
