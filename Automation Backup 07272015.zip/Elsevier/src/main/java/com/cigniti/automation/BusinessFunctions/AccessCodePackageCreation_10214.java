package com.cigniti.automation.BusinessFunctions;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.datadriven.ReadResourceData;

public class AccessCodePackageCreation_10214 extends EvolveCommonBussinessFunctions{
	
	//Click on the Access Code Package link and verify	
	static String isbnPackageName=ReadingExcel.keyValueBasedOnCommonValue(testDataPath, "GenericValue", 0, 1, 2, "TC-10214").get("ISBNPkgName");
	
	public static String ISBNPkg;
	public static boolean accessCodePackage() throws Throwable{
		boolean flag = true;
		try{
			Thread.sleep(medium);
			if(!click(ElsevierObjects.Accesscodelink, "Add Access Code Package")){
				flag = false;
			}
	
			String breadCrumb=getText(ElsevierObjects.breadcrumb,"Get Bread Crumb Text.");
			if(isElementPresent(ElsevierObjects.breadcrumb, "Bread Crumb - Evolve Admin > Add Access Code Package")){
				Reporters.SuccessReport(ReadResourceData.getResourceData("TC-10214-19", "NA"), ReadResourceData.getResourceData("TC-10214-20", breadCrumb));
				flag = true;
			}else{
				Reporters.failureReport(ReadResourceData.getResourceData("TC-10214-19", "NA"), ReadResourceData.getResourceData("TC-10214-20", breadCrumb));
				flag=false;
			}
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
		}
		return flag;
	}

	public static boolean verifyCreatePackage(String testdata) throws Throwable{
		boolean flag = true;
		try{
		String str=driver.findElement(ElsevierObjects.verifyISBNtextenable).getAttribute("disabled");

		Reporters.SuccessReport(ReadResourceData.getResourceData("TC-10214-21", "NA"), ReadResourceData.getResourceData("TC-10214-22", str));


		if(!type(ElsevierObjects.PackageName, testdata, "Input Package Name ")){
			Thread.sleep(medium);
			flag = false;
		}
		if(!click(ElsevierObjects.savebutton, "Click on Save Button")){
			Thread.sleep(medium);
			flag = false;
		}
		Thread.sleep(medium);
		if(!Alert()){
			flag = false;
		}
		driver.findElement(ElsevierObjects.PackageName).clear();
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
		}
		return flag;

	}

	public static boolean verifyPackageNametxtBox() throws Throwable{
		boolean flag = true;
		try{
			String ISBNPkgName=ReadingExcel.keyValueBasedOnCommonValue(testDataPath, "GenericValue", 0, 1, 2, "TC-10214").get("ISBNPkgName");
			if(type(ElsevierObjects.PackageName, ISBNPkgName, "Input Package Name ")){
				Reporters.SuccessReport(ReadResourceData.getResourceData("TC-10214-23", ISBNPkgName), ReadResourceData.getResourceData("TC-10214-24", ISBNPkgName));
				flag = true;
			}else{
				Reporters.failureReport(ReadResourceData.getResourceData("TC-10214-23", ISBNPkgName), ReadResourceData.getResourceData("TC-10214-25", ISBNPkgName));
				flag=false;
			}

			ReadingExcel re=new ReadingExcel();


			
			List<String> testdata1=re.getDataToList(testDataPath, "RetestingData", 0, 1, "TC-10214");
			for(String testString : testdata1){

				Thread.sleep(medium);
				if(type(ElsevierObjects.PackageISBN, testString, "Package ISBN")){
					Reporters.SuccessReport("Enter into the ISBN Package  : "+testString, "ISBN Package is Entered into ISBN Package Name Text Box : "+testString);
					flag = true;
				}else{
					Reporters.failureReport("Enter into the ISBN Package  : "+testString, "ISBN Package is failed to Entered into ISBN Package Name Text Box : "+testString);
					flag=false;
				}

				if(!click(ElsevierObjects.savebutton, "Click on Save Button")){
					Thread.sleep(medium);
					flag = false;
				}System.out.println();
				Thread.sleep(medium);
				if(!Alert()){
					flag = false;
				}
			}
		}catch(Exception e){
			System.out.println("exception occurred");}
		return flag;

	}

	public static boolean verifyISBNPackage() throws Throwable{
		driver.findElement(ElsevierObjects.PackageName).clear();
		boolean flag = true;
		try{
			Random ra = new Random( System.currentTimeMillis() );
			String isbnPkg=ReadingExcel.keyValueBasedOnCommonValue(testDataPath, "GenericValue", 0, 1, 2, "TC-10214").get("Input_ISBN");
			ISBNPkg = isbnPkg+Integer.toString((1 + ra.nextInt(2)) * 100000 + ra.nextInt(100000));
	
	
			if(!type(ElsevierObjects.PackageISBN, ISBNPkg, "Package ISBN")){
				flag = false;
			}
			if(!click(ElsevierObjects.savebutton, "Click on Save Button")){
				Thread.sleep(medium);
				flag = false;
			}
			Thread.sleep(medium);
			if(!Alert()){
				flag = false;
			}
			Thread.sleep(medium);
			//please change the value from automation111 to a new package name ie. ex: any 13 alphanumeric value
			if(!type(ElsevierObjects.PackageISBN, ISBNPkg , "Package ISBN")){
				flag = false;
			}
	
			if(!type(ElsevierObjects.PackageName, isbnPackageName, "Input Package Name ")){
				Thread.sleep(medium);
				flag = false;
			}
			if(!click(ElsevierObjects.savebutton, "Click on Save Button")){
				Thread.sleep(medium);
				flag = false;
			}
			Thread.sleep(medium);
			String sucMsg=getText(ElsevierObjects.verifysuccessmesg, "Get Success Message.");
			if(verifyText(ElsevierObjects.verifysuccessmesg, "Package successfully saved. ", "Package successfully saved. ")){
				Reporters.SuccessReport(ReadResourceData.getResourceData("TC-10214-28", "NA"), ReadResourceData.getResourceData("TC-10214-29", sucMsg));
	
			}else{
				Reporters.failureReport(ReadResourceData.getResourceData("TC-10214-28", "NA"), ReadResourceData.getResourceData("TC-10214-30", sucMsg));
			}
			Reporters.SuccessReport("ISBN Package Creation", "ISBN Package is successfully Created as :" + ISBNPkg);
			Thread.sleep(medium);
			String isbnInvalid=ReadingExcel.keyValueBasedOnCommonValue(testDataPath, "GenericValue", 0, 1, 2, "TC-10214").get("AddISBN_Invalid");
			if(!type(ElsevierObjects.verifyISBNtextenable, isbnInvalid, "ISBN Text Box")){
				flag = false;
			}
			Thread.sleep(medium);
			if(!click(ElsevierObjects.addbtn, "Add ISBN")){
				flag = false;
			}
			String errMsg=getText(ElsevierObjects.errormesg, "Get Error Message.");
			if(verifyText(ElsevierObjects.errormesg, "ISBN doesn't exist in Evolve.", "Error Message Displayed")){
				Reporters.SuccessReport(ReadResourceData.getResourceData("TC-10214-31", "NA"), ReadResourceData.getResourceData("TC-10214-32", errMsg));
	
			}else{
				Reporters.failureReport(ReadResourceData.getResourceData("TC-10214-31", "NA"), ReadResourceData.getResourceData("TC-10214-33", errMsg));
	
			}
	
			Thread.sleep(medium);
	
			ReadingExcel r=new ReadingExcel();
			
			List<String> testdata=r.getDataToList(testDataPath, "ISBNData", 0, 1, "TC-10214");
			for(String testString1 : testdata){
				if(type(ElsevierObjects.verifyISBNtextenable, testString1, "ISBN Text Box")){
					Reporters.SuccessReport(ReadResourceData.getResourceData("TC-10214-34", testString1), ReadResourceData.getResourceData("TC-10214-35", testString1));
				}else{
					Reporters.failureReport(ReadResourceData.getResourceData("TC-10214-34", testString1), ReadResourceData.getResourceData("TC-10214-36", testString1));
				}
				click(ElsevierObjects.addbtn, "Add ISBN");
	
			}
	
			String str1=driver.findElement(ElsevierObjects.Admin_Verify_Tableheadings).getText();
			System.out.println("str1  >>>"+str1+"<<<");
	
			String[] sArray = new String[]{"Author","Product Title","Product Type","Edition","ISBN"};
			for(String s : sArray){
				if(str1.contains(s)){
					Reporters.SuccessReport(ReadResourceData.getResourceData("TC-10214-37", "NA"), ReadResourceData.getResourceData("TC-10214-38", s));
				}else{
					Reporters.failureReport(ReadResourceData.getResourceData("TC-10214-37", "NA"), ReadResourceData.getResourceData("TC-10214-39", s));	
				}
			}
	
	
			List<WebElement> tableData=driver.findElements(ElsevierObjects.verifyISBNTable);
			for(WebElement data: tableData){
				System.out.println(data.getText());
				Reporters.SuccessReport("Each ISBN is Added ", "Each ISBN is added to the grid showing: " +data.getText());
			}
	
			isbnDataFromApplication("TC-10214");
	
			if(!click(ElsevierObjects.removelink, "Remove Link")){
				flag = false;
			}
			Thread.sleep(medium);
			String testdata1=ReadingExcel.keyValueBasedOnCommonValue(testDataPath, "GenericValue", 0, 1, 2, "TC-10214").get("testdata1");
			if(verifyTextPresent(testdata1)){
				Reporters.SuccessReport("Verify the ISBN : "+testdata1+" is removed from the Table or not", "ISBN "+testdata1+" details are successfully removed from the table");	
			}else{
				Reporters.failureReport("Verify the ISBN : "+testdata1+" is removed from the Table or not", "ISBN "+testdata1+" details are not failed to remove from the table");			
			}
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
		}
		return flag;
	}


	public static boolean marketingPageBookDetails(By ISBNTxtBox, String isbn, By addBtn, By tablecontent, String user) throws Throwable{
		boolean flag=true;
		try{
			if(!type(ISBNTxtBox, isbn, "Enter the ISBN in the text box ")){
				Thread.sleep(medium);
				flag = false;
			}
	
			if(!click(addBtn, "Click on Add Button")){
				flag = false;
			}
			Thread.sleep(medium);
			String content=null;
			List<WebElement> tableContent=driver.findElements(tablecontent);
	
			String Author=tableContent.get(1).getText();
			System.out.println("Author is "+ Author);
	
			titleForCompare=tableContent.get(2).getText();
			System.out.println("Title is "+ titleForCompare);
	
			String Edition=tableContent.get(3).getText();
			System.out.println("Edition is "+ Edition);
	
			String ProductType=tableContent.get(4).getText();
			System.out.println("Product Type is "+ ProductType);
	
			String ISBN=tableContent.get(5).getText();
			System.out.println("ISBN is "+ ISBN);
	
			Reporters.SuccessReport("Enter the ISBN: "+ISBN+" into the ISBN text field and click on add", "Author is "+ Author+"<br>Title is "+ titleForCompare+"<br>Edition is "+ Edition+"<br>Product Type is "+ ProductType+"<br>ISBN is "+ ISBN);
	
			String bookDetails=titleforfutureuse3;
			if(user.equalsIgnoreCase("promotionCreateMarketingSinglePercentage")){
				if(bookDetails.trim().contains(titleForCompare.trim())){
					Reporters.SuccessReport("verify the row added to the table matches the data for ISBN from Step #3", "The table matches the data for ISBN from Step #3");
				}else{
					Reporters.failureReport("verify the row added to the table matches the data for ISBN from Step #3", "The table matches the data for ISBN from Step #3 is failed");
				}
			}
			for(WebElement str:tableContent)
			{
				content=str.getText();
			}
			System.out.println(content);
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
		}
		return flag;
	}

	public static boolean  verifyTextPresent(String text) throws Throwable
	{  
		boolean flag=false;
		try{
			String bool=configProps.getProperty("OnSuccessReports");
			boolean b=Boolean.parseBoolean(bool);
			if(!(driver.getPageSource()).contains(text))
			{
	
				Reporters.SuccessReport("VerifyTextPresent",text+" is not present in the page");
				flag= true;
			}
			else if(b && flag)
			{
				Reporters.failureReport("VerifyTextPresent",text+" is present in the page");
				flag= false;
	
			}
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
		}
		return flag;
	}

}
