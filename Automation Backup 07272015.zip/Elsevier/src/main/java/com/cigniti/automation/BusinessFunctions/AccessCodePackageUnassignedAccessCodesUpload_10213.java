package com.cigniti.automation.BusinessFunctions;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.FileReader;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Property;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;


public class AccessCodePackageUnassignedAccessCodesUpload_10213 extends EvolveCommonBussinessFunctions{

	
	//Downloading the text file and verifying for the Access Code Literals
	public static boolean clickDownloadAndCompareNotePadDataWithStringliterals() throws Throwable{

		boolean flag = true;
		try{
		Property configProps=new Property("config.properties");
		BufferedReader br = null;
		r=new Robot();

		 Thread.sleep(medium);
		if(!click(ElsevierObjects.accesscodedownloadlink, "Click on Download Link")){
			flag = false;
		}

		//click(ElsevierObjects.downloadlink, "download link");

		 Thread.sleep(medium);
		if(isChecked(ElsevierObjects.radioinput, "TXT file format radiobutton is selected ")){
			//If browser type is 'IE', click TAB and Enter
			// if(configProps.getProperty("browserType").equalsIgnoreCase("ie")){
			if(ElsevierObjects.adminBrowserType.equalsIgnoreCase("ie")){
				 Thread.sleep(low);
				r.keyPress(KeyEvent.VK_TAB);
				 Thread.sleep(low);
				r.keyPress(KeyEvent.VK_ENTER);
			}
			else{
				click(ElsevierObjects.downloadlink, "download link");
			}
		}
		 Thread.sleep(medium);

		//If browser type is 'IE', click ALT+S and release ALT+S
		//if(configProps.getProperty("browserType").equalsIgnoreCase("ie")){
		if(ElsevierObjects.adminBrowserType.equalsIgnoreCase("ie")){
			r.keyPress(KeyEvent.VK_ALT);
			r.keyPress(KeyEvent.VK_S);
			r.keyRelease(KeyEvent.VK_S);
			r.keyRelease(KeyEvent.VK_ALT);
			 Thread.sleep(low);

			//If browser type other than 'IE'. 
		}
		//If browser type is Firefox, 
		else  
			//if(configProps.getProperty("browserType").equalsIgnoreCase("firefox")){
			if(ElsevierObjects.adminBrowserType.equalsIgnoreCase("firefox")){
				r.keyPress(KeyEvent.VK_DOWN);
				r.keyPress(KeyEvent.VK_TAB);
				r.keyPress(KeyEvent.VK_TAB);
				r.keyPress(KeyEvent.VK_TAB);
				 Thread.sleep(low);
				r.keyPress(KeyEvent.VK_ENTER);
			}
		//If browser type other than 'Chrome'. don't perform any operation. Since file will be downloaded automatically.
		 Thread.sleep(medium); 
		}catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
		return flag;
	}


	public static boolean accesscodeUploadLink() throws Throwable{
		boolean flag = true;
		try{
		String uploadLink=getText(ElsevierObjects.Admin_Login_Upload_lnk, "Admin Login Upload link");
		if(click(ElsevierObjects.Admin_Login_Upload_lnk, " Click on Upload Unassigned Codes")){
			Reporters.SuccessReport("Click on the Create Unassigned Codes in the Unassigned Access COde Management section", "Successfully Clicked on the Create Unassigned Codes in the Unassigned Access COde Management section");
		}else{
			Reporters.failureReport("Click on the Create Unassigned Codes in the Unassigned Access COde Management section", "Successfully Clicked on the Create Unassigned Codes in the Unassigned Access COde Management section");
		}
		String breadCrumb=getText(ElsevierObjects.Admin_VerifyUploadTxt, "Admin Verify Upload Text");
		if(isElementPresent(ElsevierObjects.Admin_VerifyUploadTxt, "Bread Crumb - Evolve Admin > Upload Access Codes ")){
			Reporters.SuccessReport("Verifying for Bread Crumb is Successfull", "Actual Bread Crumb is : "+breadCrumb +"<br> Expected Bread Crumb is : Bread Crumb - Evolve Admin > Upload Access Codes");	
		}else{
			Reporters.failureReport("Verifying for Bread Crumb failed ", "Actual Bread Crumb is : "+breadCrumb +"<br> Expected Bread Crumb is : Bread Crumb - Evolve Admin > Upload Access Codes");
		}	
	}catch(Exception e){
		sgErrMsg=e.getMessage();return false;
	}
		return flag;
	}

	public static boolean verifyCopyToExcel(String filePath) throws Throwable{
		boolean flag = true;
		try{
		UpdateColDataExcel ex=new UpdateColDataExcel();
		
		ex.UpdateColData(filePath, readcolumns.twoColumns(0, 1, "TC-10212", configProps.getProperty("TestData")).get("textfilepath"), "UploadFile");			 
		}catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
		return flag;	
	}
	
	
	public static boolean uploadExcel(String filePath) throws Throwable{
		boolean flag = true;
		try{

		
			uploadFile(ElsevierObjects.Admin_Browse_Btn, filePath, "Admin Browse Button");
			 Thread.sleep(high);
			if(!click(ElsevierObjects.Admin_Upload_Btn, " Click on Upload Button")){
				flag = false;
			}
			Thread.sleep(veryhigh);
			Thread.sleep(veryhigh);
			String sucMsg=getText(ElsevierObjects.Admin_Upld_Sucmsg, "Admin Upload Success message");
			waitForElementPresent(ElsevierObjects.Admin_Upld_Sucmsg, "Your file was successfully uploaded.");
			if(verifyText(ElsevierObjects.Admin_Upld_Sucmsg, "Your file was successfully uploaded.", "Success Message")){
				Reporters.SuccessReport("The Success Message Validation", "The success message : "+sucMsg+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
			}
			 Thread.sleep(medium);
		}catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
		return flag;
	}

	
	
	public static void setClipboardData(String string) {
	try{
		StringSelection stringSelection = new StringSelection(string);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
	}catch(Exception e){
		sgErrMsg=e.getMessage();
	}	}


	public static boolean accessCodeVerify(String validAccessCodes, String user) throws Throwable{
		boolean flag = true;
		try{
			if(click(ElsevierObjects.Admin_Search_AccessCodeLnk, "Click on Search Access Code")){
				Reporters.SuccessReport("Click on the Search Access Code link", "Successfully Clicked on the Search Access Code link");
			}else
			{
				Reporters.failureReport("Click on the Search Access Code link", "Failed to Click on the Search Access Code link");
			}
			if(!type(ElsevierObjects.Admin_Seach_Code, validAccessCodes, "Valid Access Code")){
				flag=false;
			}
			if(!click(ElsevierObjects.Admin_Search_Submit, "Click on Submit Button")){
				flag = false;
			}
			 Thread.sleep(medium);
			if(user.equalsIgnoreCase("upload")){

				String AccessCode = validAccessCodes;
				String AccessCodeAfterSearch = driver.findElement(ElsevierObjects.Admin_Evolve_AccessCodeAfterSearch).getText();

				if(AccessCode.contains(AccessCodeAfterSearch)){
					Reporters.SuccessReport("Search For Access Code", "Access code is active"+AccessCodeAfterSearch);
				}else
				{
					Reporters.failureReport("Search For Access Code", "Failed");
				}
			}else{
				if(javaClick(ElsevierObjects.Evolve_AccessCodeLink, "Click on the Access Code : ")){
					Reporters.SuccessReport("Click on the Search Access Code link", "Successfully Clicked on the Search Access Code link");
				}else
				{
					Reporters.failureReport("Click on the Search Access Code link", "Failed to Click on the Search Access Code link");
				}
				 Thread.sleep(medium);System.out.println("");
				String accessCodeRemaingUses=getText(ElsevierObjects.Evolve_AccessCodeRemaingUses, "Access code Remaining usage");
				String accessCodeStatus=getText(ElsevierObjects.Evolve_AccessCodeStatus, "Access Code Status ");
				if(accessCodeRemaingUses.contains("0")){
					Reporters.SuccessReport("Verify the access code shows as Redeemed and <br># of remaining uses is listed as 0.", "The Access Code Remaining Uses are : "+accessCodeRemaingUses);
				}else{
					Reporters.failureReport("Verify the access code shows as Redeemed and <br># of remaining uses is listed as 0.", "TThe Access Code Remaining Uses are : "+accessCodeRemaingUses);
				}
				if(accessCodeStatus.contains("Redeem")){
					Reporters.SuccessReport("Verify the access code shows as Redeemed and <br># of remaining uses is listed as 0.", "The Access Code usage status is : "+accessCodeStatus);
				}else{
					Reporters.failureReport("Verify the access code shows as Redeemed and <br># of remaining uses is listed as 0.", "The Access Code usage status is : "+accessCodeStatus);
				}
			}
			 Thread.sleep(low);
		}catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
		return flag;
	}

}
