package com.cigniti.automation.Test;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;

public class UploadFile extends EvolveCommonBussinessFunctions{

	
	 @Test
	 public void uploadFile() throws Throwable{
	 
		driver.findElement(By.id("userName")).sendKeys("schintakindi"); 
		driver.findElement(By.id("password")).sendKeys("Password2");
		driver.findElement(By.xpath(".//*[@id='pageBody']/form/table/tbody/tr[2]/td/table/tbody/tr[2]/td[1]/input[3]")).click();
Thread.sleep(medium);
driver.findElement(By.xpath(".//*[@id='pageBody']/form/table/tbody/tr[5]/td/table[17]/tbody/tr[2]/td[2]/a[text()='Upload Unassigned Codes']")).click();
Thread.sleep(medium);
driver.findElement(By.xpath(".//*[@id='filename']")).click();


		Robot r=new Robot();
	   
	  
	   Thread.sleep(medium);
	   
	   Thread.sleep(medium);
	   r.keyPress(KeyEvent.VK_TAB);
	   Thread.sleep(low);
	   r.keyPress(KeyEvent.VK_TAB);
	   Thread.sleep(low);
	   r.keyPress(KeyEvent.VK_ENTER);
	   r.keyRelease(KeyEvent.VK_ENTER);
	   Thread.sleep(high);
	 	   
	   setClipboardData(configProps.getProperty("UploadDataFile"));
	 
	   r.keyPress(KeyEvent.VK_CONTROL);
	   r.keyPress(KeyEvent.VK_V);
	   r.keyRelease(KeyEvent.VK_V);
	   r.keyRelease(KeyEvent.VK_CONTROL);
	 

	   r.keyPress(KeyEvent.VK_ENTER);
	   r.keyRelease(KeyEvent.VK_ENTER);
	   Thread.sleep(100000);
	 
	  }
	  
	   public static void setClipboardData(String string) {
	     StringSelection stringSelection = new StringSelection(string);
	     Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
	  }
}
