package com.cigniti.automation.Test;

import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.AcesscodeBusinessfunctions15558;
import com.cigniti.automation.BusinessFunctions.EComm_Preorde_MyEvolve_Page15590;
import com.cigniti.automation.BusinessFunctions.EComm_Preorde_MyEvolve_Page15594_BussinessFunctions;
import com.cigniti.automation.BusinessFunctions.EComm_Preorde_rMyEvolve_Page15591_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.ECommercePackagependingcourseid_15461;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;
import com.cigniti.automation.datadriven.ReadResourceData;

public class EComm_Preorde_MyEvolve_Page15590_Script2 extends EComm_Preorde_MyEvolve_Page15590 {
	
	public static final String CINICAL_MEDICAL_ASSISTANT_ONLINE =ReadingExcel.columnDataByHeaderName("product", "TC-15590", testDataPath);;
	
	@Test
	public void eCommPreordeMyEvolvePageScript2_15590() throws Throwable{
		
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		String courseID=ReadingExcel.columnDataByHeaderName("CourseID", "TC-15590", testDataPath);
		String product=ReadingExcel.columnDataByHeaderName("product", "TC-15590", testDataPath);
		
		stepReport("Login to evolve as student who placed preorder");
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		launchUrl(configProps.getProperty("URL4"));
		String username=readcolumns.twoColumns(0,1, "ECommercePreOrder", configProps.getProperty("TestData")).get("ECommPreordeMyEvolvePage15590");
		String password=readcolumns.twoColumns(0,2, "ECommercePreOrder", configProps.getProperty("TestData")).get("ECommPreordeMyEvolvePage15590");
		if(User_BusinessFunction.SignInAsDifferentUser(username, password)){
			Reporters.SuccessReport("Login into Application as same student user", "Successfully logged in as Student user with the credentials : <br> Username : "+username+"<br> Password : "+password);
		}else{
			Reporters.failureReport("Login into Application as same student user", "Failed to log in as Student user with the credentials : <br> Username : "+username+"<br> Password : "+password);
		}
		
		stepReport("Verify that the course now appears under My Evolve");
		if(click(ElsevierObjects.Myevolve,"Click on my evolve")){
			Reporters.SuccessReport("Click on My Evolve", "Successfully clicked on the My Evolve");
		}else{
			Reporters.failureReport("Click on My Evolve", "Failed to click on the My Evolve");
		}
		String course=ReadingExcel.columnDataByHeaderName("course", "TC-15590", testDataPath);
		String button1=ReadingExcel.columnDataByHeaderName("button1", "TC-15590", testDataPath);
		String button2=ReadingExcel.columnDataByHeaderName("button2", "TC-15590", testDataPath);
		String courseType=ReadingExcel.columnDataByHeaderName("courseType", "TC-15590", testDataPath);
		
		ECommercePackagependingcourseid_15461.VerifyContentpagewithinputs(courseType,course,button1,button2,"Yes");
		
		stepReport("Verify the Enter Later button");
		verifyEnterLaterButton();
		
		stepReport("Enter the instructor's course ID");
		enterInstructorCourseId(courseID);
		//enterCourseId(product);
		
		stepReport("Verify the contents of the course");
		EComm_Preorde_MyEvolve_Page15594_BussinessFunctions.courseDetailsPage(ElsevierObjects.courseContentLink,"contentHome");
		
		stepReport("Login to Evolve Admin");
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),ReadResourceData.getResourceData("TC-10214-1", configProps.getProperty("AdminUser")),
				ReadResourceData.getResourceData("TC-10214-2", configProps.getProperty("AdminUser")),
				ReadResourceData.getResourceData("TC-10214-3", configProps.getProperty("AdminUser")));
		
		stepReport("Verify the student's PAR report and revoke their access");
		ECommercePackagependingcourseid_15461.adminPARVerify(username);
		
		stepReport("Verify the student no longer has access to protected content");
		launchUrl(configProps.getProperty("URL4"));
		EComm_Preorde_MyEvolve_Page15594_BussinessFunctions.courseDetailsPage(ElsevierObjects.courseContentLink,"");
		
		stepReport("Redeem a new access code and verify access to content");
		protectedContent();
		EComm_Preorde_MyEvolve_Page15594_BussinessFunctions.courseDetailsPage(ElsevierObjects.courseContentLink,"contentHome");
		
		stepReport("Login to Evolve Admin");
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),ReadResourceData.getResourceData("TC-10214-1", configProps.getProperty("AdminUser")),
				ReadResourceData.getResourceData("TC-10214-2", configProps.getProperty("AdminUser")),
				ReadResourceData.getResourceData("TC-10214-3", configProps.getProperty("AdminUser")));
		
		stepReport("Verify the student's PAR report and revoke their access");
		ECommercePackagependingcourseid_15461.adminPARVerify(username);
		
		stepReport("Verify the student no longer has access to protected content");
		launchUrl(configProps.getProperty("URL4"));
		EComm_Preorde_MyEvolve_Page15594_BussinessFunctions.courseDetailsPage(ElsevierObjects.courseContentLink,"");
		driver.findElement(By.xpath(".//*[@class='btn']")).click();
		Thread.sleep(medium);
		
		stepReport("Enter course ID in search box on Evolve Catalog page");
		launchUrl(configProps.getProperty("URL4"));
		//AcesscodeBusinessfunctions15558.verifyHoneyPot();
		Thread.sleep(high);
		//String Courseid3=ReadingExcel.columnDataByHeaderName("LOCourseid3", "Tc-15558",configProps.getProperty("TestData"));
		selfEnrollNavigate(courseID);
		
		stepReport("Complete order using access code");
		checkoutProduct(true, product, 0, "Institution");
		EComm_Preorde_MyEvolve_Page15594_BussinessFunctions.courseDetailsPage(ElsevierObjects.courseContentLink,"");
		
		launchUrl(configProps.getProperty("URL4"));
		//AcesscodeBusinessfunctions15558.verifyHoneyPot();
		Thread.sleep(high);
		//String Courseid3=ReadingExcel.columnDataByHeaderName("LOCourseid3", "Tc-15558",configProps.getProperty("TestData"));
		selfEnrollNavigate(courseID);
		checkoutProduct(true, product, 6,"");
		EComm_Preorde_MyEvolve_Page15594_BussinessFunctions.courseDetailsPage(ElsevierObjects.courseContentLink,"contentHome");
		

	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
