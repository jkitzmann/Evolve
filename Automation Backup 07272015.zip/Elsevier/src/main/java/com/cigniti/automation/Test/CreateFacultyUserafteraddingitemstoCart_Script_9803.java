package com.cigniti.automation.Test;

import java.util.Random;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.CreateFacultyUserafteraddingitemstoCart_9803;
import com.cigniti.automation.BusinessFunctions.CreateFacultyUserfromSplashPage_9799;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class CreateFacultyUserafteraddingitemstoCart_Script_9803 extends CreateFacultyUserafteraddingitemstoCart_9803 {

  @Test
  public void CreateFacultyUserafteraddingitemstoCart_9803() throws Throwable {
	
		  SwitchToBrowser(ElsevierObjects.studentBrowserType);
		 isbn = ReadingExcel.columnDataByHeaderName("ISBN","TC-9803",configProps.getProperty("TestData"));
		 Firstname=ReadingExcel.columnDataByHeaderName("Firstname","TC-9803",configProps.getProperty("TestData"));
		 Lastname=ReadingExcel.columnDataByHeaderName("Lastname","TC-9803",configProps.getProperty("TestData"));
		 Random ra = new Random( System.currentTimeMillis() );
	     EmailId =ReadingExcel.columnDataByHeaderName("EmailId","TC-9803",configProps.getProperty("TestData"))+Integer.toString((1 + ra.nextInt(2)) * 10000 + ra.nextInt(10000))+"@evolveqa.info";
	     Password=ReadingExcel.columnDataByHeaderName("Password","TC-9803",configProps.getProperty("TestData"));
		 ConformPassword=ReadingExcel.columnDataByHeaderName("ConformPassword","TC-9803",configProps.getProperty("TestData"));
		 Country=ReadingExcel.columnDataByHeaderName("Country","TC-9803",configProps.getProperty("TestData"));
		 State=ReadingExcel.columnDataByHeaderName("State","TC-9803",configProps.getProperty("TestData"));
		 City=ReadingExcel.columnDataByHeaderName("City","TC-9803",configProps.getProperty("TestData"));
		 Institution=ReadingExcel.columnDataByHeaderName("Institution","TC-9803",configProps.getProperty("TestData"));
		 StreetAddress=ReadingExcel.columnDataByHeaderName("StreetAddress","TC-9803",configProps.getProperty("TestData"));
		 Zipcode=ReadingExcel.columnDataByHeaderName("ZipCode","TC-9803",configProps.getProperty("TestData"));
		 PhoneNumber=ReadingExcel.columnDataByHeaderName("PhoneNumber","TC-9803",configProps.getProperty("TestData"));
		 ProgramType=ReadingExcel.columnDataByHeaderName("ProgramType","TC-9803",configProps.getProperty("TestData"));
		
		stepReport("Add item to cart and enter checkout");
		 writeReport(CreateFacultyUserafteraddingitemstoCart_9803.facultyafteraddingcart(),"Enter URL,search for product,Registered the product and details are entered",
				                                                                          "Successfully EvolveCertURL is Launched </br> Click on Faculty link </br> User is taken to Honeypot page </br> Product is searched from Online Course Honeypot and ISBN is " +isbn,
				                                                                          "Failed to Launch URL,search for product and registration");
		Thread.sleep(medium);
		stepReport("Verify the registration form in checkout");
		writeReport(CreateFacultyUserafteraddingitemstoCart_9803.Registrationform(),"Enter details in the Registration form and verify details in the Review and submit page",
				                                                                    "Successfully details are entered in the Registration form,verified details in the review and submit page and page is navigated to confirmation page",
				                                                                    "Failed to enter details and verified details in the review and submit page");
		Thread.sleep(medium);
		stepReport("Log out and back into the new account");
		writeReport(CreateFacultyUserafteraddingitemstoCart_9803.ConfirmationRelogin(),"Relogin using above Created user details and verify the product",
                                                                                       "Successfully Relogin with user details and verified the details of the product",
                                                                                       "Failed to Relogin and verify the details of the product");
		Thread.sleep(medium);
		getAccountDetails();
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		stepReport("Login to Evolve Admin");
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Enter Admin URL and login with the Credentials",
				                                                      "Successfully launched with Admin URL and logged in with User credentials",
				                                                      "Failed to login with Admin URL and login");
		Thread.sleep(medium);
		stepReport("Verify that an AR was created");
		writeReport(CreateFacultyUserafteraddingitemstoCart_9803.search_adoptions(),"Search Adoption with the username",
				                                                                    "Successfully click on Search Adoptions,searched by Today's date then it displayed the Username and ISBN just Ordered",
				                                                                    "Failed to search with username in Search Adoptions");
		Thread.sleep(medium);
		/*writeReport(CreateFacultyUserafteraddingitemstoCart_9803.emailVerification(),"Launch Email URL,login and search the Email registered",
	    		                                                                     "Successfully Email URL is Launched,login and Registered Email is reached",
	    		                                                                     "Failed to Launch,login and get Registered Email");
	   */
		//SwitchToBrowser("Chrome");
		stepReport("Verify email");
		if(emailLogin()){
			Reporters.SuccessReport("Email login:", "Successfully logged into User Email.");
		}
		else{
			Reporters.failureReport("Email Login:", "Failed to login into User Email.");
		}
		
		CreateFacultyUserafteraddingitemstoCart_9803.emailVerification();
      }
  
   } 
