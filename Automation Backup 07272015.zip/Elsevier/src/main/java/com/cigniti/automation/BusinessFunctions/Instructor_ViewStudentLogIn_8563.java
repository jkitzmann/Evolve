package com.cigniti.automation.BusinessFunctions;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;

public class Instructor_ViewStudentLogIn_8563 extends EvolveCommonBussinessFunctions {
	
	public static boolean studentLogin() throws Throwable{
		boolean flag = true;
		try
		{
		if(!type(ElsevierObjects.checkout_login_username, configProps.getProperty("StudentUser"), "Student Name")){
			flag = false;
		}
		if(!type(ElsevierObjects.checkout_login_password, configProps.getProperty("StudentPassword"), "Password")){
			flag = false;
		}
		if(!click(ElsevierObjects.educator_btnLogin,"Clicked On login")){
	   		 flag = false;
	   	 }
		/*if(!click(ElsevierObjects.educator_chkInstution,"Clicked On Checkbox")){
	   		 flag = false;
	   	 }
		if(!click(ElsevierObjects.educator_form_btnContinue,"Clicked on Continue Button")){
   		 	flag = false;
   	 	 }*/
		}
		catch(Exception e)

		{

		sgErrMsg=e.getMessage();

		return false;
		}
		return flag;
	}
	
	public static boolean educatorlogin() throws Throwable{
		boolean flag = true;
		try
		{
		if(!type(ElsevierObjects.educator_txtStudentUser, sEducatorUser, "Student Name")){
			flag = false;
		}
		if(!type(ElsevierObjects.educator_txtStudentPassword,  sEducatorPassword, "Password")){
			flag = false;
		}
		if(!click(ElsevierObjects.educator_btnLogin,"Clicked On login")){
	   		 flag = false;
	   	 }
		/*if(!click(ElsevierObjects.educator_chkInstution,"Clicked On Checkbox")){
	   		 flag = false;
	   	 }
		if(!click(ElsevierObjects.educator_form_btnContinue,"Clicked on Continue Button")){
   		 	flag = false;
   	 	 }*/
		}
		catch(Exception e)

		{

		sgErrMsg=e.getMessage();

		return false;
		}
		return flag;
	}
	
	
}
