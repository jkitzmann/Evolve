
package com.cigniti.automation.BusinessFunctions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cigniti.automation.Test.ReadFileExample;
import com.cigniti.automation.Utilities.Reporters;


public class UpdateColDataExcel {

	//source - excel file in which you want to update particular column data
	//destination - excel file in which you want to update particular column data
    public void UpdateColData(String excelpath, String textpath, String sheet) throws Throwable {
        FileInputStream fileInputStream = null;
        XSSFCell updateCell = null;
        try {

            //Here we are reading the excel file
            fileInputStream = new FileInputStream(excelpath);
            //Creating the workbook from the file
            XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
            //Reading the sheet
            XSSFSheet worksheet = workbook.getSheet(sheet);

            //Creating an obj to the list
            ArrayList<String> columndata = (ArrayList<String>) ReadFileExample.readTxt(textpath);
            if(columndata!=null){
            	Reporters.SuccessReport("Verify the Access Codes from text file are Captured", "The Access Codes are successfully captured :"+columndata);
            }else{
            	Reporters.failureReport("Verify the Access Codes from text file are Captured", "The Access Codes are not captured ");
            }
            //List myList = createList();
            
            //Iterating the loop for inserting the data in list to the file
            for (int i = 0; i < columndata.size(); i++) {

                //Getting the row from the sheet that is to be updated
                XSSFRow myRow = worksheet.getRow(i+1);

                //checking whether the cell to be updated is already created or not.
                //If the cell is not created then myRow.getCell(1) returns null, then new cell will be created.
                //If already cell is created then we will get the cell and then we will update the value in it. 
                if (myRow.getCell(2) == null) {
                    //Creating new cell
                    updateCell = myRow.createCell(2);
                } else {
                    //Getting the cell
                    updateCell = myRow.getCell(2);
                }
                //Setting the value to the cell from the list.
                updateCell.setCellValue((String)columndata.get(i));
            }

            //This will close the file input stream.
            fileInputStream.close();

            //Write new file
            //Now we have to write a new file to view the updated data. Here we are creating the file with
            //same name and in the same location. So that the file will be replaced
            FileOutputStream newFileStream = new FileOutputStream(excelpath);

            //Writing the data to the file.
            workbook.write(newFileStream);

            //This will close the file output stream
            newFileStream.close();
        } catch (FileNotFoundException ex) {
        	ex.printStackTrace();
            
        } 
        }
   }
