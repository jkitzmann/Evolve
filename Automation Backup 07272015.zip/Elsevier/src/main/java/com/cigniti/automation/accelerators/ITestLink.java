package com.cigniti.automation.accelerators;

public interface ITestLink {
	public void reportTestCaseResult(String testlinkPropName);
}
