package com.cigniti.automation.Utilities;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class DynamicBrowse {

	public static Property configProps=new Property("config.properties");
	
    public static void main(String[] args) throws Exception {
        //IE
    	File file = new File("Drivers\\IEDriverServer.exe");
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
        
            DesiredCapabilities capab = DesiredCapabilities.internetExplorer();
            capab.setCapability(
            InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
                 true);

            WebDriver driver = new InternetExplorerDriver(capab);
            driver.get("http://www.google.com");
            //Chrome
            System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");				
			driver = new ChromeDriver(DesiredCapabilities.chrome());  
            driver.get("http://www.google.com");
            
         // Check the title of the page
         System.out.println("Page title is: " + driver.getTitle());

         //driver.quit();
     }

	
}
