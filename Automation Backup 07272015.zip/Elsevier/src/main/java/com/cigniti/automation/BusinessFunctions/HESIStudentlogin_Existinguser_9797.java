package com.cigniti.automation.BusinessFunctions;

import org.openqa.selenium.Keys;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class HESIStudentlogin_Existinguser_9797 extends EvolveCommonBussinessFunctions {
	public static String ISBN;
	public static String Country;
	public static String State;
	public static String City;
	public static String Institute;
	public static String Programtype;
	public static String Year;
	public static String StreetAddress;
	public static String CityAddress;
	public static String StateAddress;
	public static String Zipcode;
	public static String price;
	public static String Title;
	public static String isbn;
	
	public static boolean LO_Creation()throws Throwable{
	try
      {
	   boolean flag = true;
	   click(ElsevierObjects.evolveCatalog, "Click on Catalog");
 	   Thread.sleep(1000);
	   type(ElsevierObjects.txtproductsearch,ISBN,"Enter the isbn number in the searchbox");
	   Thread.sleep(2000);
	   click(ElsevierObjects.gobutton,"click on GO button");
	   Thread.sleep(2000);
	   String price = getText(ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomprice,"get the price of product");
	   Reporters.SuccessReport("Verify the price of product","Price of the product is verified " +price);
	   Thread.sleep(1000);
	   click (ElsevierObjects.Admin_Evolve_Ecom_HeadCDRomAddtoCart,"Click on Register for this now button");
	   Thread.sleep(1000);
	   click(ElsevierObjects.Hesi_Student_Reedembutton,"Click on Reedem/checkout button");
	   Thread.sleep(2000);
	   return flag;}
	   catch(Exception e){return false;}
	}  
	   
	public static boolean UpdateAccount()throws Throwable{
	try
	   {
		boolean flag = true;  
		selectByVisibleText(ElsevierObjects.Hesi_Student_country,Country,"Select country name from the list");
		Thread.sleep(2000);
		selectByVisibleText(ElsevierObjects.Hesi_Student_state,State,"Select State name from the list");
		Thread.sleep(2000);
		selectBySendkeys(ElsevierObjects.Hesi_Student_City,City,"Enter Cityname");
		Thread.sleep(4000);
		driver.findElement(ElsevierObjects.Hesi_Student_City).sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		type(ElsevierObjects.Hesi_Student_institute,Institute,"Enter institute name");
		Thread.sleep(2000);
		selectByVisibleText(ElsevierObjects.educator_form_txtddprogramType,Programtype,"Select programtype form list");
		Thread.sleep(2000);
		selectBySendkeys(ElsevierObjects.Hesi_Student_year,Year,"Select the year from the list");
		Thread.sleep(2000);
		type(ElsevierObjects.student_billingAddress,StreetAddress,"Enter the street address in the box");
		Thread.sleep(1000);
	    type(ElsevierObjects.student_billingAddress_city,CityAddress,"Enter city in the textbox");
	    Thread.sleep(1000);
	    selectByVisibleText(ElsevierObjects.student_billingAddress_state,StateAddress,"Enter state in the textbox");
	    Thread.sleep(1000);
	    type(ElsevierObjects.student_billingAddress_zip,Zipcode,"Enter ZIP code in the textbox");
	    Thread.sleep(1000);
	    click(ElsevierObjects.educator_form_btnContinue,"Click on continue button");
		Thread.sleep(veryhigh);
		Thread.sleep(veryhigh);
		switchToFrameByLocator(ElsevierObjects.Admin_Evolve_Ecom_framename,"Switch to iframe");
		Thread.sleep(medium);
		click(ElsevierObjects.Use_this_address,"Click on use this address");
		Thread.sleep(high);
		creditCardDetails(); 
		Thread.sleep(veryhigh);
		click(ElsevierObjects.checkbox1,"Click on checkbox");
		Thread.sleep(2000);
		click(ElsevierObjects.instructor_submit,"Click on submit button");
		Thread.sleep(1000);
	    return flag;}
	    catch(Exception e){return false;}
	}
	
	public static boolean confirmationpage()throws Throwable{
	try 
	  {
	   boolean flag = true;
	   if(click(ElsevierObjects.Myevolve,"Click on MyEvolve")){
		   Reporters.SuccessReport("Verify My Evolve","Successfully clicked on My Evolve and user is taken to My Evolve page");
	   }else{
		   Reporters.failureReport("Verify My Evolve","Failed to click on My Evolve");
	   }
	   Thread.sleep(2000);
	   click(ElsevierObjects.Myevolve,"Click on MyEvolve");
	   click(ElsevierObjects.Pbc_Refresh,"Click on Refresh");
	   click(ElsevierObjects.Pbc_Refresh,"Click on Refresh");
	   click(ElsevierObjects.Pbc_Refresh,"Click on Refresh");
	   click(ElsevierObjects.Pbc_Refresh,"Click on Refresh");
	   Thread.sleep(2000);
	   //String Courseid = getText(ElsevierObjects.Nursing_course_id,"Get CourseId of the product");
	   //Reporters.SuccessReport("Verify the Courseid of product","Courseid of the product is : "+Courseid);
	   Thread.sleep(1000);
	   String Titlelink = getText(ElsevierObjects.Nursing_course_link,"Get the Titlelink of the product");
	   Reporters.SuccessReport("Verify the Titlelink of the product","Titlelink of the product is : "+Titlelink);
	   
	   Thread.sleep(1000);
	   return flag;}
	   catch(Exception e){return false;}
	}
	
    public static boolean Hesiregistration() throws Throwable{
	try
	   {
	    boolean flag = true;
	    Thread.sleep(3000);
	    if(click(ElsevierObjects.evolveCatalog, "Click on Catalog")){
		     Reporters.SuccessReport("Click on catalog","Successfully clicked on catalog");
		}else{
		     Reporters.failureReport("Click on catalog","Failed to click on catalog");
	    }
		Thread.sleep(2000);
		/*if(click(ElsevierObjects.Hesi_Student_HesiExam,"Click on Hesi Exams Button")){
		     Reporters.SuccessReport("Click on Hesi Exams Icon","Successfully clicked on Hesi Exams Honeypot");
		}else{
		     Reporters.failureReport("Click on Hesi Exams Icon","Failed to click on HesiExams Honeypot");
		}
		Thread.sleep(1000);*/
	    if(click(ElsevierObjects.Hesi_Student_HesiRegister,"Click on Hesi Register Button")){
	        Reporters.SuccessReport("Click on Hesi Registartion link","Successfully clicked on Register for Hesi link");
	    }else{
	        Reporters.failureReport("Click on Hesi Registartion link","Failed to click on Register for Hesi link");
	    }
		Thread.sleep(2000);
		String header = ReadingExcel.columnDataByHeaderName("HesiHeader","TC-8567",configProps.getProperty("TestData"));
	    String h = getText(ElsevierObjects.Hesi_Registration_header,"Get the header of the page");
	    if(h.contains(header)){
	    	Reporters.SuccessReport("Verify the header of the page","Header is verified where Hesi Registration and Register Now button is present");
	    }else{
	    	Reporters.failureReport("Verify the header of the page","Failed to verify the page header where Hesi Registration and Register Now button");
	    }
	    Thread.sleep(2000);
	    if(click(ElsevierObjects.Hesi_Student_Registernow,"Click on Register Now button")){
	    	 Reporters.SuccessReport("Click on Register Now","Successfully clicked on Register Now button and Item is added to cart");
	     }else{
	    	 Reporters.failureReport("Click on Register Now","Failed to click on Register Now button and Item is added to cart");
	     }
	    Thread.sleep(2000);
	    Title = getText(ElsevierObjects.Hesi_title,"Get the title of the product");
		Reporters.SuccessReport("Verify the title of product", "Title of the product is " +Title);
		Thread.sleep(1000);
		     
		isbn = getText(ElsevierObjects.Hesi_Student_isbn,"Get the isbn present there");
		Reporters.SuccessReport("Verify the isbn of the product", "ISBN of the product is "+isbn);    
	 
	   Thread.sleep(1000);
	   String s = ReadingExcel.columnDataByHeaderName("S","TC-8567",configProps.getProperty("TestData"));
	   price=getText(ElsevierObjects.Hesi_Student_price,"Get price present there");
	   if(price.contains(s)){
	 		Reporters.SuccessReport("verify the price of product","Prices are compared successfully : <br> Expected price is : "+price+" <br> Actual price is :"+s);
	   }else{
	 		Reporters.failureReport("verify the price of product","Prices comparision is failed : <br> Expected price is : "+price+" <br> Actual price is :"+s);
	   }
	   Thread.sleep(1000);
	   Reporters.SuccessReport("Verify Item add to Cart","Item is Successfully add to cart and Price is verified it remains ZERO");
	   Thread.sleep(1000);
	   if(click(ElsevierObjects.Hesi_Student_Reedembutton,"Click on Reedem/Checkout button")){
		   Reporters.SuccessReport("Click on Reedem/Checkout button","Successfully clicked on Reedem/Checkout button and Confirmation page is displayed");
	   }else{
		   Reporters.failureReport("Click on Reedem/Checkout button","Failed to click on Reedem/Checkout button and Confirmation page is displayed");
	   }
	   Thread.sleep(2000);		
	   click(ElsevierObjects.instructor_chk ,"Click on check box");
	   Thread.sleep(1000);
	   click(ElsevierObjects.instructor_submit ,"Click on submit button");
	   Thread.sleep(4000);
	   String st=driver.findElement(ElsevierObjects.Hesi_Student_msg).getText();
	   Reporters.SuccessReport("Verify the Success Message","Successfully Message is verified :"+st);
	   Thread.sleep(1000);  
	   String HesiProductTitle=getText(ElsevierObjects.Hesi_Student_title,"Get the title Present there");
	   if(HesiProductTitle.contains(Title)){
	    	Reporters.SuccessReport("Verify the title of product", "Titles compared is successfully: <br> Expected Title is :"+HesiProductTitle+"<br>Actual Title is :"+Title);
	   }else{
	    	Reporters.failureReport("Verify the title of product", "Titles comparision is failed: <br> Expected Title is :"+HesiProductTitle+"<br>Actual Title is :"+Title);
	   }
	   Thread.sleep(1000);
	   String ISBN = getText(ElsevierObjects.Hesi_Student_ISBN,"Get the isbn present there");
	   if(ISBN.contains(isbn)){
	    	Reporters.SuccessReport("Verify the isbn of the product", "ISBN's are compared successfully: <br>Expected ISBN is :"+ISBN+"<br>Actual ISBN is :"+isbn);
	   }else{
	    	Reporters.failureReport("Verify the isbn of the product", "Failed to compare ISBN's :<br>Expected ISBN is :"+ISBN+"<br>Actual ISBN is :"+isbn);
	   }
	   Thread.sleep(1000);
	   String Price = getText(ElsevierObjects.Price,"Get the price of the product");
	   if(Price.contains(price)){
		    Reporters.SuccessReport("Verify Item Price of product", "Prices are compared successfully: <br> Expected Price is : "+Price+"<br>Actual Price is : "+price);
	   }else{
		    Reporters.failureReport("Verify Item Price of product", "Prices comparision failed: <br> Expected Price is : "+Price+"<br>Actual Price is : "+price);
	   }
	   Thread.sleep(1000);
	   String TotalPrice=getText(ElsevierObjects.Hesi_Verify_Total,"Get the Totalprice Present there");
	   if(TotalPrice.contains(price)){
			Reporters.SuccessReport("Verify Total Price of product", "TotalPrices are compared successfully: <br> Expected Price is : "+Price+"<br>Actual Price is : "+price);
	   }else{
			Reporters.failureReport("Verify Total Price of product", "TotalPrices comparision failed: <br> Expected Price is : "+Price+"<br>Actual Price is : "+price);
	   }
	    return flag;}
	    catch(Exception e){return false;} 
    }
}	
	
    