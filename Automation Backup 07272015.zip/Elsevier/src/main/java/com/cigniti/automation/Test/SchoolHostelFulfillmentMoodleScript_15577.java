package com.cigniti.automation.Test;

import java.util.Random;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentFaculty_15243;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class SchoolHostelFulfillmentMoodleScript_15577 extends EvolveCommonBussinessFunctions{
	Random ra = new Random( System.currentTimeMillis() );
	@Test
	public void schoolHostelFulfillmentMoodle_15577() throws Throwable{
		try
		{
		    // HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String user="educator";
		
			facultyUser=ReadingExcel.columnDataByHeaderName("Faculty_User","SchoolHostedCommonData",testDataPath);
			facultyPwd=ReadingExcel.columnDataByHeaderName("Faculty_passWord","SchoolHostedCommonData",testDataPath);
			writeReport(EvolveCommonBussinessFunctions.existingUserLogin(user,facultyUser,facultyPwd), "Launch Evolve Cert URL And Login As Existing Educator: "+facultyUser, 
					"Successfully Launched Evolve Cert URL.</br>Successfully Logged In as Educator. "+facultyUser,
					"Failed to Launch Evolve Cert URL.</br>Failed to Login As Educator. "+facultyUser);
			writeReport(EvolveCommonBussinessFunctions.deleteCart(),"Deleting Cart Item.",
					"Successfully Deleted Cart Item.",
					"Failed to Delete Cart Item.");
			writeReport(EvolveCommonBussinessFunctions.getAccountDetails(), "Fetching Account Details From MyAccount Page.", 
					"Successfully Fetched Username: "+getAccountDetailsUserName+"</br>Successfully Fetched FirstName: "+getAccountDetailsFirstName+"</br>Successfully Fetched Lastname: "+getAccountDetailsLastName+"</br>Successfully Fetched Email: "+getAccountDetailsEmail+"</br>Successfully Fetched Institution: "+getAccountDetailsInstitution+"</br>Successfully Fetched PhoneNumber: "+getAccountDetailsPhone+"</br>Successfully Fetched StreetAdreess: "+ getAccountDetailsStreetAddress, 
					"Failed to Fetch Account Details From MyAccount Page. ");
		
			String product = ReadingExcel.columnDataByHeaderName("searchNumber","SchoolHostedCommonData",configProps.getProperty("TestData"));
			String productCost=ExpectedPrice;
			writeReport(EvolveCommonBussinessFunctions.searchProduct(product,productCost), "Searching For Hosted ISBN: "+product, 
					"Successfully Enter ISBN: "+product+"</br>Successfully Searched for ISBN: "+product, 
					"Failed To Search For ISBN: "+product);
			
			writeReport(EvolveCommonBussinessFunctions.requestProduct(), "Clicking On Request Product Button", 
					"Successfully Clicked On Request Product Button</br>Successfully Navigated To MyCart Page.", 
					"Failed To Click On Request Product Button</br>Failed to Navigate to MyCart Page.");
		
			lmsvalue=ReadingExcel.columnDataByHeaderName("LMSValuemoodle","SchoolHostedCommonData",configProps.getProperty("TestData"));
			writeReport(EvolveCommonBussinessFunctions.hostedAfterRequestPopUp(), "Switching To Hosted Popup Frame.", 
					"Successfully Switched To Hosted POPUP Frame.", 
					"Failed To Switch To Hosted POPUP Frame");
			
			writeReport(EvolveCommonBussinessFunctions.lmsInPopUp(lmsvalue),"Clicking On LMS Value Radio Button In Hosted Popup.", 
					"Successfully Clicked On LMS VALUE Radio Button.</b> Successfully Selected "+lmsvalue+" From DropDown</br> Successfully Clicked On Apply Button.", 
					"Failed To Click On LMS VALUE Radio Button.</b> Failed Selected "+lmsvalue+" From DropDown");
			
			String evolve="false";
			writeReport(EvolveCommonBussinessFunctions.hostedMycart(lmsvalue,evolve),"Navigating To My Cart Page And Clicking On Redeem Checkout Button.", 
					"Successfully Navigated To MyCart Page.</br>Successfully Verified ISBN: "+product+"</br> Successfully Verified title "+title+"</br>Successfully Verified TotalPrice "+ExpectedPrice+" </br>Successfully Verified LmsValue "+lmsvalue+"</br>Successfully Clicked On Redeem CheckOut Button.", 
					"Failed To Navigate To MyCart Page And Failed To Click On Redeem CheckOut Button.");
			
			writeReport(EvolveCommonBussinessFunctions.reviewAndSubmit(),"Navigating To Review And Submit Page And Clicking On Submit Button.", 
					"Successfully Navigated To Review And Submit Page.</b> Successfully Clicked On Check Box YES I AM REGISTERED USER.</br> Successfully Clicked CheckBox YES I AM INSTRUCTOR.</br> Successfully Clicked On Submit Button.", 
					"Failed To Navigate To Review And Submit Page And Failed To click On Submit Button.");
			
			writeReport(EvolveCommonBussinessFunctions.receiptPage(lmsvalue),"Navigating To Receipt Page And Logout Educator Account.", 
					"Successfully Navigated To Receipt Page.</br> Successfully Verified TotalPrice "+ExpectedPrice+" </br>Successfully Verified LmsValue "+lmsvalue+"</br>Successfully Clicked On Redeem CheckOut Button.</br>Successfully Logged out Educator "+facultyUser+" Account.", 
					"Failed To Navigate To Receipt Page.");
			
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials"+adminUser,
                    "Launching the URL for User is successful </br > Login to Application Using User credentials :"+adminUser+" is Successful",
                       "Launching and Login to Application Using User credentials : "+ adminUser+" is Failed");
			
			writeReport(EvolveCommonBussinessFunctions.clickAdoptionRequest(getAccountDetailsUserName),"Clicking On Adoption Request Link In Admin Page And Searching For Adoption request",
                    "Successfully Clicked On Adoption Request Link In Admin Page.</br>Successfully Clicked On Today Radio Button</br>Successfully Clicked On Search Button. ",
                       "Failed To Click On Adoption Request Link In Admin Page And Searching For Adoption request");
			
			writeReport(EvolveCommonBussinessFunctions.getAdoptionRequestDetails(), "Fetching Account Details From Adoption Request Details Page.", 
					"Sucessfully Clicked On AdoptionNumber: "+adoptionRequest_getAdoptionNum+"</br>Successfully Fetched Username: "+adoptionRequest_Username+"</br>Successfully Fetched FirstName: "+adoptionRequest_FirstName+"</br>Successfully Fetched Lastname: "+adoptionRequest_LastName+"</br>Successfully Fetched Email: "+adoptionRequest_Email+"</br>Successfully Fetched Institution: "+adoptionRequest_Institution+"</br>Successfully Fetched PhoneNumber: "+adoptionRequest_Phone+"</br>Successfully Fetched StreetAdress: "+ adoptionRequest_Adress+"</br>Successfully Fetched Format: "+adoptionRequest_Format, 
					"Failed To Click On AdoptionNumber: "+adoptionRequest_getAdoptionNum+"</br>Failed to Fetch Account Details From Adoption Request Details Page. ");
			
			String URL="true";
			String chkbx="false";
			String key="false";
			compareStatus=ReadingExcel.columnDataByHeaderName("Status","SchoolHostedCommonData",configProps.getProperty("TestData"));
			String Status=ReadingExcel.columnDataByHeaderName("changeStatus","SchoolHostedCommonData",configProps.getProperty("TestData"));
			String downloadURL=ReadingExcel.columnDataByHeaderName("downloadURL","SchoolHostedCommonData",configProps.getProperty("TestData"));
			String KeyValue=ReadingExcel.columnDataByHeaderName("keyValue","SchoolHostedCommonData",configProps.getProperty("TestData"));
			writeReport(EvolveCommonBussinessFunctions.verifyStatus(lmsvalue,URL,chkbx,key,Status,downloadURL,KeyValue,facultyUser,facultyPwd), "Verify Account Details In Adoption Request Details Page.", 
					"Successfully Verified Username: "+adoptionRequest_Username+"</br>Successfully Verified FirstName: "+adoptionRequest_FirstName+"</br>Successfully Verified Lastname: "+adoptionRequest_LastName+"</br>Successfully Verified Email: "+adoptionRequest_Email+"</br>Successfully Entered URL In Download URL Text Box: "+downloadURL+"</br>Successfully Changed Status To Fulfilled.</br> Successfully Handled Email PopUp. ", 
					"Failed to Verify Account Details In Adoption Request Details Page. ");
			
			
			writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout as "+adminUser, 
					  "Successfully logged out "+adminUser+" admin page.", 
					  "Failed to logout "+adminUser+" admin page.");
			
			SwitchToBrowser("chrome");
			
			writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Launching Evolve Email URL And Login In Into Evolve Email Page.", 
					  "Successfully Launched Evolve Email URL And Successfully logged in into Evolve Email Page.", 
					  "Failed to Launch Evolve Email URL and failed to log in into Evolve Email Page.");
			String emailid=EvolveCommonBussinessFunctions.getAccountDetailsEmail;
			writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(emailid),"Searching For Email ID "+getAccountDetailsEmail,
					"Successfully entered the emailid "+emailid+" in search box.",
					"Failed to enter email id:"+emailid);
			
			String emailTitleMoodle=ReadingExcel.columnDataByHeaderName("titleOfMoodle","SchoolHostedCommonData",configProps.getProperty("TestData"));;
			verifyTitleInEmailBody(emailTitleMoodle);
			
			downloadURL=ReadingExcel.columnDataByHeaderName("downloadURL","SchoolHostedCommonData",configProps.getProperty("TestData"));
			writeReport(EvolveCommonBussinessFunctions.verifyDownloadURLInEmail(downloadURL), " Verifying Download Link in Email Body.", 
					  " Successfully Verified Download URL Link: "+downloadURL +" </br></br> Here is the Mail Body Content for further Reference:"+emailBody, 
					  "Failed To Verify Download URL Link: "+downloadURL+" </br></br> Here is the Mail Body Content for further Reference:"+emailBody);
				
		}
		catch(Exception e){
			System.out.println(e);
		}
}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
