package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.RosterSubmissionfromwithincourse_10438;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;

public class RosterSubmissionfromwithincourse_Script_10438 extends RosterSubmissionfromwithincourse_10438 {
@Test	
public static void rosterSubmissionfromwithincourse_10438() throws Throwable {
	 
	// SwitchToBrowser(ElsevierObjects.studentBrowserType);
	 String user="educator";
	 facultyUser=ReadingExcel.columnDataByHeaderName("facultyUserName", "TC-10438", configProps.getProperty("TestData"));
	facultyPwd=ReadingExcel.columnDataByHeaderName("facultyPassword", "TC-10438", configProps.getProperty("TestData"));
	/* facultyUser=configProps.getProperty("Faculty_User");
	 facultyPwd=configProps.getProperty("Faculty_Pwd");*/
	stepReport("Create and fulfill new LO course for existing instructor.");
	LO_Unique_CourseFulfillment_Faculty_Script_10410 S=new LO_Unique_CourseFulfillment_Faculty_Script_10410();
	S.loUniqueCoursefulfillmentFaculty_10410();
    // LO_Unique_CourseFulfillment_Faculty_Script_10410.loUniqueCoursefulfillmentFaculty_10410();
     Thread.sleep(medium);
     getCourseId1=ReadingExcel.columnDataByHeaderName("courseid1","TC-10410",configProps.getProperty("TestData"));
	 ReadingExcel.updateCellInSheet(1,3,configProps.getProperty("TestData"), "TC-10438",getCourseId1);
     InstructorHeader=ReadingExcel.columnDataByHeaderName("Instructorheader","TC-10438",configProps.getProperty("TestData"));
     StudentHeader=ReadingExcel.columnDataByHeaderName("Studentheader","TC-10438",configProps.getProperty("TestData"));
	 
	stepReport("Create new student user.");
    writeReport(RosterSubmissionfromwithincourse_10438.AccountCreationdetails(),"Create 'LO Unique Course Fulfillment-Faculty' Launch Evolvecert URL and create a new student",
    		                                                                     "Created 'LO Unique Course Fulfillment-Faculty' with CourseId "+getCourseId1 +"</br> Username:"+ facultyUser+ "</br> Password:"+ facultyPwd+ 
    		                                                                     "</br> Launched Successfully Evolvecert URL and </br> Created a new student user and his details are </br>Lastname :"+lastname+"</br>Firstname : "+firstname+"<br>EmailId :"+email+"</br> Username"+username+"</br> Password :"+Password+
    		                                                                     "</br> Faculty details are </br>Lastname :"+Lastname+"</br>Firstname : "+Firstname+"<br>EmailId :"+Email+"</br> Username"+user1+"</br> Password :"+Password1,
    		                                                                     "Failed to create 'LO Unique Course Fulfillment-Faculty' and Launch Evolvecert URL ");

    stepReport("Login as the instructor and open the course."); 
    writeReport(EvolveCommonBussinessFunctions.existingUserLogin(user,facultyUser,facultyPwd),"Launching Evolvecert URL And Login to Application.",
		   	                                                                                   "Launching Evolvecert URL for User is successful </br > Login to Application Using User credentails :"+facultyUser+" is Successful",
			                                                                                   "Launching and Login to Application Using User credentails : "+ facultyUser+" is Failed");
     EvolveCommonBussinessFunctions.getAccountDetails();
     LoEmail = getAccountDetailsEmail;
	 String ID1="true";
     writeReport(RosterSubmissionfromwithincourse_10438.courseIDSearch(ID1),"Verifying course ID's generated in Admin page are in Educator page.",
																		  	"Succesfully verified CourseId "+getCourseId1+". </br> Clicked on "+getCourseId1+".", 
																		  	"Failed to verify CourseId "+getCourseId1+".");
     Thread.sleep(medium);

     stepReport("Submit the course roster through LO.");
     writeReport(RosterSubmissionfromwithincourse_10438.RosterCreation(),"Enter courseid,search product and verify the user",
			                                                             "Successfully product is searched and verified",
			                                                             "Failed to product search and verification");
     
     EvolveCommonBussinessFunctions.instructorLogout();
     Thread.sleep(medium);
     
	 //SwitchToBrowser("firefox");
	 
	 stepReport("Verify the roster emails.");
     RosterSubmissionfromwithincourse_10438.Emailforwarding();
	 	 
	 //SwitchToBrowser("firefox");
	 
	 //RosterSubmissionfromwithincourse_10438.GmailverificationforFaculty();
	 
	 Thread.sleep(medium);
     stepReport("Login as the instructor and verify the roster within LO.");
     RosterSubmissionfromwithincourse_10438.InstructorRelogin();
	 SwitchToBrowser(ElsevierObjects.adminBrowserType);
	 
	 stepReport("Verify the roster within Evolve admin.");
	 writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Enter Admin URL and login with the Credentials",
                                                                   "Successfully launched with Admin URL and logged in with User credentials",
                                                                   "Failed to login with Admin URL and login");
	 RosterSubmissionfromwithincourse_10438.RostersearchingAdmin();
	 
     writeReport(EvolveCommonBussinessFunctions.adminLogout(),"Logout from the admin","Successfully logout from the admin","Failed to logout from the admin");
     SwitchToBrowser(ElsevierObjects.studentBrowserType);
     
     stepReport("Verify course access for the new student.");
     RosterSubmissionfromwithincourse_10438.StudentRelogin();
     
     stepReport("Verify course access for the new student created through the roster submission.");
	 RosterSubmissionfromwithincourse_10438.RosterStudentRelogin();
  }
}
