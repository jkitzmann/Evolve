package com.cigniti.automation.BusinessFunctions;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class QuickEnrollfromPortalAdmin_15599 extends EvolveCommonBussinessFunctions{
	
	public static String Firstname;
	public static String Lastname;
	public static String Email;
	public static String username;
	public static String Password;
	public static String fullname;
	public static String Fullname;
	public static String sFirstname;
	public static String sLastname;
	public static String sEmail;
	public static String username1;
	public static String Password1;
	public static String firstname;
	public static String lastname;
	public static String email;
	public static String username2;
	public static String Password2;
	public static String CouId;
	public static String newstudentuser;
	public static String newstudentPassword;
	public static String newEmail;	
 
  
  public static boolean AccountCreation() throws Throwable {
  try
	 {
	  boolean flag = true;
	  CreateNewUser(ElsevierObjects.STUDENT);
	  Thread.sleep(medium);
	  getAccountDetailsforRoster();
	  Firstname = getAccountDetailsFirstName;
	  Lastname = getAccountDetailsLastName;
	  Email = getAccountDetailsEmail;
	  fullname = Firstname+" "+Lastname;
	  username = credentials[0];
	  Password = credentials[1];
	  System.out.println(username);
	  CreateNewUser(ElsevierObjects.STUDENT);
      Thread.sleep(medium);
      getAccountDetailsforRoster();
      sFirstname = getAccountDetailsFirstName;
	  sLastname = getAccountDetailsLastName;
	  sEmail = getAccountDetailsEmail;
      username1 = credentials[0];
	  Password1 = credentials[1];
	  System.out.println(username1);
	  CreateNewUser(ElsevierObjects.EDUCATOR);
	  Thread.sleep(medium);
	  getAccountDetailsforRoster();
	  firstname = getAccountDetailsFirstName;
	  lastname = getAccountDetailsLastName;
	  email = getAccountDetailsEmail;
	  username2 = credentials[0];
	  Password2 = credentials[1];
	  System.out.println(username2);
	  System.out.println(newstudentuser);
	  System.out.println(newstudentPassword);
	  Fullname = "Zaphod"+" "+"Beeblebrox";
	  Thread.sleep(medium);
	  click(ElsevierObjects.Logout,"Logout button");
	  Thread.sleep(low);
	  return flag;}
      catch(Exception e){return false;}
 }
	  
  public static boolean Rostercreation() throws Throwable {
  try
	{
	  boolean flag = true;	  
	  b=true;
	  if(click(ElsevierObjects.Student_Home_Login,"Click on login button")){
		    Reporters.SuccessReport("Click on login", "Launched Evolvecert URL Successfully and clicked on login");
	  }else{
		  Reporters.failureReport("Click on login", "Failed to Launch Evolvecert URL and click on login");
	  }
	  type(ElsevierObjects.common_login_userName,configProps.getProperty("ecertAdminUserID"),"Enter Username");
	  Thread.sleep(low);
	  type(ElsevierObjects.common_login_passWord,configProps.getProperty("ecertAdminPassword"),"Enter Password");
	  Thread.sleep(low);
	  click(ElsevierObjects.submit,"Login button");
	  Thread.sleep(low);
	  click(ElsevierObjects.myAccount,"My Account");
	  Thread.sleep(low);
	  click(ElsevierObjects.Administration_portal,"Administration Portal");
	  Thread.sleep(low);
	  click(ElsevierObjects.Admin_portal_Courses,"Courses");
	  b=false;
	  String Str = getText(ElsevierObjects.Manage_courses,"Get the title of the page");
	  if(Str!=null){
	      Reporters.SuccessReport("Verify the title of the page","Successfully User is able to verify the Title of the Page and it is :" +Str);
	  }else{
		  Reporters.failureReport("Verify the title of the page","Failed to verify the title of the page");
	  }
	  Thread.sleep(low);
      //step 6
	  b=true;
	  type(ElsevierObjects.Manage_Courses_Filter,CouId,"Enter the courseID in the textbox");
      Thread.sleep(low);
      b=false;
      isElementPresent(ElsevierObjects.Group_Id,"Check the GroupId in the textbox");
      Thread.sleep(low);
      if(isElementPresent(ElsevierObjects.Group_Id_details,"Check the GroupId column")){
    	  Reporters.SuccessReport("Verify the GroupId column","There is one search result that displays the course ID entered in the Group ID column.");
      }else{
    	  Reporters.failureReport("Verify the GroupId column","There is more than one search results that displays the course ID entered in the Group ID column.");
      }
      Thread.sleep(low);
      
      Actions actions = new Actions(driver);
      WebElement tableContent = driver.findElement(ElsevierObjects.Group_Id_details);

      actions.doubleClick(tableContent).build().perform();
      Thread.sleep(high);
      
      Reporters.SuccessReport("Verify courses","Double click on the CourseId and User is get into the course");
      
  	  return flag;}
      catch(Exception e){return false;}
  }
  
  public static boolean StudentEnroll() throws Throwable {
  try
	{
	 boolean flag = true;     
     if(click(ElsevierObjects.course_tools_Administration,"Click on Administrations")){
    	  Reporters.SuccessReport("Click on Administartions","Successfully clicked on Administration");
      }else{
    	  Reporters.failureReport("Click on Administartions","Failed to click on Administration");
      }
      Thread.sleep(low);
      String header = getText(ElsevierObjects.Administration_header,"Get the Header of Administration page");
      if(header!=null){
		   Reporters.SuccessReport("Verify the Header of the Administration page","Section of Administration is verified and the header is:</br> "+header);
	  }else{
		   Reporters.failureReport("Verify the Header of the Administration page","Failed to verify header of Administration page.");
	  }
      Thread.sleep(low);
      switchToFrameById("embeddedTool");
      String Quick = getText(ElsevierObjects.Quick_Enroll,"Get text of Quick Enroll tab");
      if(Quick!=null){
          Reporters.SuccessReport("Verify the Quick Enroll tab","User is able to verify the Quick Enroll </br> "+Quick);
      }else{
    	  Reporters.failureReport("Verify the Quick Enroll tab","Failed to verify Quick Enroll tab");
      }
      Thread.sleep(low);
      if(isElementPresent(ElsevierObjects.Administartion_username,"Verify Username textbox")){
    	  Reporters.SuccessReport("Verify the Username textbox","User is able to verify the Username textbox");
      }else{
    	  Reporters.failureReport("Verify the Username textbox","User is failed to verify the Username textbox");
      }
      Thread.sleep(low);
      isElementPresent(ElsevierObjects.Administartion_Select_Role,"Verify dropdown for Roles");
      String std =  getText(ElsevierObjects.Administartion_Default_Role,"Verify default in the dropdown for Roles");
      if(std!=null){
    	  Reporters.SuccessReport("Verify the dropdown for Roles","User is able to verify the dropdown for Roles </br> and Default Role in dropdown is :"+std);
      }else{
    	  Reporters.failureReport("Verify the dropdown for Roles","User is failed to verify the dropdown for Roles");
      }
      Thread.sleep(low);
      if(isEnabled(ElsevierObjects.Update_Enrollments,"Check the Update Enrollment button")){
    	  Reporters.SuccessReport("Verify the Update Enrollment","User is able to verify the Update Enrollments and it is enabled");
      }else{
    	  Reporters.failureReport("Verify the Update Enrollment","User is failed to verify the Update Enrollments");
      }
      Thread.sleep(low);
      String s3 = username + "," + username1 + "," + newstudentuser;
      b=true;
      type(ElsevierObjects.Administartion_username,s3,"Enter the usernames in the textbox");
      Thread.sleep(low);
      b=false;
      if(selectByValue(ElsevierObjects.Administartion_Select_Role,"student","Select Student from the dropdown")){
    	  Reporters.SuccessReport("Select Student","Successfully Student is selected from the dropdown");
      }else{
    	  Reporters.failureReport("Select Student","Failed to Student select from the dropdown");
      } 
      
      Thread.sleep(low);
      b=true;
      click(ElsevierObjects.Update_Enrollments,"Update Enrollments");
      Thread.sleep(low);
      b=false;
      switchToDefaultFrame();
      Thread.sleep(low);
      String Success = getText(ElsevierObjects.Roster_success,"Get Success Header");
      if(Success!=null){
          Reporters.SuccessReport("Verify Success Header in the page","User is Successfully able to verify the header of the page </br>" +Success);
      }else{
    	  Reporters.failureReport("Verify Success Header in the page","User is Failed to verify header of the page.");
      }
      Thread.sleep(low);
      String enroll = getText(ElsevierObjects.Success_Enroll_update,"Get Enrollment Updated header");
      if(enroll!=null){
          Reporters.SuccessReport("Verify Enrollment Updated in the page","User is Successfully able to verify the Enrollment Updated </br>" +enroll);
      }else{
    	  Reporters.failureReport("Verify Enrollment Updated in the page","User is failed to verify the Enrollment Updated.");
      }
      Thread.sleep(low);
      String Ok  = getText(ElsevierObjects.Roster_Ok,"Get text of OK button");
      if(Ok!=null){
          Reporters.SuccessReport("Verify OK button in the page","User is Successfully able to verify the OK button </br>" +Ok);
      }else{
    	  Reporters.failureReport("Verify OK button in the page","User is failed to verify the OK button");
      }
      Thread.sleep(low);
      b=true;
      click(ElsevierObjects.Roster_Ok,"OK button");
      Thread.sleep(low);
      click(ElsevierObjects.Rosters_teams,"Rosters and Teams");
      Thread.sleep(low);
      b=false;
      switchToFrameById("embeddedTool");
      //table two rows comparision
      String user = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+username+"')]"),"Get the Student Username");
      if(user!=null){
   	     Reporters.SuccessReport("Verify Student Username from the table","Successfully Student Username is verified </br>" +user);
      }else{
   	     Reporters.failureReport("Verify Student Username from the table","Failed to verify Student Username");
      }
      String fname = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+username+"')]/following-sibling::td[contains(text(),'"+fullname+"')]"),"Get the Student fullname");
      if(fname!=null){
  	     Reporters.SuccessReport("Verify Student fullname from the table","Successfully Student fullname is verified </br>" +fname);
      }else{
  	     Reporters.failureReport("Verify Student fullname from the table","Failed to verify Student fullname");
      }
      String role = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+username+"')]/following-sibling::td[contains(text(),'Student')]"),"Get the Role of user");
      if(role!=null){
   	   Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +role);
      }else{
   	   Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
      }
      String email = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+username+"')]/following-sibling::td[contains(text(),'"+Email+"')]"),"Get the EmailId of User");
      if(email!=null){
   	     Reporters.SuccessReport("Verify Student EmailId from the table","Successfully Student EmailId is verified </br>" +email);
      }else{
   	     Reporters.failureReport("Verify Student EmailId from the table","Failed to verify Student EmailId");
      } 
      if(isChecked(By.xpath(" .//*[@id='rosterTable']//td[text()='"+username+"']//following-sibling::td[4]/input"),"HasAccess")){
	      Reporters.SuccessReport("Verify HasAccess Checkbox","HasAccess is Checked for this User");
      }else{
  	      Reporters.failureReport("Verify HasAccess Checkbox","HasAccess is UnChecked for this User");
      }
      Thread.sleep(medium);
      String user1 = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+username1+"')]"),"Get the Student Username");
      if(user1!=null){
   	   Reporters.SuccessReport("Verify Student Username from the table","Successfully Student Username is verified </br>" +user1);
      }else{
   	   Reporters.failureReport("Verify Student Username from the table","Failed to verify Student Username");
      }
      String fname1 = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+username1+"')]/following-sibling::td[contains(text(),'"+fullname+"')]"),"Get the Student fullname");
      if(fname1!=null){
   	     Reporters.SuccessReport("Verify Student fullname from the table","Successfully Student fullname is verified </br>" +fname1);
      }else{
   	     Reporters.failureReport("Verify Student fullname from the table","Failed to verify Student fullname");
      }
      String role1 = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+username1+"')]/following-sibling::td[contains(text(),'Student')]"),"Get the Role of user");
      if(role1!=null){
   	     Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +role1);
      }else{
   	     Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
      }
      String email1 = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+username1+"')]/following-sibling::td[contains(text(),'"+sEmail+"')]"),"Get the EmailId of User");
      if(email1!=null){
    	  Reporters.SuccessReport("Verify Student EmailId from the table","Successfully Student EmailId is verified </br>" +email1);
      }else{
    	  Reporters.failureReport("Verify Student EmailId from the table","Failed to verify Student EmailId");
      } 
      if(isChecked(By.xpath(".//*[@id='rosterTable']//td[text()='"+username1+"']//following-sibling::td[4]/input"),"HasAccess")){
	      Reporters.SuccessReport("Verify HasAccess Checkbox","HasAccess is Checked for this User");
      }else{
  	      Reporters.failureReport("Verify HasAccess Checkbox","HasAccess is UnChecked for this User");
      }
      Thread.sleep(medium);
      String Ruser = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+newstudentuser+"')]"),"Get the Roster Student Username");
      if(Ruser!=null){
   	   Reporters.SuccessReport("Verify Student Username from the table","Successfully Student Username is verified </br>" +Ruser);
      }else{
   	   Reporters.failureReport("Verify Student Username from the table","Failed to verify Student Username");
      }
      String Rname1 = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+newstudentuser+"')]/following-sibling::td[contains(text(),'"+Fullname+"')]"),"Get the Student fullname");
      if(Rname1!=null){
   	     Reporters.SuccessReport("Verify Student fullname from the table","Successfully Student fullname is verified </br>" +Rname1);
      }else{
   	     Reporters.failureReport("Verify Student fullname from the table","Failed to verify Student fullname");
      }
      String Rrole1 = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+newstudentuser+"')]/following-sibling::td[contains(text(),'Student')]"),"Get the Role of user");
      if(role1!=null){
   	     Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +Rrole1);
      }else{
   	     Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
      }
      String Remail = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+newstudentuser+"')]/following-sibling::td[contains(text(),'"+newEmail+"')]"),"Get the EmailId of User");
      if(Remail!=null){
    	  Reporters.SuccessReport("Verify Student EmailId from the table","Successfully Student EmailId is verified </br>" +Remail);
      }else{
    	  Reporters.failureReport("Verify Student EmailId from the table","Failed to verify Student EmailId");
      } 
      if(isChecked(By.xpath(".//*[@id='rosterTable']//td[text()='"+newstudentuser+"']//following-sibling::td[4]/input"),"HasAccess")){
	      Reporters.SuccessReport("Verify HasAccess Checkbox","HasAccess is Checked for this User");
      }else{
  	      Reporters.failureReport("Verify HasAccess Checkbox","HasAccess is UnChecked for this User");
      }
      return flag;}
      catch(Exception e){return false;}
  }
      
      //step = 11
  public static boolean FacultyEnroll() throws Throwable {
  try
	 {
	  boolean flag = true;  
	  switchToDefaultFrame();
      if(click(ElsevierObjects.course_tools_Administration,"Click on Administrations")){
    	  Reporters.SuccessReport("Click on Administartions","Successfully clicked on Administration");
      }else{
    	  Reporters.failureReport("Click on Administartions","Failed to click on Administration");
      }
      String header = getText(ElsevierObjects.Administration_header,"Get the Header of Administration page");
      if(header!=null){
		   Reporters.SuccessReport("Verify the Header of the Administration page","Successfully Section of Administration is verified and the header is:</br> "+header);
	  }else{
		   Reporters.failureReport("Verify the Header of the Administration page","Failed to verify header of Administration page.");
	  }
      Thread.sleep(low);
      switchToFrameById("embeddedTool");
      String Quick = getText(ElsevierObjects.Quick_Enroll,"Get text of Quick Enroll tab");
      if(Quick!=null){
          Reporters.SuccessReport("Verify the Quick Enroll tab","User is Successfully able to verify the Quick Enroll </br> "+Quick);
      }else{
    	  Reporters.failureReport("Verify the Quick Enroll tab","Failed to verify Quick Enroll tab");
      }
      Thread.sleep(low);
      if(isElementPresent(ElsevierObjects.Administartion_username,"Verify Username textbox")){
    	  Reporters.SuccessReport("Verify the Username textbox","User is Successfully able to verify the Username textbox");
      }else{
    	  Reporters.failureReport("Verify the Username textbox","User is failed to verify the Username textbox");
      }
      Thread.sleep(low);
      isElementPresent(ElsevierObjects.Administartion_Select_Role,"Verify dropdown for Roles");
      String std =  getText(ElsevierObjects.Administartion_Default_Role,"Verify default in the dropdown for Roles");
      if(std!=null){
    	  Reporters.SuccessReport("Verify the dropdown for Roles","User is able to verify the dropdown for Roles </br> and Default Role in dropdown is :"+std);
      }else{
    	  Reporters.failureReport("Verify the dropdown for Roles","User is failed to verify the dropdown for Roles");
      }
      Thread.sleep(low);
      if(isEnabled(ElsevierObjects.Update_Enrollments,"Check the Update Enrollment button")){
    	  Reporters.SuccessReport("Verify the Update Enrollment","User is able to verify the Update Enrollments and it is enabled");
      }else{
    	  Reporters.failureReport("Verify the Update Enrollment","User is failed to verify the Update Enrollments");
      }
      b=true;
      type(ElsevierObjects.Administartion_username,username2,"Enter the usernames in the textbox");
      Thread.sleep(low);
      b=false;
      if(selectByValue(ElsevierObjects.Administartion_Select_Role,"instructor","Select Faculty from the dropdown")){
    	  Reporters.SuccessReport("Select Faculty","Successfully Faculty is selected from the dropdown");
      }else{
    	  Reporters.failureReport("Select Faculty","Failed to Faculty select from the dropdown");
      } 
      
      Thread.sleep(low);
      b=true;
      click(ElsevierObjects.Update_Enrollments,"Update Enrollments");
      Thread.sleep(low);
      b=false;
      switchToDefaultFrame();
      Thread.sleep(low);
      String Success = getText(ElsevierObjects.Roster_success,"Get Success Header");
      if(Success!=null){
          Reporters.SuccessReport("Verify Success Header in the page","User is Successfully able to verify the header of the page </br>" +Success);
      }else{
    	  Reporters.failureReport("Verify Success Header in the page","User is Failed to verify header of the page.");
      }
      Thread.sleep(low);
      String enroll = getText(ElsevierObjects.Success_Enroll_update,"Get Enrollment Updated header");
      if(enroll!=null){
          Reporters.SuccessReport("Verify Enrollment Updated in the page","User is Successfully able to verify the Enrollment Updated </br>" +enroll);
      }else{
    	  Reporters.failureReport("Verify Enrollment Updated in the page","User is failed to verify the Enrollment Updated.");
      }
      Thread.sleep(low);
      String Ok  = getText(ElsevierObjects.Roster_Ok,"Get text of OK button");
      if(Ok!=null){
          Reporters.SuccessReport("Verify OK button in the page","User is Successfully able to verify the OK button </br>" +Ok);
      }else{
    	  Reporters.failureReport("Verify OK button in the page","User is failed to verify the OK button");
      }
      Thread.sleep(low);
      b=true;
      click(ElsevierObjects.Roster_Ok,"OK button");
      Thread.sleep(low);
      click(ElsevierObjects.Rosters_teams,"Rosters and Teams");
      Thread.sleep(low);
      b=false;
      switchToFrameById("embeddedTool");
      //verification of columns need to be there
      String user = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+username2+"')]"),"Get Faculty Usename from table");
      if(user!=null){
   	   Reporters.SuccessReport("Verify Faculty Username from the table","Successfully Faculty Username is verified </br>" +user);
      }else{
   	   Reporters.failureReport("Verify Faculty Username from the table","Failed to verify Faculty Username");
      }
      String fname = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+username2+"')]/following-sibling::td[contains(text(),'"+fullname+"')]"),"Get the fullname of user");
      if(fname!=null){
   	     Reporters.SuccessReport("Verify Faculty fullname from the table","Successfully Faculty fullname is verified </br>" +fname);
      }else{
   	     Reporters.failureReport("Verify Faculty fullname from the table","Failed to verify Faculty fullname");
      }
      String role = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+username2+"')]/following-sibling::td[contains(text(),'Instructor')]"),"Get the Role of User");
      if(role!=null){
      	  Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +role);
      }else{
      	  Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
      }
      String Email = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+username2+"')]/following-sibling::td[contains(text(),'"+email+"')]"),"Get the EmailId of user");
      if(Email!=null){
 	      Reporters.SuccessReport("Verify Faculty EmailId from the table","Successfully Faculty EmailId is verified </br>" +Email);
      }else{
 	      Reporters.failureReport("Verify Faculty EmailId from the table","Failed to verify Faculty EmailId");
      } 
      if(isChecked(By.xpath(".//*[@id='rosterTable']//td[text()='"+username2+"']//following-sibling::td[4]/input"),"HasAccess")){
    	  Reporters.SuccessReport("Verify HasAccess Checkbox","HasAccess is Checked for this User");
      }else{
    	  Reporters.failureReport("Verify HasAccess Checkbox","HasAccess is UnChecked for this User");
      }
      return flag;}
      catch(Exception e){return false;}
   }
      //step 14
   public static boolean UnEnroll() throws Throwable {
   try
     {
      boolean flag = true; 
      switchToDefaultFrame();
      if(click(ElsevierObjects.course_tools_Administration,"Click on Administrations")){
    	  Reporters.SuccessReport("Click on Administartions","Successfully clicked on Administration");
      }else{
    	  Reporters.failureReport("Click on Administartions","Failed to click on Administration");
      }
      String header = getText(ElsevierObjects.Administration_header,"Get the Header of Administration page");
      if(header!=null){
		   Reporters.SuccessReport("Verify the Header of the Administration page","Successfully Section of Administration is verified and the header is:</br> "+header);
	  }else{
		   Reporters.failureReport("Verify the Header of the Administration page","Failed to verify header of Administration page.");
	  }
      Thread.sleep(low);
      switchToFrameById("embeddedTool");
      String Quick = getText(ElsevierObjects.Quick_Enroll,"Get text of Quick Enroll tab");
      if(Quick!=null){
          Reporters.SuccessReport("Verify the Quick Enroll tab","User is Successfully able to verify the Quick Enroll tab </br> "+Quick);
      }else{
    	  Reporters.failureReport("Verify the Quick Enroll tab","Failed to verify Quick Enroll tab");
      }
      Thread.sleep(low);
      if(isElementPresent(ElsevierObjects.Administartion_username,"Verify Username textbox")){
    	  Reporters.SuccessReport("Verify the Username textbox","User is Successfully able to verify the Username textbox");
      }else{
    	  Reporters.failureReport("Verify the Username textbox","User is failed to verify the Username textbox");
      }
      Thread.sleep(low);
      isElementPresent(ElsevierObjects.Administartion_Select_Role,"Verify dropdown for Roles");
      String std =  getText(ElsevierObjects.Administartion_Default_Role,"Verify default in the dropdown for Roles");
      if(std!=null){
    	  Reporters.SuccessReport("Verify the dropdown for Roles","User is able to verify the dropdown for Roles </br> and Default Role in dropdown is :"+std);
      }else{
    	  Reporters.failureReport("Verify the dropdown for Roles","User is failed to verify the dropdown for Roles");
      }
      Thread.sleep(low);
      if(isEnabled(ElsevierObjects.Update_Enrollments,"Check the Update Enrollment button")){
    	  Reporters.SuccessReport("Verify the Update Enrollment","User is able to verify the Update Enrollments and it is enabled");
      }else{
    	  Reporters.failureReport("Verify the Update Enrollment","User is failed to verify the Update Enrollments");
      }
      Thread.sleep(low);
      b=true;
      type(ElsevierObjects.Administartion_username,newstudentuser,"Enter the usernames in the textbox");
      Thread.sleep(medium);
      b=false;
      if(selectByValue(ElsevierObjects.Administartion_Select_Role,"unenroll","Select unenroll from the dropdown")){
    	  Reporters.SuccessReport("Select unenroll","Successfully Unenroll is selected from the dropdown");
      }else{
    	  Reporters.failureReport("Select unenroll","Failed to Unenroll select from the dropdown");
      }
      selectByValue(ElsevierObjects.Administartion_Select_Role,"unenroll","Select unenroll from the list");
      Thread.sleep(medium);
      b=true;
      click(ElsevierObjects.Update_Enrollments,"Update Enrollments");
      Thread.sleep(low);
      b=false;
      switchToDefaultFrame();
      Thread.sleep(low);
      String Success = getText(ElsevierObjects.Roster_success,"Get Success Header");
      if(Success!=null){
          Reporters.SuccessReport("Verify Success Header in the page","User is Successfully able to verify the header of the page </br>" +Success);
      }else{
    	  Reporters.failureReport("Verify Success Header in the page","User is Failed to verify header of the page.");
      }
      Thread.sleep(low);
      String enroll = getText(ElsevierObjects.Success_Enroll_update,"Get Enrollment Updated header");
      if(enroll!=null){
          Reporters.SuccessReport("Verify Enrollment Updated in the page","User is Successfully able to verify the Enrollment Updated </br>" +enroll);
      }else{
    	  Reporters.failureReport("Verify Enrollment Updated in the page","User is failed to verify the Enrollment Updated.");
      }
      Thread.sleep(low);
      String Ok  = getText(ElsevierObjects.Roster_Ok,"Get text of OK button");
      if(Ok!=null){
          Reporters.SuccessReport("Verify OK button in the page","User is Successfully able to verify the OK button </br>" +Ok);
      }else{
    	  Reporters.failureReport("Verify OK button in the page","User is failed to verify the OK button");
      }
      Thread.sleep(low);
      b=true;
      click(ElsevierObjects.Roster_Ok,"OK button");
      Thread.sleep(medium);
      click(ElsevierObjects.Rosters_teams,"Rosters and Teams");
      Thread.sleep(high);
      b=false;
      switchToFrameById("embeddedTool");
		//verification of unenroll row
      if(newstudentuser==null){
    	  Reporters.failureReport("Verify user is Unenroll from the table","Failed to Unenroll user from the table </br>"+newstudentuser);
      }else{
    	  Reporters.SuccessReport("Verify user is Unenroll from the table","User is Successfully Unenroll from the table");
      }
	  return flag;}
      catch(Exception e){return false;}
   }

   public static boolean StudentRelogin() throws Throwable{
    try
	   {
		boolean flag = true;
		switchToDefaultFrame();
		EvolveCommonBussinessFunctions.instructorLogout();
		Thread.sleep(medium);
		launchUrl(configProps.getProperty("URL4"));
		b=true;
		Thread.sleep(low);
		if(click(ElsevierObjects.Student_Home_Login,"Click on login button")){
			 Reporters.SuccessReport("Click on login", "Launched Evolvecert URL Successfully and clicked on login");
		}else{
			 Reporters.failureReport("Click on login", "Failed to Launch Evolvecert URL and click on login");
		}
		Thread.sleep(low);
		type(ElsevierObjects.common_login_userName,username,"Enter username");
		Thread.sleep(low);
		type(ElsevierObjects.common_login_passWord,Password,"Enter Password");
		Thread.sleep(low);
		if(click(ElsevierObjects.submit,"Click on login button")){
	          Reporters.SuccessReport("Click on login", "User is Successfully login with the created student details");
	    }else{
		     Reporters.failureReport("Click on login", "User is failed to login with the created student details");
	    }
		Thread.sleep(low);
		b=true;
		click(ElsevierObjects.Myevolve,"My Evolve");
		Thread.sleep(low);
		b=false;
		String Id = getText(ElsevierObjects.Roster_Evolve_CourseId,"Get Unique CourseId");
		if(Id.contains(CouId)){
			 Reporters.SuccessReport("Verify Unique CourseId","User is Successfully verified CourseId </br> Actual CourseId is :"+CouId+"</br> Expected CourseId is: "+Id);
		}else{
			 Reporters.failureReport("Verify Unique CourseId","User is failed to verify CourseId");
		}
		Thread.sleep(low);
		String Courselink = getText(ElsevierObjects.Roster_Evolve_Courselink,"Get Unique CourseId link");
		if(Courselink!=null){
			Reporters.SuccessReport("Verify Unique CourseId link","User is Successfully verified CourseId link </br>" +Courselink);
		}else{
			Reporters.failureReport("Verify Unique CourseId link","User is failed to verify CourseId link");
		}
		Thread.sleep(low);
		b=true;
		click(ElsevierObjects.Roster_Evolve_Courselink,"Unique CourseId link");
		Thread.sleep(low);
		click(ElsevierObjects.Courses,"Courses");
		Thread.sleep(low);
		b=false;
	    String Protect = getText(ElsevierObjects.Protected_content,"Get title of Protected Content");
	    if(Protect!=null){
	    	Reporters.SuccessReport("Verify title of Protected Content","User is Successfully verified title of Protected Content</br>" +Protect);
	    }else{
	    	Reporters.failureReport("Verify title of Protected Content","User is failed to verify title of Protected Content");
	    }
		Thread.sleep(low);
		if(isElementPresent(ElsevierObjects.redeem_AcessCode_txt,"RedeemAccess Blank textbox")){
			Reporters.SuccessReport("Verify RedeemAccess Blank textbox","User is Successfully verified RedeemAccess Blank textbox");
		}else{
			Reporters.failureReport("Verify RedeemAccess Blank textbox","User is failed to verify RedeemAccess Blank textbox");
		}
	    Thread.sleep(low);
		click(ElsevierObjects.protectedContent_PopUp_cancel_Btn,"Cancel button");
	    EvolveCommonBussinessFunctions.instructorLogout();
		 return flag;}
		 catch(Exception e){return false;}
	}	
   
   public static boolean Studentlogin() throws Throwable{
   try
	  {
	   boolean flag = true;
	   b=true;
	   if(click(ElsevierObjects.Student_Home_Login,"Click on login button")){
			 Reporters.SuccessReport("Click on login", "Launched Evolvecert URL Successfully and clicked on login");
	   }else{
			 Reporters.failureReport("Click on login", "Failed to Launch Evolvecert URL and click on login");
	   }
	   Thread.sleep(low);
	   type(ElsevierObjects.common_login_userName,username1,"Enter username in the textbox");
	   Thread.sleep(low);
	   type(ElsevierObjects.common_login_passWord,Password1,"Enter Password in the textbox");
	   Thread.sleep(low);
	   if(click(ElsevierObjects.submit,"Click on login button")){
	          Reporters.SuccessReport("Click on login", "User is Successfully login with the created student details");
	   }else{
		     Reporters.failureReport("Click on login", "User is failed to login with the created student details");
	   }
	   Thread.sleep(low);
	   b=true;
	   click(ElsevierObjects.Myevolve,"My Evolve");
	   Thread.sleep(low);
	   b=false;
	   String Id = getText(ElsevierObjects.Roster_Evolve_CourseId,"Get Unique CourseId");
	   if(Id.contains(CouId)){
			 Reporters.SuccessReport("Verify Unique CourseId","User is Successfully verified CourseId </br> Actual CourseId is :"+CouId+"</br> Expected CourseId is: "+Id);
		}else{
			 Reporters.failureReport("Verify Unique CourseId","User is failed to verify CourseId");
		}
	   Thread.sleep(low);
	   String Courselink = getText(ElsevierObjects.Roster_Evolve_Courselink,"Get Unique CourseId link");
	   if(Courselink!=null){
			Reporters.SuccessReport("Verify Unique CourseId link","User is Successfully verified CourseId link </br>" +Courselink);
	   }else{
			Reporters.failureReport("Verify Unique CourseId link","User is failed to verify CourseId link");
	   }
	   Thread.sleep(low);
	   b=true;
	   click(ElsevierObjects.Roster_Evolve_Courselink,"Unique CourseId link");
	   Thread.sleep(low);
	   click(ElsevierObjects.Courses,"Courses");
	   Thread.sleep(low);
	   b=false;
	   String Protect = getText(ElsevierObjects.Protected_content,"Get title of Protected Content");
	   if(Protect!=null){
	    	Reporters.SuccessReport("Verify title of Protected Content","User is Successfully verified title of Protected Content</br>" +Protect);
	   }else{
	    	Reporters.failureReport("Verify title of Protected Content","User is failed to verify title of Protected Content");
	   }
	   Thread.sleep(low);
	   if(isElementPresent(ElsevierObjects.redeem_AcessCode_txt,"RedeemAccess Blank textbox")){
		    Reporters.SuccessReport("Verify RedeemAccess Blank textbox","User is Successfully verified RedeemAccess Blank textbox");
	   }else{
			Reporters.failureReport("Verify RedeemAccess Blank textbox","User is failed to verify RedeemAccess Blank textbox");
	   }
	   Thread.sleep(low);
	   click(ElsevierObjects.protectedContent_PopUp_cancel_Btn,"Cancel button");
	   EvolveCommonBussinessFunctions.instructorLogout();
		return flag;}
	    catch(Exception e){return false;}
	}		
  
   public static boolean FacultyRelogin() throws Throwable{
   try
	  {
	    boolean flag = true;
		launchUrl(configProps.getProperty("URL3"));
		Thread.sleep(low);
		b=true;
		if(click(ElsevierObjects.Student_Home_Login,"Click on login button")){
			 Reporters.SuccessReport("Click on login", "Launched Evolvecert URL Successfully and clicked on login");
		}else{
			 Reporters.failureReport("Click on login", "Failed to Launch Evolvecert URL and click on login");
		}
	    Thread.sleep(low);
  	    type(ElsevierObjects.common_login_userName,username2,"Enter username in the textbox");
	    Thread.sleep(low);
	    type(ElsevierObjects.common_login_passWord,Password2,"Enter Password in the textbox");
	    Thread.sleep(low);
	    if(click(ElsevierObjects.submit,"Click on login button")){
	          Reporters.SuccessReport("Click on login", "User is Successfully login with the created faculty details");
	    }else{
		     Reporters.failureReport("Click on login", "User is failed to login with the created faculty details");
	    }
	    Thread.sleep(low);
        b=true;	   
		click(ElsevierObjects.Myevolve,"My Evolve");
	    Thread.sleep(low);
	    b=false;
	    String Id = getText(ElsevierObjects.Roster_Evolve_CourseId,"Get Unique CourseId");
	    if(Id.contains(CouId)){
			 Reporters.SuccessReport("Verify Unique CourseId","User is Successfully verified CourseId </br> Actual CourseId is :"+CouId+"</br> Expected CourseId is: "+Id);
		}else{
			 Reporters.failureReport("Verify Unique CourseId","User is failed to verify CourseId");
		}
		Thread.sleep(low);
		String Courselink = getText(ElsevierObjects.Roster_Evolve_Courselink,"Get Unique CourseId link");
		if(Courselink!=null){
			 Reporters.SuccessReport("Verify Unique CourseId link","User is Successfully verified CourseId link </br>" +Courselink);
		}else{
			 Reporters.failureReport("Verify Unique CourseId link","User is failed to verify CourseId link");
		}
		Thread.sleep(low);
		b=true;
	    click(ElsevierObjects.Roster_Evolve_Courselink,"Unique CourseId link");
	    Thread.sleep(low);
	    click(ElsevierObjects.Courses,"Courses");
	    b=false;	
		Thread.sleep(low);
		List<WebElement> s=driver.findElements(ElsevierObjects.educator_CoursePage_SubFolders);
	     for(WebElement subFolder:s){
	    if(waitForElementPresent(ElsevierObjects.educator_CoursePage_SubFolders, "Course folder contains sub folders.")){
	        Reporters.SuccessReport("Verifying subfolders.", "Verified Subfolders of Course Folder.</br>SubFolder is:"+subFolder.getText());
	    }
	    else{
	        Reporters.failureReport("Verifying subfolders.", "Failed To Verify Subfolders of Course Folder.");
	    }
	   }
		EvolveCommonBussinessFunctions.instructorLogout();
		  return flag;}
		  catch(Exception e){return false;}
   }	
   
   public static boolean newuserRelogin() throws Throwable{
   try
	  {
	   boolean flag = true;
	   launchUrl(configProps.getProperty("URL4"));
	   Thread.sleep(low);
	   b =true;
	   if(click(ElsevierObjects.Student_Home_Login,"Click on login button")){
			Reporters.SuccessReport("Click on login", "Launched Evolvecert URL Successfully and clicked on login");
	   }else{
			Reporters.failureReport("Click on login", "Failed to Launch Evolvecert URL and click on login");
	   }
	   Thread.sleep(low);
	   type(ElsevierObjects.common_login_userName,newstudentuser,"Enter username in the textbox");
	   Thread.sleep(low);
	   type(ElsevierObjects.common_login_passWord,newstudentPassword,"Enter Password in the textbox");
	   Thread.sleep(low);
	   if(click(ElsevierObjects.submit,"Click on login button")){
	        Reporters.SuccessReport("Click on login", "User is Successfully login with the created Rostered student details");
	   }else{
		   Reporters.failureReport("Click on login", "User is failed to login with the created Rostered student details");
	   }
	   b =true;
	   click(ElsevierObjects.Myevolve,"My Evolve");
	   Thread.sleep(low);
	   b =false;
	   if(CouId==null){
	    	Reporters.failureReport("Verify CourseId","Failed to Unenroll user and the CourseId is present in the user's content list </br>" +CouId);
	   }else{
	    	Reporters.SuccessReport("Verify CourseId","User is Successfully Unenroll User that the course ID no longer is present in the user's content list");
	   }
	   EvolveCommonBussinessFunctions.instructorLogout();
	   return flag;}
	   catch(Exception e){return false;}
	 }		
				
 }
 
	 

