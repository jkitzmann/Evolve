package com.cigniti.automation.BusinessFunctions;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Reporter;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Test.Enrollment_10437_Script;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class Enrollments_10437  extends EvolveCommonBussinessFunctions{

	public static String name;
	public static String pswrd;

	//====variables for new student creation 
	public static String studentUserName ; 
	public static String studentPassword ;

	//variables for new faculty creation
	public static String eUseName;
	public static String ePassword;

	//==variable for courseID getting from selfEnroll=====//
	public static String selfCourseID;
	public static String enrolledStudent;
	public static String enrolledpassword;
	@Override
	public boolean adminLogin() throws Throwable {

		return super.adminLogin();

	}
	

	public static void  verifyingPageDisplay(List<Map<String, String>> resourcesMap)throws Throwable
	{
		try{
			launchUrl(configProps.getProperty("URL3"));
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			writeReport((User_BusinessFunction.Educatorlogin(configProps.getProperty("ecertAdminUserID"),configProps.getProperty("ecertAdminPassword"))), "Log into evolvecert.elsevier.com as a user who has access to portal Admin",
					"Successfully Logged into the 'evolvecert.elsevier.com' using User credentials are.</br> Username : " +configProps.getProperty("ecertAdminUserID")+"</br> password : "+ configProps.getProperty("ecertAdminPassword"),
			"failed to log in 'evolvecert.elsevier.com' ");
			Thread.sleep(medium);
			b=true;
			click(ElsevierObjects.myAccount,"'My Account' link");

			click(ElsevierObjects.administrationPortal_lnk, "'Administration Portal' in the 'My Account' link");

			click(ElsevierObjects.enrollment_Lnk, "'Enrollments' link from the Administration Portal page");
			b=false;
			Thread.sleep(low);

			//====Report for  enter user name(from Step #1), course Id and select role as student
			if(type(ElsevierObjects.username, resourcesMap.get(0).get("userName"), " username(from Step #1),and >>") &&type(ElsevierObjects.resourceId, resourcesMap.get(0).get("courserId"), "Enter the courseID>>") &&selectByValue(ElsevierObjects.role, resourcesMap.get(0).get("role"), "role as student>>"))
				Reporters.SuccessReport("Enter the username, courseID and select role as student ", "Successfully Enter the username(from Step #1) "+studentUserName+"</br> courseID : "+selfCourseID+"and select role as "+resourcesMap.get(0).get("role"));

			else
				Reporters.failureReport("Enter the username, courseID and select role as student ", "failed to enter the student from step#1");


			//====Report for  enter  user name(from Step #2), course Id and select role as faculty
			if(type(ElsevierObjects.username1, resourcesMap.get(1).get("userName"), "Enter the User name>>") && type(ElsevierObjects.resourceId1, resourcesMap.get(1).get("courserId"),"Enter the courseID>>")&&selectByValue(ElsevierObjects.role1, resourcesMap.get(1).get("role"), "Enter the role assigned to him>>"))
				Reporters.SuccessReport("Enter UserName, courseID and select role as faculty","Successfully Enter the UserName(from Step #2) "+eUseName+"</br> courseID : "+selfCourseID+"and select role as "+resourcesMap.get(1).get("role"));
			else
				Reporters.failureReport("Enter UserName, courseID and select role as faculty", "failed to enter the user from step #2");


			//====Report for  enter  user name(from Step #3), course Id and select to unEnroll user from any unique course.
			if(type(ElsevierObjects.username2, resourcesMap.get(2).get("userName"), "Enter the User name>>")&&type(ElsevierObjects.resourceId2, resourcesMap.get(2).get("courserId"), "Enter the courseID>>")&&selectByValue(ElsevierObjects.role2, resourcesMap.get(2).get("role"), "Enter the role assigned to him>>"))
				Reporters.SuccessReport("Enter UserName, courseID and select to unEnroll user from any unique course.","Successfully Enter the UserName(from Step #3) "+enrolledStudent+"</br> courseID : "+selfCourseID+"and select role as" +resourcesMap.get(2).get("role"));
			else
				Reporters.failureReport("Enter user name, courseID and select to unEnroll user from any unique course.", "failed to enter the user for unEnroll");

			b=true;
			click(ElsevierObjects.submit_Bt,"hit the submit button");
			b=false;

			//String user1VerifyEnr = getText(ElsevierObjects.visible_Text, "verify the Text");
			if(getText(ElsevierObjects.visible_Text, "verify the Text").contains("API enroll successful") && getText(ElsevierObjects.visible_Text2, "verify the Text").contains("API enroll successful")){
				Reporters.SuccessReport("verify the user1 & user2 success Messages", "successfully Two will say: 'Enrollment updated. API enroll successful.' ");
			}
			else
			{
				Reporters.failureReport("verify the user1 & user2 success Messages", "failed to verify the text");
			}
			String user3VerifyEnr=getText(ElsevierObjects.visible_Text3, "verifying the text ");

			if(user3VerifyEnr.contains("API unenroll successful."))
			{
				Reporters.SuccessReport("verify the user3 Success Messages", "successfully verified One will say:  'Enrollment updated. API unEnroll successful.' the text");
			}
			else
			{
				Reporters.failureReport("verify the user3 success Messages", "failed to verify the text");

			}
			User_BusinessFunction.Logout();


		}catch (Exception e) 
		{

			e.printStackTrace();
			System.out.println(e.getMessage());
		}

	}




	//=========================End Of The Method==============================================//




	public static void  processMyEvovle(String userType)throws Throwable
	{
		
		Thread.sleep(medium);
		System.out.println("===>>In Process My Evolve");

		if(!click(ElsevierObjects.lnkevolve," 'My Evolve' tab")){
			flag=false;
		}
		try{
			Thread.sleep(100);
			if(userType.equalsIgnoreCase("student"))
			{

				Thread.sleep(high);
				click(ElsevierObjects.refresh_Btn,"click on the Refresh Button");
				Thread.sleep(medium);
				b=true;
				click(ElsevierObjects.courseIDLink_InUsers_ContentList, "new link for the enrolled course within the user's content list, Course Link of CourseID :"+selfCourseID+" And Navigated To Course Details Page.");
				Thread.sleep(veryhigh);

				click(ElsevierObjects.CONTENT_HOME, "'Content_Home' link in the left hand side of the course library page");

				click(ElsevierObjects.Course_in_ContentHome_page,"'Course' link in the content home page ");
				b=false;

				//click(ElsevierObjects.COURSE_LINK, " 'Course' library folder in the left hand menu of the course");
				Thread.sleep(medium);

				String protetedContentTitle = getText(ElsevierObjects.protectedContent_Title, "");

				if((protetedContentTitle.contains("Protected Content"))&&isElementPresent(ElsevierObjects.redeem_AcessCode_txt, "verify the redeem AcessCode text field is present"))

				{
					Reporters.SuccessReport("verify PopUp title & it's Content","successfully verify's the popUp title and appearance of the 'Redeem Access Code Text_Field'");
					b=true;
					click(ElsevierObjects.protectedContent_PopUp_cancel_Btn, "'Cancel' button"); 
					b=false;
				}
				else
				{
					Reporters.failureReport("verify PopUp title & it's Content","unable to verify the popUp title and appearance of the 'Redeem Access Code Text_Field'");

				}
				User_BusinessFunction.Logout();
			}
			Thread.sleep(medium);


			if(userType.equalsIgnoreCase("Faculty")){

				Thread.sleep(high);
				click(ElsevierObjects.refresh_Btn,"click on the Refresh Button");
				Thread.sleep(medium);

				if(click(By.xpath("//*[@id='set']/li/div/div/span[text()='COURSE ID: "+selfCourseID+"']/following-sibling::a"),"Click on Course Title.")){
					Reporters.SuccessReport("Clicking on the new link for the enrolled course within the user's content list. ", "Successfully Clicked On Course Link of CourseID :"+selfCourseID+".Navigated To Course Details Page.");
				}
				else{
					Reporters.failureReport("Clicking on the new link for the enrolled course within the user's content list. ", "Failed To Click On Course Link of CourseID :"+selfCourseID+" And Failed To Navigate To Course Details Page.");
				}
				Thread.sleep(60000);
				//driver.manage().timeouts().implicitlyWait(600, TimeUnit.SECONDS);
				b=true;
				click(ElsevierObjects.CONTENT_HOME, "'Content_Home' link in the left hand side of the course library page");
				click(ElsevierObjects.Course_in_ContentHome_page,"'Course' link in the content home page.<br/> The folder should now display subFolders.<br/>No pop up is displayed to the user ");
				b=false;

				User_BusinessFunction.Logout();

			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}


	//=========================End Of The Method==============================================//



	public static void processMyEvovleForUnenrollUser() throws Throwable
	{
		Thread.sleep(medium);
		System.out.println("===>>In Process My Evolve");

		if(!click(ElsevierObjects.lnkevolve," 'My Evolve' tab")){
			flag=false;
		}
		try{

			Thread.sleep(medium);
			click(ElsevierObjects.refresh_Btn,"click on the Refresh Button");
			Thread.sleep(medium);

			String nolink=getText(By.xpath(".//*[@id='el-pane']/div/div[2]"), "");
			if(nolink != null)
			{
				Reporters.SuccessReport("verify there is NOT a link in the user's content list for the enrolled course ID", "Successfully verified there is NO link in the user's content list for the course ID, Because this student was unEnrolled.");
			}
			else
			{
				Reporters.failureReport("verify there is NOT a link in the user's content list for the enrolled course ID", "failed to verify the link ");
			}
			User_BusinessFunction.Logout();

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}


}


//=========================End Of The Method==============================================//






