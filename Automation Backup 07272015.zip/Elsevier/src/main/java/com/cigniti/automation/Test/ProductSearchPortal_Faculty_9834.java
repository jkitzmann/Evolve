package com.cigniti.automation.Test;

import java.util.Random;

import jxl.Sheet;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ElsevierConstants;
import com.cigniti.automation.Utilities.ExcelLib;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class ProductSearchPortal_Faculty_9834 extends User_BusinessFunction {
	
	//**************************** Declarations *****************************************************
 	//public static Sheet inputSheetObj =null;
 	 // Input sheet file name

 	/*@BeforeTest
	public void excelLoad1() throws Exception
	{
	// Provide sheet path  and sheet name , will return the respective sheet object			
	inputSheetObj=ExcelLib.getSheetObject(ElsevierConstants.EXCEL_INPUT_SHEET_PATH,"TC-9810");		
	System.out.println("Test Data Accessed Successfully");
	SwitchToBrowser(ElsevierObjects.studentBrowserType);

	}
*/Random ra = new Random( System.currentTimeMillis() );
	
	@Test
	public void ProductSearchPortal_Faculty_9834() throws Throwable
	
	{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		SwitchToBrowser(ElsevierObjects.studentBrowserType);

		String Catalogs=ReadingExcel.columnDataByHeaderName("Catalogs", "TC-9834", configProps.getProperty("TestData"));
		String Catalogs1=ReadingExcel.columnDataByHeaderName("Catalogs1", "TC-9834", configProps.getProperty("TestData"));
		String honeyPotString=ReadingExcel.columnDataByHeaderName("HoneyPots", "TC-9834", configProps.getProperty("TestData"));
		String [] HoneyPots=honeyPotString.split(",");
		System.out.println(Catalogs);
		
		
		writeReport(User_BusinessFunction.Educatorlogin(sEducatorUser, sEducatorPassword),"Login to Application Using Educator Credentials"+sEducatorUser,
                "Launching the URL for Educator is successful </br > Login to Application Using Educator credentails :"+sEducatorUser+" is Successful",
                "Launching and Login to Application Using Educator credentails : "+ sEducatorUser+" is Failed");
		Thread.sleep(10000);
		writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as:"+sEducatorUser,
                                                                 "Navigating to CATALOG page is Successful",
                                                                 "Navigating to CATALOG Page is failed");

		writeReport(User_BusinessFunction.HESI_Search(Catalogs),"Searching for Value:"+Catalogs,
                                                                   "Entered "+Catalogs+" to Search </br > Click on Go Button",
                                                                   "Unable to Search for : "+ Catalogs);
		
		Thread.sleep(medium);

		writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Authorlocator,ElsevierObjects.Title,ElsevierObjects.ProductTypeLocatorforFaculty,Catalogs),"Verifying Values Present in Results",
                                                                                     "The Acutal Value from  Application is : </br>"+Catalogs+"</br> is Presented in the Exepcted Values  of all first page results, Hence Search is as expected",
                                                                                     "The Acutal Value from  Application is : </br>"+Catalogs+"</br> is Not Presented in the Exepcted Values  of all first page results, Hence Search is not as expected");

		writeReport(User_BusinessFunction.HESI_Search(Catalogs,Catalogs1),"Searching for Value:"+Catalogs +"And "+Catalogs1,
                "Entered "+Catalogs+" and "+Catalogs1 +"to Search </br > Click on Go Button",
                "Unable to Search for : "+ Catalogs +" And "+Catalogs1 );

		
		writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Authorlocator,ElsevierObjects.Title,ElsevierObjects.ProductTypeLocatorforFaculty,Catalogs,Catalogs1),"Verifying Values Present in Results",
                "The Acutal Value from  Application is : </br>"+Catalogs+"</br> is Presented in the Exepcted Values  of all first page results, Hence Search is as expected",
                "The Acutal Value from  Application is : </br>"+Catalogs+"</br> is Not Presented in the Exepcted Values  of all first page results, Hence Search is not as expected");

	    		
		writeReport(User_BusinessFunction.Educatorlogin(sEducatorUser, sEducatorPassword),"Login to Application Using Educator Credentials"+sEducatorUser,
                "Launching the URL for Educator is successful </br > Login to Application Using Educator credentails :"+sEducatorUser+" is Successful",
                "Launching and Login to Application Using Educator credentails : "+ sEducatorUser+" is Failed");

		/*writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as:"+sEducatorUser,
                                                                 "Navigating to CATALOG page is Successful",
                                                                 "Navigating to CATALOG Page is failed");
*/
		for(int i=0;i<=HoneyPots.length;i++)
		{
		writeReport(User_BusinessFunction.NavigateToCatalogHome(),"Navigating to CATALOG Page using Roles as: "+sEducatorUser ,
                "Navigating to CATALOG page is Successful", 
                "Navigating to CATALOG Page is failed");

		Thread.sleep(medium);
		writeReport(User_BusinessFunction.SearchinHoneyPots_Faculty(HoneyPots[i], Catalogs1),"Searching In Honey Pot: "+HoneyPots[i],
                "Searching "+Catalogs1+" from "+HoneyPots[i]+" Honey Pot page is Successful",
                "Searching "+Catalogs1+" from "+HoneyPots[i]+" Honey Pot page is not Successful");
		
		writeReport(User_BusinessFunction.VerifyValueinResults(ElsevierObjects.Authorlocator,ElsevierObjects.Title,ElsevierObjects.ProductTypeLocatorforFaculty,Catalogs1),"Verifying Values Present in Results",
                "The Acutal Value from  Application is : </br>"+Catalogs1+"</br> is Presented in the Exepcted Values  of all first page results, Hence Search is as expected",
                "The Acutal Value from  Application is : </br>"+Catalogs1+"</br> is Not Presented in the Exepcted Values  of all first page results, Hence Search is not as expected");
		}
		writeReport(User_BusinessFunction.Logout(),"Clicking on Logout",
                                                      "Clicking on Logout is Successful",
                                                      "Clicking on Logout is not Successful");
		}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}}
	
	
	/*@AfterClass
	public static void browserStop()
	{
		driver.close();
	}*/
	
	

