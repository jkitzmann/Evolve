package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.HESI_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class HESIStudentUpdate_Script_9861 extends HESI_BusinessFunction{
	@Test
	public void HESIStudentUpdate9861() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		stepReport("Login to Evolve as existing student");
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		String HESI_USER=ReadingExcel.columnDataByHeaderName("HESI_USERNAME", "HESI", configProps.getProperty("TestData"));        
        String HESI_Password=ReadingExcel.columnDataByHeaderName("HESI_PASSWORD", "HESI", configProps.getProperty("TestData"));
        //String EvolveId=ReadingExcel.columnDataByHeaderName("Catalogs", "TC-9859", configProps.getProperty("TestData"));
        String hesiUserExisting=ReadingExcel.columnDataByHeaderName("HEST_STUDENT_USER", "HESI", configProps.getProperty("TestData"));
        String hesiPassword=ReadingExcel.columnDataByHeaderName("HESI_STUDENT_PWD", "HESI", configProps.getProperty("TestData"));
        writeReport(SwitchToBrowser(ElsevierObjects.studentBrowserType),"Launching Browser to Student","Launching Browser to Student is succesful","Lanching Browser to Student is failed");

		String Firstname=ReadingExcel.columnDataByHeaderName("FirstName", "TC-9861", configProps.getProperty("TestData"));
		String Lastname=ReadingExcel.columnDataByHeaderName("LastName", "TC-9861", configProps.getProperty("TestData"));
		String Emailid=ReadingExcel.columnDataByHeaderName("Emailid", "TC-9861", configProps.getProperty("TestData"));
		String hesiEmail = ReadingExcel.columnDataByHeaderName("HESI_STUDENT_EMAIL", "HESI", configProps.getProperty("TestData"));
		/*
		String Instution=ReadingExcel.columnDataByHeaderName("Institution", "TC-9859", configProps.getProperty("TestData"));
		String Mobile=ReadingExcel.columnDataByHeaderName("Phone", "TC-9859", configProps.getProperty("TestData"));
		String Address1=ReadingExcel.columnDataByHeaderName("Address1", "TC-9859", configProps.getProperty("TestData"));
		String Address2=ReadingExcel.columnDataByHeaderName("Address2", "TC-9859", configProps.getProperty("TestData"));
		String Country=ReadingExcel.columnDataByHeaderName("Country", "TC-9859", configProps.getProperty("TestData"));
		String State=ReadingExcel.columnDataByHeaderName("State", "TC-9859", configProps.getProperty("TestData"));
		String City=ReadingExcel.columnDataByHeaderName("City", "TC-9859", configProps.getProperty("TestData"));
		String Program=ReadingExcel.columnDataByHeaderName("Program", "TC-9859", configProps.getProperty("TestData"));
		String ZipCode=ReadingExcel.columnDataByHeaderName("ZipCode", "TC-9859", configProps.getProperty("TestData"));
		// String Catalogs=ReadingExcel.columnDataByHeaderName("Catalogs", "TC-8563AndTC-8565", configProps.getProperty("TestData"));
*/
		String user="student";
		writeReport(EvolveCommonBussinessFunctions.existingUserLogin(user,hesiUserExisting,hesiPassword), "Launch Evolve Cert URL And Login As Existing student: "+hesiUserExisting, 
				"Successfully Launched Evolve Cert URL.</br>Successfully Logged In as student. "+hesiUserExisting,
				"Failed to Launch Evolve Cert URL.</br>Failed to Login As student. "+hesiUserExisting);

		stepReport("Update account details in Evolve");
		writeReport(HESI_BusinessFunction.StudentUpdateAccountDetails(Firstname,Lastname,Emailid),"Values Submitted Successfully","Entered Values are Successfully Submitted","Entered Values are not Submitted");
		Thread.sleep(veryhigh);
		Thread.sleep(veryhigh);
		writeReport(HESI_BusinessFunction.getAccountDetails("studentUpdate"), "Fetching Account Details From MyAccount Page.", 
				"Successfully Fetched Username: "+getAccountDetailsUserName+"</br>Successfully Fetched FirstName: "+getAccountDetailsFirstName+"</br>Successfully Fetched Lastname: "+getAccountDetailsLastName+"</br>Successfully Fetched Email: "+getAccountDetailsEmail,"Failed to Fetch Account Details From MyAccount Page. ");
		
		stepReport("Login to HESI");
		writeReport(HESI_BusinessFunction.HESI_Login(HESI_USER,HESI_Password),"Launching HESI URL and UserName"+HESI_USER,
				"Launching the URL for HESI USER is successful </br > Login to Application Using HESI USER credentails :"+HESI_USER+" is Successful",
				"Launching and Login to Application Using HESI USER credentails : "+ HESI_USER+" is Failed");

		stepReport("Search for existing student's account");
		writeReport(HESI_BusinessFunction.NavigatingtoStudentAccountManagmentPage(),"Navigating to Student Account Managment Page",
				"Clicking on Account Managment is Successful </br> Clicking on Student Account link is Successful",
				"Navigating to Student Account Managment is Failed");
		writeReport(HESI_BusinessFunction.SearchStudnetuser(getAccountDetailsUserName),"Searching Student User"+getAccountDetailsUserName,"Searching Studnet is Successful","Searching Student is not successful");
		Thread.sleep(veryhigh);
		Thread.sleep(veryhigh);
		
		stepReport("Verify the account changes made in Evolve are reflected in HESI");
		writeReport(HESI_BusinessFunction.getStudnetDetailsandCompare(getAccountDetailsUserName,getAccountDetailsFirstName,getAccountDetailsLastName,getAccountDetailsEmail),"Fecthing Account Details from HESI and Comparing with CERT values",
				"All Comparisons are successful",
				"Some of the Validation are failed please refer Above Steps");
		
		// log back in to the student account and revert the changes
		stepReport("Log back in to Evolve and revert the changes to the account");
		writeReport(EvolveCommonBussinessFunctions.existingUserLogin(user,hesiUserExisting,hesiPassword), "Launch Evolve Cert URL And Login As Existing student: "+hesiUserExisting, 
				"Successfully Launched Evolve Cert URL.</br>Successfully Logged In as student. "+hesiUserExisting,
				"Failed to Launch Evolve Cert URL.</br>Failed to Login As student. "+hesiUserExisting);
		
		writeReport(HESI_BusinessFunction.StudentUpdateAccountDetails(Firstname,Lastname,hesiEmail),"Values Submitted Successfully","Entered Values are Successfully Submitted","Entered Values are not Submitted");
		
		
	
	}
	@AfterTest
	public void closeBtrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
