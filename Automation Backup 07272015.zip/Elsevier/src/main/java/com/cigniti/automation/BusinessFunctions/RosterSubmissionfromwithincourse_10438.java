package com.cigniti.automation.BusinessFunctions;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class RosterSubmissionfromwithincourse_10438 extends EvolveCommonBussinessFunctions{
	
   public static String lastname;
   public static String firstname;
   public static String email;
   public static String Studentdetails;
   public static String username;
   public static String Password;
   public static String Lastname;
   public static String Firstname;
   public static String Email;
   public static String Facultydetails;
   public static String user1;
   public static String Password1;
   public static String newLastname;
   public static String newFirstname;
   public static String newEmail;
   public static String gmailusername;
   public static String gmailpassword;
   public static String newStudentdetails;
   public static String getCourseId1;
   public static String LoEmail;
   public static String RosterUser;
   public static String RosterPwd;
   public static String InstructorHeader;
   public static String StudentHeader;
   
   public static boolean AccountCreationdetails() throws Throwable{
   try
     {
      boolean flag = true;
      CreateNewUser(ElsevierObjects.STUDENT);
	  Thread.sleep(medium);
	  getAccountDetailsforRoster();
	  lastname = getAccountDetailsLastName;
	  firstname = getAccountDetailsFirstName;
	  email = getAccountDetailsEmail;
	  Studentdetails = lastname+","+firstname+","+email;
	  System.out.println(Studentdetails);
	  username = getAccountDetailsUserName;
	  Password = credentials[1];
	  EvolveCommonBussinessFunctions.instructorLogout();
	  String user="educator";
	  RosterUser=ReadingExcel.columnDataByHeaderName("RosterUserName", "TC-10438", configProps.getProperty("TestData"));;
	  RosterPwd=ReadingExcel.columnDataByHeaderName("RosterPassword", "TC-10438", configProps.getProperty("TestData"));
	  EvolveCommonBussinessFunctions.existingUserLogin(user,RosterUser,RosterPwd);
	  Thread.sleep(medium);
	  getAccountDetailsforRoster();
	  Lastname = getAccountDetailsLastName;
	  Firstname = getAccountDetailsFirstName;
	  Email = getAccountDetailsEmail;
	  Facultydetails = Lastname+","+Firstname+","+Email;
	  System.out.println(Facultydetails);
	  user1 = getAccountDetailsUserName;
	  Password1 = configProps.getProperty("Roster_Pwd");
	  EvolveCommonBussinessFunctions.instructorLogout();
	  return flag;}
	  catch(Exception e){return false;}	  
}
   
   public static boolean courseIDSearch(String ID1) throws Throwable{
		boolean flag=true;
		try{
		if(ID1.equalsIgnoreCase("true")){
		waitForVisibilityOfElement(By.xpath(".//*[@id='set']/li/div/div/span[text()='COURSE ID: "+getCourseId1+"']"),"Verify course id1 present.");
		}
		click(By.xpath("//*[@id='set']/li/div/div/span[text()='COURSE ID: "+getCourseId1+"']/following-sibling::a"),"Click on Course Title.");
				
		Thread.sleep(60000);
		//driver.manage().timeouts().implicitlyWait(600, TimeUnit.SECONDS);
		
		//driver.navigate().refresh();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return flag;	
	}
  public static boolean RosterCreation() throws Throwable{ 
  try
     {
	  boolean flag = true;
	  //driver.switchTo().defaultContent();
	  b=true;
      click(ElsevierObjects.Rosters_Teams,"Rosters and Teams and User is shown 'Roster & Teams' area of the course.");
      Thread.sleep(low);
      b=false;
      switchToFrameById("embeddedTool");
      b=true;
      click(ElsevierObjects.Submit_Roster,"Submit Roster and User is given a 'Submit Roster' popup.");
      Thread.sleep(low);
      b=false;
      newFirstname = "Zaphod";
      newLastname = "Beeblebrox";
	  Random ra = new Random(System.currentTimeMillis());
      newEmail = "zbeeblebrox"+Integer.toString((1 + ra.nextInt(2)) * 1000 + ra.nextInt(1000))+"@evolveqa.info";
      ReadingExcel.updateCellInSheet(1,2,configProps.getProperty("TestData"), "TC-10438", newEmail);
      newStudentdetails = newLastname+","+newFirstname+","+newEmail;
      WebElement frame=driver.findElement(By.xpath("//*[@id='submitRosterModal']/div[2]/iframe"));
      driver.switchTo().frame(frame);    
      driver.findElement(ElsevierObjects.Roster_field).clear();
	  driver.findElement(ElsevierObjects.Roster_field).sendKeys(Studentdetails);
	  if(Studentdetails!=null){
		  Reporters.SuccessReport("Enter Lastname,Firstname and EmailId","Successfully Created student details are entered :"+Studentdetails);
	  }else{
		  Reporters.failureReport("Enter Lastname,Firstname and EmailId","Failed to enter created student details");
	  }
	  Thread.sleep(medium);
      driver.findElement(ElsevierObjects.Roster_field).sendKeys(Keys.ENTER);
	  Thread.sleep(medium);
	  driver.findElement(ElsevierObjects.Roster_field).sendKeys(Facultydetails);
	  if(Facultydetails!=null){
		  Reporters.SuccessReport("Enter Lastname,Firstname and EmailId","Successfully Faculty details are entered :"+Facultydetails);
	  }else{
		  Reporters.failureReport("Enter Lastname,Firstname and EmailId","Failed to enter created Faculty details");
	  }
	  Thread.sleep(medium);
	  driver.findElement(ElsevierObjects.Roster_field).sendKeys(Keys.ENTER);
	  Thread.sleep(medium);
	  driver.findElement(ElsevierObjects.Roster_field).sendKeys(newStudentdetails);
	  if(newStudentdetails!=null){
		  Reporters.SuccessReport("Enter Lastname,Firstname and EmailId","Successfully newstudent details for Roster are entered :"+newStudentdetails);
	  }else{
		  Reporters.failureReport("Enter Lastname,Firstname and EmailId","Failed to enter newstudent details for Roster");
	  }
	  if(click(ElsevierObjects.PreviewRoster_AsssignRoles, "Click on Priview and Rosters button")){
		 Reporters.SuccessReport("Enter the LastName,FirstName,and EmailId", "Sucessfully Now the popup displays the 3 users listed with a dropdown next to each name to assign roles to the enrollees");
	  }else {
	    Reporters.failureReport("Enter the LastName,FirstName,and EmailId", "Failed to show the popup and 3 users listed with a dropdown next to each name to assign roles to the enrollees");	
	  }
	  Thread.sleep(high);
	  selectByValue(ElsevierObjects.Role_Selection1, "student", "Select the role as a Student");
	  Thread.sleep(low);
	  selectByValue(ElsevierObjects.Role_Selection2, "instructor", "Select the role as an instructor");
	  Thread.sleep(low);
	  selectByValue(ElsevierObjects.Role_Selection3, "student", "Select the role as a Student");
	  Thread.sleep(low);
	  if(!isChecked(ElsevierObjects.Email_radiobutton,"Select the 'Email the roster to me, and also email my students their usernames & passwords' Radio button"))
	  {
			Reporters.SuccessReport("Select Radio button", "Sucessfully selecting 'Email the roster to me, and also email my students their usernames & passwords' Radio button");
	  }
	  else
	  {
			click(ElsevierObjects.Email_radiobutton,"Select the 'Email the roster to me, and also email my students their usernames & passwords' Radio button");
      }
	  Thread.sleep(low);
	  b=true;
      click(ElsevierObjects.Submit_This_Roster,"Submit this Roster");
      b=false;
      String Suc = "Success";
      String s=getText(ElsevierObjects.Roster_success_message, "Verify the Success Message");
	  if(s.contains(getCourseId1)&& s.contains(Suc)){
		 Reporters.SuccessReport("Verify Success Message","User will see a success message: "+s);
	  } else{
		 Reporters.failureReport("Verify Success Message","User will unable to see a success message: "+s);	
	  }
	    return flag;}
	    catch(Exception e){return false;}
    }
   
   //step 9
  public static boolean Emailforwarding() throws Throwable {
		try
		{
			boolean flag = true;
			launchUrl(configProps.getProperty("EmailURL"));
			Thread.sleep(medium);
			type(ElsevierObjects.emailaddress,configProps.getProperty("verifyemail_username"),"Enter email id");
			Thread.sleep(medium);
			type(ElsevierObjects.emailpassword,configProps.getProperty("verifyemail_password"),"Enter password");
			Thread.sleep(medium);
			click(ElsevierObjects.emaillogin, "Click on Login Button.");
			Thread.sleep(high);
			click(ElsevierObjects.email_Icon,"Click on Email icon.");
			Thread.sleep(medium);
			click(ElsevierObjects.email_dropdown,"Click on Dropdown.");
			Thread.sleep(medium);
			click(ElsevierObjects.email_dropdown_Fromchk,"Click on From check box.");
			Thread.sleep(medium);
			click(ElsevierObjects.email_dropdown_Tochk,"Click on To checkbox.");
			Thread.sleep(medium);
			
			
			driver.findElement(ElsevierObjects.email_SearchBox).clear();
			Thread.sleep(medium);
			type(ElsevierObjects.email_SearchBox,newEmail,"Enter the EmailAddress.");
			Thread.sleep(medium);
			click(ElsevierObjects.email_SearchIcon,"Click on search icon.");
			Thread.sleep(veryhigh);
			String EmailTitle2 = getText(ElsevierObjects. titleInEmail,"Verify the Subject of the Email");
			if(EmailTitle2.equalsIgnoreCase(StudentHeader)){
				Reporters.SuccessReport("Verify Subject of Email","Successfully Emailsubject is verified </br> Actual title is :"+StudentHeader+"</br> Expected title is: "+EmailTitle2);
			}else{
				Reporters.failureReport("Verify Subject of Email","Failed to verify Email subject </br> Actual title is :"+StudentHeader+"</br> Expected title is: "+EmailTitle2);
			}
			Thread.sleep(medium);
			switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
			String emailBody2 = getText(ElsevierObjects.email_body_text,"Get email body text");
			
			
			/*
			if(emailBody2!=null){
				Reporters.SuccessReport("Verify Emailbody content","Successfully Emailbody content is verified </br> "+emailBody2);
			}else{
				Reporters.failureReport("Verify Emailbody content","Failed to verify Emailbody content.");
			}
			*/
			String[] credentialsArr = emailBody2.split("\n");
			gmailusername = null;
			gmailpassword = null;
			for(String User : credentialsArr){
				if(User.contains("Username:")){
					gmailusername = User.replaceAll("Username:", "").trim();
				}
				if(User.contains("Password:")){
					gmailpassword = User.replaceAll("Password:", "").trim();
				} 
			}
			ReadingExcel.updateCellInSheet(1,0,configProps.getProperty("TestData"), "TC-10438", gmailusername);
			ReadingExcel.updateCellInSheet(1,1,configProps.getProperty("TestData"), "TC-10438", gmailpassword);
			if(emailBody2.contains(gmailusername)&& emailBody2.contains(gmailpassword)){ 
				Reporters.SuccessReport("Verify email content.","Successfully Roster Student details are verified :</br> Student Username :"+gmailusername+"</br> Student Password :"+gmailpassword);
			}else{
				Reporters.failureReport("Verify email content.","Failed to verify the email content.");
			}
			driver.switchTo().defaultContent();
			
			/*
			b= true;
			click(ElsevierObjects.Email_forward,"Forward button");
			b= false;
			Thread.sleep(medium);
			String parentHandle2 = driver.getWindowHandle();
			for(String winHandle : driver.getWindowHandles()) {
				driver.switchTo().window(winHandle);
				Thread.sleep(medium);
			} 
			Thread.sleep(medium);
			type(ElsevierObjects.Email_Forwarding_To,configProps.getProperty("gmailUsername"),"Enter Gmail username");
			Thread.sleep(medium);
			b= true;
			click(ElsevierObjects.Email_Send,"Send button and Email is forwarded to a checkable gmail account");
			b=false;
			driver.switchTo().window(parentHandle2);
			Thread.sleep(medium);
			*/
			
			driver.findElement(ElsevierObjects.email_SearchBox).clear();
			Thread.sleep(medium);
			type(ElsevierObjects.email_SearchBox,LoEmail,"Enter the EmailAddress.");
			Thread.sleep(medium);
			click(ElsevierObjects.email_SearchIcon,"Click on search icon.");
			Thread.sleep(veryhigh);
			String EmailTitle = getText(ElsevierObjects. titleInEmail,"Verify the Subject of the Email");
			if(EmailTitle.equalsIgnoreCase(InstructorHeader)){
				Reporters.SuccessReport("Verify Subject of Email","Successfully Emailsubject is verified </br> Actual title is :"+InstructorHeader+"</br> Expected title is: " +EmailTitle);
			}else{
				Reporters.failureReport("Verify Subject of Email","Failed to verify Email subject </br> Actual title is :"+InstructorHeader+"</br> Expected title is: " +EmailTitle);
			}
			Thread.sleep(medium);
			switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
			String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
			
			// going to try validating content of email here instead of going to gmail
			String hiddenPwd = "******";
			if(emailBody.contains(getCourseId1)&& emailBody.contains(lastname) && emailBody.contains(firstname) && emailBody.contains(email) && emailBody.contains(username) && emailBody.contains(hiddenPwd)&& emailBody.contains(Lastname)
					&& emailBody.contains(Firstname)&& emailBody.contains(Email)&& emailBody.contains(user1)&& emailBody.contains(newLastname)&& emailBody.contains(newFirstname) && emailBody.contains(newEmail) && emailBody.contains(gmailusername)&& emailBody.contains(gmailpassword)){
					Reporters.SuccessReport("Verify email content.","Successfully details in Email are compared and the details are :</br> CourseId :" +getCourseId1+"</br> Student Firstname :"+firstname+"</br> Student Lastname :"+lastname+"</br> Student EmailId :"+email+"</br> Student Username :"+username+"</br> Student Password :"+hiddenPwd+
							                                                                                                                                    "</br> Faculty Firstname :"+Firstname+"</br> Faculty Lastname :"+Lastname+"</br> Faculty EmailId :"+Email+"</br> Faculty Username :"+user1+"</br> Faculty Password :"+hiddenPwd+
							                                                                                                                                    "</br> RosterStudent Firstname :"+newFirstname+"</br> RosterStudent Lastname :"+newLastname+"</br> RosterStudent EmailId :"+newEmail+"</br> RosterStudent Username :"+gmailusername+"</br> RosterStudent Password :"+gmailpassword);
			}else{
				Reporters.failureReport("Verify email content.","Failed to verify the email content.");
			}
			driver.switchTo().defaultContent();
			Thread.sleep(low);
			/*
			if(emailBody!=null){
				Reporters.SuccessReport("Verify Emailbody content","Successfully Emailbody content is verified </br> "+emailBody);
			}else{
				Reporters.failureReport("Verify Emailbody content","Failed to verify Emailbody content.");
			}
			driver.switchTo().defaultContent();
			b= true;
			click(ElsevierObjects.Email_forward,"Forward button");
			b= false;
			Thread.sleep(medium);
			String parentHandle = driver.getWindowHandle();
			for(String winHandle : driver.getWindowHandles()) {
				driver.switchTo().window(winHandle);
				Thread.sleep(medium);
			} 
			Thread.sleep(low);
			type(ElsevierObjects.Email_Forwarding_To,configProps.getProperty("gmailUsername"),"Enter Gmail username");
			Thread.sleep(low);
			b= true;
			click(ElsevierObjects.Email_Send,"Send button and Email is forwarded to a checkable gmail account");
			b=false;
			driver.switchTo().window(parentHandle);
			Thread.sleep(medium);
			*/
			//2nd email
			driver.findElement(ElsevierObjects.email_SearchBox).clear();
			Thread.sleep(medium);
			type(ElsevierObjects.email_SearchBox,email,"Enter the EmailAddress.");
			Thread.sleep(medium);
			click(ElsevierObjects.email_SearchIcon,"Click on search icon.");
			Thread.sleep(veryhigh);
			String EmailTitle1 = getText(ElsevierObjects. titleInEmail,"Verify the Subject of the Email");
			if(EmailTitle1.equalsIgnoreCase(StudentHeader)){
				Reporters.SuccessReport("Verify Subject of Email","Successfully Emailsubject is verified </br> Actual title is :"+StudentHeader+"</br> Expected title is: " +EmailTitle1);
			}else{
				Reporters.failureReport("Verify Subject of Email","Failed to verify Email subject </br> Actual title is :"+StudentHeader+"</br> Expected title is: " +EmailTitle1);
			}
			Thread.sleep(medium);
			switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
			String emailBody1=getText(ElsevierObjects.email_body_text,"Get email body text");
			
			// attempting to verify email content here instad of in gmail
			if(emailBody1.contains(username)&& emailBody1.contains(Password)){ 
				Reporters.SuccessReport("Verify email content.","Successfully Student details are verified :</br> Student Username :"+username+"</br> Student Password :"+Password);
			}else{
				Reporters.failureReport("Verify email content.","Failed to verify the email content.");
			}
			driver.switchTo().defaultContent();
			Thread.sleep(low);
			
			/*
			if(emailBody1!=null){
				Reporters.SuccessReport("Verify Emailbody content","Successfully Emailbody content is verified </br> "+emailBody1);
			}else{
				Reporters.failureReport("Verify Emailbody content","Failed to verify Emailbody content.");
			}
			driver.switchTo().defaultContent();
			b= true;
			click(ElsevierObjects.Email_forward,"Forward button");
			b= false;
			Thread.sleep(medium);
			String parentHandle1 = driver.getWindowHandle();
			for(String winHandle : driver.getWindowHandles()) {
				driver.switchTo().window(winHandle);
				Thread.sleep(medium);
			} 
			Thread.sleep(low);
			type(ElsevierObjects.Email_Forwarding_To,configProps.getProperty("gmailUsername"),"Enter Gmail username");
			Thread.sleep(low);
			b= true;
			click(ElsevierObjects.Email_Send,"Send button and Email is forwarded to a checkable gmail account");
			b=false;
			driver.switchTo().window(parentHandle1);
			Thread.sleep(medium);
			*/
			//3rd email
			
			b=true;
			click(ElsevierObjects.email_logout,"Logout button");  
			b = false;
			return flag;}
		catch(Exception e){return false;}  
	}



	//gmail verification

	public static boolean GmailverificationforFaculty() throws Throwable{
		try
		{
			boolean flag = true;
			driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");
			driver.manage().deleteAllCookies();
			Thread.sleep(medium);
			launchUrl(configProps.getProperty("GmailURL"));
			Thread.sleep(medium);
			b=true;
			// gmail signin now has user/pass on separate pages with a next button between. reworking this section.
			/*type(ElsevierObjects.Gmail_username,configProps.getProperty("gmailUsername"),"Enter username");
			Thread.sleep(medium);
			type(ElsevierObjects.Gmail_password,configProps.getProperty("gmailPassword"),"Enter password");
			Thread.sleep(medium);
			click(ElsevierObjects.Gmail_login,"Login");
			Thread.sleep(medium);*/
			
			type(ElsevierObjects.Gmail_username,configProps.getProperty("gmailUsername"),"Enter username");
			Thread.sleep(medium);
			click(ElsevierObjects.Gmail_next,"Next");
			Thread.sleep(medium);
			type(ElsevierObjects.Gmail_password,configProps.getProperty("gmailPassword"),"Enter password");
			Thread.sleep(medium);
			click(ElsevierObjects.Gmail_login,"Login");
			Thread.sleep(medium);
			
			b=false;
			click(ElsevierObjects.Gmail_searchbox,"Click on gmail searchbox");
			Thread.sleep(medium);
			type(ElsevierObjects.Gmail_searchbox,LoEmail,"Enter EmailAddress in the searchbox");
			Thread.sleep(medium);
			click(ElsevierObjects.Gmail_search_button,"Click on search button");
			Thread.sleep(high);
			click(ElsevierObjects.Gmail_verify_mail,"Click on forward mail present there");
			Thread.sleep(veryhigh);
            String Pwd = "******";
			String content = getText(ElsevierObjects.Gmail_total_frame,"Get Text of body content");
			if(content.contains(getCourseId1)&& content.contains(lastname) && content.contains(firstname) && content.contains(email) && content.contains(username) && content.contains(Pwd)&& content.contains(Lastname)
				&& content.contains(Firstname)&& content.contains(Email)&& content.contains(user1)&& content.contains(newLastname)&& content.contains(newFirstname)&&content.contains(newEmail) && content.contains(gmailusername)&& content.contains(gmailpassword)){
				Reporters.SuccessReport("Verify text in Gmail","Successfully details in Email are compared and the details are :</br> CourseId :" +getCourseId1+"</br> Student Firstname :"+firstname+"</br> Student Lastname :"+lastname+"</br> Student EmailId :"+email+"</br> Student Username :"+username+"</br> Student Password :"+Pwd+
						                                                                                                                                    "</br> Faculty Firstname :"+Firstname+"</br> Faculty Lastname :"+Lastname+"</br> Faculty EmailId :"+Email+"</br> Faculty Username :"+user1+"</br> Faculty Password :"+Pwd+
						                                                                                                                                    "</br> RosterStudent Firstname :"+newFirstname+"</br> RosterStudent Lastname :"+newLastname+"</br> RosterStudent EmailId :"+newEmail+"</br> RosterStudent Username :"+gmailusername+"</br> RosterStudent Password :"+gmailpassword);
			}else{
				Reporters.failureReport("Verify text in Gmail","Failed to verify the Emailbody");
			}

			//2nd iteration
			Thread.sleep(medium);
			click(ElsevierObjects.Gmail_searchbox,"Click on gmail searchbox");
			Thread.sleep(medium);
			type(ElsevierObjects.Gmail_searchbox,username,"Enter EmailAddress in the searchbox");
			Thread.sleep(medium);
			click(ElsevierObjects.Gmail_search_button,"Click on search button");
			Thread.sleep(veryhigh);
			WebElement element = driver.findElement(By.xpath(".//*[@class='y6']//span[2]/b[text()='"+username+"']"));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", element);
			Thread.sleep(veryhigh);
			String content1 = getText(ElsevierObjects.Gmail_total_frame,"Get Text of body content");
			if(content1.contains(username)&& content1.contains(Password)){ 
				Reporters.SuccessReport("Verify text in Gmail","Successfully Student details are verified :</br> Student Username :"+username+"</br> Student Password :"+Password);
			}else{
				Reporters.failureReport("Verify text in Gmail","Failed to verify the Emailbody");
			}

			//3rd iteration
			Thread.sleep(medium);
			click(ElsevierObjects.Gmail_searchbox,"Click on gmail searchbox");
			Thread.sleep(medium);
			type(ElsevierObjects.Gmail_searchbox,newEmail,"Enter EmailAddress in the searchbox");
			Thread.sleep(medium);
			click(ElsevierObjects.Gmail_search_button,"Click on search button");
			Thread.sleep(veryhigh);
			WebElement element1 = driver.findElement(By.xpath(".//*[@class='y6']/span[1]"));
			JavascriptExecutor executor1 = (JavascriptExecutor)driver;
			executor1.executeScript("arguments[0].click();", element1);
			Thread.sleep(veryhigh);
			String content2 = getText(ElsevierObjects.Gmail_total_frame,"Get Text of body content");
			if(content2.contains(gmailusername)&& content2.contains(gmailpassword)){ 
				Reporters.SuccessReport("Verify text in Gmail","Successfully Roster Student details are verified :</br> Student Username :"+gmailusername+"</br> Student Password :"+gmailpassword);
			}else{
				Reporters.failureReport("Verify text in Gmail","Failed to verify the Emailbody");
			}

			click(ElsevierObjects.Gmail_Signout_button,"Click on dropdown");
			Thread.sleep(medium);
			click(ElsevierObjects.Gmail_Logout,"Click on signout button");
			return flag;}
		catch(Exception e){return false;}  
	}
  //step 19
  public static boolean InstructorRelogin() throws Throwable{
  try
	 {
	  boolean flag = true;
	  String educatorUsername=ReadingExcel.columnDataByHeaderName("facultyUserName", "TC-15461", configProps.getProperty("TestData"));
	  String educatorPassword=ReadingExcel.columnDataByHeaderName("facultyPassword", "TC-15461", configProps.getProperty("TestData"));
		
	  launchUrl(configProps.getProperty("URL3"));
	  Thread.sleep(low);
	  if(click(ElsevierObjects.Student_Home_Login,"Click on login button")){
		    Reporters.SuccessReport("Click on login", "Launched Evolvecert URL Successfully and clicked on login");
	  }else{
		  Reporters.failureReport("Click on login", "Failed to Launch Evolvecert URL and click on login");
	  }
	  Thread.sleep(low);
	  b=true;
	  type(ElsevierObjects.common_login_userName,educatorUsername,"Enter username in the textbox");
	  Thread.sleep(low);
	  type(ElsevierObjects.common_login_passWord,educatorPassword,"Enter Password in the textbox");
	  Thread.sleep(low);
	  b=false;
	  if(click(ElsevierObjects.submit,"Click on login button")){
	      Reporters.SuccessReport("Click on login", "User is Successfully login with the faculty details");
	  }else{
		  Reporters.failureReport("Click on login", "User is failed to login with the faculty details");
	  }
	  Thread.sleep(low);
	  b=true;
	  click(ElsevierObjects.Myevolve,"MyEvolve");
	  b=false;
	  String ID1="true";
	  RosterSubmissionfromwithincourse_10438.courseIDSearch(ID1);
	  
	  // adding a logout/log back in step
	  EvolveCommonBussinessFunctions.instructorLogout();
	  Thread.sleep(low);
	  if(click(ElsevierObjects.Student_Home_Login,"Click on login button")){
		    Reporters.SuccessReport("Click on login", "Launched Evolvecert URL Successfully and clicked on login");
	  }else{
		  Reporters.failureReport("Click on login", "Failed to Launch Evolvecert URL and click on login");
	  }
	  Thread.sleep(low);
	  b=true;
	  type(ElsevierObjects.common_login_userName,educatorUsername,"Enter username in the textbox");
	  Thread.sleep(low);
	  type(ElsevierObjects.common_login_passWord,educatorPassword,"Enter Password in the textbox");
	  Thread.sleep(low);
	  b=false;
	  if(click(ElsevierObjects.submit,"Click on login button")){
	      Reporters.SuccessReport("Click on login", "User is Successfully login with the faculty details");
	  }else{
		  Reporters.failureReport("Click on login", "User is failed to login with the faculty details");
	  }
	  Thread.sleep(low);
	  b=true;
	  click(ElsevierObjects.Myevolve,"MyEvolve");
	  b=false;
	  RosterSubmissionfromwithincourse_10438.courseIDSearch(ID1);
	  
	  b=true;
	  click(ElsevierObjects.Rosters_teams,"Rosters and Teams");
      Thread.sleep(low);
      b=false;
      switchToFrameById("embeddedTool");
      String user = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+username+"')]"),"Get the Student Username");
      if(user!=null){
   	     Reporters.SuccessReport("Verify Student Username from the table","Successfully Student Username is verified </br>" +user);
      }else{
   	     Reporters.failureReport("Verify Student Username from the table","Failed to verify Student Username");
      }
      Thread.sleep(medium);
      String role = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+username+"')]/following-sibling::td[contains(text(),'Student')]"),"Get the Role of user");
      if(role!=null){
   	   Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +role);
      }else{
   	   Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
      }
      String fuser = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+user1+"')]"),"Get Faculty Usename from table");
      Thread.sleep(medium);
      if(fuser!=null){
   	   Reporters.SuccessReport("Verify Faculty Username from the table","Successfully Faculty Username is verified </br>" +fuser);
      }else{
   	   Reporters.failureReport("Verify Faculty Username from the table","Failed to verify Faculty Username");
      }
      String Role = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+user1+"')]/following-sibling::td[contains(text(),'Instructor')]"),"Get the Role of User");
      Thread.sleep(medium);
      if(Role!=null){
      	  Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +Role);
      }else{
      	  Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
      }
      String newuser = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+gmailusername+"')]"),"Get the new Student Username");
      if(newuser!=null){
   	     Reporters.SuccessReport("Verify new Student Username from the table","Successfully new Student Username is verified </br>" +newuser);
      }else{
   	     Reporters.failureReport("Verify new Student Username from the table","Failed to verify new Student Username");
      }
      String role1 = getText(By.xpath(".//*[@id='rosterTable']/tbody//tr//td[contains(text(),'"+gmailusername+"')]/following-sibling::td[contains(text(),'Student')]"),"Get the Role of user");
      Thread.sleep(medium);
      if(role1!=null){
   	   Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +role1);
      }else{
   	   Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
      } 
      switchToDefaultFrame();
      EvolveCommonBussinessFunctions.instructorLogout();
	  return flag;}
      catch(Exception e){return false;}
}
  
   public static boolean RostersearchingAdmin() throws Throwable{
   try
     {
	   boolean flag = true;
	   b= true;
	   click(ElsevierObjects.Admin_Search_Rosters,"Search Rosters");
	   Thread.sleep(medium);
	   type(ElsevierObjects.Roster_Course_ID,getCourseId1,"Enter the CourseId in the textbox");
	   Thread.sleep(medium);
	   click(ElsevierObjects.Roster_Search,"Search button");
	   Thread.sleep(medium);
       click(ElsevierObjects.Course_ID_Link,"Courseid link of the Roster now created");
       Thread.sleep(medium);
       b= false;
       String fUser =getText(By.xpath(".//*[@id='pageBody']//tr//td[contains(text(),'"+user1+"')]"),"Get Faculty Usename from table");
       if(fUser!=null){
    	   Reporters.SuccessReport("Verify Faculty Username from the table","Successfully Faculty Username is verified </br>" +fUser);
       }else{
    	   Reporters.failureReport("Verify Faculty Username from the table","Failed to verify Faculty Username");
       }
       Thread.sleep(medium);
       String fRole =getText(By.xpath(".//*[@id='pageBody']//tr//td[contains(text(),'"+user1+"')]/following-sibling::td[contains(text(),'Instructor')]"),"Get the Role of user");
       if(fRole!=null){
    	   Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +fRole);
       }else{
    	   Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
       }
       
       String sUser =getText(By.xpath(".//*[@id='pageBody']//tr//td[contains(text(),'"+username+"')]"),"Get student Usename from table");
       Thread.sleep(medium);
       if(sUser!=null){
    	   Reporters.SuccessReport("Verify Student Username from the table","Successfully Student Username is verified </br>" +sUser);
       }else{
    	   Reporters.failureReport("Verify Student Username from the table","Failed to verify Student Username");
       }
       String sRole =getText(By.xpath(".//*[@id='pageBody']//tr//td[contains(text(),'"+username+"')]/following-sibling::td[contains(text(),'Student')]"),"Get the Role of user");
       Thread.sleep(medium);
       if(sRole!=null){
    	   Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +sRole);
       }else{
    	   Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
       }
       String nUser =getText(By.xpath(".//*[@id='pageBody']//tr//td[contains(text(),'"+gmailusername+"')]"),"Get student Username from table");
       Thread.sleep(medium);
       if(nUser!=null){
    	   Reporters.SuccessReport("Verify new Student Username from the table","Successfully new Student Username is verified </br>" +nUser);
       }else{
    	   Reporters.failureReport("Verify new Student Username from the table","Failed to verify new Student Username");
       }
       String nRole =getText(By.xpath(".//*[@id='pageBody']//tr//td[contains(text(),'"+gmailusername+"')]/following-sibling::td[contains(text(),'Student')]"),"Get the Role of user");
       Thread.sleep(medium);
       if(nRole!=null){
    	   Reporters.SuccessReport("Verify Username Role from the table","Successfully Username Role is verified </br>" +nRole);
       }else{
    	   Reporters.failureReport("Verify Username Role from the table","Failed to verify Username Role");
       }
      return flag;}
	  catch(Exception e){return false;}
    }
   
   public static boolean StudentRelogin() throws Throwable{
   try
     {
	  boolean flag = true;
	  launchUrl(configProps.getProperty("URL4")); 
	  Thread.sleep(low);
	  if(click(ElsevierObjects.Student_Home_Login,"Click on login button")){
		    Reporters.SuccessReport("Click on login", "Launched Evolvecert URL Successfully and clicked on login");
	  }else{
		  Reporters.failureReport("Click on login", "Failed to Launch Evolvecert URL and click on login");
	  }
	  Thread.sleep(low);
	  b=true;
	  type(ElsevierObjects.common_login_userName,username,"Enter username");
	  Thread.sleep(low);
	  type(ElsevierObjects.common_login_passWord,Password,"Enter Password");
	  Thread.sleep(low);
	  b=false;
	  if(click(ElsevierObjects.submit,"Click on login button")){
	       Reporters.SuccessReport("Click on login", "Successfully login with the created student details");
	  }else{
		   Reporters.failureReport("Click on login", "Failed to login with the created student details");
	  }
	  Thread.sleep(low);
	  b=true;
	  click(ElsevierObjects.Myevolve,"My Evolve");
	  Thread.sleep(low);
	  b=false;
	  String Id = getText(ElsevierObjects.Roster_Evolve_CourseId,"Get Unique CourseId");
	  if(Id.contains(getCourseId1)){
			Reporters.SuccessReport("Verify Unique CourseId","Successfully verified CourseId </br> Actual CourseId is :"+getCourseId1+"</br> Expected CourseId is: "+Id);
	  }else{
			Reporters.failureReport("Verify Unique CourseId","Failed to verify CourseId");
	  }
	  Thread.sleep(low);
	  String Courselink = getText(ElsevierObjects.Roster_Evolve_Courselink,"Get Unique CourseId link");
	  if(Courselink!=null){
			Reporters.SuccessReport("Verify Unique CourseId link","User is Successfully verified CourseId link </br>" +Courselink);
	  }else{
			Reporters.failureReport("Verify Unique CourseId link","User is failed to verify CourseId link");
	  }
	  Thread.sleep(low);
	  b=true;
	  click(ElsevierObjects.Roster_Evolve_Courselink,"Unique CourseId link");
	  Thread.sleep(veryhigh);
	  click(ElsevierObjects.educator_CoursePage_Courselink,"Course");
	  Thread.sleep(low);
	  b=false;
	  String Protect = getText(ElsevierObjects.Protected_content,"Get title of Protected Content");
      if(Protect!=null){
	    	Reporters.SuccessReport("Verify title of Protected Content","User is Successfully verified title of Protected Content</br>" +Protect);
	  }else{
	    	Reporters.failureReport("Verify title of Protected Content","User is failed to verify title of Protected Content");
	  }
	  Thread.sleep(low);
	  if(isElementPresent(ElsevierObjects.redeem_AcessCode_txt,"RedeemAccess Blank textbox")){
			Reporters.SuccessReport("Verify RedeemAccess Blank textbox","User is Successfully verified RedeemAccess Blank textbox");
	  }else{
			Reporters.failureReport("Verify RedeemAccess Blank textbox","User is failed to verify RedeemAccess Blank textbox");
	  }
	  Thread.sleep(low);
	  click(ElsevierObjects.protectedContent_PopUp_cancel_Btn,"Cancle button");
	  EvolveCommonBussinessFunctions.instructorLogout();
	  return flag;}
	  catch(Exception e){return false;}
 }

   public static boolean RosterStudentRelogin() throws Throwable{
   try
	 {
	  boolean flag = true;
	  launchUrl(configProps.getProperty("URL4"));
	  Thread.sleep(low);
	  if(click(ElsevierObjects.Student_Home_Login,"Click on login button")){
		    Reporters.SuccessReport("Click on login", "Launched Evolvecert URL Successfully and clicked on login");
	  }else{
		  Reporters.failureReport("Click on login", "Failed to Launch Evolvecert URL and click on login");
	  }
	  Thread.sleep(low);
	  b=true;
	  type(ElsevierObjects.common_login_userName,gmailusername,"Enter username");
	  Thread.sleep(low);
	  type(ElsevierObjects.common_login_passWord,gmailpassword,"Enter Password");
	  Thread.sleep(low);
	  b=false;
	  if(click(ElsevierObjects.submit,"Click on login button")){
		       Reporters.SuccessReport("Click on login", "Successfully login with the created student details");
      }else{
			   Reporters.failureReport("Click on login", "Failed to login with the created student details");
	  }
	  Thread.sleep(low);
	  b=true;
	  click(ElsevierObjects.Myevolve,"My Evolve");
	  Thread.sleep(low);
	  b=false;
	  String Id = getText(ElsevierObjects.Roster_Evolve_CourseId,"Get Unique CourseId");
	  if(Id.contains(getCourseId1)){
			Reporters.SuccessReport("Verify Unique CourseId","Successfully verified CourseId </br> Actual CourseId is :"+getCourseId1+"</br> Expected CourseId is: "+Id);
	  }else{
			Reporters.failureReport("Verify Unique CourseId","Failed to verify CourseId");
	  }
	  Thread.sleep(low);
	  String Courselink = getText(ElsevierObjects.Roster_Evolve_Courselink,"Get Unique CourseId link");
	  if(Courselink!=null){
			Reporters.SuccessReport("Verify Unique CourseId link","User is Successfully verified CourseId link </br>" +Courselink);
	  }else{
			Reporters.failureReport("Verify Unique CourseId link","User is failed to verify CourseId link");
	  }
	  Thread.sleep(low);
	  b=true;
	  click(ElsevierObjects.Roster_Evolve_Courselink,"Unique CourseId link");
	  Thread.sleep(low);
	  click(ElsevierObjects.educator_CoursePage_Courselink,"Course");
	  Thread.sleep(veryhigh);
	  b=false;
	  String Protect = getText(ElsevierObjects.Protected_content,"Get title of Protected Content");
	  if(Protect!=null){
	    	Reporters.SuccessReport("Verify title of Protected Content","User is Successfully verified title of Protected Content</br>" +Protect);
	  }else{
	    	Reporters.failureReport("Verify title of Protected Content","User is failed to verify title of Protected Content");
	  }
	  Thread.sleep(low);
	  if(isElementPresent(ElsevierObjects.redeem_AcessCode_txt,"RedeemAccess Blank textbox")){
			Reporters.SuccessReport("Verify RedeemAccess Blank textbox","User is Successfully verified RedeemAccess Blank textbox");
	  }else{
			Reporters.failureReport("Verify RedeemAccess Blank textbox","User is failed to verify RedeemAccess Blank textbox");
	  }
	  Thread.sleep(low);
	  click(ElsevierObjects.protectedContent_PopUp_cancel_Btn,"Cancle button");
	  EvolveCommonBussinessFunctions.instructorLogout();
	   return flag;}
	   catch(Exception e){return false;}
     } 
}
