package com.cigniti.automation.BusinessFunctions;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.openqa.selenium.By;

public class LTI_BusinessFunctions extends EvolveCommonBussinessFunctions {
	
	public static boolean d2l_Login(String username, String password) throws Throwable {
		
		boolean flag = true;
		try {
			
			// launch the d2l login url and login
			driver.manage().deleteAllCookies();
			if (!launchUrl(configProps.getProperty("D2L_URL")))
				flag = false;
			
			if (!waitForElementPresent(ElsevierObjects.D2L_Username, "Username field"))
				flag = false;
			
			if (!type(ElsevierObjects.D2L_Username, username, "Enter Username"))
				flag = false;
			else
				Reporters.SuccessReport("Enter username",  "Successfully entered username: " + username);
			
			if (!type(ElsevierObjects.D2L_Password, password, "Enter Password"))
				flag = false;
			else
				Reporters.SuccessReport("Enter password",  "Successfully entered password: " + password);
			
			if (!click(ElsevierObjects.D2L_LoginButton, "Login button")){
				flag = false;
				Reporters.failureReport("Click Login button","Failed to click Login button.");
			}
			else
				Reporters.SuccessReport("Click Login button","Successfully clicked Login button.");
			
			Thread.sleep(medium);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
		
	}
	
	public static boolean adminCreateNewCourse() throws Throwable {
		
		boolean flag = true;
		try {
			
			String template = ReadingExcel.columnDataByHeaderName("CourseTemplateName", "LTITestCases", configProps.getProperty("TestData"));
			
			// navigate to create new course screen
			if (!click(ElsevierObjects.D2L_AdminTools, "Admin Tools link")){
				flag = false;
				Reporters.failureReport("Click Admin Tools link","Failed to click Admin Tools.");
			}
			else
				Reporters.SuccessReport("Click Admin Tools link","Successfully clicked Admin Tools.");
			Thread.sleep(low);
			
			if  (!click(ElsevierObjects.D2L_CourseManagement, "Course Management link")){
				flag = false;
				Reporters.failureReport("Click Course Management link","Failed to click Course Management.");
			}
			else
				Reporters.SuccessReport("Click Course Management link","Successfully clicked Course Management.");
			Thread.sleep(low);
			
			switchToFrameByLocator(ElsevierObjects.D2L_ContentIFrame, "Content frame");
			if (!click(ElsevierObjects.D2L_CreateNewCourseOffering, "Create new course button")){
				flag = false;
				Reporters.failureReport("Click Create New Course button","Failed to click Create New Course.");
			}
			else
				Reporters.SuccessReport("Click Create New Course button","Successfully clicked Create New Course.");
			
			// select the existing template option and the correct template
			if (!click(ElsevierObjects.D2L_ExistingTemplateOption, "Create course using existing template option")){
				flag = false;
				Reporters.failureReport("Click use existing template option","Failed to click use existing template option.");
			}
			else
				Reporters.SuccessReport("Click use existing template option","Successfully clicked use existing template option.");
			
			if (!selectByVisibleText(ElsevierObjects.D2L_TemplateDropdown, template, "Existing template selection")){
				flag = false;
				Reporters.failureReport("Select the template","Failed to select the template: " + template);
			}
			else
				Reporters.SuccessReport("Select the template","Successfully selected the template: " + template);
			
			if (!click(ElsevierObjects.D2L_NextButton, "Next button")){
				flag = false;
				Reporters.failureReport("Click Next button","Failed to click Next button.");
			}
			else
				Reporters.SuccessReport("Click Next button","Successfully clicked Next button.");
			
			// enter course info and save new course name to spreadsheet
			Random ra = new Random( System.currentTimeMillis() );
			Date today = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat ("MMddyyyy");
			String courseName = "LTIauto_" + Integer.toString((1 + ra.nextInt(2)) * 10000 + ra.nextInt(10000)) + "_" + sdf.format(today);
			
			if (!type(ElsevierObjects.D2L_EnterCourseName, courseName, "Course Offering Name"))
				flag = false;
			else
				Reporters.SuccessReport("Enter Course Offering Name",  "Successfully entered Course Offering Name: " + courseName);
			
			if (!type(ElsevierObjects.D2L_EnterCourseCode, courseName, "Course Offering Code"))
				flag = false;
			else
				Reporters.SuccessReport("Enter Course Offering Code",  "Successfully entered Course Offering Code: " + courseName);
			
			if (!selectByVisibleText(ElsevierObjects.D2L_SemesterDropdown, "Ongoing", "Semester dropdown"))
				flag = false;
			
			if (!click(ElsevierObjects.D2L_NextButton, "Next button")){
				flag = false;
				Reporters.failureReport("Click Next button","Failed to click Next button.");
			}
			else
				Reporters.SuccessReport("Click Next button","Successfully clicked Next button.");
			Thread.sleep(low);
			
			if (!click(ElsevierObjects.D2L_CreateButton, "Create button")){
				flag = false;
				Reporters.failureReport("Click Create button","Failed to click Create button.");
			}
			else
				Reporters.SuccessReport("Click Create button","Successfully clicked Create button.");
			
			if (flag)
				ReadingExcel.updateCellInSheet(1, 3, configProps.getProperty("TestData"), "LTITestCases", courseName);
			
			if (!click(ElsevierObjects.D2L_DoneButton, "Done button")){
				flag = false;
				Reporters.failureReport("Click Done button","Failed to click Done button.");
			}
			else
				Reporters.SuccessReport("Click Done button","Successfully clicked Done button.");
			Thread.sleep(low);
			
			switchToDefaultFrame();
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean createNewIntegrationConnector() throws Throwable {
		
		boolean flag = true;
		try {
			
			String name = ReadingExcel.columnDataByHeaderName("CourseName", "LTITestCases", configProps.getProperty("TestData"));
			
			// navigate to administration portal
			if (!click(ElsevierObjects.myAccount, "My Account")){
				flag = false;
				Reporters.failureReport("Click My Account","Failed to click My Account.");
			}
			else
				Reporters.SuccessReport("Click My Account","Successfully clicked My Account.");
			
			if (!click(ElsevierObjects.Ecert_Admin_PortalLink, "Portal Administration")){
				flag = false;
				Reporters.failureReport("Click Portal Administration","Failed to click Portal Administration.");
			}
			else
				Reporters.SuccessReport("Click Portal Administration","Successfully clicked Portal Administration.");
			Thread.sleep(low);
			
			// go to auth/integration connectors area, select add new evolve sso client option
			if (!click(ElsevierObjects.AuthAndIntConnectors, "Authentication and Integration Connectors")){
				flag = false;
				Reporters.failureReport("Click Authentication and Integration Connectors","Failed to click Authentication and Integration Connectors.");
			}
			else
				Reporters.SuccessReport("Click Authentication and Integration Connectors","Successfully clicked Authentication and Integration Connectors.");
			Thread.sleep(low);
			
			if (!click(ElsevierObjects.AddConnector, "Add Connector")){
				flag = false;
				Reporters.failureReport("Click Add Connector","Failed to click Add Connector.");
			}
			else
				Reporters.SuccessReport("Click Add Connector","Successfully clicked Add Connector.");
			
			if (!click(ElsevierObjects.EvolveSSOClient, "Evolve SSO Client")){
				flag = false;
				Reporters.failureReport("Click Evolve SSO Client","Failed to click Evolve SSO Client.");
			}
			else
				Reporters.SuccessReport("Click Evolve SSO Client","Successfully clicked Evolve SSO Client.");
			Thread.sleep(low);
			
			// enter new connector info and submit
			if (!type(ElsevierObjects.EnterConnectorID, name + "@evolveqa.info", "Enter new Connector ID"))
				flag = false;
			else
				Reporters.SuccessReport("Enter Connector ID",  "Successfully entered Connector ID: " + name + "@evolveqa.info");
			
			if (!type(ElsevierObjects.EnterConnectorName, name, "Enter new Connector name"))
				flag = false;
			else
				Reporters.SuccessReport("Enter Connector Name",  "Successfully entered Connector Name: " + name);
			
			if (!type(ElsevierObjects.CustomParameter, "user_id", "Enter custom parameter"))
				flag = false;
			else
				Reporters.SuccessReport("Enter custom parameter",  "Successfully entered custom parameter: user_id");
			
			if (!click(ElsevierObjects.CreateSecretKey, "Create secret key")){
				flag = false;
				Reporters.failureReport("Click Create secret key link","Failed to click Create secret key.");
			}
			else
				Reporters.SuccessReport("Click Create secret key link","Successfully clicked Create secret key.");
			Thread.sleep(medium);
			
			String key = getAttribute(ElsevierObjects.SecretKey, "value", "Secret Key");
			
			if (!click(ElsevierObjects.AddConnectorSubmit, "Submit button")){
				flag = false;
				Reporters.failureReport("Click Submit button","Failed to click Submit button.");
			}
			else
				Reporters.SuccessReport("Click Submit button","Successfully clicked Submit button.");
			
			if (flag)
				ReadingExcel.updateCellInSheet(1, 4, configProps.getProperty("TestData"), "LTITestCases", key);
			
			Thread.sleep(medium);
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean addIntegrationToCourse() throws Throwable {
		
		boolean flag = true;
		try {
			
			String courseID = ReadingExcel.columnDataByHeaderName("ExistingCourseID", "LTITestCases", configProps.getProperty("TestData"));
			String name = ReadingExcel.columnDataByHeaderName("CourseName", "LTITestCases", configProps.getProperty("TestData"));
			
			// navigate to administration portal, go to Courses
			if (!click(ElsevierObjects.myAccount, "My Account")){
				flag = false;
				Reporters.failureReport("Click My Account","Failed to click My Account.");
			}
			else
				Reporters.SuccessReport("Click My Account","Successfully clicked My Account.");
			
			if (!click(ElsevierObjects.Ecert_Admin_PortalLink, "Portal Administration")){
				flag = false;
				Reporters.failureReport("Click Portal Administration","Failed to click Portal Administration.");
			}
			else
				Reporters.SuccessReport("Click Portal Administration","Successfully clicked Portal Administration.");
			Thread.sleep(low);
			
			if (!click(ElsevierObjects.Admin_portal_Courses, "Courses link")){
				flag = false;
				Reporters.failureReport("Click Courses link","Failed to click Courses link.");
			}
			else
				Reporters.SuccessReport("Click Courses link","Successfully clicked Courses link.");
			Thread.sleep(medium);
			
			// search for the existing course and click edit
			if (!type(ElsevierObjects.Manage_Courses_Filter, courseID, "Enter the existing course ID"))
					flag = false;
			else
				Reporters.SuccessReport("Enter existing course ID",  "Successfully entered existing course ID: " + courseID);
			Thread.sleep(medium);
			
			if(isElementPresent(ElsevierObjects.Group_Id_details,"Check the GroupId column")){
				Reporters.SuccessReport("Verify the GroupId column","There is one search result that displays the course ID entered in the Group ID column.");
			}else{
				Reporters.failureReport("Verify the GroupId column","There is more than one search results that displays the course ID entered in the Group ID column.");
			}
			
			click(ElsevierObjects.Group_Id_details, "Course in search results");
			Thread.sleep(low);
			
			if (!click(ElsevierObjects.EditCourse, "Edit Course button")){
				flag = false;
				Reporters.failureReport("Click Edit Course button","Failed to click Edit Course button.");
			}
			else
				Reporters.SuccessReport("Click Edit Course button","Successfully clicked Edit Course button.");
			Thread.sleep(medium);
			
			// add the new integration to the course
			if (!selectByVisibleText(ElsevierObjects.AddIntegrationSystem, name, "Add Integration dropdown")){
				flag = false;
				Reporters.failureReport("Select the new integration","Failed to select the integration: " + name);
			}
			else
				Reporters.SuccessReport("Select the new integration","Successfully selected the integration: " + name);
			
			if (!type(ElsevierObjects.AddIntegrationID, courseID, "Course ID textbox"))
				flag = false;
			else
				Reporters.SuccessReport("Enter unique ID",  "Successfully entered unique ID: " + courseID);
			
			if (!click(ElsevierObjects.EditCourseSubmit, "Submit button")){
				flag = false;
				Reporters.failureReport("Click Submit button","Failed to click Submit button.");
			}
			else
				Reporters.SuccessReport("Click Submit button","Successfully clicked Submit button.");
			
			Thread.sleep(medium);
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean addLinkToD2LCourse(String prefix, String courseName, String secretKey, String connectorID, String assessmentLink) throws Throwable {
		
		boolean flag = true;
		try {
			
			// search for the course
			if (!type(ElsevierObjects.D2L_CourseSearch, courseName, "Course search field"))
				flag = false;
			else
				Reporters.SuccessReport("Enter course name in search field",  "Successfully entered course name: " + courseName);
			Thread.sleep(low);
			
			if (!click(ElsevierObjects.D2L_CourseSearchButton, "Search button")){
				flag = false;
				Reporters.failureReport("Click Search button","Failed to click Search button.");
			}
			else
				Reporters.SuccessReport("Click Search button","Successfully clicked Search button.");
			Thread.sleep(high);
			
			// edit course and go to external learning tools
			if (!click(ElsevierObjects.D2L_EditCourse, "Edit Course")){
				flag = false;
				Reporters.failureReport("Click Edit Course","Failed to click Edit Course.");
			}
			else
				Reporters.SuccessReport("Click Edit Course","Successfully clicked Edit Course.");
			
			if (!click(ElsevierObjects.D2L_ExternalLearningTools, "External Learning Tools")){
				flag = false;
				Reporters.failureReport("Click External Learning Tools","Failed to click External Learning Tools.");
			}
			else
				Reporters.SuccessReport("Click External Learning Tools","Successfully clicked External Learning Tools.");
			Thread.sleep(low);
			
			// add the link to the course
			if (!click(ElsevierObjects.D2L_NewLinkButton, "New Link button")){
				flag = false;
				Reporters.failureReport("Click New Link button","Failed to click New Link button.");
			}
			else
				Reporters.SuccessReport("Click New Link button","Successfully clicked New Link button.");
			Thread.sleep(high);
			
			// enter required info for link and save
			if (!type(ElsevierObjects.D2L_EnterLinkTitle, prefix + courseName, "Link Title"))
				flag = false;
			else
				Reporters.SuccessReport("Enter Link Title",  "Successfully entered Link Title: " + prefix + courseName);
			
			if (!type(ElsevierObjects.D2L_EnterLinkURL, assessmentLink, "Link URL"))
				flag = false;
			else
				Reporters.SuccessReport("Enter Link URL",  "Successfully entered Link URL: " + assessmentLink);
			
			if (!click(ElsevierObjects.D2L_SecretKeyOption, "Link key/secret option")){
				flag = false;
				Reporters.failureReport("Click Link key/secret option","Failed to click Link key/secret option.");
			}
			else
				Reporters.SuccessReport("Click Link key/secret option","Successfully clicked Link key/secret option.");
			Thread.sleep(low);
			
			if (!type(ElsevierObjects.D2L_KeyTextbox, connectorID, "Key textbox"))
				flag = false;
			else
				Reporters.SuccessReport("Enter Key",  "Successfully entered Key: " + connectorID);
			
			if (!type(ElsevierObjects.D2L_SecretTextbox, secretKey, "Secret textbox"))
				flag = false;
			else
				Reporters.SuccessReport("Enter Secret",  "Successfully entered Secret: " + secretKey);
			
			if (!click(ElsevierObjects.D2L_SendContext_checkbox, "Uncheck send context checkbox")){
				flag = false;
				Reporters.failureReport("Uncheck send context checkbox","Failed to uncheck send context checkbox.");
			}
			else
				Reporters.SuccessReport("Uncheck send context checkbox","Successfully unchecked send context checkbox.");
			
			if (!click(ElsevierObjects.D2L_SendUserID_checkbox, "Check send user ID checkbox")){
				flag = false;
				Reporters.failureReport("Check send user ID checkbox","Failed to check send user ID checkbox.");
			}
			else
				Reporters.SuccessReport("Check send user ID checkbox","Successfully checked send user ID checkbox.");
			
			if (!click(ElsevierObjects.D2L_SendUsername_checkbox, "Check send user name checkbox")){
				flag = false;
				Reporters.failureReport("Check send user name checkbox","Failed to check send user name checkbox.");
			}
			else
				Reporters.SuccessReport("Check send user name checkbox","Successfully checked send user name checkbox.");
			
			if (!click(ElsevierObjects.D2L_SendEmail_checkbox, "Check send user email checkbox")){
				flag = false;
				Reporters.failureReport("Check send user email checkbox","Failed to check send user email checkbox.");
			}
			else
				Reporters.SuccessReport("Check send user email checkbox","Successfully checked send user email checkbox.");
			
			if (!click(ElsevierObjects.D2L_SendLinkTitle_checkbox, "Uncheck send link title checkbox")){
				flag = false;
				Reporters.failureReport("Uncheck send link title checkbox","Failed to uncheck send link title checkbox.");
			}
			else
				Reporters.SuccessReport("Uncheck send link title checkbox","Successfully unchecked send link title checkbox.");
			
			Thread.sleep(low);
			if (!click(ElsevierObjects.D2L_AddLinkSaveButton, "Save button")){
				flag = false;
				Reporters.failureReport("Click Save button","Failed to click Save button.");
			}
			else
				Reporters.SuccessReport("Click Save button","Successfully clicked Save button.");
			Thread.sleep(high);
			
			driver.navigate().refresh();
			click(ElsevierObjects.D2L_EditNewLink, "Edit new link");
			Thread.sleep(medium);
			
			// scroll to bottom of the page
			driver.executeScript("window.scrollTo(0, document.body.scrollHeight);");
			
			driver.findElement(ElsevierObjects.D2L_AddParameterNumber).clear();
			Thread.sleep(low);
			if (!type(ElsevierObjects.D2L_AddParameterNumber, "2", "Custom parameter count"))
				flag = false;
			else
				Reporters.SuccessReport("Enter custom parameter count",  "Successfully entered custom parameter count: 2");
			Thread.sleep(low);
			if (!click(ElsevierObjects.D2L_AddParameterLink, "Add custom parameters")){
				flag = false;
				Reporters.failureReport("Click Add custom parameters","Failed to click Add custom parameters.");
			}
			else
				Reporters.SuccessReport("Click Add custom parameters","Successfully clicked Add custom parameters.");
			Thread.sleep(medium);
			
			if (!type(ElsevierObjects.D2L_Parameter1_Name, "chrome_frame", "Parameter 1 Name"))
				flag = false;
			else
				Reporters.SuccessReport("Enter Parameter 1 Name",  "Successfully entered Parameter 1 Name: chrome_frame");
			
			if (!type(ElsevierObjects.D2L_Parameter1_Value, "false", "Parameter 1 Value"))
				flag = false;
			else
				Reporters.SuccessReport("Enter Parameter 1 Value",  "Successfully entered Parameter 1 Value: false");
			
			if (!type(ElsevierObjects.D2L_Parameter2_Name, "interactive_login", "Parameter 2 Name"))
				flag = false;
			else
				Reporters.SuccessReport("Enter Parameter 2 Name",  "Successfully entered Parameter 2 Name: interactive_login");
			
			if (!type(ElsevierObjects.D2L_Parameter2_Value, "false", "Parameter 2 Value"))
				flag = false;
			else
				Reporters.SuccessReport("Enter Parameter 2 Value",  "Successfully entered Parameter 2 Value: false");
			
			if (!click(ElsevierObjects.D2L_AddLinkSaveButton, "Save button")){
				flag = false;
				Reporters.failureReport("Click Save button","Failed to click Save button.");
			}
			else
				Reporters.SuccessReport("Click Save button","Successfully clicked Save button.");
			Thread.sleep(medium);
			
			if (!click(ElsevierObjects.D2L_MyHome, "My Home link")){
				flag = false;
				Reporters.failureReport("Click My Home link","Failed to click My Home link.");
			}
			else
				Reporters.SuccessReport("Click My Home link","Successfully clicked My Home link.");
			Thread.sleep(medium);
			
			// edit course and go to course builder
			if (!type(ElsevierObjects.D2L_CourseSearch, courseName, "Course search field"))
				flag = false;
			else
				Reporters.SuccessReport("Enter course name in search field",  "Successfully entered course name: " + courseName);
			Thread.sleep(low);
			
			if (!click(ElsevierObjects.D2L_CourseSearchButton, "Search button")){
				flag = false;
				Reporters.failureReport("Click Search button","Failed to click Search button.");
			}
			else
				Reporters.SuccessReport("Click Search button","Successfully clicked Search button.");
			Thread.sleep(high);
			
			if (!click(ElsevierObjects.D2L_EditCourse, "Edit Course")){
				flag = false;
				Reporters.failureReport("Click Edit Course","Failed to click Edit Course.");
			}
			else
				Reporters.SuccessReport("Click Edit Course","Successfully clicked Edit Course.");
			
			if (!click(ElsevierObjects.D2L_CourseBuilder, "Course Builder")){
				flag = false;
				Reporters.failureReport("Click Course Builder","Failed to click Course Builder.");
			}
			else
				Reporters.SuccessReport("Click Course Builder","Successfully clicked Course Builder.");
			Thread.sleep(high);
			
			// add module containing link to course
			if (!click(ElsevierObjects.D2L_CreateModule, "Create Module")){
				flag = false;
				Reporters.failureReport("Click Create Module","Failed to click Create Module.");
			}
			else
				Reporters.SuccessReport("Click Create Module","Successfully clicked Create Module.");
			Thread.sleep(high);
			
			switchToFrameByLocator(ElsevierObjects.D2L_ContentIFrame, "Content frame");
			Thread.sleep(low);
			if (!click(ElsevierObjects.D2L_CourseLocation, "Course link")){
				flag = false;
				Reporters.failureReport("Click Course link","Failed to click Course link.");
			}
			else
				Reporters.SuccessReport("Click Course link","Successfully clicked Course link.");
			Thread.sleep(high);
			
			switchToDefaultFrame();
			switchToFrameByLocator(ElsevierObjects.D2L_ContentIFrame, "Content frame");
			Thread.sleep(low);
			if (!type(ElsevierObjects.D2L_CreateModuleName, prefix + courseName, "New module name"))
				flag = false;
			else
				Reporters.SuccessReport("Enter new module name",  "Successfully entered new module name: " + prefix + courseName);
			
			switchToDefaultFrame();
			
			if (!click(ElsevierObjects.D2L_ModuleCreateButton, "Create button")){
				flag = false;
				Reporters.failureReport("Click Create button","Failed to click Create button.");
			}
			else
				Reporters.SuccessReport("Click Create button","Successfully clicked Create button.");
			Thread.sleep(medium);
			
			if (!click(ElsevierObjects.D2L_CreateLink, "Add link to module")){
				flag = false;
				Reporters.failureReport("Click Add link to module","Failed to click Add link to module.");
			}
			else
				Reporters.SuccessReport("Click Add link to module","Successfully clicked Add link to module.");
			Thread.sleep(medium);
			
			switchToFrameByLocator(ElsevierObjects.D2L_ContentIFrame, "Content frame");
			Thread.sleep(low);
			if (!click(ElsevierObjects.D2L_ModuleLocation, "Module location")){
				flag = false;
				Reporters.failureReport("Click Module location","Failed to click Module location.");
			}
			else
				Reporters.SuccessReport("Click Module location","Successfully clicked Module location.");
			Thread.sleep(high);
			
			switchToDefaultFrame();
			switchToFrameByLocator(ElsevierObjects.D2L_InsertQuicklinkFrame, "Content frame");
			Thread.sleep(low);
			if (!click(ElsevierObjects.D2L_AddToolToModule, "Add External Learning Tool to module")){
				flag = false;
				Reporters.failureReport("Click External Learning Tool","Failed to click External Learning Tool.");
			}
			else
				Reporters.SuccessReport("Click External Learning Tool","Successfully clicked External Learning Tool.");
			Thread.sleep(medium);
			
			switchToDefaultFrame();
			switchToFrameByLocator(ElsevierObjects.D2L_InsertQuicklinkFrame, "Content frame");
			Thread.sleep(low);
			if (!click(ElsevierObjects.D2L_SelectLTILink, "Select external LTI")){
				flag = false;
				Reporters.failureReport("Select external LTI","Failed to Select external LTI.");
			}
			else
				Reporters.SuccessReport("Select external LTI","Successfully Select external LTI.");
			Thread.sleep(medium);
			
			switchToDefaultFrame();
			if (!click(ElsevierObjects.D2L_AddLinkSaveButton, "Save button")){
				flag = false;
				Reporters.failureReport("Click Save button","Failed to click Save button.");
			}
			else
				Reporters.SuccessReport("Click Save button","Successfully clicked Save button.");
			Thread.sleep(low);
			
			if (!click(ElsevierObjects.D2L_MyHome, "My Home link")){
				flag = false;
				Reporters.failureReport("Click My Home link","Failed to click My Home link.");
			}
			else
				Reporters.SuccessReport("Click My Home link","Successfully clicked My Home link.");
			Thread.sleep(medium);
			
			// search for the course again and verify the link has been added
			if (!type(ElsevierObjects.D2L_CourseSearch, courseName, "Course search field"))
				flag = false;
			else
				Reporters.SuccessReport("Enter course name in search field",  "Successfully entered course name in search field: " + courseName);
			Thread.sleep(low);
			
			if (!click(ElsevierObjects.D2L_CourseSearchButton, "Search button")){
				flag = false;
				Reporters.failureReport("Click Search button","Failed to click Search button.");
			}
			else
				Reporters.SuccessReport("Click Search button","Successfully clicked Search button.");
			Thread.sleep(high);
			
			if (!click(ElsevierObjects.D2L_CourseContentLink, "Content link")){
				flag = false;
				Reporters.failureReport("Click Content link","Failed to click Content link.");
			}
			else
				Reporters.SuccessReport("Click Content link","Successfully clicked Content link.");
			Thread.sleep(medium);
			
			if (!click(ElsevierObjects.D2L_SelectLTILink, "Content module")){
				flag = false;
				Reporters.failureReport("Click the content module", "Failed to click the content module.");
			}
			else
				Reporters.SuccessReport("Click the content module", "Successfully clicked the content module.");
			
			if (isElementPresent(ElsevierObjects.D2L_ExternalContentLink))
				Reporters.SuccessReport("Check for the external content link", "Verified the external content link is present.");
			else {
				flag = false;
				Reporters.failureReport("Check for the external content link", "The external content link is not displayed.");
			}
			
			// return home
			if (!click(ElsevierObjects.D2L_MyHome, "My Home link")){
				flag = false;
				Reporters.failureReport("Click My Home link","Failed to click My Home link.");
			}
			else
				Reporters.SuccessReport("Click My Home link","Successfully clicked My Home link.");
			Thread.sleep(medium);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean addUserToClasslist(String courseName, String firstName, String lastName, String userID, String email, String role, String password) throws Throwable {
		
		boolean flag = true;
		try {
			
			// search for the course and go to the classlist
			if (!type(ElsevierObjects.D2L_CourseSearch, courseName, "Course search field"))
				flag = false;
			else
				Reporters.SuccessReport("Enter course name in search field",  "Successfully entered course name: " + courseName);
			Thread.sleep(low);
			
			if (!click(ElsevierObjects.D2L_CourseSearchButton, "Search button")){
				flag = false;
				Reporters.failureReport("Click Search button","Failed to click Search button.");
			}
			else
				Reporters.SuccessReport("Click Search button","Successfully clicked Search button.");
			Thread.sleep(high);
			
			if (!click(ElsevierObjects.D2L_Classlist, "Classlist")){
				flag = false;
				Reporters.failureReport("Click Classlist link","Failed to click Classlist link.");
			}
			else
				Reporters.SuccessReport("Click Classlist link","Successfully clicked Classlist link.");
			Thread.sleep(low);
			
			// select create and enroll new user option
			if (!click(ElsevierObjects.D2L_AddParticipants, "Add Participants")){
				flag = false;
				Reporters.failureReport("Click Add Participants","Failed to click Add Participants.");
			}
			else
				Reporters.SuccessReport("Click Add Participants","Successfully clicked Add Participants.");
			
			if (!click(ElsevierObjects.D2L_CreateNewUser, "Create and enroll new user")){
				flag = false;
				Reporters.failureReport("Click Create and enroll new user","Failed to click Create and enroll new user.");
			}
			else
				Reporters.SuccessReport("Click Create and enroll new user","Successfully clicked Create and enroll new user.");
			
			// enter user info and click enroll
			if (!type(ElsevierObjects.D2L_NewUserFirstName, firstName, "First Name")){
				flag = false;
				Reporters.failureReport("Enter new user's first name", "Failed to enter first name: " + firstName);
			}
			else
				Reporters.SuccessReport("Enter new user's first name", "Successfully entered first name: " + firstName);
			
			if (!type(ElsevierObjects.D2L_NewUserLastName, lastName, "Last Name")){
				flag = false;
				Reporters.failureReport("Enter new user's last name", "Failed to enter last name: " + lastName);
			}
			else
				Reporters.SuccessReport("Enter new user's last name", "Successfully entered last name: " + lastName);
			
			if (!type(ElsevierObjects.D2L_NewUserID, userID, "User ID")){
				flag = false;
				Reporters.failureReport("Enter new user's ID", "Failed to enter user ID: " + userID);
			}
			else
				Reporters.SuccessReport("Enter new user's ID", "Successfully entered user ID: " + userID);
			
			if (!type(ElsevierObjects.D2L_NewUserEmail, email, "Email")){
				flag = false;
				Reporters.failureReport("Enter new user's email", "Failed to enter email: " + email);
			}
			else
				Reporters.SuccessReport("Enter new user's email", "Successfully entered email: " + email);
			
			if (!selectByVisibleText(ElsevierObjects.D2L_NewUserRole, role, "Role")){
				flag = false;
				Reporters.failureReport("Select user's role", "Failed to select user's role: " + role);
			}
			else
				Reporters.SuccessReport("Select user's role", "Successfully selected user's role: " + role);
			
			if (!type(ElsevierObjects.D2L_NewUserPass, password, "Password")){
				flag = false;
				Reporters.failureReport("Enter new user's password", "Failed to enter password: " + password);
			}
			else
				Reporters.SuccessReport("Enter new user's password", "Successfully entered password: " + password);
			
			if (!click(ElsevierObjects.D2L_EnrollButton, "Enroll button")){
				flag = false;
				Reporters.failureReport("Click Enroll button", "Failed to click Enroll button");
			}
			else
				Reporters.SuccessReport("Click Enroll button", "Successfully clicked Enroll button");
			Thread.sleep(high);
			
			// save the new user's first and last name to the spreadsheet
			ReadingExcel.updateCellInSheet(1, 7, configProps.getProperty("TestData"), "LTITestCases", firstName);
			ReadingExcel.updateCellInSheet(1, 8, configProps.getProperty("TestData"), "LTITestCases", lastName);
			
			// return to My Home
			click(ElsevierObjects.D2L_MyHome, "My Home");
			Thread.sleep(medium);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean verifyClasslist(String courseName, String firstName, String lastName, String email, String role) throws Throwable {
		
		boolean flag = true;
		try {
			
			// search for the course and go to the classlist
			if (!type(ElsevierObjects.D2L_CourseSearch, courseName, "Course search field"))
				flag = false;
			else
				Reporters.SuccessReport("Enter course name in search field",  "Successfully entered course name: " + courseName);
			Thread.sleep(low);
			
			if (!click(ElsevierObjects.D2L_CourseSearchButton, "Search button")){
				flag = false;
				Reporters.failureReport("Click Search button","Failed to click Search button.");
			}
			else
				Reporters.SuccessReport("Click Search button","Successfully clicked Search button.");
			Thread.sleep(high);
			
			if (!click(ElsevierObjects.D2L_Classlist, "Classlist")){
				flag = false;
				Reporters.failureReport("Click Classlist link","Failed to click Classlist link.");
			}
			else
				Reporters.SuccessReport("Click Classlist link","Successfully clicked Classlist link.");
			Thread.sleep(low);
			
			// verify student's name in class list 
			if (isElementPresent(ElsevierObjects.D2L_ClasslistName)) {
				if (getText(ElsevierObjects.D2L_ClasslistName, "Get student name").contains(firstName) && getText(ElsevierObjects.D2L_ClasslistName, "Get student name").contains(lastName))
					Reporters.SuccessReport("Verify student's name appears in class list", "Successfully located student's name: " + firstName + " " + lastName);
				else {
					flag = false;
					Reporters.failureReport("Verify student's name appears in class list", "Unable to locate student's name: " + firstName + " " + lastName);
				}				
			}
			else {
				flag = false;
				Reporters.failureReport("Verify student's name appears in class list", "Unable to locate student's name: " + firstName + " " + lastName);
			}
			
			// verify student's email in class list
			if (isElementPresent(ElsevierObjects.D2L_ClasslistEmail)) {
				if (getText(ElsevierObjects.D2L_ClasslistEmail, "Get email address").contains(email))
					Reporters.SuccessReport("Verify student's email appears in class list", "Successfully located student's email: " + email);
				else {
					flag = false;
					Reporters.failureReport("Verify student's email appears in class list", "Unable to locate student's email: " + email);
				}
			}
			else {
				flag = false;
				Reporters.failureReport("Verify student's email appears in class list", "Unable to locate student's email: " + email);
			}
			
			// verify student's role in class list
			if (isElementPresent(ElsevierObjects.D2L_ClasslistRole)) {
				if (getText(ElsevierObjects.D2L_ClasslistRole, "Get role").contains(role))
					Reporters.SuccessReport("Verify student's role appears in class list", "Successfully located student's role: " + role);
				else {
					flag = false;
					Reporters.failureReport("Verify student's role appears in class list", "Unable to locate student's role: " + role);
				}
			}
			else {
				flag = false;
				Reporters.failureReport("Verify student's role appears in class list", "Unable to locate student's role: " + role);
			}
			
			// return to My Home
			click(ElsevierObjects.D2L_MyHome, "My Home");
			Thread.sleep(medium);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;		
	}
	
	public static boolean getURLandScheme(String courseID, String module, String assessmentName) throws Throwable {
		
		boolean flag = true;
		try {
			
			// navigate to administration portal, go to Courses
			if (!click(ElsevierObjects.myAccount, "My Account")){
				flag = false;
				Reporters.failureReport("Click My Account","Failed to click My Account.");
			}
			else
				Reporters.SuccessReport("Click My Account","Successfully clicked My Account.");
			
			if (!click(ElsevierObjects.Ecert_Admin_PortalLink, "Portal Administration")){
				flag = false;
				Reporters.failureReport("Click Portal Administration","Failed to click Portal Administration.");
			}
			else
				Reporters.SuccessReport("Click Portal Administration","Successfully clicked Portal Administration.");
			Thread.sleep(low);
			
			if (!click(ElsevierObjects.Admin_portal_Courses, "Courses link")){
				flag = false;
				Reporters.failureReport("Click Courses link","Failed to click Courses link.");
			}
			else
				Reporters.SuccessReport("Click Courses link","Successfully clicked Courses link.");
			Thread.sleep(medium);
			
			// search for the existing course and open it
			if (!type(ElsevierObjects.Manage_Courses_Filter, courseID, "Enter the existing course ID"))
					flag = false;
			else
				Reporters.SuccessReport("Enter existing course ID",  "Successfully entered existing course ID: " + courseID);
			Thread.sleep(medium);
			
			if(isElementPresent(ElsevierObjects.Group_Id_details,"Check the GroupId column")){
				Reporters.SuccessReport("Verify the GroupId column","There is one search result that displays the course ID entered in the Group ID column.");
			}else{
				Reporters.failureReport("Verify the GroupId column","There is more than one search results that displays the course ID entered in the Group ID column.");
			}
			
			click(ElsevierObjects.Group_Id_details, "Course in search results");
			Thread.sleep(low);
			
			if (!click(ElsevierObjects.AdminGoToGroup, "Open Course button")){
				flag = false;
				Reporters.failureReport("Click Open Course button","Failed to click Open Course button.");
			}
			else
				Reporters.SuccessReport("Click Open Course button","Successfully clicked Open Course button.");
			Thread.sleep(high);
			
			// navigate to the correct module
			if (!click(ElsevierObjects.educator_CoursePage_Courselink, "Course link")) {
				flag = false;
				Reporters.failureReport("Click the Course link", "Failed to click the Course link");
			}
			else
				Reporters.SuccessReport("Click the Course link", "Successfully clicked the Course link");
			Thread.sleep(low);
			
			By moduleLink = By.xpath(".//a[text()='" + module + "']");
			if (!click(moduleLink, "Module link")) {
				flag = false;
				Reporters.failureReport("Click the Module link", "Failed to click the Module link");
			}
			else
				Reporters.SuccessReport("Click the Module link", "Successfully clicked the Module link");
			Thread.sleep(low);
			
			// open the about window for the assessment
			By editButton = By.xpath(".//div/a[text()='" + assessmentName + "']/ancestor::div[contains(@class,'content-info')]/following-sibling::div/a[@class='btn']");
			if (!click(editButton, "Edit button")) {
				flag = false;
				Reporters.failureReport("Click the Edit button for the assessment", "Failed to click the Edit button for assessment: " + assessmentName);
			}
			else
				Reporters.SuccessReport("Click the Edit button for the assessment", "Successfully clicked the Edit button for the assessment: " + assessmentName);
			Thread.sleep(low);
			
			By aboutLink = By.xpath(".//div/a[text()='" + assessmentName + "']/ancestor::div[contains(@class,'content-info')]/following-sibling::div//span[text()='About']");
			if (!click(aboutLink, "About link")) {
				flag = false;
				Reporters.failureReport("Click the About link for the assessment", "Failed to click the About link for assessment: " + assessmentName);
			}
			else
				Reporters.SuccessReport("Click the About link for the assessment", "Successfully clicked the About link for the assessment: " + assessmentName);
			Thread.sleep(low);
			
			// get the protection scheme and save it to the spreadsheet
			String scheme = getText(ElsevierObjects.Ecert_Admin_ProtectionSchemeID, "Protection Scheme");
			int start = scheme.lastIndexOf('(');
            int end = scheme.lastIndexOf(')');
            scheme = scheme.substring(start + 1, end);
            System.out.println("Protection Scheme: " + scheme);
            ReadingExcel.updateCellInSheet(1, 13, configProps.getProperty("TestData"), "LTITestCases", scheme);
            
            // get the LTI URL and save it to the spreadsheet
            String url = getAttribute(ElsevierObjects.LTIurl, "href", "LTI URL");
            System.out.println("LTI URL: " + url);
            ReadingExcel.updateCellInSheet(1, 13, configProps.getProperty("TestData"), "LTITestCases", scheme);
            
            // close the popup and logout
            click(ElsevierObjects.ProtectionSchemeID_OK, "OK button");
            Thread.sleep(low);
            instructorLogout();
            Thread.sleep(medium);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean d2l_Logout() throws Throwable {
		
		boolean flag = true;
		try {
			
			if (!click(ElsevierObjects.D2L_UserMenu, "User menu")) {
				flag = false;
				Reporters.failureReport("Click user menu dropdown", "Failed to click the user menu dropdown");
			}
			else
				Reporters.SuccessReport("Click the user menu dropdown", "Successfully clicked the user menu dropdown");
			Thread.sleep(low);
			
			if (!click(ElsevierObjects.D2L_Logout, "Log Out")) {
				flag = false;
				Reporters.failureReport("Click Log Out", "Failed to click Log Out");
			}
			else
				Reporters.SuccessReport("Click Log Out", "Successfully clicked Log Out");
			Thread.sleep(low);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean maintainProduct(String isbn) throws Throwable {
		
		boolean flag = true;
		try {
			
			// go to maintain products
			if (!click(ElsevierObjects.admin_MaintainProduct_lnk, "Maintain Products link")) {
				flag = false;
				Reporters.failureReport("Click Maintain Products", "Failed to click Maintain Products");
			}
			else
				Reporters.SuccessReport("Click Maintain Products", "Successfully clicked Maintain Products");
			Thread.sleep(low);
			
			// search for the isbn
			if (!type(ElsevierObjects.admin_MaintainProduct_Knotxt, isbn, "Search field")) {
				flag = false;
				Reporters.failureReport("Enter isbn in search field", "Failed to enter isbn in search field: " + isbn);
			}
			else
				Reporters.SuccessReport("Enter isbn in search field", "Successfully entered isbn in search field: " + isbn);
			
			if (!click(ElsevierObjects.admin_MaintainProduct_Submit, "Search button")) {
				flag = false;
				Reporters.failureReport("Click Search button", "Failed to click on Search button");
			}
			else
				Reporters.SuccessReport("Click Search button", "Successfully clicked Search button");
			Thread.sleep(low);
			
			// click on isbn in search results
			if (!click(ElsevierObjects.MaintainPrdct_prdctSerachReslut_isbn, "Search result")) {
				flag = false;
				Reporters.failureReport("Click ISBN in search results", "Failed to click on ISBN in search results");
			}
			else
				Reporters.SuccessReport("Click ISBN in search results", "Successfully clicked on ISBN in search results");
			Thread.sleep(medium);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean createAccessCode(String expectedScheme) throws Throwable {
		
		boolean flag = true;
		try {
			
			// go to create access code tab
			if (!click(ElsevierObjects.createAccessCode, "Create Access Codes tab")) {
				flag = false;
				Reporters.failureReport("Click Create Access Codes tab", "Failed to click Create Access Codes tab");
			}
			else
				Reporters.SuccessReport("Click Create Access Codes tab", "Successfully clicked Create Access Codes tab");
			Thread.sleep(medium);
			
			// get the protection scheme and compare to expected
			String scheme = getText(ElsevierObjects.createAccessCodeSchemeID, "Protection Sheme");
			if (scheme.equals(expectedScheme))
				Reporters.SuccessReport("Compare protection schemes", "Schemes match!</br>Expected: " + expectedScheme + "</br>" + "Actual: " + scheme);
			else {
				flag = false;
				Reporters.failureReport("Compare protection schemes", "Schemes do not match!</br>Expected: " + expectedScheme + "</br>" + "Actual: " + scheme);
			}
			
			// create new access code
			Random ra = new Random( System.currentTimeMillis() );
			Date today = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat ("MMddyyyy");
			String codeSetName = "AccessCode_" + Integer.toString((1 + ra.nextInt(2)) * 100 + ra.nextInt(10000)) + "_" + sdf.format(today);
			
			if (!type(ElsevierObjects.CreateAccessCode_codesetname, codeSetName , "Code set name")) {
				flag = false;
				Reporters.failureReport("Enter code set name", "Failed to enter code set name: " + codeSetName);
			}
			else
				Reporters.SuccessReport("Enter code set name", "Successfully entered code set name: " + codeSetName);
			
			if (!type(ElsevierObjects.CreateAccessCode_codeNumber, "1", "Code set number")){
				flag=false;
				Reporters.failureReport("Enter number to generate", "Failed to entere number to generate: 1");
			}
			else
				Reporters.SuccessReport("Enter number to generate", "Successfully entered number to generate: 1");
			
			if (!click(ElsevierObjects.CreateAccessCode_Submit, "Save button")) {
				Reporters.failureReport("Click Save button", "Failed to create access code");
			}
			else
				Reporters.SuccessReport("Click Save button", "Successfully created access code set: " + codeSetName);
			Thread.sleep(high);
			
			// get the new access code and save to spreadsheet
			if (!click(ElsevierObjects.MaintainPrdct_MaintainAccesCode, "Manage Access Codes tab")) {
				flag = false;
				Reporters.failureReport("Click Manage Access Codes tab", "Failed to click Manage Access Codes tab");
			}
			else
				Reporters.SuccessReport("Click Manage Access Codes tab", "Successfully clicked Manage Access Codes tab");
			Thread.sleep(medium);
			
			if (!click(ElsevierObjects.accessCodeSetName_clk, "New access code set")) {
				flag = false;
				Reporters.failureReport("Click the new access code set", "Failed to click the new access code set: " + codeSetName);
			}
			else
				Reporters.SuccessReport("Click the new access code set", "Successfully clicked the new access code set: " + codeSetName);
			Thread.sleep(medium);
			
			String code = getText(ElsevierObjects.AccessCode, "New access code");
			System.out.println("New access code: " + code);
			if(code.equals(null)){
				flag = false;
				Reporters.failureReport("Retrieve the new access code", "Failed to retrieve the new access code");
			}
			else{
				Reporters.SuccessReport("Retrieve the new access code", "Successfully retrieved the new access code: " + code);
				ReadingExcel.updateCellInSheet(1, 17, configProps.getProperty("TestData"), "LTITestCases", code);
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean studentVerifyCourse(String courseName) throws Throwable {
		
		boolean flag = true;
		try {
			
			// verify the course link is displayed for the student and open it
			By courseLink = By.xpath(".//a[@title='Enter " + courseName + "']");
			if (!isElementPresent(courseLink)) {
				flag = false;
				Reporters.failureReport("Verify course link is present", "Failed to locate link for course: " + courseName);
			}
			else
				Reporters.SuccessReport("Verify course link is present", "Successfully located link for course: " + courseName);
			
			// open the course and go to content
			if (!click(courseLink, "Course link")) {
				flag = false;
				Reporters.failureReport("Open the course", "Unable to click link to open course: " + courseName);
			}
			else
				Reporters.SuccessReport("Open the course", "Successfully clicked link to open course: " + courseName);
			Thread.sleep(medium);
			
			if (!click(ElsevierObjects.D2L_CourseContentLink, "Content link")) {
				flag = false;
				Reporters.failureReport("Click Content link", "Failed to click Content link");
			}
			else
				Reporters.SuccessReport("Click Content link", "Successfully clicked Content link");
			Thread.sleep(medium);
			
			// verify the external learning tool link is present
			if (!isElementPresent(ElsevierObjects.D2L_ExternalLink)) {
				flag = false;
				Reporters.failureReport("Verify link to external tool is present", "Unable to locate link to external tool for course: " + courseName);
			}
			else
				Reporters.SuccessReport("Verify link to external tool is present", "Successfully located link to external tool for course: " + courseName);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean submitAccessCode() throws Throwable {
		
		boolean flag = true;
		try {
			
			String invalidAC = ReadingExcel.columnDataByHeaderName("InvalidAC", "LTITestCases", configProps.getProperty("TestData"));
			String redeemedAC = ReadingExcel.columnDataByHeaderName("RedeemedAC", "LTITestCases", configProps.getProperty("TestData"));
			String validAC = ReadingExcel.columnDataByHeaderName("ValidAC", "LTITestCases", configProps.getProperty("TestData"));
			
			// click content link to open access code popup
			if (!click(ElsevierObjects.D2L_ExternalLink, "External Learning Tool link")) {
				flag = false;
				Reporters.failureReport("Click External Learning Tool link", "Failed to click External Learning Tool link");
			}
			else
				Reporters.SuccessReport("Click External Learning Tool link", "Successfully clicked External Learning Tool link");
			Thread.sleep(veryhigh);
			
			// verify appearance of protected content popup
			switchToFrameByLocator(ElsevierObjects.D2L_AccessCodeFrame, "Enter Access Code frame");
			String title = getText(ElsevierObjects.Protected_content, "Title of protected content popup");
			if (title != null)
				Reporters.SuccessReport("Verify title of popup", "Popup title located: " + title);
			else
				Reporters.failureReport("Verify title of popup", "Unable to locate popup title");
			
			if (isElementPresent(ElsevierObjects.redeem_AcessCode_txt, "Access Code textbox"))
			    Reporters.SuccessReport("Verify blank Access Code textbox is displayed", "Blank Access Code textbox is displayed");
			else
				Reporters.failureReport("Verify blank Access Code textbox is displayed", "Blank Access Code textbox is not displayed");
			
			// enter invalid access code and verify messaging
			if (!type(ElsevierObjects.redeem_AcessCode_txt, invalidAC, "Access Code textbox")) {
				flag = false;
				Reporters.failureReport("Enter invalid access code", "Failed to enter invalid access code: " + invalidAC);
			}
			else
				Reporters.SuccessReport("Enter invalid access code", "Successfully entered invalid access code: " + invalidAC);
			
			if (!click(ElsevierObjects.AccessCodeRedeemButton, "Redeem button")) {
				flag = false;
				Reporters.failureReport("Click Redeem button", "Failed to click Redeem button");
			}
			else
				Reporters.SuccessReport("Click Redeem button", "Successfully clicked Redeem button");
			Thread.sleep(high);
			
			title = getText(ElsevierObjects.InvalidCodeTitle, "Invalid code popup title");
			String message = getText(ElsevierObjects.InvalidCodeMessage, "Invalid code popup message");
			if (title != null && message != null) {
				Reporters.SuccessReport("Validate title and message of popup",
						"Title and message are correct...</br>" +
						"Title: " + title + "</br>" +
						"Message: " + message);
			}
			else {
				flag = false;
				Reporters.failureReport("Validate title and message of popup",
						"Title and message are incorrect...</br>" +
						"Title: " + title + "</br>" +
						"Message: " + message);
			}
			
			if (!click(ElsevierObjects.InvalidCodeOK, "OK button")) {
				flag = false;
				Reporters.failureReport("Close invalid code popup", "Failed to close the invalid code popup");
			}
			else
				Reporters.SuccessReport("Close invalid code popup", "Successfully closed invalid code popup");
			Thread.sleep(low);
			
			// enter redeemed access code and verify messaging
			driver.findElement(ElsevierObjects.redeem_AcessCode_txt).clear();
			Thread.sleep(low);
			
			if (!type(ElsevierObjects.redeem_AcessCode_txt, redeemedAC, "Access Code textbox")) {
				flag = false;
				Reporters.failureReport("Enter redeemed access code", "Failed to enter redeemed access code: " + redeemedAC);
			}
			else
				Reporters.SuccessReport("Enter redeemed access code", "Successfully entered redeemed access code: " + redeemedAC);
			
			if (!click(ElsevierObjects.AccessCodeRedeemButton, "Redeem button")) {
				flag = false;
				Reporters.failureReport("Click Redeem button", "Failed to click Redeem button");
			}
			else
				Reporters.SuccessReport("Click Redeem button", "Successfully clicked Redeem button");
			Thread.sleep(high);
			
			title = getText(ElsevierObjects.InvalidCodeTitle, "Invalid code popup title");
			message = getText(ElsevierObjects.InvalidCodeMessage, "Invalid code popup message");
			if (title != null && message != null) {
				Reporters.SuccessReport("Validate title and message of popup",
						"Title and message are correct...</br>" +
						"Title: " + title + "</br>" +
						"Message: " + message);
			}
			else {
				flag = false;
				Reporters.failureReport("Validate title and message of popup",
						"Title and message are incorrect...</br>" +
						"Title: " + title + "</br>" +
						"Message: " + message);
			}
			
			if (!click(ElsevierObjects.InvalidCodeOK, "OK button")) {
				flag = false;
				Reporters.failureReport("Close invalid code popup", "Failed to close the invalid code popup");
			}
			else
				Reporters.SuccessReport("Close invalid code popup", "Successfully closed invalid code popup");
			Thread.sleep(low);
			
			// enter valid access code
			driver.findElement(ElsevierObjects.redeem_AcessCode_txt).clear();
			Thread.sleep(low);
			
			if (!type(ElsevierObjects.redeem_AcessCode_txt, validAC, "Access Code textbox")) {
				flag = false;
				Reporters.failureReport("Enter valid access code", "Failed to enter valid access code: " + validAC);
			}
			else
				Reporters.SuccessReport("Enter valid access code", "Successfully entered valid access code: " + validAC);
			
			if (!click(ElsevierObjects.AccessCodeRedeemButton, "Redeem button")) {
				flag = false;
				Reporters.failureReport("Click Redeem button", "Failed to click Redeem button");
			}
			else
				Reporters.SuccessReport("Click Redeem button", "Successfully clicked Redeem button");
			Thread.sleep(veryhigh);
			
			switchToDefaultFrame();
			switchToFrameByLocator(ElsevierObjects.D2L_AccessCodeFrame, "Containing frame");
			switchToFrameByLocator(ElsevierObjects.D2L_EmbeddedContentFrame, "Embedded content frame");
			if (!isElementPresent(ElsevierObjects.BeginAssessmentButton, "Begin Assessment button")) {
				flag = false;
				Reporters.failureReport("Verify Begin Assessment button is displayed", "Unable to locate Begin Assessment button");
			}
			else
				Reporters.SuccessReport("Verify Begin Assessment button is displayed", "Successfully located Begin Assessment button");
			
			// return to my home
			switchToDefaultFrame();
			click(ElsevierObjects.D2L_MyHome, "My Home");
			Thread.sleep(medium);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean reverifyStudentAccess() throws Throwable {
		
		boolean flag = true;
		try {
			
			// click the external content link
			if (!click(ElsevierObjects.D2L_ExternalLink, "External Learning Tool link")) {
				flag = false;
				Reporters.failureReport("Click External Learning Tool link", "Failed to click External Learning Tool link");
			}
			else
				Reporters.SuccessReport("Click External Learning Tool link", "Successfully clicked External Learning Tool link");
			Thread.sleep(veryhigh);
			
			// verify the begin assessment button is displayed
			switchToFrameByLocator(ElsevierObjects.D2L_AccessCodeFrame, "Containing frame");
			switchToFrameByLocator(ElsevierObjects.D2L_EmbeddedContentFrame, "Embedded content frame");
			if (!isElementPresent(ElsevierObjects.BeginAssessmentButton, "Begin Assessment button")) {
				flag = false;
				Reporters.failureReport("Verify Begin Assessment button is displayed", "Unable to locate Begin Assessment button");
			}
			else
				Reporters.SuccessReport("Verify Begin Assessment button is displayed", "Successfully located Begin Assessment button");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}
	
	public static boolean createNewEvolveStudent() throws Throwable {
		
		boolean flag = true;
		try {
			
			// launch evolve homepage
			driver.manage().deleteAllCookies();
			Thread.sleep(low);
			if (!launchUrl(configProps.getProperty("URL"))) {
				flag = false;
				Reporters.failureReport("Open the Evolve Main Page", "Failed to open the Evolve Main Page");
			}
			else
				Reporters.SuccessReport("Open the Evolve Main Page", "Successfully opened the Evolve Main Page");
			
			// open new account form
			if (!click(ElsevierObjects.evolve_createNewUser, "Create Account link")) {
				flag=false;
				Reporters.failureReport("Open Create Account form", "Failed to open the Create Account form");
			}
			else
				Reporters.SuccessReport("Open Create Account form", "Successfully opened the Create Account form");
			Thread.sleep(low);
			
			// fill in the form and submit
			switchToFrameByLocator(ElsevierObjects.evolve_newAcount_frame, "Create Account frame");
			
			// first name
			if (!type(ElsevierObjects.evolve_newAccount_firstname, "LTIauto", "First name")) {
				flag = false;
				Reporters.failureReport("Enter first name", "Failed to enter first name");
			}
			else
				Reporters.SuccessReport("Enter first name", "Successfully entered first name: LTIauto");
			
			// last name
			if (!type(ElsevierObjects.evolve_newAcount_Lastname, "LTIauto", "Last name")) {
				flag = false;
				Reporters.failureReport("Enter last name", "Failed to enter last name");
			}
			else
				Reporters.SuccessReport("Enter last name", "Successfully entered last name: LTIauto");
			
			// email address
			Random ra = new Random( System.currentTimeMillis() );
			Date today = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat ("MMddyyyy");
			String email = "LTIauto_" + Integer.toString((1 + ra.nextInt(2)) * 100 + ra.nextInt(100)) + "_" + sdf.format(today) + "@evolveqa.info";
			ReadingExcel.updateCellInSheet(1, 19, configProps.getProperty("TestData"), "LTITestCases", email);
			System.out.println("New student email address: " + email);
			
			if (!type(ElsevierObjects.evolve_newAcount_Email, email, "Email Address")) {
				flag = false;
				Reporters.failureReport("Enter email address", "Failed to enter email address: " + email);
			}
			else
				Reporters.SuccessReport("Enter email address", "Successfully entered email address: " + email);
			
			// password
			if (!type(ElsevierObjects.evolve_newAcount_Pwd, "Test123", "Password")) {
				flag = false;
				Reporters.failureReport("Enter password", "Failed to enter password");
			}
			else
				Reporters.SuccessReport("Enter password", "Successfully entered password");
			
			if (!type(ElsevierObjects.evolve_newAcount_ConfirmPwd, "Test123", "Confirm Password")) {
				flag = false;
				Reporters.failureReport("Enter confirm password", "Failed to enter confirm password");
			}
			else
				Reporters.SuccessReport("Enter confirm password", "Successfully entered confirm password");
			
			// submit the form
			if (!click(ElsevierObjects.evolve_newAcount_Submit_btn, "Submit button")) {
				flag=false;
				Reporters.failureReport("Click Submit", "Failed to click Submit button");
			}
			else
				Reporters.SuccessReport("Click Submit", "Successfully clicked the Submit button");
			Thread.sleep(high);
			
			if (!click(ElsevierObjects.newAccount_contiue_btn, "Continue button")) {
				flag=false;
				Reporters.failureReport("Click Continue", "Failed to click Continue button");
			}
			else
				Reporters.SuccessReport("Click Continue", "Successfully clicked Continue button");
			Thread.sleep(high);
			
			// logout
			if (!instructorLogout()) {
				flag = false;
				Reporters.failureReport("Logout of account", "Failed to logout of new student account");
			}
			else
				Reporters.SuccessReport("Logout of account", "Successfully logged out of new student account");
			Thread.sleep(medium);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return flag;
	}

}
