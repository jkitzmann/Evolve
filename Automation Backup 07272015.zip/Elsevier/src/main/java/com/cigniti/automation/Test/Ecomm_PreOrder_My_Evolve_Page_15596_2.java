package com.cigniti.automation.Test;

import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EComm_Preorde_MyEvolve_Page15594_BussinessFunctions;
import com.cigniti.automation.BusinessFunctions.ECommercePackagependingcourseid_15461;
import com.cigniti.automation.BusinessFunctions.Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class Ecomm_PreOrder_My_Evolve_Page_15596_2 extends Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions{
	@Test
	public void ecommPreOrderMyEvolvePage_15596_2() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		launchUrl(configProps.getProperty("URL4"));
		String courseID=ReadingExcel.columnDataByHeaderName("CourseID", "TC-15596", testDataPath);
		String username=readcolumns.twoColumns(0,1, "ECommercePreOrder", configProps.getProperty("TestData")).get("ecommPreOrderMyEvolve15596");
		String password=readcolumns.twoColumns(0,2, "ECommercePreOrder", configProps.getProperty("TestData")).get("ecommPreOrderMyEvolve15596");
		if(User_BusinessFunction.SignInAsDifferentUser(username, password)){
			Reporters.SuccessReport("Login into Application as same student user", "Successfully logged in as Student user with the credentials : <br> Username : "+username+"<br> Password : "+password);
		}else{
			Reporters.failureReport("Login into Application as same student user", "Failed to log in as Student user with the credentials : <br> Username : "+username+"<br> Password : "+password);
		}
		String course=ReadingExcel.columnDataByHeaderName("course", "TC-15596", testDataPath);
		String button1=ReadingExcel.columnDataByHeaderName("button1", "TC-15596", testDataPath);
		String button2=ReadingExcel.columnDataByHeaderName("button2", "TC-15596", testDataPath);
		String courseType=ReadingExcel.columnDataByHeaderName("courseType", "TC-15596", testDataPath);
		
		ECommercePackagependingcourseid_15461.VerifyContentpagewithinputs(courseType, course ,button1,"","Yes");
		verifyEnterLaterButton();
		enterInstructorCourseId(courseID);
		//enterCourseId("111638_nuser2013_1001");
		EComm_Preorde_MyEvolve_Page15594_BussinessFunctions.courseDetailsPage(By.xpath("//*[@id='set']/li/div/div/a"),"contentHome");
		//verifySubFloders();
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
