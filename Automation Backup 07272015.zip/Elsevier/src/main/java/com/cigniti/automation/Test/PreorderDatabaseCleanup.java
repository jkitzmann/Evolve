package com.cigniti.automation.Test;

import java.sql.*;
import java.util.HashSet;

import org.testng.annotations.*;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.Utilities.Reporters;

public class PreorderDatabaseCleanup extends EvolveCommonBussinessFunctions {
	
	@Test
	public void preorderDBCleanup() throws Throwable {
		
		try {
			
			final String DB_URL = "jdbc:oracle:thin:@evcertlarge";
			final String DB_USER = "automation";
			final String DB_PASS = "cert1autords";
			final String TNS_NAMES_LOC = "C:/oracle/product/10.2.0/client_1/NETWORK/ADMIN";
			final String LAST_FOUR = "<ENCR1AES0006>6EE28D509A8BA0EADEC26C65017CC258";
			
			// setup db connection
			ResultSet rs;
			String query;
			System.setProperty("oracle.net.tns_admin", TNS_NAMES_LOC);
			Class.forName("oracle.jdbc.OracleDriver").newInstance();
			Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
			Statement statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			
			// get the parent order ids that use the credit card
			stepReport("Get the order ids that use the credit card");
			HashSet<String> orderIDs = new HashSet<String>();
			query = "select eo.evl_order_id from evladmin.evl_order eo " +
					"join evladmin.credit_card_detail ccd " +
					"on eo.credit_card_id = ccd.credit_card_id " +
					"where ccd.last_four_digits = '" + LAST_FOUR + "'";
			rs = statement.executeQuery(query);
			while(rs.next()){
				orderIDs.add(rs.getString(1));
			}
			
			// get any child orders of the above parents
			query = "select pq.evl_order_id from evladmin.preorder_queue pq where pq.parent_evl_order_id in (";
			int i = 1;
			for (String ordernum : orderIDs){
				query += ordernum;
				if (i < orderIDs.size()){
					query += ",";
				}
				i++;
			}
			query += ")";
			rs = statement.executeQuery(query);
			while (rs.next()){
				orderIDs.add(rs.getString(1));
			}
			if (orderIDs.size() > 0){
				Reporters.SuccessReport("Retrieve order IDs that use the credit card and their children", "Successfully retrieved the order IDs.");
				System.out.println(orderIDs);
			}
			else {
				Reporters.failureReport("Retrieve order IDs that use the credit card and their children", "Failed to retrieve the order IDs.");
			}
			
			// create a complete list of the orders for use in deletions
			i = 1;
			String orderList = "";
			for (String ordernum : orderIDs){
				orderList += ordernum;
				if (i < orderIDs.size()){
					orderList += ",";
				}
				i++;
			}
			System.out.println(orderList + "\n");
			
			// get the order review ids from the database
			stepReport("Get evl_order_review_id from database for the orders");
			HashSet<String> reviewIDs = new HashSet<String>();
			query = "select evl_order_review_id from evladmin.evl_order_review where evl_order_id in (" + orderList + ")";
			rs = statement.executeQuery(query);
			while(rs.next()){
				reviewIDs.add(rs.getString(1));
			}
			
			// create a complete list of the review ids for use in deletions
			i = 1;
			String reviewList = "";
			for (String reviewnum : reviewIDs){
				reviewList += reviewnum;
				if (i < reviewIDs.size()){
					reviewList += ",";
				}
				i++;
			}
			System.out.println(reviewList + "\n");
			
			stepReport("Delete the necessary records from the database");
			int rowsDeleted;
			conn.setAutoCommit(true);
			
			if (reviewIDs.size() > 0) {
				// delete from evl_order_review_audit table
				System.out.println("Deleting from evl_order_review_audit table");
				query = "delete from evladmin.evl_order_review_audit where evl_order_review_id in (" + reviewList + ")";
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records from evl_order_review_audit", "Successfully deleted " + rowsDeleted + " rows from evl_order_review_audit.");
			
				// delete from evl_order_review table
				System.out.println("Deleting from evl_order_review table");
				query = "delete from evladmin.evl_order_review where evl_order_id in (" + orderList + ")";
				System.out.println(query);
				rowsDeleted = statement.executeUpdate(query);
				System.out.println(rowsDeleted + " rows deleted.\n");
				Reporters.SuccessReport("Deleting records from evl_order_review", "Successfully deleted " + rowsDeleted + " rows from evl_order_review.");
			}
			
			// delete from order_item table
			System.out.println("Deleting from order_item table");
			query = "delete from evladmin.order_item where evl_order_id in (" + orderList + ")";
			System.out.println(query);
			rowsDeleted = statement.executeUpdate(query);
			System.out.println(rowsDeleted + " rows deleted.\n");
			if (rowsDeleted > 0) {
				Reporters.SuccessReport("Deleting records from order_item", "Successfully deleted " + rowsDeleted + " rows from order_item.");
			}
			else
				Reporters.failureReport("Deleting records from order_item", "Failed to delete any rows from order_item.");
			
			// delete from preorder_queue table
			System.out.println("Deleting from preorder_queue table");
			query = "delete from evladmin.preorder_queue where evl_order_id in (" + orderList + ")";
			System.out.println(query);
			rowsDeleted = statement.executeUpdate(query);
			System.out.println(rowsDeleted + " rows deleted.\n");
			if (rowsDeleted > 0) {
				Reporters.SuccessReport("Deleting records from preorder_queue", "Successfully deleted " + rowsDeleted + " rows from preorder_queue.");
			}
			else
				Reporters.failureReport("Deleting records from preorder_queue", "Failed to delete any rows from preorder_queue.");
			
			// delete from evl_order table
			System.out.println("Deleting from evl_order table");
			query = "delete from evladmin.evl_order where evl_order_id in (" + orderList + ")";
			System.out.println(query);
			rowsDeleted = statement.executeUpdate(query);
			System.out.println(rowsDeleted + " rows deleted.\n");
			if (rowsDeleted > 0) {
				Reporters.SuccessReport("Deleting records from evl_order", "Successfully deleted " + rowsDeleted + " rows from evl_order.");
			}
			else
				Reporters.failureReport("Deleting records from evl_order", "Failed to delete any rows from evl_order.");
			
			// delete from credit_card_detail table
			System.out.println("Deleting from credit_card_detail table");
			query = "delete from evladmin.credit_card_detail where last_four_digits = '" + LAST_FOUR + "'";
			System.out.println(query);
			rowsDeleted = statement.executeUpdate(query);
			System.out.println(rowsDeleted + " rows deleted.\n");
			if (rowsDeleted > 0) {
				Reporters.SuccessReport("Deleting records from credit_card_detail", "Successfully deleted " + rowsDeleted + " rows from credit_card_detail.");
			}
			else
				Reporters.failureReport("Deleting records from credit_card_detail", "Failed to delete any rows from credit_card_detail.");
			
			rs.close();
			statement.close();
			conn.close();
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
