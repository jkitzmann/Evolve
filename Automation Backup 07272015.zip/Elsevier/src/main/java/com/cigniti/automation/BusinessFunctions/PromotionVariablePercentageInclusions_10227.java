package com.cigniti.automation.BusinessFunctions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class PromotionVariablePercentageInclusions_10227 extends EvolveCommonBussinessFunctions{
	static org.openqa.selenium.Alert alert;

	//Validating Profit Center Section for Variable Percentage Inclusions
	public static boolean validateDifferentSection(String type,By xpath,String user,By comboBox, By addBtn, By percentField,String percentage1, String percentage2,By percFailMsg, 
			By sucMsg, By backgroundColor, By selectOption1,By selectOption2, By rmvLink, By anyTextField, 
			By percRowValue, By selectOptionFinal, By viewAllLink) throws Throwable{
		try{
			boolean flag=true;
			//click(ElsevierObjects.Evolve_Admin_Prmlnk_SelcallRdiobtn, "Check the checkbox");
			//isEnabled(ElsevierObjects.Evolve_Admin_Prmlnk_AddIncludeBtn, "Add Button is Enabled");
			String comboSize=getAttribute(comboBox, "size", "");
			System.out.println(comboSize);
			if(comboSize.contains("5")){
				Reporters.SuccessReport("Profit Centers shows 5", "Profit Centers shows 5");
			}else{
				Reporters.failureReport("Profit Centers shows 5", "Profit Centers shows 5");
			}			
			List<WebElement> selectOptionData=getElements(comboBox);
			for(WebElement option: selectOptionData){
				System.out.println(option.getText());
			}
			
			String [] Values1=new String[5];
			List<WebElement> selectOption=driver.findElements(xpath);
			for(int i =0;i<5;i++)
			{
			  Values1[i]=selectOption.get(i).getText();  	
			//	System.out.println(option.getText());
			}				
			verifysort(Values1);
			
			
			isElementPresent(percentField, "Percentage Field","<br>"+driver.getCurrentUrl());	
			isElementPresent(addBtn, "Add Button","<br>"+driver.getCurrentUrl());			
			
			//Validating the products...
			type(percentField, percentage1, "Enter the Percentage");
			Thread.sleep(medium);
			click(addBtn, "Click on add button");
			Thread.sleep(medium);
			String errMsg=getText(percFailMsg, "");
			if(verifyText(percFailMsg, "Please select product group to add to the promotion.", "Select one or more inclusions from  the Profit Center")){
				Reporters.SuccessReport("The Error Message Validation", "The Error message : "+errMsg+" is displayed");	
			}else{
				Reporters.failureReport("The Error Message Validation", "The Error message : "+errMsg+" is failed to display");
			}
			driver.findElement(percentField).clear();		
			click(selectOption1, "Select any Option ");
			click(addBtn, "Click on add button");
			Alert();
			Thread.sleep(medium);		
			//addProduct(ElsevierObjects.Evolve_Admin_Prmlnk_SelcOption,percentField, percentage , addBtn, 1);
			click(selectOption1, "Select any Option ");
			click(selectOption1, "Select any Option ");	
			driver.findElement(percentField).clear();	
			driver.findElement(By.xpath(".//*[@id='enddate']")).click();
			type(percentField, percentage1, "Enter the Percentage");
			click(addBtn, "Click on add button");	
			String addMsg=getText(sucMsg, "");
			if(verifyText(sucMsg, "The Promotion Inclusion is successfully saved. ", "Promotion Inclusions are successfully saved")){
				Reporters.SuccessReport("The Promotion Inclusion Message Validation", "The success message : "+addMsg+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Promotion Inclusion Message Validation", "The success message : "+addMsg+" is failed to display");
			}
			verifyBackGroundColor(backgroundColor);	
			
			isElementPresent(rmvLink, "Remove link", "<br>"+driver.getCurrentUrl());			
			//step 7			
			click(selectOption1, "Select any Option ");
			click(selectOption2, "Select any Option ");
			driver.findElement(percentField).clear();
			click(anyTextField, "");
			type(percentField, percentage2, "Enter the Percentage");
			click(addBtn, "Click on add button");
			if(verifyText(sucMsg, "The Promotion Inclusion is successfully saved. ", "Promotion Inclusions are successfully saved")){
				Reporters.SuccessReport("The Promotion Inclusion Message Validation", "The success message : "+addMsg+" is successfully displayed");	
			}else{
				Reporters.failureReport("The Promotion Inclusion Message Validation", "The success message : "+addMsg+" is failed to display");
			}
			verifyBackGroundColor(backgroundColor);
			String percentageValue=getText(percRowValue, "");

			if(percentageValue.contains(percentage1)){
				Reporters.SuccessReport("Validating the Previous percentage remains same or not", "The previously added inclusions is retained in original percentage off value.");
			}else{
				Reporters.failureReport("Validating the Previous percentage remains same or not", "The previously added inclusions changed their original percentage off value.");
			}
			List<WebElement> element=driver.findElements(rmvLink);
			int getSize=element.size();
			for (int i = 1; i < getSize+1; i++) {
				String row1=getText(By.xpath(ElsevierObjects.remove1+i+ElsevierObjects.remove2), "");
				//driver.findElement(By.xpath(ElsevierObjects.remove1+i+ElsevierObjects.remove2)).getText();
				System.out.println(row1);
				if(row1.contains("remove")){
					System.out.println(row1);
					Reporters.SuccessReport("Remove link", "Remove Link is present");
				}else{

					Reporters.failureReport("Remove link", "Remove Link is not present");
				}
			}
			//Step 8			
			click(rmvLink, "");
			Thread.sleep(medium);
			Alert();
			Thread.sleep(medium);
			click(rmvLink, "");
			Thread.sleep(medium);
			Alert();
			//Step 9
			flag=iterate(type,user,selectOptionFinal, percentField, percentage1, addBtn, sucMsg, percRowValue, rmvLink, 5, anyTextField);

			flag= validateViewAll(viewAllLink, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_ViewNewPageMsg, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, VerifyText3, "");

			return flag;			
		}catch(Exception e){return false;}
	}	



	//Add products
	public static boolean addProduct(By option, By percentageField, String percentage, By addBtn,  int size) throws Throwable{
		boolean flag=true;
		List<WebElement> data=driver.findElements(option);
		int length=data.size();
		for (int i = 0; i < size; i++) {
			String name=data.get(i).getText();
			click1(data.get(i), "");
			driver.findElement(percentageField).clear();
			driver.findElement(ElsevierObjects.Evolve_Admin_Prmlnk_EndDate).click();
			type(percentageField, percentage, "Enter the Percentage");
			click(addBtn, "Click on add button");		
		}
		return flag;
	}

	

	//Validating the products 
	public static boolean validateIncludeAllProducts() throws Throwable{

		try{
			boolean flag=true;
			click(ElsevierObjects.Evolve_Admin_Prmlnk_IncludeChk, "Check the checkbox");
			String alertMessage=alert.getText();
			Reporters.SuccessReport(alertMessage, "PopUp is present with the Message : " + alertMessage);
			alert.dismiss();
			if(isChecked(ElsevierObjects.Evolve_Admin_Prmlnk_IncludeChk, "")){
				Reporters.failureReport("promotion page with no changes made", "User is not taken back to promotion page with no changes made");				
			}else{
				Reporters.SuccessReport("promotion page with no changes made", "User is taken back to promotion page with no changes made");
			}
			click(ElsevierObjects.Evolve_Admin_Prmlnk_IncludeChk, "Check the checkbox");
			Alert();

			String AddDisabled=getAttribute(ElsevierObjects.Evolve_Admin_Prmlnk_AddIncludeBtn, "disabled", "Get the attribute value ");
			if(AddDisabled.contains("disabled")){
				Reporters.SuccessReport("Promotion Inclusions section is now grayed out/disabled. ", "The rest of the Promotion Inclusions section is now grayed out/disabled. ");
			}else{
				Reporters.failureReport("Promotion Inclusions section is now grayed out/disabled. ", "The rest of the Promotion Inclusions section Enabled. ");
			}
			verifyText(ElsevierObjects.Evolve_Admin_Prmlnk_SucMsgInclude, "All products have been included successfully. ", "Success Message is present");


			return flag;			
		}catch(Exception e){return false;}
	}

	/*public static boolean validateISBNSectionInclusion() throws Throwable{
		try{
			boolean flag=true;
			flag=PromotionVariablePercentageExclusions_15581.validateISBNSection("", ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExcludeTxtBox, 
					ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExludeBtn, 
					ElsevierObjects.Promotion_ExclusionVariable_ProISBNErrorMsg, ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExludeSucMsg,
					ElsevierObjects.Promotion_ExclusionVariable_ISBNAddList, ElsevierObjects.Promotion_ExclusionVariable_ISBNRem, 
					readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("InvalidISBN"));	

			flag= validateViewAll(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNViewall, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_ViewNewPageMsg, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, VerifyText3,"isbnIncExclusion");

			return flag;			
		}catch(Exception e){return false;}
	}*/
	
	public static boolean validateISBNSection() throws Throwable{
		try{
			boolean flag=true;
			flag=validateISBNSection("",ElsevierObjects.Evolve_Admin_Prmlnk_ISBNtxt, 
					ElsevierObjects.Evolve_Admin_Prmlnk_ISBNpercent, ElsevierObjects.Evolve_Admin_Prmlnk_ISBNAdd, 
					ElsevierObjects.Evolve_Admin_Prmlnk_ISBNErrMsg, ElsevierObjects.Evolve_Admin_Prmlnk_IncSucMsg,
					ElsevierObjects.Evolve_Admin_Prmlnk_ISBNAddList, ElsevierObjects.Evolve_Admin_Prmlnk_ISBNRem, 
					readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("InvalidISBN"), 
					readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("Percentage"));	

			/*flag= validateViewAll(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNViewall, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_ViewNewPageMsg, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, VerifyText3,"isbnIncExclusion");
*/
			return flag;			
		}catch(Exception e){return false;}
	}


	//Validating the ISBN Upload Section
	public static boolean uploadCSVFile() throws Throwable{
		boolean flag=true;

		flag=uploadCSVFile("",ElsevierObjects.Evolve_Admin_Prmlnk_ISBNBrowse, ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplPercent, 
				ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplBtn, ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplSucMsg);

		Thread.sleep(medium);
		return flag;
	}
	//Validating the ISBN Upload Section Type
	public static boolean uploadCSVSection(String invalidPercentage, String percentage) throws Throwable{
		try{
			boolean flag=true;
		String beforeRemove=getText(ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplbefore, "");
		click(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNViewall, "Click on viewAll Link");
		List<WebElement> items=driver.findElements(ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplList);
		int size=items.size();
		System.out.println(size);
		String verifyTxt=getText(ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplafter, "");
		click(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, "Click on CheckBox");
		click(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, "Click on remove button");
		Thread.sleep(medium);
		Alert();
		if(verifyTxt.contains(beforeRemove)){
			Reporters.failureReport("Data is "+beforeRemove+" Not Removed", "Data is "+beforeRemove+" not removed");
		}else{
			Reporters.SuccessReport("Data is successfully removed "+beforeRemove, "Data is successfully removed "+beforeRemove);
		}
		Thread.sleep(medium);
		String beforeRemove1=getText(ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplafter, "");
		System.out.println(beforeRemove1);
		Thread.sleep(medium);
		click(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, "Click on CheckBox");
		click(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, "Click on remove button");
		org.openqa.selenium.Alert alert;
		alert = driver.switchTo().alert();
		Thread.sleep(medium);
		alert.dismiss();
		String verifyTxt1=getText(ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplafter, "");
		if(verifyTxt1.contains(beforeRemove1)){
			Reporters.SuccessReport("Data is "+beforeRemove1+" Not Removed", "Data is "+beforeRemove1+" not removed");
		}else{
			Reporters.failureReport("Data is successfully removed "+beforeRemove1, "Data is successfully removed "+beforeRemove1);
		}
		click(ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, "Click on the Back button");
		click(ElsevierObjects.Evolve_Admin_Prmlnk_DscAdd, "Click on the add button next to Discount all other eligible items");
		Thread.sleep(medium);
		Alert();
		type(ElsevierObjects.Evolve_Admin_Prmlnk_DscAllOthr, invalidPercentage, "Enter the Value in the percentage field");
		click(ElsevierObjects.Evolve_Admin_Prmlnk_DscAdd, "Click on the add button next to Discount all other eligible items");
		Thread.sleep(medium);
		Alert();
		driver.findElement(ElsevierObjects.Evolve_Admin_Prmlnk_DscAllOthr).clear();
		driver.findElement(ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplPercent).click();
		type(ElsevierObjects.Evolve_Admin_Prmlnk_DscAllOthr, percentage, "Enter the Value in the percentage field");
		click(ElsevierObjects.Evolve_Admin_Prmlnk_DscAdd, "Click on the Add button");
		alert=driver.switchTo().alert();
		Thread.sleep(medium);
		alert.dismiss();

		driver.findElement(ElsevierObjects.Evolve_Admin_Prmlnk_DscAllOthr).clear();
		driver.findElement(ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplPercent).click();
		type(ElsevierObjects.Evolve_Admin_Prmlnk_DscAllOthr, percentage, "Enter the Value in the percentage field");
		click(ElsevierObjects.Evolve_Admin_Prmlnk_DscAdd, "Click on the Add button");
		Thread.sleep(medium);
		Alert();
		verifyText(ElsevierObjects.Evolve_Admin_Prmlnk_DscAddSucMsg, "All products have been included successfully. ", "Success Message is present");
		click(ElsevierObjects.Evolve_Admin_Prmlnk_DscAddRemLnk, "Click on the remove link");
		alert=driver.switchTo().alert();
		Thread.sleep(medium);
		alert.dismiss();
		isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_DscAddRow, "Element is present");
		String discountAllOtherEligibleItems=getText(ElsevierObjects.Evolve_Admin_Prmlnk_DscAddRow, "");
		System.out.println(discountAllOtherEligibleItems);
		String tabledata=getText(ElsevierObjects.Evolve_Admin_Prmlnk_DscAddRow, "");
		System.out.println(tabledata);
		click(ElsevierObjects.Evolve_Admin_Prmlnk_DscAddRemLnk, "Click on the remove link");
		Thread.sleep(medium);
		Alert();
		Thread.sleep(medium);
		
		if(tabledata.contains(discountAllOtherEligibleItems)){
			Reporters.SuccessReport("Element is removed", "element is removed successfully");
		}else{
			Reporters.failureReport("Element is not removed", "element is not removed");
		}
		/*if(isElementPresent(ElsevierObjects.Evolve_Admin_Prmlnk_DscAddRow, "")){
			Reporters.failureReport("Element is not removed", "element is not removed");
		}else{
			Reporters.SuccessReport("Element is removed", "element is removed successfully");
		}*/
		//isElementPresentNegCheck(ElsevierObjects.Evolve_Admin_Prmlnk_DscAddRow, "Element is not present");
		/*
		flag= validateViewAll(ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplViewall, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_ISBNViewNewPageMsg, 
				ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
				ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData , VerifyText5);			

		flag=validateUploadISBNSection(ElsevierObjects.Evolve_Admin_Prmlnk_ISBNUplViewall, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, 
				ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
				null, null);*/
		return flag;
	}catch(Exception e){System.out.println("error at "+e.getMessage());return false;}




	}
}
