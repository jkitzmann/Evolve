package com.cigniti.automation.BusinessFunctions;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Accessories;
import com.cigniti.automation.Utilities.Reporters;

public class Z_Create_LO_Unique_Course_15583 extends EvolveCommonBussinessFunctions{
	public static String EMAIL_ID ="";
	//Search Product.
	public static boolean searchProduct() throws Throwable{
		String product = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15583", configProps.getProperty("TestData")).get("Product"); 
		return LO_GlobalStudent_8571.searchProduct(product,null);
	}

	//Add product to Cart.
	public static boolean addProductToCart() throws Throwable{
		return LO_GlobalStudent_8571.addProductToCart(readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15583", configProps.getProperty("TestData")));
	}
	
	//Verify details in Confirm Order page.
	public static boolean confirmationOrder() throws Throwable{
		return confirmationOrder(readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15583", configProps.getProperty("TestData"))); 
	}
	
	//Search for Adoption Request.
	public static boolean searchAdoptionRequest() throws Throwable{
		Map<String, String> formMap = new HashMap<String, String>();
		//formMap.put("UserName", readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData")).get("UserName"));
		//formMap.put("SearchDate", readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15583", configProps.getProperty("TestData")).get("SearchDate"));
		return LO_GlobalCourse_9826.searchAdoptionRequest(formMap);
	}	

	/** Generic method for performing actions in Adoption Search Results page.
	 * 
	 * @param adoptionSearchdataMap
	 * @return
	 * @throws Throwable
	 */
	public static boolean adoptionSearchResults(Map<String,String> adoptionSearchdataMap) throws Throwable{
		flag = true;
		
		Thread.sleep(medium);
		
		//Click on email link in 'Adoption Search Results' page, to open 'Adoption Search Details' page.
		if(adoptionSearchdataMap.get("Email")!=null){
			String xpath = Accessories.fetchDynamicLocator(ElsevierObjects.Adoption_SearchResilts_Email.toString(), ElsevierObjects.ReplaceString1, adoptionSearchdataMap.get("Email"));
			if(!click(By.xpath(xpath), "Click on email link '"+adoptionSearchdataMap.get("Email")+"'.")){
				flag = false;
			}
		}
		return flag;
	}
	
	//Click on Email link.
	public static boolean adoptionSearchResults() throws Throwable{
		Map<String, String> formMap = new HashMap<String, String>();
		//formMap.put("Email", readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData")).get("Email"));
		return adoptionSearchResults(formMap);
	}

	//Verify the data in Adoption Request Details page.
	public static boolean verifyAdoptionRequestDetails() throws Throwable{
		boolean flag = true;
		Map<String, String> ardExpectedMap = new HashMap<String, String>();
		HashMap<String, String> ardActualMap = new HashMap<String, String>();
		By by = ElsevierObjects.AdoptionRequestDetails_TABLE;

		Map<String, String> userCredTestDataMap = readcolumns.twoColumnsBasedOnSheetName(0, 1, "DynamicCredentials", configProps.getProperty("TestData"));
		Map<String, String> userDetailsTestDataMap = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-8571 & 9826", configProps.getProperty("TestData"));
		Map<String, String> userProdDetailsTestDataMap = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15583", configProps.getProperty("TestData"));

		//Capture expected results from testdata.
		ardExpectedMap.put("UserName", userCredTestDataMap.get("UserName"));
		ardExpectedMap.put("Password", userCredTestDataMap.get("Password"));
		ardExpectedMap.put("FirstName", userDetailsTestDataMap.get("FirstName"));
		ardExpectedMap.put("LastName", userDetailsTestDataMap.get("LastName"));
		ardExpectedMap.put("InstutionName", userDetailsTestDataMap.get("InstutionName"));
		ardExpectedMap.put("PhoneNumber", userDetailsTestDataMap.get("PhoneNumber"));
		ardExpectedMap.put("Format", userProdDetailsTestDataMap.get("Format"));
		ardExpectedMap.put("ProjectedCourseEnrollment", userProdDetailsTestDataMap.get("ProjectedCourseEnrollment"));
		
		ardExpectedMap.put("Email", StdEmail);
		ardExpectedMap.put("CountrySelected", userDetailsTestDataMap.get("CountrySelected"));
		ardExpectedMap.put("CountrySelected", userDetailsTestDataMap.get("CountrySelected"));
		ardExpectedMap.put("ISBN", userProdDetailsTestDataMap.get("Product"));
		ardExpectedMap.put("ProductTitle_Edition", userProdDetailsTestDataMap.get("ProductTitle_Edition"));
		ardExpectedMap.put("Author", userProdDetailsTestDataMap.get("Author"));
		ardExpectedMap.put("Comment", userProdDetailsTestDataMap.get("Comment"));
		
		//Capture actual results from test data.
		ardActualMap.put("UserName", getTableTD(by,11,2).getText());
		ardActualMap.put("Password", getTableTD(by,12,2).getText());
		ardActualMap.put("FirstName", getTableTD(by,14,2).getText());
		ardActualMap.put("LastName", getTableTD(by,15,2).getText());
		ardActualMap.put("InstutionName", getTableTD(by,17,2).getText());
		ardActualMap.put("PhoneNumber", getTableTD(by, 22, 2).getText());
		ardActualMap.put("CountrySelected", getTableTD(by, 19, 2).getText());
		ardActualMap.put("Format", getTableTD(by,5,2).getText());
		
		//Captures only number
		String pce = getTableTD(by,8,1).getText();
		pce = pce.replaceAll(".*?(\\d+).*", "$1");
		ardActualMap.put("ProjectedCourseEnrollment", pce);
		
		WebElement emailTable = getTableTD(by,25,1).findElement(By.tagName("table"));
		ardActualMap.put("Email", getTableTD(emailTable, 2, 1).getText());

		List<WebElement> prodDetails = getTableTD(by, 1, 1).findElements(By.tagName("div"));
		ardActualMap.put("ProductTitle_Edition", prodDetails.get(1).getText());
		ardActualMap.put("ISBN", prodDetails.get(5).getText());
		ardActualMap.put("Author", prodDetails.get(3).getText());
		

		//Capture comment
		String comment = getTableTD(by,7,1).findElements(By.tagName("div")).get(1).getText();
		ardActualMap.put("Comment", comment);
		
		String[] verifyArr = new String[]{"UserName", "Password", "FirstName", "LastName", "InstutionName", "Email",
				"PhoneNumber", "CountrySelected", "ProductTitle_Edition", "ISBN", "Author", "Format"};
		
		for(String verifyString : verifyArr){
			if(ardExpectedMap.get(verifyString).trim().equalsIgnoreCase(ardActualMap.get(verifyString).trim())){
				Reporters.SuccessReport("Display "+verifyString, "Successfully displayed "+verifyString);
			}else{
				flag = false;
				Reporters.failureReport("Display "+verifyString, "Failed to display "+verifyString);
			}
		}
		
		String expectedDefaultValue = userProdDetailsTestDataMap.get("DefaultRequestStatus");
		String actualDefaultValue = getFirstSelectedOption(ElsevierObjects.AdoptionRequestDetails_RequestStatus, "Fetch default value from dropdown");
		if(!expectedDefaultValue.equalsIgnoreCase(actualDefaultValue)){
			flag = false;
		}
		
		return flag;
	}
	
	/** Updates request status in 'Adoption Request Details' page.
	 * 
	 * @return
	 * @throws Throwable 
	 */
	public static boolean updateARD_RequestStatus(Map<String, String> reqMap) throws Throwable{
		if(reqMap == null){
			return false;
		}
		Thread.sleep(low);
		//Update request status.
		if(reqMap.get("RequestStatusToUpdate")!=null){
			if(!selectByVisibleText(ElsevierObjects.AdoptionRequestDetails_RequestStatus, reqMap.get("RequestStatusToUpdate"), "Update request status")){
				flag = false;
			}			
		}

		Thread.sleep(low);
		//Click on Save button
		if(reqMap.get("ClickSaveButton")!=null && reqMap.get("ClickSaveButton").equalsIgnoreCase("yes")){
			if(!click(ElsevierObjects.AdoptionRequestDetails_SaveButton, "Click on Save button")){
				flag = false;
			}			
		}
		
		Thread.sleep(low);
		//Verify the title in dialog.
		if(reqMap.get("EmailSelectionDialogTitle")!=null){
			if(!reqMap.get("EmailSelectionDialogTitle").equalsIgnoreCase(getText(ElsevierObjects.AdoptionRequestDetails_EmailSelectionDialog_Title, "Fetch title"))){
				flag = false; 
			}			
		}
		
		Thread.sleep(low);
		//Click on 'Send Email' button.
		if(reqMap.get("ClickSendEmailButton")!=null && reqMap.get("ClickSendEmailButton").equalsIgnoreCase("yes")){
			if(!click(ElsevierObjects.AdoptionRequestDetails_SendEmailButton , "Click on 'Send Email button'")){
				flag = false;
			}
		}
		
		Thread.sleep(medium);
		String expectedDefaultValue = reqMap.get("RequestStatusToUpdate");
		String actualDefaultValue = getFirstSelectedOption(ElsevierObjects.AdoptionRequestDetails_RequestStatus, "Fetch default value from dropdown");
		if(expectedDefaultValue.equalsIgnoreCase(actualDefaultValue)){
			flag = false;
		}
		
		Thread.sleep(low);
		if(reqMap.get("ValidateCourseId")!=null && reqMap.get("ValidateCourseId").equalsIgnoreCase("yes")){
			if(!(getAttribute(ElsevierObjects.AdoptionRequestDetails_CourseId, "value", "Fetch course id's").trim().length()>0)){
				flag = false;
			}			
		}
		EvolveCommonBussinessFunctions.courseID1 = driver.findElement(ElsevierObjects.adoptionRequestCourseId1).getAttribute("value");
		return flag;
	}

	public static boolean updateARD_RequestStatus() throws Throwable{
		Map<String, String> userProdDetailsTestDataMap = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15583", configProps.getProperty("TestData"));
		
		Map<String, String> reqMap = new HashMap<String, String>();
		reqMap.put("RequestStatusToUpdate", userProdDetailsTestDataMap.get("RequestStatusToUpdate"));
		reqMap.put("ClickSaveButton", "yes");
		reqMap.put("EmailSelectionDialogTitle", userProdDetailsTestDataMap.get("EmailSelectionDialogTitle"));
		reqMap.put("ClickSendEmailButton", "yes");
		reqMap.put("ValidateCourseId", "yes");
		
		return updateARD_RequestStatus(reqMap);
	}
	
	public static boolean updateRequestStatus() throws Throwable{
		flag = true;
		Map<String, String> userDetailMap = readcolumns.twoColumnsBasedOnSheetName(0, 1, "DefaultRequestStatus", configProps.getProperty("TestData"));
		
		//Verify Default Request Status
		if(userDetailMap.get("DefaultRequestStatus")!=null){
				if(!userDetailMap.get("DefaultRequestStatus").trim().equalsIgnoreCase(getFirstSelectedOption(ElsevierObjects.AdoptionRequestDetails_RequestStatus, "Fetch selected value.").trim())){
					flag=false;
				}
		}
		
		//Update Request Status.
		if(userDetailMap.get("RequestStatusToUpdate")!=null){
			if(!selectByVisibleText(ElsevierObjects.AdoptionRequestDetails_RequestStatus, userDetailMap.get("RequestStatusToUpdate"), "Update request status.")){
				flag = false;
			}
		}

		if(!click(ElsevierObjects.AdoptionRequestDetails_SaveButton, "Click on Save button.")){
			flag = false;
		}
		
		return flag;
	}
	
}
