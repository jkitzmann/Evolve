package com.cigniti.automation.Test;

import jxl.Sheet;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;

import com.cigniti.automation.BusinessFunctions.LOUniqueCourseFulfillmentfromSearchResultsPage_LO_15100;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentFaculty_15243;
import com.cigniti.automation.BusinessFunctions.LO_Global_Instructor_AR_8572;
import com.cigniti.automation.BusinessFunctions.LO_Unique_CourseFulfillment_Faculty_10410;
import com.cigniti.automation.BusinessFunctions.LO_Unique_CourseFulfillment_Faculty_15586;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class LOUniqueCourseFulfillmentfromSearchResultsPage_LO_Script_15100 extends LOUniqueCourseFulfillmentfromSearchResultsPage_LO_15100{
	public static Sheet inputSheetObj =null;
	public static String facultyUser;
	public static String facultyPwd;
	public static String facultyUserName;
	public static String facultyPassword;
	public static String productCost=ExpectedPrice;
	public static String course;
	
	@Test 
	public void loUniqueCoursefulfillmentFacultyfromSearchResultsPage_LO_15100() throws Throwable{
		try
		{
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			String evolve="true";
			String lmsvalue=null;
			
	//	evolveContent=ReadingExcel.columnDataByHeaderName("content", "TC-10410", configProps.getProperty("TestData"));
		product=ReadingExcel.columnDataByHeaderName("searchNumber", "TC-10410", configProps.getProperty("TestData"));
		String format_LO=ReadingExcel.columnDataByHeaderName("format_LO", "TC-10410", configProps.getProperty("TestData"));
		String statusAfterEmailSent=ReadingExcel.columnDataByHeaderName("verifyStatusAfterEmailSent", "TC-10410", configProps.getProperty("TestData"));
		String productId=ReadingExcel.columnDataByHeaderName("productID", "TC-10410", configProps.getProperty("TestData"));
		//courseLink=ReadingExcel.columnDataByHeaderName("courseLnik","TC-10410" ,configProps.getProperty("TestData"));
		//String IdLength=ReadingExcel.columnDataByHeaderName("length", "TC-10410", configProps.getProperty("TestData"));
		comment=null;

		//courseLink=ReadingExcel.columnDataByHeaderName("courseLnik","TC-10410" ,configProps.getProperty("TestData"));
		//String format_LO=ReadingExcel.columnDataByHeaderName("format_LO", "TC-10410", configProps.getProperty("TestData"));

		
		product=ReadingExcel.columnDataByHeaderName("searchNumber", "TC-10410", configProps.getProperty("TestData"));
		String user="educator";
		facultyUser=ReadingExcel.columnDataByHeaderName("Faculty_User", "TC-10410", configProps.getProperty("TestData"));
		facultyPwd=ReadingExcel.columnDataByHeaderName("Faculty_passWord", "TC-10410", configProps.getProperty("TestData"));
		
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		writeReport(EvolveCommonBussinessFunctions.existingUserLogin(user,facultyUser,facultyPwd),"Login to Application Using User Credentials",
																							   	  "Launching the URL for User is successfull </br > Login to Application Using User Credentials :"+facultyUser+" is Successful",
																								  "Launching and Login to Application Using User Credentials : "+ facultyUser+" is Failed");
		writeReport(EvolveCommonBussinessFunctions.getAccountDetails(),"Fetching Account Details from My Account.",
								   "Successfully Fetched account details from My Account page.",
								   "Failed to Fetch the account details from My Account page.");
		writeReport(EvolveCommonBussinessFunctions.searchProduct(product,productCost),"Serach for the product..",
								  "Successfully Entered ISBN:"+product+" in Search Box.</br>Clicked On Go Button.</br>Navigated To Product Details Page.",
								  "Failed to Enter ISBN:"+product+" in Search Box.");
		writeReport(EvolveCommonBussinessFunctions.requestProduct(),"Clicking on the Request Product Button In Product Details Page.",
									"Successfully clicked on Request Product Button.",
									"Failed to click on Request Product Button.");
		writeReport(EvolveCommonBussinessFunctions.hostedAfterRequestPopUp(),"Switching to Course Configuration Popup in Request Product page.",
									 "Successfully switched to Course Configuration Popup in Request Product page.",
									 "Failed to switch to Course Configuration Popup in Request Product page.");
		
		evolveContent=ReadingExcel.columnDataByHeaderName("content", "TC-10410", configProps.getProperty("TestData"));
		comment="";
		enrollment="";
		writeReport(EvolveCommonBussinessFunctions.evolveContentInPopUp(evolveContent,comment,enrollment),"Entering Evolve Content In Course Configuration Popup.",
											"Successfully entered evolve content in Course Configuration Popup.</br>Clicked On Apply Button In Popup.</br>Navigated To Mycart Page.",
											"Failed to enter evolve content in Course Configuration Popup.</br>Failed To click On Apply Button In Popup.</br>Failed To Navigate To Mycart Page.");
		EvolveCommonBussinessFunctions.hostedMycart(lmsvalue,evolve);
		System.out.println();
		searchTrial="false";
		String TrialLink="";
		LO_Unique_CourseFulfillment_Faculty_10410.userReviewSubmit(searchTrial,TrialLink);
		String lmsTextLO=EvolveCommonBussinessFunctions.lmsText;
		LO_Unique_CourseFulfillment_Faculty_10410.receiptPage(searchTrial,TrialLink);
		writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the educator page.", 
						"Successfully logged out the educator:"+facultyUser, 
						"Failed to logout the educator page:"+facultyUser);
		
		SwitchToBrowser("chrome");
		writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Login In Into Evolve Email Page.", 
						  "Successfully login into Evole Email Page.", 
						  "Failed to login into Evolve Email Page.");
		String emailid=EvolveCommonBussinessFunctions.getAccountDetailsEmail;
		writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(emailid),"Search email in evolve webmail.",
							"Successfully entered the emailid "+emailid+" in search box.",
							"Failed to enter email id.");
		String emailTitle=ReadingExcel.columnDataByHeaderName("emailTitle", "TC-10410", configProps.getProperty("TestData"));

		verifyTitleInEmailBody(emailTitle);
		
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login to Application Using Admin Credentials :"+adminUser,
				"Launching the URL for Admin is successful </br > Login to Application Using Admin credentials :"+adminUser+" is Successful", 
				"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");
		LO_Global_Instructor_AR_8572.admin_Adoptionsearch();
	
		/*writeReport(EvolveCommonBussinessFunctions.clickAdoptionRequest(),"Click on Search Adoption request link in Admin page.",
																		  "Successfully clicked on Search Adoption request link.",
				  														  "Failed to click on Search Adoption request link.");*/
		trial="false";
		LO_Global_Instructor_AR_script_8572.check_Approvedstatus(trial);
		writeReport(EvolveCommonBussinessFunctions.getAdoptionRequestDetails(),"Clicking On Adoption Number.</br>Fetching Adoption Details of User and Course in Adoption Request Details page",
				   "Adoption Number:"+adoptionRequest_getAdoptionNum+" is On Top Of The Row.</br>Successfully Clicked On "+adoptionRequest_getAdoptionNum+"</br>Successfully Fetched the details of User And Course from Adoption Request Details Page.",
				   "Failed To Click On Adoption Number:"+adoptionRequest_getAdoptionNum+"</br>Failed to Fetch the details of User And Course from Adoption Request Details Page.");
		writeReport(LOUniqueCourseFulfillmentfromSearchResultsPage_LO_15100.searchResultVerifyLOStatusInARPage(format_LO,facultyUser,facultyPwd),"Verify User and course details in Adoption Request Details page."
																						,"Successfully verified the User and Course details in Adoption Request Details Page.",
																						"Failed to verify the User and Course details in Adoption Request Details Page.");	
		LOUniqueCourseFulfillmentfromSearchResultsPage_LO_15100.getCourseId(statusAfterEmailSent,productId,facultyUser);
		Thread.sleep(high);
		writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout.", 
																  "Successfully logged out admin page.", 
																  "Failed to logout admin page");
		
		SwitchToBrowser("chrome");
		writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Login In Into Evolve Email Page.", 
				  "Successfully login into Evole Email Page.", 
				  "Failed to login into Evolve Email Page.");
	//	String emailid=EvolveCommonBussinessFunctions.getAccountDetailsEmail;
		writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(emailid),"Search email in evolve webmail.",
					"Successfully entered the emailid "+emailid+" in search box.",
					"Failed to enter email id.");
		String EmailTitle=ReadingExcel.columnDataByHeaderName("emailOnlineTitle", "TC-10410", configProps.getProperty("TestData"));

		verifyTitleInEmailBody(EmailTitle);
		
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		facultyUserName=ReadingExcel.columnDataByHeaderName("Faculty_User", "TC-10410", configProps.getProperty("TestData"));
		facultyPassword=ReadingExcel.columnDataByHeaderName("Faculty_passWord", "TC-10410", configProps.getProperty("TestData"));
		writeReport(LO_Unique_CourseFulfillment_Faculty_10410.reLogin(facultyUserName, facultyPassword),  "Login to Application Using User Credentials",
																							    	"Launching the URL for User is successful </br > Login to Application Using User credentails :"+facultyUserName+" is Successful",
																							    	"Launching and Login to Application Using User credentails : "+ facultyUserName+" is Failed");
		String ID1="true";
		String ID2="false";
		writeReport(LO_Unique_CourseFulfillment_Faculty_10410.courseIDSearch(ID1,ID2),"Verify course ID's generated in Admin page are in Educator page or not.",
																		  "Successfully verified CourseId "+courseID1+". </br> Clicked on "+courseID1+".", 
																		  	"Failed to verify CourseId "+courseID1);
		/*writeReport(LO_Unique_CourseFulfillment_Faculty_15586.courseDetailsPage(),"Verify Course details in Course Details page.",
																			"Successfully verified all course details. </br> Succesfully get the protection scheme id.",
																			"Failed to verify all course details.");	*/
		
		writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the educator page.", 
				"Successfully logged out the educator:"+facultyUserName, 
				"Failed to logout the educator page:"+facultyUserName);
		writeReport(LO_Unique_CourseFulfillment_Faculty_10410.reLogin(facultyUserName, facultyPassword),  "Login to Application Using User Credentials",
		    	"Launching the URL for User is successful </br > Login to Application Using User credentails :"+facultyUserName+" is Successful",
		    	"Launching and Login to Application Using User credentails : "+ facultyUserName+" is Failed");
		writeReport(LO_Unique_CourseFulfillment_Faculty_10410.courseIDSearch(ID1,ID2),"Verify course ID's generated in Admin page are in Educator page or not.",
				  "Successfully verified CourseId "+courseID1+". </br> Clicked on "+courseID1+".", 
				  	"Failed to verify CourseId "+courseID1);
		
		searchTrial="false";
		LO_Unique_CourseFulfillment_Faculty_10410.courseDetailsPage(searchTrial);
		
		writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the educator page.", 
				"Successfully logged out the educator:"+facultyUserName, 
				"Failed to logout the educator page:"+facultyUserName);
		
		}
		catch (Exception e)
		 {
			System.out.println(e.getMessage());
		 }

	}

@AfterTest
public void tear() throws Throwable{
	/*HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
	Base.tearDown();*/
}
}