package com.cigniti.automation.Test;


import java.util.Map;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.AccessCodePackageCreation_10214;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.Sample10214Business;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.datadriven.ReadResourceData;

public class Sample10214 extends Sample10214Business{
	//public static Map<String, String> TC10214_RETESTING=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-10214_RETESTING", configProps.getProperty("TestData"));
	ReadingExcel r=new ReadingExcel();
	
	@Test
	public void accessCodePackageCreation_10214() throws Throwable{

	try{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		String isbn1=ReadingExcel.getCell(1, 0, testDataPath, "TC-10214_RETESTING");
		String isbn2=ReadingExcel.getCell(2, 0, testDataPath, "TC-10214_RETESTING");
		String isbn3=ReadingExcel.getCell(3, 0, testDataPath, "TC-10214_RETESTING");
		String isbn4=ReadingExcel.getCell(4, 0, testDataPath, "TC-10214_RETESTING");
		String isbn5=ReadingExcel.getCell(5, 0, testDataPath, "TC-10214_RETESTING");
		
		isbnVerify("TC-10214_RETESTING_Details",isbn1, 0, 1, 2, 1);
		isbnVerify("TC-10214_RETESTING_Details",isbn2, 3, 4, 5, 1);
		isbnVerify("TC-10214_RETESTING_Details",isbn3, 6, 7, 8, 1);
		isbnVerify("TC-10214_RETESTING_Details",isbn4, 9, 10, 11, 1);
		isbnVerify("TC-10214_RETESTING_Details",isbn5, 12, 13, 14, 1);
		
		
		
		//String str=readcolumns.twoColumns(0, 1, "TC-10214", configProps.getProperty("TestData")).get("ISBNPkgName");
		
		String str=ReadingExcel.keyValueBasedOnCommonValue(testDataPath, "GenericValue", 0, 1, 2, "TC-10214").get("ISBNPkgName");
		System.out.println(str);
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),ReadResourceData.getResourceData("TC-10214-1", configProps.getProperty("AdminUser")),
				ReadResourceData.getResourceData("TC-10214-2", configProps.getProperty("AdminUser")),
				ReadResourceData.getResourceData("TC-10214-3", configProps.getProperty("AdminUser")));
		
		//accessCodePackage;
		writeReport(AccessCodePackageCreation_10214.accessCodePackage(),ReadResourceData.getResourceData("TC-10214-4", "NA"),
				ReadResourceData.getResourceData("TC-10214-5","NA"),
				ReadResourceData.getResourceData("TC-10214-6", "NA"));
		
		
		writeReport(AccessCodePackageCreation_10214.verifyCreatePackage(str),ReadResourceData.getResourceData("TC-10214-7", "NA"),
				ReadResourceData.getResourceData("TC-10214-8", "NA"),
				ReadResourceData.getResourceData("TC-10214-9", "NA"));
		
		
		writeReport(AccessCodePackageCreation_10214.verifyPackageNametxtBox(),ReadResourceData.getResourceData("TC-10214-10", "NA"),
				ReadResourceData.getResourceData("TC-10214-11", "NA"),
				ReadResourceData.getResourceData("TC-10214-12", "NA"));
		
		writeReport(AccessCodePackageCreation_10214.verifyISBNPackage(),ReadResourceData.getResourceData("TC-10214-13", "NA"),
				ReadResourceData.getResourceData("TC-10214-14", "NA"),
				ReadResourceData.getResourceData("TC-10214-15", "NA"));
		
		
		 writeReport(EvolveCommonBussinessFunctions.adminLogout(),ReadResourceData.getResourceData("TC-10214-16", "NA"),
				 ReadResourceData.getResourceData("TC-10214-17", "NA"),
				 ReadResourceData.getResourceData("TC-10214-18", "NA"));
		 
	}catch(Exception e){
		System.out.println(e.getMessage());
	}
	
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
	
}
