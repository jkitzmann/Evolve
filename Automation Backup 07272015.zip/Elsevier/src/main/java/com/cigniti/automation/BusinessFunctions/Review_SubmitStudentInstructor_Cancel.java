package com.cigniti.automation.BusinessFunctions;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;


public class Review_SubmitStudentInstructor_Cancel  extends EvolveCommonBussinessFunctions{

	public static String paperback_price;	
	public static String estimated_tax;
	public String isbn;
	public String evolveEmail;
	public String evolveStudentEmail;
	public static String titleInReviewSubmit;
	
	//Common Methods for test Cases Review&Submit Instructor Cancel
	public static boolean checkCart(String user, String reviewAndSubmit) throws Throwable{
		boolean flag = true;
		try{
			/*Thread.sleep(medium);
			if(!clickOnMainPageLink()){
				flag=false;
			}*/
			Thread.sleep(medium);
			if(user .equalsIgnoreCase("educator")){
				if(launchUrl(configProps.getProperty("URL3"))){ 
					Reporters.SuccessReport("Launch evolvecert.elsevier.com", "Successfully Launched evolvecert.elsevier.com");
				}else{
					Reporters.failureReport("Launch evolvecert.elsevier.com", "Failed to Launch evolvecert.elsevier.com");
				}
				 
			}else{
				if(launchUrl(configProps.getProperty("URL4"))){ 
					Reporters.SuccessReport("Launch evolvecert.elsevier.com", "Successfully Launched evolvecert.elsevier.com");
				}else{
					Reporters.failureReport("Launch evolvecert.elsevier.com", "Failed to Launch evolvecert.elsevier.com");
				}
				 
			}

			if(reviewAndSubmit .equalsIgnoreCase("false")){
				if(!javaClick(ElsevierObjects.clickOnCart, "Clicked on Cart Icon")){
					flag = false;
				}Thread.sleep(low); 
			}

			if(!click(ElsevierObjects.login, "login link")){
				flag = false;
			}Thread.sleep(low);
			String educatorUsername=ReadingExcel.columnDataByHeaderName("InstructorName", "ReviewAndSubmit",configProps.getProperty("TestData"));
			String educatorPassword=ReadingExcel.columnDataByHeaderName("MailpassWord", "ReviewAndSubmit",configProps.getProperty("TestData"));
			String studentUsername=ReadingExcel.columnDataByHeaderName("Student", "ReviewAndSubmit",configProps.getProperty("TestData"));
			String studentPassword=ReadingExcel.columnDataByHeaderName("StudentPassword", "ReviewAndSubmit",configProps.getProperty("TestData"));
			if(user .equalsIgnoreCase("educator")){				
				if(type(ElsevierObjects.email,educatorUsername,"Email")){
					Reporters.SuccessReport("Input the Existing Instructor Username", "Successfully Entered the Existing instructor username : "+educatorUsername);
				}else{
					Reporters.failureReport("Input the Existing Instructor Username", "Successfully Entered the Existing instructor username : "+educatorUsername);
				}
				if(type(ElsevierObjects.password,educatorPassword, "password")){
					Reporters.SuccessReport("Input the Existing Instructor Password", "Successfully Entered the Existing instructor Password : "+educatorPassword);
				}else{
					Reporters.failureReport("Input the Existing Instructor Password", "Successfully Entered the Existing instructor Password : "+educatorPassword);
				}
			}else{
				if(type(ElsevierObjects.email,studentUsername,"Email")){
					Reporters.SuccessReport("Input the Existing Student Username", "Successfully Entered the Existing Student username : "+studentUsername);
				}else{
					Reporters.failureReport("Input the Existing Student Username", "Successfully Entered the Existing Student username : "+studentUsername);
				}
				if(type(ElsevierObjects.password,studentPassword, "password")){
					Reporters.SuccessReport("Input the Existing Student Password", "Successfully Entered the Existing Student Password : "+studentPassword);
				}else{
					Reporters.failureReport("Input the Existing Student Password", "Successfully Entered the Existing Student Password : "+studentPassword);
				}
			}
Thread.sleep(medium);
			if(click(ElsevierObjects.submit, "login submit")){
				Reporters.SuccessReport("Log into Application is successful", "Successfully logged into the application as Existing user credentials");
			}else{
				Reporters.failureReport("Log into Application is successful", "Failed to log into the application as Existing user credentials");
			}
			Thread.sleep(high);
			click(ElsevierObjects.Catalog_Header_Link, "Click on Catalog");
			//Thread.sleep(medium);
			Thread.sleep(medium);
		}catch(Exception e){
			System.out.println(sgErrMsg="Error message");return false;
		}
		return flag;
	}

	//Search and Products to cart and Checkouts...
	public static boolean searchAndAddproduct(String reviewAndSubmit,String searchData) throws Throwable{
		boolean flag = true;
		try{
			if(reviewAndSubmit .equalsIgnoreCase("false")){
				//typeAndSearch();
				searchAndGo(searchData);
				addSingleProduct("", ElsevierObjects.paperbackPrice,ElsevierObjects.paperback_click);
			}

			if(reviewAndSubmit .equalsIgnoreCase("true")){
				if(!click(ElsevierObjects.Catalog_Header_Link, "Click on Catalog")){
					flag=false;
				}
			}
			if(reviewAndSubmit .equalsIgnoreCase("true")){
				searchAndGo(searchData);
				//typeAndSearch();
				addSingleProduct("",ElsevierObjects.paperbackPrice,ElsevierObjects.paperback_click);
				if(!click(ElsevierObjects.Catalog_Header_Link, "Click on Catalog")){
					flag=false;
				}
				searchAndGo(searchData);
				//typeAndSearch();
				String user="iteration2";
				addSingleProduct(user, ElsevierObjects.paperbackPrice2 ,ElsevierObjects.paperback_click2 );

			}
			String itemsInCart=getText(ElsevierObjects.itemInCart, "");
			if(isElementPresent(ElsevierObjects.itemInCart, "Item is added to cart")){
				Reporters.SuccessReport("Item added to cart.", "Title of item: "+itemsInCart);
			}else{
				Reporters.failureReport("Item added to cart.", "Title of item: "+itemsInCart);
			}
			Thread.sleep(medium);
			if(javaClick(ElsevierObjects.checkout, "Redeem Checkout")){
				Reporters.SuccessReport("Click on redeem/checkout.", "Successfully clicked on the redeem/checkout button <br>User is Successfully taken to Review & Submit page.");
			}else{
				Reporters.failureReport("Click on redeem/checkout.", "Failed to click on the redeem/checkout button<br>User is not taken to Review & Submit page.");
			}
		}catch(Exception e){
			System.out.println(sgErrMsg="Error message");return false;
		}
		return flag;		
	}

	public static boolean validteReviewPage()throws Throwable{
		boolean flag = true;
		try{
			Thread.sleep(medium);

			String reviewAndSub=getText(ElsevierObjects.reviewAndSubmit, "Get the value review and submit to a string");
			if(reviewAndSub.contains("2. REVIEW & SUBMIT")){
				Reporters.SuccessReport("The REVIEW & SUBMIT page is presented", "The REVIEW & SUBMIT page is successfully displayed");
			}else{
				Reporters.failureReport("The REVIEW & SUBMIT page is not present", "The REVIEW & SUBMIT page is failed to display");
			}
			String titleOfProduct=getText(ElsevierObjects.itemTitle, "");
			if(titleOfProduct!=null){
				Reporters.SuccessReport("Verify the item is displayed in the cart", "Item is displayed in the cart <br> The title of the product added to the cart: "+titleOfProduct);
			}else{
				Reporters.failureReport("Verify the item is displayed in the cart", "Item is not displayed in the cart <br> The title of the product added to the cart: "+titleOfProduct);
			}
			String cancelOrder=getText(ElsevierObjects.cancleOrder, "");
			if(cancelOrder!=null){
				Reporters.SuccessReport("Validate the Cancel Order Link", "The Cancel Order Link is present on the page<br> The Link is : "+cancelOrder);
			}else{
				Reporters.failureReport("Validate the Cancel Order Link", "The Cancel Order Link is not present on the page<br> The Link is : "+cancelOrder);
			}

		}catch(Exception e){
			System.out.println(sgErrMsg="Error occured due to exception");return false;
		}
		return flag;
	}
	/* //type and search for paperback
	 public static boolean typeAndSearch() throws Throwable{
		 boolean flag = true;

		 	if(!type(ElsevierObjects.txtproductsearch,readcolumns.twoColumnsBasedOnSheetName(0, 1, "ReviewAndSubmit", configProps.getProperty("TestData")).get("searchPaperback"), "text to search")){
				flag = false;
			}
			if(!click(ElsevierObjects.gobutton, "search button")){
				flag = false;
			}

		 return flag;
	 }*/

	//adds Single Product to cart
	public static boolean addSingleProduct(String user, By Price, By Paperback) throws Throwable{
		boolean flag = true;
		try{	

			paperback_price = getText(Price, "Price of paperback.");
			if(paperback_price != "$0.00"){
				Reporters.SuccessReport("Validate the price of the product is greater than 0", "The Product price is greater than $0 and has a product type of Paperback. <br> The product price is : "+paperback_price);
				Thread.sleep(medium);
				if(!click(Paperback, "Clicked On PaperBack.")){
					flag = false;
				}
			}else{
				Reporters.failureReport("Validate the price of the product is greater than 0", "The Product price is not greater than $0 and has a product type of Paperback. <br> The product price is : "+paperback_price);
			}
			Thread.sleep(medium);
			String title=getText(ElsevierObjects.marketingPageSinglePercentage_Title, "Get the title of the Book");
			System.out.println(title);

			String ISBN=getText(ElsevierObjects.marketingPageSinglePercentage_ISBN, "Get the ISBN Value for future Use");
			System.out.println(ISBN);

			String price=getText(ElsevierObjects.marketingPageSinglePercentage_Price, "Get the Price of the Book");
			System.out.println(price);

			if(javaClick(ElsevierObjects.btnaddtocart, "Added to Cart..")){
				Reporters.SuccessReport("Click on Add to Cart Button", "The product is Successfully added to the cart");
			}else{
				Reporters.failureReport("Click on Add to Cart Button", "The product is failed to add to the cart");
			}
			if(user.equalsIgnoreCase("iteration2")){
				List<WebElement> titles=driver.findElements(ElsevierObjects.itemTitle);
				//String titleOfProduct=getText(ElsevierObjects.itemTitle, "");
				System.out.println(titles.get(1).getText());
				int flag1=1;
				/*for (int i = 0; i < titles.size(); i++) {
					if(titles.get(i).getText().contains(title)){
						Reporters.SuccessReport("Validate the title", "The title in the page is verified successfully. <br> The title on the page : "+title+"<br> The title in the review and submit page : "+titles.get(1).getText());
					}else{
						Reporters.failureReport("Validate the title", "The title in the page is failed to verify. <br> The title on the page : "+title+"<br> The title in the review and submit page : "+titles.get(1).getText());
					}
				}
				if(titles.get(1).getText().contains(title)){
					Reporters.SuccessReport("Validate the title", "The title in the page is verified successfully. <br> The title on the page : "+title+"<br> The title in the review and submit page : "+titles.get(1).getText());
				}else{
					Reporters.failureReport("Validate the title", "The title in the page is failed to verify. <br> The title on the page : "+title+"<br> The title in the review and submit page : "+titles.get(1).getText());
				}*/
				for(int i=0;i<titles.size();i++)
				{
				if(titles.get(i).getText().contains(title))
				{flag1=1;
				break;}
				else
				{flag1=0;}
				}
				if(flag1==1)
				{
					Reporters.SuccessReport("Validate the title", "The title in the page is verified successfully. <br> The title on the page : "+title+"<br> The title in the review and submit page : "+titles.get(1).getText());
				}
				else
				{
					Reporters.failureReport("Validate the title", "The title in the page is failed to verify. <br> The title on the page : "+title+"<br> The title in the review and submit page : "+titles.get(1).getText());
				}
				
			}else{
				
				String titleOfProduct=getText(ElsevierObjects.itemTitle, "");
				System.out.println(titleOfProduct);
				titleInReviewSubmit=titleOfProduct;
				if(titleOfProduct.contains(title)){
					Reporters.SuccessReport("Validate the title", "The title in the page is verified successfully. <br> The title on the page : "+title+"<br> The title in the review and submit page : "+titleOfProduct);
				}else{
					Reporters.failureReport("Validate the title", "The title in the page is failed to verify. <br> The title on the page : "+title+"<br> The title in the review and submit page : "+titleOfProduct);
				}
			}


			Thread.sleep(high);
		}catch(Exception e){
			System.out.println(sgErrMsg);
		}

		return flag;
	}


	//Cancle the Order
	public static boolean cancelOrder() throws Throwable{
		boolean flag = true;
		try{
			Alert alert = null;
			Thread.sleep(medium);
			if(click(ElsevierObjects.cancleOrder, "Cancle Order")){
				Reporters.SuccessReport("Click on Cancel Order Link", "Successfully clicked on the Cancel Order Link");
			}else{
				Reporters.failureReport("Click on Cancel Order Link", "Failed to click on the Cancel Order Link");
			}
			Thread.sleep(medium);
			alert = driver.switchTo().alert();
			String alertMessage=alert.getText();
			if(alertMessage!=null){
				Reporters.SuccessReport("Verify the alert is present or not", "Alert is present with the message : "+alertMessage);
			}else{
				Reporters.failureReport("Verify the alert is present or not", "Alert is not present");
			}
			Thread.sleep(medium);
			alert.dismiss();

			Thread.sleep(medium);
			String reviewAndSub=getText(ElsevierObjects.reviewAndSubmit, "Get the value review and submit to a string");
			if(reviewAndSub.contains("2. REVIEW & SUBMIT")){
				Reporters.SuccessReport("Click on Cancel button of the alert message and Verify The REVIEW & SUBMIT page is present", "Successfully clicked on the Cancel button of the alert Message and The REVIEW & SUBMIT page is displayed");
			}else{
				Reporters.failureReport("Click on Cancel button of the alert message and Verify The REVIEW & SUBMIT page is present", "Failed to click on the Cancel button of the alert Message and The REVIEW & SUBMIT page is failed to display");
			}
			/*String itemsInCart1=getText(ElsevierObjects.itemInCart, "");
			if(isElementPresent(ElsevierObjects.clickOnCart, "Item is Removed for Cart.")){
				Reporters.SuccessReport("Verify the items in cart", "The total Count of products added to the cart is : "+itemsInCart1);
			}else{
				Reporters.failureReport("Verify the items in cart", "The total Count of products added to the cart is : "+itemsInCart1);
			}*/
			// verifyText(ElsevierObjects.reviewAndSubmit, "2. Review & Submit", "Review and Submit Text is Verified");
			//Thread.sleep(medium);
			// isElementPresent(ElsevierObjects.itemInCart, "Item is added to cart");
			Thread.sleep(medium);
			if(click(ElsevierObjects.cancleOrder, "Cancle Order")){
				Reporters.SuccessReport("Click on Cencel Order Link", "Successfully clicked on the Cancel Order Link");
			}else{
				Reporters.failureReport("Click on Cencel Order Link", "Failed to click on the Cancel Order Link");
			}
			Thread.sleep(medium);
			Alert();
			Thread.sleep(medium);

			String catalog=getText(ElsevierObjects.homepage_welcome_message, "");
			if(isElementPresent(ElsevierObjects.homepage_welcome_message, "Item is Removed for Cart.")){
				Reporters.SuccessReport("Verify the user is taken back to the Catalog page", "User is successfully taken back to the catalog page <br> The text on the catalog page: "+catalog);
			}else{
				Reporters.failureReport("Verify the user is taken back to the Catalog page", "User is not taken back to the catalog page <br> The text on the catalog page: "+catalog);
			}
			click(ElsevierObjects.clickOnCart, "Clicked on Cart Icon");
			String cartItems=getText(ElsevierObjects.noCartItems, "");
			if(cartItems!=null){
				Reporters.SuccessReport("Check for the No items are present in the cart.", "There are no items in the cart is displayed <br> The message printed is : "+cartItems);
			}else{
				Reporters.failureReport("Check for the No items are present in the cart.", "items are available in the cart");
			}
			/* String itemsInCart=getText(ElsevierObjects.itemInCart, "");
		 if(isElementPresent(ElsevierObjects.clickOnCart, "Item is Removed for Cart.")){
			 	Reporters.SuccessReport("Verify the items in cart", "The total Count of products added to the cart is : "+itemsInCart);
			}else{
				Reporters.failureReport("Verify the items in cart", "The total Count of products added to the cart is : "+itemsInCart);
			}*/
			Thread.sleep(medium);
		}catch(Exception e){
			System.out.println(sgErrMsg);
		}
		return flag;
	}

	//Common Methods for test Cases Review&Submit Instructor

	//Verify Review and Submit Page
	static float finalPrice;
	public static boolean verifyReviewAndSubmit(String user) throws Throwable{
		boolean flag = true;
		try{
			Reporters.SuccessReport("Verify User is taken to Review & Submit page and Validate the elements on the page", "User is taken to Review & Submit page <br> User can see the below elements");
			isElementPresent(ElsevierObjects.edit_BillingAddress, "Edit link below Billing Address", driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.edit_ShippingAddress, "Edit link below Shipping address", driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.edit_CreditCard, "Edit link below Credt Card", driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.instructor_checkoutcvv, "CVV blank field", driver.getCurrentUrl());

			Reporters.SuccessReport("Verify Review & Submit page", "Successfully verified the Review & Submit Page in the below steps");
			if(user.equalsIgnoreCase("educator")){
				isElementPresent(ElsevierObjects.edit_salesRepCode, "Sales Rep Code text box", driver.getCurrentUrl());			
				isElementPresent(ElsevierObjects.checkbox2, "Yes, I am an instructor", driver.getCurrentUrl());
			}else{
				if(isElementPresentNegCheck(ElsevierObjects.edit_salesRepCode, "Sales Rep Code text box")){
					Reporters.failureReport("Verify user Should not see Sales Rep Code text box", "User able to see Sales Rep Code text box");
				}else{
					Reporters.SuccessReport("Verify user Should not see Sales Rep Code text box", "User not able to see Sales Rep Code text box");
				}
				if(isElementPresentNegCheck(ElsevierObjects.checkbox2, "Yes, I am an instructor")){
					Reporters.failureReport("Verify user Should not see Sales Rep Code text box", "User able to see Yes, I am an instructor");
				}else{
					Reporters.SuccessReport("Verify user Should not see a checkbox for Yes, I am an instructor", "User not able to see Yes, I am an instructor");
				}
				//isElementPresent(ElsevierObjects.checkbox2, "Yes, I am an instructor", driver.getCurrentUrl());
				//Reporters.SuccessReport("Verify user Should not see Sales Rep Code text box", "User not able to see Sales Rep Code text box");
				//Reporters.SuccessReport("Verify user Should not see a checkbox for Yes, I am an instructor", "User not able to see Yes, I am an instructor");
			}
			isElementPresent(ElsevierObjects.checkbox1, "I accept the Registered User Agreement.", driver.getCurrentUrl());
			//String usText=getText(ElsevierObjects.us_OrdersOnly, "");
			if(verifyText(ElsevierObjects.us_OrdersOnly, "U.S. orders only.", "US Order Text verified.")){
				Reporters.SuccessReport("Verify the text U.S. orders only.", "The text U.S. orders only. is present on the page");
			}else{
				Reporters.failureReport("Verify the text U.S. orders only.", "The text U.S. orders only. is not present on the page");
			}

			if(verifyText(ElsevierObjects.internationalOrder, "For International orders, please visit ", "text is present.")){
				Reporters.SuccessReport("Verify the text For International orders, please visit www.elsevier.com", "The text For International orders, please visit www.elsevier.com. is present on the page");
			}else{
				Reporters.failureReport("Verify the text For International orders, please visit www.elsevier.com", "The text For International orders, please visit www.elsevier.com is not present on the page");
			}

			String total=getText(ElsevierObjects.Admin_Evolve_Ecom_Total, "");
			float totalPri=convertStringToPrice(total);
			System.out.println("total price in the review and submit page is : "+totalPri);
			estimated_tax = getText(ElsevierObjects.estimatedtax, "Estimated");
			float estimatedTax=convertStringToPrice(estimated_tax);
			System.out.println("------------"+ estimated_tax); 	
			System.out.println("estimated tax is --------> "+estimatedTax);
			if(estimatedTax >0.00){
				Reporters.SuccessReport("Verify there is an estaimted tax value greater than $0", "The estimated tax is verified and is greater than $0");
			}else{
				Reporters.failureReport("Verify there is an estaimted tax value greater than $0", "The estimated tax verification is failed and is not greater than $0");
			}
			List<WebElement> abs = driver.findElements(By.xpath(".//*/div[@class='price span2'][contains(text(),'$')]"));
			String price1=abs.get(0).getText();	
			String price2=abs.get(1).getText();
			float finalPrice=convertStringToPrice(price1)+convertStringToPrice(price2)+estimatedTax;

			if(finalPrice==totalPri){
				Reporters.SuccessReport("Verify the Total is the addition of the item's list price + estimated tax value.", "Successfully Verified the Total is the addition of the item's list price + estimated tax value.<br> Total Price : "+totalPri+"<br> Addition of two product prices plus estimated tax : "+finalPrice);
			}else{
				Reporters.failureReport("Verify the Total is the addition of the item's list price + estimated tax value.", "Failed to Verify the Total is the addition of the item's list price + estimated tax value.<br> Total Price : "+totalPri+"<br> Addition of two product prices plus estimated tax : "+finalPrice);
			}

			//float fin=finalPrice+totalPrice;

			/*for(WebElement a:abs){
				System.out.println("--------"+ a.getText());
				String price=a.getText();
				float pr=0;
				float price1=convertStringToPrice(price);
				float finalPrice=price1+pr;
				//float f=convertPrice(a.getLocation(0));
			}*/
		}catch(Exception e){
			System.out.println(sgErrMsg);
		}

		return flag;

	}

	public static float convertPrice(By Locator) throws Throwable{
		flag=true;
		String Price=getText(Locator, "Get Price from the package ");
		String PriceReplace=Price.replace("$", "");
		float TotalPrice=Float.parseFloat(PriceReplace);
		return TotalPrice;
	}

	/*//Search and Products to cart and Checkouts...
		 public boolean searchAndAddproduct(String reviewAndSubmit) throws Throwable{
			boolean flag = true;

				if(reviewAndSubmit == "false"){
					typeAndSearch();
					addSingleProduct(ElsevierObjects.paperbackPrice,ElsevierObjects.paperback_click);
				}

				if(reviewAndSubmit == "true"){
					if(!click(ElsevierObjects.evolveCatalog, "Click on Catalog")){
						  flag=false;
					 }
				}
				if(reviewAndSubmit == "true"){
					typeAndSearch();
					addSingleProduct(ElsevierObjects.paperbackPrice,ElsevierObjects.paperback_click);
					if(!click(ElsevierObjects.evolveCatalog, "Click on Catalog")){
						  flag=false;
					}
					typeAndSearch();
					addSingleProduct(ElsevierObjects.paperbackPrice2 ,ElsevierObjects.paperback_click2 );

				}

			isElementPresent(ElsevierObjects.itemInCart, "Item is added to cart");
			Thread.sleep(medium);
			if(!click(ElsevierObjects.checkout, "Redeem Checkout")){
					flag = false;
			}


			return flag;		
		 }
	 */		 
	//type and search for paperback
	public boolean typeAndSearch() throws Throwable{
		boolean flag = true;
		try{
			if(!type(ElsevierObjects.txtproductsearch,readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-Review&Submit", configProps.getProperty("TestData")).get("searchPaperback"), "text to search")){
				flag = false;
			}
			if(!click(ElsevierObjects.gobutton, "search button")){
				flag = false;
			}
		}catch(Exception e){
			System.out.println(sgErrMsg="Error message");return false;
		}
		return flag;
	}

	public boolean getPrice(By locator, String value) throws Throwable{
		boolean flag = true;
		try{
			List<WebElement> TotalRowCount=driver.findElements(locator);
			// By.xpath(".//*[@id='pageLayout-body-inner-most']//table//tbody//tr")
			int RowIndex=1;
			for(WebElement rowElement:TotalRowCount)
			{
				List<WebElement> TotalColumnCount=rowElement.findElements(By.tagName("td"));
				// int ColumnIndex=1;
				for(WebElement colElement:TotalColumnCount)
				{
					String s1 = colElement.getText();
					// String value= colElement.findElement(By.tagName("s")).getText(); Estimated Tax
					if(s1.contains(value)){
						String value1= TotalColumnCount.get(1).getText();
						System.out.println("Estimated Taxess====>>>"+value1);

					}
				}
				RowIndex=RowIndex+1;
			}
		}catch(Exception e){
			System.out.println(sgErrMsg="Error message");return false;
		}
		return flag;
	}

	//Delete the second Link
	public boolean deleteLink(String isbn) throws Throwable{
		boolean flag = true;
		try{
			if(click(By.xpath(ElsevierObjects.deleteProduct1+isbn+ElsevierObjects.deleteProduct2),"DElete")){
				Reporters.SuccessReport("Click the Delete link. next to the second item", "Successfully clicked on the Delete Link next to the second item");
			}else{
				Reporters.failureReport("Click the Delete link. next to the second item", "Failed to click on the Delete Link next to the second item");
			}
			Thread.sleep(high);

			//String s = getText(By.xpath(".//*[@id='page']/div//div/a/span"), "");
			String s = getText(By.xpath(".//input[@name='quantity']"), "");
			if(s!=null){
				Reporters.SuccessReport("Verify only the first item remains in the cart.", "The Total number of items present in the cart are : " +s);
			}else{
				Reporters.failureReport("Verify only the first item remains in the cart.", "The Total number of items present in the cart are : " +s);
			}

			String total=getText(ElsevierObjects.Admin_Evolve_Ecom_Total, "");
			float totalPri=convertStringToPrice(total);
			System.out.println("total price in the review and submit page is : "+totalPri);
			estimated_tax = getText(ElsevierObjects.estimatedtax, "Estimated");
			float estimatedTax=convertStringToPrice(estimated_tax);
			System.out.println("------------"+ estimated_tax); 	
			System.out.println("estimated tax is --------> "+estimatedTax);
			/*if(estimatedTax >0.00){
				Reporters.SuccessReport("Verify there is an estaimted tax value greater than $0", "The estimated tax is verified and is greater than $0");
			}else{
				Reporters.failureReport("Verify there is an estaimted tax value greater than $0", "The estimated tax verification is failed and is not greater than $0");
			}*/
			List<WebElement> abs = driver.findElements(By.xpath(".//*/div[@class='price span2'][contains(text(),'$')]"));
			String price1=abs.get(0).getText();	
			//String price2=abs.get(1).getText();
			float finalPrice=convertStringToPrice(price1)+estimatedTax;

			if(finalPrice==totalPri){
				Reporters.SuccessReport("Verify the Total is the addition of the item's list price + estimated tax value.", "Successfully Verified the Total is the addition of the item's list price + estimated tax value.<br> Total Price : "+totalPri+"<br> Addition of two product prices plus estimated tax : "+finalPrice);
			}else{
				Reporters.failureReport("Verify the Total is the addition of the item's list price + estimated tax value.", "Failed to Verify the Total is the addition of the item's list price + estimated tax value.<br> Total Price : "+totalPri+"<br> Addition of two product prices plus estimated tax : "+finalPrice);
			}


		}catch(Exception e){
			System.out.println(sgErrMsg="Error message");return false;
		}
		return flag;
	}

	//edit Credit Card Link
	public boolean editCreditCard() throws Throwable{
		boolean flag = true;		
		try{
			String beforeEditing=getText(ElsevierObjects.creditPrev, "");
			if(click(ElsevierObjects.edit_CreditCard, "Clicked On Credit Card Link.")){
				Reporters.SuccessReport("Click on Edit link in Credit Card section.", "Successfully Clicked on the Edit Link in Credit Card Section");
			}else{
				Reporters.failureReport("Click on Edit link in Credit Card section.", "Failed to Click on the Edit Link in Credit Card Section");
			}
			Thread.sleep(medium);
			isElementPresent(ElsevierObjects.CreditCardNum, "Card Number",driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.CreditCardName, "Card Name",driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.CreditCardCvv, "Card Cvv",driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.creditCard_form, "Card type",driver.getCurrentUrl());
			if(selectByVisibleText(ElsevierObjects.creditCard_form, "Visa", "")){
				Reporters.SuccessReport("Select the card type from the DropDown Card Type and verify card type is a DropDown", "Successfully Selected the card type from the Card Type DropDown and verifed card type is a DropDown");
			}else{
				Reporters.failureReport("Select the card type from the DropDown Card Type and verify card type is a DropDown", "Failed to Select the card type from the Card Type DropDown and verifed card type is a DropDown");
			}
			isElementPresent(ElsevierObjects.CreditCardMonth, "Month",driver.getCurrentUrl());
			if(selectByVisibleText(ElsevierObjects.CreditCardMonth, "February", "")){
				Reporters.SuccessReport("Select the Exp. Month from the DropDown Exp. Month and verify Exp. Month is a DropDown", "Successfully Selected the Exp. Month from the Exp. Month DropDown and verifed Exp. Month is a DropDown");
			}else{
				Reporters.failureReport("Select the Exp. Month from the DropDown Exp. Month and verify Exp. Month is a DropDown", "Failed to Select the Exp. Month from the Exp. Month DropDown and verifed Exp. Month is a DropDown");
			}
			isElementPresent(ElsevierObjects.CreditCardyear, "Year",driver.getCurrentUrl());
			String year=ReadingExcel.columnDataByHeaderName("year", "ReviewAndSubmit",configProps.getProperty("TestData"));
			if(selectByVisibleText(ElsevierObjects.CreditCardyear, year, "")){
				Reporters.SuccessReport("Select the Exp. Year from the DropDown Exp. Year and verify Exp. Year is a DropDown", "Successfully Selected the Exp. Year from the Exp. Year DropDown and verifed card type is a DropDown");
			}else{
				Reporters.failureReport("Select the Exp. Year from the DropDown Exp. Year and verify Exp. Year is a DropDown", "Failed to Select the Exp. Year from the Exp. Year DropDown and verifed card type is a DropDown");
			}
			isElementPresent(ElsevierObjects.creditCard_save, "Save Button",driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.creditCard_cancel, "Cancel Button",driver.getCurrentUrl());
			Thread.sleep(medium);
			if(click(ElsevierObjects.creditCard_cancel, "Clicked On Cancel Credit Card Link.")){
				Reporters.SuccessReport("Click the Cancel link from the Edit Credit Card area.", "Successfully Clicked on the Cancel link from the Edit Credit Card area.");
			}else{
				Reporters.failureReport("Click the Cancel link from the Edit Credit Card area.", "Failed to Click on the Cancel link from the Edit Credit Card area.");
			}

			String afterEditing=getText(ElsevierObjects.creditPrev, "");
			if(beforeEditing.equalsIgnoreCase(afterEditing)){
				Reporters.SuccessReport("Verify the Previous Credit Card info displays.", "Successfully Verified the Previous Credit Card info displays.<br> Credit Card Type before clicking on edit link : "+beforeEditing+"<br> Credit Card Type after clicking on edit link : "+afterEditing);
			}else{
				Reporters.failureReport("Verify the Previous Credit Card info displays.", "Failed to Verify the Previous Credit Card info displays.<br> Credit Card Type before clicking on edit link : "+beforeEditing+"<br> Credit Card Type after clicking on edit link : "+afterEditing);
			}
			Thread.sleep(medium);
		}catch(Exception e){
			System.out.println(sgErrMsg="Error message");return false;
		}
		return flag;
	}

	//edit Billing Address Link
	public boolean editBillingAddress() throws Throwable{
		boolean flag = true;
		try{
			String beforeEditing=getText(ElsevierObjects.billingPrev, "");
			if(click(ElsevierObjects.edit_BillingAddress, "Clicked On  Edit Billing Address Link.")){
				Reporters.SuccessReport("Click on Edit link in Billing Address.", "Successfully Clicked on the Edit Link in Billing Address");
			}else{
				Reporters.failureReport("Click on Edit link in Billing Address.", "Failed to Click on the Edit Link in Billing Address");
			}
			Thread.sleep(medium);
			isElementPresent(ElsevierObjects.student_billingAddress, "Billing Address1",driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.billingAddress2, "Billing Address2",driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.student_billingAddress_city, "City",driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.selectState, "State",driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.student_billingAddress_zip, "ZipCode",driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.billingAddressSave, "Billing Address Save",driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.billingAddressCancel, "Blling Address Cancel",driver.getCurrentUrl());
			Thread.sleep(medium);
			if(click(ElsevierObjects.billingAddressCancel, "Clicked On Cancel Billing Address Link.")){
				Reporters.SuccessReport("Click on Cancel link in Billing Address.", "Successfully Clicked on the Cancel Link in Billing Address");
			}else{
				Reporters.failureReport("Click on Cancel link in Billing Address.", "Failed to Click on the Cancel Link in Billing Address");
			}
			String afterEditing=getText(ElsevierObjects.billingPrev, "");
			if(beforeEditing.equalsIgnoreCase(afterEditing)){
				Reporters.SuccessReport("Verify the Previous Billing Address displays.", "Successfully Verified the Previous Billing Address displays.<br> Billing Address before clicking on edit link : "+beforeEditing+"<br> Billing Address after clicking on edit link : "+afterEditing);
			}else{
				Reporters.failureReport("Verify the Previous Billing Address displays.", "Failed to Verify the Previous Billing Address displays.<br> Billing Address before clicking on edit link : "+beforeEditing+"<br> Billing Address after clicking on edit link : "+afterEditing);
			}
			Thread.sleep(medium); 
		}catch(Exception e){
			System.out.println(sgErrMsg="Error message");return false;
		}
		return flag;
	}

	//edit Shipping Address Link
	public boolean editShippingAddress() throws Throwable{
		boolean flag = true;
		try{
			String beforeEditing=getText(ElsevierObjects.shippingPrev, "");
			if(click(ElsevierObjects.edit_ShippingAddress, "Clicked On  Edit Shipping Address Link.")){
				Reporters.SuccessReport("Click on Edit link in Shipping Address.", "Successfully Clicked on the Edit Link in Shipping Address");
			}else{
				Reporters.failureReport("Click on Edit link in Shipping Address.", "Failed to Click on the Edit Link in Shipping Address");
			}
			Thread.sleep(medium);
			isElementPresent(ElsevierObjects.shippingAddressAttention, "Shipping Address", driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.Student_Shipping_Addr1, "Address1", driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.Student_Shipping_City, "City", driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.selectShippingState, "State", driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.Student_Shipping_Zip, "Zip-Code", driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.shippingAddressSave, "Save Address Button", driver.getCurrentUrl());
			isElementPresent(ElsevierObjects.shippingAddressCancel, "Cancel Button", driver.getCurrentUrl());
			Thread.sleep(medium);
			if(click(ElsevierObjects.shippingAddressCancel, "Clicked On Cancel Shipping Address Link.")){
				Reporters.SuccessReport("Click on Cancel link in Shipping Address.", "Successfully Clicked on the Cancel Link in Shipping Address");
			}else{
				Reporters.failureReport("Click on Cancel link in Shipping Address.", "Failed to Click on the Cancel Link in Shipping Address");
			}
			String afterEditing=getText(ElsevierObjects.shippingPrev, "");
			if(beforeEditing.equalsIgnoreCase(afterEditing)){
				Reporters.SuccessReport("Verify the Previous Shipping Address displays.", "Successfully Verified the Previous Shipping Address displays.<br> Shipping Address before clicking on edit link : "+beforeEditing+"<br> Shipping Address after clicking on edit link : "+afterEditing);
			}else{
				Reporters.failureReport("Verify the Previous Shipping Address displays.", "Failed to Verify the Previous Shipping Address displays.<br> Shipping Address before clicking on edit link : "+beforeEditing+"<br> Shipping Address after clicking on edit link : "+afterEditing);
			}
			Thread.sleep(medium);
		}catch(Exception e){
			System.out.println(sgErrMsg="Error message");return false;
		}
		return flag;
	}

	//Edit And Update Credit Card Information
	public boolean updateCreditCard() throws Throwable{
		boolean flag = true;
		try{
			if(click(ElsevierObjects.edit_CreditCard, "Clicked On Credit Card Link.")){
				Reporters.SuccessReport("Click on Edit link in Credt Card section.", "Successfully Clicked on the Edit link in Credt Card section.");
			}else{
				Reporters.failureReport("Click on Edit link in Credt Card section.", "Failed to Click on the Edit link in Credt Card section.");
			}
			creditCardDetails(ElsevierObjects.creditCard_save);
			Thread.sleep(veryhigh);
		}catch(Exception e){
			System.out.println(sgErrMsg="Error message");return false;
		}
		return flag;
	}
public static String billingAddress;
	//Edit And Update Billing Address Information
	public boolean updateBillingAndShippingAddress(By xpath, String value,By locator, By locator1,By locator2, String adress) throws Throwable{
		boolean flag = true;
		try{
			if(click(locator, "Clicked On  Edit Billing Address Link.")){
				Reporters.SuccessReport("Click on Edit link in "+adress+" Address.", "Successfully Clicked on the Edit link in "+adress+" Address");
			}else{
				Reporters.failureReport("Click on Edit link in "+adress+" Address.", "Failed to click on the Edit link in "+adress+" Address");
			}
			Thread.sleep(medium);

			//Update the Billing Address 

			//Random ra = new Random( System.currentTimeMillis() );
			//String streetAddress = readcolumns.twoColumnsBasedOnSheetName(0, 1, "Tc-8566", configProps.getProperty("TestData")).get("StreetAddress")+Integer.toString((1 + ra.nextInt(2)) * 100000 + ra.nextInt(100000));
			ReadingExcel.updateCellValue(1, 6, configProps.getProperty("TestData"), "ReviewAndSubmit");
			billingAddress= ReadingExcel.columnDataByHeaderName("StreetAddress", "ReviewAndSubmit",configProps.getProperty("TestData"));
			
			//billingAddress= readcolumns.twoColumnsBasedOnSheetName(0, 1, "ReviewAndSubmit", configProps.getProperty("TestData")).get("StreetAddress");
			
			if(type(locator2, billingAddress,"Enter user street adress")){
				Reporters.SuccessReport("Enter new "+adress+" Address info.", "Successfully entered new "+adress+" Address info. <br> New street Address : "+billingAddress);
			}else{
				Reporters.failureReport("Enter new "+adress+" Address info.", "Failed to enter new "+adress+" Address info. ");
			}
			Thread.sleep(medium);
			selectByValue(xpath, value, "State");
			if(click(locator1, "Clicked On Save "+adress+" Address Link.")){
				Reporters.SuccessReport("Click on save "+adress+" Address.", "Successfully Clicked on the save "+adress+" Address");
			}else{
				Reporters.failureReport("Click on save in "+adress+" Address.", "Failed to click on the save "+adress+" Address");
			}
			Thread.sleep(high);
			
			Thread.sleep(veryhigh);		
			if(isElementPresentNegCheck(ElsevierObjects.useThisAddressFrame, "")){
				if(switchToFrameByLocator(ElsevierObjects.useThisAddressFrame, "")){
					Reporters.SuccessReport("Please Verify Your Address popup. ", "Successfully Verified the Address popup. ");
				}else{
					Reporters.failureReport("Please Verify Your Address popup. ", "Failed to Verify the Address popup. ");
				}
				
				if(isElementPresent(ElsevierObjects.useThisAddressEducator)){
					if(click(ElsevierObjects.useThisAddressEducator, "Clicked On Use This Address Link.")){
						Reporters.SuccessReport("Click the Use This Address button.", "Successfully Clicked on the Use This Address button.");
					}else{
						Reporters.failureReport("Click the Use This Address button.", "Failed to Clicked on the Use This Address button.");
					}
				
			}else{
				waitForVisibilityOfElement(ElsevierObjects.useThisAddressButton, "");
				
				if(click(ElsevierObjects.useThisAddressButton, "Clicked On Use This Address Link.")){
					Reporters.SuccessReport("Click the Use This Address button.", "Successfully Clicked on the Use This Address button.");
				}else{
					Reporters.failureReport("Click the Use This Address button.", "Failed to Clicked on the Use This Address button.");
				}
			}
			}
			Thread.sleep(veryhigh);
		}catch(Exception e){
			System.out.println(sgErrMsg="Error message");return false;
		}
		return flag;
	}

	public boolean submit(String user) throws Throwable{
		boolean flag = true;
		try{
			if(user.equalsIgnoreCase("educator")){
				Thread.sleep(medium);
				if(click(ElsevierObjects.checkbox1, "Clicked On CheckBox.")){
					Reporters.SuccessReport("Verify Checkmark option for 'Yes, I am an instructor'", "Successfully Clicked on the Checkbox option for 'Yes, I am an instructor'");
				}else{
					Reporters.failureReport("Verify Checkmark option for 'Yes, I am an instructor'", "Failed to Click on the Checkbox option for 'Yes, I am an instructor'");
				}
				Thread.sleep(medium);
				if(click(ElsevierObjects.checkbox2, "Clicked On CheckBox.")){
					Reporters.SuccessReport("Verify Checkmark option for 'Yes, I accept the Registered User Agreement'", "Successfully Clicked on the Checkbox option for 'Yes, I accept the Registered User Agreement'");
				}else{
					Reporters.failureReport("Verify Checkmark option for 'Yes, I accept the Registered User Agreement'", "Failed to Click on the Checkbox option for 'Yes, I accept the Registered User Agreement'");
				}
			}else{
				Thread.sleep(medium);
				if(click(ElsevierObjects.checkbox1, "Clicked On CheckBox.")){
					Reporters.SuccessReport("Verify Checkmark option for 'Yes, I accept the Registered User Agreement'", "Successfully Clicked on the Checkbox option for 'Yes, I accept the Registered User Agreement'");
				}else{
					Reporters.failureReport("Verify Checkmark option for 'Yes, I accept the Registered User Agreement'", "Failed to Click on the Checkbox option for 'Yes, I accept the Registered User Agreement'");
				}
			}
			/*if(!type(ElsevierObjects.instructor_checkoutcvv, readcolumns.twoColumnsBasedOnSheetName(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("student_CardCvv") ,"Enter cvv")){
					flag=false;
			 }
			 */
			Thread.sleep(medium);
			if(javaClick(ElsevierObjects.Student_Review_Submit, "Clicked On Credit Card Link.")){
				Reporters.SuccessReport("Click on Submit Button", "Successfully Clicked on the Submit Button");
			}else{
				Reporters.failureReport("Click on Submit Button", "Failed to Click on the Submit Button");
			}
			Thread.sleep(medium);
		}catch(Exception e){
			System.out.println(sgErrMsg="Error message");return false;
		}
		return flag;
	}


	public boolean orderConformation(String user) throws Throwable{
		boolean flag = true;
		try{
			System.out.println("....................Validating email verifications...........");
			evolveEmail="success@evolveqa.info";
			evolveStudentEmail="studentuser1@evolveqa.info";
			if(user.equalsIgnoreCase("educator")){
				if(type(ElsevierObjects.email_SearchBox, evolveEmail,"Enter the email id.")){
					Reporters.SuccessReport("Input the email into the search box", "Successfully entered the email into the search box");
				}else{
					Reporters.failureReport("Input the email into the search box", "Failed to enter the email into the search box");
				}
			}else{ 
				if(type(ElsevierObjects.email_SearchBox, evolveStudentEmail,"Enter the email id.")){
					Reporters.SuccessReport("Input the email into the search box", "Successfully entered the email into the search box");
				}else{
					Reporters.failureReport("Input the email into the search box", "Failed to enter the email into the search box");
				}
			}
			Thread.sleep(high);
			if(!click(ElsevierObjects.email_SearchIcon,"Click on search icon.")){
				flag=false;
			}
			Thread.sleep(veryhigh);		
			String orderConfirm = getText(ElsevierObjects.order_Conform,"");		
			String orderConfirmip = "Order";
			if(orderConfirm.contains(orderConfirmip)){
				Reporters.SuccessReport("Verify the User receives an email titled Order Confirmation.", "User receives an email titled Order Confirmation in the inbox : " +orderConfirm );
				waitForVisibilityOfElement(ElsevierObjects.order_Conform,"");			
				String evolveEmailweb = getText(ElsevierObjects.evolveEmailWeb, "");
				//for educator search mail.......
				if(user.equalsIgnoreCase("educator")){
					if(evolveEmailweb.contains(evolveEmail)){
						if(click(ElsevierObjects.email_logout,"Click on logout...")){
							Reporters.SuccessReport("Log out from the email application", "Successfully Logged out from the email application");
						}else{
							Reporters.failureReport("Log out from the email application", "Failed to Log out from the email application");
						}
						waitForVisibilityOfElement(ElsevierObjects.evolve_login, "");
					}
				}else{				
					//for student search mail.....
					if(evolveEmailweb.contains(evolveStudentEmail)){
						if(!click(ElsevierObjects.email_logout,"Click on logout...")){
							flag=false;
						}
						Thread.sleep(medium);	
						waitForVisibilityOfElement(ElsevierObjects.evolve_login, "");
					}

				}			
			}else{
				Reporters.failureReport("Verify the User receives an email titled Order Confirmation.", "User failed to receive an email titled Order Confirmation in the inbox");
			}
		}catch(Exception e){
			System.out.println(sgErrMsg="Error message");return false;
		}
		return flag;
	}
	public static boolean validateConfirmationPage(String billing, String shippingAdd) throws Throwable{
		boolean flag=true;
		try{
			Thread.sleep(medium);
			String orderNo=getText(ElsevierObjects.Admin_Evolve_Ecom_OrdNo, "");
			if(orderNo!=null){
				Reporters.SuccessReport("Order No.", "Örder No. is : " +orderNo);
			}else{
				Reporters.failureReport("Order No.", "Örder is not submitted");
			}

			String billingAddress=getText(ElsevierObjects.Admin_Evolve_Ecom_Billing, "");
			String shipping=getText(ElsevierObjects.Admin_Evolve_Ecom_Shipping, "");
			String creditCard=getText(ElsevierObjects.Admin_Evolve_Ecom_CreditCard, "");
			
			if(billingAddress.contains(billing))	{
				Reporters.SuccessReport("Validating Billing address", "Billing address is Verified and is correct as expected <Br> Billing Address Captured from Application is : "+billingAddress +"<br> Actual Billing Address is : "+billing);
			}else{
				Reporters.failureReport("Validating Billing address", "Billing address is Verified and is different as expected <Br> Billing Address Captured from Application is : "+billingAddress +"<br> Actual Billing Address is : "+billing);
			}
			if(shipping.contains(shippingAdd)	){
				Reporters.SuccessReport("Validating Shipping address", "Shipping address is Verified and is correct as expected <Br> Shipping Address Captured from Application is : "+shipping +"<br> Actual Shipping Address is : "+shippingAdd);
			}else{
				Reporters.failureReport("Validating Shipping address", "Shipping address is Verified and is correct as expected <Br> Shipping Address Captured from Application is : "+shipping +"<br> Actual Shipping Address is : "+shippingAdd);
			}
			if(creditCard.equalsIgnoreCase("visa"))	{
				Reporters.SuccessReport("Validating Credit card details", "Credit card details are correct");
			}else{
				Reporters.failureReport("Validating Credit card details", "Credit card details are not correct");
			}

			List<WebElement> testdata= driver.findElements(ElsevierObjects.Admin_Evolve_Ecom_pricelist);

			String freeShip=testdata.get(0).getText();

			float freeShipping=Float.parseFloat(freeShip.replace("$", ""));

			String subTot=testdata.get(1).getText();
			float subTotal=Float.parseFloat(subTot.replace("$", ""));

			String disc=testdata.get(2).getText();
			float discount=Float.parseFloat(disc.replace("$", ""));

			String tax=testdata.get(3).getText();
			float taxpayable=Float.parseFloat(tax.replace("$", ""));

			String total=testdata.get(4).getText();
			float finalPrice=Float.parseFloat(total.replace("$", ""));

			//TODO change the decimal places to two digit
			float expected=freeShipping + subTotal-discount+taxpayable;
			float actual=finalPrice;

			if(expected==actual){
				Reporters.SuccessReport("Price are Calculated", "The subtotal, discount/promotion, and total prices are all calculated as expected <Br> Actual Price is : "+actual + "<br> Expected Price after the calculations is : "+expected);
			}else{
				Reporters.failureReport("Price are Calculated", "The subtotal, discount/promotion, and total prices are all failed to calculate as expected <Br> Actual Price is : "+actual + "<br> Expected Price after the calculations is : "+expected);
			}
			
			String titleOfProduct=getText(ElsevierObjects.itemTitle, "");
			System.out.println(titleOfProduct);
			
			if(titleOfProduct.contains(titleInReviewSubmit)){
				Reporters.SuccessReport("Verify the same item in order is displayed", "The title in the page is verified successfully. <br> The title on the order confirmation page : "+titleOfProduct+"<br> The title in the review and submit page : "+titleInReviewSubmit);
			}else{
				Reporters.failureReport("Verify the same item in order is displayed", "The title in the page is failed to verify. <br> The title on the order confirmation page page : "+titleOfProduct+"<br> The title in the review and submit page : "+titleInReviewSubmit);
			}
		}catch(Exception e){
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}

}



