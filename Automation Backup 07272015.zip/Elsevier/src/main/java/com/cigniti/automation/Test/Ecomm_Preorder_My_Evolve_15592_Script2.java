package com.cigniti.automation.Test;

import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EComm_Preorde_MyEvolve_Page15594_BussinessFunctions;
import com.cigniti.automation.BusinessFunctions.EComm_Preorde_rMyEvolve_Page15591_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.ECommercePackagependingcourseid_15461;
import com.cigniti.automation.BusinessFunctions.Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;
import com.cigniti.automation.datadriven.ReadResourceData;

public class Ecomm_Preorder_My_Evolve_15592_Script2 extends Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions {

	public static final String CINICAL_MEDICAL_ASSISTANT_ONLINE ="9780323287029";

	@Test
	public void ecommPreorderMyEvolve15592_2() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		String course=ReadingExcel.columnDataByHeaderName("course", "TC-15592", testDataPath);
		String button1=ReadingExcel.columnDataByHeaderName("button1", "TC-15592", testDataPath);
		String button2=ReadingExcel.columnDataByHeaderName("button2", "TC-15592", testDataPath);
		String courseType=ReadingExcel.columnDataByHeaderName("courseType", "TC-15592", testDataPath);
		
		
		launchUrl(configProps.getProperty("URL4"));
		String courseID=ReadingExcel.columnDataByHeaderName("CourseID", "TC-15592", testDataPath);
		String username=readcolumns.twoColumns(0,1, "ECommercePreOrder", configProps.getProperty("TestData")).get("ECommPreordeMyEvolvePage15592");
		String password=readcolumns.twoColumns(0,2, "ECommercePreOrder", configProps.getProperty("TestData")).get("ECommPreordeMyEvolvePage15592");
		if(User_BusinessFunction.SignInAsDifferentUser(username, password)){
			Reporters.SuccessReport("Login into Application as same student user", "Successfully logged in as Student user with the credentials : <br> Username : "+username+"<br> Password : "+password);
		}else{
			Reporters.failureReport("Login into Application as same student user", "Failed to log in as Student user with the credentials : <br> Username : "+username+"<br> Password : "+password);
		}
		
		
		//verifyTwoButtons();
		ECommercePackagependingcourseid_15461.VerifyContentpagewithinputs(courseType,course,button1,button2,"Yes");
		enterInstructorCourseId(courseID);
		//myevolve();
		EComm_Preorde_MyEvolve_Page15594_BussinessFunctions.courseDetailsPage(By.xpath("//*[@id='set']/li/div/div/a"),"contentHome");
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),ReadResourceData.getResourceData("TC-10214-1", configProps.getProperty("AdminUser")),
				ReadResourceData.getResourceData("TC-10214-2", configProps.getProperty("AdminUser")),
				ReadResourceData.getResourceData("TC-10214-3", configProps.getProperty("AdminUser")));
		ECommercePackagependingcourseid_15461.adminPARVerify(username);
		launchUrl(configProps.getProperty("URL4"));
		//myevolve();
		EComm_Preorde_MyEvolve_Page15594_BussinessFunctions.courseDetailsPage(By.xpath("//*[@id='set']/li/div/div/a"),"");
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
