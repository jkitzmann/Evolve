package com.cigniti.automation.Test;

import java.util.Random;

import jxl.Sheet;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class SearchResults_FILTERBY_ProductType_9812 extends User_BusinessFunction {
	
	//**************************** Declarations *****************************************************
 	public static Sheet inputSheetObj =null;
	Random ra = new Random( System.currentTimeMillis() );
	@Test
	public void SearchResults_FILTERBY_ProductType() throws Throwable
	
	{
		try	
		{
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());

		writeReport(SwitchToBrowser(ElsevierObjects.studentBrowserType),"Launching Browser to Student","Launching Browser to Student is succesful","Lanching Browser to Student is failed");

		String Catalogs=ReadingExcel.columnDataByHeaderName( "SearchElements", "TC-9812",configProps.getProperty("TestData"));		
		String Input1=ReadingExcel.columnDataByHeaderName( "Input1", "TC-9812",configProps.getProperty("TestData"));
		String Input2=ReadingExcel.columnDataByHeaderName( "Input2", "TC-9812",configProps.getProperty("TestData"));
		System.out.println(Catalogs);
		
        System.out.println("*********************************Login As Student****************************");

		writeReport(User_BusinessFunction.Studentlogin(sStudentUser, sStudentPassword),"Login to Application Using Student Credentials"+sStudentUser,
        		                                                                           "Launching the URL for Student is successful </br > Login to Application Using Student credentails :"+sStudentUser+" is Successful",
        		           		                                                           "Launching and Login to Application Using Student credentails : "+ sStudentUser+" is Failed");
		if(!click(ElsevierObjects.Myevolve,"Click on my evolve"))
		{
			flag=false;
		}
		writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as:"+sStudentUser,
                                                                 "Navigating to CATALOG page is Successful",
                                                                 "Navigating to CATALOG Page is failed");
		Thread.sleep(medium);
		writeReport(User_BusinessFunction.HESI_Search(Catalogs),"Searching for Value:"+Catalogs,
                                                                   "Entered "+Catalogs+" to Search </br > Click on Go Button",
                                                                   "Unable to Search for : "+ Catalogs);
		writeReport((isChecked(ElsevierObjects.Selecallfilterbyproducttype,"Checking All Products Link")),"Verifying 'All Products'  option is Selected by Default","Search results screen is displayed with default FILTER BY PRODUCT TYPE 'All Products' radio button selected","Search results screen is displayed with default FILTER BY PRODUCT TYPE 'All Products' radio button is not selected");
		writeReport(User_BusinessFunction.ClickonFilterByProudctType(Input1),"Click on Product Type :"+Input1+" Under Filter By Product Type",
                "Clicking On Product Type :"+Input1+" Under Filter By Product Type is Successful",
                "Clicking On Product Type :"+Input1+" Under Filter By Product Type is not Successful");
				
		writeReport(User_BusinessFunction.VerifyValueinResultsinallpages(ElsevierObjects.ProductTypeLocatorforStudent,Input1),"Verifying Values: "+Input1+" Present in Results",
                "The Acutal Value from  Application is : "+sActualValues+", is Present in the results",
                "The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the </br>AND</br> The Exepcted Values  is :"+sExpectedValues +"  Both Values are not matching Hence search is as not expected");
	  
		writeReport(User_BusinessFunction.ClickonFilterByProudctType(Input1),"Uncheck the Product Type :"+Input1+" Under Filter By Product Type",
                "Product Type :"+Input1+" Under Filter By Product Type is Unchecked Successful",
                "Product Type :"+Input1+" Under Filter By Product Type is not Unchecked Successful");
		writeReport((isChecked(ElsevierObjects.Selecallfilterbyproducttype,"Checking All Products Link")),"Verifying All Product option is Selected Again","Search results screen is displayed with  FILTER BY PRODUCT TYPE 'All Products' radio button selected as Default Option Again","Search results screen is displayed with  FILTER BY PRODUCT TYPE 'All Products' radio button is not selected");
		
		System.out.println("*********************************Only Single Product Type****************************");
		
		writeReport(User_BusinessFunction.ClickonFilterByProudctType(Input2),"Click on Product Type :"+Input2+" Under Filter By Product Type",
                "Clicking On Product Type :"+Input2+" Under Filter By Product Type is Successful",
                "Clicking On Product Type :"+Input2+" Under Filter By Product Type is not Successful");
		Thread.sleep(medium);
		writeReport(User_BusinessFunction.VerifyValueinResultsinallpages(ElsevierObjects.ProductTypeLocatorforStudent,Input2),"Verifying Values: "+Input2+" Present in Results",
				"The Acutal Value from  Application is : "+sActualValues+", is Present in the results",
                "The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the </br>AND</br> The Exepcted Values  is :"+sExpectedValues +",  Both Values are not matching Hence search is as not expected");
		Thread.sleep(medium);
		writeReport(User_BusinessFunction.ClickonFilterByProudctType(Input2),"Uncheck the Product Type :"+Input2+" Under Filter By Product Type",
                "Product Type :"+Input2+" Under Filter By Product Type is Unchecked Successful",
                "Product Type :"+Input2+" Under Filter By Product Type is not Unchecked Successful");
		writeReport((isChecked(ElsevierObjects.Selecallfilterbyproducttype,"Checking All Products Link")),"Verifying All Product option is Selected Again","Search results screen is displayed with  FILTER BY PRODUCT TYPE 'All Products' radio button selected as Default Option Again","Search results screen is displayed with  FILTER BY PRODUCT TYPE 'All Products' radio button is not selected");
		
		//writeReport((driver.findElement(ElsevierObjects.Selecallfilterbyproducttype).isSelected()),"Verifying All Product option is Selected Again","Search results screen is displayed with  FILTER BY PRODUCT TYPE 'All Products' radio button selected as Default Option Again","Search results screen is displayed with  FILTER BY PRODUCT TYPE 'All Products' radio button is not selected");
		Thread.sleep(medium);
		System.out.println("*********************************Verify Two  Product Types****************************");
		writeReport(User_BusinessFunction.ClickonFilterByProudctType(Input1),"Click on Product Type :"+Input1+" Under Filter By Product Type",
                "Clicking On Product Type :"+Input1+" Under Filter By Product Type is Successful",
                "Clicking On Product Type :"+Input1+" Under Filter By Product Type is not Successful");
		Thread.sleep(medium);
		writeReport(User_BusinessFunction.ClickonFilterByProudctType(Input2),"Click on Product Type :"+Input2+" Under Filter By Product Type",
                "Clicking On Product Type :"+Input2+" Under Filter By Product Type is Successful",
                "Clicking On Product Type :"+Input2+" Under Filter By Product Type is not Successful");
		Thread.sleep(medium);
		writeReport(User_BusinessFunction.VerifyValueinTwoResultsinallpages(ElsevierObjects.ProductTypeLocatorforStudent,Input1,Input2),"Verifying Values Present in Results",
                "The Acutal Value from  Application is : "+sExpectedValues+", is Present in the results",
                "The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the </br>AND</br> not matching Exepcted Values  is :"+sExpectedValues +",  Both Values are not matching Hence search is as not expected");
		Thread.sleep(medium);
		writeReport(User_BusinessFunction.Logout(),"Clicking on Logout",
                "Clicking on Logout is Successful",
                "Clicking on Logout is not Successful");
		
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		
        System.out.println("*********************************Login As Faculty****************************");


       writeReport(User_BusinessFunction.Educatorlogin(sEducatorUser, sEducatorPassword),"Login to Application Using Educator Credentials"+sEducatorUser,
                                                       "Launching the URL for Educator is successful </br > Login to Application Using Educator credentails :"+sEducatorUser+" is Successful",
                                                       "Launching and Login to Application Using Educator credentails : "+ sEducatorUser+" is Failed");

      Thread.sleep(high);
      
       writeReport(User_BusinessFunction.NavigateToCatalog(),"Navigating to CATALOG Page using Roles as: "+sEducatorUser,
                "Navigating to CATALOG page is Successful",
                "Navigating to CATALOG Page is failed");

       Thread.sleep(medium);
       writeReport(User_BusinessFunction.HESI_Search(Catalogs),"Searching for Value: "+Catalogs,
                  "Entered "+Catalogs+" to Search </br > Click on Go Button",
                  "Unable to Search for : "+ Catalogs);
       writeReport((isChecked(ElsevierObjects.Selecallfilterbyproducttype,"Checking All Products Link")),"Verifying 'All Products'  option is Selected by Default","Search results screen is displayed with default FILTER BY PRODUCT TYPE 'All Products' radio button selected","Search results screen is displayed with default FILTER BY PRODUCT TYPE 'All Products' radio button is not selected");
       writeReport(User_BusinessFunction.ClickonFilterByProudctType(Input1),"Click on Product Type :"+Input1+" Under Filter By Product Type",
                                                                            "Clicking On Product Type :"+Input1+" Under Filter By Product Type is Successful",
                                                                            "Clicking On Product Type :"+Input1+" Under Filter By Product Type is not Successful");
       Thread.sleep(high);
writeReport(User_BusinessFunction.VerifyValueinResultsinallpages(ElsevierObjects.ProductTypeLocatorforFaculty,Input1),"Verifying Values: "+Input1+" Present in Results",
"The Acutal Value from  Application is : "+sActualValues+", is Present in the results",
"The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the </br>AND</br> The Exepcted Values  is :"+sExpectedValues +"  Both Values are not matching Hence search is as not expected");

writeReport(User_BusinessFunction.ClickonFilterByProudctType(Input1),"Uncheck the Product Type :"+Input1+" Under Filter By Product Type",
"Product Type :"+Input1+" Under Filter By Product Type is Unchecked Successful",
"Product Type :"+Input1+" Under Filter By Product Type is not Unchecked Successful");
Thread.sleep(3000);	

writeReport((isChecked(ElsevierObjects.Selecallfilterbyproducttype,"Checking All Products Link")),"Verifying All Product option is Selected Again","Search results screen is displayed with  FILTER BY PRODUCT TYPE 'All Products' radio button selected as Default Option Again","Search results screen is displayed with  FILTER BY PRODUCT TYPE 'All Products' radio button is not selected");
System.out.println("*********************************Only Single Product Type****************************");

writeReport(User_BusinessFunction.ClickonFilterByProudctType(Input2),"Click on Product Type :"+Input2+" Under Filter By Product Type",
"Clicking On Product Type :"+Input2+" Under Filter By Product Type is Successful",
"Clicking On Product Type :"+Input2+" Under Filter By Product Type is not Successful");
Thread.sleep(3000);	

writeReport(User_BusinessFunction.VerifyValueinResultsinallpages(ElsevierObjects.ProductTypeLocatorforFaculty,Input2),"Verifying Values: "+Input1+" Present in Results",
"The Acutal Value from  Application is : "+sActualValues+", is Present in the results",
"The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the </br>AND</br> The Exepcted Values  is :"+sExpectedValues +",  Both Values are not matching Hence search is as not expected");

writeReport(User_BusinessFunction.ClickonFilterByProudctType(Input2),"Uncheck the Product Type :"+Input2+" Under Filter By Product Type",
"Product Type :"+Input2+" Under Filter By Product Type is Unchecked Successful",
"Product Type :"+Input2+" Under Filter By Product Type is not Unchecked Successful");
writeReport((isChecked(ElsevierObjects.Selecallfilterbyproducttype,"Checking All Products Link")),"Verifying All Product option is Selected Again","Search results screen is displayed with  FILTER BY PRODUCT TYPE 'All Products' radio button selected as Default Option Again","Search results screen is displayed with  FILTER BY PRODUCT TYPE 'All Products' radio button is not selected");
Thread.sleep(3000);	

System.out.println("*********************************Verify Two Product Types****************************");
writeReport(User_BusinessFunction.ClickonFilterByProudctType(Input1),"Click on Product Type :"+Input1+" Under Filter By Product Type",
"Clicking On Product Type :"+Input1+" Under Filter By Product Type is Successful",
"Clicking On Product Type :"+Input1+" Under Filter By Product Type is not Successful");
Thread.sleep(3000);	

writeReport(User_BusinessFunction.ClickonFilterByProudctType(Input2),"Click on Product Type :"+Input2+" Under Filter By Product Type",
"Clicking On Product Type :"+Input2+" Under Filter By Product Type is Successful",
"Clicking On Product Type :"+Input2+" Under Filter By Product Type is not Successful");
Thread.sleep(3000);	

writeReport(User_BusinessFunction.VerifyValueinTwoResultsinallpages(ElsevierObjects.ProductTypeLocatorforFaculty,Input1,Input2),"Verifying Values Present in Results",
"The Acutal Value from  Application is : "+sExpectedValues+", is Present in the results",
"The Acutal Value from  Application is : "+sActualValues+" ,is not Presented in the </br>AND</br> not matching Exepcted Values  is :"+sExpectedValues +",  Both Values are not matching Hence search is as not expected");
Thread.sleep(3000);	

writeReport(User_BusinessFunction.Logout(),"Clicking on Logout",
    "Clicking on Logout is Successful",
    "Clicking on Logout is not Successful");

}catch(Exception e){  boolean test1=false; writeReport(test1,"Test Got failed due to:"+e,
                "No Results",
                "The Test Case Failed due to This exception:"+e);

 }
    
}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}	
}