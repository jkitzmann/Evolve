package com.cigniti.automation.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import com.cigniti.automation.Utilities.Property;
import com.cigniti.automation.Utilities.Reporters;
public class TextCount {
	public static void main(String args[]){
Property configProps=new Property("config.properties");
BufferedReader br = null;

	try {

		int count=0;
		
		String sCurrentLine;
		br = new BufferedReader(new FileReader(configProps.getProperty("textfilepath")));
		while ((sCurrentLine = br.readLine()) != null) { 
			count++;
		}
		int Finalcount=count;
		System.out.println(Finalcount);

	} catch (IOException e) {
		e.printStackTrace();
	} finally {
		try {
			if (br != null)br.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	

}
}

	
	
	
	
