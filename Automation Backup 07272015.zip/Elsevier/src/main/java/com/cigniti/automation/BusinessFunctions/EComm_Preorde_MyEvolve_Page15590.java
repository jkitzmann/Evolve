package com.cigniti.automation.BusinessFunctions;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Random;

import org.openqa.selenium.By;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Test.EComm_Preorde_MyEvolve_Page15590_Script;
import com.cigniti.automation.Test.ReadFileExample;
import com.cigniti.automation.Utilities.ReadTextFile;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class EComm_Preorde_MyEvolve_Page15590 extends Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions{

	public boolean createAccessCode(String isbNumber,String sUsesPerCode,String sNumberOfGenerated) throws Throwable {
		boolean flag =true;
		try{
		ElsevierObjects.browserType="firefox";
		
		if(!click(ElsevierObjects.EVOLVE_BUTTON, "EVOLVE BUTTON")){
			flag = false;
		}
		if(!click(ElsevierObjects.maintainProd, "maintain Product link")){
			flag =false;
		}
		if(!type(ElsevierObjects.searchTitle,isbNumber,"ISBN Number")){
			flag = false;
		}
		if(!click(ElsevierObjects.btnserchTitle,"Search Button")){
			flag =false;
		}
		Thread.sleep(medium);
		if(!click(By.xpath("//a[text()='"+isbNumber+"']"), "ISBN number")){
			flag =false;
		}
		Thread.sleep(medium);

		createAccessCode(sUsesPerCode,sNumberOfGenerated);

		if(!click(ElsevierObjects.DOWNLOAD_ACCESS_CODE, "DOWNLOAD ACCESS CODE")){
			flag =false;
		}
		if(!click(ElsevierObjects.DOWNLOAD_ACCESS_CODE_TXT, "DOWNLOAD ACCESS CODE TXT")){
			flag =false;
		}

		Thread.sleep(high);
		if(ElsevierObjects.adminBrowserType.equalsIgnoreCase("ie")){
			r = new Robot();
			r.keyPress(KeyEvent.VK_ALT);
			r.keyPress(KeyEvent.VK_S);
			r.keyRelease(KeyEvent.VK_S);
			r.keyRelease(KeyEvent.VK_ALT);
			Thread.sleep(low);

			//If browser type other than 'IE'. 
		}
		//If browser type is Firefox, 
		else  
			//if(configProps.getProperty("browserType").equalsIgnoreCase("firefox")){
			if(ElsevierObjects.adminBrowserType.equalsIgnoreCase("firefox")){
				r = new Robot();
				r.keyPress(KeyEvent.VK_DOWN);
				r.keyPress(KeyEvent.VK_TAB);
				r.keyPress(KeyEvent.VK_TAB);
				r.keyPress(KeyEvent.VK_TAB);
				Thread.sleep(low);
				r.keyPress(KeyEvent.VK_ENTER);
			}
	}
		catch(Exception e)
		{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		return false;
		}
		return flag;
	}

	public boolean createAccessCode(String sUsesPerCode,String sNumberOfGenerated) throws Throwable{
		boolean flag=true;
		try{
			if(!click(ElsevierObjects.createAccessCode, "Click on create access code")){
				flag=false;
			}
			Thread.sleep(medium);

			protectionID=getText(By.xpath(".//*[@id='protectionschemeselectedid']"), "Protection Sheme ID");
			ReadingExcel.updateCellInSheet(1,3,configProps.getProperty("TestData"), "TC-15590", protectionID);
			Random ra = new Random( System.currentTimeMillis() );
			String CodeSetName = readcolumns.twoColumns(0, 1, "Tc-15235", configProps.getProperty("TestData")).get("CodeSetName")+Integer.toString((1 + ra.nextInt(2)) * 10000 + ra.nextInt(10000));
			EvolveCommonBussinessFunctions.ACCESS_CODE =CodeSetName;
			ReadingExcel.updateCellInSheet(1,4,configProps.getProperty("TestData"), "TC-15590", CodeSetName);

			//ReadingExcel.updateCellValue(2, 1, configProps.getProperty("TestData"), 17);
			if(!type(ElsevierObjects.CreateAccessCode_codesetname, CodeSetName , "Code set name")){
				flag=false;
			}
			Thread.sleep(medium);

			driver.findElement(ElsevierObjects.Admin_Useper_code).clear();
			driver.findElement(ElsevierObjects.CreateAccessCode_codeNumber).click();
			if(!type(ElsevierObjects.Admin_Useper_code,sUsesPerCode,"Uses per code")){
				flag=false;
			}

			driver.findElement(ElsevierObjects.CreateAccessCode_codeNumber).clear();
			if(!type(ElsevierObjects.CreateAccessCode_codeNumber,sNumberOfGenerated,"Number of generated")){
				flag=false;
			}


			if(!click(ElsevierObjects.CreateAccessCode_Submit, "Click on Create access code submit button")){
				flag=false;
			}

			Thread.sleep(high);
			if(isElementPresent(ElsevierObjects.Success_MSG_for_AccessCode, "The Access Code Set was successfully created message")){
				Reporters.SuccessReport("Verify success message for access code creation ", "Successfully Created access code.</br>AccessCode Set Name Is: "+CodeSetName +"<br/> Success Message :The Access Code Set was successfully created");
			}
			else{
				Reporters.failureReport("Creating AccessCode.", "Failed To Create access code.");

			}
			Thread.sleep(high);
			ImplicitWait();
		}
		catch(Exception e)
		{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		return false;
		}
		return flag;
	}
	public static boolean compareProtectionScheme(String protectionSche1, String protectionScheme2)throws Throwable{
		boolean flag= true;
		try{


			if(protectionSche1.equalsIgnoreCase(protectionScheme2)){
				Reporters.SuccessReport("Verify that the Scheme Id value displayed on the Create Access Code tab matches <br/>the protection scheme saved for the corse ID in the above template.", "The Scheme Id value displayed on the Create Access Code tab matches the protection scheme saved for the corse ID in the above template.<br/> Protection Scheme ID saved for the above course : "+protectionSche1+"<br/> The Scheme Id value displayed on the Create Access Code tab : "+protectionScheme2);
			}else{
				Reporters.failureReport("Verify that the Scheme Id value displayed on the Create Access Code tab matches <br/>the protection scheme saved for the corse ID in the above template.", "The Scheme Id value displayed on the Create Access Code tab does not matches the protection scheme saved for the corse ID in the above template.<br/> Protection Scheme ID saved for the above course : "+protectionSche1+"<br/> The Scheme Id value displayed on the Create Access Code tab : "+protectionScheme2);
			}


		}
		catch(Exception e)
		{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		return false;
		}
		return flag;
	}

	public static boolean protectedContent()throws Throwable{
		boolean flag= true;
		try{
			//String AccessCode = ReadTextFile.readTextFile(EvolveCommonBussinessFunctions.ACCESS_CODE);
			String codesetName=ReadingExcel.columnDataByHeaderName("CodeSetName","TC-15590", testDataPath);
			System.out.println(codesetName);
			String filepath=configProps.getProperty("DownLoadFile")+codesetName+".txt";
			System.out.println(filepath);
			ArrayList<String> columndata = (ArrayList<String>) ReadFileExample.readTxt(filepath);
			String AccessCode=columndata.get(0);

			//type the access code generated in the previous step
			if(type(ElsevierObjects.accessRedeem, AccessCode, "Access Code")){
				Reporters.SuccessReport("Enter the access code", "Access code is entered. <br> Access Code : "+AccessCode);
			}else{
				Reporters.failureReport("Enter the access code", "Access code is not entered. ");
			}

			click(By.xpath(".//*[@id='ajax-modal']/div[2]/form[1]/button"), "Redeem Button");
			Thread.sleep(high);
			String invalidMessage=getText(By.xpath(".//*[@class='cp_dialog portlet']/div[contains(@class,'cp_dialog_body')]"), "Ïnvalid Access Code Message");
			if(invalidMessage!=null){
				Reporters.SuccessReport("Enter an invalid access code. Verify the user receives below message", "Invalid message is printed : <br/>"+invalidMessage);
			}else{
				Reporters.failureReport("Enter an invalid access code. Verify the user receives below message", "Invalid message is not printed <br/>: "+invalidMessage);
			}

			click(By.xpath(".//*[@class='cp_button cp_primaryButton cp_dialog_okay']"), "OK button");
			Thread.sleep(high);
			//type an invalid access code
			if(type(ElsevierObjects.accessRedeem, "abcdefgh", "Access Code")){
				Reporters.SuccessReport("Enter the access code", "Access code is entered. <br> Access Code : "+AccessCode);
			}else{
				Reporters.failureReport("Enter the access code", "Access code is not entered. ");
			}

			click(By.xpath(".//*[@id='ajax-modal']/div[2]/form[1]/button"), "Redeem Button");
			Thread.sleep(high);

			String invalidMessage1=getText(By.xpath(".//*[@class='cp_dialog portlet']/div[contains(@class,'cp_dialog_body')]"), "Ïnvalid Access Code Message");
			if(invalidMessage!=null){
				Reporters.SuccessReport("Enter an invalid access code. Verify the user receives below message", "Invalid message is printed : "+invalidMessage1);
			}else{
				Reporters.failureReport("Enter an invalid access code. Verify the user receives below message", "Invalid message is not printed : "+invalidMessage1);
			}
			click(By.xpath(".//*[@class='cp_button cp_primaryButton cp_dialog_okay']"), "OK button");
			Thread.sleep(high);
			//String filepath=configProps.getProperty("DownLoadFile")+EvolveCommonBussinessFunctions.ACCESS_CODE+".txt";
			//ArrayList<String> columndata = (ArrayList<String>) ReadFileExample.readTxt(filepath);
			String accesscode=columndata.get(4);

			//type an valid access code
			if(type(ElsevierObjects.accessRedeem, accesscode, "Access Code")){
				Reporters.SuccessReport("Enter the access code", "Access code is entered. <br> Access Code : "+AccessCode);
			}else{
				Reporters.failureReport("Enter the access code", "Access code is not entered. ");
			}
			click(By.xpath(".//*[@id='ajax-modal']/div[2]/form[1]/button"), "Redeem Button");
			Thread.sleep(high);


		}catch(Exception e)
		{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		return false;
		}
		return flag;
	}

	public static boolean selfEnrollNavigate(String courseid) throws Throwable{
		boolean flag = true;
		try{
		if(type(ElsevierObjects.enrollResourceId, courseid, "Input Course Id ")){
			Reporters.SuccessReport("Entering CourseID in Required TextBox.", "Entered CourseID "+courseid+" in  TextBox.");
		}
		else{
			Reporters.failureReport("Entering CourseID in Required TextBox.", "Failed To Enter CourseID "+courseid+" in  TextBox.");
		}      

		Thread.sleep(medium);
		if(click(ElsevierObjects.enrollContinue, "Click on Continue Button")){
			Reporters.SuccessReport("Clicking On Continue Button After Entering CourseID.", "Successfully Clicked On Continue Button.</br>Navigated To My Evolve Page.");
		}
		else{
			Reporters.failureReport("Clicking On Continue Button After Entering CourseID.", "Failed To Click On Continue Button");
		}

		Thread.sleep(medium);
		}
		catch(Exception e)
		{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		return false;
		}
		return flag;
	}

	public boolean checkoutProduct(boolean isStudentHaveAccessCode,String isbnNumber, int accesscodeNumber, String condition) throws Throwable{
		boolean flag = true;
		String errorMessage = "";
		try{
			
			if(isStudentHaveAccessCode){
				if(click(By.id("ac-radio-apply-"+isbnNumber+""), "ac-radio-apply")){
					Reporters.SuccessReport("Select the radio button 'I have an access code:'", "'I have an access code:' radio button is selected");
				}else{
					Reporters.failureReport("Select the radio button 'I have an access code:'", "'I have an access code:' radio button is not selected");
				}

				Thread.sleep(high);
				String codesetName=ReadingExcel.columnDataByHeaderName("CodeSetName","TC-15590", testDataPath);
				System.out.println(codesetName);
				String filepath=configProps.getProperty("DownLoadFile")+codesetName+".txt";
				System.out.println(filepath);
				ArrayList<String> columndata = (ArrayList<String>) ReadFileExample.readTxt(filepath);
				String AccessCode=columndata.get(accesscodeNumber);
				
				if(type(ElsevierObjects.ACCESS_CODE, AccessCode, "ACCESS CODE")){
					Reporters.SuccessReport("Enter the access code", "Access code is entered. <br> Access Code : "+AccessCode);
				}else{
					Reporters.failureReport("Enter the access code", "Access code is not entered. ");
				}
				if(!click(By.id("ac-apply-"+isbnNumber), "ac apply")){
					flag = false;
				}

				Thread.sleep(medium);
				String totalAmount = getText(ElsevierObjects.SUB_TOTAL, "Sub Total");
				if(totalAmount.contains("$0.00")){
					Reporters.SuccessReport("Verify Total price", "Price is verified successfully. The Total Price is 0");
				}

				else{
					Reporters.failureReport("Verify Total price", "The Total Price is Not Zero "+ totalAmount);
				}
				b=true;
				if(!click(ElsevierObjects.btnRedeem, "Redeem Checkout Button")){
					flag = false;
				}

				Thread.sleep(medium);
				if(condition.equalsIgnoreCase("Institution")){
				if(!click(ElsevierObjects.Student_Shipping_Chk, "'I'm not affiliated with an institution")){
					flag = false;
				}
				Thread.sleep(high);
				click(ElsevierObjects.btnprofilesubmit, "Hit Continue");
				b=false;
				}
				Thread.sleep(high);
				if(!click(ElsevierObjects.REGISTERED_USER_AGGREMENT, "Registered User Agreement.")){
					flag = false;
				}
				Thread.sleep(medium);
				if(!click(ElsevierObjects.btnsubmit, "")){
					flag = false;
				}

			}
			else{
				if(click(ElsevierObjects.btnRedeem, "Redeem Checkout button")){
					Reporters.SuccessReport("Click on Redeem and Checkout", "Successfully clicked on the Redeem and Checkout");
				}else{
					Reporters.failureReport("Click on Redeem and Checkout", "Failed to click on the Redeem and Checkout");
				}
				Thread.sleep(high);

				if(isStudentHaveAccessCode){
					if(!click(ElsevierObjects.REGISTERED_USER_AGGREMENT, "Registered User Agreement.")){
						flag = false;
					}
				}
				Thread.sleep(medium);
				if(!click(ElsevierObjects.Student_Shipping_Chk, "Shipping Check box")){
					flag = false;
				}

				Thread.sleep(high);
				if(!type(ElsevierObjects.STREET_ADDRESS, "1851 MCKELVEY HILL DR", "Street Adress")){
					flag = false;
				}

				if(!type(ElsevierObjects.CITY, "Maryland heights", "City")){
					flag = false;
				}
				if(!selectByValue(ElsevierObjects.STATE, "MO", "State")){
					flag = false;
				}

				if(!type(ElsevierObjects.BILLING_PIN_CODE, "63043", "Pin Code")){
					flag = false;
				}

				if(click(ElsevierObjects.btnprofilesubmit, "Submit")){
					Reporters.SuccessReport("Enter Student Shipping address", "Shipping address entered Successfully : <br/> 1851 MCKELVEY HILL DR <br/>Maryland heights<br/>Mo, 63043");
				}else{
					Reporters.failureReport("Enter Student Shipping address", "Failed to enter Shipping address");
				}
				Thread.sleep(medium);

				if(!switchToFrameByLocator(ElsevierObjects.Student_register_frame, "Switch to frame")){
					flag=false;
				}
				if(!click(ElsevierObjects.Student_register_UseAdress_btn,"Click on use this adress button")){
					flag=false;
				}
				Thread.sleep(high);
				String getTitle = getTitle();
				if(!getTitle.contains("Check Out")){
					flag = false;
				}
			}
		
		}
		catch(Exception e)
		{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		return false;
		}
		return flag;
		}
	}

