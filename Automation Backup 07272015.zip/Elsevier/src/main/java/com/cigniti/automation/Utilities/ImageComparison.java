package com.cigniti.automation.Utilities;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.PixelGrabber;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Actiondriver;

public class ImageComparison extends Actiondriver
{

	@Test
	public void search() throws Throwable
	{
		//Image_Comparisions();
		String filePath = ReadingExcel.getAbsoulteFilePath(readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("UploadImgFile"));
		//String url="https://evolvecert.elsevier.com/testing2866";
		Image_Comparisions(filePath);
	}


	public static String Image_Comparisions(String file1) throws Throwable
	{

		System.out.println("Executing processImage Keyword");

		try {

			//driver.navigate().to(url1);
			//file1 = ":\\Images\\Elsevier - Copy.PNG";
			String file2=driver.findElement(By.xpath(".//*[@id='pageLayout-body-inner-most']/div[1]/div/a/img")).getAttribute("src");

			URL url = new URL(file2);
			InputStream in = new BufferedInputStream(url.openStream());
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			byte[] buf = new byte[1024];
			int n = 0;
			while (-1!=(n=in.read(buf)))
			{
				out.write(buf, 0, n);
			}
			out.close();
			in.close();
			byte[] response = out.toByteArray();

			FileOutputStream fos = new FileOutputStream(configProps.getProperty("imageDownloadPath"));
			fos.write(response);
			fos.close();


			file2 = configProps.getProperty("imageDownloadPath");

			Image pic1= Toolkit.getDefaultToolkit().getImage(file1);
			Image pic2= Toolkit.getDefaultToolkit().getImage(file2);

			try {

				PixelGrabber grab11 = new PixelGrabber(pic1, 0, 0, -1, -1,
						false);
				PixelGrabber grab21 = new PixelGrabber(pic2, 0, 0, -1, -1,
						false);

				int[] array1= null;

				if (grab11.grabPixels()) {
					int width = grab11.getWidth();
					int height = grab11.getHeight();
					array1= new int[width * height];
					array1= (int[]) grab11.getPixels();
				}

				int[] array2 = null;

				if (grab21.grabPixels()) 
				{
					int width = grab21.getWidth();
					int height = grab21.getHeight();
					array2 = new int[width * height];
					array2 = (int[]) grab21.getPixels();
				}

				Reporters.SuccessReport("Validate the Image is uploaded in the application or not ", "Image is Successfully Uploaded and Compared <br> The image on the page: "+driver.getCurrentUrl()+" is same as the uploaded file <br> Uploaded Image path is : \\TestData\\evolve_logo_latest_splash.PNG <br>Downloaded Image path from the application is : "+file2);
				System.out.println("Pixels equal: "
						+ java.util.Arrays.equals(array1, array2 ));

			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}

			return "Pass";
		} catch (Throwable t) {
			// report error
			Reporters.failureReport("Validate the Image is uploaded in the application or not", "Image is Failed to Upload into the application <br> The image on the page: "+driver.getCurrentUrl()+" is not same as the uploaded file <br> Uploaded Image path is : \\TestData\\evolve_logo_latest_splash.PNG");
			return "Fail - " + t.getMessage();

		}

	}
}


