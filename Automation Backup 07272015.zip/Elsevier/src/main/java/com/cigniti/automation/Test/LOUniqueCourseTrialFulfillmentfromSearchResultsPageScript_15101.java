package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseFulfillmentfromSearchResultsPage_LO_15100;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentFaculty_15243;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101;
import com.cigniti.automation.BusinessFunctions.LO_Global_Instructor_AR_8572;
import com.cigniti.automation.BusinessFunctions.LO_Unique_CourseFulfillment_Faculty_10410;
import com.cigniti.automation.BusinessFunctions.LO_Unique_CourseFulfillment_Faculty_15586;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;

public class LOUniqueCourseTrialFulfillmentfromSearchResultsPageScript_15101 extends LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101 {
	String adminUser=configProps.getProperty("AdminUser");
	public static String productCost=ExpectedPrice;
	
	@Test
	public void lOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101() throws Throwable{
		try {
			iSBN=ReadingExcel.columnDataByHeaderName("iSBN","TC-15101", configProps.getProperty("TestData"));
			KNOIsbn=iSBN;
			System.out.println("KNOIsbn:"+KNOIsbn);
			product=iSBN;
			requestText=ReadingExcel.columnDataByHeaderName("requestText","TC-15101", configProps.getProperty("TestData"));
			String statusAfterEmailSent=ReadingExcel.columnDataByHeaderName("verifyStatusAfterEmailSent", "TC-15101", configProps.getProperty("TestData"));
			String productId=ReadingExcel.columnDataByHeaderName("productID", "TC-15101", configProps.getProperty("TestData"));
			String format_LO=ReadingExcel.columnDataByHeaderName("format_LO", "TC-15101", configProps.getProperty("TestData"));
			TrialStatus=ReadingExcel.columnDataByHeaderName("trialStatus","TC-15101", configProps.getProperty("TestData"));
			checkTrialStatus=ReadingExcel.columnDataByHeaderName("checkTrialStatus","TC-15101", configProps.getProperty("TestData"));
			String startDate=ReadingExcel.columnDataByHeaderName("StartDate","TC-15101", configProps.getProperty("TestData"));
			String DayTrial=ReadingExcel.columnDataByHeaderName("TRialLink","TC-15101", configProps.getProperty("TestData"));
			
			compareStartDate=ReadingExcel.columnDataByHeaderName("comapreStartDate","TC-15101", configProps.getProperty("TestData"));
			compareEmailTemplateStartDate=ReadingExcel.columnDataByHeaderName("EmailTemlateocTrial","TC-15101", configProps.getProperty("TestData"));
			compareEmailTemplateWarning1=ReadingExcel.columnDataByHeaderName("EmailTemlatewarning1","TC-15101", configProps.getProperty("TestData"));
			compareEmailTemplateWarning2=ReadingExcel.columnDataByHeaderName("EmailTemlatewarning2","TC-15101", configProps.getProperty("TestData"));
			compareEmailTemplateEnd=ReadingExcel.columnDataByHeaderName("EmailTemlateendDate","TC-15101", configProps.getProperty("TestData"));
			unEnrollDays=ReadingExcel.columnDataByHeaderName("unEnrollDays","TC-15101", configProps.getProperty("TestData"));
			warning1Days=ReadingExcel.columnDataByHeaderName("daysWarning1","TC-15101", configProps.getProperty("TestData"));
			wraning2Days=ReadingExcel.columnDataByHeaderName("daysWarning2","TC-15101", configProps.getProperty("TestData"));
			endDays=ReadingExcel.columnDataByHeaderName("endDays","TC-15101", configProps.getProperty("TestData"));
			
			TrialEmailTitle=ReadingExcel.columnDataByHeaderName("emailTitle","TC-15101", configProps.getProperty("TestData"));
			trialEmailTitleAfterFullfilled=ReadingExcel.columnDataByHeaderName("trialEmailTitleAfterFullfilled", "TC-15101", configProps.getProperty("TestData"));
			String EmailTitleAfterFullfilled=trialEmailTitleAfterFullfilled;
		
		//***********************************************************************************************************************************************************//	
		
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Launching Admin URL and Login into Admin Page.", 
						   "Successfully Launched the Admin URL </br> Successfully logged into Admin Page as"+adminUser, 
						   "Failed to Launch the Admmin URL </br> Failed to login into Admin Page.");
			
			writeReport(LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.maintainProductLink(iSBN), "Clicking Maintain products link in Admin Page And Searching For ISBN:"+iSBN, 
							"Successfully Clicked on Maintain Product Link in Admin Page. </br> Successfully entered ISBN:"+iSBN+" in Search box. </br> Successfully Clicked on Search Button.</br>Successfully Navigated To Product Search Result Page.", 
							"Failed to Click on Maintain Product Link in Admin page.</br>Failed To Search For ISBN:"+iSBN);
			
			writeReport(LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.f_prodLinkInMaintainProductPage(), "Clicking F-Prod link in Product Search Result Page.",
										 "Successfully Clicked on F-prod link in Product Search Result Page.",
										 "Failed to Click on F-Prod Link in Product Search Result Page.");
			String value="Start Date";
			LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.compareStartDtaeTrialReg(value,startDate,compareEmailTemplateStartDate);
			String warning1="Warning 1";
			LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.f_productionTrialRegistrationTable(warning1,warning1Days,compareEmailTemplateWarning1);
			String warning2="Warning 2";
			LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.f_productionTrialRegistrationTable(warning2,wraning2Days,compareEmailTemplateWarning2);
			String end="End Date";
			LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.f_productionTrialRegistrationTable(end,endDays,compareEmailTemplateEnd);
			String unenroll="Unenroll User*";
			LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.compareUnEnrollTrialReg(unenroll,unEnrollDays);
		
			Thread.sleep(high);
			writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout.", 
																		"Successfully logged out Admin page", 
																		"Failed to logout Admin page.");
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String user="educator";
			facultyUser=ReadingExcel.columnDataByHeaderName("Faculty_User", "TC-15101", configProps.getProperty("TestData"));
			facultyPwd=ReadingExcel.columnDataByHeaderName("Faculty_passWord", "TC-15101", configProps.getProperty("TestData"));
			
			writeReport(EvolveCommonBussinessFunctions.existingUserLogin(user,facultyUser,facultyPwd),"Login to Application Using User Credentials",
																								   	  "Launching the URL for User is successful </br > Login to Application Using User Credentials :"+facultyUser+" is Successful",
																									  "Launching and Login to Application Using User Credentials : "+ facultyUser+" is Failed");
			writeReport(EvolveCommonBussinessFunctions.getAccountDetails(),"Fetching Account Details from My Account.",
																		   "Successfully Fetched account details from My Account page.",
																		   "Failed to Fetch the account details from My Account page.");
			
			writeReport(EvolveCommonBussinessFunctions.searchProduct(product,productCost),"Search for the product..",
																						  "Successfully Entered ISBN:"+product+" in Search Box.</br>Clicked On Go Button.</br>Navigated To Product Details Page.",
																						  "Failed to Enter ISBN:"+product+" in Search Box.");
			LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.request30DayTrial();
			searchTrial="true";
			LOUniqueCourseTrialFulfillmentfromSearchResultsPageScript_15101.Mycart(searchTrial,DayTrial);
			accessCode="false";
			
			LO_Unique_CourseFulfillment_Faculty_10410.userReviewSubmit(searchTrial,DayTrial);
			String lmsTextLO=EvolveCommonBussinessFunctions.lmsText;
			LO_Unique_CourseFulfillment_Faculty_10410.receiptPage(searchTrial,DayTrial);
			
			writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the educator page.", 
																			"Successfully logged out the educator:"+facultyUser, 
																			"Failed to logout the educator page:"+facultyUser);
			
			//****************************Title Verification In Email After Requesting The Product*************************************//
			
			SwitchToBrowser("chrome");
			writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Login In Into Evolve Email Page.", 
																	  "Succesfully login into Evole Email Page.", 
																	  "Failed to login into Evolve Email Page.");
			String emailid=EvolveCommonBussinessFunctions.getAccountDetailsEmail;
			writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(emailid),"Search email in evolve webmail.",
												"Successfully entered the emailid "+emailid+" in search box.",
												"Failed to enter email id.");
			trial="true";
			LOUniqueCourseTrialFulfillmentFaculty_15243.verifyEmailBodyAfterRequestProduct(trial);
			
			//****************************************Verifying User Details In ADMIN*************************************************//
		
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login to Application Using Admin Credentials"+adminUser,
					"Launching the URL for Admin is successful </br > Login to Application Using Admin credentials :"+adminUser+" is Successful", 
					"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");
		
			LO_Global_Instructor_AR_8572.admin_Adoptionsearch();
			
			/*writeReport(EvolveCommonBussinessFunctions.clickAdoptionRequest(),"Clicking on Search Adoption request link in Admin page.",
					  "Successfully clicked on Seach Adoption Requests link.</br>Successfully Selected Today Radio Button In Adoption Request Page.</br>Successfully Clicked On Search Button</br>Navigated To Adoption Search Results Page.",
					  "Failed to click on Search Adoption Requests link.</br>Failed To Select Today Radio Button In Adoption Request Page.</br>Failed To Navigate To Adoption Search Results Page.");*/
			
			LO_Global_Instructor_AR_script_8572.check_Approvedstatus(trial);	
			
			writeReport(EvolveCommonBussinessFunctions.getAdoptionRequestDetails(),"Get Detils of User and Course in Adoption request Details page",
																					"Successfully got the details of User And Course from Adoption Request Details Page.",
																					"Failed to get the details of User And Course from Adoption Request Details Page.");
			LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.verifyTrialLOStatus(format_LO);
		
			LOUniqueCourseFulfillmentfromSearchResultsPage_LO_15100.getCourseId(statusAfterEmailSent,productId,facultyUser);
		
			LOUniqueCourseTrialFulfillmentfromSearchResultsPage_15101.adoptionRequestVerifyMIlestoneDateformat(startDate);
			
			Thread.sleep(high);
			writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout.", 
					  "Successfully logged out admin page.", 
					  "Failed to logout admin page.");
			
			//**************************Verifying Title After Fulfilling The Request**********************************************************//
			SwitchToBrowser("chrome");
			writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Login In Into Evolve Email Page.", 
					  "Successfully login into Evolve Email Page.", 
					  "Failed to login into Evolve Email Page.");

			writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(emailid),"Search email in evolve webmail.",
						"Successfully entered the emailid "+emailid+" in search box.",
						"Failed to enter email id.");
			LOUniqueCourseTrialFulfillmentFaculty_15243.verifyEmailBodyAfterRequestFullfill(EmailTitleAfterFullfilled);
			
			
			//**********************************Searching For Course ID In Faculty Page Generated In ADMIN After Fulfilling The Request************************//
			
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			facultyUserName=ReadingExcel.columnDataByHeaderName("Faculty_User", "TC-15101", configProps.getProperty("TestData"));
			facultyPassword=ReadingExcel.columnDataByHeaderName("Faculty_passWord", "TC-15101", configProps.getProperty("TestData"));
			//driver.navigate().to("https://evolvecert.elsevier.com/cs/store?role=faculty");
			writeReport(LO_Unique_CourseFulfillment_Faculty_10410.reLogin(facultyUserName, facultyPassword),  "Login to Application Using User Credentials",
																								    	"Launching the URL for User is successful </br > Login to Application Using User Credentials :"+facultyUserName+" is Successful",
																								    	"Launching and Login to Application Using User Credentials : "+ facultyUserName+" is Failed");
			
			String ID1="true";
			String ID2="false";
			writeReport(LO_Unique_CourseFulfillment_Faculty_10410.courseIDSearch(ID1,ID2),"Verify course ID's generated in Admin page are in Educator page or not.",
																			  "Successfully verified CourseId "+courseID1+". </br> Clicked on "+courseID1+".", 
																			  	"Failed to verify CourseId "+courseID1);
			
			// adding a logout/log back in step
			writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the educator page.", 
					"Sucecssfully logged out the educator:"+facultyUser, 
					"Failed to logout the educator page:"+facultyUser);
			writeReport(LO_Unique_CourseFulfillment_Faculty_10410.reLogin(facultyUserName, facultyPassword),  "Login to Application Using User Credentials",
			    	"Launching the URL for User is successful </br > Login to Application Using User Credentials :"+facultyUserName+" is Successful",
			    	"Launching and Login to Application Using User Credentials : "+ facultyUserName+" is Failed");
			writeReport(LO_Unique_CourseFulfillment_Faculty_10410.courseIDSearch(ID1,ID2),"Verify course ID's generated in Admin page are in Educator page or not.",
					  "Successfully verified CourseId "+courseID1+". </br> Clicked on "+courseID1+".", 
					  	"Failed to verify CourseId "+courseID1);
			
			/*writeReport(LO_Unique_CourseFulfillment_Faculty_15586.courseDetailsPage(),"Verify Course details in Course Details page.",
																				"Successfully verified all course details. </br> Succesfully get the protection scheme id.",
																				"Failed to verify all course details.");*/
			LO_Unique_CourseFulfillment_Faculty_10410.courseDetailsPage(searchTrial);
			writeReport(EvolveCommonBussinessFunctions.instructorLogout(), "Logout the educator page.", 
					"Sucecssfully logged out the educator:"+facultyUser, 
					"Failed to logout the educator page:"+facultyUser);
		}
		catch(Exception e){
			System.out.println(e);
		}
	
	}	
}
