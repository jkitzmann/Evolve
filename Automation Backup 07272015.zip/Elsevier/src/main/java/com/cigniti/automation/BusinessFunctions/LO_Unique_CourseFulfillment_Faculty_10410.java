package com.cigniti.automation.BusinessFunctions;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.Utilities.WritingExcel;

public class LO_Unique_CourseFulfillment_Faculty_10410 extends EvolveCommonBussinessFunctions{
	public static Map<String, String> values=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC_9804", configProps.getProperty("TestData"));
	public static String courseLink;
	public static String protectionSchemeText;
	
	public static boolean verifyLOStatusInARPage(String format_LO) throws Throwable{
		boolean flag=true;
		try{
			String status=ReadingExcel.columnDataByHeaderName("Status", "TC-10410", testDataPath);
			if(getAccountDetailsFirstName.contains(adoptionRequest_FirstName) && getAccountDetailsLastName.contains(adoptionRequest_LastName) && getAccountDetailsEmail.contains(adoptionRequest_Email) && getAccountDetailsInstitution.contains(adoptionRequest_Institution) && getAccountDetailsPhone.contains(adoptionRequest_Phone) && getAccountDetailsUserName.contains(adoptionRequest_Username) && password.contains(adoptionRequest_Password) && getAccountDetailsCountry.contains(adoptionRequest_Country)){
				Reporters.SuccessReport("Verifying The User Information In Matches That Of Instructor.", "Verified Firstname:"+adoptionRequest_FirstName+",Lastname:"+adoptionRequest_LastName+",Email:"+adoptionRequest_Email+",Institution:"+adoptionRequest_Institution+",Username:"+adoptionRequest_Username+",Password:"+adoptionRequest_Password+",Phone:"+adoptionRequest_Phone+",Country:"+adoptionRequest_Country+",Adress:"+adoptionRequest_Adress);
			}
			else{
				Reporters.failureReport("Verifying The User Information In Matches That Of Instructor.", "Failed To Verify User Details In Adoption Request Details Page.");
			}
			if(title.contains(adoptionRequest_producttitle) && Isbn.contains(adoptionRequest_Isbn) && author.contains(adoptionRequest_Author) /*&& productType.contains(adoptionRequest_ProductType)*/ && adoptionRequest_Format.contains(format_LO)){
				
				Reporters.SuccessReport("Verifying the product information is correct per the online course ordered ", "Verified ISBN:"+adoptionRequest_Isbn+",Title:"+adoptionRequest_producttitle+",ProductType:"+adoptionRequest_ProductType+",Author:"+adoptionRequest_Author+",Format:"+adoptionRequest_Format);
			}
			else{
				Reporters.failureReport("Verifying the product information is correct per the online course ordered ", "Failed To Verify the product information is correct per the online course ordered.");
			}				
			if(verifyText(ElsevierObjects.adoptionRequestStatus, status, "Verify request status.")){
				Reporters.SuccessReport("Verifying Adoption Request Status.", "Verified Adoption Request "+status+" Status.");
			}
			else{
				Reporters.failureReport("Verifying Adoption Request Status.", "Failed To verify Adoption Request Status.");
			}
			System.out.println("adoptionRequest_Comment:"+adoptionRequest_Comment);
			System.out.println("comment:"+comment);
			System.out.println("adoptionRequest_CourseContent:"+adoptionRequest_CourseContent);
			System.out.println("evolveContent:"+evolveContent);
			System.out.println("adoptionRequest_Enrollment:"+adoptionRequest_Enrollment);
			System.out.println("enrollment:"+enrollment);
			String changeStatus=ReadingExcel.columnDataByHeaderName("changeStatus", "TC-10410", testDataPath);
			if(adoptionRequest_Comment.trim().contains(comment.trim()) && adoptionRequest_CourseContent.trim().contains(evolveContent.trim()) && adoptionRequest_Enrollment.trim().contains(enrollment.trim())){
				Reporters.SuccessReport("Verifying CourseContent,Enrollment,Customer Comment in Adoption Request Details Page.","Successfully Verified Content:"+adoptionRequest_CourseContent+",Enrollment:"+adoptionRequest_Enrollment+",Customer comment:"+adoptionRequest_Comment);
			}
			else{
				Reporters.failureReport("Verifying CourseContent,Enrollment,Customer Comment in Adoption Request Details Page.", "Failed To Verify CourseContent,Enrollment,Customer Comment in Adoption Request Details Page.");
			}
			selectByVisibleText(ElsevierObjects.adoptionRequestStatus, changeStatus, "Change status to fullfilled.");
			Thread.sleep(medium);				
			if(click(ElsevierObjects.adoptionRequest_Save,"Click on Save button.")){
				Reporters.SuccessReport("Selecting "+changeStatus+" Status from dropdown.</br>Clicking On Save Button", "Successfully Selected Status:"+changeStatus+" from Dropdown.</br>Clicked On Save Button.</br>User is shown a pop up regarding if an email should be sent.");
			}
			else{
				Reporters.failureReport("Selecting "+changeStatus+" Status from dropdown.</br>Clicking On Save Button", "Failed To Change Status from dropdown.</br>Failed To Click On Save Button.");
			}
			Thread.sleep(veryhigh);
			Thread.sleep(veryhigh);
			if(click(ElsevierObjects.emailPopup,"Click on Send mail button on popup.")){
				Reporters.SuccessReport("Clicking On Send Mail Button In Email Popup.", "Successfully Clicked On Send Mail Button in Email Popup.</br>The Page is Refreshed After Send Email Button Is Clicked.");
			}
			else{
				Reporters.failureReport("Clicking On Send Mail Button In Email Popup.", "Failed To Click On Send Email Button In Email Popup.");
			}
			Thread.sleep(medium);
		}
		catch(Exception e){sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
		
		return flag;
	}
		
	public static boolean verifyLOStatusAfterEmailSentInARPage(String statusAfterEmailSent,String productId,String username) throws Throwable{
	boolean flag=true;
	try{
		 courseID1=getAttribute(ElsevierObjects.adoptionRequestCourseId1,"value", "Get courseId1");
		 String ID=courseID1.split("_")[2];
		 int IDlength=ID.length();
		 System.out.println("ID:"+ID);
		 System.out.println("courseID1:"+courseID1);
		 courseID2=getAttribute(ElsevierObjects.adoptionRequestCourseId2,"value", "Get CourseId2");
		 System.out.println("courseID2:"+courseID2);
		 ReadingExcel.updateCellInSheet(1,12,configProps.getProperty("TestData"), "TC-10410", courseID1);
		 ReadingExcel.updateCellInSheet(1,13,configProps.getProperty("TestData"), "TC-10410", courseID2);
		 String adoptionrequeststatus=getText(ElsevierObjects.adoptionRequestFulfillStatus,"adoptionRequestFulfillStatus");
		// if(adoptionrequeststatus.contains(statusAfterEmailSent) && courseID1.contains("("+productId+")"+"_"+"("+username+")"+"_"+"([0-9])")){
		 if(adoptionrequeststatus.equals(statusAfterEmailSent) && courseID1.contains(productId) && courseID1.contains(username) && IDlength==4){
			 Reporters.SuccessReport("Verifying Status After Sending Email.</br>Fetching CourseId's And Verifying Course ID Format.", "Successfully Verified Status:"+statusAfterEmailSent+" after sending email.</br>Fetched CourseId's:"+courseID1+","+courseID2+"</br>Succesfully Verified Course ID Format (productID)_(instructorname on the AR)_(4 digit number):"+courseID1);
			}
		 else{
				Reporters.failureReport("Verifying Status After Sending Email.</br>Fetching CourseId's And Verifying Course ID Format.", "Failed To Verify Status:"+statusAfterEmailSent+" after sending email.</br>Failed To Verify Course ID Format (productID)_(instructorname on the AR)_(4 digit number):"+courseID1); 
		 }
		}
	catch(Exception e){sgErrMsg=e.getMessage();
	System.out.println(e);return false;
}
	
		return flag;
	}
	 //(productID)_(instructorname on the AR)_(4 digit number)
	public static boolean reLogin(String facultyUserName,String facultyPassword)throws Throwable{
		boolean flag=true;
		try{	
		
		launchUrl(configProps.getProperty("URL3"));
		driver.manage().deleteAllCookies();
		driver.navigate().refresh();
		Thread.sleep(medium);
		click(ElsevierObjects.student_login, "click on Faculty login");
		Thread.sleep(high);
		type(ElsevierObjects.educator_txtStudentUser,facultyUserName,"Enter user name.");
		Thread.sleep(high);
		type(ElsevierObjects.educator_txtStudentPassword,facultyPassword,"Enter password");
		Thread.sleep(high);
		click(ElsevierObjects.userLogin_btn,"Click on login button.");
		Thread.sleep(high);
		}
		catch(Exception e){sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
		
		return flag;
	}
	
	
	public static boolean courseIDSearch(String ID1,String ID2) throws Throwable{
        boolean flag=true;
        try{
        if(ID1.equalsIgnoreCase("true")){
        String COURSEID1=getText(By.xpath(".//*[@id='set']/li/div/div/span[text()='COURSE ID: "+courseID1+"']"), "Course ID");
        System.out.println("COURSEID1 :"+COURSEID1);
        waitForVisibilityOfElement(By.xpath(".//*[@id='set']/li/div/div/span[text()='COURSE ID: "+courseID1+"']"),"Verify course id1 present.");
        Thread.sleep(low);
        }
        if(ID2.equalsIgnoreCase("true")){
        waitForVisibilityOfElement(By.xpath(".//*[@id='set']/li/div/div/span[text()='COURSE ID: "+courseID2+"']"), "Verify course id2 present.");
        Thread.sleep(low);
        }
        click(By.xpath("//*[@id='set']/li/div/div/span[text()='COURSE ID: "+courseID1+"']/following-sibling::a"),"Click on COurse Title.");
 
        Thread.sleep(60000);
        //driver.manage().timeouts().implicitlyWait(600, TimeUnit.SECONDS);
        
        //driver.navigate().refresh();
        }
        catch(Exception e){sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
		
        return flag;  
 }

            public static boolean courseDetailsPage(String searchTrial) throws Throwable{
            boolean flag=true;
            try{
                   driver.navigate().refresh();
                   waitForElementPresent(ElsevierObjects.educator_CoursePage_Courselink,"Verify course link present in course details page.");
                   Thread.sleep(medium);
                   if(waitForElementPresent(ElsevierObjects.educator_CoursePage_LockIcon, "Verify Lock Icon present or not.")){
                         Reporters.SuccessReport("Verifying Course Library Link And Lock Icon Are present in Course Content Menu.", "Verified Course Library Link And Lock Icon In Course Content Menu.");
                   }
                   else{
                         Reporters.failureReport("Verifying Course Library Link And Lock Icon Are present in Course Content Menu.", "Failed To Verify Course Library Link And Lock Icon In Course Content Menu.");
                   }
                   Thread.sleep(medium);
                   if(click(ElsevierObjects.educator_CoursePage_Courselink, "Click on course link present in course details page.")){
                   Reporters.SuccessReport("Clicking On Course Link.", "Clicked On Course Link In content menu.");
                         }
                   else{
                         Reporters.failureReport("Clicking On Course Link.", "Failed To Click On Course Link In content menu.");
                   }
                   Thread.sleep(medium);
                   List<WebElement> s=driver.findElements(ElsevierObjects.educator_CoursePage_SubFolders);
                     for(WebElement subFolder:s){
                   //String subFolders=getText(ElsevierObjects.educator_CoursePage_SubFolders, "Get All Subfolders Title.");
                   
                   if(waitForElementPresent(ElsevierObjects.educator_CoursePage_SubFolders, "Course folder contains sub folders.")){
                         Reporters.SuccessReport("Verifying subfolders.", "Verified Subfolders of Course Folder.</br>SubFolder is:"+subFolder.getText());
                   }
                   else{
                         Reporters.failureReport("Verifying subfolders.", "Failed To Verify Subfolders of Course Folder.");
                   }
                     }
                   Thread.sleep(medium);
                   if(searchTrial.equalsIgnoreCase("false")){
                         click(ElsevierObjects.educator_CoursePage_CourseContentLink, "Click on Course content link in course details page.");
                         Thread.sleep(medium);
                         click(ElsevierObjects.educator_CoursePage_EditLink,"Click on Edit link in Course folder.");
                         Thread.sleep(medium);
                         if(click(ElsevierObjects.educator_CoursePage_EditLink_About,"Click on About link in Edit.")){
                                Reporters.SuccessReport("Clicking On Content Home Link.</br>Clicking On Edit Button And Selecting About from Options Dropdown.", "Successfully Clicked On Course Content Link.</br>Clicked On Edit Button on course Folder in Main Page.</br>Selected About from Options Dropdown.");
                         }
                         else{
                                Reporters.failureReport("Clicking On Content Home Link.</br>Clicking On Edit Button And Selecting About from Options Dropdown.", "Failed To Click On Course content Link.</br>Failed To Click On Edit Button.Failed To Select About From Options Dropdown.");
                         }
                         Thread.sleep(medium);
                          protectionSchemeText=getText(ElsevierObjects.educator_CoursePage_ProtectionSchemeText, "Protection scheme text.");
                         //protectionSchemeID=protectionSchemeText.split("\\(")[1].replaceAll("\\)", "protectionSchemeText");
                         int start = protectionSchemeText.lastIndexOf('(');
                         int end = protectionSchemeText.lastIndexOf(')');
                         protectionSchemeID = protectionSchemeText.substring(start + 1, end);
                         System.out.println("protectionSchemeID: "+protectionSchemeID);
                   
                         if(protectionSchemeID!=null){
                                Reporters.SuccessReport("Fetching Protection Scheme ID .", "Successfully Fetched Protection Scheme ID:"+protectionSchemeID);
                         }
                         else{
                                Reporters.failureReport("Fetching Protection Scheme ID.", "Failed To Fetch Protection Scheme ID.");
                         }
                         Thread.sleep(medium);
                         click(ElsevierObjects.ProtectionSchemeID_OK,"Click On Ok Button.");
                         Thread.sleep(medium);
                   }
                  
            }
            catch(Exception e){sgErrMsg=e.getMessage();
    		System.out.println(e);return false;
    	}
    		
            return flag;  
     }

		public static boolean userReviewSubmit(String searchTrial,String TrialLink) throws Throwable{
		    boolean flag = true;
		  try{
		    //totalPriceInReviePage=getText(ElsevierObjects.totalPriceInReviewPage, "Total price in review page");
		    priceInReviewPage=getText(ElsevierObjects.evolve_Rview_chkprice, "price in review page");
		    isbnInReviewPage=getText(ElsevierObjects.evolve_Rview_chkIsbn,"Isbn in review page");
		    titleInReviewPage=getText(ElsevierObjects.evolve_Rview_chktitle, "Title in review page");
		    
		    
		    // Doesn't look like there is a trial link on the cart details page any longer. Commenting out this section.
		    /*&if(searchTrial.equalsIgnoreCase("true")){
		    	String requestTextInReviewPage=getText(ElsevierObjects.evolve_MyCart_RequestTrial30Dayslnk, "Get text of Request 30 days trial link.");
		    	if(TrialLink.contains(requestTextInReviewPage)){
		    		Reporters.SuccessReport("Verifying Request Trial Text In Review Page.", "Successfully Verified Request Trial Text:"+requestTextInReviewPage+" In Review Page.");
		    	}
		    	else{
		    		Reporters.failureReport("Verifying Request Trial Text In Review Page.", "Failed To Verify Request Trial Text In Review Page.");
		    	}
		    }*/
		    
		    if(priceInReviewPage.contains(ExpectedPrice) && titleInReviewPage.contains(title) && isbnInReviewPage.trim().contains(Isbn.trim())){
		    	click(ElsevierObjects.evolveInstructorChk,"Click on Instructor checkbox");
		        Thread.sleep(medium);
		        click(ElsevierObjects.evolveRegisterAcceptChk,"Click on Register checkbox");
		        Thread.sleep(medium);
		        if(click(ElsevierObjects.instructor_submit,"Click on Instructor Submit button")){
		        	Reporters.SuccessReport("Verifying Price,Title,ISBN in Review/Submit Page.clicking On Submit Button", "Successfully Verified Price:"+priceInReviewPage+",ISBN:"+isbnInReviewPage+",Title:"+titleInReviewPage+" in Review/Submit Page.</br>Successfully Clicked On Checkboxes Yes, I accept the Registered User Agreement and Yes, I am an instructor checkboxes.</br>Successfully Clicked On Submit Button.</br>Navigated To Receipt Page.");
		        }
		        else{
		        	Reporters.failureReport("Verifying Price,Title,ISBN in Review/Submit Page.clicking On Submit Button", "Failed To Verify Price,ISBN,Title in Review/Submit Page.</br>Failed To Click On Checkboxes Yes, I accept the Registered User Agreement and Yes, I am an instructor checkboxes.</br>Failed To Click On Submit Button.</br>Failed To Navigate To Receipt Page.");
		        }
		       Thread.sleep(high);
		  }
		  }
		  catch(Exception e){sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
			
		  return flag;
		}
		public static boolean receiptPage(String searchTrial,String TrialLink) throws Throwable{
			boolean flag=true;
			try{
				/*if(searchTrial.equalsIgnoreCase("true")){
					String requestTextInReceiptPage=getText(ElsevierObjects.evolve_MyCart_RequestTrial30Dayslnk, "Get text of Request 30 days trial link.");
					if(TrialLink.contains(requestTextInReceiptPage)){
						Reporters.SuccessReport("Verifying Request Trial Text In Receipt Page.", "Successfully Verified Request Trial Text:"+requestTextInReceiptPage+" In Receipt Page.");
					}
					else{
						Reporters.failureReport("Verifying Request Trial Text In Receipt Page.", "Failed To Verify Request Trial Text In Receipt Page.");
				   	}
				}*/
				productType=getText(ElsevierObjects.ProductType, "ProductType");
				titleInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chktitle,"Price in Receipt page");
				isbnInReceiptPage=getText(ElsevierObjects.evolve_Receipt_chktisbn,"Price in Receipt page");
				PriceinReceiptPage=getText(ElsevierObjects.evolve_Receipt_chkprice,"Price in Receipt page");
				String orderNumber=getText(ElsevierObjects.ORDERNUM_IN_RECEIPT_PAGE,"ORDERNUM_IN_RECEIPT_PAGE");
				if(isbnInReceiptPage.contains(Isbn) && titleInReceiptPage.contains(title) &&  PriceinReceiptPage.equals(ExpectedPrice) ){
					Reporters.SuccessReport("Verifying Product details In Receipt Page And Fetching Order Number.", "Successfully Verified price:"+PriceinReceiptPage+",ISBN:"+isbnInReceiptPage+",Title:"+title+" in Receipt Page.</br>successfully Fetched Order Number:"+orderNumber);
				}
				else{
					Reporters.failureReport("Verifying Product details In Receipt Page And Fetching Order Number.", "Failed To Verify Product Details In Receipt Page.</br>Failed To Fetch Order Number.");
				}
			}
			catch(Exception e){sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
			
			return flag;
		}
}
