package com.cigniti.automation.Test;

import java.util.List;
import java.util.Map;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.beust.jcommander.internal.Lists;
import com.beust.jcommander.internal.Maps;
import com.cigniti.automation.BusinessFunctions.Enrollments_10437;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.SelfEnrollLOCourseHomePage_10302;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class Enrollment_10437_Script  extends Enrollments_10437{

	String existingUserId;
	String existingUserPwd;
	@Test
	public void enrollments_10437()throws  Throwable
	{

		try
		{
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			//Step 1:Create Student User from Student Page
			writeReport(User_BusinessFunction.CreateNewStudentHome(), "Create new student",
					"Sucessfully created new student and his credentials are :</br>NewStudentUserName : " +EvolveCommonBussinessFunctions.credentials[0]+"</br>NewStudentPassword : " +EvolveCommonBussinessFunctions.credentials[1],
			"Failed to create new student");	

			studentUserName = EvolveCommonBussinessFunctions.credentials[0];
			studentPassword = EvolveCommonBussinessFunctions.credentials[1];

			User_BusinessFunction.Logout();
			

			//Step 2:Create Faculty User from Faculty Page
			writeReport(User_BusinessFunction.CreateNewFacultyHome(), "create new faculty", 
					"Sucessfully created new faculty and his credentials are :</br>facultyUserName : " +EvolveCommonBussinessFunctions.credentials[0]+"</br>facultyPassword : " +EvolveCommonBussinessFunctions.credentials[1],
			"failed to create new faculty");


			eUseName =EvolveCommonBussinessFunctions.credentials[0];
			ePassword = EvolveCommonBussinessFunctions.credentials[1];


			System.out.println("educator username=>>>>>"+eUseName);
			System.out.println("educator password=>>>>>"+ePassword);

			User_BusinessFunction.Logout();

			//Step 3:Complete all test steps for the following test case
			SelfEnrollLOCourseHomePage_10303_Script S=new SelfEnrollLOCourseHomePage_10303_Script();
			S.SelfEnrollLOCourseHomePage10303();

			selfCourseID=ReadingExcel.columnDataByHeaderName("CourseIDFromSelfEnrollcourse","Tc-10437",testDataPath);	
			enrolledStudent=ReadingExcel.columnDataByHeaderName("selfenrolledStudentusername","Tc-10437",testDataPath);;
			enrolledpassword=ReadingExcel.columnDataByHeaderName("selfenrolledStuentpassword","Tc-10437",testDataPath);;			
			System.out.println("Enrolled UserName===>>>" +enrolledStudent);
			System.out.println("Enrolled Course Id ===>>>" +selfCourseID);
			
			if(selfCourseID!=null)
			{
				Reporters.SuccessReport("get courseID and student credentials already enrolled in course from</br> 'Self enroll into LO course through ecommerce - Home page'","Getting CourseID,username and password of the student already enrolled in this course from</br> 'Self enroll into LO course through ecommerce - Home page'</br>The courseId is : "+selfCourseID+"</br>EnrolledStudentUsername : "+enrolledStudent+"</br>EnrolledStudentPassword : "+enrolledpassword);
			}
			else
			{
				Reporters.failureReport("get courseID and student credentials already enrolled in course from</br> 'Self enroll into LO course through ecommerce - Home page'", "failed to get the courseID and student details");
			}


			//step 4:Verifying that the required page is displayed or not
			List<Map<String, String>> resourceList = Lists.newArrayList();

			Map<String, String> studentMap = Maps.newLinkedHashMap();
			studentMap.put("userName", studentUserName);
			studentMap.put("courserId", selfCourseID);
			studentMap.put("role", "student");

			Map<String, String> falMap = Maps.newHashMap();
			falMap.put("userName",eUseName);
			falMap.put("courserId", selfCourseID);
			falMap.put("role", "instructor");

			Map<String, String> exstingUserName = Maps.newHashMap();
			exstingUserName.put("userName", enrolledStudent);
			exstingUserName.put("courserId", selfCourseID);
			exstingUserName.put("role", "unenroll");

			resourceList.add(studentMap);
			resourceList.add(falMap);
			resourceList.add(exstingUserName);
			Enrollment_10437_Script.verifyingPageDisplay(resourceList);

			Thread.sleep(medium);
			//======Step: 5 Log out of evolve cert as log back in as the student user from Step #1.
			if(User_BusinessFunction.Studentlogin(Enrollments_10437.studentUserName,Enrollments_10437.studentPassword))
			{
				Reporters.SuccessReport("Log out of evolve cert as log back in as the student user from Step #1", "Sucessfully logged into evolve cert as the student user: "+studentUserName);
			}
			else
			{
				Reporters.failureReport("Log out of evolve cert as log back in as the student user from Step #1", "failed to log into the evolvecert as a student from step#1");
			}
			
			Enrollment_10437_Script.processMyEvovle("student");

			if(User_BusinessFunction.Educatorlogin(Enrollments_10437.eUseName,Enrollments_10437.ePassword))

			{
				Reporters.SuccessReport("Log out of evolve cert as log back in as the faculty user from Step #2", "Sucessfully logged into evolve cert as the faculty user: "+eUseName);
			}
			else
			{
				Reporters.failureReport("Log out of evolve cert as log back in as the faculty user from Step #2", "failed to log into the evolvecert as a faculty from step#2");
			}

			Thread.sleep(high);
			Enrollment_10437_Script.processMyEvovle("Faculty");
			
			if(User_BusinessFunction.Studentlogin(Enrollments_10437.enrolledStudent,Enrollments_10437.enrolledpassword))
			{
				Reporters.SuccessReport("Log out of evolve cert as log back in as the Student user from Step #3", "Sucessfully logged into evolve cert as the Student user: "+enrolledStudent);
			}
			else
			{
				Reporters.failureReport("Log out of evolve cert as log back in as the Student user from Step #3", "failed to log into the evolvecert as a student from step#3");
			}

			Thread.sleep(medium);
		
			Enrollment_10437_Script.processMyEvovleForUnenrollUser();




		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
	/*@AfterTest
	public void tear() throws Throwable{
		HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		Base.tearDown();
	}*/

}
