package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EComm_Preorde_rMyEvolve_Page15591_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;

public class EComm_Preorde_MyEvolve_Page15591_Script extends EComm_Preorde_rMyEvolve_Page15591_Bussiness_Functions {
	
	public static final String CINICAL_MEDICAL_ASSISTANT_ONLINE =ReadingExcel.columnDataByHeaderName("product", "TC-15591", testDataPath);
	
	@Test
	public void ECommPreordeMyEvolvePage15591() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		String pubDatePreOrder=ReadingExcel.columnDataByHeaderName("pubDatePreOrder", "TC-15591", testDataPath);
		String pubDatePreOrderStatus=ReadingExcel.columnDataByHeaderName("pubDateStatusPreOrder", "TC-15591", testDataPath);
		String pubDatePostOrder=ReadingExcel.columnDataByHeaderName("pubDatePostOrder", "TC-15591", testDataPath);
		String pubDatePostOrderStatus=ReadingExcel.columnDataByHeaderName("pubDatePostStatus", "TC-15591", testDataPath);
		String cardType=ReadingExcel.columnDataByHeaderName("CardType", "TC-15591", testDataPath);
		String cardNumber=ReadingExcel.columnDataByHeaderName("CardNumber", "TC-15591", testDataPath);
		String cardName=ReadingExcel.columnDataByHeaderName("CardName", "TC-15591", testDataPath);
		String month=ReadingExcel.columnDataByHeaderName("Month", "TC-15591", testDataPath);
		String year=ReadingExcel.columnDataByHeaderName("Year", "TC-15591", testDataPath);
		String cvv=ReadingExcel.columnDataByHeaderName("CVV", "TC-15591", testDataPath);
		
		/*String cardType=readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("student_CardType");
		String cardNumber=readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("student_CardNum");
		String cardName=readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("studentCardName");
		String month=readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("CreditCardMonth");
		String year=readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("CreditCardYear");
		String cvv=readcolumns.twoColumns(0, 1, "Tc-8564(Credit Card Details)", configProps.getProperty("TestData")).get("student_CardCvv");
		*/
		
		adminLogin();
		
		editResource(CINICAL_MEDICAL_ASSISTANT_ONLINE);
		
		modifyPublicatonDate(pubDatePreOrder, pubDatePreOrderStatus);
		
		writeReport(launchUrl(configProps.getProperty("NoCacheURL")), "Run the URL https://evolvecert.elsevier.com/cs/noCache", "Successfully ran the URL https://evolvecert.elsevier.com/cs/noCache", "Failed to run the URL https://evolvecert.elsevier.com/cs/noCache");
		
		Thread.sleep(medium);
		//writeReport(User_BusinessFunction.CreateNewUser("Student"), "Create New Student user", "Successfully created new student user with credentials: <br> Username: "+credentials[0]+"<br> Password : "+credentials[1], "Failed to create a new student account");
		writeReport(Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions.CreateNewUser("student", "ECommPreordeMyEvolvePage15591", "ECommercePreOrder", 2, 1,2,0), "Create New Student user", "Successfully created new student user with credentials: <br> Username: "+credentials[0]+"<br> Password : "+credentials[1], "Failed to create a new student account");
		System.out.println("Creed>>>>"+credentials[0]+","+credentials[1]);
		searchISBNNumber(CINICAL_MEDICAL_ASSISTANT_ONLINE);
		studnetCheckOut(false,CINICAL_MEDICAL_ASSISTANT_ONLINE);
		enterCreditCardData(cardType, cardNumber, cvv, cardName, month, year, CINICAL_MEDICAL_ASSISTING_ONLIN_E);
		acceptAndContinue();
		adminLogin();
		editResource(CINICAL_MEDICAL_ASSISTANT_ONLINE);
		modifyPublicatonDate(pubDatePostOrder,pubDatePostOrderStatus);
		writeReport(launchUrl(configProps.getProperty("NoCacheURL")), "Run the URL https://evolvecert.elsevier.com/cs/noCache", "Successfully ran the URL https://evolvecert.elsevier.com/cs/noCache", "Failed to run the URL https://evolvecert.elsevier.com/cs/noCache");
		
		/*
		User_BusinessFunction.Studentlogin("nuser1241", "abc@123");
		
		verifyOnlineCourseButtons();
		enterAsIndependentSelfStudy();*/
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
