package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.AccessCodePackageUnassignedAccessCodesUpload_10213;
import com.cigniti.automation.BusinessFunctions.AccessCodePackageUnassignedAccessCreation_10212;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.FileDelete;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class AccessCodePackageUnassignedAccessCreation_10212_Script extends AccessCodePackageUnassignedAccessCreation_10212 {
  	
	@Test
	public void accessCodePackageUnassignedAccessCreation_10212() throws Throwable
	{
	try{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		
		stepReport("Login to Evolve Admin.");
		writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials"+ configProps.getProperty("AdminUser"),
                "Launching the URL for User is successful </br > Login to Application Using User credentails :"+configProps.getProperty("AdminUser")+" is Successful",
                   "Launching and Login to Application Using User credentails : "+ configProps.getProperty("AdminUser")+" is Failed");
		
		stepReport("Upload unassigned access codes.");
		if(unassignedAccesscodeLink())
		{
     		Reporters.SuccessReport("Unassigned Access code link ", "Successfully clicked on Unassigned access code link");
		}
		else
		{
			
			Reporters.failureReport("Unassigned Access code link ", "Failed to clicked on Unassigned access code link");
		}
				
		verifyCodeCreation();
		if(clickDownloadAndCompareNotePadDataWithStringliterals())
		{
			Reporters.SuccessReport("Verify Access Codes generated", "Access Codes text file is downloaded and String literals verified successfully in the above step");
			
		}
		else
		{
			Reporters.failureReport("Verify Access Codes generated", "Access Codes text file failed to download and String literals verified failed. ");
			
		}
		
		stepReport("Verify access codes generated successfully.");
		extFileCountAndVerify();
		
		 writeReport(EvolveCommonBussinessFunctions.adminLogout(),"Clicking on Logout",
                 "Clicking on Logout is Successful",
                 "Clicking on Logout is not Successful");
		 FileDelete.deleteFile(downloadFilePath);
	}catch(Exception e){
	System.out.println(e.getMessage());
	FileDelete.deleteFile(downloadFilePath);
	}
}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
