package com.cigniti.automation.Test;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.Admin_BusinessFunction;
import com.cigniti.automation.BusinessFunctions.EComm_Preorde_MyEvolve_Page15594_BussinessFunctions;
import com.cigniti.automation.BusinessFunctions.EComm_Preorder_MyEvolve_Page_15452_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.EComm_Preorder_MyEvolve_Page_15598_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.ECommercePackagependingcourseid_15461;
import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarteFaculty1_15459;
import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarte_Student_SplitOrders1_15597;
import com.cigniti.automation.BusinessFunctions.Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentFaculty_15243;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class Ecomm_Preorder_MyEvolve_Page_15598  extends  ECommercePackagependingcourseid_15461{

	String product1;
	String product2;
	String originalProduct;
	@Test
	public void Ecomm_Preorder_MyEvolve_Page_TC15598() throws Throwable{
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		//Step 1:Complete test cases:  LO Unique Course Fulfillment-Faculty and capture the product id
		//product1 = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15598", configProps.getProperty("TestData")).get("ISBN1");
		//product2 = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC - 15598", configProps.getProperty("TestData")).get("ISBN2");
		 String ISBN1=ReadingExcel.columnDataByHeaderName( "ISBN1", "TC-15598",configProps.getProperty("TestData"));	
		 String ISBN2=ReadingExcel.columnDataByHeaderName( "ISBN2", "TC-15598",configProps.getProperty("TestData"));
		 String Date=ReadingExcel.columnDataByHeaderName( "Date_New", "TC-15598",configProps.getProperty("TestData"));
		 String discount1=ReadingExcel.columnDataByHeaderName("Discount1", "TC-15461", testDataPath);
			String discount2=ReadingExcel.columnDataByHeaderName("Discount2", "TC-15461", testDataPath);
			String streetAddress=ReadingExcel.columnDataByHeaderName("StreetAddress","TC-15588",configProps.getProperty("TestData"));
			String zip=ReadingExcel.columnDataByHeaderName("ZipCode","TC-15588",configProps.getProperty("TestData"));
			String cityAddress=ReadingExcel.columnDataByHeaderName("CityAddress", "TC-15588",configProps.getProperty("TestData"));
			String stateAddress=ReadingExcel.columnDataByHeaderName("StateAddress","TC-15588",configProps.getProperty("TestData"));
			
			String course1=ReadingExcel.columnDataByHeaderName("course1", "TC-15461", testDataPath);
			String course2=ReadingExcel.columnDataByHeaderName("course2", "TC-15461", testDataPath);
			
		 String discountvalue=ReadingExcel.columnDataByHeaderName( "DiscountType1", "TC-15598",configProps.getProperty("TestData"));
		 CreateLOUniqueCourseFaculty_Script_15583 louniqueCourse=new CreateLOUniqueCourseFaculty_Script_15583();
		 
		 louniqueCourse.uniqueCourseLOFaculty("TC-15598",ISBN1, 2);
		 louniqueCourse.uniqueCourseLOFaculty("TC-15598",ISBN2, 3);
		 
		 
		 
			String Processvalue=ReadingExcel.columnDataByHeaderName("Processvalue1", "TC-15598", configProps.getProperty("TestData"));
			String StatuCode=ReadingExcel.columnDataByHeaderName("StatuCodeUpdate1", "TC-15598", configProps.getProperty("TestData"));
		   
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials"+ configProps.getProperty("AdminUser"),
	                "Launching the URL for User is successful </br > Login to Application Using User credentails :"+configProps.getProperty("AdminUser")+" is Successful",
	                   "Launching and Login to Application Using User credentails : "+ configProps.getProperty("AdminUser")+" is Failed");
		   
			
		   writeReport(Admin_BusinessFunction.NavigatetoBusinessProducts(), "Navigating to Basic Product Reports under ONIX PPM Load Data Manager ",  
					                                                          "Navigating to Basic Product Reports under ONIX PPM Load Data Manager is Successful ",
					                                                          "Navigating to Basic Product Reports under ONIX PPM Load Data Manager is failed ");
		
		   writeReport(Admin_BusinessFunction.EditISBNStatusCode(ISBN1, Processvalue,Date,StatuCode), "Editing ISBN : " +ISBN1,  
				   "Entering ISBN "+ISBN+" is successful </br> Selecting "+Processvalue+" is Successful</br> Clicking on Go is Successful </br> Selecting "+StatuCode+" is Successful</br>Entering Date is "+Date+"is Successful </br>Clicking on Edit is Successful</br> 'Product Resource is successfully updated' Message appeared",
                                                                          "Editing ISBN is failed");

		   writeReport(Admin_BusinessFunction.EditISBNStatusCode(ISBN2, Processvalue,Date,StatuCode), "Editing ISBN2 : " +ISBN2,  
				   "Entering ISBN "+ISBN+" is successful </br> Selecting "+Processvalue+" is Successful</br> Clicking on Go is Successful </br> Selecting "+StatuCode+" is Successful</br>Entering Date is "+Date+"is Successful </br>Clicking on Edit is Successful</br> 'Product Resource is successfully updated' Message appeared",
                                                                          "Editing ISBN is failed");

			writeReport(launchUrl(configProps.getProperty("NoCacheURL")), "Run the URL https://evolvecert.elsevier.com/cs/noCache", "Successfully ran the URL https://evolvecert.elsevier.com/cs/noCache", "Failed to run the URL https://evolvecert.elsevier.com/cs/noCache");
			Thread.sleep(3000);
			driver.navigate().back();
		 
		   writeReport(evolveAdminlogin(),"Login to Application Using User Credentials"+adminUser,
	                "Launching the URL for User is successful </br > Login to Application Using User credentails :"+adminUser+" is Successful",
	                   "Launching and Login to Application Using User credentails : "+ adminUser+" is Failed");
			verifyEcommerceLink();
			
			if(inputPackageData()){
	     		Reporters.SuccessReport("Input the Package Data", "The data is correctly entered into the fields");
			}else{			
				Reporters.failureReport("Input the Package Data", "The data is Not correctly entered into the fields");
			}
			
			isbnEntry( ISBN1, discountvalue, discount1);
			ImplicitWait();
			Thread.sleep(3000);
			isbnEntry( ISBN2, discountvalue, discount2);
			ImplicitWait();
			Thread.sleep(3000);
					
			if(crossPromotionTab()){
	     		Reporters.SuccessReport("Validating Cross Promotion Tab", "Successfully clicked on the Cross promotion tab and added the data to the table");
			}else{
				Reporters.failureReport("Validating Cross Promotion Tab", "failed to click on the Cross promotion tab and failed to add the data to the table");
			}
			if(marketingPageTab()){
		 		Reporters.SuccessReport("Validating Marketing Tab", "Marketing tab validations are Successfully Done");
			}else{			
				Reporters.failureReport("Validating Marketing Tab", "Marketing tab validations are failed");
			}
			String user="";
			String checkbox="selectFeatureRadioButton";
			if(ECommercePackagependingcourseid_15461.crossPromoteItems(user, checkbox, "TC-15461", 7)){
		 		Reporters.SuccessReport("Validating Cross Promote Items", "Cross Promote items are Successfully Validated");
			}else{			
				Reporters.failureReport("Validating Cross Promote Items", "Cross Promote items are Validation failed");
			}
			
			Thread.sleep(5000);
			String uniqueMarketingURL=EvolveCommonBussinessFunctions.uniqueUrl;
			System.out.println("URL is:"+uniqueMarketingURL);
			Reporters.SuccessReport("Newly Created URL Details.", "Newly Created URL from the above steps :"+UniqueURL);
			writeReport(Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions.CreateNewUser("student", "eCommPreorderMyEvolvePage15598", "ECommercePreOrder", 8, 1,2,0), "Create New Student user", "Successfully created new student user with credentials: <br> Username: "+credentials[0]+"<br> Password : "+credentials[1], "Failed to create a new student account");
			//User_BusinessFunction.Studentlogin("tuser1243", "abc@123");
			//String url=ReadingExcel.columnDataByHeaderName("uniqueURL", "TC-15461", testDataPath);
		
			//Admin_BusinessFunction.addProduct("","","");
			
			
			
			uniqueMarketingURL=UniqueURL;
			
			Admin_BusinessFunction.launchAndAddtoCart(uniqueMarketingURL,ISBN1,ISBN2,Date);
			
			Admin_BusinessFunction.newstudentBilling("iteration",streetAddress, cityAddress, stateAddress, zip,ISBN1,ISBN2,Date);
			
			Admin_BusinessFunction.verifyMessageInReceiptPage(ISBN1,ISBN2,Date);
			
			String ISBNVALUES=ISBN1+","+ISBN2;
			Thread.sleep(veryhigh);
			Admin_BusinessFunction.VerifyOrderDetais(ISBNVALUES);
		
			String subtotal=ReadingExcel.columnDataByHeaderName("subtotal", "TC_15459", testDataPath);
			String discountPrice=ReadingExcel.columnDataByHeaderName("discount", "TC_15459", testDataPath);	
			String tax=ReadingExcel.columnDataByHeaderName("tax", "TC_15459", testDataPath);
			String total=ReadingExcel.columnDataByHeaderName("total", "TC_15459", testDataPath);
			ECommercePreorderALaCarte_Student_SplitOrders1_15597.verifyOrderPricesHeadings(subtotal,discountPrice,tax,total);
			
			
			writeReport(ECommercePreorderALaCarte_Student_SplitOrders1_15597.getStudentAccountDetails(),"Get Account Details from My Account.",
					"Successfully got the account details from My Account page.",
					"Failed to get the account details from the My Account page.");
			
			
			
			//SwitchToBrowser("chrome");
			writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Login In Into Evolve Email Page.", 
																			  "Successfully login into Evolve Email Page.", 
																			  "Failed to login into Evolve Email Page.");
			String emailid=ECommercePreorderALaCarte_Student_SplitOrders1_15597.getAccountDetailsEmail;
			writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(emailid),"Search email in evolve webmail.",
																"Successfully entered the emailid "+emailid+" in search box.",
																"Failed to enter email id.");
					
		
			Admin_BusinessFunction.ordersVerificationEmailBody(ordernumber1,ordernumber2);
			
			 writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials"+ configProps.getProperty("AdminUser"),
		                "Launching the URL for User is successful </br > Login to Application Using User credentails :"+configProps.getProperty("AdminUser")+" is Successful",
		                   "Launching and Login to Application Using User credentails : "+ configProps.getProperty("AdminUser")+" is Failed");
			
			writeReport(ECommercePreorderALaCarte_Student_SplitOrders1_15597.viewOrEditUserProfile(getAccountDetailsUserName), "Clicking On View/Edit Profile link.", 
					"Successfully Clicked on View/Edit Profile Link.</br>Successfully Entered Username: "+getAccountDetailsUserName+"</br>Sucessfully Clicked On View Profile Search Button.",
					"Failed to click on View/Edit Profile.");
		
	
			writeReport(ECommercePreorderALaCarte_Student_SplitOrders1_15597.orderHistoryInAdmin(), "Clicking On OrderHistory Button.", 
					"Successfully Clicked On Oredr History Button.",
					"Failed To Click On Order History Button.");
			
			Admin_BusinessFunction.cacelPreOrder(ISBN1);
			
			Admin_BusinessFunction.cacelPreOrder(ISBN2);
		
			ECommercePreorderALaCarte_Student_SplitOrders1_15597.evolveBreadCrumb();
			
			ECommercePreorderALaCarte_Student_SplitOrders1_15597.manageAdminstrator();
			
			Processvalue=ReadingExcel.columnDataByHeaderName("Processvalue2", "TC-15598", configProps.getProperty("TestData"));
			 StatuCode=ReadingExcel.columnDataByHeaderName("StatuCodeUpdate2", "TC-15598", configProps.getProperty("TestData"));
			 Date=ReadingExcel.columnDataByHeaderName("Date_Old", "TC-15598",configProps.getProperty("TestData"));
		   
			 ECommercePreorderALaCarte_Student_SplitOrders1_15597.evolveBreadCrumb();
			/* writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials"+ configProps.getProperty("AdminUser"),
	                "Launching the URL for User is successful </br > Login to Application Using User credentails :"+configProps.getProperty("AdminUser")+" is Successful",
	                   "Launching and Login to Application Using User credentails : "+ configProps.getProperty("AdminUser")+" is Failed");*/
		   			
		   writeReport(Admin_BusinessFunction.NavigatetoBusinessProducts(), "Navigating to Basic Product Reports under ONIX PPM Load Data Manager ",  
					                                                          "Navigating to Basic Product Reports under ONIX PPM Load Data Manager is Successful ",
					                                                          "Navigating to Basic Product Reports under ONIX PPM Load Data Manager is failed ");
		
		   writeReport(Admin_BusinessFunction.EditISBNStatusCode(ISBN1, Processvalue,Date,StatuCode), "Editing ISBN : " +ISBN1,  
				   "Entering ISBN "+ISBN1+" is successful </br> Selecting "+Processvalue+" is Successful</br> Clicking on Go is Successful </br> Selecting "+StatuCode+" is Successful</br>Entering Date is "+Date+"is Successful </br>Clicking on Edit is Successful</br> 'Product Resource is successfully updated' Message appeared",
                                                                         "Editing ISBN is failed");

		   writeReport(Admin_BusinessFunction.EditISBNStatusCode(ISBN2, Processvalue,Date,StatuCode), "Editing ISBN2 : " +ISBN2,  
				   "Entering ISBN "+ISBN2+" is successful </br> Selecting "+Processvalue+" is Successful</br> Clicking on Go is Successful </br> Selecting "+StatuCode+" is Successful</br>Entering Date is "+Date+"is Successful </br>Clicking on Edit is Successful</br> 'Product Resource is successfully updated' Message appeared",
                                                                         "Editing ISBN is failed");

			writeReport(launchUrl(configProps.getProperty("NoCacheURL")), "Run the URL https://evolvecert.elsevier.com/cs/noCache", "Successfully ran the URL https://evolvecert.elsevier.com/cs/noCache", "Failed to run the URL https://evolvecert.elsevier.com/cs/noCache");
			Thread.sleep(3000);
			driver.navigate().back();
	}
}
