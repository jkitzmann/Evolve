package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class KNOACfromHomePage_NewInstructor_Script_15235 extends EvolveCommonBussinessFunctions {
	@Test
	public void KNOACHomePagNewInstructor_15235() throws Throwable{
	try{
		stepReport("Login to Evolve Admin");
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		if(evolveAdminlogin()){
			Reporters.SuccessReport("Login to Application Using Admin Credentials"+adminUser,"Launching the URL for Admin is successful </br > Login to Application Using Admin credentials :"+adminUser+" is Successful");
		}
		else{
			Reporters.failureReport("Login to Application Using Admin Credentials"+adminUser,"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");
		}
		
		stepReport("Create access code for KNO product");
		EvolveCommonBussinessFunctions.maintainProduct();
		createAccessCode();
		
		EvolveCommonBussinessFunctions.manageAccessCode();
		if(adminLogout()){
			Reporters.SuccessReport("Admin logout as "+adminUser,"Successfully logged out "+adminUser+" admin page.");
		}
		else{
			Reporters.failureReport("Admin logout as "+adminUser,"Failed To log out "+adminUser+" admin page.");
		} 
		
		stepReport("Create new instructor user");
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		String user="educator";
		EvolveCommonBussinessFunctions.CreateNewUser(user);
		
		stepReport("Submit access code through catalog page and enter checkout");
		pageBurstReedem();
		String name="KNO";
		String accessCode="true";
		String knoUser="newuser";
		stepReport("Complete checkout and submit order");
		updateVSTandKNOAccount(user,name,accessCode,knoUser);
		AccessCodeReviewandSubmit();
		
		stepReport("Verify KNO Library link in My Evolve");
		knoLibrary(user,knoUser);
		if(instructorLogout()){
			Reporters.SuccessReport("Logout Instructor:"+credentials[0], "Successfully logged out Instructor "+credentials[0]);
		}
		else{
			Reporters.failureReport("Logout Instructor:"+credentials[0], "Failed to logout Instructor "+credentials[0]);
		}
		
		stepReport("Login to Evolve Admin");
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		if(evolveAdminlogin()){
			Reporters.SuccessReport("Login to Application Using Admin Credentials"+adminUser,"Launching the URL for Admin is successful </br > Login to Application Using Admin credentials :"+adminUser+" is Successful");
		}
		else{
			Reporters.failureReport("Login to Application Using Admin Credentials"+adminUser,"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");
		}
		
		stepReport("Verify the access code status is Redeemed");
		adminAccessCodeSearch();
		if(adminLogout()){
			Reporters.SuccessReport("Admin logout as "+adminUser,"Successfully logged out "+adminUser+" admin page.");
		}
		else{
			Reporters.failureReport("Admin logout as "+adminUser,"Failed To log out "+adminUser+" admin page.");
		}
		
		stepReport("Verify the access code cannot be used again");
		SwitchToBrowser(ElsevierObjects.studentBrowserType);
		reLogingForAccessCodeRedeem();
		String StudentUserName=readcolumns.twoColumns(0, 1, "Tc-15228", configProps.getProperty("TestData")).get("StudentUser");
		if(instructorLogout()){
			Reporters.SuccessReport("Logout Student Page.", "Successfully logged out Student page:"+StudentUserName);
		}
		else{
			Reporters.failureReport("Logout Student Page.", "Failed to logout Student page:"+StudentUserName);
		}
	}
	catch(Exception e){
		System.out.println(e);
	}

}
@AfterTest
public void tear() throws Throwable{
	//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
	//Base.tearDown();
}
	
}


