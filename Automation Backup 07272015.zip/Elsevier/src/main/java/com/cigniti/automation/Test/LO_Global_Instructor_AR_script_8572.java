package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentFaculty_15243;
import com.cigniti.automation.BusinessFunctions.LO_GlobalStudent_8571;
import com.cigniti.automation.BusinessFunctions.LO_Global_Instructor_AR_8572;
import com.cigniti.automation.BusinessFunctions.LO_Unique_CourseFulfillment_Faculty_10410;
import com.cigniti.automation.BusinessFunctions.SelfEnrollLOCourseHomePage_10303;
import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class LO_Global_Instructor_AR_script_8572 extends LO_Global_Instructor_AR_8572{
	
	@Test
	public void lO_Global_Instructor_AR_8572() throws Throwable{
		try{
			String ISBNProduct=readcolumns.twoColumns(0, 1, "TC-9826 & 8572", configProps.getProperty("TestData")).get("Educatorsearch_Num");
			String courseID=readcolumns.twoColumns(0, 1, "TC-9826 & 8572", configProps.getProperty("TestData")).get("CourseID");
			String courseTitle=readcolumns.twoColumns(0, 1, "TC-9826 & 8572", configProps.getProperty("TestData")).get("Educator_course_Title");
			
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());

			
			stepReport("Create new instructor user");
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			
			writeReport(EvolveCommonBussinessFunctions.CreateNewUser("educator"),"Creating Faculty User From Faculty Page.", 
					"Successfuully Created New Faculty User Username:"+credentials[0]+",Password:"+credentials[1]+"</br>User Now logged Into Evolve Cert As A Faculty.",
					"Failed To Create New Faculty User.");

			stepReport("Search for product and add to cart");
			writeReport(EvolveCommonBussinessFunctions.searchProduct(ISBNProduct,productCost),"Search for the product..",
					  "Successfully Entered ISBN:"+product+" in Search Box.</br>Clicked On Go Button.</br>Navigated To Product Details Page.",
					  "Failed to Enter ISBN:"+product+" in Search Box.");
			
			writeReport(EvolveCommonBussinessFunctions.requestProduct(),"Clicking on the  Register For This Product Button In Product Details Page.",
					"Successfully clicked on Register For This Product Button.",
					"Failed to click on  Register For This Product Button.");
			
			stepReport("Verify my cart and enter checkout");
			myCart();
			
			stepReport("Complete checkout and submit order");
			EvolveCommonBussinessFunctions.updateVSTandKNOAccount("educator","","","");
		
			if(reviewAndSubmit()){
				Reporters.SuccessReport("Submitting The Order In Review Page.","Clicked On CheckBoxes And Submitted The Order.");
			} else {
				Reporters.failureReport("Submitting The Order In Review Page.","Failed To Click On CheckBoxes And Failed To Submit The Order.");
			}
			
			
			stepReport("Verify receipt page");
			LO_GlobalStudent_8571.receiptPage();
		
			getAccountDetails();
			
			if(instructorLogout()){
				Reporters.SuccessReport("Logout Educator ","Successfully logged out Educator.");
			} else {
				Reporters.failureReport("Logout Educator ","Failed to log out Educator");					
			}
			
			stepReport("Verify email");
			writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Login In Into Evolve Email Page.", 
					  "Succesfully login into Evole Email Page.", 
					  "Failed to login into Evolve Email Page.");
			
			String emailid=EvolveCommonBussinessFunctions.getAccountDetailsEmail;
			writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(emailid),"Search email in evolve webmail.",
													"Successfully entered the emailid "+emailid+" in search box.",
													"Failed to enter email id.");
			
			String emailTitle=readcolumns.twoColumns(0, 1, "TC-9826 & 8572", configProps.getProperty("TestData")).get("educatoremailTitle");
			
			verifyTitleInEmailBody(emailTitle);
			
			stepReport("Login to Evolve Admin");
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(), "Login to Application Using Admin Credentials"+adminUser,
					"Launching the URL for Admin is successful </br > Login to Application Using Admin credentials :"+adminUser+" is Successful", 
					"Launching and Login to Application Using Admin credentials : "+ adminUser+" is Failed");	
			
			stepReport("Verify AR and fulfill it");
			admin_Adoptionsearch();

			verifyPendingStatus();
			writeReport(EvolveCommonBussinessFunctions.getAdoptionRequestDetails(),"Clicking On Adoption Number:"+adoptionRequest_getAdoptionNum+".</br>Fetching Adoption Details of User and Course in Adoption Request Details page",
					   "Adoption Number:"+adoptionRequest_getAdoptionNum+" is On Top Of The Row.</br>Successfully Clicked On "+adoptionRequest_getAdoptionNum+"</br>Successfully Fetched the details of User And Course from Adoption Request Details Page.",
					   "Failed To Click On Adoption Number:"+adoptionRequest_getAdoptionNum+"</br>Failed to Fetch the details of User And Course from Adoption Request Details Page.");
			
			String format=readcolumns.twoColumns(0, 1, "TC-9826 & 8572", configProps.getProperty("TestData")).get("formatInAdoptionPage");
			verifyUserDetails(format);
			writeReport(EvolveCommonBussinessFunctions.adminLogout(), "Admin logout as "+adminUser,
					"Successfully logged out admin page.", 
				  	"Failed to logout admin page.");	
			
			stepReport("Log back in to instructor account");
			writeReport(User_BusinessFunction.Educatorlogin(credentials[0],credentials[1]),"Relogin Into Educator Page.",
					"Successfully Logged Into Educator :"+credentials[0]+" Page.",
					"Failed To Login Into Educator Page.");
			
			stepReport("Verify course ID is included in My Evolve");
			educator_courseId_search(courseID,courseTitle);
			if(instructorLogout()){
				Reporters.SuccessReport("Logout Educator ","Successfully logged out Educator.");
			} else {
				Reporters.failureReport("Logout Educator ","Failed to log out Educator");					
			}			
		}
		catch(Exception e){
			System.out.println(e);
		}
	
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
	
}

