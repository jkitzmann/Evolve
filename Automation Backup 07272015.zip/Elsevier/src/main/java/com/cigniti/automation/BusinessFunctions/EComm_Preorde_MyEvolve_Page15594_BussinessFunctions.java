package com.cigniti.automation.BusinessFunctions;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class EComm_Preorde_MyEvolve_Page15594_BussinessFunctions extends Ecomm_Preorder_MyEvolve_Common_Bussiness_Functions {

	@Override
	public boolean createAccessCode(String isbnNumber) throws Throwable {
		
		boolean flag =true;
		try{
			if(click(ElsevierObjects.EVOLVE_BUTTON, "Evolve Button")){
				Reporters.SuccessReport("Click on Evolve Admin link in the breadcrumb ", "Successfully Clicked on Evolve Admin link in the breadcrumb ");
			}else{
				Reporters.failureReport("Click on Evolve Admin link in the breadcrumb ", "Successfully Clicked on Evolve Admin link in the breadcrumb ");
			}
			if(click(ElsevierObjects.maintainProd, "Maintain Products.")){
				Reporters.SuccessReport("Click  on Maintain Products.  ", "Successfully Clicked  on Maintain Products.  ");
			}else{
				Reporters.failureReport("Click  on Maintain Products.  ", "Failed to Click  on Maintain Products.  ");
			}
			if(type(ElsevierObjects.searchTitle,isbnNumber,"ISBN")){
				Reporters.SuccessReport("Search for the ISBN ", "Successfully entered ISBN "+isbnNumber+" into the search box");
			}else{
				Reporters.failureReport("Search for the ISBN ", "Failed to enter ISBN "+isbnNumber+" into the search box");
			}
			if(!click(ElsevierObjects.btnserchTitle,"ISBN Number")){
				flag =false;
			}
			
			if(click(By.xpath("//a[text()='"+isbnNumber+"']"), "Create Acess Code")){
				Reporters.SuccessReport("Click on the Create Access Code tab.", "Successfully Clicked on the Create Access Code tab.");
			}else{
				Reporters.failureReport("Click on the Create Access Code tab.", "Failed to Click on the Create Access Code tab.");
			}
			Thread.sleep(medium);
			super.createAccessCode();
			
			if(isElementPresent(ElsevierObjects.DOWNLOAD_ACCESS_CODE,"Download Access Code")){
				Reporters.SuccessReport("Verify Access Code Message", "The Access Code Set was successfully created");
				Reporters.SuccessReport("Verify Download Access Code Link", "Click here to download the access codes was displayed success fully");
			}
			else{
				Reporters.failureReport("Verify Access Code Message", "Unable to Create Access Code for given ISBN Number"+isbnNumber);
				Reporters.failureReport("Verify Download Access Code Link", "unable to display the Click here to download the access codes link ");
			}
			
			
			
			if(!click(ElsevierObjects.DOWNLOAD_ACCESS_CODE, "Download Access Code")){
				flag =false;
			}
			if(!click(ElsevierObjects.DOWNLOAD_ACCESS_CODE_TXT, "Download Access Code Text.")){
				flag =false;
			}
			
			System.out.println("Admin browser: " + ElsevierObjects.adminBrowserType);
			System.out.println("Student browser: " + ElsevierObjects.studentBrowserType);
			
			Thread.sleep(high);
			if(ElsevierObjects.adminBrowserType.equalsIgnoreCase("ie")){
				r = new Robot();
				r.keyPress(KeyEvent.VK_ALT);
				r.keyPress(KeyEvent.VK_S);
				r.keyRelease(KeyEvent.VK_S);
				r.keyRelease(KeyEvent.VK_ALT);
				Thread.sleep(low);
	
				//If browser type other than 'IE'. 
			}
			//If browser type is Firefox, 
			else  
				//if(configProps.getProperty("browserType").equalsIgnoreCase("firefox")){
				if(ElsevierObjects.adminBrowserType.equalsIgnoreCase("firefox")){
					r = new Robot();
					r.keyPress(KeyEvent.VK_DOWN);
					r.keyPress(KeyEvent.VK_TAB);
					r.keyPress(KeyEvent.VK_TAB);
					r.keyPress(KeyEvent.VK_TAB);
					Thread.sleep(low);
					r.keyPress(KeyEvent.VK_ENTER);
				}
	
				  
			
			
			Thread.sleep(medium);
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}
		return flag;
	}
	
	public static boolean courseDetailsPage(By courseLink, String user) throws Throwable{
		boolean flag=true;
		try{
			driver.navigate().refresh();
			if(click(ElsevierObjects.Myevolve,"Click on my evolve")){
				Reporters.SuccessReport("Click on My Evolve link", "Successfully clicked on My Evolve Link");
			}else{
				Reporters.failureReport("Click on My Evolve link", "Failed to click on My Evolve Link");
			}
			String knoLibraryLink=getText(courseLink, "Course library link");
			if(click(courseLink, "Click on course link")){
				Reporters.SuccessReport("Verifying course Link And Clicking Course link.", "Successfully Verified Course link in My Evolve Page: "+knoLibraryLink+"</br>Successfully clicked on Course link.");
			}else{
				Reporters.failureReport("Verifying Course link And Clicking On Course link.", "Failed to Verify Course link in My Evolve Page: "+knoLibraryLink+"</br>Failed To click on Course link.");
			}
			Thread.sleep(60000);
		//driver.manage().timeouts().implicitlyWait(400, TimeUnit.SECONDS);
			//Thread.sleep(200000);
			if(user.equalsIgnoreCase("contentHome")){
				Thread.sleep(medium);
				driver.navigate().refresh();
				driver.navigate().refresh();
				//driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
				if( javaClick(ElsevierObjects.educator_CoursePage_CourseContentLink, "Click on Course content link in course details page.")){
					Reporters.SuccessReport("Clicking On Course Link in course Details page.", "Clicked On Course Link in Course Details page.");
				}
				else{
					Reporters.failureReport("Clicking On Course Link in course Details page.", "Failed To Click on Course link in Details page.");
				}
				driver.navigate().refresh();
				
				Thread.sleep(medium);
				List<WebElement> s=driver.findElements(ElsevierObjects.educator_CoursePage_SubFolders);
				for(WebElement subFolder:s){

					if(isElementPresent(ElsevierObjects.educator_CoursePage_SubFolders, "Course folder contains sub folders.")){
						Reporters.SuccessReport("Verifying subfolders.", "Verified Subfolders of Course Folder.</br>SubFolder is:"+subFolder.getText());
					}
					else{
						Reporters.failureReport("Verifying subfolders.", "Failed To Verify Subfolders of Course Folder.");
					}
				}
			}else{
				driver.navigate().refresh();
				if( click(ElsevierObjects.educator_CoursePage_CourseLink, "Click on Course content link in course details page.")){
					Reporters.SuccessReport("Clicking On Course Link in course Details page.", "Clicked On Course Link in Course Details page.");
				}else{
					Reporters.failureReport("Clicking On Course Link in course Details page.", "Failed To Click on Course link in Details page.");
				}
				Thread.sleep(medium);
				String protectedMessage=getText(By.xpath(".//*[@id='ajax-modal']/div[2]/p"), "Protected Content Message");
				if(protectedMessage!=null){
					Reporters.SuccessReport("Verify the user is not able to access the folders and subfolders within the course(having lock icon).", "User is not able to access the folders and subfolders within the course(having lock icon). <br> Protected Message is Printed : "+protectedMessage);
				}else{
					Reporters.failureReport("Verify the user is not able to access the folders and subfolders within the course(having lock icon).", "User is able to access the folders and subfolders within the course(having lock icon).");
				}
			}


		}
		catch(Exception e)
		{
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		return false;
		}
		return flag;  
	}
	
	
	
	
	
}
