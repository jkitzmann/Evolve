package com.cigniti.automation.BusinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
public class EcommercePreorder_OrderHistory_15475 extends EvolveCommonBussinessFunctions{
	
	public static boolean manageAdministrators()
			throws Throwable {
		boolean flag = true;
		try
		{
		Thread.sleep(medium);
		if (!click(ElsevierObjects.manageAdmin, "Manage Administrators")) {
			flag = false;
		}
		
		if (!waitForElementPresent(ElsevierObjects.testadmin, "testadmin")) {
			flag = false;
		}
		Thread.sleep(medium);
		if (!click(ElsevierObjects.testadmin, "testadmin")) {
			flag = false;
		}
		Thread.sleep(medium);
		if (!click(ElsevierObjects.managePrivileges, "Manage Privileges")) {
			flag = false;
		}
		Thread.sleep(medium);
		if (!click(ElsevierObjects.maintainPPMChkBox, "Manage Privileges")) {
			flag = false;
		}
		Thread.sleep(medium);
		if (!click(ElsevierObjects.rolesSaveBtn, "Manage Privileges")) {
			flag = false;
		}
		Thread.sleep(medium);
		if (!click(ElsevierObjects.adminSaveBtn, "Manage Privileges")) {
			flag = false;
		}
		driver.navigate().refresh();
		if (!waitForElementPresent(ElsevierObjects.evolveadminLnk, "testadmin")) {
			flag = false;
		}
		Thread.sleep(medium);
		if (!click(ElsevierObjects.evolveadminLnk, "Manage Privileges")) {
			flag = false;
		}
		}
		catch(Exception e)
		{

			sgErrMsg=e.getMessage();

			return false;
		}
			return flag;
	}
	
	
	//ONIX PPM Load Data Manager page
	public static boolean baseProductResource(String product, String editResource, String publicationDate,String publishingStatus )
			throws Throwable {
		boolean flag = true;
		try
		{
		Thread.sleep(medium);
		if (!click(ElsevierObjects.baseProductResourceLnk, "BaseProductResource")) {
			flag = false;
		}
		if(!type(ElsevierObjects.baseProductResKey, product, "Search for product : "+product)){
			flag = false;
		}
		if(!selectByVisibleText(ElsevierObjects.editResourceSelect, editResource, "Select EditResource.")){
			flag = false;
		}
		Thread.sleep(300);	
		if (!click(ElsevierObjects.goBtn, "Go Button")) {
			flag = false;
			
		}
		Thread.sleep(medium);
		if(!type(ElsevierObjects.publicationDateTxt, publicationDate, "publicationDate : "+publicationDate)){
			flag = false;
		}
		if(!selectByVisibleText(ElsevierObjects.publishingStatusSelect, publishingStatus, "publishingStatusSelect")){
			flag = false;
		}
		if (!click(ElsevierObjects.resourceEditBtn, "Edit Button")) {
			flag = false;
			
		}	
		}
		catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}
			return flag;
		}
	
	
	//Search Product.
		public static boolean baseProductResource() throws Throwable{
			try
			{
			String product = readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-15475", configProps.getProperty("TestData")).get("Product"); 	
			String editResource=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-15475", configProps.getProperty("TestData")).get("EditResource"); 
			String publicationDate=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-15475", configProps.getProperty("TestData")).get("PublicationDate"); 
			String publishingStatus=readcolumns.twoColumnsBasedOnSheetName(0, 1, "TC-15475", configProps.getProperty("TestData")).get("PublishingStatus");			
			return baseProductResource(product,editResource,publicationDate,publishingStatus);
		}catch(Exception e)
		{
			sgErrMsg=e.getMessage();

			return false;

		}
		}
			
		
		
		
		//student LogIn 
		public static boolean studentLoginGeneral() throws Throwable{
			boolean flag = true;
			try
			{
			driver.manage().deleteAllCookies();
			//driver.navigate().refresh();
			if(!launchUrl(configProps.getProperty("URL"))){
				flag = false;
			}
			Thread.sleep(medium);
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			if(!clickOnMainPageLink()){
				flag=false;
			}
			if(!click(ElsevierObjects.home_student_lnkstudent,"Clicked On student Link")){
				flag = false;
			}
			if(!click(ElsevierObjects.student_login,"Clicked On student LogIn")){
				flag = false;
			}
			if(!type(ElsevierObjects.email,configProps.getProperty("StudentUser"),"Email")){
				flag = false;
			}
			if(!type(ElsevierObjects.password,configProps.getProperty("StudentPassword"),"Email")){
				flag = false;
			}
			if(!click(ElsevierObjects.submit,"Clicked on Login Button")){
				flag = false;
			}
			if(!click(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Search Results catalogue")){
				flag = false;
			}
			if(!click(ElsevierObjects.myAccountmenu,"Clicked on My accounts menu")){
				flag = false;
			}
			if(!click(ElsevierObjects.orderHistorylnk,"Clicked Order History link")){
				flag = false;
			}
			}
			catch(Exception e)
			{
				sgErrMsg=e.getMessage();

				return false;

			}
			return flag;
		}	
	
}