package com.cigniti.automation.Utilities;

import java.util.Calendar;

import com.cigniti.automation.accelerators.Actiondriver;
import com.cigniti.automation.accelerators.Base;

public class Reporters extends Base{

	public static Property configProps=new Property("config.properties");
	static String  timeStamp=Accessories.timeStamp().replace(":", "_").replace(".", "_");

	public static void reportCreater() throws Throwable{
		int intReporterType=Integer.parseInt(configProps.getProperty("reportsType"));

		switch (intReporterType) {
		case 1:
			//ExcelReporter.excelTestReportCreator();
			break;
		case 2:
			
			HtmlReporters.htmlCreateReport();
			HtmlReporters.createDetailedReport();

			break;
		default:
			//ExcelReporter.excelTestReportCreator();
			HtmlReporters.htmlCreateReport();
			break;
		}
	}

	public static void SuccessReport(String strStepName, String strStepDes) throws Throwable{
		int intReporterType=Integer.parseInt(configProps.getProperty("reportsType"));
		switch (intReporterType) {
		case 1:

			break;
		case 2:
			if(configProps.getProperty("OnSuccessScreenshot").equalsIgnoreCase("True"))
			{
			Actiondriver.screenShot(Base.filePath()+strStepName.replace(" ", "_").replace(":", "_").replace("</br>", "_").replace("-","_")+"_"+Base.timeStamp+".jpeg");
			}
			HtmlReporters.onSuccess(strStepName, strStepDes);

			break;

		default:
			if(configProps.getProperty("OnSuccessScreenshot").equalsIgnoreCase("True"))
			{
			Actiondriver.screenShot(Base.filePath()+strStepName.replace(" ", "_").replace(":", "_").replace("</br>", "_").replace("-","_")+"_"+Base.timeStamp+".jpeg");
			}
			HtmlReporters.onSuccess(strStepName, strStepDes);
			break;
		}
	}	

	public static void failureReport(String strStepName, String strStepDes) throws Throwable{
		int intReporterType=Integer.parseInt(configProps.getProperty("reportsType"));
		switch (intReporterType) {
		case 1:
			flag= true;
			break;
		case 2:
			
			//Actiondriver.screenShot(Base.filePath()+strStepName.replace(" ", "_").replace(":", "_").replace("</br>", "_")+"_"+Base.timeStamp+Calendar.getInstance().getTime()+".jpeg");
			Actiondriver.screenShot(Base.filePath()+strStepName.replace(" ", "_").replace(":", "_").replace("</br>", "_")+"_"+Base.timeStamp+".jpeg");
			//Actiondriver.screenShot(Base.filePath()+strStepDes.replaceAll("@#%^&*()","_")+"_"+Base.timeStamp+".jpeg");
			//.replace("#", "_").replace("*", "_").replace(".", "_")
			flag= true;
			HtmlReporters.onFailure(strStepName, strStepDes);

			break;

		default:
			flag =true;
			//Actiondriver.screenShot(Base.filePath()+strStepName.replace(" ", "_").replace(":", "_").replace("</br>", "_")+"_"+Base.timeStamp+Calendar.getInstance().getTime()+".jpeg");	
			Actiondriver.screenShot(Base.filePath()+strStepName.replace(" ", "_").replace(":", "_").replace("</br>", "_")+"_"+Base.timeStamp+".jpeg");				
			HtmlReporters.onFailure(strStepName, strStepDes);
			break;
		}
		//JiraConnector.invokePostMethod(new String(Base64.encode("vnallani:Ctl@1234")), "http://localhost:8888/rest/api/2/issue", "{\"fields\":{\"project\":{\"key\":\"TEST\"},\"summary\":\""+strStepName+"\",\"issuetype\":{\"name\":\"Bug\"}}}");
	}
}
