package com.cigniti.automation.Test;

import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.User_BusinessFunction;
import com.cigniti.automation.BusinessFunctions.VitalSourceAccountAC_HomePage_StudentExists_VST;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;


public class VitalSourceAccountAC_HomePage_StudentExists_VST_Script_15222 extends VitalSourceAccountAC_HomePage_StudentExists_VST {
	
	@Test 
	public void vitalSourceAccountAC_HomePage_StudentExists_VST_15222() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String username1=ReadingExcel.columnDataByHeaderName( "VST_StudentUsername", "VST",configProps.getProperty("TestData"));
			String password1=ReadingExcel.columnDataByHeaderName( "VST_StudentPassword", "VST",configProps.getProperty("TestData"));
			
			String user1="";
			
			String username=readcolumns.twoColumns(0,1, "VSTPageBurstCredentials", configProps.getProperty("TestData")).get("VitalSourceAccountPageburstCCNewStudent15561");
			String password=readcolumns.twoColumns(0,2, "VSTPageBurstCredentials", configProps.getProperty("TestData")).get("VitalSourceAccountPageburstCCNewStudent15561");
			writeReport(login(user1,username, password), "Login into Existing Student", "Successfully logged into the Student with the credentials: <br/> Username : "+username+"<br/> Password : "+password, "Failed to log into the application");
			Thread.sleep(medium);
			
			if(pageBurstReedem1()){
				Reporters.SuccessReport("Page burst Reddem access page", "Succesfully navigated to page burst reedeem access page");
			}
			else{
				Reporters.failureReport("Page burst Reddem access page", "Failed to navigated to page burst reedeem access page");
			}
			
			if(accessCodeAccountUpdateVST()){
				Reporters.SuccessReport("Update VSTandKNO Account", "Succesfully updated User account");
			}
			else{
				Reporters.failureReport("Update VSTandKNO Account", "Failed to update User account");
			}
			String user = "student";
			if(AccessCodeReviewandSubmitVST(user)){
				Reporters.SuccessReport("Access Code review and submit page", "Succesfully navigated to review and submit page.");
			}
			else{
				Reporters.failureReport("Access Code review and submit page", "Failed to navigated to review and submit page.");
			}
			String accessCodeUser = "student";
			String condition="existingStudEducator";
			
			pageburstVstLink(accessCodeUser,acessCode_titleAfterRequest,"validTitle");
			if(instructorLogout())
			{
				Reporters.SuccessReport("Student Log out:", "Student Loged Out Successfully");
			}
	       else{
				Reporters.failureReport("Student Log out:", "Student Log out Failed."); 
			}
			
			reLogingForAccessCodeRedeem(username1,password1);
			ReadingExcel.removeUsedVSTCode(VSTDataPath, "VSTCodes");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			ReadingExcel.removeUsedVSTCode(VSTDataPath, "VSTCodes");
		}
	}
	@AfterTest
	public void closeBrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
	
}
