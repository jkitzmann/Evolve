package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EcommercePKGCrossPromoteExclusions5_15560;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class EcommercePKGCrossPromoteExclusions5_15560_Script extends EcommercePKGCrossPromoteExclusions5_15560 {
	@Test
	public void ecommercePKGCrossPromoteExclusions5_15560() throws Throwable
	{
		try{
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
			//ElsevierObjects.adminBrowserType="chrome";
			stepReport("Login to Evolve Admin");
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			writeReport(evolveAdminlogin(),"Login to Application Using User Credentials"+adminUser,
                    "Launching the URL for User is successful </br > Login to Application Using User credentails :"+adminUser+" is Successful",
                       "Launching and Login to Application Using User credentails : "+ adminUser+" is Failed");
			
			stepReport("Verify UI of the add ecom package page");
			verifyEcommerceLink();
			
			if(viewTopViewAddPakage())
			{
	     		Reporters.SuccessReport("Validate the 'Package Items section' of the page ", "All fields are available in Package item section");
			}
			else
			{	
				Reporters.failureReport("Validate the 'Package Items section' of the page ", "All fields are not available in Package item section");
			}
			
			cloneEnabled();
			
			stepReport("Create and save the package details");
			if(inputPackageData())
			{
	     		Reporters.SuccessReport("Input the Package Data", "The data is correctly entered into the fields");
			}
			else
			{
				
				Reporters.failureReport("Input the Package Data", "The data is Not correctly entered into the fields");
			}
			
			stepReport("Add ISBNs to the package");
			verifyAndAddISBNPackages();
			
			stepReport("Add specific product type discount through Cross Promotions tab");
			if(crossPromotionTab())
			{
				Reporters.SuccessReport("Promotion Tab", "The data is correctly entered into the fields");
			}
			else
			{

				Reporters.failureReport("Promotion Tab", "The data is correctly entered into the fields");
			}

			verifyExcludeProducts();

			Reporters.SuccessReport("Validate the Profit Center section.", "Validate the Profit Center section");
			if(validateProfitCenter())
			{
				Reporters.SuccessReport("Validating Profit Center", "Cross Promotion Exclusions are Successfully Done");
			}
			else
			{

				Reporters.failureReport("Validating Profit Center", "Cross Promotion Exclusions are failed");
			}

			Reporters.SuccessReport("Validate the Major Subject Code section.", "Validate the Major Subject Code section.");
			if(validateMajorSubjectCodeSection())
			{
				Reporters.SuccessReport("Validating Major Subject Code Center", "Cross Promotion Exclusions are Successfully Done");
			}
			else
			{

				Reporters.failureReport("Validating Major Subject Code Center", "Cross Promotion Exclusions are failed");
			}

			Reporters.SuccessReport("Validate the Product Type section.", "Validate the Product Type section.");
			if(validateProductTypeCodeSection())
			{
				Reporters.SuccessReport("Validating Product Type Code Center", "Cross Promotion Exclusions are Successfully Done");
			}
			else
			{

				Reporters.failureReport("Validating Product Type Code Center", "Cross Promotion Exclusions are failed");
			}

			Reporters.SuccessReport("Validate the ISBN Type section.", "Validate the ISBN Type section.");
			if(validateISBNSection())
			{
				Reporters.SuccessReport("Validating ISBN Center", "Validating ISBN Section Successfully Done");
			}
			else
			{

				Reporters.failureReport("Validating ISBN Center", "Validating ISBN Section Failed");
			}

			Reporters.SuccessReport("Validate the ISBN Upload Type.", "Validate the ISBN Type section.");
			if(uploadCSVFile())
			{
				Reporters.SuccessReport("Upload CSV File", "CSV file upload Successfully Done");
			}
			else
			{

				Reporters.failureReport("Upload CSV File", "CSV file upload Failed");
			}
			if(validateUploadISBNSection())
			{
				Reporters.SuccessReport("Validate Upload CSV Section", "CSV File Upload Section validation is Successfully Done");
			}
			else
			{

				Reporters.failureReport("Validate Upload CSV Section", "CSV File Upload Section validation is failed");
			}

			Thread.sleep(medium);

			if(adminLogout()){	

				Reporters.SuccessReport("Logout Successful", "Successfully logout from admin");
			}
			else
			{

				Reporters.failureReport("Logout Successful", "logout failed from admin");
			}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	/*@AfterTest
	public void closeBtrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		Base.tearDown();
	}*/
}
