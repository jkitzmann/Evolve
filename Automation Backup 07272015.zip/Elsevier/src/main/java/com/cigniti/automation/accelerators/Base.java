package com.cigniti.automation.accelerators;

import java.awt.Desktop;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Accessories;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.MyListener;
import com.cigniti.automation.Utilities.Property;
import com.cigniti.automation.Utilities.ReadColumns;
//
//import com.cigniti.automation.utilities.Accessories;
//import com.cigniti.automation.utilities.HtmlReporters;
//import com.cigniti.automation.utilities.MyListener;
//import com.cigniti.automation.utilities.Property;
//import com.cigniti.automation.utilities.Reporters;
//import com.cigniti.automation.utilities.SendMail;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.Utilities.SendMail;
import com.cigniti.automation.datadriven.ReadResourceData;


public class Base 
{
	public static ReadColumns readcolumns=new ReadColumns();
	public static Property configProps=new Property("config.properties");
	public static Property configdata=new Property("Testdata.properties");
	public static String currentSuite="";
	public static String method="";
	public static String timeStamp=Accessories.timeStamp().replace(" ","_").replace(":","_").replace(".", "_");
	public static boolean flag =false;
	public static WebDriver webDriver;
	public static EventFiringWebDriver driver;
	//public static Integer count=1;
	public static String result=null;
	public static String mesg=null;
	public static String TESTCASENAME="";
	public static String url = "jdbc:mysql://172.16.6.121/";
	public static String dbName = "test";
	public static String userName = "root";
	public static Connection conn = null;
	public static Statement stmt = null;
	public static PreparedStatement pstmt = null;
	public static ResultSet rs = null;
	public static int count=1;
	public static int x=0;
	public static String timeStampBeforeSutie = Accessories.timeStamp().replace(" ","_").replace(":","_").replace(".", "_");
	static String browser=null;
	static int len=0;
	static int i=0;
	protected static int j=0;
	static	 ITestContext itc;
	public static long timeStampBeforeExecution;
	
	/**
	 *Initializing browser requirements, Test Results file path and Database requirements from the configuration file
	 * @Date  19/02/2013
	 * @Revision History
	 * 
	 */

	
	@BeforeSuite(alwaysRun = true) 	
	public static void setupSuite(ITestContext ctx) throws Throwable {
		itc=ctx;
		String strBrowserType[];
		Accessories.calculateSuiteStartTime();
		timeStampBeforeExecution=System.currentTimeMillis() ;

		
		browser=configProps.getProperty("browserType");

		if(!(browser.toString().contains(",")))
		{
			strBrowserType=new String[]{browser};
		}
		else
		{
			strBrowserType=browser.split("\\,");
		}
		len =strBrowserType.length;
		while(i<len)

		{
			String browserType=strBrowserType[i];
			if(strBrowserType[i].toString().equalsIgnoreCase("firefox"))
			{
				webDriver= new FirefoxDriver();
				i=i+1;
				break;

			}
			else if(strBrowserType[i].toString().equalsIgnoreCase("ie"))
			{
				File file = new File("Drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				webDriver= new InternetExplorerDriver();
				i=i+1;
				break;

			}
			else if(strBrowserType[i].toString().equalsIgnoreCase("chrome"))
			{
				
				System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");				
				webDriver=new ChromeDriver();
				i=i+1;
				break;

			}

		}

		driver = new EventFiringWebDriver(webDriver);

		MyListener myListener = new MyListener();
		driver.register(myListener);

		try 
		{
			 	driver.manage().deleteAllCookies();
			 	//driver.get(configProps.getProperty("URL"));
			 	int implicitWaitTime = 20;
			 	if("ie".equalsIgnoreCase(configProps.getProperty("browserType"))){
			 		driver.manage().timeouts().implicitlyWait(implicitWaitTime * 2, TimeUnit.SECONDS);
			 	}else{
			 		driver.manage().timeouts().implicitlyWait(implicitWaitTime, TimeUnit.SECONDS);
			 	}
				
			System.out.println(">>>>"+driver.getWindowHandle());
			driver.manage().window().maximize();
			ReadResourceData.readResourceData();
			Reporters.reportCreater();
			HtmlReporters.currentSuit = ctx.getCurrentXmlTest().getSuite().getName();
		}
		catch (Exception e1)
		{
			System.out.println(e1);
		}
		/*
		 * DB start	
		 */
		/*try 
		{
			Class.forName("com.mysql.jdbc.Driver").newInstance();

			conn = DriverManager.getConnection(url + "test", userName, "");

			stmt = conn.createStatement();

		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}*/

	}

	
	public static void close()
	{
		driver.close();		driver.quit();
	}
	/**
	 *  De-Initializing and closing all the connections
	 * @throws Exception 
	 * @throws Throwable
	 */

	public static void tearDown() throws Throwable 
	{
		Accessories.calculateSuiteExecutionTime();
		Accessories.calculateSuiteExecutionTime();
		HtmlReporters.createHtmlSummaryReport();
		//open the result file
		String dir =  configProps.getProperty("openResult"); // path to your new file
		File fl = new File(dir);
		File[] folders = fl.listFiles(new FileFilter() {			
			public boolean accept(File file) {
				return file.isDirectory();
			}
		});
		long lastMod = Long.MIN_VALUE;
		File choise = null;
		for (File folder : folders) {
			if (folder.lastModified() > lastMod) {
				choise = folder;
				lastMod = folder.lastModified();
			}
		}
		System.out.println(choise); // directory
		
		
		
		dir = ""+choise;
		fl = new File(dir);
		File[] files = fl.listFiles(new FileFilter() {			
			public boolean accept(File file) {
				return file.isFile();
			}
		});
		
		
		lastMod = Long.MIN_VALUE;
		choise = null;
		for (File file : files) {
			if (file.lastModified() > lastMod) {
				choise = file;
				lastMod = file.lastModified();
			}
		}
		
		dir = ""+choise;
		File htmlFile = new File(dir);
		
		//ElsevierObjects.testresultPath=dir;
		Desktop.getDesktop().browse(htmlFile.toURI());
		/* .................*/
		
		
		
		
		driver.quit();
		
		if(configProps.getProperty("MailTransfer").equalsIgnoreCase("True"))
		{
			SendMail.attachReportsToEmail(choise);
		}

		
		
		
		/*
		 * DB end	
		 */
		if (conn != null && !conn.isClosed())
			conn.close();

		/*if(configProps.getProperty("ReRunFailureTestCases").equalsIgnoreCase("True"))
		{

		//Rerun
			Test.copyFile();
			BatchExecute btexe=new BatchExecute();

			btexe.runFailure();

		}*/

		
	}
	


	/**
	 * Write results to Browser specific path
	 * @Date  19/02/2013
	 * @Revision History
	 * 
	 */
	//@Parameters({"browserType"})
	public static String filePath()
	{
		String strDirectoy="ResultFile";

		/*if(configProps.getProperty("browserType").equalsIgnoreCase("ie"))
		{
			strDirectoy="IE\\IE";	

		}
		else if(configProps.getProperty("browserType").equalsIgnoreCase("firefox"))
		{
			strDirectoy="Firefox\\Firefox";

		}
		else
		{
			strDirectoy="Chrome\\Chrome";

		}

		if(strDirectoy!="")
		{
			new File(configProps.getProperty("screenShotPath")+strDirectoy+"_"+timeStamp).mkdirs();
		}
*/
		new File(configProps.getProperty("screenShotPath")+strDirectoy+"_"+timeStamp).mkdirs();
		return configProps.getProperty("screenShotPath")+strDirectoy+"_"+timeStamp+"\\";

	}
	/**
	 * Browser type prefix for Run ID
	 * @Date  19/02/2013
	 * @Revision History
	 * 
	 */
	public static String result_browser()
	{
		if(configProps.getProperty("browserType").equals("ie"))
		{
			return "IE";
		}
		else if(configProps.getProperty("browserType").equals("firefox"))
		{
			return "Firefox";
		}
		else
		{
			return "Chrome";
		}
	}
	/**
	 * Related to Xpath
	 * @Date  19/02/2013
	 * @Revision History
	 * 
	 */
	public static String methodName()
	{
		if(configProps.getProperty("browserType").equals("ie"))
		{
			return "post";
		}
		else
		{
			return "POST";
		}
	}


	/*@AfterMethod()
	public void TestLink() throws Throwable
	{

		Accessories.calculateTestCaseExecutionTime();
		TestClass.reportTestCaseResult(PROJECTNAME, TESTPLANNAME,SmokeTest.TESTCASENAME, BUILDNAME, SmokeTest.mesg, SmokeTest.result);
		SmokeTest.TESTCASENAME="";
		SmokeTest.mesg=null;
		SmokeTest.result=null;
	}*/
	@AfterMethod(alwaysRun=true)

	public static void TestLink() throws Throwable
	{
		Accessories.calculateTestCaseExecutionTime();


	}


	@BeforeMethod(alwaysRun=true)
	public void reportHeader(Method method){
		Accessories.calculateSuiteStartTime();
		flag=false;
		String adminBrowse ="";
		String studentBrowser ="";
		if(ElsevierObjects.adminBrowserType!=null){
			adminBrowse = ElsevierObjects.adminBrowserType;
		}else{
			adminBrowse = "N/A";
		}
		
		if(ElsevierObjects.studentBrowserType!=null){
			studentBrowser = ElsevierObjects.studentBrowserType;
		}else{
			studentBrowser = "N/A";
		}
		HtmlReporters.tc_name=method.getName().toString()+","+adminBrowse+","+studentBrowser+","+Base.timeStampBeforeSutie;
		String[] ts_Name=this.getClass().getName().toString().split("\\.");
		HtmlReporters.packageName=ts_Name[0]+"."+ts_Name[1]+"."+ts_Name[2];
		
		HtmlReporters.testHeader(ts_Name[ts_Name.length-2].concat(" : ").concat(HtmlReporters.tc_name));
	}
	
	
}