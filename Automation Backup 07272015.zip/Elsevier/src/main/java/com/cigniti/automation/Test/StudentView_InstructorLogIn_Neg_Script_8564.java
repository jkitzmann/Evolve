package com.cigniti.automation.Test;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarte_Student_SplitOrders1_15597;
import com.cigniti.automation.BusinessFunctions.StudentView_InstructorLogIn_Neg_8564;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class StudentView_InstructorLogIn_Neg_Script_8564 extends StudentView_InstructorLogIn_Neg_8564 {
	@Test
	public void studentViewInstructorLogin_8564() throws Throwable{
	
		try {
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			if(studentSearch())
			{
				Reporters.SuccessReport("Clicked On Student link ", "Currently on  Evolve home page");
			}
	       else{
				Reporters.failureReport("Clicked On Student link", "Failed Opening  Evolve home page"); 
			}
			if(srarchPrice())
			{
				Reporters.SuccessReport("Price is present ", "Price is present");
			}
	       else{
				Reporters.failureReport("Price is present", "Price is not present"); 
			}
			
			String status=driver.findElement(By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]")).getAttribute("class");
			if(status.equals("finished"))
		    {
				 Reporters.SuccessReport("User Credit Card Details:", "Already user Credit Card Details exists");
			}
			else
			{
				if(creditCardDetails())
				{
					Reporters.SuccessReport("Credit Card Details Entred Succesfully ", "Credit Card Details Enterd");
				}
		       else{
					Reporters.failureReport("Credit Card Details Entred Not Succesfully", "Credit Card Details not Enterd"); 
				}
			}
			
			if(status.equals("finished"))
			{
				if(studentReview(status))
				{
					Reporters.SuccessReport("Student Review Succesfully ", "Student Reviewed ");
				}
		       else{
					Reporters.failureReport("Student Review Not Succesfull", "Credit Card Details Enterd"); 
				}
			}
			else{
				
				if(studentReview(status))
				{
					Reporters.SuccessReport("Student Review Succesfully ", "Student Reviewed ");
				}
		       else{
					Reporters.failureReport("Student Review Not Succesfull", "Credit Card Details Enterd"); 
				}
			}
			Thread.sleep(high);
			ECommercePreorderALaCarte_Student_SplitOrders1_15597.getStudentAccountDetails();
			if(instructorLogout())
			{
				Reporters.SuccessReport("Student Log out:", "Student Loged Out Successfully");
			}
	       else{
				Reporters.failureReport("Student Log out:", "Student Log out Failed."); 
			}
			Thread.sleep(high);
			//admin Login
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			if(evolveAdminlogin())
			{
				Reporters.SuccessReport("Admin login ", "Successfully Reviewed and Submitted");
			}
	       else{

	    	   Reporters.failureReport("Review and submit ", "Failed to Review and Submit");
			}
			
			if(verifyNoAdoptionRequest(getAccountDetailsUserName))
			{
				Reporters.SuccessReport("Searched for AR", "No adoptions found, as expected.");
			}
			else{
				Reporters.failureReport("Searched for AR", "Adoptions are included in results");
			}
			
			Thread.sleep(medium);
			if(adminLogout())
			{
	     		Reporters.SuccessReport("Clicked on Logout", "Successfully Clicked on Logout");
			}
			else
			{
				Reporters.failureReport("Clicked on MAC", "Not Clicked on Logout ");
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
}
