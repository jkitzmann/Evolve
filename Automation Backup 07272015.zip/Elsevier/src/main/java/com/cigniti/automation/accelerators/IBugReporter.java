package com.cigniti.automation.accelerators;

public interface  IBugReporter {
	void postBug(String propFileName);
}
