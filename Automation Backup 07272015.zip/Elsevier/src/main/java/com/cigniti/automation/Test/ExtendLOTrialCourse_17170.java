package com.cigniti.automation.Test;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.LOUniqueCourseTrialFulfillmentFaculty_15243;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.Utilities.DateGenerator;
import java.util.Date;


public class ExtendLOTrialCourse_17170 extends EvolveCommonBussinessFunctions{

	@Test
	public void ExtendLOTrialCourse1_17170() throws Throwable{
		
		try {
			SwitchToBrowser(ElsevierObjects.adminBrowserType);
			
	stepReport("Login to Evolve Admin.");
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to EvolveAdmin page with the User Credentials",
				                                                         "Successfully login to EvolveAdmin page with the User Credentials",
				                                                         "Failed to login the EvolveAdmin page with the User Credentials");
			
	stepReport("Find a Trial Adoption Request");
			
			EvolveCommonBussinessFunctions.searchAdoptionRequest(false,false,true,true);
			
			click(ElsevierObjects.AR_RESULTS_DATE_SORT,"Click Submit Date Column Header to Sort Asc");
			Thread.sleep(medium);
			
			click(ElsevierObjects.AR_RESULTS_ROW_SELECT,"Click First Row of AR Search Results");
			
			String AR_number = getText(ElsevierObjects.AR_DETAILS_NUMBER,"AR Number from AR Details Page");
			
			String AR_ISBN = getText(ElsevierObjects.AR_DETAILS_ISBN,"AR Details ISBN Field");
			
			AR_number = AR_number.substring(20,25);
			int AR_number_int = Integer.parseInt(AR_number);
			
	stepReport("Get Event Product Data for Associated ISBN");
			if(click(ElsevierObjects.ADMIN_BREADCRUMB,"Click on Evolve Admin Breadcrumb link")){
				Reporters.SuccessReport("Clicking On Admin Breadcrumb", "Successfully Click On Admin Breadcrumb");
			}
			else{
				Reporters.failureReport("Clicking On Admin Breadcrumb","Failed To Click On Admin Breadcrumb");
			};
			Thread.sleep(low);
			
			EvolveCommonBussinessFunctions.maintainProductLink(AR_ISBN);
			Thread.sleep(low);

			if(click(ElsevierObjects.MaintainPrdct_prdctSerachReslut_isbn,"Click on isbn num in product result page")){
				Reporters.SuccessReport("Clicking On Maintain Product Link And Searching For The ISBN: "+AR_ISBN, "Successfully Clicked On Maintain Product Page Link.</br>Successfully Searched For ISBN: "+AR_ISBN);
			}
			else{
				Reporters.failureReport("Clicking On Maintain Product Link And Searching For The ISBN: "+AR_ISBN,"Failed To Click On Maintain Product Page Link.</br>Failed To Search For ISBN: "+AR_ISBN);
			}
			
			Thread.sleep(low);
			
			if(click(ElsevierObjects.ADMIN_FACULTY_PROD_TAB,"Click on Faculty Prod Tab")){
				Reporters.SuccessReport("Click on Faculty Prod Tab", "Successfully Clicked on Faculty Prod Tab");
			}
			else{
				Reporters.failureReport("Click on Faculty Prod Tab","Failed To Click on Faculty Prod Tab");
			};
			
			Thread.sleep(medium);
			
			int fProd_warning1Days = Integer.parseInt(getAttribute(ElsevierObjects.TRIAL_WARN1_FPROD,"value","FPROD Warning 1 Field"));
			int fProd_warning2Days = Integer.parseInt(getAttribute(ElsevierObjects.TRIAL_WARN2_FPROD,"value","FPROD Warning 2 Field"));
			int fProd__warningEndDays = Integer.parseInt(getAttribute(ElsevierObjects.TRIAL_END_DATE_FPROD,"value","FPROD End Date Field"));
			int fProd_disableAtEndDays = Integer.parseInt(getAttribute(ElsevierObjects.TRIAL_DISABLE_DATE_FPROD,"value","FPROD Unenroll Date Field"));
				
			Reporters.SuccessReport("Click on Faculty Prod Tab", "Successfully Grabbed Trial Values from Faculty Prod Tab. </br>"
					 + "fProd_warning1Days = " + fProd_warning1Days + "</br>"
					 + "fProd_warning2Days = " + fProd_warning2Days + "</br>"
					 + "fProd__warningEndDays = " + fProd__warningEndDays + "</br>"
					 + "fProd_disableAtEndDats = " + fProd_disableAtEndDays);
		
			System.out.println("fProd_warning1Days = " + fProd_warning1Days);
			System.out.println("fProd_warning2Days = " + fProd_warning2Days);
			System.out.println("fProd__warningEndDays = " + fProd__warningEndDays);
			System.out.println("fProd_disableAtEndDats = " + fProd_disableAtEndDays);
			
stepReport("Go Back to AR Details Page");
		
			if(click(ElsevierObjects.ADMIN_BREADCRUMB,"Click on Evolve Admin Breadcrumb link")){
				Reporters.SuccessReport("Clicking On Admin Breadcrumb", "Successfully Click On Admin Breadcrumb");
			}
			else{
				Reporters.failureReport("Clicking On Admin Breadcrumb","Failed To Click On Admin Breadcrumb");
			};
			Thread.sleep(low);
			
			if(click(ElsevierObjects.lnkAdaptionrequest, "Click Search Adoption Requests link")){
		     	Reporters.SuccessReport("Click Search Adoption Requests link", "Successfully clicked Search Adoption Requests link");
			}else{
				Reporters.failureReport("Click Search Adoption Requests link", "Failed to click Search Adoption Requests link");
			};
			
			Thread.sleep(low);
			
			if(searchAdoptionByAdoptionNumber(AR_number)){
		     	Reporters.SuccessReport("Go to Adoption Request Details page", "Successfully went to Adoption Request Details page");
			}else{
				Reporters.failureReport("Go to Adoption Request Details page", "Failed to go to Adoption Request Details page");
			};
			
			Thread.sleep(medium);
			
			String AR_number_2 = getText(ElsevierObjects.AR_DETAILS_NUMBER,"AR Number from AR Details Page");
			AR_number_2 = AR_number_2.substring(20,25);
			int AR_number_2_int = Integer.parseInt(AR_number_2);
			
			if(AR_number_int == AR_number_2_int){Reporters.SuccessReport("Land on Adoption Request Details Page", "Successfully Landed Back on same Adoption Request Details Page" + "</br>"  + AR_number + " == " + AR_number_2);
			}else{
				Reporters.failureReport("Land on Adoption Request Details Page", "Failed to Land back on same Adoption Request Details Page" + "</br>" + AR_number + " != " + AR_number_2);
			};
			
	stepReport("Extend Trial and Verify Results");
			
			if(click(ElsevierObjects.EXTEND_AR_TRIAL, "Click Extend Trial button")){
		     	Reporters.SuccessReport("Click Extend Trial button", "Successfully clicked Extend Trial button");
			}else{
				Reporters.failureReport("Click Extend Trial button", "Failed to click Extend Trial button");
			};
			
			Thread.sleep(low);
			
			String AR_email = getText(ElsevierObjects.AR_DETAILS_EMAIL,"AR Details Email Field");
			String AR_username = getText(ElsevierObjects.Adoption_request_username,"AR Details Email Field");
			String sheetname = "TC-17170";
			
			ReadingExcel.updateCellInSheet(1,0,configProps.getProperty("TestData"), sheetname, AR_number);
			ReadingExcel.updateCellInSheet(1,1,configProps.getProperty("TestData"), sheetname, AR_username);
			ReadingExcel.updateCellInSheet(1,2,configProps.getProperty("TestData"), sheetname, AR_email);
			
			String AR_warning1Date = getAttribute(ElsevierObjects.AR_DETAILS_WARN1,"origin","AR Details Warning 1 Field");
			String AR_warning2Date = getAttribute(ElsevierObjects.AR_DETAILS_WARN2,"origin","AR Details Warning 2 Field");
			String AR_warningEndDate = getAttribute(ElsevierObjects.AR_DETAILS_END_DATE,"origin","AR Details End Date Field");
			String AR_disableAtEndDate = getAttribute(ElsevierObjects.AR_DETAILS_DISABLE_DATE,"origin","AR Details Disable At End Field");
			
			
			Reporters.SuccessReport("Click on Faculty Prod Tab", "Successfully Grabbed New Trial DateValues from Adoption Request. </br>"
					 + "AR_warning1Date = " + AR_warning1Date + "</br>"
					 + "AR_warning2Date = " + AR_warning2Date + "</br>"
					 + "AR_warningEndDate = " + AR_warningEndDate + "</br>"
					 + "AR_disableAtEndDate = " + AR_disableAtEndDate);
			
			String expectedAR_warning1Date = DateGenerator.getFutureDate(fProd_warning1Days);
			String expectedAR_warning2Date = DateGenerator.getFutureDate(fProd_warning2Days);
			String expectedAR_endDate = DateGenerator.getFutureDate(fProd__warningEndDays);
			String expectedAR_disableAtEndDate = DateGenerator.getFutureDate(fProd_disableAtEndDays);
			
			if(AR_warning1Date.trim().equals(expectedAR_warning1Date.trim())){Reporters.SuccessReport("Verify the extended Warning 1 Date is as expected", "Actual Warning 1 date successfully matches the expected Warning 1 Date" + "</br>"  + AR_warning1Date + " == " + expectedAR_warning1Date);
			}else{
				Reporters.failureReport("Verify the extended Warning 1 Date is as expected", "Actual Warning 1 date fails to match the expected Warning 1 Date" + "</br>" + AR_warning1Date + " != " + expectedAR_warning1Date);
			};
			
			if(AR_warning2Date.trim().equals(expectedAR_warning2Date.trim())){Reporters.SuccessReport("Verify the extended Warning 2 Date is as expected", "Actual Warning 2 date successfully matches the expected Warning 2 Date" + "</br>"  + AR_warning2Date + " == " + expectedAR_warning2Date);
			}else{
				Reporters.failureReport("Verify the extended Warning 2 Date is as expected", "Actual Warning 2 date fails to match the expected Warning 2 Date" + "</br>" + AR_warning2Date + " != " + expectedAR_warning2Date);
			};
			
			if(AR_warningEndDate.trim().equals(expectedAR_endDate.trim())){Reporters.SuccessReport("Verify the extended AR End Date is as expected", "Actual AR End date successfully matches the expected AR End Date" + "</br>"  + AR_warningEndDate + " == " + expectedAR_endDate);
			}else{
				Reporters.failureReport("Verify the extended AR End Date is as expected", "Actual AR End date fails to match the expected AR End Date" + "</br>" + AR_warningEndDate + " != " + expectedAR_endDate);
			};
			
			if(AR_disableAtEndDate.trim().equals(expectedAR_disableAtEndDate.trim())){Reporters.SuccessReport("Verify the extended AR Disable At End Date is as expected", "Actual AR Disable At End date successfully matches the expected AR Disable At End Date" + "</br>"  + AR_disableAtEndDate + " == " + expectedAR_disableAtEndDate);
			}else{
				Reporters.failureReport("Verify the extended AR Disable At End Date is as expected", "Actual AR Disable At End date fails to match the expected AR Disable At End Date" + "</br>" + AR_disableAtEndDate + " != " + expectedAR_disableAtEndDate);
			};
			
			if(click(ElsevierObjects.LOGOUT, "Click Logout button")){
		     	Reporters.SuccessReport("Click Logout button", "Successfully logged out of Evolve Admin");
			}else{
				Reporters.failureReport("Click Logout button", "Failed to log out of Evolve Admin");
			};
			
			
	stepReport("Verify Extend Trial Email");
			
			String extendTrialEmailTitle=ReadingExcel.columnDataByHeaderName("EXTEND_TRIAL_EMAIL", sheetname, testDataPath);
			Thread.sleep(low);
	
			writeReport(EvolveCommonBussinessFunctions.emailLogin(), "Login In Into Evolve Email Page.", 
					  "Succesful login into Evolve Email Page.", 
					  "Failed to login into Evolve Email Page.");
			
			writeReport(LOUniqueCourseTrialFulfillmentFaculty_15243.searchEmail(AR_email),"Search email in evolve webmail.",
					"Successfully entered the emailid "+AR_email+" in search box.",
					"Failed to enter email id.");
				
			String titleInEmail=getText(ElsevierObjects.titleInEmail, "Get title in evolve email page.");
			System.out.println( "From Excel = " + extendTrialEmailTitle + "<br> From email = " + titleInEmail);
			
			if(titleInEmail.trim().contains(extendTrialEmailTitle.trim()))
				
			{
				Reporters.SuccessReport("Verifying Email Title.", "Successfully Verified Email Title</br>The Actual Title is :"+titleInEmail+"</br>The Expected Title Is :"+extendTrialEmailTitle);
			}
			else{
				Reporters.failureReport("Verifying Email Title.", "Failed To Verify Email Title.</br>The Actual Title is :"+titleInEmail+"</br>The Expected Title Is :"+extendTrialEmailTitle);
			}
			Thread.sleep(low);
			
			switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
			
			Thread.sleep(low);
			
			expectedAR_endDate = DateGenerator.convertDate(expectedAR_endDate);
			
			String actualEmailBody = getText(ElsevierObjects.email_body_text,"Get email body text");
			String expectedEmailBody = "Your trial will expire on "+ expectedAR_endDate;
			
			if(actualEmailBody.contains(expectedEmailBody)){
				Reporters.SuccessReport("Verify Email Body", "Email body successfully contains the expected value <br> + Actual Value is: " + actualEmailBody + "<br>Expected text to contain is: "+expectedEmailBody);
			}
			else{
				Reporters.failureReport("Verify Email Body", "Email body does not contain the expected value <br> + Actual Value is: " + actualEmailBody + "<br>Expected text to contain is: "+expectedEmailBody);
			}
			
			click(ElsevierObjects.email_logout,"Click on logout.");
			Thread.sleep(medium);

	stepReport("Data Cleanup for Next Run - Converting Trial to Permanent");
			
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to EvolveAdmin page with the User Credentials",
				                                                         "Successfully login to EvolveAdmin page with the User Credentials",
				                                                         "Failed to login the EvolveAdmin page with the User Credentials");
			
			Thread.sleep(low);
			
			if(click(ElsevierObjects.lnkAdaptionrequest, "Click Search Adoption Requests link")){
		     	Reporters.SuccessReport("Click Search Adoption Requests link", "Successfully clicked Search Adoption Requests link");
			}else{
				Reporters.failureReport("Click Search Adoption Requests link", "Failed to click Search Adoption Requests link");
			};
			
			Thread.sleep(low);
			
			if(searchAdoptionByAdoptionNumber(AR_number)){
		     	Reporters.SuccessReport("Go to Adoption Request Details page", "Successfully went to Adoption Request Details page");
			}else{
				Reporters.failureReport("Go to Adoption Request Details page", "Failed to go to Adoption Request Details page");
			};
			
			Thread.sleep(medium);
			
			if(click(ElsevierObjects.adoptionRequest_ConvertToPermanent, "Click Convert to Permanent button")){
		     	Reporters.SuccessReport("Click Convert to Permanent button", "Successfully Converting Trial to a Permanent Course");
			}else{
				Reporters.failureReport("Click Convert to Permanent button", "Failed to Convert Trial to a Permanent Course");
			};
			
			}
			
	catch (Exception e) {
		System.out.println(e.getMessage());	
	}
	
	}}