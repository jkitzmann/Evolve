package com.cigniti.automation.Test;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.awt.image.PixelGrabber;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.cigniti.automation.Utilities.Property;
import com.cigniti.automation.Utilities.ReadColumns;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Actiondriver;
//compareNotePadDataWithStringliterals()
public class Sample extends Actiondriver{
	
	public static Property configProps=new Property("config.properties");
	public static Property configdata=new Property("Testdata.properties");
	public void sample1(){
		 String textFilepath=System.getProperty("user.dir")+"\\TestData\\unassignedaccesscodes.txt";
		 
		   //System.out.println(textFilepath);
		   File source = new File("C:\\Users\\IN00893\\Downloads\\unassignedaccesscodes.txt");
		   File dest = new File(textFilepath);
		   try {
			   FileUtils.copyFile(source, dest);
		       //FileUtils.copyDirectory(source, dest);
			   System.out.println("copied successfully");
		   } catch (IOException e) {
		       e.printStackTrace();
		   }
	}
	
	
	/** Retrieve the data present in the excel cell.
	 * 
	 * @param rowNumber
	 * @param columnNumber
	 * @param path
	 * @param sheetIndex
	 * @return
	 */
	public static void getCell(){

		String cellData = null;
		try {
			//String path="C:\\Users\\IN00893\\Desktop\\vst1.xlsx";
			//File f = new File(path);
			//FileInputStream ios = new FileInputStream(f);
			//XSSFWorkbook workbook = new XSSFWorkbook(ios);
			//XSSFSheet sheet=workbook.getSheet("Sheet1");
			//XSSFSheet sheet = workbook.getSheetAt(0);
			//Cell cell = sheet.getRow(0).getCell(0);
			//XSSFRow row=sheet.getRow(0);
			//System.out.println(":::::"+row.toString());

			//sheet.removeRow(row);
			
			XSSFWorkbook workbook = null;

			FileInputStream istream= new FileInputStream ("C:\\Users\\IN00893\\Desktop\\vst1.xlsx");

			//POIFSFileSystem inputStream = new POIFSFileSystem(new BufferedInputStream(istream));
			workbook = new XSSFWorkbook(istream);

			XSSFRow row = null;
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			row= sheet.getRow(0);
			

			//The below method removes only cell values not row.
			sheet.removeRow(row);

			FileOutputStream out = new FileOutputStream ("C:\\Users\\IN00893\\Desktop\\vst2.xlsx");
			workbook.write(out);
			/*switch(cell.getCellType()) {
			case Cell.CELL_TYPE_STRING: 
				cellData = cell.getStringCellValue();
				System.out.println(cellData);
				sheet.removeRow( sheet.getRow(0) );
				//cell.getRow().removeCell(cell);
				//sheet.removeRow(row);
				//System.out.println(row);
				break;
			case Cell.CELL_TYPE_NUMERIC:  
				cellData = ""+cell.getNumericCellValue();
				break;
			}*/
		}catch (Exception e) {
			System.out.println("Exception occured while reading the cell data "+e);
			e.printStackTrace();
		}

		//return cellData;
	}

	public static void getdata(){
		String s=readcolumns.twoColumns(0, 1,"TC-10214", configProps.getProperty("TestData")).get("ISBNPkgName");
		String s1=readcolumns.twoColumns(0, 1, "TC-10214", configProps.getProperty("TestData")).get("Input_ISBN");
		String s2=readcolumns.twoColumns(0, 1, "TC-10214", configProps.getProperty("TestData")).get("Existing_ISBN");
		String s3=readcolumns.twoColumns(0, 1, "TC-10214", configProps.getProperty("TestData")).get("AddISBN_Invalid");
		String s4=readcolumns.twoColumns(0, 1, "TC-10214", configProps.getProperty("TestData")).get("testdata1");
		System.out.println(s);
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		System.out.println(s4);
	}
	
	public static String Image_Comparisions() throws Throwable
	{

	System.out.println("Executing processImage Keyword");

	try {
		driver.navigate().to("https://evolvecert.elsevier.com/testing2058");
		String file1 = "C:\\Users\\IN00893\\Desktop\\Regarding_Image_Comparisons\\Elsevier.png";
	
	//String file2 = "C:\\Users\\IN00893\\Desktop\\Regarding_Image_Comparisons\\Elsevier - Copy.png";*/
	
	//String file1 = "C:\\Users\\IN00893\\Desktop\\Regarding_Image_Comparisons\\water - Copy.PNG";
	
	String file2=driver.findElement(By.xpath(".//*[@id='pageLayout-body-inner-most']/div[1]/div/a")).getAttribute("img");
	//String file2 = "C:\\Users\\IN00893\\Desktop\\Regarding_Image_Comparisons\\water.PNG";
	Image pic1= Toolkit.getDefaultToolkit().getImage(file1);
	Image pic2= Toolkit.getDefaultToolkit().getImage(file2);

	try {

	PixelGrabber grab11 = new PixelGrabber(pic1, 0, 0, -1, -1,false);
	PixelGrabber grab21 = new PixelGrabber(pic2, 0, 0, -1, -1,false);

	int[] array1= null;

	if (grab11.grabPixels()) {
	int width = grab11.getWidth();
	int height = grab11.getHeight();
	array1= new int[width * height];
	array1= (int[]) grab11.getPixels();
	}

	int[] array2 = null;

	if (grab21.grabPixels()) {
	int width = grab21.getWidth();
	int height = grab21.getHeight();
	array2 = new int[width * height];
	array2 = (int[]) grab21.getPixels();
	}

	System.out.println("Pixels equal: "+ java.util.Arrays.equals(array1, array2 ));

	} catch (InterruptedException e1) {
	e1.printStackTrace();
	}

	return "Pass";
	} catch (Throwable t) {
	// report error
	System.out.println("pixels are not equal");
		return "Fail - " + t.getMessage();

	}

	}
	
	public static boolean compareImage() {
		try {
		// take buffer data from botm image files //
		File fileA=new File("C:\\Users\\IN00893\\Desktop\\Regarding_Image_Comparisons\\AWESOME.png");
		File fileB=new File("C:\\Users\\IN00893\\Desktop\\Regarding_Image_Comparisons\\AWESOME.png");
		BufferedImage biA = ImageIO.read(fileA);
		DataBuffer dbA = biA.getData().getDataBuffer();
		int sizeA = dbA.getSize();
		BufferedImage biB = ImageIO.read(fileB);
		DataBuffer dbB = biB.getData().getDataBuffer();
		int sizeB = dbB.getSize();
		// compare data-buffer objects //
		if(sizeA == sizeB) {
		for(int i=0; i<sizeA; i++) {
		if(dbA.getElem(i) != dbB.getElem(i)) {
		return false;
		}
		}
		return true;
		}
		else {
		return false;
		}
		}
		catch (Exception e) {
		System.out.println("Failed to compare image files ...");
		return false;
		}
		} 
	 public ArrayList<String> columnDataFromkey()
		{
			ArrayList<String> columndata = null;
			try {
				File f = new File("C:\\Users\\IN00893\\Desktop\\EvolveNew21-11-2014\\Elsevier24-11\\TestData\\TestData - Copy.xlsx");
				FileInputStream ios = new FileInputStream(f);
				XSSFWorkbook workbook = new XSSFWorkbook(ios);
				XSSFSheet sheet = workbook.getSheet("TC-10214Copy");
				//XSSFSheet sheet = workbook.getSheetAt(sheetindex);
				Iterator<Row> rowIterator = sheet.iterator();
				columndata = new ArrayList<String>();

				while (rowIterator.hasNext()) {
					Row row = rowIterator.next();
					Iterator<Cell> cellIterator = row.cellIterator();
					while (cellIterator.hasNext()) {
						Cell cell = cellIterator.next();
						if(cell.toString().equalsIgnoreCase("CreatePackageData")){
						if(row.getRowNum() > 0){ //To filter column headings
							if(cell.getColumnIndex() == 0){// To match column index
								switch (cell.getCellType()) {
								case Cell.CELL_TYPE_NUMERIC:
									columndata.add(cell.getNumericCellValue()+"");
									break;
								case Cell.CELL_TYPE_STRING:
									columndata.add(cell.getStringCellValue());
									columndata.add(1, cell.getStringCellValue());
									break;
								}
							}
						}
					}
					}
				}
				ios.close();
				//System.out.println(columndata);
			} catch (Exception e) {
				e.printStackTrace();
			}

			//returns the complete column data
			return columndata;

		}
	 
	 
	 public  List<String> twoColumnsFroKeys1(String path,String uniqueName,int uniqueColumnValue,int getColumnValue, String sheetName) {
		 List<String> getValue = new ArrayList<String>();
			ReadingExcel re=new ReadingExcel();
			ArrayList<String> Keys=re.columnData(uniqueColumnValue, sheetName,path);
			ArrayList<String> values=re.columnData(getColumnValue, sheetName,path);
			//String dynamic="CreatePackageData";
			Map<String, String> excelConfig = new HashMap<String, String>();
			
			for(int i=0; i<Keys.size(); i++)
			{	
				if(Keys.get(i).equalsIgnoreCase(uniqueName)){
				for(int j=i; j<values.size(); j++)
				{
					if(Keys.get(j).equalsIgnoreCase(uniqueName)){
					excelConfig.put(Keys.get(i), values.get(j));
					String excel=excelConfig.put(Keys.get(i), values.get(j)).toString();
					//System.out.println(excel);
					getValue.add(excel);
					//System.out.println(excelConfig);
					//System.out.println(getValue);
					//break;
				}
					break;
			}
			}}
			System.out.println(getValue);
			 //System.out.println(excelConfig.size());
			// System.out.println(excelConfig.get("pin"));
			return getValue;
			
		}
	 public  Map<String, String> twoColumnsFroKeys(String path,String uniqueName,int uniqueColumnValue,int getColumnValue, String sheetName) {
		 List<String> getValue = new ArrayList<String>();
		 ArrayList<String> Keys=new ArrayList<String>();
		 Map<String, String> excelConfig = new HashMap<String, String>();
			ReadingExcel re=new ReadingExcel();
			List<String> key=re.columnData(0, sheetName, path);
			ArrayList<String> values=re.columnData(1, sheetName, path);
			for (int i = 0; i < key.size(); i++) {
				if(key.get(i).equalsIgnoreCase(uniqueName)){
					for (int j = i; j < values.size(); j++) {
						if(key.get(j).equalsIgnoreCase(uniqueName)){
						excelConfig.put(key.get(i), values.get(j));
						String excel=excelConfig.put(key.get(i), values.get(j)).toString();
						Keys.add(excel);
						System.out.println(excel);
					}
					}
					break;
				}
			}
			ArrayList<String> values1=re.columnData(2, sheetName, path);
			for(int i=0; i<Keys.size(); i++)
			{	
				for(int j=i; j<values1.size(); j++)
				{
					excelConfig.put(Keys.get(i), values1.get(j));
					break;
				}
			}
			return excelConfig;
		}

 public static void main(String args[]) throws Throwable {
	   //Property configProps=new Property("config.properties");
	   //BufferedReader br = null;
	   Sample s=new Sample();
	   s.twoColumnsFroKeys("C:\\Users\\IN00893\\Desktop\\EvolveNew21-11-2014\\Elsevier24-11\\TestData\\TestData - Copy.xlsx", "GenericData", 0, 1, "TC-10214Copy");
	   //s.sample1();
	  // s.getCell();
	  // s.getdata();
	  // s.Image_Comparisions();
	//s.compareImage();
	   /*String filepath="C:\\Users\\IN00893\\Desktop\\unassignedaccesscodes.txt";
	   List<String> data=new ArrayList<String>();
		try {
			
			
			String sCurrentLine;
			
			br = new BufferedReader(new FileReader(configProps.getProperty(filepath)));
			
			while ((sCurrentLine = br.readLine()) != null) {
				for(String s:data){
					data.add(s);
				}
				if(sCurrentLine.startsWith("UC")){
				if (sCurrentLine.contains("0") || sCurrentLine.contains("o")|| sCurrentLine.contains("O") || sCurrentLine.contains("l") || sCurrentLine.contains("1") || sCurrentLine.contains("Q")) {
					System.out.println("failed");
					//Reporters.failureReport("Expected conditions", "Expected condition failed");;
				}else{
					System.out.println("pass");
					//Reporters.SuccessReport("Expected conditions", "Expected condition failed");
				}
			}
		*/

		/*} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}*/
}
 

	
 
}
