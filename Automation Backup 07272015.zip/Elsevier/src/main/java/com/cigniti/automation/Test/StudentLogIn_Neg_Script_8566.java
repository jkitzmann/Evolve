package com.cigniti.automation.Test;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarte_Student_SplitOrders1_15597;
import com.cigniti.automation.BusinessFunctions.StudentLogIn_Neg_8566;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class StudentLogIn_Neg_Script_8566 extends StudentLogIn_Neg_8566 {
	@Test
	public void studentViewLogin_8566() throws Throwable{
	
		try {
			    SwitchToBrowser(ElsevierObjects.studentBrowserType);
				if(studentLoginGeneral())
				{
					Reporters.SuccessReport("Student Loged in Successfully", "Student Login Page");
				}
		       else{
					Reporters.failureReport("Student NOt Loged in", "Student Login Page"); 
				}
				if(searchCourseBeforeAdd())
				{
					Reporters.SuccessReport("Searched Product Successfully", "Product Search Page");
				}
		       else{
					Reporters.failureReport("Searched Product Successfully", "Product Search Page"); 
				}
				if(studentcheckout())
				{
					Reporters.SuccessReport("Student Checkout Process Successfully", "Student checkedout");
				}
		       else{
					Reporters.failureReport("Student Checkout Process Not Successfully", "Student checkedout Failed"); 
				}
				
				
				 if(!isElementPresentNegCheck(ElsevierObjects.searchBillAddress, "Billing Address Not Present"))
				 {
					 /*if(!click(ElsevierObjects.btnprofilecontinue, "Clicked on continue")){
							flag = false;
						}*/
					 Reporters.SuccessReport("User Billing Details:", "Already user Billing Details exists");
				 }
				 else
				 {
					 if(studentBillingAddress())
						{
							Reporters.SuccessReport("Billing Details Entred Succesfully ", "Billing Details Enterd");
						}
				       else{
							Reporters.failureReport("Billing Details not Entred Succesfully", "Billing Details not Enterd"); 
						}
				 }
				String status=driver.findElement(By.xpath(".//*[@id='pageLayout-body-inner-most']/div/div/div[2]")).getAttribute("class");
				
				if(status.equals("finished"))
			    {
					 Reporters.SuccessReport("User Credit Card Details:", "Already user Credit Card Details exists");
				}
				else
				{
					if(creditCardDetails())
					{
						Reporters.SuccessReport("Credit Card Details Entred Succesfully ", "Credit Card Details Enterd");
					}
			       else{
						Reporters.failureReport("Credit Card Details Entred Not Succesfully", "Credit Card Details not Enterd"); 
					}
				}
				
				if(status.equals("finished"))
				{
					if(studentReview(status))
					{
						Reporters.SuccessReport("Student Review Succesfully ", "Student Reviewed ");
					}
			       else{
						Reporters.failureReport("Student Review Not Succesfull", "Credit Card Details Enterd"); 
					}
				}
				else{
					
					if(studentReview(status))
					{
						Reporters.SuccessReport("Student Review Succesfully ", "Student Reviewed ");
					}
			       else{
						Reporters.failureReport("Student Review Not Succesfull", "Credit Card Details Enterd"); 
					}
				}
				Thread.sleep(high);
				
				ECommercePreorderALaCarte_Student_SplitOrders1_15597.getStudentAccountDetails();
				if(instructorLogout())
				{
					Reporters.SuccessReport("Student Log out:", "Student Loged Out Successfully");
				}
		       else{
					Reporters.failureReport("Student Log out:", "Student Log out Failed."); 
				}
				Thread.sleep(high);
				
				//admin Login
				SwitchToBrowser(ElsevierObjects.adminBrowserType);
				if(evolveAdminlogin())
				{
					Reporters.SuccessReport("Admin login ", "Successfully Reviewed and Submitted");
				}
		       else{

		    	   Reporters.failureReport("Review and submit ", "Failed to Review and Submit");
				}
				
				if(verifyNoAdoptionRequest(getAccountDetailsUserName))
				{
					Reporters.SuccessReport("Searched for AR", "No adoptions found, as expected.");
				}
				else{
					Reporters.failureReport("Searched for AR", "Adoptions are included in results");
				}
				
				Thread.sleep(medium);
				if(adminLogout())
				{
		     		Reporters.SuccessReport("Clicked on Logout", "Successfully Clicked on Logout");
				}
				else
				{
					Reporters.failureReport("Clicked on MAC", "Not Clicked on Logout ");
				}
				
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
}
