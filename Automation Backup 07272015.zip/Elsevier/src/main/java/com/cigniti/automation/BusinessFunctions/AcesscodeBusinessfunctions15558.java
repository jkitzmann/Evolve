package com.cigniti.automation.BusinessFunctions;


import java.text.SimpleDateFormat;
//import org.joda.time.*;

//import java.time.Period;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.internal.thread.ThreadExecutionException;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.datadriven.ReadResourceData;
import com.google.common.base.Throwables;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Days;


public class AcesscodeBusinessfunctions15558 extends EvolveCommonBussinessFunctions
{

	public static boolean createAccesscode(String ISBNPkg,String ISBNPkgname) throws Throwable
	{
		try
		{

			{
				b=true;
				if(!click(ElsevierObjects.Accesscodelink, "Add Access Code Package")){
					flag = false;
				}
				if(!type(ElsevierObjects.PackageISBN, ISBNPkg , "Package ISBN")){
					flag = false;
				}

				if(!type(ElsevierObjects.PackageName,ISBNPkgname, "Input Package Name ")){
					Thread.sleep(2000);
					flag = false;
				}

				if(!click(ElsevierObjects.savebutton, "Click on Save Button")){
					Thread.sleep(2000);
					flag = false;
				}
				Thread.sleep(3000);

				b=false;
				if(verifyText(ElsevierObjects.verifysuccessmesg, "Package successfully saved. ", "Package successfully saved. ")){
					Reporters.SuccessReport("Access Code Package Created Successfully","Access Code Package:"+ISBNPkg+"</br> Package name"+ISBNPkgname+"</br> Create Successfully");

				}else{
					Reporters.SuccessReport("Access Code Package Not Created","Access Code Package:"+ISBNPkg+"</br> Package name"+ISBNPkgname+"</br> Not Created");
				}



				return true;
			}

		}catch(Exception e){sgErrMsg="Failed to create Access code package"+e;return false;}
	}

	public static boolean AddISBN(String ISBN) throws Throwable
	{
		try
		{

			flag=true;
			if(!type(ElsevierObjects.verifyISBNtextenable,ISBN,"ISBN Value"))
			{
				flag = false;
			}
			Thread.sleep(2000);
			if(!click(ElsevierObjects.addbtn, "Add ISBN")){
				flag = false;
			}

			return flag;		
		}catch(Exception e){sgErrMsg="Failed to ADD ISBN"+e; return false;}
	}

	public static boolean NavigatetoUnassigncodes() throws Throwable
	{
		try
		{
			b=true;
			flag=true;
			if(!click(ElsevierObjects.Admin_Evolve_lnk, "Bread Crumb - Evolve Admin "))
			{
				flag=false;
			}

			if(!click(ElsevierObjects.unassignedaccesslink, " Create Unassigned Access Code"))
			{
				flag = false;
			}
			b=false;
			return flag;        		

		}catch(Exception e){sgErrMsg="Failed to Navigate to Unassigned Codes Page"+e; return false;}

	}

	public static boolean verifyCodeCreation_15558(String month_txt,String day_txt,String year_txt,String CountGenerate_txt) throws Throwable{
		boolean flag = true;
		try{

			if(!type(ElsevierObjects.unassignedinputmonth, month_txt, "Input Month")){
				Thread.sleep(2000);
				flag = false;
			}
			if(!type(ElsevierObjects.unassignedinputdate, day_txt, "Input Date")){
				Thread.sleep(2000);
				flag = false;
			}
			if(!type(ElsevierObjects.unassignedinputyear, year_txt, "Input Year")){
				Thread.sleep(2000);
				flag = false;
			}
			/*driver.findElement(ElsevierObjects.unassigneddaysofaccess).clear();
		if(!type(ElsevierObjects.unassigneddaysofaccess, Daysaccess_txt, "No. of days access")){
			Thread.sleep(2000);
			flag = false;
		}*/

			if(!type(ElsevierObjects.unassignedcodenumbertogenerate, CountGenerate_txt, "No. codes to generate")){
				Thread.sleep(2000);
				flag = false;
			}

			if(!click(ElsevierObjects.unassignedcodesave, "Click on Save Button")){
				Thread.sleep(2000);
				flag = false;
			}
			Thread.sleep(6000);

			if(verifyText(ElsevierObjects.accesscodesuccmesg, "The Access Code Set was successfully created.", "Success Message Displayed")){
				Reporters.SuccessReport("The Access Code Set Creation Success Message", "The Access Code Set was successfully created with the Following data: "
						+ "<br> Date of Expiration : "+month_txt+":"+day_txt+":"+year_txt +"<br>Days of Access:  0<br> Number to Generate:  "+CountGenerate_txt +"<br>The data is entered successfully ");

			}else{
				Reporters.failureReport("The Access Code Set Creation Success Message", "The Access Code Set was failed created with the Following data: "
						+ "<br> Date of Expiration : "+month_txt+":"+day_txt+":"+year_txt +"<br>Days of Access:  0<br> Number to Generate:  "+CountGenerate_txt);

			}

			Thread.sleep(4000);
			String sucMsg=getText(ElsevierObjects.accesscodedownloadlink, "");
			if(verifyText(ElsevierObjects.accesscodedownloadlink, "Click here to download the access codes.", "download link is Displayed")){
				Reporters.SuccessReport("The Success Message Validation", "The success message :"+sucMsg+" is displayed");	
			}else{
				Reporters.failureReport("The Success Message Validation", "The success message : "+sucMsg+" is failed to display");
			}

		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());return false;
		}
		return flag;

	}

	public static boolean verifyCopyToExcel(String filePath,String Downloadpath) throws Throwable{
		boolean flag = true;
		try{
			UpdateColDataExcel ex=new UpdateColDataExcel();
			//String filePath = ReadingExcel.getAbsoulteFilePath(readcolumns.twoColumns(0, 1, "TC-10212", configProps.getProperty("TestData")).get("UploadDataFile"));
			ex.UpdateColData(filePath, Downloadpath, "UploadFile");			 
		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(sgErrMsg);
			return false;
		}
		return flag;	
	}

	public static boolean EvolveCatalog(String user,String filepath) throws Throwable
	{
		boolean flag = true;
		try{

			String validRedeemCode=ReadingExcel.getCell(1, 2, filepath, "UploadFile");
			//enter into the site as student
			if(click(ElsevierObjects.evolveCatalog, "Click on Catalog")){
				Reporters.SuccessReport("Click on the evolve catalog link", "Successfully clicked on the evolve catalog link");
			}else{
				Reporters.failureReport("Click on the evolve catalog link", "failed to click on the evolve catalog link");
			}
			
			// None of this applies to the redesigned catalog page
			/*if(!javaClick(ElsevierObjects.Student_Home_Packard_img, "Clicked on Pageburst eBook")){
				flag = false;
			}	
			if(!javaClick(ElsevierObjects.Student_Home_Packard_img, "Clicked on Pageburst eBook")){
				flag = false;
			}
			if(javaClick(ElsevierObjects.Student_Home_Redeem_lnktxt, "Clicked on Pageburst eBook")){
				Reporters.SuccessReport("Click on the Pageburst honeypot and Redeem an access Code link", "Successfully clicked on the Pageburst honeypot and Redeem an access Code link");
			}else{
				Reporters.failureReport("Click on the Pageburst honeypot and Redeem an access Code link", "failed to click on the Pageburst honeypot and Redeem an access Code link");
			}*/
			
			if(type(ElsevierObjects.Student_Home_Redeem_txtbox, validRedeemCode, "Enter Redeem code in Text Box")){
				Reporters.SuccessReport("Enter the access code", "Successfully Entered the access code into the input box <br> Access code entered is : "+validRedeemCode);
			}else{
				Reporters.failureReport("Enter the access code", "failed to Enter the access code into the input box");
			}
			if(javaClick(ElsevierObjects.Student_Home_Redeem_Subbtn, "Clicked on Submit Redeem Button")){
				Reporters.SuccessReport("Click on the Redeem submit button", "Successfully Clicked on the Redeem submit button");
			}else{
				Reporters.failureReport("Click on the Redeem submit button", "Failed to Click on the Redeem submit button");
			}
			Thread.sleep(veryhigh);
			if(user.equalsIgnoreCase("true")){
				Thread.sleep(3000);
				waitForVisibilityOfElement(ElsevierObjects.Student_Home_Redeem_Chkout, "");
				Thread.sleep(3000);
				driver.findElement(ElsevierObjects.Student_Home_Redeem_Chkout).sendKeys(Keys.ENTER);
				Thread.sleep(3000);
				/*if(!click(ElsevierObjects.Student_Home_Redeem_Chkout, "Clicked on Submit Redeem/Checkout Button")){
				flag = false;
			}*/		
			}else{
				Thread.sleep(1000);
				//TODO actions to be done in the morning....
				String invalidMessage=getText(ElsevierObjects.Evolve_AccessCodeNotValid, "Get the Invalid message");
				if(verifyText(ElsevierObjects.Evolve_AccessCodeNotValid, invalidMessage, "Invalid ISBN Message")){
					Reporters.SuccessReport("Verify the Invalid Message ", "In Valid Message is successfully printed <br> Invalid message : "+invalidMessage);
				}else{
					Reporters.failureReport("Verify the Invalid Message ", "In Valid Message is failed to print");
				}
			}
		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());return false;
		}
		return flag;
	}
	public static boolean VerifyContentpage() throws Throwable
	{
		boolean falg=true;
		try
		{

			driver.findElement(By.xpath(".//a[contains(text(),'Refresh')]")).click();
			Thread.sleep(6000);
			driver.findElement(By.xpath(".//a[contains(text(),'Refresh')]")).click();
			Thread.sleep(6000);
			driver.findElement(By.xpath(".//a[contains(text(),'Refresh')]")).click();
			driver.findElement(By.xpath(".//a[contains(text(),'Refresh')]")).click();
			Thread.sleep(30000);
			List<WebElement> TotalConentlist=driver.findElements(By.xpath(".//*[@id='set']/li//div//div[@class='item platform_product']"));

			for(int i=0;i<=TotalConentlist.size();i++)
			{

				String Productype=TotalConentlist.get(i).findElement(By.tagName("span")).getText();


				int tempint=i+1;
				if(Productype!=null)
				{
					Reporters.SuccessReport("Verifying Product type Details Sequence:" +tempint, "Product Type name in Content list is:"+Productype);

				}
				else
				{
					Reporters.failureReport("Verifying Product type Details Sequence:"+tempint, "Product Type name in Content list is not valid");
				}

				String CourseDetails=TotalConentlist.get(i).findElement(By.tagName("a")).getText();
				if(CourseDetails!=null)
				{
					Reporters.SuccessReport("Verifying CourseDetails", "CourseDetails are Present in the Content list is:"+CourseDetails);

				}
				else
				{
					Reporters.failureReport("Verifying CourseDetails", "CourseDetails are not Present in the Content list ");
				}
				if(isElementPresent(By.xpath(".//*[@id='set']/li['"+i+"']//div//div[@class='item platform_product']//button")))
				{			
					List<WebElement> buttons=TotalConentlist.get(i).findElements(By.tagName("button"));

					if(buttons.size()==0)
					{
						Reporters.SuccessReport("Verifying Buttons", "No  Buttons Avilable ");

					}
					else
					{
						for(int a=0;a<buttons.size();a++)
						{


							String Button=buttons.get(a).getText();
							if(Button!=null)
							{
								Reporters.SuccessReport("Verifying Buttons", "Buttons are avilable :</br>"+Button);

							}
							else
							{
								Reporters.SuccessReport("Verifying Buttons", "No  Buttons Avilable ");
							}

						}

					}
				}
				else{
					Reporters.SuccessReport("Verifying Buttons", "No  Buttons Avilable ");		}

			}
		}catch(Exception e){
			sgErrMsg=e.getMessage();
			return false;
		}
		return falg;
	}

	public static boolean VerifyContentpagewithinputs(String Prodcutypeinput,String coursedetailsinputs,String Button1,String Button2,String Validation) throws Throwable
	{
		boolean falg=true;
		try
		{
			driver.findElement(By.xpath(".//a[contains(text(),'Refresh')]")).click();
			Thread.sleep(medium);
			driver.findElement(By.xpath(".//a[contains(text(),'Refresh')]")).click();
			Thread.sleep(medium);
			List<WebElement> TotalConentlist=driver.findElements(By.xpath(".//*[@id='set']/li//div//div[@class='item platform_product']"));

			String Productype="";
			int successflag=0;
			int index=0;
			for(int i=0;i<TotalConentlist.size();i++)
			{

				String CourseDetails=TotalConentlist.get(i).findElement(By.tagName("a")).getText();
				if(CourseDetails!=null)
				{
					if(CourseDetails.equalsIgnoreCase(coursedetailsinputs))
					{
						Reporters.SuccessReport("Verifying CourseDetails :"+coursedetailsinputs, "CourseDetails is Present in the Content list is:"+CourseDetails);
						successflag=1;
						index=i;
						break;
					}
				}
				else
				{
					Reporters.failureReport("Verifying CourseDetails :"+coursedetailsinputs, "CourseDetails is not Present in the Content list ");
				}
			}

			if(successflag==1)
			{
				Productype=TotalConentlist.get(index).findElement(By.tagName("span")).getText();

				if(Productype!=null)
				{
					if(Productype.equalsIgnoreCase(Prodcutypeinput))
					{
						Reporters.SuccessReport("Verifying Product type: " +Prodcutypeinput +" </br> for Course Details :"+coursedetailsinputs , "Product Type name is Present in Content list is:"+Productype);
					}
				}
				else
				{
					Reporters.failureReport("Verifying Product type Details Sequence:"+Prodcutypeinput, "Product Type name is Present in Content list is not valid");
				}

				if(isElementPresent(By.xpath(".//*[@id='set']/li['"+index+"']//div//div[@class='item platform_product']//button")))
				{			
					List<WebElement> buttons=TotalConentlist.get(index).findElements(By.tagName("button"));

					if(buttons.size()==0)
					{
						if(Validation.equalsIgnoreCase("Yes"))
						{	
							Reporters.failureReport("Verifying Buttons for Course Details :"+coursedetailsinputs, "No  Buttons Avilable ");		
						}
						else
						{
							Reporters.SuccessReport("Verifying Buttons  for Course Details :"+coursedetailsinputs, "No  Buttons Avilable ");
						}
					}
					else
					{
						for(int a=0;a<buttons.size();a++)
						{


							String Button=buttons.get(a).getText();
							if(Button!=null)
							{

								if(Button.equalsIgnoreCase(Button1))
								{	
									Reporters.SuccessReport("Verifying Buttons", "Buttons are avilable :</br>"+Button+" for Product Type"+Productype);
								}
								else
									if(Button.equalsIgnoreCase(Button2))
									{	
										Reporters.SuccessReport("Verifying Buttons", "Buttons are avilable :</br>"+Button+" for Product Type"+Productype);
									}
							}
							else
							{
								Reporters.SuccessReport("Verifying Buttons", "Buttons Avilable is "+Button+" is Mismatching and not as expected for Productype :"+Productype);
							}

						}

					}
				}
				else{
					Reporters.SuccessReport("Verifying Buttons", "No  Buttons Avilable ");		}
			}
			else
			{	
				Reporters.failureReport("Verifying Content list", " Expected values are not Present in the Content list </br>Course details:"+coursedetailsinputs+"</br>Product type :"+Prodcutypeinput+"</br> Buttons details are : No Buttons Avilable");
				return false;	 
			}


		}catch(Exception e){sgErrMsg="Failed to verify content list"+e;return false;}


		return falg;
	}

	public static boolean verifyProducttype(String Prodcutypeinput) throws Throwable
	{
		
		try

		{

			driver.findElement(By.xpath(".//a[contains(text(),'Refresh')]")).click();
			Thread.sleep(medium);
			driver.findElement(By.xpath(".//a[contains(text(),'Refresh')]")).click();
			Thread.sleep(medium);
			List<WebElement> TotalConentlist=driver.findElements(By.xpath(".//*[@id='set']/li/div/div/span"));
			int flag=0;
			String Productype="";
			Thread.sleep(100);
			for(int i=0;i<TotalConentlist.size();i++)

			{
				Productype=TotalConentlist.get(i).getText();

				if(Productype!=null)
				{
					if(Productype.contains(Prodcutypeinput))
					{
						Reporters.SuccessReport("Verifying Product type: " +Prodcutypeinput , "Product Type name is Present in Content list is:"+Productype );

						return true;

					}
					else
					{
						flag=1;

					}


				}

			}	

			if(flag==1)
			{
				Reporters.failureReport("Verifying Product type Details Sequence:"+Prodcutypeinput, "Product Type name is not Present in Content list:"+Prodcutypeinput);

				return false;

			}
		}catch(Exception e){sgErrMsg="Failed to verify content list"+e;return false;}


		return flag;
	}


	public static boolean confirmbutton()throws Throwable
	{
		try
		{
			flag=true;
			b=true;
			Thread.sleep(3000);
			if(!click(ElsevierObjects.Yescheckbox, "Yes Check Box"))
			{flag=false;}

			if(!click(ElsevierObjects.confirmbutton, "Confirm Button"))
			{flag=false;}
			b=false;
			return flag;
		}catch(Exception e){sgErrMsg="Unable to click on Item"+e;return false;}
	}

	public static boolean clickonbutton_coursedetails(String Coursedetails,String button)throws Throwable
	{
		try
		{
			Thread.sleep(100);
			List<WebElement> TotalConentlist=driver.findElements(By.xpath(".//*[@id='set']/li//div//div[@class='item platform_product']"));
			List<WebElement> buttons=driver.findElements(By.xpath(".//*[@id='set']/li//div//div[@class='item platform_product']//a[contains(text(),'"+Coursedetails+"')]/following-sibling::button"));
			//driver.findElement(By.xpath(".//*[@id='set']/li//div//div[@class='item platform_product']//a[contains(text(),'"+Coursedetails+"')]"));
			for(int i=0;i<buttons.size();i++)
			{
				String temp=buttons.get(i).getText();
				if(temp.equalsIgnoreCase(button))
				{
					buttons.get(i).click();
				}
				//driver.findElement(By.xpath(".//*[@id='set']/li//div//div[@class='item platform_product']//a[contains(text(),'"+Coursedetails+"')]/following-sibling::button[contains(text(),'"+button+"')]")).click();
			}
			return true;
		}catch(Exception e){sgErrMsg="Unable to click on Item"+e;return false;}
	}

	public static boolean verifyingcoursedetailsafternavigationforcourse() throws Throwable
	{

		try
		{
			if(click(ElsevierObjects.courseLink_selfstudy, "Click on course link present in course details page."))
			{
				Reporters.SuccessReport("Clicking On Course Link.", "Clicked On Course Link In content menu.");
			}
			else
			{
				Reporters.failureReport("Clicking On Course Link.", "Failed To Click On Course Link In content menu.");
			}
			Thread.sleep(3000);
			List<WebElement> s=driver.findElements(ElsevierObjects.educator_CoursePage_SubFolders);
			for(WebElement subFolder:s){
				//String subFolders=getText(ElsevierObjects.educator_CoursePage_SubFolders, "Get All Subfolders Title.");

				if(waitForElementPresent(ElsevierObjects.educator_CoursePage_SubFolders, "Course folder contains sub folders."))
				{
					Reporters.SuccessReport("Verifying subfolders.", "Verified Subfolders of Course Folder.</br>SubFolder is:"+subFolder.getText());
				}
				else
				{
					Reporters.failureReport("Verifying subfolders.", "Failed To Verify Subfolders of Course Folder.");
				}
			}
			
		}catch(Exception e){
			sgErrMsg=e.getMessage();
			return false;
		}
		return true;
	}
	

	public static boolean verifyingcoursedetailsafternavigationforcontenthome() throws Throwable
	{

		try
		{//ElsevierObjects.educator_CoursePage_CourseContentLink
			if(click(By.linkText("Content Home"), "Click on Content Home link present in course details page."))
			{
				Reporters.SuccessReport("Clicking On Content Home Link.", "Clicked On Content Home Link In content menu.");
			}
			else
			{
				Reporters.failureReport("Clicking On Content Home Link.", "Failed To Click On Content Home Link In content menu.");
			}
			Thread.sleep(2000);
			List<WebElement> s=driver.findElements(ElsevierObjects.educator_CoursePage_SubFolders);
			for(WebElement subFolder:s){
				//String subFolders=getText(ElsevierObjects.educator_CoursePage_SubFolders, "Get All Subfolders Title.");

				if(waitForElementPresent(ElsevierObjects.educator_CoursePage_SubFolders, "Course folder contains sub folders."))
				{
					Reporters.SuccessReport("Verifying subfolders.", "Verified Subfolders of Course Folder.</br>SubFolder is:"+subFolder.getText());
				}
				else
				{
					Reporters.failureReport("Verifying subfolders.", "Failed To Verify Subfolders of Course Folder.");
				}
			}
			
		}catch(Exception e){
			sgErrMsg=e.getMessage();
			return false;
		}
		return true;
	}

	public static boolean clickon_coursedetails(String Coursedetails)throws Throwable
	{
		try
		{
			List<WebElement> TotalConentlist=driver.findElements(By.xpath(".//*[@id='set']/li//div//div[@class='item platform_product']"));
			driver.findElement(By.xpath(".//*[@id='set']/li//div//div[@class='item platform_product']//a[contains(text(),'"+Coursedetails+"')]")).click();
			return true;
		}catch(Exception e){sgErrMsg="Unable to click on Course Details"+e;return false;}
	}
	public static boolean Entercourseid(String Courseid)throws Throwable
	{
		try
		{
			flag=true;
			b=true;
			if(!type(ElsevierObjects.courseid_acc,Courseid, "Enter Course id"))
			{flag=false;}

			if(!click(ElsevierObjects.Continue, "Continue button"))
			{flag=false;}
			Thread.sleep(10000);
			String succesmsg=getText(By.xpath(".//*[@id='modalCourseId-okay']/p[1]"), "Success Message");
			if(succesmsg.contains("Thank you for your request! You have successfully enrolled into your instructor's course."))
			{

				Reporters.SuccessReport("Message appeared ", "The following message appeared : "+succesmsg);
			}else{
				Reporters.failureReport("Message not appeared ", "The following message not appeared : "+succesmsg);
			}

			if(!click(ElsevierObjects.Okbutton, "Continue button "))

			{flag=false;}
			Thread.sleep(4000);
			b=false;
			return flag;
		}catch(Exception e){sgErrMsg="Unable to Enter course Details"+e;return false;}

	}

	public static boolean adminPARVerify(String userName)throws Throwable{
		boolean flag=true;
		try{
			click(ElsevierObjects.VIEWPROFILE_LINK, "Click on view edit profile");
			type(By.name("username"), userName, "Username");
			click(By.name("action"), "Search Button");
			Thread.sleep(3000);
			click(By.xpath("//*[@id='evolve_usersearchlist_table']/tbody/tr/td[1]"), "Username");
			Thread.sleep(3000);
			click(By.id("parBtn"), "PAR Button");
			if(isElementPresent(By.xpath("//strong[text()='Manage Protected Access Rights']"),""))
				Reporters.SuccessReport("Verify Manage Protected Access Rights page", "User is taken to Manage Protected Access Rights Page");
			else
				Reporters.failureReport("Verify Manage Protected Access Rights page", "User is unable to take Manage Protected Access Rights Page");

		}catch(Exception e){
			System.out.println("Exception occurred");
			sgErrMsg=e.getMessage();
			return false;
		}
		return flag;
	}


	public static boolean verifytable(String ISBN,int days) throws Throwable
	{
		try
		{
			List <WebElement>totalrows=driver.findElements(By.xpath(".//*[@id='protectedaccessrightsdiv']/table/tbody/tr"));
			int flag=1;
			for(int i=0;i<totalrows.size();i++)
			{
				String courseid=totalrows.get(i).findElement(By.xpath(".//td[2]")).getText();
				if(courseid.contains(ISBN))
				{
					flag=0;
					String StartDate=totalrows.get(i).findElement(By.xpath(".//td[4]")).getText();
					String EndDate=totalrows.get(i).findElement(By.xpath(".//td[5]")).getText();

					/*
	 SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

		Date d1 = null;
		Date d2 = null;
		//Period period = new Period(d1, d2);
		d1 = format.parse(StartDate);
		d2 = format.parse(EndDate);
		long diff = d2.getTime() - d1.getTime();


		long diffDays = diff / (24 * 60 * 60 * 1000);

		System.out.print(diffDays + " days, ");

//To Verfiy Boundry values we added possible combination of including last date , without inclucding last date
					 */

					//String dateStart = "12/03/2014";
					//String dateStop = "06/01/2015";

					SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

					Date d1 = null;
					Date d2 = null;


					d1 = format.parse(StartDate);
					d2 = format.parse(EndDate);

					DateTime dt1 = new DateTime(d1);
					DateTime dt2 = new DateTime(d2);

					System.out.print(Days.daysBetween(dt1, dt2).getDays() + " days, ");
					long diffDays=Days.daysBetween(dt1, dt2).getDays();


					if(diffDays==days)
					{
						Reporters.SuccessReport("Verifying ISBN Duration from start date to End date: "+ISBN, "Most Recent details of ISBN :"+ISBN+"</br>Course Details:"+courseid+"</br> Start Date: "+StartDate+"</br> End Date: "+EndDate+"</br> Difference between days : "+days);	
						return true;
					}else 
					{
						Reporters.failureReport("Verifying ISBN Duration from start date to End date: "+ISBN, "Most Recent details of ISBN :"+ISBN+"</br>Course Details:"+courseid+"</br> Start Date: "+StartDate+"</br> End Date: "+EndDate+"</br> Difference between days : "+diffDays);
						return false;

					}


				}
				else
				{
					flag =1;

				}

			}
			if(flag==1)
			{
				Reporters.failureReport("Verifying ISBN  is not present "+ISBN, "ISBN is not present in the Results");  	  

			}
			return false;
		}catch( Exception e){sgErrMsg="Failed to check the results"+e; return false;}


	}

	public static boolean verifyHoneyPot() throws Throwable{
		boolean flag = true;
		try{
			Thread.sleep(3000);
			driver.findElement(ElsevierObjects.catalog).sendKeys(Keys.ENTER);
			Thread.sleep(3000);
			if(isElementPresent(ElsevierObjects.enrollHoneyPotImg)){
				Reporters.SuccessReport("Clicking On Catalog Tab.", "Successfully Clicked On Catalog Tab.");
			}
			else{
				Reporters.failureReport("Clicking On Catalog Tab.", "Failed To Click On Catalog Tab.");
			}
			Thread.sleep(3000);

			if(javaClick(ElsevierObjects.enrollHoneyPotImg, "Click on Honey Pot Image")){
				Reporters.SuccessReport("Clicking On Online Course Honey Pot.", "Successfully Clicked On Online Course Honey Pot.");
			}
			else{
				Reporters.failureReport("Clicking On Online Course Honey Pot.", "Failed To Click On Online Course Honey Pot.");
			}             
			Thread.sleep(5000);
			waitForVisibilityOfElement(ElsevierObjects.enrollHoneyPotInstructorCourse, "Enroll HoneyPot Instructor Course");
			if(javaClick(ElsevierObjects.enrollHoneyPotInstructorCourse, "Click on enroll in instructors course")){
				Reporters.SuccessReport("Clicking On Enroll Your Course Link in Online Course Honeypot.", "Successfully Clicked On Enroll Your Course Link in Online Course Honey Pot.");
			}
			else{
				Reporters.failureReport("Clicking On Enroll Your Course Link in Online Course Honeypot.", "Failed To Click On Enroll Your Course Link in Online Course Honey Pot.");
			}             
			Thread.sleep(3000);
		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());return false;
		}

		return flag;
	}

	public static boolean selfEnrollNavigate(String courseid) throws Throwable{
		boolean flag = true;
		try{
			if(type(ElsevierObjects.enrollResourceId, courseid, "Input Course Id ")){
				Reporters.SuccessReport("Entering CourseID in Required TextBox.", "Entered CourseID "+courseid+" in  TextBox.");
			}
			else{
				Reporters.failureReport("Entering CourseID in Required TextBox.", "Failed To Enter CourseID "+courseid+" in  TextBox.");
			}      
	
			Thread.sleep(2000);
			if(click(ElsevierObjects.enrollContinue, "Click on Continue Button")){
				Reporters.SuccessReport("Clicking On Continue Button After Entering CourseID.", "Successfully Clicked On Continue Button.</br>Navigated To My Evolve Page.");
			}
			else{
				Reporters.failureReport("Clicking On Continue Button After Entering CourseID.", "Failed To Click On Continue Button");
			}
	
			Thread.sleep(4000);
			String succesmsg=getText(By.xpath(".//*[@id='youreEnrolled']/p"), "Success Message");
			if(succesmsg.contains("Thank you for your request! This product is now available in your My Evolve content list."))
			{
				Reporters.SuccessReport("Message appeared ", "The following message appeared : "+succesmsg);
			}else{
				Reporters.failureReport("Message not appeared ", "The following message not appeared : Thank you for your request! This product is now available in your My Evolve content list.");
			}
	
			if(click(ElsevierObjects.Successfulenroll, "Click on Continue Button")){
				Reporters.SuccessReport("Clicking On Continue Button After Successful Enrollment.", "Successfully Clicked On Continue Button.</br>Navigated To My Evolve Page.");
			}
			else{
				Reporters.failureReport("Clicking On Continue Button After Entering CourseID.", "Failed To Click On Continue Button.</br>Failed To Navigate To My Evolve Page.");
			}
	
	
			Thread.sleep(2000);
		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());return false;
		
		}
		return flag;
	}


	}






