package com.cigniti.automation.BusinessFunctions;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Reporters;

public class PromotionSinglePercentageExclusions_15580 extends EvolveCommonBussinessFunctions{

	public static boolean validateISBNSection() throws Throwable{
		boolean flag=true;
		try{
			
			String condition="exclusion";
			flag=PromotionVariablePercentageExclusions_15581.validateISBNSection(condition, ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExcludeTxtBox, 
					ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExludeBtn, 
					ElsevierObjects.Promotion_ExclusionVariable_ProISBNErrorMsg, ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExludeSucMsg,
					ElsevierObjects.Promotion_ExclusionVariable_ISBNAddList, ElsevierObjects.Promotion_ExclusionVariable_ISBNRem, 
					readcolumns.twoColumns(0, 1, "Ecom_TCID_10217", configProps.getProperty("TestData")).get("InvalidISBN"));	

			/*flag= validateViewAll(ElsevierObjects.Promotion_ExclusionVariable_ISBNViewAll, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_PrdTyp_ViewNewPageMsg, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_MajSub_VwNewPageRemove, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwBack, 
					ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwChkBox, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_VwTxtVrfy, ElsevierObjects.Admin_Evolve_Ecom_CrsPrm_RmvData, VerifyText3,"isbnIncExclusion");*/
			
					
		}catch(Exception e){return false;}
		return flag;	
	}
	
	/*public static boolean validateISBNDataAddedInput(String condition) throws Throwable{
		boolean flag=true;
		try{
			if(condition.equalsIgnoreCase("exclusion")){
			List<WebElement> isbnDataAdded=driver.findElements(ElsevierObjects.Promotion_isbnListValueExclude);
			for(WebElement e: isbnDataAdded){
			Reporters.SuccessReport("List of ISBNs added One by One into the Text box", "ISBN is added to the ISBN Text box Successfully : " + e.getText());}
			}else{
				List<WebElement> isbnDataAdded=driver.findElements(ElsevierObjects.Promotion_isbnListValueExclude);
				int size=isbnDataAdded.size();
				int count=0;
				for(WebElement e: isbnDataAdded)
				{
					if(count<3){
					Reporters.SuccessReport("List of ISBNs added One by One into the Text box", "ISBN is added to the ISBN Text box Successfully : " + e.getText());
					count++;
					}else{
						System.out.println("Come out from loop");
					}
				}
			}
		}catch(Exception e){System.out.println(e.getMessage()); return false;}
		return flag;
	}
	
	public static boolean validateISBNDataAddedUpload(String condition) throws Throwable{
		boolean flag=true;
		try{
			if(condition.equalsIgnoreCase("exclusion")){
			List<WebElement> isbnDataAdded=driver.findElements(ElsevierObjects.Promotion_isbnListValueExclude);
			for(WebElement e: isbnDataAdded){
			Reporters.SuccessReport("List of ISBNs added One by One into the Text box", "ISBN is added to the ISBN Text box Successfully : " + e.getText());}
			}else{
				List<WebElement> isbnDataAdded=driver.findElements(ElsevierObjects.Promotion_isbnListValueExclude);
				int size=isbnDataAdded.size();
				int count=0;
				for(WebElement e: isbnDataAdded)
				{
					if(count<3){
					Reporters.SuccessReport("List of ISBNs added One by One into the Text box", "ISBN is added to the ISBN Text box Successfully : " + e.getText());
					count++;
					}else{
						System.out.println("Come out from loop");
					}
				}
			}
		}catch(Exception e){System.out.println(e.getMessage()); return false;}
		return flag;
	}*/
	//Validating the ISBN Upload Section
	public static boolean uploadCSVFile() throws Throwable{
		boolean flag=true;
		String condition="exclusion";
		try{
		flag=PromotionVariablePercentageExclusions_15581.uploadCSVFile(condition, ElsevierObjects.Promotion_ExclusionVariable_ISBNBrowse, 
				ElsevierObjects.Promotion_ExclusionVariable_ISBNUpload, ElsevierObjects.marketingPageSinglePercentage_PrmPge_ISBNExludeSucMsg);
		flag=PromotionVariablePercentageExclusions_15581.removeVerify(ElsevierObjects.Promotion_ExclusionVariable_ISBNUplRem, ElsevierObjects.remove11, ElsevierObjects.remove12);
		Thread.sleep(medium);
		
	}catch(Exception e){
		System.out.println(e.getMessage());return false;
	}
		return flag;
	}
	
}
