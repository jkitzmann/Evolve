package com.cigniti.automation.Test;

import java.util.Random;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.Admin_BusinessFunction;
import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.accelerators.Base;
import com.cigniti.automation.Utilities.Reporters;

public class Search_RemoveCancelledandRemoveOutofPrintProducts_AdminUpdate_15477and15595 extends EvolveCommonBussinessFunctions{
	Random ra = new Random( System.currentTimeMillis() );	
	@Test
	public void Search_RemoveCancelledandRemoveOutofPrintProducts_AdminUpdateISBN_15477and15595() throws Throwable{
		try 
		{
		       //HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		
			stepReport("Update status of first product to Cancelled");
			
			Thread.sleep(low);
            writeReport(SwitchToBrowser(ElsevierObjects.adminBrowserType),"Launching Browser for Admin User","Launching Browser for Admin User is succesful","Lanching Browser for Admin User is failed");

			String ISBN=ReadingExcel.columnDataByHeaderName("ISBN1", "AdminTC-15477and15595", configProps.getProperty("TestData"));
			String Processvalue=ReadingExcel.columnDataByHeaderName("Processvalue1", "AdminTC-15477and15595", configProps.getProperty("TestData"));
			String StatuCode=ReadingExcel.columnDataByHeaderName("StatuCodeUpdate1", "AdminTC-15477and15595", configProps.getProperty("TestData"));
		   
			writeReport(EvolveCommonBussinessFunctions.evolveAdminlogin(),"Login to Application Using User Credentials"+ configProps.getProperty("AdminUser"),
					"Launching the URL for User is successful </br > Login to Application Using User credentails :"+configProps.getProperty("AdminUser")+" is Successful",
					"Launching and Login to Application Using User credentails : "+ configProps.getProperty("AdminUser")+" is Failed");
			Thread.sleep(high);
			
			writeReport(Admin_BusinessFunction.NavigatetoBusinessProducts(), "Navigating to Basic Product Reports under ONIX PPM Load Data Manager ",  
					"Navigating to Basic Product Reports under ONIX PPM Load Data Manager is Successful ",
					"Navigating to Basic Product Reports under ONIX PPM Load Data Manager is failed ");
			
			writeReport(Admin_BusinessFunction.EditISBNStatusCode(ISBN, Processvalue,StatuCode), "Editing ISBN : " +ISBN,  
					"Entering ISBN "+ISBN+" is successful </br> Selecting "+Processvalue+" is Successful</br> Clicking on Go is Successful </br> Selecting "+StatuCode+" is Successful </br>Clicking on Edit is Successful</br> 'Product Resource is successfully updated' Message appeared",
					"Editing ISBN is failed");
			Thread.sleep(high);

		    stepReport("Update status of second product to Out Of Print");
			
			ISBN=ReadingExcel.columnDataByHeaderName("ISBN2", "AdminTC-15477and15595", configProps.getProperty("TestData"));
			Processvalue=ReadingExcel.columnDataByHeaderName("Processvalue2", "AdminTC-15477and15595", configProps.getProperty("TestData"));
			StatuCode=ReadingExcel.columnDataByHeaderName("StatuCodeUpdate2", "AdminTC-15477and15595", configProps.getProperty("TestData"));
			 
			Thread.sleep(high);
			
			writeReport(Admin_BusinessFunction.EditISBNStatusCode(ISBN, Processvalue,StatuCode), "Editing ISBN : " +ISBN,  
					"Entering ISBN "+ISBN+" is successful </br> Selecting "+Processvalue+" is Successful</br> Clicking on Go is Successful </br> Selecting "+StatuCode+" is Successful </br>Clicking on Edit is Successful</br> 'Product Resource is successfully updated' Message appeared",
					"Editing ISBN is failed");
			Thread.sleep(high);
			
			stepReport("Archive the third product");
			
			// get the isbn to be archived
			ISBN=ReadingExcel.columnDataByHeaderName("ISBN3", "AdminTC-15477and15595", configProps.getProperty("TestData"));
			
			// navigate to maintain products
			writeReport(click(ElsevierObjects.Admin_Evolve_AdminLink, "Click Evolve Admin breadcrumb"),
					"Navigate to main Admin page",
					"Successfully navigated to main Admin page", "Failed to navigate to main Admin page");
			Thread.sleep(low);
			
			writeReport(click(ElsevierObjects.admin_MaintainProduct_lnk, "Click Maintain Products"),
					"Navigate to Maintain Products",
					"Successfully navigated to Maintain Products","Failed to navigate to Maintain Products");
			Thread.sleep(low);
			
			// verify the archived/cancelled/out-of-print checkboxes are present and checked by default
			// archived checkbox
			if (isElementPresent(ElsevierObjects.Exclude_Archived, "Archived checkbox")){
				if (isChecked(ElsevierObjects.Exclude_Archived, "Archived checkbox")){
					Reporters.SuccessReport("Verify Archived checkbox is displayed and checked by default",
							"Archived checkbox is displayed and checked by default.");
				}
				else 
					Reporters.failureReport("Verify Archived checkbox is displayed and checked by default",
							"Archived checkbox is displayed but is not checked by default.");
			}
			else {
				Reporters.failureReport("Verify the Archived checkbox is displayed and checked by default",
						"The Archived checkbox is not displayed.");
			}
			
			// cancelled checkbox
			if (isElementPresent(ElsevierObjects.Exclude_Cancelled, "Cancelled checkbox")){
				if (isChecked(ElsevierObjects.Exclude_Cancelled, "Cancelled checkbox")){
					Reporters.SuccessReport("Verify Cancelled checkbox is displayed and checked by default",
							"Cancelled checkbox is displayed and checked by default.");
				}
				else 
					Reporters.failureReport("Verify Cancelled checkbox is displayed and checked by default",
							"Cancelled checkbox is displayed but is not checked by default.");
			}
			else {
				Reporters.failureReport("Verify the Cancelled checkbox is displayed and checked by default",
						"The Cancelled checkbox is not displayed.");
			}
			
			// out of print checkbox
			if (isElementPresent(ElsevierObjects.Exclude_OOP, "Out Of Print checkbox")){
				if (isChecked(ElsevierObjects.Exclude_OOP, "Out Of Print checkbox")){
					Reporters.SuccessReport("Verify Out Of Print checkbox is displayed and checked by default",
							"Out Of Print checkbox is displayed and checked by default.");
				}
				else 
					Reporters.failureReport("Verify Out Of Print checkbox is displayed and checked by default",
							"Out Of Print checkbox is displayed but is not checked by default.");
			}
			else {
				Reporters.failureReport("Verify the Out Of Print checkbox is displayed and checked by default",
						"The Out Of Print checkbox is not displayed.");
			}
			
			// search for the product and click on it
			if (type(ElsevierObjects.admin_MaintainProduct_Knotxt, ISBN, "Enter ISBN in search field")){
				Reporters.SuccessReport("Enter ISBN in search field", "Successfully entered ISBN in search field.");
			}
			else
				Reporters.failureReport("Enter ISBN in search field", "Failed to enter ISBN in search field.");
			
			Thread.sleep(low);
			if (click(ElsevierObjects.admin_MaintainProduct_Submit, "Click on search button")) {
				Reporters.SuccessReport("Click Search button","Successfully clicked on Search button.");
			}
			else
				Reporters.failureReport("Click on Search button", "Failed to click on Search button.");
			Thread.sleep(low);
			
			if (click(ElsevierObjects.MaintainPrdct_prdctSerachReslut_isbn,"Click on isbn num in product result page")) {
				Reporters.SuccessReport("Click on ISBN in search results", "Successfully clicked on ISBN in search results.");
			}
			else
				Reporters.failureReport("Click on ISBN in search results", "Failed to click on ISBN in search results.");
			Thread.sleep(medium);
			
			// verify Archived checkbox is displayed and unchecked by default
			if (isElementPresent(ElsevierObjects.Archived, "Archived checkbox")){
				if (isCheckedNegative(ElsevierObjects.Archived, "Archived checkbox")){
					Reporters.failureReport("Verify Archived checkbox is displayed and unchecked by default",
							"Archived checkbox is displayed but is checked by default.");
				}
				else 
					Reporters.SuccessReport("Verify Archived checkbox is displayed and unchecked by default",
							"Archived checkbox is displayed and unchecked by default.");
			}
			else {
				Reporters.failureReport("Verify the Archived checkbox is displayed and unchecked by default",
						"The Archived checkbox is not displayed.");
			}
			
			// check the archived box and save
			if (click(ElsevierObjects.Archived, "Click the Archived checkbox")) {
				Reporters.SuccessReport("Check the Archived box", "Successfully checked the Archived box.");
			}
			else
				Reporters.failureReport("Check the Archived box", "Failed to check the Archived box.");
			
			if (click(ElsevierObjects.Save_and_Publish, "Click the Save & Publish button")) {
				Reporters.SuccessReport("Click the Save & Publish button", "Successfully clicked the Save & Publish button.");
			}
			else
				Reporters.failureReport("Click the Save & Publish button", "Failed to click the Save & Publish button.");
			Thread.sleep(medium);
			
			// verify messaging on screen after archiving product
			String expectedMsg = ReadingExcel.columnDataByHeaderName("ProdUpdatedMsg", "AdminTC-15477and15595", configProps.getProperty("TestData"));
			String actualMsg = getText(ElsevierObjects.Updated_Successfully_Msg, "Product updated message");
			if (expectedMsg.equals(actualMsg)){
				Reporters.SuccessReport("Verify that the correct 'product updated' message is displayed",
						"The correct message is displayed:</br>" +
						"Expected: " + expectedMsg + "</br>" +
						"Actual: " + actualMsg);
			}
			else {
				Reporters.failureReport("Verify that the correct 'product updated' message is displayed",
						"The correct message is not displayed:</br>" +
						"Expected: " + expectedMsg + "</br>" +
						"Actual: " + actualMsg);
			}
			
			expectedMsg = ReadingExcel.columnDataByHeaderName("ProdArchivedMsg", "AdminTC-15477and15595", configProps.getProperty("TestData"));
			actualMsg = getText(ElsevierObjects.Product_Archived_Msg, "Product updated message");
			if (expectedMsg.equals(actualMsg)){
				Reporters.SuccessReport("Verify that the correct 'product archived' message is displayed",
						"The correct message is displayed:</br>" +
						"Expected: " + expectedMsg + "</br>" +
						"Actual: " + actualMsg);
			}
			else {
				Reporters.failureReport("Verify that the correct 'product archived' message is displayed",
						"The correct message is not displayed:</br>" +
						"Expected: " + expectedMsg + "</br>" +
						"Actual: " + actualMsg);
			}
			
			click(ElsevierObjects.StudentTab, "Student tab");
			Thread.sleep(medium);
			actualMsg = getText(ElsevierObjects.Product_Archived_Msg, "Product updated message");
			if (expectedMsg.equals(actualMsg)){
				Reporters.SuccessReport("Verify that the correct 'product archived' message is displayed on the Student tab",
						"The correct message is displayed:</br>" +
						"Expected: " + expectedMsg + "</br>" +
						"Actual: " + actualMsg);
			}
			else {
				Reporters.failureReport("Verify that the correct 'product archived' message is displayed on the Student tab",
						"The correct message is not displayed:</br>" +
						"Expected: " + expectedMsg + "</br>" +
						"Actual: " + actualMsg);
			}
			
			writeReport(click(ElsevierObjects.Admin_Evolve_AdminLink, "Click Evolve Admin breadcrumb"),
					"Navigate to main Admin page",
					"Successfully navigated to main Admin page", "Failed to navigate to main Admin page");
			Thread.sleep(low);
			
			writeReport(click(ElsevierObjects.admin_MaintainProduct_lnk, "Click Maintain Products"),
					"Navigate to Maintain Products",
					"Successfully navigated to Maintain Products","Failed to navigate to Maintain Products");
			Thread.sleep(low);
			
			click(ElsevierObjects.Exclude_Archived, "Uncheck Exclude Archived checkbox");
			
			if (type(ElsevierObjects.admin_MaintainProduct_Knotxt, ISBN, "Enter ISBN in search field")){
				Reporters.SuccessReport("Enter ISBN in search field", "Successfully entered ISBN in search field.");
			}
			else
				Reporters.failureReport("Enter ISBN in search field", "Failed to enter ISBN in search field.");
			
			Thread.sleep(low);
			if (click(ElsevierObjects.admin_MaintainProduct_Submit, "Click on search button")) {
				Reporters.SuccessReport("Click Search button","Successfully clicked on Search button.");
			}
			else
				Reporters.failureReport("Click on Search button", "Failed to click on Search button.");
			
			Thread.sleep(low);
			if (click(ElsevierObjects.MaintainPrdct_prdctSerachReslut_isbn,"Click on isbn num in product result page")) {
				Reporters.SuccessReport("Click on ISBN in search results", "Successfully clicked on ISBN in search results.");
			}
			else
				Reporters.failureReport("Click on ISBN in search results", "Failed to click on ISBN in search results.");
			Thread.sleep(medium);
			
// ------------------ need to verify that the archived box is still checked and archived message displayed, then can move on to the rest
			actualMsg = getText(ElsevierObjects.Product_Archived_Msg, "Product updated message");
			if (expectedMsg.equals(actualMsg)){
				Reporters.SuccessReport("Verify that the correct 'product archived' message is still displayed",
						"The correct message is displayed:</br>" +
						"Expected: " + expectedMsg + "</br>" +
						"Actual: " + actualMsg);
			}
			else {
				Reporters.failureReport("Verify that the correct 'product archived' message is still displayed",
						"The correct message is not displayed:</br>" +
						"Expected: " + expectedMsg + "</br>" +
						"Actual: " + actualMsg);
			}
			
			if (isElementPresent(ElsevierObjects.Archived, "Archived checkbox")){
				if (isChecked(ElsevierObjects.Archived, "Archived checkbox")){
					Reporters.SuccessReport("Verify Archived checkbox is displayed and is checked",
							"Archived checkbox is displayed and is checked.");
				}
				else 
					Reporters.failureReport("Verify Archived checkbox is displayed and is checked",
							"Archived checkbox is displayed but is unchecked.");
			}
			else {
				Reporters.failureReport("Verify the Archived checkbox is displayed and unchecked by default",
						"The Archived checkbox is not displayed.");
			}
			
			driver.navigate().to(configProps.getProperty("NoCacheURL"));
			Thread.sleep(high);
	        driver.navigate().to(configProps.getProperty("SOLR"));
	        boolean falg_SOLR=true;
	        writeReport(falg_SOLR, "Run SOLR reindexing job"+configProps.getProperty("SOLR"), "Running SOLR Job is Successful", "Running SOLR Job is failed");
	        System.out.println("Wait for "+SOLRMinutes+" mins for preorder queue job to run");
			
			for(int i=1;i<=SOLRMinutes;i++) {
				Thread.sleep(60000);
				System.out.println("Completed Minutes:" +i );
			}
			System.out.println("Completed wait time for "+SOLRMinutes+" mins for preorder queue job to run");
			writeReport(falg_SOLR, "Wait for "+SOLRMinutes+" Min till the Indexing and SOLR job is completed", "Waiting for "+SOLRMinutes+" Minutes are Completed", "Waiting for "+SOLRMinutes+"Minutes are NOT Completed");
 
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
