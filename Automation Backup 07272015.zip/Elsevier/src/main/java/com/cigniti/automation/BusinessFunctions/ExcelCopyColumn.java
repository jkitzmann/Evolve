package com.cigniti.automation.BusinessFunctions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;
import com.google.common.collect.Table.Cell;
import com.cigniti.automation.Test.ReadFileExample;
import com.cigniti.automation.Utilities.ReadingExcel;

public class ExcelCopyColumn {
	
	@Test
	public void copyToExcel(String filepath,String sourceFile,String Destination,int colindex,String sheetName)
	{
		try {
	    	 ReadingExcel re=new ReadingExcel();
	    	 
	    	 //read existing column data(how much data available)
	 		 List<String> testdata1=re.columnData(colindex,sheetName, Destination);
	 		
	 		 //read txt file
	    	 ArrayList<String> columndata = (ArrayList<String>) ReadFileExample.readTxt(sourceFile);
	    	 
	    	 // update existing file
             FileInputStream file = new FileInputStream(new File(Destination));
          
             XSSFWorkbook workbook = new XSSFWorkbook(file);
             XSSFSheet sheet = workbook.getSheetAt(1);
             Cell cell = null;
     
             for(int i=0;i<columndata.size();i++)
             {
            	 Row dataRow = sheet.createRow(testdata1.size()-1+i);
                 dataRow.createCell(colindex).setCellValue(columndata.get(i).toString());
             }           
             file.close();
             
             FileOutputStream outFile =new FileOutputStream(new File(Destination));
             workbook.write(outFile);
             outFile.close();
             
         } catch (FileNotFoundException e) {
             e.printStackTrace();
         } catch (IOException e) {
             e.printStackTrace();
         }
}
		
}
