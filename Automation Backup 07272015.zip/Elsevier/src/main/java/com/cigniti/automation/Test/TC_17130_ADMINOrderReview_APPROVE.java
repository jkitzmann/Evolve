package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.FraudTestCases_Lib;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.Utilities.Database;
import com.cigniti.automation.accelerators.Base;

public class TC_17130_ADMINOrderReview_APPROVE extends FraudTestCases_Lib{
	
	@Test
	public void tc_17130_ADMINOrderReview_APPROVE() throws Throwable{
	//	HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		EvolveCommonBussinessFunctions.SwitchToBrowser(ElsevierObjects.adminBrowserType);
		
		String sUserName = configProps.getProperty("AdminUser");
		String sPassword = configProps.getProperty("AdminPassword");
		String orderNumber = ReadingExcel.columnDataByHeaderName("ORDER2", "FraudTestCases", testDataPath);
		String expectedConfidentialNote = ReadingExcel.columnDataByHeaderName("ConfidentialMessage1", "FraudTestCases", testDataPath);
		
		stepReport("Launch the URL: "+configProps.getProperty("URL2"));
		if(launchUrl(configProps.getProperty("URL2"))){
			Reporters.SuccessReport("Launch the URL "+configProps.getProperty("URL2"), "Successfully Launched URL "+configProps.getProperty("URL2"));
		}else{
			Reporters.failureReport("Launch the URL "+configProps.getProperty("URL2"), "Failed to Launch URL "+configProps.getProperty("URL2"));
		}
		
		stepReport("Login as Admin User with valid credentials");
		adminLogin(sUserName, sPassword);
		
		stepReport("Verify 'Maintain Suspicous Orders' section");
		maintainSuspicious();
		
		stepReport("Search for Order Number and Change the status to Approved");
		searchOrder(orderNumber, "Approved", expectedConfidentialNote);
		searchOrderRejected(orderNumber, "Approved");
		
		stepReport("Logout from Admin User");
		adminLogout();
		
		stepReport("Fraud database cleanup");
		Database.fraudDBCleanup();
		
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}















