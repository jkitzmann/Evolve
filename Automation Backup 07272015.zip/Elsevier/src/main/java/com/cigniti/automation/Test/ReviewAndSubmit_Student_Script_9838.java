package com.cigniti.automation.Test;

import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.BusinessFunctions.Review_SubmitStudentInstructor_Cancel;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;

public class ReviewAndSubmit_Student_Script_9838 extends Review_SubmitStudentInstructor_Cancel {

	@Test 
	public void reviewAndSubmit_Student_9838() throws Throwable{
		try {
			//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
			SwitchToBrowser(ElsevierObjects.studentBrowserType);
			String searchPaperback=ReadingExcel.columnDataByHeaderName("searchData", "ReviewAndSubmit",configProps.getProperty("TestData"));
			String isbn=ReadingExcel.columnDataByHeaderName("isbn", "ReviewAndSubmit",configProps.getProperty("TestData"));
			String user = "student";
			String reviewAndSubmit = "true";
			if(isElementPresent(ElsevierObjects.evolveCatalog)){
				click(ElsevierObjects.evolveCatalog, "Click on Catalog");
			}
			
			checkCart(user, reviewAndSubmit);
			searchAndAddproduct(reviewAndSubmit, searchPaperback);
			//String newToEvolve=getText(ElsevierObjects.newtoEvol, "New to Evolve");
			/*if(newToEvolve.contains("New to Evolve")){
				type(ElsevierObjects.educator_txtStudentUser, configProps.getProperty("StudentUser1"), "Existing Instructor username");
				type(ElsevierObjects.educator_txtStudentPassword, configProps.getProperty("StudentPassword1"), "Existing Instructor password");
				click(ElsevierObjects.educator_btnLogin, "Click on Login button");
			}*/
			if(isElementPresent(ElsevierObjects.newtoEvol)){
				type(ElsevierObjects.educator_txtStudentUser, configProps.getProperty("Student"), "Existing Student username");
				type(ElsevierObjects.educator_txtStudentPassword, configProps.getProperty("StudentPassword1"), "Existing Instructor password");
				click(ElsevierObjects.educator_btnLogin, "Click on Login button");
			}
			
			if(!EvolveCommonBussinessFunctions.creditCardDetails())
				flag = false;
			Thread.sleep(high);
			
			validteReviewPage();
			Thread.sleep(medium);
			if(verifyReviewAndSubmit(user)){
				Reporters.SuccessReport("Verify Review And Submit Page:", "Review And Submit Page Verified Successfully.");
			}else{
				Reporters.failureReport("Verify Review And Submit Page:", "Verification Failed For Review And Submit Page.");
			}
			Thread.sleep(medium);	
			if(deleteLink(isbn)){
				Reporters.SuccessReport("Delete Link:", "Second Link Delete Successfully.");
			}else{
				Reporters.failureReport("Delete Link:", "Second Link Failed  to Delete.");
			}
			ImplicitWait();
			Thread.sleep(medium);
			if(editCreditCard()){
				Reporters.SuccessReport("Edit Credit Link:", "Credit Card Link is Edited Successfully ");
			}else{
				Reporters.failureReport("Edit Credit Link:", "Failed to Edit Credit Card Link");
			}
			if(editBillingAddress()){
				Reporters.SuccessReport("Edit Billing Address Link:", "Billing Address Link is Edited Successfully ");
			}else{
				Reporters.failureReport("Edit Billing Address Link:", "Failed to Edit Billing Address Link");
			}
			if(editShippingAddress()){
				Reporters.SuccessReport("Edit Shipping Address Link:", "Shipping Address Link is Edited Successfully ");
			}else{
				Reporters.failureReport("Edit Shipping Address Link:", "Failed to Edit Shipping Address Link");
			}
			if(updateCreditCard()){
				Reporters.SuccessReport("Update Credit Card Details:", "Credit Card Details Update Successfully ");
			}else{
				Reporters.failureReport("Update Credit Card Details:", "Failed to Update Credit Card Details");
			}
			String billing="Billing";
			String value="TX";
			if(updateBillingAndShippingAddress(ElsevierObjects.statesBilling,value,ElsevierObjects.edit_BillingAddress,ElsevierObjects.billingAddressSave,ElsevierObjects.student_billingAddress, billing)){
				Reporters.SuccessReport("Update Billing Address Details:", "Billing Address Details Update Successfully ");
			}else{
				Reporters.failureReport("Update Billing Address Details:", "Failed to Update Billing Address Details");
			}
			ReadingExcel.updateCellInSheet(1,10,configProps.getProperty("TestData"), "ReviewAndSubmit", billingAddress);
			String shipping="Shipping";
			ImplicitWait();
			if(updateBillingAndShippingAddress(ElsevierObjects.statesShipping,value,ElsevierObjects.edit_ShippingAddress,ElsevierObjects.shippingAddressSave,ElsevierObjects.Student_Shipping_Addr1, shipping)){
				Reporters.SuccessReport("Update Billing Address Details:", "Billing Address Details Update Successfully ");
			}else{
				Reporters.failureReport("Update Billing Address Details:", "Failed to Update Billing Address Details");
			}
			ImplicitWait();
			submit(user);
			//Evolve Email Verfication..... 
			if(emailLogin()){
				Reporters.SuccessReport("EvolveMail Login:", "EvolveMail Login Successfully ");
			}else{
				Reporters.failureReport("Submit", "Failed to Login as EvolveMail.");
			}
			if(orderConformation(user)){
				Reporters.SuccessReport("Order Confirmation:", "Order Confirmed Successfully ");
			}else{
				Reporters.failureReport("Order Confirmation:", "Failed to Confirm Order.");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@AfterTest
	public void tear() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
	
	
}
