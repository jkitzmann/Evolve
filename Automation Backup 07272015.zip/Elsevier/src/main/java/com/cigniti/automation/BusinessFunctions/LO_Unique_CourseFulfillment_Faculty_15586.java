package com.cigniti.automation.BusinessFunctions;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.WritingExcel;

public class LO_Unique_CourseFulfillment_Faculty_15586 extends EvolveCommonBussinessFunctions{
	public static Map<String, String> values=readcolumns.twoColumnsBasedOnSheetName(0, 1, "Tc-9804", configProps.getProperty("TestData"));
	public static String courseLink;
	public static String protectionSchemeText;
	public static boolean verifyLOStatusInARPage(String format_LO) throws Throwable{
	boolean flag=true;
		try{	
		if(getAccountDetailsFirstName.contains(adoptionRequest_FirstName) && getAccountDetailsLastName.contains(adoptionRequest_LastName) && getAccountDetailsEmail.contains(adoptionRequest_Email) && getAccountDetailsInstitution.contains(adoptionRequest_Institution) && getAccountDetailsPhone.contains(adoptionRequest_Phone) && userName.contains(adoptionRequest_Username) && password.contains(adoptionRequest_Password)){
			if(title.contains(adoptionRequest_producttitle) && Isbn.contains(adoptionRequest_Isbn) && author.contains(adoptionRequest_Author) && productType.contains(adoptionRequest_ProductType) && adoptionRequest_Format.contains(format_LO)){
				System.out.println("I am in if block...........");
				verifyText(ElsevierObjects.adoptionRequestStatus, values.get("Status"), "Verify request status.");		
			}
		}		
		System.out.println("adoptionRequest_Comment:"+adoptionRequest_Comment);
		System.out.println("comment:"+comment);
		System.out.println("adoptionRequest_CourseContent:"+adoptionRequest_CourseContent);
		System.out.println("evolveContent:"+evolveContent);
		System.out.println("adoptionRequest_Enrollment:"+adoptionRequest_Enrollment);
		System.out.println("enrollment:"+enrollment);
		
		if(adoptionRequest_Comment.contains(comment) && adoptionRequest_CourseContent.contains(evolveContent) && adoptionRequest_Enrollment.contains(enrollment)){
			selectByValue(ElsevierObjects.adoptionRequestStatus, values.get("changeStatus"), "Change ststus to fullfilled.");
		}
			Thread.sleep(medium);				
			click(ElsevierObjects.adoptionRequest_Save,"Click on Save button.");
			Thread.sleep(high);
			click(ElsevierObjects.emailPopup,"Click on Send mail button on popup.");
	}
	 catch(Exception e){sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
		return flag;
	}
		
	public static boolean verifyLOStatusAfterEmailSentInARPage(String statusAfterEmailSent,String productId,String username) throws Throwable{
	boolean flag=true;
		try{
		 courseID1=getAttribute(ElsevierObjects.adoptionRequestCourseId1,"value", "Get courseId1");
		 System.out.println("courseID1:"+courseID1);
		 courseID2=getAttribute(ElsevierObjects.adoptionRequestCourseId2,"value", "Get CourseId2");
		 System.out.println("courseID2:"+courseID2);
		 WritingExcel.writeExcel(configProps.getProperty("TestData"), "TC-10410", courseID1, 1, 10);
		 WritingExcel.writeExcel(configProps.getProperty("TestData"), "TC-10410", courseID2, 1, 11);
 
		if(ElsevierObjects.adoptionRequestStatus.equals(statusAfterEmailSent) && courseID1.equals("("+productId+")"+"_"+"("+username+")"+"_"+"([0-9])")){
			System.out.println("in if block...................");
		}
	}
		 catch(Exception e){sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
		return flag;
	}
	 //(productID)_(instructorname on the AR)_(4 digit number)
	
	
	
	public static boolean reLogin(String facultyUserName,String facultyPassword)throws Throwable{
		try{	
			launchUrl(configProps.getProperty("URL3"));
			Thread.sleep(medium);
			
			click(ElsevierObjects.student_login, "click on student login");
			Thread.sleep(high);
			type(ElsevierObjects.educator_txtStudentUser,facultyUserName,"Enter user name.");
			Thread.sleep(high);
			type(ElsevierObjects.educator_txtStudentPassword,facultyPassword,"Enter password");
			Thread.sleep(high);
			click(ElsevierObjects.userLogin_btn,"Click on login button.");
		}
		 catch(Exception e){sgErrMsg=e.getMessage();
			System.out.println(e);return false;
		}
		return flag;
	}
public static boolean courseIDSearch(String ID1,String ID2) throws Throwable{
	try{	
		if(ID1.equalsIgnoreCase("true")){
		waitForVisibilityOfElement(ElsevierObjects.educator_courseSearch_ID1,"Verify course id1 present.");
		}
		if(ID2.equalsIgnoreCase("true")){
		waitForVisibilityOfElement(ElsevierObjects.educator_courseSearch_ID2, "Verify course id2 present.");
		}
		click(ElsevierObjects.educator_courseSearch_title,"Click on COurse Title.");
	
		Thread.sleep(60000);
		//driver.manage().timeouts().implicitlyWait(600, TimeUnit.SECONDS);
	}
	 catch(Exception e){sgErrMsg=e.getMessage();
		System.out.println(e);return false;
	}
	return flag;
}
}
