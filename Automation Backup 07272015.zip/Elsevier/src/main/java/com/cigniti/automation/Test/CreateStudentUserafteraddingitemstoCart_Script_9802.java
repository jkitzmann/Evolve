package com.cigniti.automation.Test;

import java.util.Random;

import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.CreateFacultyUserafteraddingitemstoCart_9803;
import com.cigniti.automation.BusinessFunctions.CreateFacultyUserfromSplashPage_9799;
import com.cigniti.automation.BusinessFunctions.CreateStudentUserafteraddingitemstoCart_9802;
import com.cigniti.automation.BusinessFunctions.ECommercePreorderALaCarte_Student_SplitOrders1_15597;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;

public class CreateStudentUserafteraddingitemstoCart_Script_9802 extends CreateStudentUserafteraddingitemstoCart_9802{
  @Test
  public void CreateStudentUserafteraddingitemstoCart_9802()throws Throwable{
	  
		 SwitchToBrowser(ElsevierObjects.studentBrowserType);
		 isbn = ReadingExcel.columnDataByHeaderName("isbnnew","TC-15588",configProps.getProperty("TestData"));
		 Firstname=ReadingExcel.columnDataByHeaderName("Firstname","TC-15588",configProps.getProperty("TestData"));
		 Lastname=ReadingExcel.columnDataByHeaderName("Lastname","TC-15588",configProps.getProperty("TestData"));
		 EmailId=ReadingExcel.columnDataByHeaderName("EmailId","TC-15588",configProps.getProperty("TestData"));
		 Random ra = new Random( System.currentTimeMillis() );
	     EmailId =ReadingExcel.columnDataByHeaderName("EmailId","TC-15588",configProps.getProperty("TestData"))+Integer.toString((1 + ra.nextInt(2)) * 1000 + ra.nextInt(1000))+"@evolveqa.info";
	     Password=ReadingExcel.columnDataByHeaderName("Password","TC-15588",configProps.getProperty("TestData"));
		 ConformPassword=ReadingExcel.columnDataByHeaderName("ConformPassword","TC-15588",configProps.getProperty("TestData"));
		 Country=ReadingExcel.columnDataByHeaderName("Country","TC-15588",configProps.getProperty("TestData"));
		 State=ReadingExcel.columnDataByHeaderName("State","TC-15588",configProps.getProperty("TestData"));
		 City=ReadingExcel.columnDataByHeaderName("City","TC-15588",configProps.getProperty("TestData"));
		 Institution=ReadingExcel.columnDataByHeaderName("Institution","TC-15588",configProps.getProperty("TestData"));
		 StreetAddress=ReadingExcel.columnDataByHeaderName("StreetAddress","TC-15588",configProps.getProperty("TestData"));
		 Year=ReadingExcel.columnDataByHeaderName("Year","TC-15588", configProps.getProperty("TestData"));
		 Zipcode=ReadingExcel.columnDataByHeaderName("ZipCode","TC-15588",configProps.getProperty("TestData"));
		 ProgramType=ReadingExcel.columnDataByHeaderName("ProgramType","TC-15588",configProps.getProperty("TestData"));
		 CityAddress=ReadingExcel.columnDataByHeaderName("CityAddress", "TC-15588",configProps.getProperty("TestData"));
		 StateAddress=ReadingExcel.columnDataByHeaderName("StateAddress","TC-15588",configProps.getProperty("TestData"));
		 
		 stepReport("Add item to cart and enter checkout");
		 writeReport(CreateStudentUserafteraddingitemstoCart_9802.Studentcreateafteraddingcart(),"Login and Register for product" ,
				                                                                                 "Successfully Launched EvolveCert URL </br> User is taken to StudentHoneyPot page </br> Searched for the Product From Simulation Honeypot for ISBN :" +isbn+ "</br> Registered for the product and click on Reedem/Checkout button",
				                                                                                 "Failed to Launch the URL and Register for product");
	     Thread.sleep(medium);
	     stepReport("Verify registration form and complete checkout");
	     writeReport(CreateStudentUserafteraddingitemstoCart_9802.Registeringdetails(),"Enter details into Registration form and submit the order",
	    		                                                                       "Entered details Successfully into Registration form,submitted the order and page is navigated to confirmation page",
	    		                                                                       "Failed to enter the Registration form and to enter details");
	     Thread.sleep(medium);
	     Thread.sleep(veryhigh);
	     stepReport("Log out and back in");
	     writeReport(CreateStudentUserafteraddingitemstoCart_9802.ConfirmationRelogin(),"Relogin using above Created user details and verify the product",
	    		                                                                        "Successfully Relogin with user details and verified the details of the product",     
	                                                                                    "Failed to Relogin and verify the details of the product");
	     Thread.sleep(low);   
	    
	     /*writeReport(CreateStudentUserafteraddingitemstoCart_9802.emailVerification(),"Launch EmailURL,login and search the Email registered",
	    		                                                                      "Successfully Launched Email URL,login and Registered Email is reached",
	    		                                                                      "Failed to Launch,login and get Registered Email");
*/		 Thread.sleep(medium);
		//SwitchToBrowser("Chrome");
		stepReport("Verify email");
		if(emailLogin()){
			Reporters.SuccessReport("Email login:", "Successfully logged into User Email.");
		}
		else{
			Reporters.failureReport("Email Login:", "Failed to login into User Email.");
		}
		
		CreateFacultyUserafteraddingitemstoCart_9803.emailVerification();
		}
}










