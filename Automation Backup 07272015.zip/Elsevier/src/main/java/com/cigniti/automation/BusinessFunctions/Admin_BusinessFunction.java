package com.cigniti.automation.BusinessFunctions;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.ReadingExcel;
import com.cigniti.automation.Utilities.Reporters;


public class Admin_BusinessFunction extends EvolveCommonBussinessFunctions
{
	public static int count1;
	public static int count;
	
	public static boolean notificationInMycart(String iSBNumber,String date ) throws Throwable{
		boolean flag=true;
		try{
		String s=date;
	    SimpleDateFormat ft = new SimpleDateFormat("MM-dd-yyyy");
	    Date d1=new SimpleDateFormat("yyyyMMdd").parse(s);
	    String verifydate=ft.format(d1);
	    System.out.println(ft.format(d1));
		try{
			String message = getText(By.xpath("//*[@id='"+iSBNumber+"']/div[5]"), "Notification Message.");
			if((message !=null )&& message.contains("To review your order at any time")){
				if(message.contains(verifydate)){
					Reporters.SuccessReport("Verifying Notification Message In MyCart Page.", "Verified Notification Message For ISBN: "+iSBNumber+" And Notification Message is :"+message+".</br>Verified publication date : "+verifydate+" in Notification Message.");
				}
				else
				{
					Reporters.failureReport("Verifying Notification Message In MyCart Page", "Failed To Verify Notification Message.");
				}
			}
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();return false;
		}
		return flag;
	}
	public static boolean newstudentBilling(String user,String streetAddress, String cityAddress, String stateAddress, String zip,String isbn1,String isbn2,String date)throws Throwable{
		boolean flag=true;
		try{
			if(user.equalsIgnoreCase("iteration")){
			click(ElsevierObjects.checkoutBtn, "Click on the Checkout Button");
			Thread.sleep(3000);
			click(ElsevierObjects.Student_Register_Chk, "Click on no institution checkbox");
			Thread.sleep(3000);
			type(ElsevierObjects.student_billingAddress,streetAddress,"Enter the Street Address in the box");
			Thread.sleep(1000);
			type(ElsevierObjects.student_billingAddress_city,cityAddress,"Enter City in the textbox");
			Thread.sleep(1000);
			selectByVisibleText(ElsevierObjects.student_billingAddress_state,stateAddress,"Enter State in the textbox");
			Thread.sleep(1000);
			type(ElsevierObjects.student_billingAddress_zip,zip,"Enter Zipcode in the textbox");
			Thread.sleep(1000);
			Reporters.SuccessReport("Enter and click","billing address is entered successfully and Details entered in billing address:</br>"+"Street Address :"+streetAddress+"</br>"+"CityAddress :"+cityAddress+"</br>"+"StateAddress :"+stateAddress+ "</br>"+"Zipcode :"+zip);
			click(ElsevierObjects.educator_form_btnContinue,"Click on continue button");
			Thread.sleep(1000);
			switchToFrameByLocator(ElsevierObjects.Admin_Evolve_Ecom_framename,"Switch to iframe");
			Thread.sleep(1000);
			String Popupheader = ReadingExcel.columnDataByHeaderName("PopUp", "TC-15588",configProps.getProperty("TestData"));
			String Popheader = getText(ElsevierObjects.Popup_header,"Get header of the frame");
			if(Popheader.contains(Popupheader)){
				Reporters.SuccessReport("Verify the header of Frame","PopupHeader is Successfully verified : </br> Expected Header is :"+Popheader+" </br> Actual Header is :"+Popupheader);
			}else{
				Reporters.failureReport("Verify the header of Frame","Failed to verify headers : </br> Expected Header is :"+Popheader+" </br> Actual Header is :"+Popupheader);
			}
			Thread.sleep(2000);
			if(click(ElsevierObjects.Use_this_address,"Click on use this address")){
				Reporters.SuccessReport("Click on Use this Address","Successfully clicked on Use this Address");
			}else{
				Reporters.failureReport("Click on Use this Address","Failed to click on Use this Address");
			}
			Thread.sleep(2000);
			String Creditheader = ReadingExcel.columnDataByHeaderName("Creditheader", "TC-15588",configProps.getProperty("TestData"));
			String cardheader = getText(ElsevierObjects.Creditcard_header,"Get header of the Page");
			if(cardheader.contains(Creditheader)){
				Reporters.SuccessReport("Verify the header of page","Creditcard Header is Successfully verified : </br> Expected Header is :"+cardheader+" </br> Actual Header is :"+Creditheader);
			}else{
				Reporters.failureReport("Verify the header of page","Failed to verify headers : </br> Expected Header is :"+cardheader+" </br> Actual Header is :"+Creditheader);
			}
			Thread.sleep(2000);
			if(creditCardDetails()){
				Reporters.SuccessReport("Enter Details and verify","Creditcard details are entered and User is Successfully taken to Review and Submit Page"); 
			}else{
				Reporters.failureReport("Enter Details and verify","User is Failed to enter creditcard details and to take Review and Submit page");
			}
			Admin_BusinessFunction.verifyMessageInReviewPage(isbn1,isbn2,date);
			Thread.sleep(4000);
			click(ElsevierObjects.Student_accept_chk, "Accept Checkbox");
			click(ElsevierObjects.Student_Review_Submit, "Review Submit Button");
			Thread.sleep(4000);
			}else{
				click(ElsevierObjects.checkoutBtn, "Click on the Checkout Button");
				Thread.sleep(3000);
				Thread.sleep(4000);
				click(ElsevierObjects.Student_accept_chk, "Accept Checkbox");
				click(ElsevierObjects.Student_Review_Submit, "Review Submit Button");
				Thread.sleep(4000);
			}

		}catch(Exception e){
			System.out.println(sgErrMsg="Exception occurred"+e);return false;
		}
		return flag;
	}

	public static boolean clickEvolveAndVerifyUserContent()throws Throwable{
		boolean flag=true;
		try{
			Thread.sleep(3000);
			if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(2000);
			if(!javaClick(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
				flag = false;
			}
			Thread.sleep(2000);
			if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}
			Thread.sleep(2000);
			if(!javaClick(ElsevierObjects.lnkevolvecart,"Clicked on Evolve Catalog")){
				flag = false;
			}
			Thread.sleep(2000);
			if(!javaClick(ElsevierObjects.Myevolve,"Click on my evolve")){
				flag=false;
			}

			Thread.sleep(3000);
			List<WebElement> listUserContent=driver.findElements(ElsevierObjects.userContentList);
			for(WebElement course: listUserContent){
				String courseList=course.getText();
				if(courseList!=null){
					Reporters.SuccessReport("Verify on the user's content list", "User Content list is verified successfully <br/> The Content list contains : "+courseList);
				}else{
					Reporters.failureReport("Verify on the user's content list", "User Content list is verification failed");
				}
			}



		}catch(Exception e){
			System.out.println("Exception occurred"+e);return false;
		}
		return flag;
	}

	public static boolean verifyMessageInReceiptPage(String ISBN1,String ISBN2,String date) throws Throwable{
		
	try{
		String s=date;
	    SimpleDateFormat ft = new SimpleDateFormat("MM-dd-yyyy");
	    Date d1=new SimpleDateFormat("yyyyMMdd").parse(s);
	    String verifydate=ft.format(d1);
	    System.out.println(ft.format(d1));
		
		ArrayList<String> list1=new ArrayList<String>();
		list1.add(ISBN1);
		list1.add(ISBN2);
		
		
		try{
			for(String list : list1){
				
				String notification=getText(By.xpath("//*[@id='pageLayout-body-inner-most']//li/div//div[contains(text(),'"+list+"')]//following::div[contains(@class,'notification_box rounded')]"),"");
				
					if(notification.contains("To review your order at any time")){
						if(notification.contains(verifydate)){
							Reporters.SuccessReport("Verifying Notification Message in Receipt Page.", "Verified Notification Message For ISBN: "+list+" And Notification Message is :"+notification+".</br>Verified publication date : "+verifydate+" in Notification Message.");
						}
						else
						{
							Reporters.failureReport("Verifying Notification Message in Receipt Page.", "Failed To Verify Notification Message.");
						}
					
					}
				}
		}
		catch(Exception e){
			sgErrMsg=e.getMessage();
		}
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();return false;
	}
	return true;
	}
	public static boolean VerifyOrderDetais(String ISBN1) throws Throwable{
		boolean flag=true;
		try{

			//String ISBN1_total=ISBN1;
			List<WebElement> totalrows=driver.findElements(By.xpath(".//div[@class='row']"));
			int index=0;
			//int flag_ver=0;
			Thread.sleep(5000);
			List<WebElement> totalordetrs=driver.findElements(By.xpath(".//div[@class='sidebar-list rounded']//h4/following-sibling::div"));
			int orderlist=totalordetrs.size();
			
			Thread.sleep(10);
				ordernumber1=totalrows.get(1).findElement(By.xpath(".//div[@class='sidebar-list rounded']//h4/following-sibling::div")).getText();		
				//ReadingExcel.updateCellInSheet(rowNumber, columnNumber, path, sheetName, cellValueToUpdate);
				List<WebElement> TotalISBNs=totalrows.get(1).findElements(By.xpath(".//div[@class='cartproductdetails']"));
				String [] stringParts = ISBN1.split(",");
				
				count=0;
				for(int b=0;b<stringParts.length;b++)
				{
				for(int a=0;a<TotalISBNs.size();a++)
				{
				
				String Temp=TotalISBNs.get(a).getText();
				
				String expectedvalue=stringParts[b];
				if(Temp.contains(expectedvalue))
				{
					/*ReadingExcel.updateCellInSheet(a+1, 1, testDataPath, "Tc-15558_Orders", ordernumber1);
					ReadingExcel.updateCellInSheet(a+1, 0, testDataPath, "Tc-15558_Orders", expectedvalue);
					count++;*/
					Reporters.SuccessReport("Verifying ISBN's in the Current order in Sequence:"+a, "ISBN's are present in the Current order Number:" +ordernumber1+" And ISBN details are"+Temp);
				//	flag_ver=1;
					break;
				}
				else
				{
				ISBN1=expectedvalue+",";
			   //  flag_ver=0;
				}
				}
				}
			//if(flag_ver==1)
		try{
				
				Thread.sleep(5000);
				//stringParts = ISBN1.split(",");
				ordernumber2=totalrows.get(3).findElement(By.xpath(".//div[@class='sidebar-list rounded']//h4/following-sibling::div")).getText();		
				count1=count;
				List<WebElement> TotalISBNs1=totalrows.get(3).findElements(By.xpath(".//div[@class='cartproductdetails']"));
				for(int b=0;b<stringParts.length;b++)
				{
				
				for(int a=0;a<TotalISBNs1.size();a++)
				{
					
					String Temp=TotalISBNs1.get(a).getText();
					String expectedvalue=stringParts[b];
					if(Temp.contains(expectedvalue))
						{
						index=a+1;
						/*ReadingExcel.updateCellInSheet(count+1, 1, testDataPath, "Tc-15558_Orders", ordernumber2);
						ReadingExcel.updateCellInSheet(count+1, 0, testDataPath, "Tc-15558_Orders", expectedvalue);
						count1++;*/
						Reporters.SuccessReport("Verifying ISBN's in the Current order in Sequence:"+a, "ISBN's are present in the Current order Number:" +ordernumber2+" And ISBN details are"+Temp);
						//flag_ver=1;
						}
					else
					{
						ISBN1=expectedvalue+",";
					//	flag_ver=0;
					}
				}
				}
			
			System.out.println("");
			}
			catch(Exception e){
				sgErrMsg=e.getMessage();
			}			
		}
		catch(Exception e12){
			sgErrMsg=e12.getMessage();
			Reporters.failureReport("Verifying Orders in Receipt Page.", "Failed To Verify Order Details.");

		}
		
		return flag;
	}
	public static boolean ordersVerificationEmailBody(String Order1,String Order2) throws Throwable{
		boolean flag=true;
		

		try{
		
			switchToFrameByLocator(ElsevierObjects.email_Body_Frame, "Switch to frame");
			Thread.sleep(3000);
			String emailBody=getText(ElsevierObjects.email_body_text,"Get email body text");
			
			if(emailBody.trim().contains(Order1.trim()) && emailBody.trim().contains(Order2.trim())){
				System.out.println("Check user details in email.");
				driver.switchTo().defaultContent();
				if(click(ElsevierObjects.email_logout,"Click on logout.")){
					
					Reporters.SuccessReport("Verifying Order details In Email Body.</br>Clicking On Logout Button.","Successfully Verified Order1: "+Order1+"</br>Order2: "+Order2+"</br></br>Email Body Is: "+emailBody+"</br></br>Successfully Clicked On Logout Button.");
				}
				else{
					Reporters.failureReport("Verifying Order details In Email Body.</br>Clicking On Logout Button.", "Failed To Verify Order Details </br>Order1: "+Order1+"</br>Order2: "+Order2+"</br>Failed To Click On Logout Button.  Email Body Is: "+emailBody+"</br>");
				}
				Thread.sleep(3000);
			}
			else{
				Reporters.failureReport("Verifying Order details In Email Body.", "Failed To Verify Order Details in Email Body.");
			}
		}
		
		catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println(e.getMessage());
			return false;
		}
	return flag;
	}
	public static boolean launchAndAddtoCart(String url,String Isbn1,String Isbn2,String date)throws Throwable{
		boolean flag=true;
		try{
			Thread.sleep(3000);
	
			launchUrl(url);
			Thread.sleep(3000);
			//System.out.println("");
			click(ElsevierObjects.Admin_Evolve_Ecom_AddtoCart, "Click on add to cart button");
			
			Thread.sleep(high);
			notificationInMycart(Isbn1,date);
			notificationInMycart(Isbn2,date);
			
			String myCart=getText(By.xpath(".//*[@id='pageLayout-body-inner-most']//h1[text()='My Cart']"), "My cart text");
			
			
			if(myCart!=null){
				Reporters.SuccessReport("Verify the package is added to the cart.", "The product is successfully added to My Cart<br/> The product is : "+myCart+"in URL is :"+driver.getCurrentUrl());
			}else{
				Reporters.failureReport("Verify the package is added to the cart.", "The product is not added to My Cart in URL is :"+driver.getCurrentUrl());
			}



		}catch(Exception e){
			sgErrMsg=e.getMessage();
			System.out.println("Exception occurred"+e);return false;
		}
		return flag;
	}

	public static boolean verifyMessageInReviewPage(String ISBN1,String ISBN2,String date) throws Throwable{
		boolean flag=true;
		
		try{
			String s=date;
		    SimpleDateFormat ft = new SimpleDateFormat("MM-dd-yyyy");
		    Date d1=new SimpleDateFormat("yyyyMMdd").parse(s);
		    String verifydate=ft.format(d1);
		    System.out.println(ft.format(d1));
			ArrayList<String> list1=new ArrayList<String>();
			
			list1.add(ISBN1);
			list1.add(ISBN2);
			Thread.sleep(10);
			for(String list2 : list1){
				try{
					
					String message=getText(By.xpath(".//*[@id='"+list2+"']/div[5]"),"Notification Message");	
					if((message !=null )&& message.contains("To review your order at any time")){
						if(message.contains(verifydate)){
							Reporters.SuccessReport("Verifying Notification Message in Review Page for The Item :"+list2, "Notification Message is"+message+"</br>Successfully Verified Publication date : "+verifydate+" In Notification Message.");
						}
						else{
							Reporters.failureReport("Verifying Notification Message in Review Page for The Item :"+list2, "Failed To Verify Notification Message.");
						}
					}
					
					//break;
				}
				catch(Exception e){
					sgErrMsg=e.getMessage();
				}
			}
		}
		catch(Exception e1){
			sgErrMsg=e1.getMessage();
		}
		return flag;
	}
public static boolean NavigatetoBusinessProducts() throws Throwable
{
try
{
	flag=true;
if(!click(ElsevierObjects.Baseproductreportlink , "Clicking on Base Product link"))
{flag=false;}
	
return flag;
}catch(Exception e){sgErrMsg="Clicking on Base product link is not successful"+e;return false;}

}

public static boolean NavigatetoMaintainProducts() throws Throwable
{
try
{
click(ElsevierObjects.MaintainProducts , "Clicking on Maintain Product link");
	
return true;
}catch(Exception e){sgErrMsg="Clicking on Base product link is not successful"+e;return false;}

}

public static boolean AddInclusionofSearchCriteriaFPROD(String ISBN) throws Throwable
{
	try{
		
		// uncheck cancelled and oop checkboxes
		click(ElsevierObjects.Exclude_Cancelled, "Uncheck Cancelled checkbox");
		click(ElsevierObjects.Exclude_OOP, "Uncheck Out of print checkbox");
		
		type(ElsevierObjects.SearchISBNinProductSearch,ISBN , "Searching for ISBN");
		driver.findElement(ElsevierObjects.SearchISBNinProductSearch).sendKeys(Keys.ENTER);
		//click(ElsevierObjects.Stuproduction, "Faculty Clicking on F-Prod");
		
		Thread.sleep(4000);
		click(ElsevierObjects.Facproduction, "Faculty Clicking on F-Prod");
		Thread.sleep(6000);
		
		click(ElsevierObjects.Fac_saveaswip, "Faculty Clicking on Save As WIP");
		Alert();
		if(!isNotChecked(ElsevierObjects.faculty_EnableeCommerece, "Faculty Enable Ecommerece"))
		{
		click(ElsevierObjects.faculty_EnableeCommerece, "Faculty Enable Ecommerece");
		}
		
		if(!isNotChecked(ElsevierObjects.faculty_Enablereg, "Faculty Enable Registrations"))
		{
		click(ElsevierObjects.faculty_Enablereg, "Faculty Enable Registrations");
		}
		
		if(!isNotChecked(ElsevierObjects.faculty_Includeinsearch, "Faculty Include Search"))
		{
		click(ElsevierObjects.faculty_Includeinsearch, "Faculty Include Search");
		}
		
		click(ElsevierObjects.facl_save, "Faculty Clicking on Save");
		Thread.sleep(6000);
		
		click(ElsevierObjects.facl_pubilsh, "Faculty Publishing the Changes");
		Thread.sleep(6000);
		Alert();
		Thread.sleep(2000);
		Alert();
		return true;
		
	}catch(Exception e){sgErrMsg="Clicking on Base product link is not successful"+e;return false;}
}

public static boolean AddInclusionofSearchCriteriaSPROD(String ISBN) throws Throwable
{
	try{

		Thread.sleep(4000);
		click(ElsevierObjects.StudentTab, "Faculty Clicking on F-Prod");
		Thread.sleep(4000);
		click(ElsevierObjects.Stu_saveaswip, "Faculty Clicking on Save As WIP");
		Thread.sleep(6000);
		Alert();
		if(!isNotChecked(ElsevierObjects.Std_EnableeCommerece, "Faculty Enable Ecommerece"))
		{
		click(ElsevierObjects.Std_EnableeCommerece, "Faculty Enable Ecommerece");
		}
		
		if(!isNotChecked(ElsevierObjects.Std_Enablereg, "Faculty Enable Registrations"))
		{
		click(ElsevierObjects.Std_Enablereg, "Faculty Enable Registrations");
		}
		
		if(!isNotChecked(ElsevierObjects.Std_Includeinsearch, "Faculty Include Search"))
		{
		click(ElsevierObjects.Std_Includeinsearch, "Faculty Include Search");
		}
		
		click(ElsevierObjects.stu_save, "Faculty Clicking on Save");
		Thread.sleep(6000);
		click(ElsevierObjects.stu_pubilsh, "Faculty Publishing the Changes");
		Thread.sleep(6000);
		Alert();
		Alert();
		return true;
	}catch(Exception e){sgErrMsg="Clicking on Base product link is not successful"+e;return false;}
}

public static boolean EditISBNStatusCode(String ISBN,String Processvalue,String StatusCode) throws Throwable
{
try
{
flag=false;
if(!type(ElsevierObjects.ISBNText, ISBN, "Typing ISBN Value in ISBN Text"))
{flag=false;}
if(!selectByVisibleText(ElsevierObjects.ProcessMenu, Processvalue , "Selecting Values from ProcessMenu"))
{flag=false;}
if(click(ElsevierObjects.GoButton, "Click on GO Button"))
{flag=false;}
Thread.sleep(veryhigh);
if(selectByVisibleText(ElsevierObjects.StatusCode, StatusCode, "Selecting Values from Status Code"))
{flag=false;}
if(click(ElsevierObjects.EditButton, "Click on Edit Button"))
{flag=false;}
Thread.sleep(veryhigh);
String temp=driver.findElement(ElsevierObjects.SuccessMsg).getText();
if(temp.equals("Product Resource is successfully updated"))
{
return true;
}
return flag;
}catch(Exception e){sgErrMsg="Clicking on Base product link is not successful"+e;return false;}

}

public static boolean EditISBNStatusCode(String ISBN,String Processvalue,String Date,String StatusCode) throws Throwable
{
try
{
flag=false;
if(!type(ElsevierObjects.ISBNText, ISBN, "Typing ISBN Value in ISBN Text"))
{flag=false;}
if(!selectByVisibleText(ElsevierObjects.ProcessMenu, Processvalue , "Selecting Values from ProcessMenu"))
{flag=false;}
if(click(ElsevierObjects.GoButton, "Click on GO Button"))
{flag=false;}
Thread.sleep(5000);
if(!type(ElsevierObjects.PublicationDate, Date, "Date"))
{flag=false;}
if(selectByVisibleText(ElsevierObjects.StatusCode, StatusCode, "Selecting Values from Status Code"))
{flag=false;}
if(click(ElsevierObjects.EditButton, "Click on Edit Button"))
{flag=false;}
Thread.sleep(veryhigh);
Thread.sleep(veryhigh);
String temp=driver.findElement(ElsevierObjects.SuccessMsg).getText();
if(temp.equals("Product Resource is successfully updated"))
{
return true;
}
return flag;
}catch(Exception e){sgErrMsg="Clicking on Base product link is not successful"+e;return false;}

}
public static boolean cacelPreOrder(String isbnNumber) throws Throwable{
	boolean flag=true;
	try{
		System.out.println("");
		List<WebElement> isbNumberList = driver.findElements(By.xpath(".//*[@id='orderDetails']//table//table//table//table//tr//td[text()=' "+isbnNumber+"']"));
		for(WebElement webElement : isbNumberList){
			if(webElement.getTagName().equalsIgnoreCase("td")){
				//if(webElement.getText().equalsIgnoreCase("ISBN")){
					if(webElement.getText().contains(isbnNumber)){
						if(isElementPresent(By.xpath(".//*[@id='orderDetails']//tr[*]//td//input"))){
							Reporters.failureReport("Verifying user do not see Cancel Pre-order Item button for any Packaged preorder item: "+isbnNumber, "Cancel PreOdrer Button Existed For Isbn: "+isbnNumber);
						}
						else{
							Reporters.SuccessReport("Verifying user do not see Cancel Pre-order Item button for any Packaged preorder item: "+isbnNumber, "Cancel PreOdrer Button is Not There For Isbn: "+isbnNumber);
						}
						}
					}
				}
			//}
	}
	catch(Exception e){
		sgErrMsg=e.getMessage();
		System.out.println(e.getMessage());
		return false;
	}
	return flag;
}


}

