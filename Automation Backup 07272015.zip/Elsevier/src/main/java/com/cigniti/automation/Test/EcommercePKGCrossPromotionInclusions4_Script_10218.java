package com.cigniti.automation.Test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.cigniti.automation.BusinessFunctions.EcommercePKGCrossPromotionInclusions4_10218;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Base;


public class EcommercePKGCrossPromotionInclusions4_Script_10218 extends EcommercePKGCrossPromotionInclusions4_10218{

	@Test
	public void ecommercePKGCrossPromotionInclusions4_10218() throws Throwable
	{
	try{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		SwitchToBrowser(ElsevierObjects.adminBrowserType);
		writeReport(evolveAdminlogin(),"Login to Application Using User Credentials"+adminUser,
                "Launching the URL for User is successful </br > Login to Application Using User credentails :"+adminUser+" is Successful",
                   "Launching and Login to Application Using User credentails : "+ adminUser+" is Failed");
		
		verifyEcommerceLink();
		
		if(viewTopViewAddPakage())
		{
     		Reporters.SuccessReport("Validate the 'Package Items section' of the page ", "All fields are available in Package item section");
		}
		else
		{	
			Reporters.failureReport("Validate the 'Package Items section' of the page ", "All fields are not available in Package item section");
		}
		
		cloneEnabled();
		
		if(inputPackageData())
		{
     		Reporters.SuccessReport("Input the Package Data", "The data is correctly entered into the fields");
		}
		else
		{
			
			Reporters.failureReport("Input the Package Data", "The data is Not correctly entered into the fields");
		}
		
		verifyAndAddISBNPackages();
		
	
		
		crossPromotionTab();
		
		validateIncludeAllProducts();
		if(validateProfitCenterInclusion())
		{
	 		Reporters.SuccessReport("Validating Profit Center Inclusions", "Cross Promotion Inclusions are Successfully Done");
		}
		else
		{
			
			Reporters.failureReport("Validating Profit Center Inclusions", "Cross Promotion Inclusions are failed");
		}
	

		Reporters.SuccessReport("Validate the Profit Center section.", "Validate the Profit Center section");
		if(validateProfitCenter())
		{
	 		Reporters.SuccessReport("Validating Profit Center", "Cross Promotion Inclusions are Successfully Done");
		}
		else
		{
			
			Reporters.failureReport("Validating Profit Center", "Cross Promotion Inclusions are failed");
		}
		
		Reporters.SuccessReport("Validate the Major Subject Code section.", "Validate the Major Subject Code section.");
		if(validateMajorSubjectCodeSection())
		{
	 		Reporters.SuccessReport("Validating Major Subject Code Center", "Cross Promotion Inclusions are Successfully Done");
		}
		else
		{
			
			Reporters.failureReport("Validating Major Subject Code Center", "Cross Promotion Inclusions are failed");
		}
		
		Reporters.SuccessReport("Validate the Product Type section.", "Validate the Product Type section.");
		if(validateProductTypeCodeSection())
		{
	 		Reporters.SuccessReport("Validating Product Type Code Center", "Cross Promotion Inclusions are Successfully Done");
		}
		else
		{
			
			Reporters.failureReport("Validating Product Type Code Center", "Cross Promotion Inclusions are failed");
		}
		
		if(validateISBNSectionFinal())
		{
	 		Reporters.SuccessReport("Validating the ISBN Center Section", "Successfully Validated ISBN Section in the above steps");
		}
		else
		{
			
			Reporters.failureReport("Validating the ISBN Center Section", "Failed to Validate ISBN Section in the above steps");
		}
		
		uploadCSV();
		if(uploadCSVSection())
		{
	 		Reporters.SuccessReport("Validate Upload CSV Section", "CSV File Upload Section validation is Successfully Done in the above steps");
		}
		else
		{
			
			Reporters.failureReport("Validate Upload CSV Section", "CSV File Upload Section validation is failed to do in the above steps");
		}
		
		Thread.sleep(medium);
		
		if(adminLogout()){	
					
			Reporters.SuccessReport("Logout Successful", "Successfully logout from admin");
		}
		else
		{
			
			Reporters.failureReport("Logout Successful", "logout failed from admin");
		}
	}catch(Exception e){
		System.out.println(e.getMessage());
	}
	
	}
	@AfterTest
	public void closeBtrowser() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		//Base.tearDown();
	}
}
