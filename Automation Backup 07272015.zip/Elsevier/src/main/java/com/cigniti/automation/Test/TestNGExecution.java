package com.cigniti.automation.Test;


import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import jxl.Hyperlink;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.WritableCellFormat;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFHyperlink;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import com.cigniti.automation.BusinessFunctions.EvolveCommonBussinessFunctions;
import com.cigniti.automation.ObjectRepository.ElsevierObjects;
import com.cigniti.automation.Utilities.Accessories;
import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.Utilities.Property;
import com.cigniti.automation.accelerators.Base;



public class TestNGExecution {

	public static Property configProps=new Property("config.properties");
	
	public static void main(String[] args) throws Throwable {
		
		System.out.println("Here");
		String FilePath = System.getProperty("user.dir")+"\\Macros\\"+configProps.getProperty("MacroFile");
				
		FileInputStream fs = new FileInputStream(FilePath);

		Workbook wb = Workbook.getWorkbook(fs);
		String sheet=configProps.getProperty("SheetName");
		Sheet sh = wb.getSheet(sheet);
		int rows = sh.getRows();
		int cols = sh.getColumns();

		HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		
		FileInputStream updatefile = new FileInputStream(new File(FilePath));
     
		HSSFWorkbook  upworkbook = new HSSFWorkbook (updatefile);
		HSSFSheet upsheet = upworkbook.getSheet(configProps.getProperty("SheetName"));
				
		for(int row=1; row<sh.getRows(); row++)
		{
			
			
			boolean result=true;
			ArrayList<String> data=new ArrayList<String>();
			for(int col=0;col<cols;col++)
			{
				data.add(sh.getCell(col,row).getContents());
			}
			HSSFRow uprow=upsheet.getRow(row); 
			
			if(data.get(3).toUpperCase().equals("YES"))
			{
				
					
				
				//Student is null and Admin is not null
				if((data.get(1)!=null||(!data.get(1).equals("NA")))&&(data.get(2)==null||data.get(2).equals("NA")))
				{
					System.out.println("Student is null and Admin is not null");
					if(data.get(1).toUpperCase().contains("IE"))
					{
						//if(data.get(1).equalsIgnoreCase(IEVersion()))
							ElsevierObjects.adminBrowserType=data.get(1);
							System.out.println("Admin browser = " + data.get(1));
						/*else
						{
							 HSSFCell cell= uprow.getCell(6);
							 if(cell==null)
								 uprow.createCell(6).setCellValue("Incompatible Browser Version Selected");
							 else
								 cell.setCellValue("Incompatible Browser Version Selected");
							 result=false;
						}*/
					}
					else{
						ElsevierObjects.adminBrowserType=data.get(1);
						System.out.println("Admin browser = " + data.get(1));
					}
				}
				
				//Student is not null and Admin is null
				if((data.get(1)==null||data.get(1).equals("NA"))&&(data.get(2)!=null||(!data.get(2).equals("NA"))))
				{
					System.out.println("Student is not null and Admin is null");
					if(data.get(2).toUpperCase().contains("IE"))
					{
						//if(data.get(2).equalsIgnoreCase(IEVersion()))
							ElsevierObjects.studentBrowserType=data.get(2);
							System.out.println("Student browser = " + data.get(2));
						/*else
						{
							 HSSFCell cell= uprow.getCell(6);
							 if(cell==null)
								 uprow.createCell(6).setCellValue("Incompatible Browser Version Selected");
							 else
								 cell.setCellValue("Incompatible Browser Version Selected");
							 result=false;
						}*/
					}
					else{
						ElsevierObjects.studentBrowserType=data.get(2);
						System.out.println("Student browser = " + data.get(2));
					}
				}
				
				//Both are not null
				if(data.get(1)!=null&&data.get(2)!=null&&(!data.get(1).equals("NA"))&&(!data.get(2).equals("NA")))
				{
					System.out.println("Both are not null");
					if(data.get(1).toUpperCase().contains("IE"))
					{
						//if(data.get(1).equalsIgnoreCase(IEVersion()))
							ElsevierObjects.adminBrowserType=data.get(1);
							System.out.println("Admin browser = " + data.get(1));
						/*else
						{
							 HSSFCell cell= uprow.getCell(6);
							 if(cell==null)
								 uprow.createCell(6).setCellValue("Incompatible Browser Version Selected");
							 else
								 cell.setCellValue("Incompatible Browser Version Selected");
							 result=false;
						}*/
					}
					else{
						ElsevierObjects.adminBrowserType=data.get(1);
						System.out.println("Admin browser = " + data.get(1));
					}
					
					
					if(data.get(2).toUpperCase().contains("IE"))
					{
						//if(data.get(2).equalsIgnoreCase(IEVersion()))
							ElsevierObjects.studentBrowserType=data.get(2);
							System.out.println("Student browser = " + data.get(2));
						/*else
						{
							 HSSFCell cell= uprow.getCell(6);
							 if(cell==null)
								 uprow.createCell(6).setCellValue("Select Local Browser Version");
							 else
								 cell.setCellValue("Select Local Browser Version");
							 result=false;
						}*/
					}
					else{
						ElsevierObjects.studentBrowserType=data.get(2);
						System.out.println("Student browser = " + data.get(2));
					}
				}
				
				
				if(result)
				{
				try
				{	//Base.timeStampBeforeExecution = System.currentTimeMillis();
					
					Base.timeStampBeforeSutie = Accessories.timeStamp().replace(" ","_").replace(":","_").replace(".", "_");
					System.out.println("Base TIme Stamp>>>>"+Base.timeStamp);
				
				
						XmlSuite suite = new XmlSuite();
						suite.setName("TmpSuite");
						XmlTest test = new XmlTest(suite);
						test.setName("TmpTest");
						List<XmlClass> classes = new ArrayList<XmlClass>();
						List<XmlSuite> suites = new ArrayList<XmlSuite>();
						classes.add(new XmlClass("com.cigniti.automation.Test."+data.get(0)));
						test.setXmlClasses(classes) ;
						suites.add(suite);
						TestNG tng = new TestNG();
						tng.setXmlSuites(suites);
						
						tng.run();
						
						HSSFCell resultcell= uprow.getCell(5);
						HSSFRow upResultLinkrow=upsheet.getRow(rows-1); 
						HSSFCell reultPathcell= upResultLinkrow.getCell(4);
						/*				
						if(resultcell==null)
						{
							 uprow.createCell(5).setCellValue(ElsevierObjects.testresult);
						}
						 else
						 {
						        resultcell.setCellValue(ElsevierObjects.testresult);
						 }
						
						 if(reultPathcell==null)
						 {
							HSSFHyperlink link = new HSSFHyperlink(HSSFHyperlink.LINK_FILE);
							link.setTextMark(ElsevierObjects.testresultPath);
							link.setAddress(ElsevierObjects.testresultPath);
							 //upResultLinkrow.createCell(4).setHyperlink(link);
							 
							upResultLinkrow.createCell(4).setCellValue(ElsevierObjects.testresultPath);

						 }
						 else
						 {
							 HSSFHyperlink link = new HSSFHyperlink(HSSFHyperlink.LINK_FILE);
							 link.setTextMark(ElsevierObjects.testresultPath);
							 reultPathcell.setHyperlink(link);
							 reultPathcell.setCellValue(ElsevierObjects.testresultPath);
							 
						 }*/
				
							if(resultcell==null)
							{
								 uprow.createCell(5).setCellValue(ElsevierObjects.testresult);
							}
							 else
							 {
								    
							       resultcell.setCellValue(ElsevierObjects.testresult);
							 }
							 if(reultPathcell==null)
							 {
								
								 uprow.createCell(4).setCellValue(ElsevierObjects.testresultPath);
								 
								 //uprow.createCell(4).setCellValue(ElsevierObjects.testresultPath);
							 }
							 else
							 {
								 
								 reultPathcell.setCellValue(ElsevierObjects.testresultPath);
								 
							 }
						 
						 
						System.out.println("Before");
						System.out.println("testresult = " + ElsevierObjects.testresult);
						System.out.println("studentBrowserType = " + ElsevierObjects.studentBrowserType);
						System.out.println("adminBrowserType = " + ElsevierObjects.adminBrowserType);
						System.out.println("testresultPath = " + ElsevierObjects.testresultPath);
						 ElsevierObjects.testresult=null;
						 ElsevierObjects.studentBrowserType=null;
						 ElsevierObjects.adminBrowserType=null;
						 ElsevierObjects.testresultPath=null;
						 System.out.println("After");
						 System.out.println("testresult = " + ElsevierObjects.testresult);
							System.out.println("studentBrowserType = " + ElsevierObjects.studentBrowserType);
							System.out.println("adminBrowserType = " + ElsevierObjects.adminBrowserType);
							System.out.println("testresultPath = " + ElsevierObjects.testresultPath);
				   
			     }
				catch(Exception ex)
				{
					ex.printStackTrace();
				}
				}
				
				updatefile.close();
			    FileOutputStream outFile =new FileOutputStream(new File(FilePath));
			    upworkbook.write(outFile);
	            outFile.close();				
		}
		}
		HtmlReporters.currentTimeList.add(System.currentTimeMillis());
		Base.tearDown();
		
		 
}
	/*public static String IEVersion() throws IOException
	{
		ArrayList<String> output = new ArrayList<String>();
		Process p = Runtime.getRuntime().exec("reg query \"HKLM\\Software\\Microsoft\\Internet Explorer\" /v Version");
		BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()),8*1024);
		String s = null;
		while ((s = stdInput.readLine()) != null)
		output.add(s);
		
		String var[] = output.get(2).trim().split("   ")[2].trim().split("\\.");
		return "IE"+var[0];
	}*/
	
	
}
