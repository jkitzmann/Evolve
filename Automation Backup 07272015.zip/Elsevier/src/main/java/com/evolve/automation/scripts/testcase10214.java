package com.evolve.automation.scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.cigniti.automation.accelerators.Actiondriver;

public class testcase10214 extends Actiondriver{
  @Test
  public void f() throws Throwable {
	 /* driver.findElement(By.id("userName")).sendKeys("schintakindi");
	  driver.findElement(By.id("password")).sendKeys("Password2");
	  driver.findElement(By.xpath("/html/body/table/tbody/tr[2]/td/div/form/table/tbody/tr[2]/td/table/tbody/tr[2]/td/input[3]")).click();
	  Thread.sleep(medium);
	  driver.findElement(By.xpath(".//*[@id='pageBody']/form/table/tbody/tr[5]/td/table[4]/tbody/tr[2]/td/a")).click();
	  Thread.sleep(medium);
	  driver.findElement(By.id("packagename")).sendKeys("achanti");
	  driver.findElement(By.id("saveBookStorePackage")).click();
	  Thread.sleep(medium);
	  
	  //Alert();
	  
	  //String str=driver.findElement(By.xpath(".//*[@id='isbn']")).getAttribute("disabled");
	  //System.out.println(str);
	  
	  driver.findElement(By.id("packageKey")).sendKeys("achanti456789");
	  driver.findElement(By.id("packagename")).sendKeys("lokesh");
	  
	  driver.findElement(By.id("saveBookStorePackage")).click();
	  Thread.sleep(medium);
	  driver.findElement(By.xpath(".//*[@id='isbn']")).sendKeys("9780323066342");
	  driver.findElement(By.id("addBookStorePackageItem")).click();
	  Thread.sleep(medium);
	  String str1=driver.findElement(By.xpath(".//*[@id='packageItems']/tr[1]")).getText();
	  System.out.println(str1);
	  Thread.sleep(medium);*/
	  
	  
  }
}
