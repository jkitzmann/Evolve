package sample;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

import jxl.Sheet;
import jxl.Workbook;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cigniti.automation.Utilities.ElsevierConstants;

public class XelRead {
	public static String path="C:\\Users\\IN00893\\Desktop\\Elsevier 27-08-2014\\Elsevier\\TestData\\TestData.xlsx";
	public static String columnDataByHeaderName()
	{
		 String cellData = null;
		 int row;
	        try {
	            File f = new File(path);
	            FileInputStream ios = new FileInputStream(f);
	            XSSFWorkbook workbook = new XSSFWorkbook(ios);
	            XSSFSheet sheet = workbook.getSheet("TC-9807");
	            Iterator<Row> rowIterator = sheet.iterator();
	            //columndata = new ArrayList<String>();

	            while (rowIterator.hasNext()) {
	                Row row1 = rowIterator.next();
	                Iterator<Cell> cellIterator = row1.cellIterator();
	                while (cellIterator.hasNext()) {
	                    Cell cell = cellIterator.next();
	                    int colnum=cell.getColumnIndex();
	                   // if(row.getRowNum() > 0){ //To filter column headings
	                        //if(cell.getColumnIndex() == colindex){// To match column index
	                        	if(cell.getStringCellValue().equalsIgnoreCase("Catalogs")){// To match column index
	                        		cellData=sheet.getRow(1).getCell(colnum).toString();
	                        		//sheet.getRow(row).getCell(ColNum);
	                        		/*switch(cell.getCellType()) {
	                				case Cell.CELL_TYPE_STRING: 
	                					cellData = cell.getStringCellValue();
	                					break;
	                				case Cell.CELL_TYPE_NUMERIC:  
	                					cellData = ""+cell.getNumericCellValue();
	                					break;*/
	                            
	                        //}
	                    }
	                }
	            }
	            ios.close();
	            //System.out.println(columndata);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        
	        //returns the complete column data
	        return cellData;		
	}
	
	/*public static XSSFSheet wrkSheetObj,inputSheetObj =null;
    public static XSSFWorkbook wrkBookObj =null;
    
    public static  XSSFSheet getSheetObject(String inputDataFilePath, String SheetName) throws Exception
	{
		FileInputStream file = new FileInputStream(new File(inputDataFilePath));
		XSSFWorkbook wrkBookObj = new XSSFWorkbook(file); 
		XSSFSheet wrkSheetObj= wrkBookObj.getSheet(SheetName);		
		return wrkSheetObj;
	}
    
    public static String getSheetCellData(Sheet inputSheetObj, String ColumnName,int row) throws Exception
	{		
    	String cellData=null;
    	String cellDataFlag="False";
		int SheetColCount=inputSheetObj.getColumns();
		for(int Colcnt=0;Colcnt<SheetColCount;Colcnt++)
		{
			if((inputSheetObj.getCell(Colcnt,0).getContents()).equals(ColumnName))
			{
				cellData=inputSheetObj.getCell(Colcnt, row).getContents();
				cellDataFlag="True";
				//System.out.println("Column Match and data is  ="+inputSheetObj.getCell(Colcnt, row).getContents());
			}			
		}
		if(cellDataFlag.equals("False"))				
			System.out.println("Column Name: "+ColumnName+" doesn't exist in the sheet");
		return cellData;
		
	}
	*/
	public static void main(String args[]){
		XelRead xl=new XelRead();
		String name=xl.columnDataByHeaderName();
		System.out.println(name);
		//xl.getSheetCellData(ElsevierConstants.EXCEL_INPUT_SHEET_PATH, "Catalogs", 1);
	}
}
