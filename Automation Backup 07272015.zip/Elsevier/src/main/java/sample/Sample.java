package sample;

import java.io.IOException;

import org.testng.annotations.AfterTest;

import com.cigniti.automation.Utilities.Reporters;
import com.cigniti.automation.accelerators.Actiondriver;
import com.cigniti.automation.datadriven.ReadResourceData;

public class Sample{

	public static void main(String[] args) throws IOException {
		
		System.out.println(ReadResourceData.readResourceData());
		System.err.println(ReadResourceData.getResourceData("TC-10214-1",""));
	}
}
