package com.cigniti.automation.Test;

import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.cigniti.automation.Utilities.HtmlReporters;
import com.cigniti.automation.accelerators.Actiondriver;
import com.cigniti.automation.accelerators.Base;

public class sampleTestNG extends Actiondriver{
	@BeforeTest
	public void before() throws Throwable{
		//HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
		driver.get("http://www.facebook.com");
		driver.manage().window().maximize();
	}
  @Test
  public void f() throws Throwable {
	 HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
	  isElementPresent(By.xpath(".//*[@id='u_0_g']/span[1]/label[text()='Female']"), "Femle ");
	  verifyText(By.xpath(".//*[@id='content']/div/div[1]/div/div/div[1]/div[3]/div[2]/span[1]"), " Find more ", "Element is verified");
  }
  
  @AfterTest
  public void tear() throws Throwable{
	  HtmlReporters.currentTimeList.add(System.currentTimeMillis());	
	  Base.tearDown();
  }
}
